//
//  MenuL3Controller.m
//  TapMyDish
//
//  Created by BDMacMini1 on 25/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MenuL3Controller.h"
#import "MenuItem.h"
#import "StringUnity.h"
#import "PhotoView.h"
#import "PostMethodUse.h"
#import "UIImage_withColor.h"
#import "StringUnity.h"

@interface MenuL3Controller (){
    __weak IBOutlet UITabBar* tabBar;
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* MyPanel;
    __weak IBOutlet UINavigationItem* NavItem;
    
    __weak IBOutlet UIView* UpperPart;
    __weak IBOutlet UIView* LowerPart;
    
    
    
    
    __weak IBOutlet UILabel* FoodCataTitleLabel;
    __weak IBOutlet UILabel* FoodCataDescribe;
    __weak IBOutlet UILabel* FoodIntroHeader;
    
    
    
    //Font Size Short Hand
    CGFloat fSUse;
    CGFloat fUse;
    
    
    NSMutableDictionary* QueryDict;
    int ML1ChosenIndex;
    int ML2ChosenIndex;
    
    NSMutableDictionary* M3Dict;
}


@end

@implementation MenuL3Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [self ShowTheImagePopUpWith:nil withDish:nil];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}
-(void)viewWillAppear:(BOOL)animated{
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self setTabBarOutLook];
    [self setFontSizes];
    
    //Load Item Use
    //[self ReloadLayout];   // called in setFont already;
    
    //NSLog(@"");
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(void) LoadDataFromML2Page:(NSMutableDictionary*) TheDict andPassM1Key:(int)indexM1 andPassM2Key:(int)indexM2{
    QueryDict = TheDict;
    ML1ChosenIndex = indexM1;
    ML2ChosenIndex = indexM2;
    NSMutableDictionary* dictM2 = [[TheDict objectForKey:@"menu"]objectForKey:[NSString stringWithFormat:@"%d",indexM1]];
    
    M3Dict = [[dictM2 objectForKey:@"m2"] objectForKey:[NSString stringWithFormat:@"%d",indexM2]];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


-(void) ReloadLayout{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    while ([LowerPart.subviews count]>0){
        [[LowerPart.subviews objectAtIndex:0] removeFromSuperview];
    }
    if (M3Dict!=nil) {
        NavItem.title = [StringUnity RefinedString:[M3Dict objectForKey:@"t"]];
    //Must have
    UIFont* headerFonts = [UIFont fontWithName:@"STHeitiTC-Medium" size:fUse*1.2];
    UIFont* DescribeFonts = [UIFont fontWithName:@"Heiti TC" size:fUse];
    NSString* tStr =[StringUnity RefinedString:[M3Dict objectForKey:@"t"]];
    [FoodCataTitleLabel setText:tStr];
    [FoodCataTitleLabel setFont:headerFonts];
    [FoodCataDescribe setText:[StringUnity RefinedString:[M3Dict objectForKey:@"remark"]]];
    [FoodCataDescribe setFont:DescribeFonts];
    NSString* tStr2 = [NSString stringWithFormat:@"%@有以下選擇：", tStr];
    [FoodIntroHeader setText:tStr2];
    [FoodIntroHeader setFont:headerFonts];
    if (!isNoColor){
        [FoodCataTitleLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [FoodIntroHeader setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
    }else{
        [FoodCataTitleLabel setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
        [FoodIntroHeader setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
    }
        [UpperPart setAccessibilityLabel:[StringUnity ReadWordRefinement:[NSString stringWithFormat:@"%@，%@，%@", FoodCataTitleLabel.text, FoodCataDescribe.text, FoodIntroHeader.text]]];
        
    UIView* LastTarget = LowerPart;
    NSMutableDictionary* M3DictInner = [M3Dict objectForKey:@"m3"];
        NSMutableDictionary* tmp = [M3DictInner mutableCopy];
        NSInteger keyindex =0;
        while (tmp.count>0){
            while ([tmp objectForKey:[NSString stringWithFormat: @"%ld", (long)keyindex]] == nil) {
                keyindex = keyindex+1;
            }
            NSMutableDictionary* nowTargetMenu = [tmp objectForKey:[NSString stringWithFormat: @"%ld", (long)keyindex]];
            MenuItem * mi = [[MenuItem alloc] initWithFrame:CGRectZero];
            //setup
            [mi InitialSetLook:nowTargetMenu withParent:self];
            [mi SetFontSize:fUse andHeaderSize:fSUse];
            //add on
            [LowerPart addSubview:mi];
            //Position
            [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:mi attribute:(NSLayoutAttributeLeft) relatedBy:(NSLayoutRelationEqual) toItem:LowerPart attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:mi attribute:(NSLayoutAttributeRight) relatedBy:(NSLayoutRelationEqual) toItem:LowerPart attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
            if (LastTarget == LowerPart){
                [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:mi attribute:(NSLayoutAttributeTop) relatedBy:(NSLayoutRelationEqual) toItem:LowerPart attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
            }else{
                [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:mi attribute:(NSLayoutAttributeTop) relatedBy:(NSLayoutRelationEqual) toItem:LastTarget attribute:NSLayoutAttributeBottom multiplier:1 constant:1]];
            }
            //finally
            mi.translatesAutoresizingMaskIntoConstraints = NO;
            ////Shadow
            mi.layer.shadowColor = [UIColor grayColor].CGColor;
            mi.layer.shadowOffset = CGSizeMake(1, 2);
            mi.layer.shadowOpacity = 0.5;
            mi.layer.shadowRadius=1.0;
            LastTarget = mi;
            [tmp removeObjectForKey:[NSString stringWithFormat: @"%ld", (long)keyindex]];
        }
        //Seal no need
        [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:LastTarget attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationLessThanOrEqual toItem:LowerPart attribute:NSLayoutAttributeBottom multiplier:1 constant:-8]];
    }
}


-(void) ShowTheImagePopUpWith:(UIImage*) myImage withDish:(NSString*) DishName{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    PhotoView* photo = [[PhotoView alloc] initWithFrame:CGRectMake(0 ,0, screenRect.size.width, screenRect.size.height)];
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
    if ([photo SetPhoto:myImage withDishName:DishName]){
        [photo setAlpha:0.0];
        [currentWindow addSubview:photo];
        [UIView beginAnimations:nil context:nil];
        [photo setAlpha:1.0];
        [UIView commitAnimations];
    }
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, photo.CloseBtn);
//    [photo addConstraint:[NSLayoutConstraint constraintWithItem:photo attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.view.frame.size.width]];
//    [photo addConstraint:[NSLayoutConstraint constraintWithItem:photo attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.view.frame.size.height+self.view.frame.origin.y]];
//    photo.translatesAutoresizingMaskIntoConstraints = NO;
//    [photo setNeedsLayout];
//    [photo layoutIfNeeded];
}


#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        
        [self ReloadLayout];
        
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,MyPanel.bounds.size.height);
    [myScroll setContentSize:CGSizeMake(0,MyPanel.bounds.size.height)];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}




@end
