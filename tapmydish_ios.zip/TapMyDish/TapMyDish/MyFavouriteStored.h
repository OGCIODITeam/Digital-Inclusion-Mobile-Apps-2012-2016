//
//  MyFavouriteStored.h
//  TapMyDish
//
//  Created by BDMacMini1 on 6/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface MyFavouriteStored : NSManagedObject

@property (nonatomic, retain) NSString* rId;
@property (nonatomic, retain) NSDate * date;
@property (nonatomic, retain) id shopData;

@end

@interface ShopData : NSValueTransformer

@end
