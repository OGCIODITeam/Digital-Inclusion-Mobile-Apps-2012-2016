//
//  RestaurantBulletPoint.h
//  TapMyDish
//
//  Created by BDMacMini1 on 4/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RestaurantBulletPoint : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UILabel *PointInfo;
@property (weak, nonatomic) IBOutlet UIImageView *typeIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *DotHeight;
@property (weak, nonatomic) IBOutlet UILabel *DotTextLabel;


-(void) setFontSize:(CGFloat)FS;

@end
