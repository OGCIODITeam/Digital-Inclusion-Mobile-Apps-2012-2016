//
//  SearchResultViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 6/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface SearchResultViewController : UIViewController<UITabBarDelegate>

-(void) LoadSearchDT:(NSString*) DT AndLocation:(CLLocation*) location;
-(void) LoadSearchSID:(NSString*) ID;
-(void) LoadSearchTwoStringsWithOne:(NSString*) Str1 andTwo:(NSString*) Str2 AndLocation:(CLLocation*) location;
-(void) LoadSearchLocationLat:(CLLocation*) location;

-(void) LoadSearchAdvance:(NSString*) query AndLocation:(CLLocation*) location;

@end
