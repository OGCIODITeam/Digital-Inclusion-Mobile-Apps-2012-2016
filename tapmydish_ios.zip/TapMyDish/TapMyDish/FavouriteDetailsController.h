//
//  FavouriteDetailsController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 7/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface FavouriteDetailsController : UIViewController<UITabBarDelegate,CLLocationManagerDelegate>

-(void) LoadDataWithShopID:(NSString*) ShopID;

@end
