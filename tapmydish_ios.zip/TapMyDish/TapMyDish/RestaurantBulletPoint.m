//
//  RestaurantBulletPoint.m
//  TapMyDish
//
//  Created by BDMacMini1 on 4/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "RestaurantBulletPoint.h"

@implementation RestaurantBulletPoint

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(void) setFontSize:(CGFloat)FS{
    _DotHeight.constant = FS;
    [_PointInfo setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_DotTextLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
}


@end
