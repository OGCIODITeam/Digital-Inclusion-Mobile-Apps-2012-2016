//
//  CollectionCell.h
//  TapMyDish
//
//  Created by BDMacMini1 on 5/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *CataTitle;

@end
