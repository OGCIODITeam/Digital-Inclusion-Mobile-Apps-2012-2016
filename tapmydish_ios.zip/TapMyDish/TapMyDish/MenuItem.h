//
//  MenuItem.h
//  TapMyDish
//
//  Created by BDMacMini1 on 26/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuItem : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UILabel *DishName;
@property (weak, nonatomic) IBOutlet UILabel *PriceLabel;
@property (weak, nonatomic) IBOutlet UIImageView *ContentImage;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *ContentImageHeight;
@property (weak, nonatomic) IBOutlet UILabel *FoodHeader;
@property (weak, nonatomic) IBOutlet UILabel *FoodDetail;
@property (weak, nonatomic) IBOutlet UIView *PhotoBtnContainer;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *PhotoBtnHeight;



-(void) InitialSetLook:(NSMutableDictionary*) Dict withParent:(id)parent;

-(void) SetFontSize:(CGFloat)fSize andHeaderSize:(CGFloat)fSSize;

@end
