//
//  FavouriteDetailsController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 7/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "FavouriteDetailsController.h"
#import "PostMethodUse.h"
#import "TabItemArrow.h"
#import "StringUnity.h"
#import "MenuL2Controller.h"
#import "MenuL3Controller.h"
#import <CoreLocation/CoreLocation.h>
#import "AppDelegate.h"
#import "CouponListViewController.h"
#import "UIImage_withColor.h"
#import "RestaurantDetailsController.h"

@interface FavouriteDetailsController (){
    
    __weak IBOutlet UITabBar* tabBar;
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* MyPanel;
    __weak IBOutlet UINavigationItem* NavItem;
    
    //HeadPart
    __weak IBOutlet UILabel* LastUpdateDate;
    __weak IBOutlet UIImageView* RestOutlook;
    __weak IBOutlet UIImageView* DescriptDot;
    __weak IBOutlet NSLayoutConstraint* DescriptDotHeight;
    __weak IBOutlet UILabel* TitleLabel;
    __weak IBOutlet UILabel* DescriptLabel;
    
    //StomachParts
    __weak IBOutlet UIView* UIStomach;
    
    //
    __weak IBOutlet UIView* UIPat;
    
    __weak IBOutlet UIView* LowerPart;
    
    __weak IBOutlet UIImageView *CouponIcon;
    __weak IBOutlet UIImageView *FavourIcon;
    __weak IBOutlet UILabel* CouponLabel;
    __weak IBOutlet UILabel* FavourLabel;
    
    
    __weak IBOutlet UIView* ToHideButton1;
    __weak IBOutlet UIView* ToHideButton2;
    
    //Font Size Short Hand
    CGFloat fSUse;
    CGFloat fUse;
    
    NSDate* LastUpdateDateValue;
    NSMutableDictionary* QueryDict;
    NSString* WEBURL;
    NSString* PHONENO;
    NSString* POS_LAT;
    NSString* POS_LONG;
    int ChosenML2Index;
    NSString* ShopIDChosen;
    
    NSMutableDictionary* QueryD;
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    int tryoutcount;
}

@end

@implementation FavouriteDetailsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[NavItem rightBarButtonItem] setAccessibilityLabel:@"更新"];
    //Fake
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    //Last
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    //Location
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:YES];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self setTabBarOutLook];
    [self setFontSizes];
    
    
    //Load Item Use
    //[self ReloadLayout];   // called in setFont already;
    
    //NSLog(@"");
    
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(void) LoadDataWithShopID:(NSString*) ShopID{
    QueryD = nil;
    ShopIDChosen =ShopID;
    //Load Saved Items
    
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyFavouriteStored" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"rId=%@", ShopIDChosen];
    [fetchRequest setPredicate:predicate];
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        //NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        if([fetchedObjects count]>0){
            QueryDict = [[[fetchedObjects objectAtIndex:0] valueForKey:@"shopData"] mutableCopy];
            LastUpdateDateValue =[[fetchedObjects objectAtIndex:0] valueForKey:@"date"];
        }else{
            //NSLog(@"Nothing Left");
        }
    }
}


-(void) ReloadLayout{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    NSMutableDictionary * info = [QueryDict objectForKey:@"info"];
    [RestOutlook setImage:[PostMethodUse ImageMethodWithNSURL:[info objectForKey:@"shopPic"]]];
    if (isNoColor) [DescriptDot setImage:[UIImage imageNamed:@"dot_grey@3x.png"]];
    else [DescriptDot setImage:[UIImage imageNamed:@"dot@3x.png"]];
    [NavItem setTitle:[StringUnity RefinedString:[info objectForKey:@"name"]]];
    DescriptDotHeight.constant = fUse;
    [TitleLabel setText:[StringUnity RefinedString:[info objectForKey:@"name"]]];
    [TitleLabel setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fUse*1.2]];
    if (isNoColor){
        [TitleLabel setTextColor:[UIColor blackColor]];
        [CouponIcon setImage:[UIImage imageNamed:@"menubtn_coupon_grey@3x.png"]];
        [FavourIcon setImage:[UIImage imageNamed:@"menubtn_favour_grey@3x.png"]];
    }
    else{
        [TitleLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [CouponIcon setImage:[UIImage imageNamed:@"menubtn_coupon@3x.png"]];
        [FavourIcon setImage:[UIImage imageNamed:@"menubtn_favour@3x.png"]];
    }
    [CouponLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
    [FavourLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
    //Data
    NSString* shopT = [info objectForKey:@"shopType"];
    NSArray * ary = [info objectForKey:@"dish"];
    for(id str in ary){
        if (str !=[NSNull null] && ![[StringUnity RefinedString:str]isEqualToString:@""])
            shopT = [NSString stringWithFormat:@"%@．%@",shopT,[StringUnity RefinedString:str]];
    }
    [DescriptLabel setText:shopT];;
    [DescriptLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    //Last Update
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"YYYY年MM月dd日"];
    [LastUpdateDate setText:[NSString stringWithFormat:@"更新日期：%@", [format stringFromDate:LastUpdateDateValue]]];
    [LastUpdateDate setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
    // Add the 5 mess
    while ([UIStomach.subviews count]>0) {
        [[UIStomach.subviews objectAtIndex:[UIStomach.subviews count]-1] removeFromSuperview];
    }
    {
        UIView* LastBottomL = UIStomach;
        UIView* LastBottomR = UIStomach;
        //address
        NSString* addressString = [NSString stringWithFormat:@"%@%@%@", [StringUnity RefinedString:[info objectForKey:@"address"]],[StringUnity RefinedString:[info objectForKey:@"building"]],[StringUnity RefinedString:[info objectForKey:@"floorRoom"]]]; //f
        if (![addressString isEqualToString:@""]){
            UILabel* headingText = [[UILabel alloc] initWithFrame:CGRectZero];
            [headingText setText:@" "];
            [headingText setIsAccessibilityElement:NO];
            [headingText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            UILabel* text = [[UILabel alloc] initWithFrame:CGRectZero];
            UIButton* btn = [[UIButton alloc] initWithFrame:CGRectZero];
            [text setNumberOfLines:0];
            [text setLineBreakMode:NSLineBreakByCharWrapping];
            UIImageView* img = [[UIImageView alloc] initWithFrame:CGRectZero];
            [text setText:[NSString stringWithFormat:@"地址：%@",addressString]];
            [text setIsAccessibilityElement:NO];
            [text setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            if (!isNoColor)[img setImage:[UIImage imageNamed:@"icon_location@3x.png"]];
            else [img setImage:[UIImage imageNamed:@"icon_location_grey@3x.png"]];
            [btn setAccessibilityLabel:[NSString stringWithFormat:@"地址：%@",addressString]];
            POS_LAT=[StringUnity RefinedString:[info objectForKey:@"lat"]];
            POS_LONG=[StringUnity RefinedString:[info objectForKey:@"long"]];
            [btn addTarget:self action:@selector(gotomap:) forControlEvents:UIControlEventTouchUpInside];
            //Position TO COPY
            [UIStomach addSubview:img];
            [UIStomach addSubview:headingText];
            [UIStomach addSubview:text];
            [UIStomach addSubview:btn];
            //btn
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
            //[UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:UIStomach attribute:NSLayoutAttributeWidth multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:text attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            NSLayoutConstraint* nswidth = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:UIStomach attribute:NSLayoutAttributeWidth multiplier:1 constant:0];
            nswidth.priority = 500;
            [UIStomach addConstraint:nswidth];
            //square
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            //Height
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
            
            //LR
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
            
            if (UIStomach == LastBottomL){
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                LastBottomL = img;
                LastBottomR = text;
            }else{
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
                //Align Left
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:LastBottomR attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                LastBottomL = img;
                LastBottomR = text;
            }
            img.translatesAutoresizingMaskIntoConstraints = NO;
            headingText.translatesAutoresizingMaskIntoConstraints = NO;
            btn.translatesAutoresizingMaskIntoConstraints=NO;
            text.translatesAutoresizingMaskIntoConstraints = NO;
        }
        //Clock
        if(false){
            NSString* TimeOp = [[info objectForKey:@"openTime"] objectForKey:@"t"];
            NSString* TimeCl = [[info objectForKey:@"closeTime"] objectForKey:@"t"];
            if (![TimeCl isEqualToString:@"00:00:00"] || ![TimeOp isEqualToString:@"00:00:00"]){
                NSString* TimeOpv = [[info objectForKey:@"openTime"] objectForKey:@"v"];
                NSString* TimeClv = [[info objectForKey:@"closeTime"] objectForKey:@"v"];
                UILabel* headingText = [[UILabel alloc] initWithFrame:CGRectZero];
                [headingText setText:@" "];
                [headingText setIsAccessibilityElement:NO];
                [headingText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
                UILabel* text = [[UILabel alloc] initWithFrame:CGRectZero];
                [text setNumberOfLines:0];
                [text setLineBreakMode:NSLineBreakByCharWrapping];
                UIImageView* img = [[UIImageView alloc] initWithFrame:CGRectZero];
                [text setText:[NSString stringWithFormat:@"營業時間：%@至%@",TimeOpv,TimeClv]];
                [text setText:[NSString stringWithFormat:@"營業時間：%@至%@",TimeOpv,TimeClv]];
                [text setAccessibilityLabel:[NSString stringWithFormat:@"營業時間：%@至%@",TimeOpv,TimeClv]];
                [text setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
                if (!isNoColor)[img setImage:[UIImage imageNamed:@"icon_time@3x.png"]];
                else [img setImage:[UIImage imageNamed:@"icon_time_grey@3x.png"]];
                //Position TO COPY
                [UIStomach addSubview:img];
                [UIStomach addSubview:headingText];
                [UIStomach addSubview:text];
                //square
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
                //Height
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
                //LR
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
                
                if (UIStomach == LastBottomL){
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                    LastBottomL = img;
                    LastBottomR = text;
                }else{
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
                    //Align Left
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:LastBottomR attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                    LastBottomL = img;
                    LastBottomR = text;
                }
                img.translatesAutoresizingMaskIntoConstraints = NO;
                headingText.translatesAutoresizingMaskIntoConstraints = NO;
                text.translatesAutoresizingMaskIntoConstraints = NO;
            }
        }else{
            NSString* TimeRange = [info objectForKey:@"operationHour"];
            if ([info objectForKey:@"operationHour"] == [NSNull null] || TimeRange==nil || [TimeRange isEqualToString:@""]){
                //NSLog(@"No Time");
            }else{
                UILabel* headingText = [[UILabel alloc] initWithFrame:CGRectZero];
                [headingText setText:@" "];
                [headingText setIsAccessibilityElement:NO];
                [headingText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
                UILabel* text = [[UILabel alloc] initWithFrame:CGRectZero];
                [text setNumberOfLines:0];
                [text setLineBreakMode:NSLineBreakByCharWrapping];
                UIImageView* img = [[UIImageView alloc] initWithFrame:CGRectZero];
                [text setText:[NSString stringWithFormat:@"營業時間：%@",[StringUnity RefinedString:TimeRange]]];
                [text setAccessibilityLabel:[NSString stringWithFormat:@"營業時間：%@",[StringUnity RefinedString:TimeRange]]];
                [text setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
                if (!isNoColor)[img setImage:[UIImage imageNamed:@"icon_time@3x.png"]];
                else [img setImage:[UIImage imageNamed:@"icon_time_grey@3x.png"]];
                //Position TO COPY
                [UIStomach addSubview:img];
                [UIStomach addSubview:headingText];
                [UIStomach addSubview:text];
                //square
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
                //Height
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
                //LR
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
                
                if (UIStomach == LastBottomL){
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                    LastBottomL = img;
                    LastBottomR = text;
                }else{
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
                    //Align Left
                    [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:LastBottomR attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                    LastBottomL = img;
                    LastBottomR = text;
                }
                img.translatesAutoresizingMaskIntoConstraints = NO;
                headingText.translatesAutoresizingMaskIntoConstraints = NO;
                text.translatesAutoresizingMaskIntoConstraints = NO;
            }
        }
        //Phone
        NSString* Tel = [info objectForKey:@"tel"];
        if (![Tel isEqualToString:@"0"] && ![Tel isEqualToString:@""]){
            //int telvalue = [Tel intValue];
            //int w = telvalue / 10000;
            //int v = telvalue % 10000;
            UILabel* headingText = [[UILabel alloc] initWithFrame:CGRectZero];
            [headingText setText:@" "];
            [headingText setIsAccessibilityElement:NO];
            [headingText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            UILabel* text = [[UILabel alloc] initWithFrame:CGRectZero];
            UIButton* btn = [[UIButton alloc] initWithFrame:CGRectZero];
            [text setNumberOfLines:0];
            [text setLineBreakMode:NSLineBreakByCharWrapping];
            UIImageView* img = [[UIImageView alloc] initWithFrame:CGRectZero];
            //[text setText:[NSString stringWithFormat:@"電話：%04d %04d",w,v]];
            [text setText:[NSString stringWithFormat:@"電話：%@",Tel]];
            [text setIsAccessibilityElement:NO];
            [text setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            if (!isNoColor)[img setImage:[UIImage imageNamed:@"icon_phone@3x.png"]];
            else [img setImage:[UIImage imageNamed:@"icon_phone_grey@3x.png"]];
            //[btn setAccessibilityLabel:[NSString stringWithFormat:@"電話：%04d %04d",w,v]];
            [btn setAccessibilityLabel:[NSString stringWithFormat:@"電話：%@",Tel]];
            PHONENO=Tel;
            [btn addTarget:self action:@selector(gotophone:) forControlEvents:UIControlEventTouchUpInside];
            //Position TO COPY
            [UIStomach addSubview:img];
            [UIStomach addSubview:headingText];
            [UIStomach addSubview:text];
            [UIStomach addSubview:btn];
            //btn
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
            //[UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:UIStomach attribute:NSLayoutAttributeWidth multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:text attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            NSLayoutConstraint* nswidth = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:UIStomach attribute:NSLayoutAttributeWidth multiplier:1 constant:0];
            nswidth.priority = 500;
            [UIStomach addConstraint:nswidth];
            //square
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            //Height
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
            //LR
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
            
            if (UIStomach == LastBottomL){
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                LastBottomL = img;
                LastBottomR = text;
            }else{
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
                //Align Left
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:LastBottomR attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                LastBottomL = img;
                LastBottomR = text;
            }
            img.translatesAutoresizingMaskIntoConstraints = NO;
            headingText.translatesAutoresizingMaskIntoConstraints = NO;
            btn.translatesAutoresizingMaskIntoConstraints = NO;
            text.translatesAutoresizingMaskIntoConstraints = NO;
        }
        //Web
        NSString* web = [info objectForKey:@"web"];
        if (![web isEqualToString:@""]){
            UILabel* headingText = [[UILabel alloc] initWithFrame:CGRectZero];
            [headingText setText:@" "];
            [headingText setIsAccessibilityElement:NO];
            [headingText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            UIButton* btn = [[UIButton alloc] initWithFrame:CGRectZero];
            UILabel* text = [[UILabel alloc] initWithFrame:CGRectZero];
            [text setNumberOfLines:0];
            [text setLineBreakMode:NSLineBreakByCharWrapping];
            [text setIsAccessibilityElement:NO];
            UIImageView* img = [[UIImageView alloc] initWithFrame:CGRectZero];
            [text setText:[NSString stringWithFormat:@"網址：%@",[StringUnity RefinedString:web]]];
            [text setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            if (!isNoColor)[img setImage:[UIImage imageNamed:@"icon_website@3x.png"]];
            else [img setImage:[UIImage imageNamed:@"icon_website_grey@3x.png"]];
            [btn setAccessibilityLabel:[NSString stringWithFormat:@"網址：%@",[StringUnity RefinedString:web]]];
            WEBURL = web;
            [btn addTarget:self action:@selector(gotoweb:) forControlEvents:UIControlEventTouchUpInside];
            //Position TO COPY
            [UIStomach addSubview:img];
            [UIStomach addSubview:headingText];
            [UIStomach addSubview:text];
            [UIStomach addSubview:btn];
            //btn
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
            //[UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:UIStomach attribute:NSLayoutAttributeWidth multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:text attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            NSLayoutConstraint* nswidth = [NSLayoutConstraint constraintWithItem:btn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:UIStomach attribute:NSLayoutAttributeWidth multiplier:1 constant:0];
            nswidth.priority = 500;
            [UIStomach addConstraint:nswidth];
            //square
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            //Height
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
            //LR
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
            
            if (UIStomach == LastBottomL){
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                LastBottomL = img;
                LastBottomR = text;
            }else{
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:headingText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:headingText attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
                //Align Left
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:LastBottomR attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                LastBottomL = img;
                LastBottomR = text;
            }
            headingText.translatesAutoresizingMaskIntoConstraints = NO;
            btn.translatesAutoresizingMaskIntoConstraints = NO;
            img.translatesAutoresizingMaskIntoConstraints = NO;
            text.translatesAutoresizingMaskIntoConstraints = NO;
        }
        //TakeAway
        NSString* HaveTA = [info objectForKey:@"haveTakenAway"];
        if (![HaveTA isEqualToString:@"0"]){
            UILabel* text = [[UILabel alloc] initWithFrame:CGRectZero];
            [text setNumberOfLines:0];
            [text setLineBreakMode:NSLineBreakByCharWrapping];
            UIImageView* img = [[UIImageView alloc] initWithFrame:CGRectZero];
            [text setText:[NSString stringWithFormat:@"設有外賣服務"]];
            [text setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            if (!isNoColor)[img setImage:[UIImage imageNamed:@"tick@3x.png"]];
            else [img setImage:[UIImage imageNamed:@"tick_grey@3x.png"]];
            //Position TO COPY
            [UIStomach addSubview:img];
            [UIStomach addSubview:text];
            //square
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            //Height
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
            //LR
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
            if (UIStomach == LastBottomL){
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:img attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeCenterY multiplier:1 constant:8]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UIStomach attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
                LastBottomL = img;
                LastBottomR = text;
            }else{
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:text attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:img attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
                //Align Left
                [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:LastBottomR attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:text attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
                LastBottomL = img;
                LastBottomR = text;
            }
            img.translatesAutoresizingMaskIntoConstraints = NO;
            text.translatesAutoresizingMaskIntoConstraints = NO;
        }
        //seal
        if (UIStomach != LastBottomL){
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomL attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
            [UIStomach addConstraint:[NSLayoutConstraint constraintWithItem:UIStomach attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastBottomR attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
        }
    }
    //End Of 5 Mess
    //Bottom Parts
    while ([LowerPart.subviews count]>0){
        [[LowerPart.subviews objectAtIndex:0] removeFromSuperview];
    }
    id canMenu = [info objectForKey:@"CanMenu"];
    BOOL canMenuBool = YES;
    if (canMenu != [NSNull null] && canMenu!=nil){
        canMenuBool = [canMenu boolValue];
    }
    if (canMenuBool){
        if ([QueryDict objectForKey:@"menu"]!=nil && [[QueryDict objectForKey:@"menu"] count]>0){
            NSMutableDictionary* menu =[QueryDict objectForKey:@"menu"];
            //Head
            UIView* HeadBase = [[UIView alloc] initWithFrame:CGRectZero];
            [HeadBase setBackgroundColor:[UIColor whiteColor]];
            UIImageView* headIcon = [[UIImageView alloc]initWithFrame:CGRectZero];
            UILabel* headText = [[UILabel alloc]initWithFrame:CGRectZero];
            [headText setText:@"餐牌分類"];
            [headText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
            if (!isNoColor){
                [headIcon setImage:[UIImage imageNamed:@"icon_menu@3x.png"]];
                [headText setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
            } else {
                [headIcon setImage:[UIImage imageNamed:@"icon_menu_grey@3x.png"]];
                [headText setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
            }
            [HeadBase addSubview:headIcon];
            [HeadBase addSubview:headText];
            [LowerPart addSubview:HeadBase];
            //HeadCons
            [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:HeadBase attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:LowerPart attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
            [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:HeadBase attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:LowerPart attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:HeadBase attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:LowerPart attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
            //Head Icon
            ////SQ
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:headIcon attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
            ////H
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:fUse]];
            ////Real
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:HeadBase attribute:NSLayoutAttributeTop multiplier:1 constant:16]];
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:HeadBase attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationLessThanOrEqual toItem:HeadBase attribute:NSLayoutAttributeBottom multiplier:1 constant:-16]];
            
            //HeadText,
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headText attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:HeadBase attribute:NSLayoutAttributeTop multiplier:1 constant:16]];
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headText attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:HeadBase attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headText attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationLessThanOrEqual toItem:HeadBase attribute:NSLayoutAttributeBottom multiplier:1 constant:-16]];
            //icon to label
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:headText attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
            ////center with word
            [HeadBase addConstraint:[NSLayoutConstraint constraintWithItem:headIcon attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:HeadBase attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            //Final Add
            HeadBase.translatesAutoresizingMaskIntoConstraints = NO;
            headIcon.translatesAutoresizingMaskIntoConstraints = NO;
            headText.translatesAutoresizingMaskIntoConstraints = NO;
            ////shadow
            HeadBase.layer.shadowColor = [UIColor grayColor].CGColor;
            HeadBase.layer.shadowOffset = CGSizeMake(1, 2);
            HeadBase.layer.shadowOpacity = 0.5;
            HeadBase.layer.shadowRadius=1.0;
            
            UIView* LastSlot = HeadBase;
            
            //End Head
            
            NSMutableDictionary* menuDup = [menu mutableCopy];
            NSInteger keyindex = 0;
            while (menuDup.count>0){
                while ([menuDup objectForKey:[NSString stringWithFormat:@"%ld", (long)keyindex]]==nil){
                    keyindex = keyindex+1;
                }
                NSString * key = [NSString stringWithFormat:@"%ld", (long)keyindex];
                NSMutableDictionary * dict = [menu objectForKey:key];
                TabItemArrow* arrow = [[TabItemArrow alloc] initWithFrame:CGRectZero];
                [arrow setFontSize:fUse];
                [arrow setLabelText:[StringUnity RefinedString:[dict objectForKey:@"t"]]];
                [arrow.LabelButtonForClick setTag:[key intValue]];
                [arrow.LabelButtonForClick addTarget:self action:@selector(gotoMenu:) forControlEvents:UIControlEventTouchUpInside];
                [LowerPart addSubview:arrow];
                // Positiioning
                [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:LastSlot attribute:NSLayoutAttributeBottom multiplier:1 constant:1]];
                [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:LowerPart attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
                [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:LowerPart attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
                //Final
                arrow.translatesAutoresizingMaskIntoConstraints = NO;
                ////shadow
                arrow.layer.shadowColor = [UIColor grayColor].CGColor;
                arrow.layer.shadowOffset = CGSizeMake(1, 2);
                arrow.layer.shadowOpacity = 0.5;
                arrow.layer.shadowRadius=1.0;
                LastSlot = arrow;
                [menuDup removeObjectForKey:key];
            }
            //Seal, need for >=
            
            [LowerPart addConstraint:[NSLayoutConstraint constraintWithItem:LastSlot attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationLessThanOrEqual toItem:LowerPart attribute:NSLayoutAttributeBottom multiplier:1 constant:-8]];
        }
    }else{
        [ToHideButton1 removeFromSuperview];
        [ToHideButton2 removeFromSuperview];
    }
}


-(IBAction)deleteFavour:(id)sender{
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delayDel)
               withObject:nil
               afterDelay:0.1];
}


-(void)delayDel{
    if([PostMethodUse getBeforeVoiceOut]){
        //Kill
        AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
        
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyFavouriteStored" inManagedObjectContext: managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"rId=%@", ShopIDChosen];
        [fetchRequest setPredicate:predicate];
        NSError *error = nil;
        NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
        if (fetchedObjects == nil) {
            NSLog(@"Fetch error, something's wrong. %@",error);
        }
        else{
            if([fetchedObjects count]>0){
                for (NSManagedObject *product in fetchedObjects) {
                    [managedObjectContext deleteObject:product];
                }
                [appDelegate saveContext];
            }else{
                //NSLog(@"Nothing Left");
            }
        }
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self performSelector:@selector(delayDel)
                   withObject:nil
                   afterDelay:0.1];
    }
}

-(void)delayUpdate{
    if([PostMethodUse connectedToInternet]){
        if([PostMethodUse getBeforeVoiceOut]){
            [PostMethodUse setIsFavourite:NO];
            NSMutableDictionary* QueryDictA = [PostMethodUse PostMethodWithFunctionString:[NSString stringWithFormat:@"m=shop_detail&id=%@", ShopIDChosen]];
            {    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
                NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
                
                NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
                NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyFavouriteStored" inManagedObjectContext: managedObjectContext];
                [fetchRequest setEntity:entity];
                
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"rId=%@", ShopIDChosen];
                [fetchRequest setPredicate:predicate];
                NSError *error = nil;
                NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
                if (fetchedObjects == nil) {
                    NSLog(@"Fetch error, something's wrong. %@",error);
                }
                else{
                    if([fetchedObjects count]>0){
                        //NSLog(@"%@",[[[fetchedObjects objectAtIndex:0] valueForKey:@"shopData"] objectForKey:@"info"]);
                        [[fetchedObjects objectAtIndex:0] setValue:[QueryDictA copy] forKey:@"shopData"];
                        [[fetchedObjects objectAtIndex:0] setValue:[NSDate date] forKey:@"date"];
                        QueryDict =[QueryDictA copy];
                    }else{
                        //NSLog(@"Nothing Left");
                    }
                }
                [self LoopAllQueryForPic];
                [appDelegate saveContext];
            }
            [PostMethodUse setIsFavourite:YES];
            // Path Changed
            /*
            [self ReloadLayout];
            [PostMethodUse AfterLoadingLayoutUse];
                // back to refreah
            UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, [NavItem rightBarButtonItem]);
            */
            RestaurantDetailsController* RD = [self.storyboard instantiateViewControllerWithIdentifier:@"RestDetailVC"];
            [RD LoadDataWithShopID:ShopIDChosen];
            NSMutableArray* vcA = [self.navigationController.viewControllers mutableCopy];
            [vcA removeObject:self.navigationController.visibleViewController];
            [vcA addObject:RD];
            [self.navigationController setViewControllers:vcA animated:NO];
        }else{
            [self performSelector:@selector(delayUpdate)
                       withObject:nil
                       afterDelay:0.1];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}


-(void)LoopAllQueryForPic{
    //info Pic
    NSMutableDictionary* info = [QueryDict objectForKey:@"info"];
    [PostMethodUse ImageMethodWithNSURL:[info objectForKey:@"shopPic"]];
    //inner Pics
    NSMutableDictionary* menu = [QueryDict objectForKey:@"menu"];
    for(NSString* key in menu){
        NSMutableDictionary * dict = [menu objectForKey:key];
        NSMutableDictionary * m2 = [dict objectForKey:@"m2"];
        for (NSString * key2 in m2){
            NSMutableDictionary * dict2 = [m2 objectForKey:key2];
            NSMutableDictionary * m3 = [dict2 objectForKey:@"m3"];
            for (NSString * key3 in m3){
                NSMutableDictionary * dict3 = [m3 objectForKey:key3];
                NSString* path =[dict3 objectForKey:@"foodPic"];
                [PostMethodUse ImageMethodWithNSURL:path];
            }
        }
    }
}


-(void)gotoMenu:(id)sender{
    UIButton* btn = (UIButton*)sender;
    ChosenML2Index = btn.tag;
    //selecter
    //PreCheck SingleTon
    NSMutableDictionary* pre = [[QueryDict objectForKey:@"menu"]objectForKey:[NSString stringWithFormat:@"%d",ChosenML2Index]];
    
    NSMutableDictionary* m2dictInner =[pre objectForKey:@"m2"];
    if ([m2dictInner count]==1){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
                   withObject:@"GoToML3Directly"
                   afterDelay:0.1];
        //[self performSegueWithIdentifier:@"GoToML3Directly" sender:self];
    }else{
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
                   withObject:@"GoToML2"
                   afterDelay:0.1];
        //[self performSegueWithIdentifier:@"GoToML2" sender:self];
    }
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}

-(void)gotoweb:(id)sender{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:WEBURL]];
}

-(void)gotophone:(id)sender{
    NSString *phoneNumber = [@"telprompt://" stringByAppendingString:PHONENO];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
}

-(void)gotomap:(id)sender{
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    tryoutcount = 0;
    [locationManager startUpdatingLocation];
    if (!([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%@,%@", POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }else{
        [PostMethodUse BeforeLoadingLayoutUse:YES];
    }
}

- (IBAction)refreshButtonPressed:(id)sender {
    if([PostMethodUse connectedToInternet]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        //NSLog(@"refresh pressed");
        //Pulling
        [self performSelector:@selector(delayUpdate)
                   withObject:nil
                   afterDelay:0.1];
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}


-(IBAction)ClickedCoupons:(id)sender{
    if ([[QueryDict objectForKey:@"coupon"] count]>0){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToCouponList"
               afterDelay:0.1];
    }else{
        [PostMethodUse PopUpNoCoupon];
    }
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"GoToML2"]){
        MenuL2Controller* ML2 = segue.destinationViewController;
        [ML2 LoadDataFromML1Page:QueryDict andPassKey:ChosenML2Index];
    }else if ([segue.identifier isEqualToString:@"GoToML3Directly"]){
        NSMutableDictionary* pre = [[QueryDict objectForKey:@"menu"]objectForKey:[NSString stringWithFormat:@"%d",ChosenML2Index]];
        NSMutableDictionary* m2dictInner =[pre objectForKey:@"m2"];
        int ChosenML3Index = 0;
        for (NSString * key in m2dictInner){
            ChosenML3Index = [key integerValue];
        }
        MenuL3Controller* dest = segue.destinationViewController;
        [dest LoadDataFromML2Page:QueryDict andPassM1Key:ChosenML2Index andPassM2Key:ChosenML3Index];
    }else if ([segue.identifier isEqualToString:@"GoToCouponList"]){
        CouponListViewController* dest = segue.destinationViewController;
        [dest LoadWithQuery:[QueryDict objectForKey:@"coupon"] AndTitle:[StringUnity RefinedString:[[QueryDict objectForKey:@"info"] objectForKey:@"name"]]];
    }
}





#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        
        [self ReloadLayout];
        
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,MyPanel.bounds.size.height);
    [myScroll setContentSize:CGSizeMake(0,MyPanel.bounds.size.height)];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}


#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}


#pragma mark - CLLocationManagerDelegate


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //    NSLog(@"didFailWithError: %@", error);
    //    UIAlertView *errorAlert = [[UIAlertView alloc]
    //                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //    [errorAlert show];
    //Location
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount = -100;
        [locationManager stopUpdatingLocation];
        [PostMethodUse AfterLoadingLayoutUse];
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%@,%@", POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if(tryoutcount>=0){
        tryoutcount = -100;
        //NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        //Location
        [locationManager stopUpdatingLocation];
        [PostMethodUse AfterLoadingLayoutUse];
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?saddr=%1.6f,%1.6f&daddr=%@,%@", currentLocation.coordinate.latitude, currentLocation.coordinate.longitude, POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }
}

@end
