//
//  MyHistoryPageViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MyHistoryPageViewController.h"
#import "RestaurantItem.h"
#import "RestaurantBulletPoint.h"
#import "PostMethodUse.h"
#import "RestaurantDetailsController.h"
#import "StringUnity.h"
#import "Adv.h"
#import "AppDelegate.h"
#import "UIImage_withColor.h"

@interface MyHistoryPageViewController ()<UITableViewDelegate, UITableViewDataSource>{
    
    __weak IBOutlet UITabBar* tabBar;
    
    __weak IBOutlet UITableView* tbView;
    
    __weak IBOutlet UILabel *NoSearchMessage;
    __weak IBOutlet UIView *OverlayNoSearch;
    NSMutableArray* TableArray;
    
    //Font Size Short Hand
    CGFloat fSUse;
    CGFloat fUse;
    
    
    
    
    ///Logic
    
    NSMutableArray* QueryArray;
    NSMutableDictionary* ImageDictionary;
    int NowPullLength;
    NSString* ShopIDChosen;
    NSMutableDictionary* QD;
    
    Boolean isNullResult;
    NSString* isNullMessage;
}
@end

@implementation MyHistoryPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [tbView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell"];
    tbView.rowHeight = UITableViewAutomaticDimension;
    tbView.estimatedRowHeight = 414;
    tbView.allowsMultipleSelectionDuringEditing = NO;
    
    [tbView setBackgroundColor:[UIColor colorWithRed:0.9451  green:0.9451  blue:0.9451  alpha:1]];
    //Fake, these should be done by Previous Page
    
    
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
    
    //NSLog(@"Pass");
    

}
-(void) Load{
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyHistory" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    NSSortDescriptor *sortDescriptor1 = [NSSortDescriptor sortDescriptorWithKey:@"dateVisited" ascending:NO];
    QueryArray = [NSMutableArray arrayWithCapacity:0];
    [fetchRequest setSortDescriptors:[[NSArray alloc] initWithObjects:sortDescriptor1,  nil]];
    NSError *error = nil;
    NSArray *fetchedObjects = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        if([fetchedObjects count]>0){
            NSMutableArray* remainder = [NSMutableArray arrayWithCapacity:0];
            for (int i =0;i< [fetchedObjects count];i++){
                if (i<10){
                    //show
                    NSManagedObject* hist = [fetchedObjects objectAtIndex:i];
                    NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:0];
                    [dict setObject:[hist valueForKey:@"bigDistrict"] forKey:@"bigDistrict"];
                    [dict setObject:[hist valueForKey:@"dateVisited"] forKey:@"dateVisited"];
                    [dict setObject:[hist valueForKey:@"dishType1"] forKey:@"dishType1"];
                    [dict setObject:[hist valueForKey:@"dishType2"] forKey:@"dishType2"];
                    [dict setObject:[hist valueForKey:@"dishType3"] forKey:@"dishType3"];
                    [dict setObject:[hist valueForKey:@"haveTakenAway"] forKey:@"haveTakenAway"];
                    [dict setObject:[hist valueForKey:@"rId"] forKey:@"sid"];
                    [dict setObject:[hist valueForKey:@"shopName"] forKey:@"shopName"];
                    [dict setObject:[hist valueForKey:@"shopPic"] forKey:@"shopPic"];
                    [dict setObject:[hist valueForKey:@"shopType"] forKey:@"shopType"];
                    [dict setObject:[hist valueForKey:@"smallDistrict"] forKey:@"smallDistrict"];
                    [QueryArray addObject:dict];
                }else{
                    [remainder addObject:[fetchedObjects objectAtIndex:i]];
                }
            }
            for (NSManagedObject* pro in remainder){
                [managedObjectContext deleteObject:pro];
            }
            [appDelegate saveContext];
        }else{
            //NSLog(@"Nothing Left");
        }
    }
    if ([QueryArray count]==0){
        NowPullLength = 0;
        isNullResult = YES;
        isNullMessage =@"沒有記錄.";
    }else{
        isNullResult = NO;
        NowPullLength = [QueryArray count];
        //AutoLengthen
        if (NowPullLength>[QueryArray count])
            NowPullLength=[QueryArray count];
        ImageDictionary = [NSMutableDictionary dictionaryWithCapacity:0];
        for (int i = 0;i<NowPullLength;i++){
            NSMutableDictionary* dict = [QueryArray objectAtIndex:i];
            if ([dict objectForKey:@"id"]==nil){
                NSString * str = [dict objectForKey:@"shopPic"];
                if ([ImageDictionary objectForKey:str]==nil){
                    [ImageDictionary setObject:[PostMethodUse ImageMethodWithNSURL:str] forKey:str];
                }
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:YES];
    [tabBar setSelectedItem:tabBar.items[4]];
    [self setTabBarOutLook];
    [self setFontSizes];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    
    
    //Load Item Use
    [self Load];
    
    //NSLog(@"");
    if (isNullResult){
        [OverlayNoSearch setHidden:NO];
        [NoSearchMessage setHidden:NO];
        [NoSearchMessage setText:isNullMessage];
    }else{
        [OverlayNoSearch setHidden:YES];
        [NoSearchMessage setHidden:YES];
    }
    
    [tbView reloadData];
    [tbView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];}


-(void) setUpBulletItemFor:(UIView*) view withDict:(NSMutableDictionary*) dict{
    //
    NSString* Reading = @"";
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    UIView* lastItem = view;
    //shopType
    if ([dict objectForKey:@"shopType"]!=[NSNull null] && ![[StringUnity RefinedString:[dict objectForKey:@"shopType"]] isEqualToString:@""]){
        NSString* val = [StringUnity RefinedString:[dict objectForKey:@"shopType"]];
        RestaurantBulletPoint* Bullet1 = [[RestaurantBulletPoint alloc] initWithFrame:CGRectZero];
        if (!isNoColor){
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"dot@3x.png"]];
        }else{
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"dot_grey@3x.png"]];
        }
        [Bullet1 setTranslatesAutoresizingMaskIntoConstraints:NO];
        [Bullet1.PointInfo setText:val];
        [Bullet1 setFontSize:fUse];
        [view addSubview:Bullet1];
        [view addConstraints:Bullet1.constraints];
        Reading = [NSString stringWithFormat:@"%@，%@",Reading,val];
        //Constraints
        if (lastItem==view){
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        }else{
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        }
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        
        lastItem = Bullet1;
    }
    //dishType1
    if ([dict objectForKey:@"dishType1"]!=[NSNull null] && !([[StringUnity RefinedString:[dict objectForKey:@"dishType1"]] isEqualToString:@""])){
        NSString* val = [StringUnity RefinedString:[dict objectForKey:@"dishType1"]];
        if ([dict objectForKey:@"dishType2"]!=[NSNull null] && !([[StringUnity RefinedString:[dict objectForKey:@"dishType2"]] isEqualToString:@""])) val = [NSString stringWithFormat:@"%@．%@",val,[StringUnity RefinedString:[dict objectForKey:@"dishType2"]]];
        if ([dict objectForKey:@"dishType3"]!=[NSNull null] && !([[StringUnity RefinedString:[dict objectForKey:@"dishType3"]] isEqualToString:@""])) val = [NSString stringWithFormat:@"%@．%@",val,[StringUnity RefinedString:[dict objectForKey:@"dishType3"]]];
        RestaurantBulletPoint* Bullet1 = [[RestaurantBulletPoint alloc] initWithFrame:CGRectZero];
        if (!isNoColor){
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"dot@3x.png"]];
        }else{
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"dot_grey@3x.png"]];
        }
        [Bullet1 setTranslatesAutoresizingMaskIntoConstraints:NO];
        [Bullet1.PointInfo setText:val];
        [Bullet1 setFontSize:fUse];
        [view addSubview:Bullet1];
        [view addConstraints:Bullet1.constraints];
        Reading = [NSString stringWithFormat:@"%@，%@",Reading,val];
        //Constraints
        
        if (lastItem==view){
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        }else{
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        }
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        
        lastItem = Bullet1;
    }    //smallDistrict
    //NSLog(@"Small District");
    if ([dict objectForKey:@"smallDistrict"]!=[NSNull null] && !([[StringUnity RefinedString:[dict objectForKey:@"smallDistrict"]] isEqualToString:@""])){
        NSString* val = [StringUnity RefinedString:[dict objectForKey:@"smallDistrict"]];
        RestaurantBulletPoint* Bullet1 = [[RestaurantBulletPoint alloc] initWithFrame:CGRectZero];
        if (!isNoColor){
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"dot@3x.png"]];
        }else{
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"dot_grey@3x.png"]];
        }
        [Bullet1 setTranslatesAutoresizingMaskIntoConstraints:NO];
        [Bullet1.PointInfo setText:val];
        [Bullet1 setFontSize:fUse];
        [view addSubview:Bullet1];
        [view addConstraints:Bullet1.constraints];
        Reading = [NSString stringWithFormat:@"%@，%@",Reading,val];
        //Constraints
        
        if (lastItem==view){
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        }else{
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        }
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        
        lastItem = Bullet1;
    }
    //haveTakenAway
    if (![@"0" isEqualToString:[dict objectForKey:@"haveTakenAway"]] ){
        RestaurantBulletPoint* Bullet1 = [[RestaurantBulletPoint alloc] initWithFrame:CGRectZero];
        if (!isNoColor){
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"tick@3x.png"]];
        }else{
            [Bullet1.typeIcon setImage:[UIImage imageNamed:@"tick_grey@3x.png"]];
        }
        [Bullet1 setTranslatesAutoresizingMaskIntoConstraints:NO];
        [Bullet1.PointInfo setText:@"設有外賣服務"];
        [Bullet1 setFontSize:fUse];
        [view addSubview:Bullet1];
        [view addConstraints:Bullet1.constraints];
        Reading = [NSString stringWithFormat:@"%@，%@",Reading,@"設有外賣服務"];
        //Constraints
        
        if (lastItem==view){
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        }else{
            [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        }
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:Bullet1 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        
        lastItem = Bullet1;
    }
    //emoji
    if ([dict objectForKey:@"emoji1"]!=[NSNull null] && NO){
        //Data
        UIView* emojiBase = [[UIView alloc] initWithFrame:CGRectZero];
        [emojiBase setIsAccessibilityElement:YES];
        UIImageView* emoji1= [[UIImageView alloc] initWithFrame:CGRectZero];
        UILabel* emoji1Label=[[UILabel alloc] initWithFrame:CGRectZero];
        [emoji1Label setIsAccessibilityElement:NO];
        emoji1Label.lineBreakMode =NSLineBreakByCharWrapping;
        emoji1Label.numberOfLines= 0;
        NSString* val1 = [self RefineEmojiNum:[[dict objectForKey:@"emoji1"] intValue]];
        [emoji1Label setText:val1];
        [emoji1Label setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
        UIImageView* emoji2= [[UIImageView alloc] initWithFrame:CGRectZero];
        UILabel* emoji2Label=[[UILabel alloc] initWithFrame:CGRectZero];
        [emoji2Label setIsAccessibilityElement:NO];
        emoji2Label.lineBreakMode =NSLineBreakByCharWrapping;
        emoji2Label.numberOfLines= 0;
        NSString* val2 = [self RefineEmojiNum:[[dict objectForKey:@"emoji2"] intValue]];
        [emoji2Label setText:val2];
        [emoji2Label setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
        UIImageView* emoji3= [[UIImageView alloc] initWithFrame:CGRectZero];
        UILabel* emoji3Label=[[UILabel alloc] initWithFrame:CGRectZero];
        [emoji3Label setIsAccessibilityElement:NO];
        emoji3Label.lineBreakMode =NSLineBreakByCharWrapping;
        emoji3Label.numberOfLines= 0;
        NSString* val3 = [self RefineEmojiNum:[[dict objectForKey:@"emoji3"] intValue]];
        [emoji3Label setText:val3];
        [emoji3Label setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
        if (isNoColor){
            [emoji1 setImage:[UIImage imageNamed:@"vote_smile_grey@3x.png"]];
            [emoji2 setImage:[UIImage imageNamed:@"vote_delicious_grey@3x.png"]];
            [emoji3 setImage:[UIImage imageNamed:@"vote_love_grey@3x.png"]];
        }else{
            [emoji1 setImage:[UIImage imageNamed:@"vote_smile@3x.png"]];
            [emoji2 setImage:[UIImage imageNamed:@"vote_delicious@3x.png"]];
            [emoji3 setImage:[UIImage imageNamed:@"vote_love@3x.png"]];
        }
        NSString* val =[NSString stringWithFormat:@"微笑%d，好味%d，喜歡%d",[[dict objectForKey:@"emoji1"] intValue],[[dict objectForKey:@"emoji2"] intValue],[[dict objectForKey:@"emoji3"] intValue]];
        [emojiBase setAccessibilityLabel:val];
        Reading = [NSString stringWithFormat:@"%@，%@",Reading,val];
        //Internal First
        [emojiBase addSubview:emoji1];
        [emojiBase addSubview:emoji1Label];
        [emojiBase addSubview:emoji2];
        [emojiBase addSubview:emoji2Label];
        [emojiBase addSubview:emoji3];
        [emojiBase addSubview:emoji3Label];
        [view addSubview:emojiBase];
        //Con Internal
        ////edge
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1 attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3Label attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationLessThanOrEqual toItem:emojiBase attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1Label attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1Label attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2Label attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2Label attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3Label attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3Label attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2 attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:emoji2Label attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3 attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:emoji3Label attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1 attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:emoji1Label attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
        ////Pos
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:emoji1Label attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:emoji2Label attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3 attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:emoji3Label attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1Label attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:emoji2 attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];;
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2Label attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:emoji3 attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        ////Size
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeWidth multiplier:0.125 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeWidth multiplier:0.125 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:emojiBase attribute:NSLayoutAttributeWidth multiplier:0.125 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1Label attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:emojiBase attribute:NSLayoutAttributeWidth multiplier:0.125 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2Label attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:emojiBase attribute:NSLayoutAttributeWidth multiplier:0.125 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3Label attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:emojiBase attribute:NSLayoutAttributeWidth multiplier:0.125 constant:0]];
        ////ratio
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji1 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:emoji1 attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji2 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:emoji2 attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
        [emojiBase addConstraint:[NSLayoutConstraint constraintWithItem:emoji3 attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:emoji3 attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
        //Fine
        emoji1.translatesAutoresizingMaskIntoConstraints = NO;
        emoji1Label.translatesAutoresizingMaskIntoConstraints = NO;
        emoji2.translatesAutoresizingMaskIntoConstraints = NO;
        emoji2Label.translatesAutoresizingMaskIntoConstraints = NO;
        emoji3.translatesAutoresizingMaskIntoConstraints = NO;
        emoji3Label.translatesAutoresizingMaskIntoConstraints = NO;
        //External
        [view addConstraint:[NSLayoutConstraint constraintWithItem:emojiBase attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        
        [view addConstraint:[NSLayoutConstraint constraintWithItem:emojiBase attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        if (lastItem==view){
            [view addConstraint:[NSLayoutConstraint constraintWithItem:emojiBase attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        }else{
            [view addConstraint:[NSLayoutConstraint constraintWithItem:emojiBase attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
        }
        emojiBase.translatesAutoresizingMaskIntoConstraints=NO;
        lastItem = emojiBase;
    }
    //seal
    if (lastItem!=view){
        [view addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:lastItem attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    }
    [view setTranslatesAutoresizingMaskIntoConstraints:NO];
    [view setNeedsLayout];
    [view layoutIfNeeded];
    if ([Reading hasPrefix:@"，"]) Reading = [Reading substringFromIndex:1];
    [view setAccessibilityLabel:[StringUnity ReadWordRefinement:Reading]];
}


-(NSString*)RefineEmojiNum:(int)num{
    if (num>=1000000){
        int n = num/1000000;
        return [NSString stringWithFormat:@"%d m",n];
    }else if (num>=1000){
        int n = num/1000;
        return [NSString stringWithFormat:@"%d k",n];
    }else if (num>=0){
        return [NSString stringWithFormat:@"%d",num];
    }
    return @"0";
}

-(void) advClicked:(id)sender{
    //
    UIButton* btn = (UIButton*)sender;
    NSMutableDictionary* dict = [QueryArray objectAtIndex:btn.tag];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[dict objectForKey:@"link"]]];
}

-(void) detailClicked:(id)sender{
    //
    UIButton* btn = (UIButton*)sender;
    QD = [QueryArray objectAtIndex:btn.tag];
    //ShopID
    ShopIDChosen = [QD objectForKey:@"sid"];
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToRestDetail"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"GoToRestDetail" sender:self];
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}

-(void)delayDel:(NSString*)rId{
    if([PostMethodUse getBeforeVoiceOut]){
        //Kill
        AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
        
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyHistory" inManagedObjectContext: managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"rId=%@", rId];
        [fetchRequest setPredicate:predicate];
        NSError *error = nil;
        NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
        if (fetchedObjects == nil) {
            NSLog(@"Fetch error, something's wrong. %@",error);
        }
        else{
            if([fetchedObjects count]>0){
                [managedObjectContext deleteObject:[fetchedObjects objectAtIndex:0]];
                [appDelegate saveContext];
            }else{
                //NSLog(@"Nothing Left");
            }
        }
        NowPullLength = [QueryArray count];
        if(NowPullLength==0){
            isNullResult = YES;
            isNullMessage =@"沒有記錄.";
            if (isNullResult){
                [OverlayNoSearch setHidden:NO];
                [NoSearchMessage setHidden:NO];
                [NoSearchMessage setText:isNullMessage];
            }else{
                [OverlayNoSearch setHidden:YES];
                [NoSearchMessage setHidden:YES];
            }
        }
        //Refresh Layout
        [tbView reloadData];
        [PostMethodUse AfterLoadingLayoutUse];
    }else{
        [self performSelector:@selector(delayDel:)
                   withObject:rId
                   afterDelay:0.1];
    }
}

#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        [NoSearchMessage setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [tbView reloadData];
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //[myScroll setContentSize:myViewPanel.bounds.size];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
         [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}



-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}






#pragma UITableViewRelated
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return NowPullLength;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    
    UITableViewCell* cell = [tbView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    [cell.contentView setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
    [cell setTranslatesAutoresizingMaskIntoConstraints:NO];
    if ([((NSMutableDictionary*)[QueryArray objectAtIndex:indexPath.row]) objectForKey:@"id"]==nil){
        RestaurantItem *item ;
        if ([[cell.contentView subviews] count]==0){
            item = [[RestaurantItem alloc] init];
            [cell.contentView addSubview:item];
            [item setTranslatesAutoresizingMaskIntoConstraints:NO];
            [cell.contentView addConstraints:item.constraints];
            NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
            [cell.contentView addConstraint:topCon];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
            [item setTranslatesAutoresizingMaskIntoConstraints:NO];
            
            
            [cell.contentView layoutIfNeeded];
            
            item.layer.shadowColor = [UIColor grayColor].CGColor;
            item.layer.shadowOffset = CGSizeMake(1, 2);
            item.layer.shadowOpacity = 0.5;
            item.layer.shadowRadius=1.0;
            
        }else{
            item =[[cell.contentView subviews] objectAtIndex:0];
            if (item == nil || ![item isKindOfClass:[RestaurantItem class]]){
                while([[cell.contentView subviews] count]>0){
                    UIView * v =[[cell.contentView subviews] objectAtIndex:0];
                    [v removeFromSuperview];
                }
                item = [[RestaurantItem alloc] init];
                [cell.contentView addSubview:item];
                [item setTranslatesAutoresizingMaskIntoConstraints:NO];
                [cell.contentView addConstraints:item.constraints];
                NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
                [cell.contentView addConstraint:topCon];
                [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
                [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
                [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
                [item setTranslatesAutoresizingMaskIntoConstraints:NO];
                
                [cell.contentView layoutIfNeeded];
                item.layer.shadowColor = [UIColor grayColor].CGColor;
                item.layer.shadowOffset = CGSizeMake(1, 2);
                item.layer.shadowOpacity = 0.5;
                item.layer.shadowRadius=1.0;
            }
        }
        
        
        
        //
        [item.RestaurantName setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fUse]];
        //[item.RestaurantName setAccessibilityTraits:(UIAccessibilityTraitHeader)];
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if (!isNoColor){
            [item.RestaurantName setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
            [item.DetailBtnPic setImage:[UIImage imageNamed:@"detail@3x.png"]];
        }else {
            [item.RestaurantName setTextColor:[UIColor blackColor]];
            [item.DetailBtnPic setImage:[UIImage imageNamed:@"detail_grey@3x.png"]];
        }
        item.detailBtnHeight.constant = fSUse+16;
        [item.DetailLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
        item.DetailBtn.tag = indexPath.row;
        [item.DetailBtn addTarget:self action:@selector(detailClicked:) forControlEvents:(UIControlEventTouchUpInside)];
        //set The Data
        NSMutableDictionary* dict = [QueryArray objectAtIndex:indexPath.row];
        
        [item.RestaurantOutLook setImage:[ImageDictionary objectForKey:[dict objectForKey:@"shopPic"]]];
        [item.RestaurantName setText:[dict objectForKey:@"shopName"]];
        [item.RestaurantName  setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fUse]];
        item.RestaurantNameHeight.constant = fUse;
        UIView* detailview = item.MyDetailList;
        while ([[detailview subviews] count]>0){
            UIView* v =[[detailview subviews] objectAtIndex:0];
            [v removeFromSuperview];
        }
        //
        //NSLog(@"indexPath.row call set up %ld", indexPath.row);
        [self setUpBulletItemFor:detailview withDict:dict];
    }else{
        //ADV Here
        
        while ([[cell.contentView subviews] count]>0){
            [[[cell.contentView subviews] objectAtIndex:0] removeFromSuperview];
        }
        NSMutableDictionary* dict = [QueryArray objectAtIndex:indexPath.row];
        Adv* adv = [[Adv alloc]initWithFrame:CGRectZero];
        [cell.contentView addSubview:adv];
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:adv attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:adv.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
        
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:adv attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:adv.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10]];
        
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:adv attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:adv.superview attribute:NSLayoutAttributeRight multiplier:1 constant:-10]];
        
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:adv attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:adv.superview attribute:NSLayoutAttributeLeft multiplier:1 constant:10]];
        
        adv.translatesAutoresizingMaskIntoConstraints = NO;
        [adv.TitleLabel setText:[dict objectForKey:@"title"]];
        [adv.DescriptionLabel setText:[dict objectForKey:@"content"]];
        [adv.LinkBtn setAccessibilityLabel:[StringUnity ReadWordRefinement:[NSString stringWithFormat:@"%@ %@",[dict objectForKey:@"title"], [dict objectForKey:@"content"]]]];
        adv.LinkBtn.tag = indexPath.row;
        [adv.LinkBtn addTarget:self action:@selector(advClicked:) forControlEvents:UIControlEventTouchUpInside];
        [adv setFontSize:fUse];
        
        adv.layer.shadowColor = [UIColor grayColor].CGColor;
        adv.layer.shadowOffset = CGSizeMake(1, 2);
        adv.layer.shadowOpacity = 0.5;
        adv.layer.shadowRadius=1.0;
    }
    
    
    //NSLog(@"Hello NowPullLength %d and %ld",NowPullLength,indexPath.row);
    if (indexPath.row == NowPullLength - 1)
    {
        //
        if (NowPullLength<[QueryArray count]){
            //[self increasePull];
        }
    }
    cell.contentView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    [cell.contentView setNeedsLayout];
    [cell.contentView layoutIfNeeded];
    
    return cell;
}

// Override to support conditional editing of the table view.
// This only needs to be implemented if you are going to be returning NO
// for some items. By default, all items are editable.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
    //return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        //Delete The List first
        NSMutableDictionary* ele = [QueryArray objectAtIndex:indexPath.row];
        [QueryArray removeObject:ele];
        //Delete The Corresponding element from Database Records
        NSString* rId = [ele objectForKey:@"sid"];
        [self performSelector:@selector(delayDel:)
                   withObject:rId
                   afterDelay:0.01];
    }
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([[segue identifier] isEqualToString:@"GoToRestDetail"]){
        RestaurantDetailsController* dist = segue.destinationViewController;
        [dist LoadDataWithShopID:ShopIDChosen andQueryDict:QD];
    }
}

-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
        return;
    }
    
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}

@end
