//
//  UpdateCallBackObject.h
//  TapMyDish
//
//  Created by BDMacMini1 on 18/1/2017.
//  Copyright © 2017年 BigDipperStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UpdateCallBackObject : NSObject<UIAlertViewDelegate>

@end
