
//
//  PhotoView.m
//  TapMyDish
//
//  Created by BDMacMini1 on 1/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "PhotoView.h"

@implementation PhotoView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.view.accessibilityElements = [NSArray arrayWithObjects:_CloseBtn,_WhiteFrame, nil];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.view.accessibilityElements = [NSArray arrayWithObjects:_CloseBtn,_WhiteFrame, nil];
    }
    return self;
}

-(Boolean) SetPhoto:(UIImage*) photo withDishName:(NSString*) DishName{
    //[_ImageRatio setConstant:photo.size.width/photo.size.height];
    if(photo!=nil){
    [_myphotoview setImage:photo];
        _WhiteFrame.accessibilityLabel = [@"相片：" stringByAppendingString:DishName];
    //Set frames
    CGFloat photoWidthUse;
    CGFloat photoHeightUse;
    CGFloat dx;
    CGFloat dy;
    CGFloat viewUseWidth = self.frame.size.width -40;//- 32;
    CGFloat viewUseHeight = self.frame.size.height-60;// - 52;
    if (photo.size.width/viewUseWidth > photo.size.height/viewUseHeight){
        //shrink for width
        photoWidthUse = viewUseWidth;
        photoHeightUse = photo.size.height/ photo.size.width * photoWidthUse;
        dx =20;
        dy =(viewUseHeight -photoHeightUse)/2 +20+20;
    }else{
        photoHeightUse = viewUseHeight;
        photoWidthUse = photo.size.width/ photo.size.height * photoHeightUse;
        dy = 40;
        dx = (viewUseWidth-photoWidthUse)/2+20;
    }
    [_WhiteFrame setFrame:CGRectMake(dx-8, dy-8, photoWidthUse+16, photoHeightUse+16)];
    [_myphotoview setFrame:CGRectMake(8, 8, photoWidthUse, photoHeightUse)];
    [self.view bringSubviewToFront:_CloseBtn];
        //[_CloseBtn.layer setFrame:CGRectMake(dx+photoWidthUse+8-24, dy-8-24, 48, 48)];
        [_CloseBtn.layer setFrame:CGRectMake(0, 20, 48, 48)];
    [_CloseBtn setTranslatesAutoresizingMaskIntoConstraints:YES];
        [_CloseBtn setImage:[UIImage imageNamed:@"btn_close_2@3x.png"] forState:(UIControlStateNormal)];
        [_BlackBase setFrame:CGRectMake(0,0, self.frame.size.width, self.frame.size.height)];        return YES;
    }
    else{
        return NO;
    }
}



-(IBAction)ClickedClose:(id)sender{
    [self removeFromSuperview];
}


- (BOOL)accessibilityViewIsModal {
    return YES;
}
@end
