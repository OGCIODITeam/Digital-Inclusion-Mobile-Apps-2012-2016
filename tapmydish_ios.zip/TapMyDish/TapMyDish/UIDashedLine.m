//
//  UIDashedLine.m
//  TapMyDish
//
//  Created by BDMacMini1 on 20/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "UIDashedLine.h"

@implementation UIDashedLine


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    {
        CGFloat thickness = 4.0;
        
        CGContextRef cx = UIGraphicsGetCurrentContext();
        CGContextSetLineWidth(cx, thickness);
        CGContextSetStrokeColorWithColor(cx, [UIColor grayColor].CGColor);
        
        CGFloat ra[] = {4,2};
        CGContextSetLineDash(cx, 0.0, ra, 2); // nb "2" == ra count
        
        CGContextMoveToPoint(cx, 0,thickness*0.5);
        CGContextAddLineToPoint(cx, self.bounds.size.width, thickness*0.5);
        CGContextStrokePath(cx);
    }
}


@end
