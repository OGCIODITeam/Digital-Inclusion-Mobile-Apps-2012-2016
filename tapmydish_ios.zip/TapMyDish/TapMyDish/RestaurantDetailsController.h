//
//  RestaurantDetailsController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 23/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface RestaurantDetailsController : UIViewController<UITabBarDelegate,CLLocationManagerDelegate>
-(BOOL) LoadDataWithShopID:(NSString*) ShopID;

-(void) LoadDataWithShopID:(NSString*) ShopID andQueryDict:(NSMutableDictionary*) QD;
-(BOOL) LoadDataWithShopCode:(NSString*) ShopCode;

@end
