//
//  CouponTicketTab.h
//  TapMyDish
//
//  Created by BDMacMini1 on 20/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CouponTicketTab : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UIImageView *Deco;
@property (weak, nonatomic) IBOutlet UIImageView *CouponIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *CouponIconHeight;
@property (weak, nonatomic) IBOutlet UILabel *TitleHeight;
@property (weak, nonatomic) IBOutlet UILabel *TitleLabel;
@property (weak, nonatomic) IBOutlet UIView *DashLine;
@property (weak, nonatomic) IBOutlet UIView *DoneCollectBase;
@property (weak, nonatomic) IBOutlet UILabel *AddedToMyFav;
@property (weak, nonatomic) IBOutlet UIImageView *AboutIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *AboutIconHeight;
@property (weak, nonatomic) IBOutlet UILabel *AboutHeight;
@property (weak, nonatomic) IBOutlet UILabel *AboutLabel;

@property (weak, nonatomic) IBOutlet UIButton *ButtonTypeOn;

-(void) setFontSize:(CGFloat)FS;

-(void) setTitle:(NSString*) TitleText AndContant:(NSString*) ContentText AndGetCollected:(BOOL)collected;

@end
