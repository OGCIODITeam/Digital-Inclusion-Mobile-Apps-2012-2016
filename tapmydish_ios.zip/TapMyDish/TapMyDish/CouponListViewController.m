//
//  CouponListViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 9/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "CouponListViewController.h"
#import "CouponDetailsViewController.h"
#import "PostMethodUse.h"
#import "StringUnity.h"
#import "AppDelegate.h"
#import "CouponTicketTab.h"
#import "UIImage_withColor.h"

@interface CouponListViewController (){
    __weak IBOutlet UITabBar* tabBar;
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* MyPanel;
    __weak IBOutlet UINavigationItem* NavItem;
    
    CGFloat fSUse;
    CGFloat fUse;
    
    NSMutableDictionary* QueryData;
    NSString* ResTitle;
    NSString* SelectedId;
}

@end

@implementation CouponListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [tabBar setDelegate:self];
    //Last
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void) LoadWithQuery:(NSMutableDictionary*)Query AndTitle:(NSString*)RestaurantTitle{
    QueryData = Query;
    ResTitle = RestaurantTitle;
}

-(void) ReloadLayout{
    [NavItem setTitle:ResTitle];
    while ([MyPanel.subviews count]>0){
        [[MyPanel.subviews objectAtIndex:0] removeFromSuperview];
    }
    //
    UIView* LastTarget = MyPanel;

    for (NSString* key in QueryData){
        NSMutableDictionary* dict = [QueryData objectForKey:key];
        NSNumber* isOutdateNum =[dict objectForKey:@"isOutdate"];
        BOOL isOutdate = [isOutdateNum boolValue];
        if (!isOutdate){
            NSString* couponName = [StringUnity RefinedString:[dict objectForKey:@"couponName"]];
            NSString* couponContent = [StringUnity RefinedString:[dict objectForKey:@"couponContent"]];
            NSString* couponRule = [StringUnity RefinedString:[dict objectForKey:@"couponRule"]];
            NSString* deadline = [dict objectForKey:@"deadline"];
            NSString* publishDate = [dict objectForKey:@"publishDate"];
            NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            NSDate* StartD = [formatter dateFromString:publishDate];
            NSDate* StopD = [formatter dateFromString:deadline];
            //Create
            CouponTicketTab* arrow = [[CouponTicketTab alloc] initWithFrame:CGRectZero];
            [arrow setFontSize:fUse];
            [arrow setTitle:couponName AndContant:couponContent AndGetCollected:!([self CheckIfSaved:[dict objectForKey:@"id"]] == nil)];
            [arrow.ButtonTypeOn addTarget:self action:@selector(clickedTab:) forControlEvents:UIControlEventTouchUpInside];
            arrow.ButtonTypeOn.tag =[key integerValue];
            //Constraint
            [MyPanel addSubview:arrow];
            //Position
            [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:MyPanel attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:MyPanel attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
            if (LastTarget == MyPanel){
                [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:MyPanel attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
            }else{
                [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:LastTarget attribute:NSLayoutAttributeBottom multiplier:1 constant:8]];
            }
            
            //finally
            arrow.translatesAutoresizingMaskIntoConstraints = NO;
            ////Shadow
            arrow.layer.shadowColor = [UIColor grayColor].CGColor;
            arrow.layer.shadowOffset = CGSizeMake(1, 2);
            arrow.layer.shadowOpacity = 0.5;
            arrow.layer.shadowRadius=1.0;
            LastTarget = arrow;
        }
    }
    if(LastTarget!=MyPanel){
        [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:MyPanel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:LastTarget attribute:NSLayoutAttributeBottom multiplier:1 constant:8]];
    }
}

-(id)CheckIfSaved:(NSString*)idd{
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cId=%@", idd];
    [fetchRequest setPredicate:predicate];
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        //NSLog(@"Fetch error, something's wrong. %@",error);
        return nil;
    }
    else{
        if([fetchedObjects count]>0){
            return [fetchedObjects objectAtIndex:0];
        }else{
            return nil;
        }
    }
}



-(void)clickedTab:(id)sender{
    //GoToCouponDetail
    UIButton* btn = (UIButton*)sender;
    SelectedId = [NSString stringWithFormat:@"%ld",btn.tag];
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToCouponDetail"
               afterDelay:0.1];
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([[segue identifier] isEqualToString:@"GoToCouponDetail"]){
        CouponDetailsViewController* vc = segue.destinationViewController;
        [vc LoadQuery:[QueryData objectForKey:SelectedId] AndTitle:ResTitle];
    }
}


#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        
        [self ReloadLayout];
        
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,MyPanel.bounds.size.height);
    [myScroll setContentSize:CGSizeMake(0,MyPanel.bounds.size.height)];
}


-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    //Location
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self setTabBarOutLook];
    [self setFontSizes];
    
    
    //Load Item Use
    //[self ReloadLayout];   // called in setFont already;
    
    //NSLog(@"");
    
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

@end
