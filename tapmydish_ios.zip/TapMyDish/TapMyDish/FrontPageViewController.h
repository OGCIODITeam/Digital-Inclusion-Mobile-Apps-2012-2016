#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface FrontPageViewController : UIViewController<UITextFieldDelegate,CLLocationManagerDelegate>

-(void)preferredContentSizeChanged:(NSNotification *)noti;
@end

