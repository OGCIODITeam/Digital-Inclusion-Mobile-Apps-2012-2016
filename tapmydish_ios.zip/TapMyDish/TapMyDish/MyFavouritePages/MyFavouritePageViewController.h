//
//  MyFavouritePageViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFavouritePageViewController : UIViewController<UITabBarDelegate>


@end