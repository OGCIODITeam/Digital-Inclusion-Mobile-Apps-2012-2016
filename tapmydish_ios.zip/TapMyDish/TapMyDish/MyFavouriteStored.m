//
//  MyFavouriteStored.m
//  TapMyDish
//
//  Created by BDMacMini1 on 6/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MyFavouriteStored.h"

@implementation MyFavouriteStored

@dynamic rId;
@dynamic date;
@dynamic shopData;

@end

@implementation ShopData

+ (Class)transformedValueClass
{
    return [NSDictionary class];
}

+ (BOOL)allowsReverseTransformation
{
    return YES;
}

- (id)transformedValue:(id)value
{
    return [NSKeyedArchiver archivedDataWithRootObject:value];
}

- (id)reverseTransformedValue:(id)value
{
    return [NSKeyedUnarchiver unarchiveObjectWithData:value];
}
@end
