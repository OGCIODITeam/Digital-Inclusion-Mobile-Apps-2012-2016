//
//  AboutUsViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 30/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <CoreLocation/CoreLocation.h>

@interface AboutUsViewController : UIViewController<UITabBarDelegate, MFMailComposeViewControllerDelegate,
CLLocationManagerDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *myScroll;
@property (weak, nonatomic) IBOutlet UIView *myViewPanel;
@property (weak, nonatomic) IBOutlet UIView *Slot1;
@property (weak, nonatomic) IBOutlet UIView *Slot2;
@property (weak, nonatomic) IBOutlet UIView *Slot2_5;
@property (weak, nonatomic) IBOutlet UIView *Slot3;
@property (weak, nonatomic) IBOutlet UIView *Slot4;
@property (weak, nonatomic) IBOutlet UIView *Slot4_5;
@property (weak, nonatomic) IBOutlet UIView *ContactUsSlot;
@property (weak, nonatomic) IBOutlet UILabel *Heading1;
@property (weak, nonatomic) IBOutlet UILabel *Slot1P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot1P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading2;
@property (weak, nonatomic) IBOutlet UILabel *Slot2P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot2P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading2_5;
@property (weak, nonatomic) IBOutlet UILabel *Slot2_5P1;

@property (weak, nonatomic) IBOutlet UILabel *Heading3;
@property (weak, nonatomic) IBOutlet UILabel *Slot3P1;

@property (weak, nonatomic) IBOutlet UILabel *Slot4P1;
@property (weak, nonatomic) IBOutlet UIButton *WebBtn1;

@property (weak, nonatomic) IBOutlet UILabel *Heading4_5;
@property (weak, nonatomic) IBOutlet UILabel *Slot4_5P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot4_5P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading5;
@property (weak, nonatomic) IBOutlet UILabel *Slot5P1;

@property (weak, nonatomic) IBOutlet UILabel *NewPhoneLabel;
@property (weak, nonatomic) IBOutlet UIButton *NewPhoneBtn;
@property (weak, nonatomic) IBOutlet UILabel *NewEmailLabel;
@property (weak, nonatomic) IBOutlet UIButton *NewEmailBtn;

@property (weak, nonatomic) IBOutlet UILabel *PhoneLabel;
@property (weak, nonatomic) IBOutlet UIButton *PhoneBtn;
@property (weak, nonatomic) IBOutlet UILabel *FaxLabel;
@property (weak, nonatomic) IBOutlet UIButton *FaxBtn;
@property (weak, nonatomic) IBOutlet UILabel *EmailLabel;
@property (weak, nonatomic) IBOutlet UIButton *EmailBtn;
@property (weak, nonatomic) IBOutlet UILabel *WebLabel;
@property (weak, nonatomic) IBOutlet UIButton *WebBtn;
@property (weak, nonatomic) IBOutlet UILabel *FBLabel;
@property (weak, nonatomic) IBOutlet UIButton *FBBtn;
@property (weak, nonatomic) IBOutlet UILabel *AddressLabel;
@property (weak, nonatomic) IBOutlet UIButton *AddressBtn;


@end
