//
//  UsageViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 26/1/2017.
//  Copyright © 2017年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UsageViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *myScroll;
@property (weak, nonatomic) IBOutlet UIView *myViewPanel;
@property (weak, nonatomic) IBOutlet UIView *Slot1;
@property (weak, nonatomic) IBOutlet UIView *Slot2;
@property (weak, nonatomic) IBOutlet UIView *Slot3;
@property (weak, nonatomic) IBOutlet UIView *Slot4;
@property (weak, nonatomic) IBOutlet UIView *Slot5;

@property (weak, nonatomic) IBOutlet UILabel *Heading1;
@property (weak, nonatomic) IBOutlet UILabel *Slot1P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot1P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading2;
@property (weak, nonatomic) IBOutlet UILabel *Slot2P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot2P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading3;
@property (weak, nonatomic) IBOutlet UILabel *Slot3P1;

@property (weak, nonatomic) IBOutlet UILabel *Heading4;
@property (weak, nonatomic) IBOutlet UILabel *Slot4P1;

@property (weak, nonatomic) IBOutlet UILabel *Heading5;
@property (weak, nonatomic) IBOutlet UILabel *Slot5P1;

@end
