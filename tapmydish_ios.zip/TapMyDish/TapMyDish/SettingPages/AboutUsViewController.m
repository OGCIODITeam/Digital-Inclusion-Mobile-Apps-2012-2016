//
//  AboutUsViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 30/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "AboutUsViewController.h"
#import "PostMethodUse.h"
#import "UIImage_withColor.h"


@interface AboutUsViewController (){
    __weak IBOutlet UITabBar* tabBar;
    
    NSString* POS_LAT;
    NSString* POS_LONG;
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    CGFloat fUse;
    
    int tryoutcount;
}

@end

@implementation AboutUsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setTabBarOutLook];
    // Do any additional setup after loading the view, typically from a nib.
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
    
    [_Heading1 setAccessibilityTraits:UIAccessibilityTraitHeader];
    [_Heading4_5 setAccessibilityTraits:UIAccessibilityTraitHeader];
    [_Heading5 setAccessibilityTraits:UIAccessibilityTraitHeader];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    //Hard Code
    POS_LAT = @"22.312786";
    POS_LONG = @"114.230008";
    [self setFontSizes];
}

#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fT = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeT = [fT pointSize];
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeT = fontSizeT*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeT = fontSizeT*1.2;
        }
        
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        //CGFloat fontSizeS = [fs pointSize];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeT= fontSizeT*2;
        }
        
        //[BWBGT setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        
        [_Heading1 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fontSize]];
        [_Heading2 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fontSize]];
        [_Heading2_5 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fontSize]];
        [_Heading3 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fontSize]];
        [_Heading4_5 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fontSize]];
        [_Heading5 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fontSize]];
        [_Slot1P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot1P2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot2P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot2P2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot2_5P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot3P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot4P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot4_5P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot4_5P2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_Slot5P1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_PhoneLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_FaxLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_EmailLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_WebLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_FBLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_AddressLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_NewPhoneLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [_NewEmailLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        fUse = fontSize;
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",_myScroll.bounds.size.height,_myViewPanel.bounds.size.height);
    [_myScroll setContentSize:_myViewPanel.bounds.size];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}
-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    //[tabBar setSelectedItem:tabBar.items[5]];
    UINavigationController* theController = self.navigationController;
    [self setTabBarOutLook];
    //Fonts
    //[self setTapMyDishColor];
    [self setFontSizes];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [_myScroll setContentSize:_myViewPanel.bounds.size];
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}


-(IBAction)SendEmail:(id)sender{
    [self showEmail:sender];
}


-(IBAction)gotomap:(id)sender{
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    tryoutcount = 0;
    [locationManager startUpdatingLocation];
    if (!([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%@,%@", POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }else{
        [PostMethodUse BeforeLoadingLayoutUse:YES];
    }
}
-(IBAction)gotoweb:(id)sender{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.hkbu.org.hk"]];
}

-(IBAction)gotophone:(id)sender{
    if (sender == _PhoneBtn){
        NSString *phoneNumber = [@"telprompt://" stringByAppendingString:@"27095559"];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
    }else{
        NSString *phoneNumber = [@"telprompt://" stringByAppendingString:@"39960760"];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
    }
}


-(IBAction)PostFacebook:(id)sender{
    NSURL* fbURLWeb = [NSURL URLWithString:@"https://www.facebook.com/HKBlindUnion"];
    NSURL* fbURLID = [NSURL URLWithString:@"fb://profile/126533087401768"];
    
    if([[UIApplication sharedApplication] canOpenURL:(fbURLID)]){
        // FB installed
        [[UIApplication sharedApplication] openURL:(fbURLID)];
    } else {
        // FB is not installed, open in safari
        [[UIApplication sharedApplication] openURL:(fbURLWeb)];
    }
}


-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    
    [super viewWillDisappear:animated];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

#pragma mark - email use
- (IBAction)showEmail:(id)sender {
    // Email Subject
    if ([MFMailComposeViewController canSendMail]) {
        NSString *emailTitle = @"點菜易";
        // Email Content
        NSString *messageBody = @"";
        // To address
        
        NSArray *toRecipents;
        if (_EmailBtn==sender){
            toRecipents = [NSArray arrayWithObject:@"adtc@hkbu.org.hk"];
        }else{
            toRecipents = [NSArray arrayWithObject:@"tapmydish@hkbu.org.hk"];
        }
        MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
        mc.mailComposeDelegate = self;
        [mc setSubject:emailTitle];
        [mc setMessageBody:messageBody isHTML:NO];
        [mc setToRecipients:toRecipents];
        
        // Present mail view controller on screen
        [self presentViewController:mc animated:YES completion:NULL];
    }else{
        [PostMethodUse PopUpNoEmail];
    }
    
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}


#pragma mark - CLLocationManagerDelegate


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //    NSLog(@"didFailWithError: %@", error);
    //    UIAlertView *errorAlert = [[UIAlertView alloc]
    //                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //    [errorAlert show];
    //Location
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount = -100;
        [locationManager stopUpdatingLocation];
        [PostMethodUse AfterLoadingLayoutUse];
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%@,%@", POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if(tryoutcount>=0){
        tryoutcount = -100;
        //NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        //Location
        [locationManager stopUpdatingLocation];
        [PostMethodUse AfterLoadingLayoutUse];
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?saddr=%1.6f,%1.6f&daddr=%@,%@", currentLocation.coordinate.latitude, currentLocation.coordinate.longitude, POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }
}

@end
