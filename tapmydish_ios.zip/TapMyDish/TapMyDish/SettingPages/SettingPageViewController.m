//
//  SettingPageViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "SettingPageViewController.h"
#import "PostMethodUse.h"
#import "AboutUsPanel.h"
#import "UIImage_withColor.h"


@interface SettingPageViewController (){
    __weak IBOutlet UITabBar* tabBar;
    
    __weak IBOutlet UIView* Tag1;
    __weak IBOutlet UIView* Tag2;
    __weak IBOutlet UIView* Tag2_5;
    __weak IBOutlet UIView* Tag3;
    __weak IBOutlet UIView* Tag4;
    
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* myViewPanel;
    
    __weak IBOutlet UILabel* TextSizeLabel;
    __weak IBOutlet UIImageView* ImageAA;
    __weak IBOutlet UILabel* PageColorLabel;
    __weak IBOutlet UIImageView* ImageColor;
    __weak IBOutlet UILabel* EnvolopeLabel;
    __weak IBOutlet UIImageView* ImageEnvolope;
    __weak IBOutlet UILabel* AboutLabel;
    __weak IBOutlet UIImageView* ImageAbout;
    
    __weak IBOutlet UILabel* GrayTextSizeShow;
    __weak IBOutlet UILabel* ColorTextShow;
    __weak IBOutlet UILabel* SmallT;
    __weak IBOutlet UILabel* NormalT;
    __weak IBOutlet UILabel* BigT;
    
    __weak IBOutlet UILabel* ColorBGT;
    __weak IBOutlet UILabel* BWBGT;

    __weak IBOutlet NSLayoutConstraint* ImageAAHeight;
    __weak IBOutlet NSLayoutConstraint* ImageGridHeight;
    __weak IBOutlet NSLayoutConstraint* ImageEnvolopeHeight;
    __weak IBOutlet NSLayoutConstraint* ImageAboutHeight;
    
    __weak IBOutlet UIButton* AboutUsBtn;
    __weak IBOutlet UILabel* VersionLabel;
    
    CGFloat fUse;
    
    UIView* AboutUsContainer;
    AboutUsPanel* aup ;
    
    
    NSString* POS_LAT;
    NSString* POS_LONG;
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    int tryoutcount;
}

@end

@implementation SettingPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    NSString *version = [info objectForKey:@"CFBundleShortVersionString"];
    NSString *build = [info objectForKey:kCFBundleVersionKey];
    
    NSURL *receiptURL = [[NSBundle mainBundle] appStoreReceiptURL];
    NSString *receiptURLString = [receiptURL path];
    BOOL isRunningTestFlightBeta =  ([receiptURLString rangeOfString:@"sandboxReceipt"].location != NSNotFound);
    if (isRunningTestFlightBeta){
        [VersionLabel setText:[NSString stringWithFormat:@"此程式版本為%@(%@)", version, build]];
    }else{
        [VersionLabel setText:[NSString stringWithFormat:@"此程式版本為%@", version]];
    }
    // Add shadow
    Tag1.layer.shadowColor = [UIColor grayColor].CGColor;
    Tag1.layer.shadowOffset = CGSizeMake(1, 2);
    Tag1.layer.shadowOpacity = 0.5;
    Tag1.layer.shadowRadius=1.0;
    Tag2.layer.shadowColor = [UIColor grayColor].CGColor;
    Tag2.layer.shadowOffset = CGSizeMake(1, 2);
    Tag2.layer.shadowOpacity = 0.5;
    Tag2.layer.shadowRadius=1.0;
//    Tag2_5.layer.shadowColor = [UIColor grayColor].CGColor;
//    Tag2_5.layer.shadowOffset = CGSizeMake(1, 2);
//    Tag2_5.layer.shadowOpacity = 0.5;
//    Tag2_5.layer.shadowRadius=1.0;
    Tag3.layer.shadowColor = [UIColor grayColor].CGColor;
    Tag3.layer.shadowOffset = CGSizeMake(1, 2);
    Tag3.layer.shadowOpacity = 0.5;
    Tag3.layer.shadowRadius=1.0;
    Tag4.layer.shadowColor = [UIColor grayColor].CGColor;
    Tag4.layer.shadowOffset = CGSizeMake(1, 2);
    Tag4.layer.shadowOpacity = 0.5;
    Tag4.layer.shadowRadius=1.0;
    //end shadow
    [self setTabBarOutLook];
    // Do any additional setup after loading the view, typically from a nib.
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    //Hard Code
    POS_LAT = @"22.312786";
    POS_LONG = @"114.230008";
    [self setFontSizes];

}


#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fT = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeT = [fT pointSize];
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeT = fontSizeT*0.8;
            [GrayTextSizeShow setText:@"已選擇細字體大小"];
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeT = fontSizeT*1.2;
            [GrayTextSizeShow setText:@"已選擇大字體大小"];
        }else{
            [GrayTextSizeShow setText:@"已選擇一般字體大小"];
        }
        
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if (isNoColor){
            [ColorTextShow setText:@"已選擇單色背景"];
        }else{
            [ColorTextShow setText:@"已選擇彩色背景"];
        }
        //CGFloat fontSizeS = [fs pointSize];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeT= fontSizeT*2;
        }
        [SmallT setFont:[UIFont fontWithName:@"Heiti TC" size:(fontSizeT*0.8)]];
        [NormalT setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        [BigT setFont:[UIFont fontWithName:@"Heiti TC" size:(fontSizeT*1.2)]];
        [TextSizeLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        [PageColorLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        [GrayTextSizeShow setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [ColorTextShow setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [EnvolopeLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        [AboutLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        [ColorBGT setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        [BWBGT setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeT]];
        
        [ImageAAHeight setConstant:fontSizeT];
        [ImageGridHeight setConstant:fontSizeT];
        [ImageEnvolopeHeight setConstant:fontSizeT+8];
        [ImageAboutHeight setConstant:fontSizeT+8];
        [VersionLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        fUse = fontSize;
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    [myScroll setContentSize:myViewPanel.bounds.size];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}
-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    [tabBar setSelectedItem:tabBar.items[5]];
    UINavigationController* theController = self.navigationController;
    [self setTabBarOutLook];
    //Fonts
    //[self setTapMyDishColor];
    [self setFontSizes];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [myScroll setContentSize:myViewPanel.bounds.size];
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(IBAction)SmallClick:(id)sender{
    [[NSUserDefaults standardUserDefaults] setInteger:-1 forKey:@"TapMyDishThreeSizes"];
    [self setFontSizes];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, GrayTextSizeShow);
}

-(IBAction)NormalClick:(id)sender{
    [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"TapMyDishThreeSizes"];
    [self setFontSizes];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, GrayTextSizeShow);
}

-(IBAction)BigClick:(id)sender{
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"TapMyDishThreeSizes"];
    [self setFontSizes];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, GrayTextSizeShow);
}

-(IBAction)ColorClick:(id)sender{
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"TapMyDishColorStyleIsGrey"];
    [self setTabBarOutLook];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, ColorTextShow);
}

-(IBAction)BWClick:(id)sender{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"TapMyDishColorStyleIsGrey"];
    [self setTabBarOutLook];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, ColorTextShow);
}






-(IBAction)SendComment:(id)sender{
    if (AboutUsContainer!=nil){
        [AboutUsContainer removeFromSuperview];
    }
    [self showEmail:sender];
}

-(IBAction)AboutUs:(id)sender{
    //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://bds.hk"]];
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    //[self performSelector:@selector(makePopUp) withObject:nil afterDelay:0.1];
    [self performSelector:@selector(gotoAboutUs) withObject:nil afterDelay:0.1];
}

-(void)gotoAboutUs{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:@"gotoAboutUs" sender:self];
    }else{
        [self performSelector:@selector(gotoAboutUs) withObject:nil afterDelay:0.1];
    }
}

-(void)makePopUp{
    if([PostMethodUse getBeforeVoiceOut]){
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        if (AboutUsContainer==nil){
            AboutUsContainer = [[UIView alloc] initWithFrame:currentWindow.frame];
            AboutUsContainer.isAccessibilityElement=NO;
            aup = [[AboutUsPanel alloc] initWithFrame:CGRectZero];
            [aup setFontSize:fUse];
            [AboutUsContainer addSubview:aup];
            //
            [AboutUsContainer addConstraint:[NSLayoutConstraint constraintWithItem:aup attribute:(NSLayoutAttributeLeading) relatedBy:(NSLayoutRelationEqual) toItem:AboutUsContainer attribute:(NSLayoutAttributeLeading) multiplier:1 constant:0]];
            [AboutUsContainer addConstraint:[NSLayoutConstraint constraintWithItem:aup attribute:(NSLayoutAttributeTrailing) relatedBy:(NSLayoutRelationEqual) toItem:AboutUsContainer attribute:(NSLayoutAttributeTrailing) multiplier:1 constant:0]];
            [AboutUsContainer addConstraint:[NSLayoutConstraint constraintWithItem:aup attribute:(NSLayoutAttributeTop) relatedBy:(NSLayoutRelationEqual) toItem:AboutUsContainer attribute:(NSLayoutAttributeTop) multiplier:1 constant:0]];
            [AboutUsContainer addConstraint:[NSLayoutConstraint constraintWithItem:aup attribute:(NSLayoutAttributeBottom) relatedBy:(NSLayoutRelationEqual) toItem:AboutUsContainer attribute:(NSLayoutAttributeBottom) multiplier:1 constant:0]];
            aup.translatesAutoresizingMaskIntoConstraints = NO;
            [aup.CloseBtn addTarget:self action:@selector(tapClose) forControlEvents:(UIControlEventTouchUpInside)];
            [aup.AddressBtn addTarget:self action:@selector(gotomap:) forControlEvents:(UIControlEventTouchUpInside)];
            [aup.EmailBtn addTarget:self action:@selector(SendComment:) forControlEvents:(UIControlEventTouchUpInside)];
            [AboutUsContainer setNeedsLayout];
            [AboutUsContainer layoutIfNeeded];
        }
        [currentWindow addSubview:AboutUsContainer];
        [PostMethodUse AfterLoadingLayoutUse];
        UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, aup.Slot1);
    }else{
        [self performSelector:@selector(makePopUp) withObject:nil afterDelay:0.1];
    }
}

-(void)tapClose{
    [AboutUsContainer removeFromSuperview];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, AboutUsBtn);
}

-(IBAction)gotomap:(id)sender{
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    tryoutcount = 0;
    [locationManager startUpdatingLocation];
    if (!([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%@,%@", POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }else{
        [PostMethodUse BeforeLoadingLayoutUse:YES];
    }
}
-(IBAction)gotoweb:(id)sender{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.hkbu.org.hk"]];
}

-(IBAction)gotophone:(id)sender{
    NSString *phoneNumber = [@"telprompt://" stringByAppendingString:@"2709 5559"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
}


-(IBAction)PostFacebook:(id)sender{
    NSURL* fbURLWeb = [NSURL URLWithString:@"https://www.facebook.com/HKBlindUnion"];
    NSURL* fbURLID = [NSURL URLWithString:@"fb://profile/126533087401768"];
    
    if([[UIApplication sharedApplication] canOpenURL:(fbURLID)]){
        // FB installed
        [[UIApplication sharedApplication] openURL:(fbURLID)];
    } else {
        // FB is not installed, open in safari
        [[UIApplication sharedApplication] openURL:(fbURLWeb)];
    }
}


-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    
    [super viewWillDisappear:animated];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [TextSizeLabel setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
        [PageColorLabel setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
        [ImageAA setImage:[UIImage imageNamed:@"labelA_grey@3x.png"]];
        [ImageColor setImage:[UIImage imageNamed:@"labelGrid_grey@3x.png"]];
        [ImageEnvolope setImage:[UIImage imageNamed:@"labelEnvolope_grey@3x.png"]];
        [ImageAbout setImage:[UIImage imageNamed:@"labelabout_grey@3x.png"]];
        [ColorTextShow setText:@"已選擇單色背景"];
        [[UITabBarItem appearance] setTitleTextAttributes:@{/*NSFontAttributeName:[UIFont systemFontOfSize:14], */NSForegroundColorAttributeName:[UIColor blackColor]} forState:UIControlStateSelected];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [TextSizeLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [PageColorLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [ImageAA setImage:[UIImage imageNamed:@"labelA@3x.png"]];
        [ImageColor setImage:[UIImage imageNamed:@"labelGrid@3x.png"]];
        [ImageEnvolope setImage:[UIImage imageNamed:@"labelEnvolope@3x.png"]];
        [ImageAbout setImage:[UIImage imageNamed:@"labelabout@3x.png"]];
        [ColorTextShow setText:@"已選擇彩色背景"];
        [[UITabBarItem appearance] setTitleTextAttributes:@{/*NSFontAttributeName:[UIFont systemFontOfSize:14], */NSForegroundColorAttributeName:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]} forState:UIControlStateSelected];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}

-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

#pragma mark - email use
- (IBAction)showEmail:(id)sender {
    // Email Subject
    if ([MFMailComposeViewController canSendMail]) {
        NSString *emailTitle = @"點菜易-意見回饋";
        // Email Content
        NSString *messageBody = @"";
        // To address
        NSArray *toRecipents = [NSArray arrayWithObject:@"adtc@hkbu.org.hk"];
        
        MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
        mc.mailComposeDelegate = self;
        [mc setSubject:emailTitle];
        [mc setMessageBody:messageBody isHTML:NO];
        [mc setToRecipients:toRecipents];
        
        // Present mail view controller on screen
        [self presentViewController:mc animated:YES completion:NULL];
    }else{
        [PostMethodUse PopUpNoEmail];
    }
    
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}


#pragma mark - CLLocationManagerDelegate


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //    NSLog(@"didFailWithError: %@", error);
    //    UIAlertView *errorAlert = [[UIAlertView alloc]
    //                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //    [errorAlert show];
    //Location
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount = -100;
        [locationManager stopUpdatingLocation];
        [PostMethodUse AfterLoadingLayoutUse];
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?daddr=%@,%@", POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if(tryoutcount>=0){
        tryoutcount = -100;
        //NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        //Location
        [locationManager stopUpdatingLocation];
        [PostMethodUse AfterLoadingLayoutUse];
        NSString *googleMapsURLString = [NSString stringWithFormat:@"http://maps.apple.com/?saddr=%1.6f,%1.6f&daddr=%@,%@", currentLocation.coordinate.latitude, currentLocation.coordinate.longitude, POS_LAT, POS_LONG];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:googleMapsURLString]];
    }
}

@end
