//
//  SettingPageViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <CoreLocation/CoreLocation.h>

@interface SettingPageViewController : UIViewController<UITabBarDelegate, MFMailComposeViewControllerDelegate,
    CLLocationManagerDelegate>


@end
