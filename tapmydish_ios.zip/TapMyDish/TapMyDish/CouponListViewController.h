//
//  CouponListViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 9/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CouponListViewController : UIViewController<UITabBarDelegate>


-(void) LoadWithQuery:(NSMutableDictionary*)Query AndTitle:(NSString*)RestaurantTitle;
@end
