//
//  AccessGroupView.m
//  TapMyDish
//
//  Created by BDMacMini1 on 22/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "AccessGroupView.h"

@interface AccessGroupView  ()

@end

@implementation AccessGroupView

-(BOOL)shouldGroupAccessibilityChildren{
    return YES;
}

@end