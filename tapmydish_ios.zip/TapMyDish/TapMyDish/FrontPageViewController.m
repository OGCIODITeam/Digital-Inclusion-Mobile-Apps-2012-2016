//
//  FrontPageViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 13/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "FrontPageViewController.h"
#import "SpeechToTextModule.h"
#import "SearchResultViewController.h"
#import "PostMethodUse.h"
#import "AppDelegate.h"
#import "AdvanceSearchViewController.h"
#import "TMDInputField.h"
#import "RecordingPlane.h"
#import "UIImage_withColor.h"
#import "StringUnity.h"

@interface FrontPageViewController ()<SpeechToTextModuleDelegate>  {
    SpeechToTextModule *speechToTextModule;
    BOOL isRecording;
    int fieldNowIn;
    
    int sixPageIn;
    
    __weak IBOutlet UITextField *TextField;
    __weak IBOutlet UITextField *TextField2;
    __weak IBOutlet UIButton *btn;
    __weak IBOutlet UIButton *btn2;
    __weak IBOutlet UIButton *btn3;
    
    
    __weak IBOutlet UIButton *btnGPS;
    __weak IBOutlet UIButton *btnCode;
    __weak IBOutlet UIButton *btnAdvance;
    
    __weak IBOutlet UIScrollView *myScroll;
    __weak IBOutlet UIView *myViewPanel;
    
    __weak IBOutlet UIView * UpperBasement;
    __weak IBOutlet UIView * MiddleBasement;
    
    __weak IBOutlet UILabel* MidLabel1;
    __weak IBOutlet UILabel* MidLabel2;
    __weak IBOutlet UILabel* MidLabel3;
    
    __weak IBOutlet UITextField* Field1;
    __weak IBOutlet UITextField* Field2;

    
    //Low Btn colors
    __weak IBOutlet UIView * LowBtn1Edge;
    __weak IBOutlet UIView * LowBtn1Inner;
    __weak IBOutlet UIView * LowBtn2Edge;
    __weak IBOutlet UIView * LowBtn2Inner;
    __weak IBOutlet UIView * LowBtn3Edge;
    __weak IBOutlet UIView * LowBtn3Inner;
    __weak IBOutlet UIView * LowBtn4Edge;
    __weak IBOutlet UIView * LowBtn4Inner;
    __weak IBOutlet UIView * LowBtn5Edge;
    __weak IBOutlet UIView * LowBtn5Inner;
    __weak IBOutlet UIView * LowBtn6Edge;
    __weak IBOutlet UIView * LowBtn6Inner;
    
    //Contents
    __weak IBOutlet UIImageView* LowBaseBtn1Image;
    __weak IBOutlet UIImageView* LowBaseBtn2Image;
    __weak IBOutlet UIImageView* LowBaseBtn3Image;
    __weak IBOutlet UIImageView* LowBaseBtn4Image;
    __weak IBOutlet UIImageView* LowBaseBtn5Image;
    __weak IBOutlet UIImageView* LowBaseBtn6Image;
    
    __weak IBOutlet UILabel* LowBaseBtn1Label;
    __weak IBOutlet UILabel* LowBaseBtn2Label;
    __weak IBOutlet UILabel* LowBaseBtn3Label;
    __weak IBOutlet UILabel* LowBaseBtn4Label;
    __weak IBOutlet UILabel* LowBaseBtn5Label;
    __weak IBOutlet UILabel* LowBaseBtn6Label;
    
    __weak IBOutlet UIButton *btnL1;
    __weak IBOutlet UIButton *btnL2;
    __weak IBOutlet UIButton *btnL3;
    __weak IBOutlet UIButton *btnL4;
    __weak IBOutlet UIButton *btnL5;
    __weak IBOutlet UIButton *btnL6;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    int tryoutcount;
    NSString* SegueToGoNext;
    
    RecordingPlane* rp;
    UIView* rl;
    UIActivityIndicatorView* indicator;
}

@end

@implementation FrontPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //testing
    NSLog(@"%@",[StringUnity ReadWordRefinement:@"-$ 1,350."]);
    [btn setHidden:YES];
    [btn2 setHidden:YES];
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [[UITabBarItem appearance] setTitleTextAttributes:@{/*NSFontAttributeName:[UIFont systemFontOfSize:14], */NSForegroundColorAttributeName:[UIColor blackColor]} forState:UIControlStateSelected];
    }else{
        [[UITabBarItem appearance] setTitleTextAttributes:@{/*NSFontAttributeName:[UIFont systemFontOfSize:14], */NSForegroundColorAttributeName:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]} forState:UIControlStateSelected];
    }
    [[UITabBarItem appearance] setTitleTextAttributes:@{/*NSFontAttributeName:[UIFont systemFontOfSize:14], */ NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateNormal];
    
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyHistory" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        if([fetchedObjects count]>0){
            //NSLog(@"%@",[[[fetchedObjects objectAtIndex:0] valueForKey:@"shopData"] objectForKey:@"menu"]);
        }else{
            //NSLog(@"Nothing Left");
        }
    }
    
    for (NSManagedObject *product in fetchedObjects) {
        //[managedObjectContext deleteObject:product];
    }
    [appDelegate saveContext];
    
    
    
    UINavigationController* theController = self.navigationController;
    [theController setNavigationBarHidden:YES];
    
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
    
    //[self.view setNeedsLayout];
    //[self.view layoutIfNeeded];
    //NSLog(@"%g + %g",myViewPanel.bounds.size.width,myViewPanel.bounds.size.height);
    //[myScroll setContentSize:myViewPanel.bounds.size];
    // Do any additional setup after loading the view, typically from a nib.
    speechToTextModule = [[SpeechToTextModule alloc] initWithCustomDisplay:nil];
    speechToTextModule.delegate = self;
    [speechToTextModule duckOff];
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    
    //self.view.accessibilityElements = @[TextField, btn, TextField2, btn2, btn3];
    btn.accessibilityLabel = @"語音輸入餐廳或菜式";
    btn2.accessibilityLabel = @"語音輸入地區或地址";
    btn3.accessibilityLabel = @"搜尋";
    
    btnCode.accessibilityLabel = @"編號搜尋";
    btnGPS.accessibilityLabel = @"定位搜尋";
    btnAdvance.accessibilityLabel = @"進階搜尋";
    
    btnL1.accessibilityLabel = @"QR掃描";
    btnL2.accessibilityLabel = @"美食餐牌";
    btnL3.accessibilityLabel = @"我的最愛";
    btnL4.accessibilityLabel = @"我的優惠";
    btnL5.accessibilityLabel = @"我的歷史";
    btnL6.accessibilityLabel = @"設定";
    
    [TextField setDelegate:self];
    [TextField2 setDelegate:self];
    [self setTapMyDishColor];
    

}

-(void)viewDidAppear:(BOOL)animated{
    UINavigationController* theController = self.navigationController;
    [theController setNavigationBarHidden:YES];
    [self setFontSizes];
    [locationManager requestWhenInUseAuthorization];
    [PostMethodUse AfterLoadingLayoutUse];
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    Field1.text = @"";
    Field2.text = @"";
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //[self.view setNeedsLayout];
    //[self.view layoutIfNeeded];
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //[myScroll setContentSize:myViewPanel.bounds.size];
    //UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:YES];
    
    [self setTapMyDishColor];
    [self setFontSizes];
    
    if ([PostMethodUse newVersionPresent]) [PostMethodUse PopUpNeedUpdate];
}

-(void)setTapMyDishColor{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [UpperBasement setBackgroundColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [MiddleBasement setBackgroundColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.view setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [LowBaseBtn1Label setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [LowBaseBtn2Label setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [LowBaseBtn3Label setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [LowBaseBtn4Label setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [LowBaseBtn5Label setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [LowBaseBtn6Label setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [LowBtn1Edge setBackgroundColor:[UIColor colorWithRed:0.70196 green:0.70196 blue:0.70196 alpha:1]];
        [LowBtn2Edge setBackgroundColor:[UIColor colorWithRed:0.70196 green:0.70196 blue:0.70196 alpha:1]];
        [LowBtn3Edge setBackgroundColor:[UIColor colorWithRed:0.70196 green:0.70196 blue:0.70196 alpha:1]];
        [LowBtn4Edge setBackgroundColor:[UIColor colorWithRed:0.70196 green:0.70196 blue:0.70196 alpha:1]];
        [LowBtn5Edge setBackgroundColor:[UIColor colorWithRed:0.70196 green:0.70196 blue:0.70196 alpha:1]];
        [LowBtn6Edge setBackgroundColor:[UIColor colorWithRed:0.70196 green:0.70196 blue:0.70196 alpha:1]];
        [LowBtn1Inner setBackgroundColor:[UIColor colorWithRed:0.972549 green:0.972549 blue:0.972549 alpha:1]];
        [LowBtn2Inner setBackgroundColor:[UIColor colorWithRed:0.972549 green:0.972549 blue:0.972549 alpha:1]];
        [LowBtn3Inner setBackgroundColor:[UIColor colorWithRed:0.972549 green:0.972549 blue:0.972549 alpha:1]];
        [LowBtn4Inner setBackgroundColor:[UIColor colorWithRed:0.972549 green:0.972549 blue:0.972549 alpha:1]];
        [LowBtn5Inner setBackgroundColor:[UIColor colorWithRed:0.972549 green:0.972549 blue:0.972549 alpha:1]];
        [LowBtn6Inner setBackgroundColor:[UIColor colorWithRed:0.972549 green:0.972549 blue:0.972549 alpha:1]];
        //Image
        [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        [btn3 setImage:[UIImage imageNamed:@"btn_search_grey.png"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateHighlighted];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateHighlighted];
        [btn3 setImage:[UIImage imageNamed:@"btn_search_grey.png"] forState:UIControlStateHighlighted];
        [LowBaseBtn1Image setImage:[UIImage imageNamed:@"btn_qrcode_grey.png"]];
        [LowBaseBtn2Image setImage:[UIImage imageNamed:@"btn_menu_grey.png"]];
        [LowBaseBtn3Image setImage:[UIImage imageNamed:@"btn_favour_grey.png"]];
        [LowBaseBtn4Image setImage:[UIImage imageNamed:@"btn_coupon_grey.png"]];
        [LowBaseBtn5Image setImage:[UIImage imageNamed:@"btn_history_grey.png"]];
        [LowBaseBtn6Image setImage:[UIImage imageNamed:@"btn_setting_grey.png"]];
    }else{
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [UpperBasement setBackgroundColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [MiddleBasement setBackgroundColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.view setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [LowBaseBtn1Label setTextColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [LowBaseBtn2Label setTextColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [LowBaseBtn3Label setTextColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [LowBaseBtn4Label setTextColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [LowBaseBtn5Label setTextColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [LowBaseBtn6Label setTextColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [LowBtn1Edge setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
        [LowBtn2Edge setBackgroundColor:[UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1]];
        [LowBtn3Edge setBackgroundColor:[UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1]];
        [LowBtn4Edge setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
        [LowBtn5Edge setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
        [LowBtn6Edge setBackgroundColor:[UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1]];
        [LowBtn1Inner setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
        [LowBtn2Inner setBackgroundColor:[UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1]];
        [LowBtn3Inner setBackgroundColor:[UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1]];
        [LowBtn4Inner setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
        [LowBtn5Inner setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
        [LowBtn6Inner setBackgroundColor:[UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1]];
        //Image
        [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        [btn3 setImage:[UIImage imageNamed:@"btn_search.png"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateHighlighted];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateHighlighted];
        [btn3 setImage:[UIImage imageNamed:@"btn_search.png"] forState:UIControlStateHighlighted];
        [LowBaseBtn1Image setImage:[UIImage imageNamed:@"btn_qrcode.png"]];
        [LowBaseBtn2Image setImage:[UIImage imageNamed:@"btn_menu.png"]];
        [LowBaseBtn3Image setImage:[UIImage imageNamed:@"btn_favour.png"]];
        [LowBaseBtn4Image setImage:[UIImage imageNamed:@"btn_coupon.png"]];
        [LowBaseBtn5Image setImage:[UIImage imageNamed:@"btn_history.png"]];
        [LowBaseBtn6Image setImage:[UIImage imageNamed:@"btn_setting.png"]];
    }

}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
//    btn.accessibilityLabel = [@"語音輸入餐廳或菜式" stringByAppendingFormat:@"，%@",TextField.text];
//    btn2.accessibilityLabel = [@"語音輸入地區或地址" stringByAppendingFormat:@"，%@",TextField2.text];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)speakTap:(id)sender {
    if ([PostMethodUse connectedToInternet]){
        if (isRecording == NO) {
            if(sender==btn){
                fieldNowIn=0;
            }else if (sender==btn2){
                fieldNowIn=1;
            }
            [self startRecording];
        } else {
            [self stopRecording];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

- (void)startRecording {
    if (isRecording == NO) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
            }
        }else{
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];
            }
        }
        [speechToTextModule beginRecording];
        isRecording = YES;
        [self showRecing];
    }
}

- (void)stopRecording {
    if (isRecording) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
            }
        }else{
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
            }
        }
        [speechToTextModule stopRecording:YES];
        isRecording = NO;
    }
}

-(void)showRecing{
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
    if(rp==nil){
        rp = [[RecordingPlane alloc]initWithFrame:currentWindow.frame];
        [rp.ClickRecButton addTarget:self action:@selector(endClick) forControlEvents:UIControlEventTouchUpInside];
        [rp.ClickRecButton setImage:[UIImage imageNamed:@"btn_record@3x.png"] forState:UIControlStateNormal];
    }
    if(rl==nil){
        rl=[[UIView alloc] initWithFrame:currentWindow.frame];
        indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        indicator.isAccessibilityElement = NO;
        indicator.frame = CGRectMake(0.0, 0.0, currentWindow.frame.size.width, currentWindow.frame.size.height);
        [rl addSubview:indicator];
    }
    [currentWindow addSubview:rl];
    [currentWindow addSubview:rp];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, rp.ClickRecButton);
}

-(void)endClick{
    [rp removeFromSuperview];
    [self stopRecording];
}
-(void)showLoadingView{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.5]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [indicator startAnimating];
    
}
-(void)removetheLoading{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [indicator stopAnimating];
    [rl removeFromSuperview];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self stopRecording];
    //No animate
    [locationManager stopUpdatingLocation];
    [self.navigationController setNavigationBarHidden:NO];
    [super viewWillDisappear:animated];
}

-(IBAction)GoLocationSearch:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoLocationSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        //Show No Location Pop up
        [PostMethodUse PopUpNeedGPSSettingInfoAlert];
    }
}


-(IBAction)TwoStringSearchClick:(id)sender
{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoQuickSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
               withObject:@"GoQuickSearch"
               afterDelay:0.1];
    }
    //[self performSegueWithIdentifier:@"GoQuickSearch" sender:self];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"GoQuickSearch"]){
        SearchResultViewController* vc = segue.destinationViewController;
        [vc LoadSearchTwoStringsWithOne:[TextField text] andTwo:[TextField2 text] AndLocation:currentLocation];
    }else if([[segue identifier] isEqualToString:@"GoLocationSearch"]){
        SearchResultViewController* vc = segue.destinationViewController;
        [vc LoadSearchLocationLat:currentLocation];
    }else if([[segue identifier] isEqualToString:@"GoAdvSearch"]){
        AdvanceSearchViewController* vc = segue.destinationViewController;
        [vc StartNewSearch];
    }
}
-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([identifier isEqualToString:@"ToQR"] || [identifier isEqualToString:@"ToMenu"] || [identifier isEqualToString:@"GoQuickSearch"] || [identifier isEqualToString:@"GoLocationSearch"] || [identifier isEqualToString:@"GoIDSearch"] || [identifier isEqualToString:@"GoAdvSearch"]){
        if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
            return;
        }
    }
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}


-(IBAction)CodeSerach:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoIDSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
                   withObject:@"GoIDSearch"
                   afterDelay:0.1];
    }
}


-(IBAction)AdvanceSerach:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoAdvSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
                   withObject:@"GoAdvSearch"
                   afterDelay:0.1];
    }
}

-(IBAction)QRScan:(id)sender{
    sixPageIn = 0;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"ToQR"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"ToQR" sender:self];
}

-(IBAction)FoodMenu:(id)sender{
    sixPageIn = 0;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"ToMenu"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"ToMenu" sender:self];
}

-(IBAction)MyFavourite:(id)sender{
    sixPageIn = 1;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"ToFavour"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"ToFavour" sender:self];
}

-(IBAction)MyCoupon:(id)sender{
    sixPageIn = 2;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"ToCoupon"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"ToCoupon" sender:self];
}

-(IBAction)MyHistory:(id)sender{
    sixPageIn = 3;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"ToHistory"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"ToHistory" sender:self];
}

-(IBAction)Settings:(id)sender{
    sixPageIn = 4;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
                          withObject:@"ToSetting"
                          afterDelay:0.1];
    //[self performSegueWithIdentifier:@"ToSetting" sender:self];
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}


#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){

        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];

        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        [MidLabel1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeH]];
        [MidLabel2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeH]];
        [MidLabel3 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeH]];
        [LowBaseBtn1Label setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [LowBaseBtn2Label setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [LowBaseBtn3Label setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [LowBaseBtn4Label setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [LowBaseBtn5Label setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [LowBaseBtn6Label setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [Field1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [((TMDInputField*)Field1) setBackSet:fontSizeS];
        [Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [((TMDInputField*)Field2) setBackSet:fontSizeS];
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
    
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    [myScroll setContentSize:myViewPanel.bounds.size];
}



#pragma mark - SpeechToTextModuleDelegate
- (BOOL)didReceiveVoiceResponse:(NSDictionary *)data {
    
    //NSLog(@"data %@",data);
    [self stopRecording];
    NSString *result = @"";
    id tmp = data[@"transcript"];
    if ([tmp isKindOfClass:[NSNumber class]] || [tmp rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location == NSNotFound) {
        // Spell out number
        // incase user spell number
        NSNumber *resultNumber = @([tmp integerValue]);
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        result = [formatter stringFromNumber:resultNumber];
    } else {
        result = tmp;
    }
    
    [self removetheLoading];
    
    if (fieldNowIn==0){
        TextField.text = result;
        //btn.accessibilityLabel = [@"語音輸入餐廳或菜式" stringByAppendingFormat:@"，%@",TextField.text];
        //UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, TextField);
    }else if (fieldNowIn==1){
        TextField2.text = result;
        //btn2.accessibilityLabel = [@"語音輸入地區或地址" stringByAppendingFormat:@"，%@",TextField2.text];
        //UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, TextField2);
    }
    return YES;
}

- (void)requestFailedWithError:(NSError *)error {
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (speechToTextModule) {
        [self stopRecording];
        speechToTextModule = nil;
    }
}


#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
//    NSLog(@"didFailWithError: %@", error);
//    UIAlertView *errorAlert = [[UIAlertView alloc]
//                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//    [errorAlert show];
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount=-100;
        if ([SegueToGoNext isEqualToString:@"GoLocationSearch"]){
            [PostMethodUse AfterLoadingLayoutUse];
            [locationManager stopUpdatingLocation];
            [PostMethodUse PopUpNoLocationInfoAlert];
        }else{
            [locationManager stopUpdatingLocation];
            [self performSelector:@selector(delaySegue:)
                       withObject:SegueToGoNext
                       afterDelay:0.1];
        }
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if (tryoutcount>=0){
        tryoutcount =-100;
        [locationManager stopUpdatingLocation];
        NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}


@end
