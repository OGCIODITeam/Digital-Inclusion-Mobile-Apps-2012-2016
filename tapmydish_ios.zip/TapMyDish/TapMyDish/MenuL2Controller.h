//
//  MenuL2Controller.h
//  TapMyDish
//
//  Created by BDMacMini1 on 25/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuL2Controller : UIViewController<UITabBarDelegate>
-(void) LoadDataFromML1Page:(NSMutableDictionary*) TheDict andPassKey:(int)index;
@end
