//
//  CouponDetailsViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 9/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CouponDetailsViewController : UIViewController<UITabBarDelegate>


-(void)LoadQuery:(NSMutableDictionary*) query AndTitle:(NSString*) title;
@end
