//
//  PostMethodUse.h
//  TapMyDish
//
//  Created by BDMacMini1 on 7/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface PostMethodUse : NSObject
+(NSMutableDictionary*) PostMethodWithFunctionString:(NSString*)VarString;
+(UIImage*) ImageMethodWithNSURL:(NSString*) url;
+(NSMutableDictionary*) PostSettingMethodWithFunctionString:(NSString*)VarString;
+(void) BeforeLoadingLayoutUse:(BOOL)needSound;
+(void) AfterLoadingLayoutUse;
+(BOOL) connectedToInternet;
+(void) PopUpNoInternetAlert;
+(void) PopUpNoLocationInfoAlert;
+(void) PopUpNeedGPSSettingInfoAlert;
+(void) PopUpNoCoupon;
+(void) PopUpNoEmail;
+(void) PopUpCancelledMyCoupon;
+(void) PopUpAddedMyCoupon;
+(void) PopUpCancelledMyFavourite;
+(void) PopUpAddedMyFavourite;
+(void) PopUpWrongSchema;
+(void) PopUpNeedUpdate;
+ (BOOL)newVersionPresent;
+(void) setBeforeVoiceOut:(BOOL)bvo;
+(BOOL) getBeforeVoiceOut;
+(BOOL) IsUnderFavourite;
+(void) setIsFavourite:(BOOL) fav;
@end
