//
//  StringUnity.m
//  TapMyDish
//
//  Created by BDMacMini1 on 25/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "StringUnity.h"

@implementation StringUnity

+(NSString*) RefinedString:(id)StringToRefine{
    NSString * str = StringToRefine;
    return [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

+(NSString*) ReadWordRefinement:(id)StringToRefine{
    NSString * str = StringToRefine;
    NSString * str2 = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    NSArray* strs = [str2 componentsSeparatedByString:@"$"];
//    NSString* modifiedString = [strs objectAtIndex:0];
//    for (int i =1;i<[strs count];i++){
//        modifiedString = [modifiedString stringByAppendingString:@"港幣"];
//        modifiedString = [modifiedString stringByAppendingString:[strs objectAtIndex:i]];
//    }
    NSError *error = NULL;
    NSRegularExpression *regex =
    [NSRegularExpression regularExpressionWithPattern:@"([+-]?)\\s*\\$\\s*([0-9]{1,3}(?:,?[0-9]{3})*(?:\\.[0-9]{1,2})?)"
                                              options:0
                                                error:&error];
    NSUInteger numberOfMatches = [regex numberOfMatchesInString:str2
                                                        options:0
                                                          range:NSMakeRange(0, [str2 length])]; // Check full string
    NSString* mStr = [regex stringByReplacingMatchesInString:str2 options:0 range:NSMakeRange(0, [str2 length]) withTemplate:@"$1$2元"];
    
    NSRegularExpression *regex2 =
    [NSRegularExpression regularExpressionWithPattern:@"([+-]?)\\s*\\$\\s*([0-9]{1,3}(?:,?[0-9]{3})*)"
                                              options:0
                                                error:&error];
    NSString* mStr2 = [regex2 stringByReplacingMatchesInString:mStr options:0 range:NSMakeRange(0, [mStr length]) withTemplate:@"$1$2元"];
    
    //if (numberOfMatches > 0) {
        // You have at least one match ...
        //NSLog(@"%ld", numberOfMatches);
    //}
    //NSLog(@"%@", mStr);
    return mStr2;
}

+(NSString*) FoodPriceString:(id)StringToRefine{
    NSString * str = StringToRefine;
    NSString * str2 = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];    NSError *error = NULL;
    NSRegularExpression *regex =
    [NSRegularExpression regularExpressionWithPattern:@"([+-]?)\\s*\\$\\s*([0-9]{1,3}(?:,?[0-9]{3})*(?:\\.[0-9]{1,2})?)"
                                              options:0
                                                error:&error];
    NSUInteger numberOfMatches = [regex numberOfMatchesInString:str2
                                                        options:0
                                                          range:NSMakeRange(0, [str2 length])]; // Check full string
    NSString* mStr = [regex stringByReplacingMatchesInString:str2 options:0 range:NSMakeRange(0, [str2 length]) withTemplate:@"$1$2元"];
    NSRegularExpression *regex2 =
    [NSRegularExpression regularExpressionWithPattern:@"([+-]?)\\s*\\$\\s*([0-9]{1,3}(?:,?[0-9]{3})*)"
                                              options:0
                                                error:&error];
    NSString* mStr2 = [regex2 stringByReplacingMatchesInString:mStr options:0 range:NSMakeRange(0, [mStr length]) withTemplate:@"$1$2元"];
//    NSRegularExpression *regex1 =
//    [NSRegularExpression regularExpressionWithPattern:@"(^[+-]?[0-9]{1,3}(?:,?[0-9]{3})*(?:\\.[0-9]{2})?$)"
//                                              options:0
//                                                error:&error];
//    
//    mStr = [regex1 stringByReplacingMatchesInString:mStr options:0 range:NSMakeRange(0, [mStr length]) withTemplate:@"$1元"];
    //if (numberOfMatches > 0) {
    // You have at least one match ...
    //NSLog(@"%ld", numberOfMatches);
    //}
    //NSLog(@"%@", mStr);
    return mStr2;

}

@end
