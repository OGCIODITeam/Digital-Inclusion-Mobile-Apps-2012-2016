//
//  MenuItem.m
//  TapMyDish
//
//  Created by BDMacMini1 on 26/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MenuItem.h"
#import "StringUnity.h"
#import "MenuL3Controller.h"
#import "PostMethodUse.h"

@interface MenuItem(){
    MenuL3Controller* myparent;
    NSString* ImgPath;
}
@end

@implementation MenuItem
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(void) InitialSetLook:(NSMutableDictionary*) Dict withParent:(id)parent{
    myparent =parent;
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    NSString* foodname = [StringUnity RefinedString:[Dict objectForKey:@"foodname"]];
    NSString* foodContent = [StringUnity RefinedString:[Dict objectForKey:@"foodContent"]];
    NSString* foodPic = [StringUnity RefinedString:[Dict objectForKey:@"foodPic"]];
    NSString* foodPrice = [StringUnity RefinedString:[Dict objectForKey:@"foodPrice"]];
    if ([foodPic isEqualToString:@""]||[foodPic isEqualToString:@"gallery/foodPic/"]){
        [_PhotoBtnContainer removeFromSuperview];
        _PhotoBtnContainer = nil;
        ImgPath = @"";
    }else{
        ImgPath =foodPic;
        for (int i =0;i<_PhotoBtnContainer.subviews.count;i++){
            if ([[_PhotoBtnContainer.subviews objectAtIndex:i] isKindOfClass:[UIButton class]]){
                UIButton* btn =[_PhotoBtnContainer.subviews objectAtIndex:i];
                [btn addTarget:self action:@selector(ShowPhoto:) forControlEvents:UIControlEventTouchUpInside];
            }
        }
        for(int i = 0;i<_PhotoBtnContainer.subviews.count;i++){
            if([[_PhotoBtnContainer.subviews objectAtIndex:i] isKindOfClass:[UIImageView class]]){
                UIImageView* btn =[_PhotoBtnContainer.subviews objectAtIndex:i];
                if (isNoColor){
                    [btn setImage:[UIImage imageNamed:@"PhotoBase_grey.png"]];
                }else{
                    [btn setImage:[UIImage imageNamed:@"PhotoBase.png"]];
                }
            }
        }
    }
    [_DishName setText:foodname];
    [_DishName setAccessibilityTraits:UIAccessibilityTraitHeader];
    [_PriceLabel setText:[NSString stringWithFormat:@"價格：%@",foodPrice]];
    [_PriceLabel setAccessibilityLabel:[NSString stringWithFormat:@"價格：%@",[StringUnity FoodPriceString:foodPrice]]];
    [_FoodHeader setText:@"食品內容："];
    [_FoodHeader setAccessibilityLabel:[NSString stringWithFormat:@"食品內容：%@",foodContent]];
    [_FoodDetail setText:foodContent];
    if([foodContent isEqualToString:@""]){
        _FoodHeader.isAccessibilityElement = NO;
    }
    if (isNoColor){
        [_DishName setTextColor:[UIColor blackColor]];
        [_ContentImage setImage:[UIImage imageNamed:@"icon_content_grey@3x.png"]];
    }else{
        [_DishName setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [_ContentImage setImage:[UIImage imageNamed:@"icon_content@3x.png"]];
    }
}

-(void) SetFontSize:(CGFloat)fSize andHeaderSize:(CGFloat)fSSize{
    UIFont* bodyFont = [UIFont fontWithName:@"Heiti TC" size:fSize];
    UIFont* BoldBodyB = [UIFont fontWithName:@"STHeitiTC-Medium" size:fSize*1.2];
    UIFont* BoldBody = [UIFont fontWithName:@"STHeitiTC-Medium" size:fSize];
    UIFont* HeadFont = [UIFont fontWithName:@"Heiti TC" size:fSSize];
    [_DishName setFont:BoldBodyB];
    [_PriceLabel setFont:bodyFont];
    [_FoodHeader setFont:BoldBody];
    [_FoodDetail setFont:bodyFont];
    if (_PhotoBtnContainer!=nil){
        for(int i = 0;i<_PhotoBtnContainer.subviews.count;i++){
            if([[_PhotoBtnContainer.subviews objectAtIndex:i] isKindOfClass:[UILabel class]]){
                UILabel* lb =[_PhotoBtnContainer.subviews objectAtIndex:i];
                [lb setFont:HeadFont];
            }
        }
        _PhotoBtnHeight.constant = fSSize + 16;
    }
    _ContentImageHeight.constant = fSize;
}

-(void)ShowPhoto:(id)sender{
    [myparent ShowTheImagePopUpWith:[PostMethodUse ImageMethodWithNSURL:ImgPath] withDish:_DishName.text];
}

@end
