//
//  TabItemTick.m
//  TapMyDish
//
//  Created by BDMacMini1 on 4/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "TabItemTick.h"

@interface TabItemTick ()  {

    BOOL meLabelOn;
}
@end

@implementation TabItemTick

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        meLabelOn = NO;
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        meLabelOn = NO;
    }
    return self;
}

-(void) setFontSize:(CGFloat)FS{
    if(meLabelOn){
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if (!isNoColor) [_ArrowImage setImage:[UIImage imageNamed:@"tickB@3x.png"]];
        else  [_ArrowImage setImage:[UIImage imageNamed:@"tickB_grey@3x.png"]];
    }else{
        [_ArrowImage setImage:[UIImage imageNamed:@"empty.png"]];
    }
    _ArrowImageHeight.constant = FS;
    [_LabelTitle setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
}

-(void) setLabelText:(NSString*) theLabel{
    if(meLabelOn){
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if (!isNoColor) [_ArrowImage setImage:[UIImage imageNamed:@"tickB@3x.png"]];
        else  [_ArrowImage setImage:[UIImage imageNamed:@"tickB_grey@3x.png"]];
    }else{
        [_ArrowImage setImage:[UIImage imageNamed:@"empty.png"]];
    }
    [_LabelTitle setText:[theLabel stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
    if (!meLabelOn){
        [_LabelButtonForClick setAccessibilityLabel:[theLabel stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
    }else{
        [_LabelButtonForClick setAccessibilityLabel:[[theLabel stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] stringByAppendingString:@" 已選擇"]];
    }
}

-(void) setLabelOn:(BOOL)LabelOn{
    meLabelOn = LabelOn;
    if(meLabelOn){
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if (!isNoColor) [_ArrowImage setImage:[UIImage imageNamed:@"tickB@3x.png"]];
        else  [_ArrowImage setImage:[UIImage imageNamed:@"tickB_grey@3x.png"]];
    }else{
        [_ArrowImage setImage:[UIImage imageNamed:@"empty.png"]];
    }
    if (!meLabelOn){
        [_LabelButtonForClick setAccessibilityLabel:_LabelTitle.text];
    }else{
        [_LabelButtonForClick setAccessibilityLabel:[_LabelTitle.text stringByAppendingString:@" 已選擇"]];
    }
}


@end
