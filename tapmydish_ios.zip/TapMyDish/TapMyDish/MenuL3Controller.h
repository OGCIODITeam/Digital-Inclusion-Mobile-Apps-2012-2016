//
//  MenuL3Controller.h
//  TapMyDish
//
//  Created by BDMacMini1 on 25/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuL3Controller : UIViewController<UITabBarDelegate>
-(void) LoadDataFromML2Page:(NSMutableDictionary*) TheDict andPassM1Key:(int)indexM1 andPassM2Key:(int)indexM2;
-(void) ShowTheImagePopUpWith:(UIImage*) myImage withDish:(NSString*) DishName;
@end
