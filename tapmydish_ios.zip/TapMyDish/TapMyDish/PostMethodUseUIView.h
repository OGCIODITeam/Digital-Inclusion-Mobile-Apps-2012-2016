//
//  PostMethodUseUIView.h
//  TapMyDish
//
//  Created by BDMacMini1 on 24/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PostMethodUseUIView : UIView



-(void) setBeforeVoiceOut:(BOOL)bvo;

-(BOOL) getBeforeVoiceOut;

- (void)didFinishAnnouncement:(NSNotification *)dict;

-(void) setNeedVoiceOut:(BOOL)bvo;

- (void)accessibilityElementDidBecomeFocused;
@end
