#import <UIKit/UIKit.h>

@interface AccessGroupView : UIView


@end