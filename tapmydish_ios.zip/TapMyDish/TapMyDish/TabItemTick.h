//
//  TabItemTick.h
//  TapMyDish
//
//  Created by BDMacMini1 on 4/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#ifndef TabItemTickDefined
#define TabItemTickDefined 1

#import <UIKit/UIKit.h>

@interface TabItemTick : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UILabel *LabelTitle;
@property (weak, nonatomic) IBOutlet UIImageView *ArrowImage
;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *ArrowImageHeight;
@property (weak, nonatomic) IBOutlet UIButton *LabelButtonForClick;

-(void) setFontSize:(CGFloat)FS;

-(void) setLabelText:(NSString*) theLabel;

-(void) setLabelOn:(BOOL)LabelOn;
@end

#endif
