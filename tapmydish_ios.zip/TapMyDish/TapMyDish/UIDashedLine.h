//
//  UIDashedLine.h
//  TapMyDish
//
//  Created by BDMacMini1 on 20/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDashedLine : UIView

@end
