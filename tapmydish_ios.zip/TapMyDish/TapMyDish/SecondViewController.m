//
//  SecondViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 9/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "SecondViewController.h"
#import "RestaurantItem.h"
#import "TabItemArrow.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //RestaurantItem *item = [[RestaurantItem alloc] init];
//    TabItemArrow *item = [[TabItemArrow alloc] initWithFrame:CGRectZero];
//    //[item setFrame:CGRectMake(0, 0, 200, 120)];
//    [self.view addSubview:item];
//    item.translatesAutoresizingMaskIntoConstraints=NO;
//    [self.view addConstraints:item.constraints];
//    NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
//    [self.view addConstraint:topCon];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];

    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    [self performSegueWithIdentifier:@"leave" sender:self];
}

@end
