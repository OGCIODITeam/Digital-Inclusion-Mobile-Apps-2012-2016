//
//  TMDInputField.h
//  TapMyDish
//
//  Created by BDMacMini1 on 24/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMDInputField : UITextField

-(void)setBackSet:(CGFloat) bs;

@end
