//
//  Adv.m
//  TapMyDish
//
//  Created by BDMacMini1 on 28/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "Adv.h"

@implementation Adv

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(void)setFontSize:(CGFloat)FSize{
    
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    UIFont* headerFonts = [UIFont fontWithName:@"STHeitiTC-Medium" size:FSize];
    UIFont* DescribeFonts = [UIFont fontWithName:@"Heiti TC" size:FSize];
    [_TitleLabel setFont:headerFonts];
    [_DescriptionLabel setFont:DescribeFonts];
    while([[_UnlimitedBGContainer subviews] count]>0){
        [[[_UnlimitedBGContainer subviews] objectAtIndex:0]removeFromSuperview];
    }
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    //GET Now Size
    //NSLog(@"%g %g",_UnlimitedBGContainer.frame.size.width,_UnlimitedBGContainer.frame.size.height);
    
    CGFloat Bheight =_UnlimitedBGContainer.frame.size.width/1047*740;
    CGFloat THeight = _UnlimitedBGContainer.frame.size.height;
    int i =0;
    while (THeight>=0){
        THeight = THeight-Bheight;
        CGRect a =CGRectMake(0, i*Bheight, _UnlimitedBGContainer.frame.size.width, Bheight);
        UIImageView* temp = [[UIImageView alloc] initWithFrame:a];
        if(isNoColor){
            [temp setImage:[UIImage imageNamed:@"ad_bg_grey@3x.png"]];
        }else{
            [temp setImage:[UIImage imageNamed:@"ad_bg@3x.png"]];
        }
        [_UnlimitedBGContainer addSubview:temp];
        //NSLog(@"Theight %g a.y is %g",THeight, a.origin.y);
        i++;
    }
}

@end
