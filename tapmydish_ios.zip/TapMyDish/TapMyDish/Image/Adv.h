//
//  Adv.h
//  TapMyDish
//
//  Created by BDMacMini1 on 28/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Adv : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UIView *UnlimitedBGContainer;
@property (weak, nonatomic) IBOutlet UILabel *TitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *DescriptionLabel;
@property (weak, nonatomic) IBOutlet UIButton *LinkBtn;

-(void)setFontSize:(CGFloat)FSize;

@end
