//
//  UIImage_withColor.h
//  TapMyDish
//
//  Created by BDMacMini1 on 8/12/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (withColor)
+ (UIImage *)imageWithColor:(UIColor *)color andBounds:(CGRect)imgBounds;
@end




@implementation UIImage (withColor)
+(UIImage *)imageWithColor:(UIColor *)color andBounds:(CGRect)imgBounds {
    UIGraphicsBeginImageContextWithOptions(imgBounds.size, NO, 0);
    [color setFill];
    UIRectFill(imgBounds);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}
@end
