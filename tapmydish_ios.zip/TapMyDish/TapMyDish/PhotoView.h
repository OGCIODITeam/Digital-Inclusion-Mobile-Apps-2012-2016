//
//  PhotoView.h
//  TapMyDish
//
//  Created by BDMacMini1 on 1/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoView : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UIView *WhiteFrame;
@property (weak, nonatomic) IBOutlet UIImageView *myphotoview;
@property (weak, nonatomic) IBOutlet UIView *BlackBase;
@property (weak, nonatomic) IBOutlet UIButton *CloseBtn;
//@property (weak, nonatomic) IBOutlet NSLayoutConstraint *ImageRatio;
-(Boolean) SetPhoto:(UIImage*) photo withDishName:(NSString*) DishName;
@end
