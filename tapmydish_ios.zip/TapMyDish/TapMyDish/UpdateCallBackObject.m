//
//  UpdateCallBackObject.m
//  TapMyDish
//
//  Created by BDMacMini1 on 18/1/2017.
//  Copyright © 2017年 BigDipperStudio. All rights reserved.
//

#import "UpdateCallBackObject.h"

@implementation UpdateCallBackObject

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    // the user clicked one of the OK/Cancel buttons
    if (buttonIndex == 1)
    {
        NSString *iTunesLink = @"https://itunes.apple.com/us/app/dian-cai-yi/id1184274363?l=zh&ls=1&mt=8";
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
    }
}

@end
