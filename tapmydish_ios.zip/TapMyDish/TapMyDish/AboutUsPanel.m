//
//  AboutUsPanel.m
//  TapMyDish
//
//  Created by BDMacMini1 on 25/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "AboutUsPanel.h"

@implementation AboutUsPanel


-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.view.accessibilityElements = [NSArray arrayWithObjects:_Slot1,_Slot2,_Slot3, _WebBtn1, _ContactUsSlot, _PhoneBtn, _FaxBtn, _EmailBtn, _WebBtn, _FBBtn, _AddressBtn, _CloseBtn, nil];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        self.view.accessibilityElements = [NSArray arrayWithObjects:_Slot1,_Slot2,_Slot3, _WebBtn1, _ContactUsSlot, _PhoneBtn, _FaxBtn, _EmailBtn, _WebBtn, _FBBtn, _AddressBtn, _CloseBtn, nil];
    }
    return self;
}

-(void)setFontSize:(CGFloat) FS{
    [_Heading1 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS]];
    [_Heading2 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS]];
    [_Heading3 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS]];
    [_Heading5 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS]];
    [_Heading5 setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS]];
    [_Slot1P1 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_Slot1P2 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_Slot2P1 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_Slot2P2 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_Slot3P1 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_Slot4P1 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_Slot5P1 setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_PhoneLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_FaxLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_EmailLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_WebLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_FBLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_AddressLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_CloseBtn setImage:[UIImage imageNamed:@"btn_close_2@3x.png"] forState:(UIControlStateNormal)];
    [_BlackBack bringSubviewToFront:_CloseBtn];
}
- (BOOL)accessibilityViewIsModal {
    return YES;
}

-(IBAction)gotoweb:(id)sender{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.hkbu.org.hk"]];
}

-(IBAction)gotophone:(id)sender{
    NSString *phoneNumber = [@"telprompt://" stringByAppendingString:@"2709 5559"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
}


-(IBAction)PostFacebook:(id)sender{
    NSURL* fbURLWeb = [NSURL URLWithString:@"https://www.facebook.com/HKBlindUnion"];
    NSURL* fbURLID = [NSURL URLWithString:@"fb://profile/126533087401768"];
    
    if([[UIApplication sharedApplication] canOpenURL:(fbURLID)]){
        // FB installed
        [[UIApplication sharedApplication] openURL:(fbURLID)];
    } else {
        // FB is not installed, open in safari
        [[UIApplication sharedApplication] openURL:(fbURLWeb)];
    }
}
@end
