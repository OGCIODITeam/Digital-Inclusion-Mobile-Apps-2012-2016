//
//  MenuPageViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MenuPageViewController.h"
#import "SpeechToTextModule.h"
#import "CollectionCell.h"
#import "TabItemArrow.h"
#import "RestaurantItem.h"
#import "SearchResultViewController.h"
#import "StringUnity.h"
#import "AdvanceSearchViewController.h"
#import "TMDInputField.h"

#import "PostMethodUse.h"
#import "RecordingPlane.h"
#import "UIImage_withColor.h"

@interface MenuPageViewController ()<SpeechToTextModuleDelegate>  {
    SpeechToTextModule *speechToTextModule;
    BOOL isRecording;
    int fieldNowIn;
    
    int ChosenItemID;
    
    __weak IBOutlet UITabBar* tabBar;
    
    
    __weak IBOutlet UITextField *TextField;
    __weak IBOutlet UITextField *TextField2;
    __weak IBOutlet UIButton *btn;
    __weak IBOutlet UIButton *btn2;
    __weak IBOutlet UIButton *btn3;
    
    __weak IBOutlet UIButton *btnGPS;
    __weak IBOutlet UIButton *btnCode;
    __weak IBOutlet UIButton *btnAdvance;
        
    __weak IBOutlet UIView * UpperBasement;
    __weak IBOutlet UIView * MiddleBasement;
    
    __weak IBOutlet UILabel* MidLabel1;
    __weak IBOutlet UILabel* MidLabel2;
    __weak IBOutlet UILabel* MidLabel3;
    
    __weak IBOutlet UITextField* Field1;
    __weak IBOutlet UITextField* Field2;
    
    
    //tb
//    __weak IBOutlet UITableView* tbView;
    
    //collection view
    //__weak IBOutlet UICollectionView* collectview;
    //__weak IBOutlet UICollectionViewFlowLayout* cvlayout;
    //__weak IBOutlet NSLayoutConstraint* cvheight;
    
    
    __weak IBOutlet UIScrollView* uppersideScroll;
    __weak IBOutlet UIView* uppersideViewPanel;
    __weak IBOutlet NSLayoutConstraint* cvheight;
    __weak IBOutlet UIView * LoweBasement;
    
        
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* myViewPanel;
    __weak IBOutlet UIView* ScrollTab;
    //Data
    NSMutableArray* CellArray;
    NSMutableArray* ScrollArray;
    NSMutableArray* DictionariesForCellArrayUse;
    NSMutableDictionary* QueryArray;
    NSMutableArray* QueryArrayLayer;
    
    NSMutableArray* nowArrayLayer;
    
    //Font Size Short Hand
    CGFloat fSUse;
    CGFloat fUse;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    int tryoutcount;
    NSString* SegueToGoNext;
    __weak IBOutlet UILabel* menuClaimNotUpdate;
    
    
    RecordingPlane* rp;
    UIView* rl;
    UIActivityIndicatorView* indicator;
}

@end

@implementation MenuPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [btn setHidden:YES];
    [btn2 setHidden:YES];
    // Do any additional setup after loading the view, typically from a nib.
    speechToTextModule = [[SpeechToTextModule alloc] initWithCustomDisplay:nil];
    speechToTextModule.delegate = self;
    [speechToTextModule duckOff];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    
    
    //self.view.accessibilityElements = @[TextField, btn, TextField2, btn2, btn3];
    btn.accessibilityLabel = @"語音輸入餐廳或菜式";
    btn2.accessibilityLabel = @"語音輸入地區或地址";
    btn3.accessibilityLabel = @"搜尋";
    
    btnCode.accessibilityLabel = @"編號搜尋";
    btnGPS.accessibilityLabel = @"定位搜尋";
    btnAdvance.accessibilityLabel = @"進階搜尋";
    
    [TextField setDelegate:self];
    [TextField2 setDelegate:self];
    //Data table
//    [tbView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell"];
//    tbView.rowHeight = UITableViewAutomaticDimension;
//    tbView.estimatedRowHeight = 100;
    //Data collect view
    //[collectview registerNib:[UINib nibWithNibName:@"CollectionCell" bundle:nil] forCellWithReuseIdentifier:@"CollectionCell"];
    //cvlayout.estimatedItemSize = CGSizeMake(100, 50);
    //collectview.translatesAutoresizingMaskIntoConstraints = NO;
    //cvlayout
    
    
    
    QueryArray = [PostMethodUse PostMethodWithFunctionString:@"m=menu_forSearch&only=dish"];
    if (QueryArray!=nil){
        QueryArrayLayer=[NSMutableArray arrayWithCapacity:0];
        NSMutableDictionary* dictdict = [QueryArray objectForKey:@"dishType"];
        NSInteger keyindex = 0;
        NSMutableDictionary* dictdictTemp = [dictdict mutableCopy];
        while (dictdictTemp.count>0){
            while ([dictdictTemp objectForKey:[NSString stringWithFormat:@"%ld", (long) keyindex]]==nil){
                keyindex = keyindex+1;
            }
            NSString* key =[NSString stringWithFormat:@"%ld", (long) keyindex];
            [QueryArrayLayer addObject:[dictdict objectForKey:key]];
            [dictdictTemp removeObjectForKey:key];
        }
    }else{
        QueryArrayLayer = [NSMutableArray arrayWithCapacity:0];
    }
    
    ScrollTab.layer.shadowColor =[UIColor grayColor].CGColor;
    ScrollTab.layer.shadowOffset = CGSizeMake(1, 2);
    ScrollTab.layer.shadowOpacity = 0.5;
    ScrollTab.layer.shadowRadius=1.0;
    
    uppersideViewPanel.layer.shadowColor =[UIColor grayColor].CGColor;
    uppersideViewPanel.layer.shadowOffset = CGSizeMake(1, 2);
    uppersideViewPanel.layer.shadowOpacity = 0.5;
    uppersideViewPanel.layer.shadowRadius=1.0;
    
    LoweBasement.layer.shadowColor =[UIColor grayColor].CGColor;
    LoweBasement.layer.shadowOffset = CGSizeMake(1, 2);
    LoweBasement.layer.shadowOpacity = 0.5;
    LoweBasement.layer.shadowRadius=1.0;
    
    nowArrayLayer = QueryArrayLayer;
    
    [self setUpNowScroll];
    
    
    
    //Must after Cells define
    
    [self setFontSizes];
    [self setTabBarOutLook];
    
    
    //Define Scroll upper to instead of collection view
    CellArray = [NSMutableArray arrayWithCapacity:0];
    DictionariesForCellArrayUse =[NSMutableArray arrayWithCapacity:0];
    //Fake
    //[self AddUpperItemWith:@"Apple"];
    
    
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)speakTap:(id)sender {
    if ([PostMethodUse connectedToInternet]){
        if (isRecording == NO) {
            if(sender==btn){
                fieldNowIn=0;
            }else if (sender==btn2){
                fieldNowIn=1;
            }
            [self startRecording];
        } else {
            [self stopRecording];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

- (void)startRecording {
    if (isRecording == NO) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
            }
        }else{
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];
            }
        }
        [speechToTextModule beginRecording];
        isRecording = YES;
        [self showRecing];
    }
}

- (void)stopRecording {
    if (isRecording) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
            }
        }else{
            if (fieldNowIn == 0){
                [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
            }else{
                [btn2 setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
            }
        }
        [speechToTextModule stopRecording:YES];
        isRecording = NO;
    }
}
-(void)showRecing{
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
    if(rp==nil){
        rp = [[RecordingPlane alloc]initWithFrame:currentWindow.frame];
        [rp.ClickRecButton addTarget:self action:@selector(endClick) forControlEvents:UIControlEventTouchUpInside];
        [rp.ClickRecButton setImage:[UIImage imageNamed:@"btn_record@3x.png"] forState:UIControlStateNormal];
    }
    if(rl==nil){
        rl=[[UIView alloc] initWithFrame:currentWindow.frame];
        indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        indicator.isAccessibilityElement = NO;
        indicator.frame = CGRectMake(0.0, 0.0, currentWindow.frame.size.width, currentWindow.frame.size.height);
        [rl addSubview:indicator];
    }
    [currentWindow addSubview:rl];
    [currentWindow addSubview:rp];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, rp.ClickRecButton);
}

-(void)endClick{
    [rp removeFromSuperview];
    [self stopRecording];
}
-(void)showLoadingView{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.5]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [indicator startAnimating];
    
}
-(void)removetheLoading{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [indicator stopAnimating];
    [rl removeFromSuperview];
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    Field1.text = @"";
    Field2.text = @"";
    //Menu
    [tabBar setSelectedItem:tabBar.items[0]];
    [self setTabBarOutLook];
    [self setFontSizes];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    }


#pragma mark - Show with scroll


-(void)AddUpperItemWith:(NSString*)ButtonLabel{
    //Base
    UIView* baseView = [[UIView alloc] initWithFrame:CGRectZero];
    [baseView setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
    [uppersideViewPanel addSubview:baseView];
    if ([CellArray count]==0){
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:uppersideViewPanel attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
    }else{
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:[CellArray objectAtIndex:[CellArray count]-1] attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
    }
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:uppersideViewPanel attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:uppersideViewPanel attribute:NSLayoutAttributeBottom multiplier:1 constant:-1]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationLessThanOrEqual toItem:uppersideViewPanel attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
    baseView.translatesAutoresizingMaskIntoConstraints = NO;
    
    //Tex
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [baseView addSubview:button];
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeTop multiplier:1 constant:-8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeLeft multiplier:1 constant:-8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeBottom multiplier:1 constant:8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:baseView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:button attribute:NSLayoutAttributeRight multiplier:1 constant:8]];
    
    
    [button.titleLabel setText:[StringUnity RefinedString:ButtonLabel]];
    [button setTitle:[StringUnity RefinedString:ButtonLabel] forState:UIControlStateNormal];
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [button setTitleColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1] forState:UIControlStateNormal];
    }else{
        [button setTitleColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1] forState:UIControlStateNormal];
    }
    [button.titleLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    //[button.titleLabel setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
    
    [CellArray addObject:baseView];
    [button addTarget:self action:@selector(RemoveUpperItemUntilId:) forControlEvents:UIControlEventTouchUpInside];
    
//    baseView.layer.shadowColor =[UIColor grayColor].CGColor;
//    baseView.layer.shadowOffset = CGSizeMake(1, 2);
//    baseView.layer.shadowOpacity = 0.5;
//    baseView.layer.shadowRadius=1.0;
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(void) RemoveUpperItemUntilId:(id)itemBeforeToRemove{
    while([CellArray count]>0){
        UIView* v = (UIView*)[CellArray objectAtIndex:[CellArray count]-1];
        if (v.subviews[0]== itemBeforeToRemove){
            //NSLog(@"Arrived");
            break;
        }
        [CellArray removeObject:v];
        [DictionariesForCellArrayUse removeObject:[DictionariesForCellArrayUse objectAtIndex:[DictionariesForCellArrayUse count]-1]];
        UIButton* b = v.subviews[0];
        [b removeTarget:self action:@selector(RemoveUpperItemUntilId:) forControlEvents:UIControlEventTouchUpInside];
        [self.view removeConstraints:b.constraints];
        [b removeFromSuperview];
        [self.view removeConstraints:v.constraints];
        [v removeFromSuperview];
        v = nil;
    }
    // Reset Lower Menu
    nowArrayLayer = [DictionariesForCellArrayUse objectAtIndex:[DictionariesForCellArrayUse count]-1];
    
    //LastOneFunction
    if([CellArray count] == 1){
        UIView* v = (UIView*)[CellArray objectAtIndex:[CellArray count]-1];
        [CellArray removeObject:v];
        [DictionariesForCellArrayUse removeObject:[DictionariesForCellArrayUse objectAtIndex:[DictionariesForCellArrayUse count]-1]];
        UIButton* b = v.subviews[0];
        [b removeTarget:self action:@selector(RemoveUpperItemUntilId:) forControlEvents:UIControlEventTouchUpInside];
        [self.view removeConstraints:b.constraints];
        [b removeFromSuperview];
        [self.view removeConstraints:v.constraints];
        [v removeFromSuperview];
        v = nil;
    }
    
    [self setLastOneUnClick];
    [self setUpNowScroll];
}

-(void) setLastOneUnClick{
    for (int i =0;i<[CellArray count];i++){
        UIView * baseview =[CellArray objectAtIndex:i];
        UIButton* button = [baseview.subviews objectAtIndex:0];
        if (i == [CellArray count]-1){
            [baseview setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:0]];
            [button setAccessibilityTraits:UIAccessibilityTraitNone];
        }else{
            [baseview setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
            [button setAccessibilityTraits:UIAccessibilityTraitButton];
        }
    }
    
}


#pragma mark - Logic for Menu

-(void)setUpNowScroll{
    while([ScrollArray count]>0){
        TabItemArrow* tia =[ScrollArray objectAtIndex:[ScrollArray count]-1];
        [self.view removeConstraints:tia.constraints];
        [tia removeFromSuperview];
        [tia.LabelButtonForClick removeTarget:self action:@selector(ClickedLowerItem:) forControlEvents:UIControlEventTouchUpInside];
        [ScrollArray removeObject:tia];
        tia = nil;
    }
    
    NSMutableArray* ary = [NSMutableArray arrayWithCapacity:0];
    
    for (NSMutableDictionary* dict in nowArrayLayer){
        NSString* arrayString = dict[@"tn"];
        [ary addObject:arrayString];
    }
    
    
    ScrollArray = [NSMutableArray arrayWithCapacity:0];
    int length = [ary count];
    //Fake Item
    for (int i =0;i<length;i++){
        TabItemArrow* tia = [[TabItemArrow alloc] initWithFrame:CGRectZero];
        [ScrollTab addSubview:tia];
        tia.translatesAutoresizingMaskIntoConstraints = NO;
        [self.view addConstraints:tia.constraints];
        
        [ScrollArray addObject:tia];
        if(i==0){
            [self.view addConstraint:[NSLayoutConstraint constraintWithItem:tia attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:ScrollTab attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
            
            [tia setLabelText:[StringUnity RefinedString:[ary objectAtIndex:i]]];
        }
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:tia attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:ScrollTab attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:tia attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:ScrollTab attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        
        if (i>0){
            [tia setLabelText:[StringUnity RefinedString:[ary objectAtIndex:i]]];
            [self.view addConstraint:[NSLayoutConstraint constraintWithItem:tia attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:[ScrollArray objectAtIndex:i-1] attribute:NSLayoutAttributeBottom multiplier:1 constant:1]];
        }
        if (i==length-1){
            [self.view addConstraint:[NSLayoutConstraint constraintWithItem:tia attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:ScrollTab attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        }
        tia.LabelButtonForClick.tag = i;
        [tia.LabelButtonForClick addTarget:self action:@selector(ClickedLowerItem:) forControlEvents:UIControlEventTouchUpInside] ;
        [tia setFontSize:fUse];
    }
    ScrollTab.translatesAutoresizingMaskIntoConstraints = NO;
    [ScrollTab setNeedsLayout];
    [ScrollTab layoutIfNeeded];
}



-(void) ClickedLowerItem:(id)sender{
    int index = ((UIButton*)sender).tag;
    NSMutableDictionary * dict = [nowArrayLayer objectAtIndex:index];
    NSMutableDictionary * ary = [dict objectForKey:@"sub"];
    if (ary == [NSNull null]){
        //go
        //NSLog(@"Can Null");
        //Get ID directly
        ChosenItemID =index;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
            currentLocation=nil;
            tryoutcount=0;
            SegueToGoNext=@"GoSearchResult";
            locationManager.desiredAccuracy = kCLLocationAccuracyBest;
            [locationManager startUpdatingLocation];
        }else{
            currentLocation=nil;
            [self performSelector:@selector(delaySegue:)
                   withObject:@"GoSearchResult"
                   afterDelay:0.1];
        }
        //[self performSegueWithIdentifier:@"GoSearchResult" sender:self];
    }else{
        Boolean DirectGo = NO;
        //Strange decode added one layer of key pair above each element
        NSMutableArray* aryRefine = [NSMutableArray arrayWithCapacity:0];
        if ([ary count]==1){
            aryRefine= ary;
        }else{
            for (int i =0;i<[ary count];i++){
                NSMutableDictionary* d =[ary objectForKey:[NSString
                                                  stringWithFormat:@"%d",i]];
                [aryRefine addObject:d];
            }
        }
        //Add Your Tab
        while ([aryRefine count]==1){
            //Get Inner
            NSMutableDictionary * dict1 = [aryRefine objectAtIndex:0];
            aryRefine = [NSMutableArray arrayWithCapacity:0];
            ary=[dict1 objectForKey:@"sub"];
            if (ary == [NSNull null]){
                //NSLog(@"Can Null");
                //Get ID directly
                DirectGo = YES;
                ChosenItemID =index;
                [PostMethodUse BeforeLoadingLayoutUse:YES];
                if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
                    currentLocation=nil;
                    tryoutcount=0;
                    SegueToGoNext=@"GoSearchResult";
                    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
                    [locationManager startUpdatingLocation];
                }else{
                    currentLocation=nil;
                    [self performSelector:@selector(delaySegue:)
                               withObject:@"GoSearchResult"
                               afterDelay:0.1];
                }
                //[self performSegueWithIdentifier:@"GoSearchResult" sender:self];
            }else{
                if ([ary count]==1){
                    aryRefine= ary;
                }else{
                    for (int i =0;i<[ary count];i++){
                        NSMutableDictionary* d =[ary objectForKey:[NSString
                                                               stringWithFormat:@"%d",i]];
                        [aryRefine addObject:d];
                    }
                }
            }
        }
        if (!DirectGo){
            //Add First Tab
            if ([CellArray count]==0){
                [self AddUpperItemWith:@"全部"];
                [DictionariesForCellArrayUse addObject:nowArrayLayer];
            }
            nowArrayLayer = aryRefine;
            [self AddUpperItemWith:dict[@"tn"]];
            [DictionariesForCellArrayUse addObject:nowArrayLayer];
        }
    }
    [self setLastOneUnClick];
    [self setUpNowScroll];
}

-(IBAction)GoLocationSearch:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoLocationSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        //Show No Location Pop up
        [PostMethodUse PopUpNeedGPSSettingInfoAlert];
    }
}



-(IBAction)CodeSerach:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoIDSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
               withObject:@"GoIDSearch"
               afterDelay:0.1];
    }
}


-(IBAction)AdvanceSerach:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoAdvSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
               withObject:@"GoAdvSearch"
               afterDelay:0.1];
    }
}





-(IBAction)TwoStringSearchClick:(id)sender
{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoQuickSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
               withObject:@"GoQuickSearch"
               afterDelay:0.1];
    }
    //[self performSegueWithIdentifier:@"GoQuickSearch" sender:self];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([[segue identifier] isEqualToString:@"GoSearchResult"]){
        NSMutableDictionary * dict = [nowArrayLayer objectAtIndex:ChosenItemID];
        SearchResultViewController* vc = segue.destinationViewController;
        [vc LoadSearchDT:[dict objectForKey:@"id"] AndLocation:currentLocation];
    }else if ([[segue identifier] isEqualToString:@"GoQuickSearch"]){
        SearchResultViewController* vc = segue.destinationViewController;
        [vc LoadSearchTwoStringsWithOne:[TextField text] andTwo:[TextField2 text] AndLocation:currentLocation];
    }else if([[segue identifier] isEqualToString:@"GoLocationSearch"]){
        SearchResultViewController* vc = segue.destinationViewController;
        [vc LoadSearchLocationLat:currentLocation];
    }else if([[segue identifier] isEqualToString:@"GoAdvSearch"]){
        AdvanceSearchViewController* vc = segue.destinationViewController;
        [vc StartNewSearch];
    }
}

-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
        return;
    }
    
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
//    btn.accessibilityLabel = [@"語音輸入餐廳或菜式" stringByAppendingFormat:@"，%@",TextField.text];
//    btn2.accessibilityLabel = [@"語音輸入地區或地址" stringByAppendingFormat:@"，%@",TextField2.text];
    return YES;
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}

#pragma mark - LayoutRelated
-(void) resetClickablesFontSize{
    for (int i =0;i<[CellArray count];i++){
        UIView * baseview =[CellArray objectAtIndex:i];
        UIButton* button = [baseview.subviews objectAtIndex:0];
        [button.titleLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    }
    for (int i = 0;i<[ScrollArray count];i++){
        TabItemArrow* tia =[ScrollArray objectAtIndex:i];
        [tia setFontSize:fUse];
    }
}


#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        
        
        [MidLabel1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeH]];
        [MidLabel2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeH]];
        [MidLabel3 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeH]];
        [Field1 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [((TMDInputField*)Field1) setBackSet:fontSizeS];
        [((TMDInputField*)Field2) setBackSet:fontSizeS];
        [menuClaimNotUpdate setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize*0.8]];
        
        [self resetClickablesFontSize];
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
        //collectionview
        
        //NSLog(@"C%g + %g",collectview.contentSize.width,collectview.contentSize.height);
        //[collectview setNeedsLayout];
        //[collectview layoutIfNeeded];
        //collectview.contentSize = collectview.collectionViewLayout.collectionViewContentSize;
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //NSLog(@"%g + %g",myScroll.bounds.size.height,ScrollTab.bounds.size.height);
    [myScroll setContentSize:myViewPanel.bounds.size];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    [locationManager stopUpdatingLocation];
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [UpperBasement setBackgroundColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [MiddleBasement setBackgroundColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.view setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];        //Image
        [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        [btn3 setImage:[UIImage imageNamed:@"btn_search_grey.png"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateHighlighted];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateHighlighted];
        [btn3 setImage:[UIImage imageNamed:@"btn_search_grey.png"] forState:UIControlStateHighlighted];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [UpperBasement setBackgroundColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [MiddleBasement setBackgroundColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.view setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        //Image
        [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        [btn3 setImage:[UIImage imageNamed:@"btn_search.png"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateHighlighted];
        [btn2 setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateHighlighted];
        [btn3 setImage:[UIImage imageNamed:@"btn_search.png"] forState:UIControlStateHighlighted];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

#pragma mark - SpeechToTextModuleDelegate
- (BOOL)didReceiveVoiceResponse:(NSDictionary *)data {
    
    //NSLog(@"data %@",data);
    [self stopRecording];
    NSString *result = @"";
    id tmp = data[@"transcript"];
    if ([tmp isKindOfClass:[NSNumber class]] || [tmp rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location == NSNotFound) {
        // Spell out number
        // incase user spell number
        NSNumber *resultNumber = @([tmp integerValue]);
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        result = [formatter stringFromNumber:resultNumber];
    } else {
        result = tmp;
    }
    [self removetheLoading];
    if (fieldNowIn==0){
        TextField.text = result;
        //btn.accessibilityLabel = [@"語音輸入餐廳或菜式" stringByAppendingFormat:@"，%@",TextField.text];
        //UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, TextField);
    }else if (fieldNowIn==1){
        TextField2.text = result;
        //btn2.accessibilityLabel = [@"語音輸入地區或地址" stringByAppendingFormat:@"，%@",TextField2.text];
        //UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, TextField2);
    }
    return YES;
}

- (void)requestFailedWithError:(NSError *)error {
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (speechToTextModule) {
        [self stopRecording];
        speechToTextModule = nil;
    }
}


#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //    NSLog(@"didFailWithError: %@", error);
    //    UIAlertView *errorAlert = [[UIAlertView alloc]
    //                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //    [errorAlert show];
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount=-100;
        if ([SegueToGoNext isEqualToString:@"GoLocationSearch"]){
            [PostMethodUse AfterLoadingLayoutUse];
            [locationManager stopUpdatingLocation];
            [PostMethodUse PopUpNoLocationInfoAlert];
        }else{
            [locationManager stopUpdatingLocation];
            [self performSelector:@selector(delaySegue:)
                  withObject:SegueToGoNext
                  afterDelay:0.1];
        }
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if (tryoutcount>=0){
        tryoutcount =-100;
        [locationManager stopUpdatingLocation];
        //NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}



//#pragma UITableViewRelated
//-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return 20;
//}
//
//-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
//    
//    UITableViewCell* cell = [tbView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
//    
//    [cell setTranslatesAutoresizingMaskIntoConstraints:NO];
//    
//    
//    RestaurantItem *item = [[RestaurantItem alloc] init];
//    [cell.contentView addSubview:item];
//    [cell.contentView addConstraints:item.constraints];
//    NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
//    [cell.contentView addConstraint:topCon];
//    [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
//    [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
//    [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
//    [item setTranslatesAutoresizingMaskIntoConstraints:NO];
//    
//    
////    item.layer.shadowColor = [UIColor grayColor].CGColor;
////    item.layer.shadowOffset = CGSizeMake(1, 2);
////    item.layer.shadowOpacity = 0.5;
////    item.layer.shadowRadius=1.0;
//    [item.RestaurantName setText:[NSString stringWithFormat:@"Rest%ld",indexPath.row]];
//    [item.RestaurantName setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
//    
//    item.detailBtnHeight.constant = fSUse+16;
//    [cell.contentView setNeedsLayout];
//    [cell.contentView layoutIfNeeded];
//        
//    return cell;
//}


//#pragma mark -- UICollectionViewDataSource
//-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
//{
//    return 3;
//}
//
//-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
//{
//    return 1;
//}
//
//-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    //if (indexPath.row ==4) return nil;
//    static NSString * CellIdentifier = @"CollectionCell";
//    CollectionCell * cell = (CollectionCell*)[collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
//    //cell.translatesAutoresizingMaskIntoConstraints = NO;
//    [self.view addConstraints:cell.constraints];
//    NSLog(@"LongerLonger%ld",(long)indexPath.row);
//    [cell.CataTitle.titleLabel setText:[NSString stringWithFormat:@"LongerLonger%ld",(long)indexPath.row]];
//    [cell.CataTitle.titleLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
//    return cell;
//}
//
//#pragma mark --UICollectionViewDelegate
//-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    UICollectionViewCell * cell = (UICollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
//    cell.backgroundColor = [UIColor whiteColor];
//}
//
//-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    return NO;
//}

@end
