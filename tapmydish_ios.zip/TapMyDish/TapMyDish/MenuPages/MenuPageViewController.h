//
//  MenuPageViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface MenuPageViewController : UIViewController<UITabBarDelegate, UITextFieldDelegate,CLLocationManagerDelegate>


@end
