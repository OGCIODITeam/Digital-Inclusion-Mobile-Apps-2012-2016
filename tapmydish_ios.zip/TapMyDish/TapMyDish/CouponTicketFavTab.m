//
//  CouponTicketFavTab.m
//  TapMyDish
//
//  Created by BDMacMini1 on 23/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "CouponTicketFavTab.h"

#import "StringUnity.h"

@implementation CouponTicketFavTab

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    }
    return self;
}


-(void) setFontSize:(CGFloat)FS{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults]boolForKey:@"TapMyDishColorStyleIsGrey"];
    _CouponIconHeight.constant = FS;
    _AboutIconHeight.constant = FS;
    [_TitleHeight setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS*1.2]];
    [_TitleLabel setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:FS*1.2]];
    [_RestaurantLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_AboutHeight setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    [_AboutLabel setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
    if (isNoColor){
        if (_DoneCollectBase!=nil){
            [_DoneCollectBase setBackgroundColor:[UIColor grayColor]];
        }
        [_TitleLabel setTextColor:[UIColor blackColor]];
        [_RestaurantLabel setTextColor:[UIColor blackColor]];
        [_CouponIcon setImage:[UIImage imageNamed:@"icon_search_1_grey@3x.png"]];
        [_AboutIcon setImage:[UIImage imageNamed:@"icon_search_2_grey@3x.png"]];
    }else{
        if (_DoneCollectBase!=nil){
            [_DoneCollectBase setBackgroundColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        }
        [_TitleLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [_RestaurantLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [_CouponIcon setImage:[UIImage imageNamed:@"icon_search_1@3x.png"]];
        [_AboutIcon setImage:[UIImage imageNamed:@"icon_search_2@3x.png"]];
    }
}

-(void) setTitle:(NSString*) TitleText AndRestaurant:(NSString*) RestaurantText AndContant:(NSString*) ContentText AndGetOutdated:(BOOL)Outdated{
    [_TitleLabel setText:TitleText];
    [_RestaurantLabel setText:RestaurantText];
    [_AboutLabel setText:ContentText];
    NSString* read = @"";
    read = [read stringByAppendingString:[StringUnity ReadWordRefinement:TitleText]];
    read = [read stringByAppendingString:@"，"];
    read = [read stringByAppendingString:[StringUnity ReadWordRefinement:RestaurantText]];
    if (!Outdated){
        [_DoneCollectBase removeFromSuperview];
        _DoneCollectBase = nil;
    }else{
        read = [read stringByAppendingString:@"，"];
        read = [read stringByAppendingString:@"已過期"];
    }
    read = [read stringByAppendingString:@"，"];
    read = [read stringByAppendingString:[StringUnity ReadWordRefinement:ContentText]];
    [_ButtonTypeOn setAccessibilityLabel:read];
    //[_ButtonTypeOn setAccessibilityTraits:UIAccessibilityTraitHeader|UIAccessibilityTraitButton];
}

@end
