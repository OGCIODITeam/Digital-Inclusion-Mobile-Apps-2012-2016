//
//  RecordingPlane.h
//  TapMyDish
//
//  Created by BDMacMini1 on 29/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordingPlane : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UIButton *ClickRecButton;

@end
