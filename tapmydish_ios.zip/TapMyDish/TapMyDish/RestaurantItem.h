//
//  ResturantItem.h
//  TapMyDish
//
//  Created by BDMacMini1 on 4/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RestaurantItem : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UILabel *RestaurantName;
@property (weak, nonatomic) IBOutlet UIImageView *RestaurantOutLook;
@property (weak, nonatomic) IBOutlet UIView *MyDetailList;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *detailBtnHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *RestaurantNameHeight;
@property (weak, nonatomic) IBOutlet UILabel *DetailLabel;

@property (weak, nonatomic) IBOutlet UIButton *DetailBtn;
@property (weak, nonatomic) IBOutlet UIImageView *DetailBtnPic;
-(void) setFontSizeBig:(CGFloat)FS andSmall:(CGFloat)FSS;


@end
