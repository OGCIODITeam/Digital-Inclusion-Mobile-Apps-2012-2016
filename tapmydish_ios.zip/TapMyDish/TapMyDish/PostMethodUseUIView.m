//
//  PostMethodUseUIView.m
//  TapMyDish
//
//  Created by BDMacMini1 on 24/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//


#import "PostMethodUseUIView.h"
#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>

@interface PostMethodUseUIView (){
    BOOL BeforeVoiceOut;
    BOOL NeedVoiceOut;
}
@end

@implementation PostMethodUseUIView


-(void) setBeforeVoiceOut:(BOOL)bvo{
    BeforeVoiceOut = bvo;
}

-(BOOL) getBeforeVoiceOut{
    return BeforeVoiceOut;
}

- (void)didFinishAnnouncement:(NSNotification *)dict
{
    NSString *valueSpoken = [[dict userInfo] objectForKey:UIAccessibilityAnnouncementKeyStringValue];
    if ([valueSpoken isEqualToString:@"請稍候"]){
        NSNumber *wasSuccessful = [[dict userInfo] objectForKey:UIAccessibilityAnnouncementKeyWasSuccessful];
        BeforeVoiceOut = [wasSuccessful boolValue];
        if (!BeforeVoiceOut){
            //NSLog(@"Deadloop%@",valueSpoken);
            UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"請稍候");
        }
    }else{
        //NSLog(@"%@",valueSpoken);
    }
}

-(void) setNeedVoiceOut:(BOOL)bvo{
    NeedVoiceOut = bvo;
}

- (void)accessibilityElementDidBecomeFocused{
//    if (NeedVoiceOut){
//        UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"請稍候");
//        NeedVoiceOut=NO;
//    }
}
@end
