//
//  FirstViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 9/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "FirstViewController.h"
#import "RestaurantItem.h"
#import "RestaurantBulletPoint.h"
@import UIKit;

@interface FirstViewController ()<UITableViewDataSource, UITableViewDelegate>{
    __weak IBOutlet UIScrollView *btn3;
    __weak IBOutlet UINavigationItem *NItem;
    __weak IBOutlet NSLayoutConstraint *TargetSee;
    __weak IBOutlet RestaurantItem* objNeed;
    __weak IBOutlet UITableView* tbView;
}


@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //NSLog(@"%g + %g",btn3.contentSize.width,btn3.contentSize.height);
    [btn3 setContentSize:CGSizeMake(400, 1000)];
    //NSLog(@"%g + %g",btn3.contentSize.width,btn3.contentSize.height);
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self
               action:@selector(aMethod:)
     forControlEvents:UIControlEventTouchUpInside];
    UIImage *buttonImageNormal = [UIImage imageNamed:@"QRScan.png"];
    UIImage *buttonImagePressed = [UIImage imageNamed:@"menu.png"];
    [button setBackgroundImage:buttonImageNormal forState:UIControlStateNormal];
    [button setBackgroundImage:buttonImagePressed forState:UIControlStateHighlighted];
    [button setTitle:@"Show View" forState:UIControlStateNormal];
    button.frame = CGRectMake(80.0, 210.0, 160.0, 160.0);
    [self.view addSubview:button];
    //CGRect someRect = CGRectMake(80.0, 420.0, 100.0, 50.0);
    //UITextField* TField = [[UITextField alloc] initWithFrame:someRect];
    //[TField setBorderStyle:UITextBorderStyleRoundedRect];
    //[TField setText:@"Hello"];
    //[self.view addSubview:TField];
    //[TField setDelegate:self];
    
    
    
    
    //
    //NSLog(@"%@", [NItem backBarButtonItem]);
    UIBarButtonItem* me = [[UIBarButtonItem alloc] initWithTitle:@"Hello" style:UIBarButtonItemStylePlain target:self action:@selector(meUse)];
    NItem.leftBarButtonItem = me;
    //NSLog(@"%@", [NItem backBarButtonItem]);
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
//    [theController addChildViewController:self];
    //[theController view]
//    RestaurantItem *item = [[RestaurantItem alloc] initWithFrame:CGRectMake(0, 0, 200, 100)];
//    [self.view addSubview:item];
//    NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
//    [self.view addConstraint:topCon];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
//    
//    [item setTranslatesAutoresizingMaskIntoConstraints:NO];
//    [self.view addConstraints:item.constraints];
//    item.layer.shadowColor = [UIColor grayColor].CGColor;
//    item.layer.shadowOffset = CGSizeMake(1, 2);
//    item.layer.shadowOpacity = 0.5;
//    item.layer.shadowRadius=1.0;
//    
//    
//    RestaurantBulletPoint *BP1 = [[RestaurantBulletPoint alloc] init];
//    [item.MyDetailList addSubview:BP1];
//    [self.view addConstraints:BP1.constraints];
//    
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeTrailing multiplier:1 constant:-8]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeBottom multiplier:1 constant:-8]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeLeading multiplier:1 constant:8]];
//    
//    [BP1.PointInfo setText:@"Hello"];
//    
//    
//
    [tbView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell"];
    tbView.delegate = self;
    tbView.dataSource = self;
    tbView.rowHeight = UITableViewAutomaticDimension;
    tbView.estimatedRowHeight = 200;
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(void) viewDidAppear:(BOOL)animated{
    //NSLog(@"%@", [NItem backBarButtonItem]);
    NItem.hidesBackButton = NO;
}


-(void)meUse{
    [self performSegueWithIdentifier:@"meUse" sender:self];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)aMethod:(id)sender{
    
}

- (void)addMyButton{    // Method for creating button, with background image and other properties
    
    UIButton *playButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    playButton.frame = CGRectMake(110.0, 360.0, 100.0, 30.0);
    [playButton setTitle:@"Play" forState:UIControlStateNormal];
    playButton.backgroundColor = [UIColor clearColor];
    [playButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal ];
    UIImage *buttonImageNormal = [UIImage imageNamed:@"blueButton.png"];
    UIImage *strechableButtonImageNormal = [buttonImageNormal stretchableImageWithLeftCapWidth:12 topCapHeight:0];
    [playButton setBackgroundImage:strechableButtonImageNormal forState:UIControlStateNormal];
    UIImage *buttonImagePressed = [UIImage imageNamed:@"whiteButton.png"];
    UIImage *strechableButtonImagePressed = [buttonImagePressed stretchableImageWithLeftCapWidth:12 topCapHeight:0];
    [playButton setBackgroundImage:strechableButtonImagePressed forState:UIControlStateHighlighted];
    [playButton addTarget:self action:@selector(aMethod:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:playButton];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void) dictationRecordingDidEnd {
    printf("dictationRecordingDidEnd\n");
}

#pragma UITableViewRelated
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    
    UITableViewCell* cell = [tbView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    [cell setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    RestaurantItem *item = [[RestaurantItem alloc] init];
    [cell.contentView addSubview:item];
    [cell.contentView addConstraints:item.constraints];
    NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
    [cell.contentView addConstraint:topCon];
    [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
    [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
    [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:item attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
    [item setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    item.layer.shadowColor = [UIColor grayColor].CGColor;
    item.layer.shadowOffset = CGSizeMake(1, 2);
    item.layer.shadowOpacity = 0.5;
    item.layer.shadowRadius=1.0;
    
    [cell.contentView setNeedsLayout];
    [cell.contentView layoutIfNeeded];
    //NSLog(@"%@",item);
    //NSLog(@"%@",cell.contentView);
    //NSLog(@"%@",cell);
    
//    RestaurantBulletPoint *BP1 = [[RestaurantBulletPoint alloc] init];
//    [item.MyDetailList addSubview:BP1];
//    [self.view addConstraints:BP1.constraints];
//    
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeTrailing multiplier:1 constant:-8]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeBottom multiplier:1 constant:-8]];
//    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:BP1 attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:item.MyDetailList  attribute:NSLayoutAttributeLeading multiplier:1 constant:8]];
//    
//    [BP1.PointInfo setText:@"Hello"];
    
    
    
    return cell;
}

@end
