//
//  PostMethodUse.m
//  TapMyDish
//
//  Created by BDMacMini1 on 7/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#define URL_POST @"http://tapmydish.hkbu.org.hk/GetValue.php"
//#define URL_POST @"http://tapmydish.bds.hk/dead.php"
#define URL2_POST @"http://tapmydish.hkbu.org.hk/SetValue.php"
#define URL_IMAGE @"http://tapmydish.hkbu.org.hk/"


#import "PostMethodUse.h"
#import "AppDelegate.h"
#import "PostMethodUseUIView.h"
#import <AVFoundation/AVFoundation.h>
#import "UpdateCallBackObject.h"





UIActivityIndicatorView *indicator;
AVSpeechSynthesizer *synthesizer;
PostMethodUseUIView* reading;
UpdateCallBackObject* updateCallbackObject;
BOOL isFavourite;

@implementation PostMethodUse

+(NSMutableDictionary*) PostMethodWithFunctionString:(NSString*)VarString{
    //NSLog(@"Post同步");
    
    //1 创建URL对象
    NSURL *url =[NSURL URLWithString:URL_POST];
    
    //2 创建请求对象
    NSMutableURLRequest *resuest =[NSMutableURLRequest requestWithURL:url];
    
    //2.1 创建请求方式
    [resuest setHTTPMethod:@"post"];//get可以省略 但是post必须要写
    
    //3 设置请求参数
    NSData *tempData = [VarString dataUsingEncoding:NSUTF8StringEncoding];
    [resuest setHTTPBody:tempData];//设置请求主体 外界看不见数据
    //4 创建响应对象
    NSURLResponse *response = nil;
    
    //5 创建连接对象
    NSError *error;
    NSData *data = [NSURLConnection sendSynchronousRequest:resuest returningResponse:&response error:&error];

    if (error){
        return nil;
    }else{
        NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        return dict;
    }
}

+(void) BeforeLoadingLayoutUse:(BOOL)needSound{
    [PostMethodUse AfterLoadingLayoutUse];
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
    if (reading==nil){
        reading = [[PostMethodUseUIView alloc] initWithFrame:CGRectMake(0.0, 0.0, currentWindow.frame.size.width, currentWindow.frame.size.height)];
        [[NSNotificationCenter defaultCenter]
         addObserver:reading
         selector:@selector(didFinishAnnouncement:)
         name:UIAccessibilityAnnouncementDidFinishNotification
         object:nil];
        [reading setAccessibilityLabel:@""];
        reading.accessibilityViewIsModal = YES;
        reading.isAccessibilityElement = YES;
        indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        indicator.isAccessibilityElement = NO;
        indicator.frame = CGRectMake(0.0, 0.0, currentWindow.frame.size.width, currentWindow.frame.size.height);
        [reading addSubview:indicator];
    }
    if (UIAccessibilityIsVoiceOverRunning() && needSound){
        [reading setBeforeVoiceOut:NO];
        UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, reading);
    }
    else{
        [reading setBeforeVoiceOut:YES];
    }
    //indicator.frame = CGRectMake(0.0, 0.0, 40, 40);
    reading.center = currentWindow.center;
    [currentWindow addSubview:reading];
    [currentWindow bringSubviewToFront:reading];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = TRUE;
    [indicator startAnimating];
    if (UIAccessibilityIsVoiceOverRunning() && needSound){
        UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"請稍候");
    }
    //if (UIAccessibilityIsVoiceOverRunning()){
        //[PostMethodUse duckOn];
        //synthesizer = [[AVSpeechSynthesizer alloc]init];
        //AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:@"請稍候"];
        //[synthesizer speakUtterance:utterance];
        //reading = [[UIView alloc]init];
        //[reading setIsAccessibilityElement:YES];
        //[reading setAccessibilityLabel:@"請稍候"];
        //[currentWindow.rootViewController.view addSubview:reading];
        
        //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, reading);
        //UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, reading);
        //UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"請稍候");
    //}
}
+(void) setBeforeVoiceOut:(BOOL)bvo{
    if (reading!=nil) [reading setBeforeVoiceOut:bvo];
}
+(BOOL) getBeforeVoiceOut{
    if (reading!=nil) return [reading getBeforeVoiceOut];
    return YES;
}

+(void) AfterLoadingLayoutUse{
    if (reading!=nil){
        [indicator stopAnimating];
        [UIApplication sharedApplication].networkActivityIndicatorVisible = FALSE;
        [reading removeFromSuperview];
//        if (reading!=nil){
//            [reading removeFromSuperview];
//            reading = nil;
////            [synthesizer stopSpeakingAtBoundary:AVSpeechBoundaryWord];
////            [PostMethodUse duckOff];
//        }
    }
}

+(void) setIsFavourite:(BOOL) fav{
    isFavourite = fav;
}

+(BOOL) IsUnderFavourite{
    return isFavourite;
}


+(UIImage*) ImageMethodWithNSURL:(NSString*) url{
    if([url isEqualToString:@""] || [url isEqualToString:@"gallery/shopPhoto/"] || [url isEqualToString:@"gallery/foodPic/"]){
        return [UIImage imageNamed:@"no_pic.png"];
    }
    if ([PostMethodUse connectedToInternet] && ![PostMethodUse IsUnderFavourite]){
        NSURL *myurl = [NSURL URLWithString:[[NSString stringWithFormat:@"%@%@",URL_IMAGE,url] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        NSData *data = [NSData dataWithContentsOfURL:myurl];
        if (data == nil){
            return [UIImage imageNamed:@"no_pic.png"];
        }
        UIImage* img = [UIImage imageWithData:data];
        //NSLog(@"Size%f,%f",img.size.width,img.size.height);
        dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            //Background Thread
            dispatch_async(dispatch_get_main_queue(), ^(void){
                AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
                NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
                
                NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
                NSEntityDescription *entity = [NSEntityDescription entityForName:@"ImageStored" inManagedObjectContext: managedObjectContext];
                [fetchRequest setEntity:entity];
                
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"path=%@", url];
                [fetchRequest setPredicate:predicate];
                NSError *error = nil;
                NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
                if (fetchedObjects == nil) {
                    NSLog(@"Fetch error, something's wrong. %@",error);
                }
                else{
                    if([fetchedObjects count]>0){
                        NSManagedObject* mo = [fetchedObjects objectAtIndex:0];
                        [mo setValue:data forKey:@"imgData"];
                    }else{
                        //NSLog(@"Nothing Left");
                        NSManagedObject *newImg = [NSEntityDescription
                                                   insertNewObjectForEntityForName:@"ImageStored"
                                                   inManagedObjectContext:managedObjectContext];
                        [newImg setValue:data forKey:@"imgData"];
                        [newImg setValue:url forKey:@"path"];
                    }
                    [appDelegate saveContext];
                }
            });
        });
        return [UIImage imageWithData:data];
    }else{
        AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
        
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"ImageStored" inManagedObjectContext: managedObjectContext];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"path=%@", url];
        [fetchRequest setPredicate:predicate];
        NSError *error = nil;
        NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
        if (fetchedObjects == nil) {
            NSLog(@"Fetch error, something's wrong. %@",error);
            return [UIImage imageNamed:@"no_pic.png"];
        }
        else{
            if([fetchedObjects count]>0){
                NSData* data = [[fetchedObjects objectAtIndex:0] valueForKey:@"imgData"];
                return [UIImage imageWithData:data];
            }else{
                //NSLog(@"Nothing Left");
                return [UIImage imageNamed:@"no_pic.png"];
            }
        }
    }
}

+(NSMutableDictionary*) PostSettingMethodWithFunctionString:(NSString*)VarString{
    //NSLog(@"Post同步");
    
    //1 创建URL对象
    NSURL *url =[NSURL URLWithString:URL2_POST];
    
    //2 创建请求对象
    NSMutableURLRequest *resuest =[NSMutableURLRequest requestWithURL:url];
    
    //2.1 创建请求方式
    [resuest setHTTPMethod:@"post"];//get可以省略 但是post必须要写
    
    //3 设置请求参数
    NSData *tempData = [VarString dataUsingEncoding:NSUTF8StringEncoding];
    [resuest setHTTPBody:tempData];//设置请求主体 外界看不见数据
    //4 创建响应对象
    NSURLResponse *response = nil;
    
    //5 创建连接对象
    NSError *error;
    NSData *data = [NSURLConnection sendSynchronousRequest:resuest returningResponse:&response error:&error];
    if (error){
        return nil;
    }else{
        NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        return dict;
    }
}

+ (BOOL)connectedToInternet
{
    NSString *urlString = @"http://www.google.com/";
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"HEAD"];
    NSHTTPURLResponse *response;
    
    [NSURLConnection sendSynchronousRequest:request returningResponse:&response error: NULL];
    
    return ([response statusCode] == 200) ? YES : NO;
}

+(void) PopUpNoInternetAlert{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@"錯誤"
                                    message:@"沒有網路連線"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"錯誤"
                                                        message:@"沒有網路連線"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}
+(void) PopUpNoLocationInfoAlert{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@"錯誤"
                                    message:@"找不到位置，請到訊號較強的地方使用"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"錯誤"
                                                        message:@"找不到位置，請到訊號較強的地方使用"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}
+(void) PopUpNeedGPSSettingInfoAlert{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@"開啟你的定位服務"
                                    message:@"請開啟你的定位服務以瀏覽附近餐廳！\n設定＞隱私＞定位服務＞開啟TapMyDish"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"開啟你的定位服務"
                                                        message:@"請開啟你的定位服務以瀏覽附近餐廳！\n設定＞隱私＞定位服務＞開啟TapMyDish"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

+(void) PopUpNoCoupon{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"沒有相關優惠。"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"沒有相關優惠。"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

+(void) PopUpNoEmail{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"請先設定電郵。"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"請先設定電郵。"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}


+(void) PopUpCancelledMyCoupon{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"已取消我的優惠。"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"已取消我的優惠。"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

+(void) PopUpAddedMyCoupon{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"已加入我的優惠。"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"已加入我的優惠。"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

+(void) PopUpCancelledMyFavourite{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"已取消我的最愛。"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"已取消我的最愛。"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

+(void) PopUpAddedMyFavourite{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"已加入我的最愛。"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"已加入我的最愛。"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}


+(void) PopUpWrongSchema{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@""
                                    message:@"錯誤連結"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"錯誤連結"
                                                       delegate:nil
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}


+(void) PopUpNeedUpdate{

    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0){
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@"軟體更新"
                                    message:@"有新版本可以下載"
                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"好" style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            NSString *iTunesLink = @"https://itunes.apple.com/us/app/dian-cai-yi/id1184274363?l=zh&ls=1&mt=8";
                                            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
                                        }];
        
        [alert addAction:defaultAction];
        UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
        [currentWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    }else{
        if (updateCallbackObject==nil){
            updateCallbackObject = [[UpdateCallBackObject alloc] init];
        }
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"軟體更新"
                                                        message:@"有新版本可以下載"
                                                       delegate:updateCallbackObject
                                              cancelButtonTitle:@"好"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

+ (BOOL)newVersionPresent {
    if(![PostMethodUse connectedToInternet]) return NO;
    // 1. Get bundle identifier
//    NSDictionary* infoDict = [[NSBundle mainBundle] infoDictionary];
//    NSString* appID = infoDict[@"CFBundleIdentifier"];
//    
//    // 2. Find version of app present at itunes store
//    NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"http://itunes.apple.com/lookup?bundleId=%@", appID]];
//    NSData* data = [NSData dataWithContentsOfURL:url];
//    NSDictionary* itunesVersionInfo = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
//    
//    // if app present
//    if ([itunesVersionInfo[@"resultCount"] integerValue] == 1){
//        NSString* appStoreVersion = itunesVersionInfo[@"results"][0][@"version"];
//        // 3. Find version of app currently running
//        NSString* currentVersion = infoDict[@"CFBundleShortVersionString"];
//        // 4. Compare both versions
//        if ([appStoreVersion compare:currentVersion options:NSNumericSearch] == NSOrderedDescending) {
//            // app needs to be updated
//            return YES;
//        }
    //    }
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    NSString *version = [info objectForKey:@"CFBundleShortVersionString"];
    NSString* str = [PostMethodUse PostMethodWithText:@"m=getVersionNo"];
    
    NSError *error = NULL;
    NSRegularExpression *regex =
    [NSRegularExpression regularExpressionWithPattern:@"\""
                                              options:0
                                                error:&error];
    str = [regex stringByReplacingMatchesInString:str options:0 range:NSMakeRange(0, [str length]) withTemplate:@""];
    NSArray* netOne = [str componentsSeparatedByString:@"."];
    NSArray* localOne = [version componentsSeparatedByString:@"."];
    for (int i = 0;i<netOne.count && i<localOne.count;i++){
        if ([[netOne objectAtIndex:i] integerValue]>[[localOne objectAtIndex:i] integerValue]){
            return YES;
        }
    }
    if (netOne.count>localOne.count) return YES;
    return NO;
}

+(NSString*) PostMethodWithText:(NSString*)VarString{
    //NSLog(@"Post同步");
    
    //1 创建URL对象
    NSURL *url =[NSURL URLWithString:URL_POST];
    
    //2 创建请求对象
    NSMutableURLRequest *resuest =[NSMutableURLRequest requestWithURL:url];
    
    //2.1 创建请求方式
    [resuest setHTTPMethod:@"post"];//get可以省略 但是post必须要写
    
    //3 设置请求参数
    NSData *tempData = [VarString dataUsingEncoding:NSUTF8StringEncoding];
    [resuest setHTTPBody:tempData];//设置请求主体 外界看不见数据
    //4 创建响应对象
    NSURLResponse *response = nil;
    
    //5 创建连接对象
    NSError *error;
    NSData *data = [NSURLConnection sendSynchronousRequest:resuest returningResponse:&response error:&error];
    
    if (error){
        return nil;
    }else{
        NSString *dict = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];;
        return dict;
    }
}




+ (void)duckOn {
    //NSLog(@"duck on");
    NSError *err;
    [[AVAudioSession sharedInstance] setActive:NO error:&err];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionDuckOthers error:&err];
    [[AVAudioSession sharedInstance] setActive:YES error:&err];
}
+ (void)duckOff {
    //NSLog(@"duck off");
    NSError *err;
    [[AVAudioSession sharedInstance] setActive:NO error:&err];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:&err];
    [[AVAudioSession sharedInstance] setActive:YES error:&err];
}
@end
