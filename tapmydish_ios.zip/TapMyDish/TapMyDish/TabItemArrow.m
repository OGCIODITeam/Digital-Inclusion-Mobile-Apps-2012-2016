//
//  TabItemArrow.m
//  TapMyDish
//
//  Created by BDMacMini1 on 4/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "TabItemArrow.h"

@implementation TabItemArrow

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        [self addSubview:self.view];
        [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view]|" options:0 metrics:nil views:@{@"view":self.view}]];
        [self needsUpdateConstraints];
    }
    return self;
}

-(void) setFontSize:(CGFloat)FS{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (!isNoColor) [_ArrowImage setImage:[UIImage imageNamed:@"arrow_right@3x.png"]];
    else  [_ArrowImage setImage:[UIImage imageNamed:@"arrow_right_grey@3x.png"]];
    _ArrowImageHeight.constant = FS;
    [_LabelTitle setFont:[UIFont fontWithName:@"Heiti TC" size:FS]];
}

-(void) setLabelText:(NSString*) theLabel{
    [_LabelTitle setText:[theLabel stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
    [_LabelButtonForClick setAccessibilityLabel:[theLabel stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
}

@end
