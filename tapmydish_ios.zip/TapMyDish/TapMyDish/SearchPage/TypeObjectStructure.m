//
//  TypeObjectStructure.m
//  TapMyDish
//
//  Created by BDMacMini1 on 17/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "TypeObjectStructure.h"
@interface TypeObjectStructure (){
    TypeObjectStructure * myParent;
    NSMutableArray* myChildren;
    NSString* myid;
    NSString* myname;
    BOOL meValueOnlyWhenChildrenZero;
}
@end


@implementation TypeObjectStructure

-(BOOL) IamClicked{
    if (myChildren==nil || [myChildren count]==0){
        return meValueOnlyWhenChildrenZero;
    }else{
        BOOL Clicked = YES;
        for (TypeObjectStructure*  child in myChildren){
            if (![[child returnID] isEqualToString:myid]){
                Clicked = Clicked && [child IamClicked];
            }else if ([myChildren count]==1){
                Clicked = Clicked && [child IamClicked];
            }
        }
        //Reset The My Instance
        for (TypeObjectStructure*  child in myChildren){
            if ([[child returnID] isEqualToString:myid]){
                [child ClickedMeFromHighestOrder:Clicked];
            }
        }
        return Clicked;
    }
}


-(void) ClickedMe:(BOOL)value{
    if (myParent!=nil){
        if ([[myParent returnID] isEqualToString:myid]){
            [myParent ClickedMe:value];
            return;
        }
    }
    [self ClickedMeFromHighestOrder:value];
}

-(void) ClickedMeFromHighestOrder:(BOOL)value{
    if (myChildren==nil || [myChildren count]==0 ){
        meValueOnlyWhenChildrenZero = value;
    }else{
        for (TypeObjectStructure*  child in myChildren){
            [child ClickedMeFromHighestOrder:value];
        }
    }
}

-(void) SetUpName:(NSString*)name AndID:(NSString*)idd{
    myid = idd;
    myname = name;
}

-(void) AddChildren:(TypeObjectStructure*) child{
    if (myChildren== nil)
    {
        myChildren = [NSMutableArray arrayWithCapacity:0];
    }
    [myChildren addObject:child];
    [child SetParent:self];
}

-(void)SetParent:(TypeObjectStructure*)par{
    myParent =par;
}


-(NSString*) returnName{
    return myname;
}

-(NSString*) returnID{
    return myid;
}

-(TypeObjectStructure*) GetChildByIndex:(NSInteger) index{
    if (myChildren == nil|| [myChildren count]==0){
        return nil;
    }
    return [myChildren objectAtIndex:index];
}

-(TypeObjectStructure*)GetParent{
    return myParent;
}


-(NSMutableArray*)GetChildren{
    return myChildren;
}

-(NSInteger) GetIndexOfChild:(TypeObjectStructure*) child{
    if (myChildren == nil|| [myChildren count]==0){
        return -1;
    }
    return [myChildren indexOfObject:child];
}
@end
