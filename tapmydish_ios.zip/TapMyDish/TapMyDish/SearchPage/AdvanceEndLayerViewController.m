//
//  AdvanceEndLayerViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 17/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "AdvanceEndLayerViewController.h"
#import "TabItemTick.h"
#import "StringUnity.h"
#import "PostMethodUse.h"
#import "UIImage_withColor.h"

@interface AdvanceEndLayerViewController () {
    BOOL isRecording;
    __weak IBOutlet UITabBar* tabBar;
    
    __weak IBOutlet UIScrollView *myScroll;
    __weak IBOutlet UIView *myViewPanel;
    
    __weak IBOutlet UIView* UpperBase;
    
    __weak IBOutlet UINavigationItem* NavItem;
    
    CGFloat fUse;
    CGFloat fSUse;
    
    int SearchType; // 0 shop 1 dist 2 dishes
    TypeObjectStructure* superObject;
    
    NSInteger indexUse;
}

@end

@implementation AdvanceEndLayerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UpperBase.layer.shadowColor = [UIColor grayColor].CGColor;
    UpperBase.layer.shadowOffset = CGSizeMake(1, 2);
    UpperBase.layer.shadowOpacity = 0.5;
    UpperBase.layer.shadowRadius=1.0;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}






-(void) viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    [self setTabBarOutLook];
    [self setFontSizes];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}


- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    
    [super viewWillDisappear:animated];
}



-(void) LoadSuper:(TypeObjectStructure*)superobject AndSearchType:(int) type{
    SearchType = type;
    superObject = superobject;
}




-(void)resetLayout{
    [NavItem setTitle:[superObject returnName]];
    while ([UpperBase.subviews count]>0){
        [[UpperBase.subviews objectAtIndex:0] removeFromSuperview];
    }
    UIView* LastView = UpperBase;
    for (TypeObjectStructure* dict in [superObject GetChildren])
    {
        NSString* tn = [dict returnName];
        TabItemTick* arrow = [[TabItemTick alloc] initWithFrame:CGRectZero];
        [arrow setLabelText:[StringUnity RefinedString:tn]];
        [arrow setFontSize:fUse];
        
        [arrow.LabelButtonForClick setTag:[superObject GetIndexOfChild:dict]];
        [arrow.LabelButtonForClick addTarget:self action:@selector(ClickedTickItem:) forControlEvents:(UIControlEventTouchUpInside)];
        //Tick Is On Or Not
        if ([[dict returnID] isEqualToString:[superObject returnID]]){
            //Use parent
            [arrow setLabelOn:[superObject IamClicked]];
        }else{
            [arrow setLabelOn:[dict IamClicked]];
        }
        //
        [UpperBase addSubview:arrow];
        //Position
        [UpperBase addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:UpperBase attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        [UpperBase addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:UpperBase attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
        if (LastView == UpperBase){
            [UpperBase addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:UpperBase attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        }else{
            [UpperBase addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:LastView attribute:NSLayoutAttributeBottom multiplier:1 constant:1]];
        }
        //finally
        arrow.translatesAutoresizingMaskIntoConstraints = NO;
        LastView = arrow;
        
    }
    [UpperBase addConstraint:[NSLayoutConstraint constraintWithItem:LastView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationLessThanOrEqual toItem:UpperBase attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
}


-(void)ClickedTickItem:(id)sender{
    [PostMethodUse BeforeLoadingLayoutUse:NO];
    TypeObjectStructure* dict = [superObject GetChildByIndex:((UIButton*)sender).tag];
    NSString* idd = [dict returnID];
    if ([idd isEqualToString:[superObject returnID]]){
        // Trouble, actually clicking superObject
        if ([superObject IamClicked]){
            [superObject ClickedMe:NO];
        }else{
            [superObject ClickedMe:YES];
        }
    }else{
        [dict ClickedMe:![dict IamClicked]];
    }
    [self resetLayout];
    [PostMethodUse AfterLoadingLayoutUse];
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
}


-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([identifier isEqualToString:@"GoToAdvanceEnd"]){
        if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
            return;
        }
    }
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}


-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}


#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [self resetLayout];
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //[myScroll setContentSize:myViewPanel.bounds.size];
}





#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
         [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}




@end
