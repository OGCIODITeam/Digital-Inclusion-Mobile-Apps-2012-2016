//
//  TypeObjectStructure.h
//  TapMyDish
//
//  Created by BDMacMini1 on 17/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef TOS
#define TOS 123

@interface TypeObjectStructure : NSObject


-(BOOL) IamClicked;
-(void) ClickedMe:(BOOL)value;
-(void) SetUpName:(NSString*)name AndID:(NSString*)idd;
-(void) AddChildren:(TypeObjectStructure*) child;
-(NSString*) returnName;
-(NSString*) returnID;
-(TypeObjectStructure*) GetChildByIndex:(NSInteger) index;
-(TypeObjectStructure*)GetParent;
-(NSMutableArray*) GetChildren;
-(NSInteger) GetIndexOfChild:(TypeObjectStructure*) child;
@end

#endif
