//
//  AdvanceEndLayerViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 17/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TypeObjectStructure.h"

@interface AdvanceEndLayerViewController : UIViewController<UITabBarDelegate>

-(void) LoadSuper:(TypeObjectStructure*)superobject AndSearchType:(int) type;

@end
