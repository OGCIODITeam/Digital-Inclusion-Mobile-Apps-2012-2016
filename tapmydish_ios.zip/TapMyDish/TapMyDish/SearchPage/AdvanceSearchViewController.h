//
//  AdvanceSearchViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 9/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AdvanceSearchViewController : UIViewController<UITabBarDelegate,
UITextFieldDelegate,
CLLocationManagerDelegate>

-(void) StartNewSearch;

@end
