//
//  AdvanceSearchVariable.h
//  TapMyDish
//
//  Created by BDMacMini1 on 16/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TypeObjectStructure.h"


@interface AdvanceSearchVariable : NSObject

+ (AdvanceSearchVariable *)sharedInstance;


-(TypeObjectStructure*) returnShopTypesSuper;
-(TypeObjectStructure*) returnDistsSuper;
-(TypeObjectStructure*) returnDishesSuper;


-(void)resetEmptyWithShopeType:(NSMutableArray*) shoptype AndDist:(NSMutableArray*)dist AndDish:(NSMutableArray*)dish;

-(BOOL) returnHaveTakenAway;
-(NSString*) returnShopName;
-(NSString*) returnShopTypes;
-(NSString*) returnDists;
-(NSString*) returnDishes;

-(NSString*) returnShopTypesIDs;
-(NSString*) returnDistsIDs;
-(NSString*) returnDishesIDs;
-(NSString*) returnShopNameIDs;
-(NSString*) returnHaveTakeAwayIDs;

-(void) setHaveTakeAway:(NSString*)haveTakeAway;
-(void) setShopName:(NSString*)shopName;

@end
