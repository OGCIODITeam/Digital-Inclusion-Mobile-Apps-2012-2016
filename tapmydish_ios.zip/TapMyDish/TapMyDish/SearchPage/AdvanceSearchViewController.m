//
//  AdvanceSearchViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 9/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "AdvanceSearchViewController.h"

#import "SearchResultViewController.h"
#import "SpeechToTextModule.h"
#import "PostMethodUse.h"
#import "AdvanceSearchVariable.h"
#import "AdvanceEndLayerViewController.h"
#import "AdvanceMidLayerViewController.h"
#import "RecordingPlane.h"
#import "UIImage_withColor.h"
#import "StringUnity.h"

@interface AdvanceSearchViewController ()<SpeechToTextModuleDelegate>  {
    SpeechToTextModule *speechToTextModule;
    BOOL isRecording;
    __weak IBOutlet UITabBar* tabBar;
    
    __weak IBOutlet UIScrollView *myScroll;
    __weak IBOutlet UIView *myViewPanel;
    
    //Upper Part
    __weak IBOutlet UIView* UpperBase;
    
    __weak IBOutlet UILabel* UpperTitle;
    __weak IBOutlet UIImageView* UpperIcon;
    __weak IBOutlet NSLayoutConstraint* UpperIconHeight;
    
    __weak IBOutlet UILabel* UpperSlot1Title;
    __weak IBOutlet UIImageView* UpperSlot1RightArrow;
    __weak IBOutlet NSLayoutConstraint* UpperSlot1RightArrowheight;
    __weak IBOutlet UILabel* UpperSlot1Describe;
    __weak IBOutlet UIButton* UpperSlot1Btn;
    
    __weak IBOutlet UILabel* UpperSlot2Title;
    __weak IBOutlet UIImageView* UpperSlot2RightArrow;
    __weak IBOutlet NSLayoutConstraint* UpperSlot2RightArrowheight;
    __weak IBOutlet UILabel* UpperSlot2Describe;
    __weak IBOutlet UIButton* UpperSlot2Btn;
    
    __weak IBOutlet UILabel* UpperSlot3Title;
    __weak IBOutlet UIImageView* UpperSlot3RightArrow;
    __weak IBOutlet NSLayoutConstraint* UpperSlot3RightArrowheight;
    __weak IBOutlet UILabel* UpperSlot3Describe;
    __weak IBOutlet UIButton* UpperSlot3Btn;
    
    
    //Mid Part
    __weak IBOutlet UIView* MidBase;
    
    __weak IBOutlet UILabel* MidTitle;
    __weak IBOutlet UIImageView* MidIcon;
    __weak IBOutlet NSLayoutConstraint* MidIconHeight;
    
    __weak IBOutlet UILabel* MidSlot1Title;
    __weak IBOutlet UIImageView* MidSlot1RightArrow;
    __weak IBOutlet NSLayoutConstraint* MidSlot1RightArrowheight;
    __weak IBOutlet UILabel* MidSlot1Describe;
    __weak IBOutlet UIButton* MidSlot1Btn;
    
    //Low Part
    __weak IBOutlet UIView* LowBase;
    
    __weak IBOutlet UILabel* LowTitle;
    __weak IBOutlet UIImageView* LowIcon;
    __weak IBOutlet NSLayoutConstraint* LowIconHeight;
    
    
    __weak IBOutlet UIButton* btn;
    __weak IBOutlet UITextField* TextField;
    __weak IBOutlet NSLayoutConstraint* btnSize;
    __weak IBOutlet UIImageView* searchBase;
    
    //Last
    __weak IBOutlet UILabel* searchLabel;
    
    CGFloat fUse;
    CGFloat fSUse;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    int tryoutcount;
    NSString* SegueToGoNext;
    
    
    //Logic
    NSMutableArray* QueryDishes;
    NSMutableArray* QueryDists;
    NSMutableArray* QueryShopTypes;
    
    int SearchType; // 0 shop 1 dist 2 dishes
    
    RecordingPlane* rp;
    UIView* rl;
    UIActivityIndicatorView* indicator;
    __weak IBOutlet NSLayoutConstraint* KeyboardConstraint;
    __weak IBOutlet UINavigationItem* NavItem;
}
@end

@implementation AdvanceSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [btn setHidden:YES];
    speechToTextModule = [[SpeechToTextModule alloc] initWithCustomDisplay:nil];
    speechToTextModule.delegate = self;
    [speechToTextModule duckOff];
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    // Do any additional setup after loading the view.
    UpperBase.layer.shadowColor = [UIColor grayColor].CGColor;
    UpperBase.layer.shadowOffset = CGSizeMake(1, 2);
    UpperBase.layer.shadowOpacity = 0.5;
    UpperBase.layer.shadowRadius=1.0;

    MidBase.layer.shadowColor = [UIColor grayColor].CGColor;
    MidBase.layer.shadowOffset = CGSizeMake(1, 2);
    MidBase.layer.shadowOpacity = 0.5;
    MidBase.layer.shadowRadius=1.0;

    LowBase.layer.shadowColor = [UIColor grayColor].CGColor;
    LowBase.layer.shadowOffset = CGSizeMake(1, 2);
    LowBase.layer.shadowOpacity = 0.5;
    LowBase.layer.shadowRadius=1.0;

    TextField.delegate = self;
    
    btn.accessibilityLabel = @"語音輸入餐廳名稱";
    [[NavItem rightBarButtonItem] setAccessibilityLabel:@"清除已選擇"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - Logic

-(IBAction)ClickedResetAll:(id)sender{
    [self StartNewSearch];
    TextField.text=@"";
    [self resetLayout];
}

-(void) StartNewSearch{
    NSMutableDictionary* LoadDish = [PostMethodUse PostMethodWithFunctionString:@"m=menu_forSearch&only=dish"];
    if (LoadDish!=nil){
        QueryDishes=[NSMutableArray arrayWithCapacity:0];
        NSMutableDictionary* dictdict = [LoadDish objectForKey:@"dishType"];
        for (NSString* key in dictdict){
            [QueryDishes addObject:[dictdict objectForKey:key]];
        }
    }else{
        QueryDishes = [NSMutableArray arrayWithCapacity:0];
    }
    
    NSMutableDictionary* LoadDist = [PostMethodUse PostMethodWithFunctionString:@"m=menu_forSearch&only=dist"];
    if (LoadDish!=nil){
        QueryDists = [LoadDist objectForKey:@"dist"];
    }else{
        QueryDists = [NSMutableArray arrayWithCapacity:0];
    }
    
    NSMutableDictionary* LoadShop = [PostMethodUse PostMethodWithFunctionString:@"m=menu_forSearch&only=shop"];
    if (LoadDish!=nil){
        QueryShopTypes = [LoadShop objectForKey:@"shopType"];
    }else{
        QueryShopTypes = [NSMutableArray arrayWithCapacity:0];
    }
    [[AdvanceSearchVariable sharedInstance] resetEmptyWithShopeType:QueryShopTypes AndDist:QueryDists AndDish:QueryDishes];
}

-(IBAction)ClickedShopType:(id)sender{
    SearchType=0;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToAdvanceMid"
               afterDelay:0.1];
}

-(IBAction)ClickedDist:(id)sender{
    SearchType=1;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToAdvanceMid"
               afterDelay:0.1];
}

-(IBAction)ClickedDish:(id)sender{
    SearchType=2;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToAdvanceMid"
               afterDelay:0.1];
}

-(IBAction)ClickedTakeAway:(id)sender{
    if (![[AdvanceSearchVariable sharedInstance] returnHaveTakenAway]){
        [[AdvanceSearchVariable sharedInstance] setHaveTakeAway:@"1"];
        MidSlot1Btn.accessibilityLabel = @"設有外賣 已選擇";
    }else{
        [[AdvanceSearchVariable sharedInstance] setHaveTakeAway:@"0"];
        MidSlot1Btn.accessibilityLabel = @"設有外賣";
    }
    [self resetLayout];
}

-(IBAction)ClickedSearch:(id)sender{
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        SegueToGoNext = @"GoToSearch";
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delaySegue:)
                   withObject:@"GoToSearch"
                   afterDelay:0.1];
    }
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([[segue identifier] isEqualToString:@"GoToSearch"]){
        SearchResultViewController* vc = segue.destinationViewController;
        NSString* query = @"";
        query = [query stringByAppendingString:[[AdvanceSearchVariable sharedInstance] returnShopNameIDs]];
        query = [query stringByAppendingString:[[AdvanceSearchVariable sharedInstance] returnHaveTakeAwayIDs]];
        query = [query stringByAppendingString:[[AdvanceSearchVariable sharedInstance] returnDistsIDs]];
        query = [query stringByAppendingString:[[AdvanceSearchVariable sharedInstance] returnDishesIDs]];
        query = [query stringByAppendingString:[[AdvanceSearchVariable sharedInstance] returnShopTypesIDs]];
        [vc LoadSearchAdvance:query AndLocation:currentLocation];
    }else if ([[segue identifier] isEqualToString:@"GoToAdvanceMid"]){
        AdvanceMidLayerViewController* vc = segue.destinationViewController;
        if (SearchType==0){
            [vc LoadSuper:[[AdvanceSearchVariable sharedInstance] returnShopTypesSuper] AndSearchType:SearchType];
        }else if(SearchType==1){
            [vc LoadSuper:[[AdvanceSearchVariable sharedInstance] returnDistsSuper] AndSearchType:SearchType];
        }else if(SearchType==2){
            [vc LoadSuper:[[AdvanceSearchVariable sharedInstance] returnDishesSuper] AndSearchType:SearchType];
        }
    }
}
-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([identifier isEqualToString:@"GoToSearch"]){
        if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
            return;
        }
    }
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}


-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void) viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    [self setTabBarOutLook];
    [self setFontSizes];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}


- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
}

-(void)keyboardWillShow:(NSNotification *)n{
    CGRect kb = [[[n userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    KeyboardConstraint.constant = kb.size.height+20;
}

-(void)keyboardWillHide:(NSNotification *)n {
    KeyboardConstraint.constant = -100000;
}


-(void)resetLayout{
    [UpperTitle setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fSUse]];
    [MidTitle setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fSUse]];
    [LowTitle setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fSUse]];
    UpperIconHeight.constant = fSUse;
    MidIconHeight.constant = fSUse;
    LowIconHeight.constant = fSUse;
    UIImage* tick;
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [UpperIcon setImage:[UIImage imageNamed:@"icon_search_1_grey@3x.png"]];
        [MidIcon setImage:[UIImage imageNamed:@"icon_search_2_grey@3x.png"]];
        [LowIcon setImage:[UIImage imageNamed:@"icon_search_3_grey@3x.png"]];
        [UpperSlot1RightArrow setImage:[UIImage imageNamed:@"arrow_right_grey@3x.png"]];
        [UpperSlot2RightArrow setImage:[UIImage imageNamed:@"arrow_right_grey@3x.png"]];
        [UpperSlot3RightArrow setImage:[UIImage imageNamed:@"arrow_right_grey@3x.png"]];
        [searchBase setImage:[UIImage imageNamed:@"btn_redbase_grey@3x.png"]];
        tick =[UIImage imageNamed:@"tick_grey@3x.png"];
        [UpperSlot1Describe setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [UpperSlot2Describe setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [UpperSlot3Describe setTextColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
    }else{
        [UpperIcon setImage:[UIImage imageNamed:@"icon_search_1@3x.png"]];
        [MidIcon setImage:[UIImage imageNamed:@"icon_search_2@3x.png"]];
        [LowIcon setImage:[UIImage imageNamed:@"icon_search_3@3x.png"]];
        [UpperSlot1RightArrow setImage:[UIImage imageNamed:@"arrow_right@3x.png"]];
        [UpperSlot2RightArrow setImage:[UIImage imageNamed:@"arrow_right@3x.png"]];
        [UpperSlot3RightArrow setImage:[UIImage imageNamed:@"arrow_right@3x.png"]];
        [searchBase setImage:[UIImage imageNamed:@"btn_redbase@3x.png"]];
        tick =[UIImage imageNamed:@"tick@3x.png"];
        [UpperSlot1Describe setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [UpperSlot2Describe setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [UpperSlot3Describe setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
    }
    UpperSlot1RightArrowheight.constant = fUse;
    UpperSlot2RightArrowheight.constant = fUse;
    UpperSlot3RightArrowheight.constant = fUse;
    MidSlot1RightArrowheight.constant = fUse;
    [UpperSlot1Title setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [UpperSlot2Title setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [UpperSlot3Title setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [MidSlot1Title setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [TextField setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
    btnSize.constant = fSUse+8;
    [UpperSlot1Describe setFont:[UIFont fontWithName:@"Heiti TC" size:fUse/2]];
    [UpperSlot2Describe setFont:[UIFont fontWithName:@"Heiti TC" size:fUse/2]];
    [UpperSlot3Describe setFont:[UIFont fontWithName:@"Heiti TC" size:fUse/2]];
    [MidSlot1Describe setFont:[UIFont fontWithName:@"Heiti TC" size:fUse/2]];
    //Data
    {
        NSString* str =[[AdvanceSearchVariable sharedInstance] returnShopTypes];
        [UpperSlot1Describe setText:str];
        [UpperSlot1Btn setAccessibilityLabel:[StringUnity ReadWordRefinement:[NSString stringWithFormat:@"餐廳類型．%@",str]]];
    }
    {
        NSString* str =[[AdvanceSearchVariable sharedInstance] returnDists];
        [UpperSlot2Describe setText:str];
        [UpperSlot2Btn setAccessibilityLabel:[StringUnity ReadWordRefinement:[NSString stringWithFormat:@"地區．%@",str]]];
    }
    {
        NSString* str =[[AdvanceSearchVariable sharedInstance] returnDishes];
        [UpperSlot3Describe setText:str];
        [UpperSlot3Btn setAccessibilityLabel:[StringUnity ReadWordRefinement:[NSString stringWithFormat:@"菜式．%@",str]]];
    }
    if ([[AdvanceSearchVariable sharedInstance] returnHaveTakenAway]){
        [MidSlot1RightArrow setImage:tick];
    }else{
        [MidSlot1RightArrow setImage:[UIImage imageNamed:@"empty.png"]];
    }
    TextField.text = [[AdvanceSearchVariable sharedInstance] returnShopName];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [AdvanceSearchVariable sharedInstance].ShopName = TextField.text;
    //btn.accessibilityLabel = [@"語音輸入餐廳名稱" stringByAppendingFormat:@"，%@",TextField.text];
    // submit now
    return YES;
}

- (IBAction)speakTap:(id)sender {
    if ([PostMethodUse connectedToInternet]){
        if (isRecording == NO) {
            [self startRecording];
        } else {
            [self stopRecording];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

- (void)startRecording {
    if (isRecording == NO) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            [btn setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];
            
        }
        [speechToTextModule beginRecording];
        isRecording = YES;
        [self showRecing];
    }
}

- (void)stopRecording {
    if (isRecording) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        }
        [speechToTextModule stopRecording:YES];
        isRecording = NO;
    }
}

-(void)showRecing{
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
    if(rp==nil){
        rp = [[RecordingPlane alloc]initWithFrame:currentWindow.frame];
        [rp.ClickRecButton addTarget:self action:@selector(endClick) forControlEvents:UIControlEventTouchUpInside];
        [rp.ClickRecButton setImage:[UIImage imageNamed:@"btn_record@3x.png"] forState:UIControlStateNormal];
    }
    if(rl==nil){
        rl=[[UIView alloc] initWithFrame:currentWindow.frame];
        indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        indicator.isAccessibilityElement = NO;
        indicator.frame = CGRectMake(0.0, 0.0, currentWindow.frame.size.width, currentWindow.frame.size.height);
        [rl addSubview:indicator];
    }
    [currentWindow addSubview:rl];
    [currentWindow addSubview:rp];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, rp.ClickRecButton);
}

-(void)endClick{
    [rp removeFromSuperview];
    [self stopRecording];

}
-(void)showLoadingView{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.5]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [indicator startAnimating];
    
}
-(void)removetheLoading{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [indicator stopAnimating];
    [rl removeFromSuperview];
}

#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [self resetLayout];
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if(isNoColor){
        [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
    }else{
        [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //[myScroll setContentSize:myViewPanel.bounds.size];
}



#pragma mark - SpeechToTextModuleDelegate
- (BOOL)didReceiveVoiceResponse:(NSDictionary *)data {
    
    //NSLog(@"data %@",data);
    [self stopRecording];
    NSString *result = @"";
    id tmp = data[@"transcript"];
    if ([tmp isKindOfClass:[NSNumber class]] || [tmp rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location == NSNotFound) {
        // Spell out number
        // incase user spell number
        NSNumber *resultNumber = @([tmp integerValue]);
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        result = [formatter stringFromNumber:resultNumber];
    } else {
        result = tmp;
    }
    [self removetheLoading];
    TextField.text = result;
    //btn.accessibilityLabel = [@"語音輸入餐廳名稱" stringByAppendingFormat:@"，%@",TextField.text];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, TextField);
    [AdvanceSearchVariable sharedInstance].ShopName = result;
    return YES;
}

- (void)requestFailedWithError:(NSError *)error {
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (speechToTextModule) {
        [self stopRecording];
        speechToTextModule = nil;
    }
}



#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [UpperTitle setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
        [MidTitle setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
        [LowTitle setTextColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1]];
        
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        [UpperTitle setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [MidTitle setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [LowTitle setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}



#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //    NSLog(@"didFailWithError: %@", error);
    //    UIAlertView *errorAlert = [[UIAlertView alloc]
    //                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //    [errorAlert show];
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount=-100;
        [locationManager stopUpdatingLocation];
        
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if (tryoutcount>=0){
        tryoutcount =-100;
        [locationManager stopUpdatingLocation];
        //NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}


@end
