//
//  CodeInputSearchViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "CodeInputSearchViewController.h"
#import "SearchResultViewController.h"
#import "RestaurantDetailsController.h"
#import "SpeechToTextModule.h"
#import "PostMethodUse.h"
#import "TMDInputField.h"
#import "RecordingPlane.h"
#import "UIImage_withColor.h"

@interface CodeInputSearchViewController ()<SpeechToTextModuleDelegate>  {
    SpeechToTextModule *speechToTextModule;
    BOOL isRecording;
    __weak IBOutlet UITabBar* tabBar;
    
    __weak IBOutlet UIButton* btn;
    __weak IBOutlet UITextField* TextField;
    __weak IBOutlet UIView* Basement;
    __weak IBOutlet UILabel* searchLabel;
    __weak IBOutlet UIImageView* searchBase;
    
    __weak IBOutlet NSLayoutConstraint* btnSize;
    
    CGFloat fUse;
    CGFloat fSUse;
    
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    int tryoutcount;
    NSString* SegueToGoNext;
    
    RecordingPlane* rp;
    UIView* rl;
    UIActivityIndicatorView* indicator;
}

@end

@implementation CodeInputSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTabBarOutLook];
    // Do any additional setup after loading the view, typically from a nib.
    [btn setHidden:YES];
    speechToTextModule = [[SpeechToTextModule alloc] initWithCustomDisplay:nil];
    speechToTextModule.delegate = self;
    [speechToTextModule duckOff];
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate  =self;
    
    Basement.layer.shadowColor = [UIColor grayColor].CGColor;
    Basement.layer.shadowOffset = CGSizeMake(1, 2);
    Basement.layer.shadowOpacity = 0.5;
    Basement.layer.shadowRadius=1.0;
    
    [TextField setDelegate:self];
    
    //btn.accessibilityLabel = [@"語音輸入餐廳編號" stringByAppendingFormat:@"，%@",TextField.text];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewWillAppear:(BOOL)animated{
    [self setTabBarOutLook];
    [self setFontSizes];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

- (void)viewWillDisappear:(BOOL)animated {
    [self stopRecording];
    TextField.text = @"";
    //No animate
    [locationManager stopUpdatingLocation];
    //[self.navigationController setNavigationBarHidden:NO];
    [super viewWillDisappear:animated];
}





-(void) resetLayout{
    [TextField setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
    [((TMDInputField*)TextField) setBackSet:fSUse];
    [searchLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fSUse]];
    btnSize.constant = fSUse+8;
}




-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}



-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"GoIDSearch"]){
        SearchResultViewController* vc = segue.destinationViewController;
        [vc LoadSearchSID:@""];
    }else if ([[segue identifier] isEqualToString:@"GoRestResult"]){
        RestaurantDetailsController* vc = segue.destinationViewController;
        [vc LoadDataWithShopCode:TextField.text];
    }
}
-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([identifier isEqualToString:@"GoIDSearch"] || [identifier isEqualToString:@"GoRestResult"] ){
        if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
            return;
        }
    }
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    //btn.accessibilityLabel = [@"語音輸入餐廳編號" stringByAppendingFormat:@"，%@",TextField.text];
    // submit now
    return YES;
}


-(NSString*) RefineSpeakText:(NSString*)speakInput{
    //
    if (speakInput == nil){
        return @"";
    }
    NSString* text = [speakInput stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSCharacterSet *_NumericOnly = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet * EnglishOnly = [NSCharacterSet letterCharacterSet];
    NSCharacterSet *myTrimStringSet = [NSCharacterSet characterSetWithCharactersInString:text];
    if ([_NumericOnly isSupersetOfSet: myTrimStringSet])
    {
        //String entirely contains decimal numbers only.
        return text;
    }else{
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        NSNumber* num =[formatter numberFromString:speakInput];
        if (num!=nil){
            return [NSString stringWithFormat:@"%@",[formatter numberFromString:speakInput]];
        }
        return speakInput;
    }
}


-(IBAction)SearchClick:(id)sender{
    if ([PostMethodUse connectedToInternet]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayedClick)
                   withObject:nil
                   afterDelay:0.1];
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

-(void)delayedClick{
    if([PostMethodUse getBeforeVoiceOut]){
        [self delayedSearchCore];
    }else{
        [self performSelector:@selector(delayedClick)
                   withObject:nil
                   afterDelay:0.1];
    }
}

-(void)delayedSearchCore{
    NSMutableDictionary* dict = [PostMethodUse PostMethodWithFunctionString:[NSString stringWithFormat:@"m=shop_detailByShopId&id=%@",TextField.text]];
    if ([dict objectForKey:@"info"]==nil || [dict objectForKey:@"info"]==[NSNull null]){
        //Move To Search
        SegueToGoNext = @"GoIDSearch";
    }else {
        //Move To Rest
        SegueToGoNext = @"GoRestResult";
    }
    if(([CLLocationManager locationServicesEnabled] && [CLLocationManager authorizationStatus]!=kCLAuthorizationStatusDenied)){
        currentLocation=nil;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        tryoutcount = 0;
        [locationManager startUpdatingLocation];
    }else{
        currentLocation=nil;
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}








- (IBAction)speakTap:(id)sender {
    if ([PostMethodUse connectedToInternet]){
        if (isRecording == NO) {
            [self startRecording];
        } else {
            [self stopRecording];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

- (void)startRecording {
    if (isRecording == NO) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            [btn setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];

        }
        [speechToTextModule beginRecording];
        isRecording = YES;
        [self showRecing];
    }
}

- (void)stopRecording {
    if (isRecording) {
        BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
        if(isNoColor){
            [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        }else{
            [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        }
        [speechToTextModule stopRecording:YES];
        isRecording = NO;
    }
}
-(void)showRecing{
    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
    if(rp==nil){
        rp = [[RecordingPlane alloc]initWithFrame:currentWindow.frame];
        [rp.ClickRecButton addTarget:self action:@selector(endClick) forControlEvents:UIControlEventTouchUpInside];
        [rp.ClickRecButton setImage:[UIImage imageNamed:@"btn_record@3x.png"] forState:UIControlStateNormal];
    }
    if(rl==nil){
        rl=[[UIView alloc] initWithFrame:currentWindow.frame];
        indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        indicator.isAccessibilityElement = NO;
        indicator.frame = CGRectMake(0.0, 0.0, currentWindow.frame.size.width, currentWindow.frame.size.height);
        [rl addSubview:indicator];
    }
    [currentWindow addSubview:rl];
    [currentWindow addSubview:rp];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, rp.ClickRecButton);
}

-(void)endClick{
    [rp removeFromSuperview];
    [self stopRecording];
    
}
-(void)showLoadingView{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.5]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [indicator startAnimating];
    
}
-(void)removetheLoading{
    [rl setBackgroundColor:[UIColor colorWithWhite:0 alpha:0]];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [indicator stopAnimating];
    [rl removeFromSuperview];
}

#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [self resetLayout];
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if(isNoColor){
        [btn setImage:[UIImage imageNamed:@"btn_mic_grey.png"] forState:UIControlStateNormal];
        [searchBase setImage:[UIImage imageNamed:@"btn_redbase_grey@3x.png"]];
    }else{
        [btn setImage:[UIImage imageNamed:@"btn_mic.png"] forState:UIControlStateNormal];
        [searchBase setImage:[UIImage imageNamed:@"btn_redbase@3x.png"]];
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,myViewPanel.bounds.size.height);
    //[myScroll setContentSize:myViewPanel.bounds.size];
}



#pragma mark - SpeechToTextModuleDelegate
- (BOOL)didReceiveVoiceResponse:(NSDictionary *)data {
    
    //NSLog(@"data %@",data);
    [self stopRecording];
    NSString *result = @"";
    id tmp = data[@"transcript"];
    if ([tmp isKindOfClass:[NSNumber class]] || [tmp rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location == NSNotFound) {
        // Spell out number
        // incase user spell number
        NSNumber *resultNumber = @([tmp integerValue]);
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        result = [formatter stringFromNumber:resultNumber];
    } else {
        result = tmp;
    }
    [self removetheLoading];
    TextField.text = [self RefineSpeakText:result];
    //btn.accessibilityLabel = [@"語音輸入餐廳編號" stringByAppendingFormat:@"，%@",TextField.text];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, TextField);
    return YES;
}

- (void)requestFailedWithError:(NSError *)error {
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (speechToTextModule) {
        [self stopRecording];
        speechToTextModule = nil;
    }
}




#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        //tabBar.unselectedItemTintColor =[UIColor colorWithRed:236/255.f green:236/255.f blue:236/255.f alpha:1];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
        //tabBar.unselectedItemTintColor =[UIColor colorWithRed:236/255.f green:236/255.f blue:236/255.f alpha:1];
    }
    if(isNoColor){
        [btn setImage:[UIImage imageNamed:@"btn_micB_grey@3x.png"] forState:UIControlStateNormal];
    }else{
        [btn setImage:[UIImage imageNamed:@"btn_micB@3x.png"] forState:UIControlStateNormal];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}


#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //    NSLog(@"didFailWithError: %@", error);
    //    UIAlertView *errorAlert = [[UIAlertView alloc]
    //                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //    [errorAlert show];
    tryoutcount++;
    if (tryoutcount>4){
        tryoutcount=-100;
        [locationManager stopUpdatingLocation];
        
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if (tryoutcount>=0){
        tryoutcount =-100;
        [locationManager stopUpdatingLocation];
        //NSLog(@"didUpdateToLocation: %@", newLocation);
        currentLocation = newLocation;
        
        [self performSelector:@selector(delaySegue:)
                   withObject:SegueToGoNext
                   afterDelay:0.1];
    }
}

@end
