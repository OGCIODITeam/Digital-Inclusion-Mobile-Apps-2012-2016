//
//  AdvanceSearchVariable.m
//  TapMyDish
//
//  Created by BDMacMini1 on 16/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "AdvanceSearchVariable.h"
@interface AdvanceSearchVariable ()

{
    TypeObjectStructure *_ShopTypes;
    TypeObjectStructure *_Dists;
    TypeObjectStructure *_Dishes;
    NSString *_HaveTakeAway;
    NSString *_ShopName;
}
@end
@implementation AdvanceSearchVariable


+ (AdvanceSearchVariable *)sharedInstance {
    static dispatch_once_t onceToken;
    static AdvanceSearchVariable *instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[AdvanceSearchVariable alloc] init];
    });
    return instance;
}

- (id)init {
    self = [super init];
    if (self) {
        _ShopTypes = [[TypeObjectStructure alloc] init];
        _Dists = [[TypeObjectStructure alloc] init];
        _Dishes = [[TypeObjectStructure alloc] init];
        // Note these aren't allocated as [[NSString alloc] init] doesn't provide a useful object
        _HaveTakeAway = nil;
        _ShopName = nil;
    }
    return self;
}


-(TypeObjectStructure*) returnShopTypesSuper{
    return _ShopTypes;
}

-(TypeObjectStructure*) returnDistsSuper{
    return _Dists;
}

-(TypeObjectStructure*) returnDishesSuper{
    return _Dishes;
}


-(void)resetEmptyWithShopeType:(NSMutableArray*) shoptype AndDist:(NSMutableArray*)dist AndDish:(NSMutableArray*)dish
{
    _ShopTypes = [[TypeObjectStructure alloc] init];
    [_ShopTypes SetUpName:@"餐廳類型" AndID:@""];
    _Dists = [[TypeObjectStructure alloc] init];
    [_Dists SetUpName:@"地區" AndID:@""];
    _Dishes = [[TypeObjectStructure alloc] init];
    [_Dishes SetUpName:@"菜式" AndID:@""];
    _HaveTakeAway = nil;
    _ShopName = nil;
    //Create Structure
    //Shop Just Eat itself
    for (NSMutableDictionary* dict in shoptype){
        TypeObjectStructure * t =[[TypeObjectStructure alloc] init];
        [t SetUpName:[dict objectForKey:@"tn"] AndID:[dict objectForKey:@"id"]];
        [_ShopTypes AddChildren:t];
    }
    //Dist
    for (NSMutableDictionary* dict in dist){
        [_Dists AddChildren:[self GenDistFromDict:dict]];
    }
    //Dish
    for (NSMutableDictionary* dict in dish){
        [_Dishes AddChildren:[self GenDishesFromDict:dict]];
    }
}


-(TypeObjectStructure*) GenDistFromDict:(NSMutableDictionary*)dict {
    TypeObjectStructure * t =[[TypeObjectStructure alloc] init];
    [t SetUpName:[dict objectForKey:@"tn"] AndID:[dict objectForKey:@"id"]];
    NSMutableArray* sub = [dict objectForKey:@"sub"];
    if (sub == nil || sub == [NSNull null] || [sub count]==0)
    return t;
    for (NSMutableDictionary* dict2 in sub){
        [t AddChildren:[self GenDistFromDict:dict2]];
    }
    return t;
}


-(TypeObjectStructure*) GenDishesFromDict:(NSMutableDictionary*)dict {
    TypeObjectStructure * t =[[TypeObjectStructure alloc] init];
    [t SetUpName:[dict objectForKey:@"tn"] AndID:[dict objectForKey:@"id"]];
    NSMutableArray* sub = [dict objectForKey:@"sub"];
    if (sub == nil || sub == [NSNull null] || [sub count]==0)
        return t;
    if ([sub count]==1){
        NSMutableDictionary* dict2 = [sub objectAtIndex:0];
        [t AddChildren:[self GenDishesFromDict:dict2]];
        return t;
    }
    NSMutableDictionary* sub2 = (NSMutableDictionary*)sub;
    for (NSString* key in sub2){
        NSMutableDictionary* dict2 = [sub2 objectForKey:key];
        [t AddChildren:[self GenDishesFromDict:dict2]];
    }
    return t;
}


-(BOOL) returnHaveTakenAway{
    if (_HaveTakeAway ==nil) return NO;
    return [_HaveTakeAway isEqualToString:@"1"];
}

-(NSString*) returnShopName{
    if (_ShopName ==nil) return @"";
    return _ShopName;
}

-(NSString*) returnShopNameIDs{
    if (_ShopName ==nil) return @"";
    return [NSString stringWithFormat:@"&name=%@" ,_ShopName];
}


-(NSString*) returnHaveTakeAwayIDs{
    if([self returnHaveTakenAway]){
        return @"&istakeout=1";
    }
    return @"";
}

-(NSString*) returnShopTypes{
    NSString* str = @"";
    for(TypeObjectStructure* dict in [_ShopTypes GetChildren]){
        if ([dict IamClicked]){
            if ([str isEqualToString:@""]){
                str = [str stringByAppendingFormat:@"%@", [dict returnName]];
            }else{
                str = [str stringByAppendingFormat:@"．%@", [dict returnName]];
            }
        }
    }
    return str;
}

-(NSString*) returnDists{
    return [self returnSub:_Dists];
}

-(NSString*) returnSub:(TypeObjectStructure*)Sub{
    NSString* str = @"";
    for(TypeObjectStructure* dict in [Sub GetChildren]){
        if ([dict IamClicked]){
            if ([str isEqualToString:@""]){
                str = [str stringByAppendingFormat:@"%@", [dict returnName]];
            }else{
                str = [str stringByAppendingFormat:@"．%@", [dict returnName]];
            }
        }else{
            NSString* str0 = [self returnSub:dict];
            if (![str0 isEqualToString:@""]){
                if ([str isEqualToString:@""]){
                    str = [str stringByAppendingFormat:@"%@", str0];
                }else{
                    str = [str stringByAppendingFormat:@"．%@", str0];
                }
            }
        }
    }
    return str;
}


-(NSString*) returnDishes{
    return [self returnSub:_Dishes];
}


-(NSString*) returnShopTypesIDs{
    NSString* str = @"";
    for(TypeObjectStructure* dict in [_ShopTypes GetChildren]){
        if ([dict IamClicked]){
            str = [str stringByAppendingFormat:@"&st[]=%@", [dict returnID]];
        }
    }
    return str;
}

-(NSString*) returnDistsIDsSub:(TypeObjectStructure*) Sub{
    NSString* str = @"";
    for(TypeObjectStructure* dict in [Sub GetChildren]){
        if ([dict IamClicked]){
            NSString* theid =[dict returnID];
            NSString* thetn =[dict returnName];
            if([thetn hasPrefix:@"全"]) {
                str = [str stringByAppendingFormat:@"&bd[]=%@", theid];
            }else{
                str = [str stringByAppendingFormat:@"&sd[]=%@", theid];
            }
        }
        if ([dict GetChildren]!=nil){
            str = [str stringByAppendingString:[self returnDistsIDsSub:dict]];
        }
    }
    return str;
}

-(NSString*) returnDistsIDs{
    return [self returnDistsIDsSub:_Dists];
}

-(NSString*) returnDishesIDsSub:(TypeObjectStructure*) Sub{
    NSString* str = @"";
    for(TypeObjectStructure* dict in [Sub GetChildren]){
        if ([dict IamClicked]){
            NSString* theid =[dict returnID];
            str = [str stringByAppendingFormat:@"&dt[]=%@", theid];
        }
        if ([dict GetChildren]!=nil){
            str = [str stringByAppendingString:[self returnDishesIDsSub:dict]];
        }
    }
    return str;
}

-(NSString*) returnDishesIDs{
    return [self returnDishesIDsSub:_Dishes];
}

-(void) setHaveTakeAway:(NSString*)haveTakeAway{
    _HaveTakeAway = haveTakeAway;
}

-(void) setShopName:(NSString*)shopName{
    _ShopName = shopName;
}

@end
