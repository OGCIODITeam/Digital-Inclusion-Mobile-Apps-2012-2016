//
//  MyCouponPageViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 27/9/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MyCouponPageViewController.h"
#import "MyCouponDetailViewController.h"
#import "PostMethodUse.h"
#import "AppDelegate.h"
#import "CouponTicketFavTab.h"
#import "StringUnity.h"
#import "UIImage_withColor.h"

@interface MyCouponPageViewController (){
    __weak IBOutlet UITabBar* tabBar;
    
    __weak IBOutlet UITableView* tbView;
    __weak IBOutlet UINavigationItem* NavItem;
    
    __weak IBOutlet UILabel *NoSearchMessage;
    __weak IBOutlet UIView *OverlayNoSearch;
    //__weak IBOutlet
    
    
    NSMutableArray* QueryArray;
    
    CGFloat fSUse;
    CGFloat fUse;
    NSInteger NowPullLength;
    
    
    Boolean isNullResult;
    NSString* isNullMessage;
    
    NSInteger SelectedCouponIndex;
}

@end

@implementation MyCouponPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NavItem rightBarButtonItem] setAccessibilityLabel:@"更新"];
    [tbView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell"];
    tbView.rowHeight = UITableViewAutomaticDimension;
    tbView.estimatedRowHeight = 414;
    tbView.allowsMultipleSelectionDuringEditing = NO;
    
    [tbView setBackgroundColor:[UIColor colorWithRed:0.9451  green:0.9451  blue:0.9451  alpha:1]];
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
    [self setTabBarOutLook];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    [tabBar setSelectedItem:tabBar.items[3]];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self setTabBarOutLook];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self LoadItem];
    if (isNullResult){
        [OverlayNoSearch setHidden:NO];
        [NoSearchMessage setText:isNullMessage];
    }else{
        [OverlayNoSearch setHidden:YES];
        [NoSearchMessage setText:isNullMessage];
    }
    [self setFontSizes];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"GoToCouponFavDetail"]){
        NSMutableDictionary* dict = [QueryArray objectAtIndex:SelectedCouponIndex];
        NSString* cId = [dict objectForKey:@"cId"];
        MyCouponDetailViewController* des = segue.destinationViewController;
        [des LoadCouponDetail:cId];
    }
}

-(void) LoadItem{
    QueryArray = [NSMutableArray arrayWithCapacity:0];
    NSMutableDictionary* MD =[NSMutableDictionary dictionaryWithCapacity:0];
    [MD setObject:@"Need" forKey:@"Clear"];
    [QueryArray addObject:MD];
    isNullMessage = @"沒有已存優惠.";
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    BOOL myBool = NO;
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        for (NSManagedObject *product in fetchedObjects) {
            //Loop
            NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:0];
            NSString* cId = [product valueForKey:@"cId"];
            NSString* couponContent = [product valueForKey:@"couponContent"];
            NSString* couponName = [product valueForKey:@"couponName"];
            NSString* couponRule = [product valueForKey:@"couponRule"];
            NSString* couponRestaurant = [product valueForKey:@"couponRestaurant"];
            NSDate* startTime = [product valueForKey:@"startTime"];
            NSDate* stopTime = [product valueForKey:@"stopTime"];
            [dict setObject:cId forKey:@"cId"];
            [dict setObject:couponContent forKey:@"couponContent"];
            [dict setObject:couponName forKey:@"couponName"];
            [dict setObject:couponRule forKey:@"couponRule"];
            [dict setObject:couponRestaurant forKey:@"couponRestaurant"];
            [dict setObject:startTime forKey:@"startTime"];
            [dict setObject:stopTime forKey:@"stopTime"];
            NSDate* nowDate = [NSDate date];
            BOOL bo = ([nowDate compare:stopTime] == NSOrderedAscending);
            myBool = myBool || !bo;
            [QueryArray addObject:dict];
        }
    }
    if (!myBool){
        [QueryArray removeObject:MD];
        MD=nil;
    }
    if ([QueryArray count]>1 && MD!=nil){
        isNullResult = NO;
    }else if ([QueryArray count]>0){
        isNullResult = NO;
    }else{
        isNullResult = YES;
    }
    [tbView reloadData];
}

-(void) ReloadLayout{
    [self LoadItem];
    if (!isNullResult){
        [OverlayNoSearch setHidden:YES];
    }else{
        [OverlayNoSearch setHidden:NO];
    }
    [tbView setNeedsLayout];
    [tbView layoutIfNeeded];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

-(IBAction)ClickTheTab:(id)sender{
    //GoToMyCouponDetailPage
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    SelectedCouponIndex = ((UIButton*)sender).tag;
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToCouponFavDetail"
               afterDelay:0.1];
}
-(void)ClickTheTabSmall:(NSInteger) index{
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    SelectedCouponIndex = index;
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToCouponFavDetail"
               afterDelay:0.1];
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}

-(IBAction)ClickClearAll:(id)sender{
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delayClearAllOutdated)
               withObject:nil
               afterDelay:0.01];
}

-(void)delayClearAllOutdated{
    if ([PostMethodUse getBeforeVoiceOut]){
        [self ClearAllOutdated];
        [self ReloadLayout];
        [PostMethodUse AfterLoadingLayoutUse];
    }else{
        [self performSelector:@selector(delayClearAllOutdated)
                   withObject:nil
                   afterDelay:0.01];
    }
}

-(void) ClearAllOutdated{
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        for (NSManagedObject *product in fetchedObjects) {
            //Loop
            NSDate* stopTime = [product valueForKey:@"stopTime"];
            NSDate* nowDate = [NSDate date];
            BOOL bo = ([nowDate compare:stopTime] == NSOrderedAscending);
            if (!bo){
                [managedObjectContext deleteObject:product];
            }
        }
    }
}

#pragma mark - delay
-(void)delayDel:(NSString*)cId{
    //Kill
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cId=%@", cId];
    [fetchRequest setPredicate:predicate];
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        if([fetchedObjects count]>0){
            [managedObjectContext deleteObject:[fetchedObjects objectAtIndex:0]];
            [appDelegate saveContext];
        }else{
            //NSLog(@"Nothing Left");
        }
    }
    [self LoadItem];
    isNullMessage =@"沒有已存記錄.";
    if (isNullResult){
        [OverlayNoSearch setHidden:NO];
        [NoSearchMessage setText:isNullMessage];
    }else{
        [OverlayNoSearch setHidden:YES];
    }
    //Refresh Layout
    [PostMethodUse AfterLoadingLayoutUse];
}


-(IBAction)clickedRefresh:(id)sender{
    if([PostMethodUse connectedToInternet]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayRefresh)
                   withObject:nil
                   afterDelay:0.01];
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

-(void)delayRefresh{
    if([PostMethodUse connectedToInternet]){
        if ([PostMethodUse getBeforeVoiceOut]){
            [self delayRefreshCore];
            UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, [NavItem rightBarButtonItem]);
            [PostMethodUse AfterLoadingLayoutUse];
        }else{
            
            [self performSelector:@selector(delayRefresh)
                       withObject:nil
                       afterDelay:0.01];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

-(void) delayRefreshCore{
    //
    NSString* mydatastring = @"";
    for(NSMutableDictionary* dict in QueryArray){
        NSString* cId = [dict objectForKey:@"cId"];
        mydatastring = [mydatastring stringByAppendingFormat:@"&cid[]=%@", cId];
    }
    {
        NSMutableDictionary* QueryDictA = [PostMethodUse PostMethodWithFunctionString:[NSString stringWithFormat:@"m=search_coupon%@", mydatastring]];
        
        AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
        
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
        [fetchRequest setEntity:entity];
        for(NSString* key in QueryDictA)
        {
            NSMutableDictionary* dict = [QueryDictA objectForKey:key];
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cId=%@", [dict objectForKey:@"id"]];
            [fetchRequest setPredicate:predicate];
            NSError *error = nil;
            NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
            if (fetchedObjects == nil) {
                NSLog(@"Fetch error, something's wrong. %@",error);
            }
            else{
                if([fetchedObjects count]>0){
                    NSString* cId = [StringUnity RefinedString:[dict objectForKey:@"id"]];
                    NSString* couponContent = [StringUnity RefinedString:[dict objectForKey:@"couponContent"]];
                    NSString* couponName = [StringUnity RefinedString:[dict objectForKey:@"couponName"]];
                    NSString* couponRule = [StringUnity RefinedString:[dict objectForKey:@"couponRule"]];
                    NSString* couponRestaurant = [StringUnity RefinedString:[dict objectForKey:@"companyName"]];
                    NSString* deadline = [dict objectForKey:@"deadline"];
                    NSString* publishDate = [dict objectForKey:@"publishDate"];
                    NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
                    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                    NSDate* startTime = [formatter dateFromString:publishDate];
                    NSDate* stopTime = [formatter dateFromString:deadline];
                    NSManagedObject* NSMO = [fetchedObjects objectAtIndex:0];
                    [NSMO setValue:cId forKey:@"cId"];
                    [NSMO setValue:couponContent forKey:@"couponContent"];
                    [NSMO setValue:couponName forKey:@"couponName"];
                    [NSMO setValue:couponRule forKey:@"couponRule"];
                    [NSMO setValue:couponRestaurant forKey:@"couponRestaurant"];
                    [NSMO setValue:startTime forKey:@"startTime"];
                    [NSMO setValue:stopTime forKey:@"stopTime"];
                }else{
                    //NSLog(@"Nothing Left");
                }
            }
        }
        [appDelegate saveContext];
    }
    [self LoadItem];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}



#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        [NoSearchMessage setFont:[UIFont fontWithName:@"Heiti TC" size:fontSize]];
        [self ReloadLayout];
        
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,MyPanel.bounds.size.height);
    //[myScroll setContentSize:CGSizeMake(0,MyPanel.bounds.size.height)];
}




#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

#pragma UITableViewRelated
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[QueryArray objectAtIndex:indexPath.row] objectForKey:@"Clear"]==nil){
        [self ClickTheTabSmall:indexPath.row];
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [QueryArray count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    
    UITableViewCell* cell = [tbView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.contentView setBackgroundColor:[UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1]];
    [cell setTranslatesAutoresizingMaskIntoConstraints:NO];
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    NSMutableDictionary* dictionary = [QueryArray objectAtIndex:indexPath.row];
    if ([dictionary objectForKey:@"Clear"]==nil)
    {
        CouponTicketFavTab* CTFT;
        if ([[cell.contentView subviews] count]==0){
            CTFT = [[CouponTicketFavTab alloc] init];
            [cell.contentView addSubview:CTFT];
            [CTFT setTranslatesAutoresizingMaskIntoConstraints:NO];
            [cell.contentView addConstraints:CTFT.constraints];
            NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
            [cell.contentView addConstraint:topCon];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
            [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
            [CTFT setTranslatesAutoresizingMaskIntoConstraints:NO];
            [cell.contentView layoutIfNeeded];
            CTFT.layer.shadowColor = [UIColor grayColor].CGColor;
            CTFT.layer.shadowOffset = CGSizeMake(1, 2);
            CTFT.layer.shadowOpacity = 0.5;
            CTFT.layer.shadowRadius=1.0;
            //Click
            //[CTFT.ButtonTypeOn addTarget:self action:@selector(ClickTheTab:) forControlEvents:(UIControlEventTouchUpInside)];
            [CTFT.ButtonTypeOn setHidden:YES];
        }
        else
        {
            if (CTFT == nil || ![CTFT isKindOfClass:[CouponTicketFavTab class]]){
                while([[cell.contentView subviews] count]>0){
                    UIView * v =[[cell.contentView subviews] objectAtIndex:0];
                    [v removeFromSuperview];
                }
                CTFT = [[CouponTicketFavTab alloc] init];
                [cell.contentView addSubview:CTFT];
                [CTFT setTranslatesAutoresizingMaskIntoConstraints:NO];
                [cell.contentView addConstraints:CTFT.constraints];
                NSLayoutConstraint * topCon = [NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeTop multiplier:1 constant:10];
                [cell.contentView addConstraint:topCon];
                [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeTrailing multiplier:1 constant:-10]];
                [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
                [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:CTFT attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:CTFT.superview attribute:NSLayoutAttributeLeading multiplier:1 constant:10]];
                [CTFT setTranslatesAutoresizingMaskIntoConstraints:NO];
                [cell.contentView layoutIfNeeded];
                CTFT.layer.shadowColor = [UIColor grayColor].CGColor;
                CTFT.layer.shadowOffset = CGSizeMake(1, 2);
                CTFT.layer.shadowOpacity = 0.5;
                CTFT.layer.shadowRadius=1.0;
                //Click
                //[CTFT.ButtonTypeOn addTarget:self action:@selector(ClickTheTab:) forControlEvents:(UIControlEventTouchUpInside)];
                [CTFT.ButtonTypeOn setHidden:YES];
            }
        }
        //
        NSString * title = [dictionary valueForKey:@"couponName"];
        NSString * rest = [dictionary valueForKey:@"couponRestaurant"];
        NSString * content = [dictionary valueForKey:@"couponContent"];
        NSDate* nowDate = [NSDate date];
        BOOL bo = ([nowDate compare:[dictionary valueForKey:@"stopTime"]] == NSOrderedAscending);
        //[CTFT setTitle:title AndRestaurant:rest AndContant:content AndGetOutdated:YES];
        [CTFT setTitle:title AndRestaurant:rest AndContant:content AndGetOutdated:!bo];
        [CTFT setFontSize:(CGFloat)fUse];
        CTFT.ButtonTypeOn.tag = indexPath.row;
        cell.isAccessibilityElement = YES;
        cell.accessibilityLabel = CTFT.ButtonTypeOn.accessibilityLabel;
    }else{
        while([[cell.contentView subviews] count]>0){
            UIView * v =[[cell.contentView subviews] objectAtIndex:0];
            [v removeFromSuperview];
        }
        UIView* btnview = [[UIView alloc] init];
        UIImageView* redBase = [[UIImageView alloc] init];
        UILabel* TextLabel = [[UILabel alloc] init];
        UIButton* Btn = [[UIButton alloc] init];
        TextLabel.isAccessibilityElement = NO;
        cell.isAccessibilityElement = YES;
        cell.accessibilityLabel = @"清除已過期的優惠";
        [TextLabel setText:@"清除已過期的優惠"];
        [TextLabel setTextAlignment:(NSTextAlignmentCenter)];
        [TextLabel setTextColor:[UIColor whiteColor]];
        [TextLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
        [TextLabel setNumberOfLines:0];
        if (isNoColor){
            [redBase setImage:[UIImage imageNamed:@"btn_redbase_grey@3x.png"]];
        }else{
            [redBase setImage:[UIImage imageNamed:@"btn_redbase@3x.png"]];
        }
        [cell.contentView addSubview:btnview];
        [btnview addSubview:redBase];
        [btnview addSubview:TextLabel];
        [btnview addSubview:Btn];
        //Constraint
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:cell.contentView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:btnview attribute:NSLayoutAttributeTrailing multiplier:1 constant:8]];
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:cell.contentView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:btnview attribute:NSLayoutAttributeLeading multiplier:1 constant:-8]];
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:cell.contentView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:btnview attribute:NSLayoutAttributeBottom multiplier:1 constant:8]];
        [cell.contentView addConstraint:[NSLayoutConstraint constraintWithItem:cell.contentView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:btnview attribute:NSLayoutAttributeTop multiplier:1 constant:-8]];
        btnview.translatesAutoresizingMaskIntoConstraints = NO;
        [btnview setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0]];
        //
        NSLayoutConstraint* nsc = [NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0];
        nsc.priority = 500;
        [btnview addConstraint:nsc];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:redBase attribute:NSLayoutAttributeTrailing multiplier:1 constant:0]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:redBase attribute:NSLayoutAttributeLeading multiplier:1 constant:0]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:redBase attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:redBase attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        redBase.translatesAutoresizingMaskIntoConstraints = NO;
        //
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:TextLabel attribute:NSLayoutAttributeTrailing multiplier:1 constant:8]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:TextLabel attribute:NSLayoutAttributeLeading multiplier:1 constant:-8]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:TextLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:8]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:TextLabel attribute:NSLayoutAttributeTop multiplier:1 constant:-8]];
        TextLabel.translatesAutoresizingMaskIntoConstraints = NO;
        //
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:Btn attribute:NSLayoutAttributeTrailing multiplier:1 constant:0]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:Btn attribute:NSLayoutAttributeLeading multiplier:1 constant:0]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:Btn attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        [btnview addConstraint:[NSLayoutConstraint constraintWithItem:btnview attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:Btn attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
        Btn.translatesAutoresizingMaskIntoConstraints = NO;
        //Click
        [Btn addTarget:self action:@selector(ClickClearAll:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    cell.contentView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    [cell.contentView setNeedsLayout];
    [cell.contentView layoutIfNeeded];
    return cell;
}

// Override to support conditional editing of the table view.
// This only needs to be implemented if you are going to be returning NO
// for some items. By default, all items are editable.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    if ([QueryArray count]>0 && [[QueryArray objectAtIndex:0] objectForKey:@"Clear"]!=nil){
        return indexPath.row!=0;
    }
    return YES;
    //return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        //Delete The List first
        NSMutableDictionary* ele = [QueryArray objectAtIndex:indexPath.row];
        [QueryArray removeObject:ele];
        //Delete The Corresponding element from Database Records
        NSString* cId = [ele objectForKey:@"cId"];
        [self performSelector:@selector(delayDel:)
                   withObject:cId
                   afterDelay:0.01];
    }
}

@end
