//
//  MyCouponDetailViewController.m
//  TapMyDish
//
//  Created by BDMacMini1 on 25/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MyCouponDetailViewController.h"
#import "StringUnity.h"
#import "AppDelegate.h"
#import "PostMethodUse.h"
#import "StringUnity.h"
#import "UIImage_withColor.h"

@interface MyCouponDetailViewController (){
    __weak IBOutlet UITabBar* tabBar;
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* MyPanel;
    __weak IBOutlet UINavigationItem* NavItem;
    
    __weak IBOutlet UIImageView *Deco;
    __weak IBOutlet UIImageView *TitleIcon;
    __weak IBOutlet NSLayoutConstraint *TitleIconHeight;
    __weak IBOutlet UILabel *TitleHeight;
    __weak IBOutlet UILabel *TitleLabel;
    __weak IBOutlet UILabel *RestaurantName;
    __weak IBOutlet UILabel* TimeLabel;
    __weak IBOutlet UIImageView *AboutIcon;
    __weak IBOutlet NSLayoutConstraint *AboutIconHeight;
    __weak IBOutlet UILabel *AboutHeight;
    __weak IBOutlet UILabel *AboutLabel;
    __weak IBOutlet UIImageView* DetailIcon;
    __weak IBOutlet NSLayoutConstraint *DetailIconHeight;
    __weak IBOutlet UILabel *DetailHeight;
    __weak IBOutlet UILabel *DetailLabel;
    
    __weak IBOutlet UIView* yomikatachiBlock1;
    __weak IBOutlet UIView* yomikatachiBlock2;
    __weak IBOutlet UIView* yomikatachiBlock3;
    
    __weak IBOutlet UIButton* LowBtn;
    __weak IBOutlet UIImageView* LowBtnPic;
    __weak IBOutlet UILabel* BtnText;
    
    __weak IBOutlet NSLayoutConstraint* BaseButtonLeastSize;
    __strong IBOutlet UIView *OutdatedBlock;
    __strong IBOutlet UILabel *OutdatedText;
    __strong IBOutlet NSLayoutConstraint *OutdatedLeading;
    __strong IBOutlet NSLayoutConstraint *OutdatedTop;
    __strong IBOutlet NSLayoutConstraint *OutdatedBottom;
    
    CGFloat fSUse;
    CGFloat fUse;
    
    NSMutableDictionary * QueryDict;
    NSString* idd;
    NSString* couponName ;
    NSString* couponContent ;
    NSString* couponRule;
    NSString* couponRestaurant;
    NSDate* StartD;
    NSDate* StopD;
    
    NSString* NavTitle;
}

@end

@implementation MyCouponDetailViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [[NavItem rightBarButtonItem] setAccessibilityLabel:@"更新"];
    // Do any additional setup after loading the view.
    [tabBar setDelegate:self];
    //Last
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(preferredContentSizeChanged:) name:UIContentSizeCategoryDidChangeNotification object:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */



-(void)LoadCouponDetail:(NSString*) cId;{
    idd = cId;
}






-(void) ReloadLayout{
    //[NavItem setTitle:NavTitle];
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cId=%@", idd];
    [fetchRequest setPredicate:predicate];
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
    }
    else{
        for (NSManagedObject *product in fetchedObjects) {
            //Loop
            couponContent = [product valueForKey:@"couponContent"];
            couponName = [product valueForKey:@"couponName"];
            couponRule = [product valueForKey:@"couponRule"];
            couponRestaurant = [product valueForKey:@"couponRestaurant"];
            StartD = [product valueForKey:@"startTime"];
            StopD = [product valueForKey:@"stopTime"];
        }
    }
    NSDateFormatter* Chiformatter = [[NSDateFormatter alloc]init];
    [Chiformatter setDateFormat:@"yyyy-MM-dd"];
    NSDate* nowdate = [NSDate date];
    BOOL bo = [nowdate compare:StopD] == NSOrderedAscending;
    //
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults]boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (!bo){
        [yomikatachiBlock1 addSubview:OutdatedBlock];
        [yomikatachiBlock1 addConstraint:OutdatedLeading];
        [yomikatachiBlock1 addConstraint:OutdatedTop];
        [yomikatachiBlock1 addConstraint:OutdatedBottom];
    }else{
        [OutdatedBlock removeFromSuperview];
        [yomikatachiBlock1 removeConstraint:OutdatedLeading];
        [yomikatachiBlock1 removeConstraint:OutdatedTop];
        [yomikatachiBlock1 removeConstraint:OutdatedBottom];
    }
    TitleIconHeight.constant = fUse;
    AboutIconHeight.constant = fUse;
    DetailIconHeight.constant = fUse;
    [BtnText setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [TitleHeight setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fUse*1.2]];
    [TitleLabel setFont:[UIFont fontWithName:@"STHeitiTC-Medium" size:fUse*1.2]];
    [AboutHeight setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [AboutLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [DetailHeight setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [DetailLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [RestaurantName setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    [TimeLabel setFont:[UIFont fontWithName:@"Heiti TC" size:fUse]];
    if (isNoColor){
        [TitleLabel setTextColor:[UIColor blackColor]];
        [RestaurantName setTextColor:[UIColor blackColor]];
        [OutdatedBlock setBackgroundColor:[UIColor grayColor]];
        [TitleIcon setImage:[UIImage imageNamed:@"icon_coupon_grey@3x.png"]];
        [AboutIcon setImage:[UIImage imageNamed:@"icon_content_grey@3x.png"]];
        [DetailIcon setImage:[UIImage imageNamed:@"icon_rule_grey@3x.png"]];
        [LowBtnPic setImage:[UIImage imageNamed:@"btn_redbase_grey@3x.png"]];
    }else{
        [TitleLabel setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [RestaurantName setTextColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [OutdatedBlock setBackgroundColor:[UIColor colorWithRed:0.86666 green:0.20392 blue:0.070588 alpha:1]];
        [TitleIcon setImage:[UIImage imageNamed:@"icon_coupon@3x.png"]];
        [AboutIcon setImage:[UIImage imageNamed:@"icon_content@3x.png"]];
        [DetailIcon setImage:[UIImage imageNamed:@"icon_rule@3x.png"]];
        [LowBtnPic setImage:[UIImage imageNamed:@"btn_redbase@3x.png"]];
    }
    //Details
    [BtnText setText:@"取消我的優惠"];
    [LowBtn setAccessibilityLabel:@"取消我的優惠"];
    //Check if added
    [TitleLabel setText:couponName];
    [RestaurantName setText:couponRestaurant];
    [AboutLabel setText:couponContent];
    if ([StopD timeIntervalSinceDate:StartD] > 3153600000){
        [TimeLabel setText:[NSString stringWithFormat:@"由 %@ 起生效",[Chiformatter stringFromDate:StartD]]];
    }else{
        [TimeLabel setText:[NSString stringWithFormat:@"有效日期由 %@ 至 %@ ",[Chiformatter stringFromDate:StartD],[Chiformatter stringFromDate:StopD]]];
    }
    NSString* refineRule = @"條款及細則：";
    NSString* refineRead =@"條款及細則：";
    NSArray* ary = [couponRule componentsSeparatedByString:@"•"];
    for (int i =0;i<ary.count;i++){
        if (![[StringUnity RefinedString:[ary objectAtIndex:i]] isEqualToString:@""]){
            refineRule = [NSString stringWithFormat:@"%@\n・%@",refineRule,[ary objectAtIndex:i]];
            refineRead = [NSString stringWithFormat:@"%@\n%@",refineRead,[ary objectAtIndex:i]];
        }
    }
    [DetailLabel setText:refineRule];
    [DetailLabel setAccessibilityLabel:[StringUnity ReadWordRefinement:refineRead]];
    NSString* reading =TitleLabel.text;
    reading = [reading stringByAppendingFormat:@"，%@", RestaurantName.text];
    if (!bo) {
        reading = [reading stringByAppendingFormat:@"，%@", @"已過期"];
    }
    reading = [reading stringByAppendingFormat:@"，%@", TimeLabel.text];
    
    [yomikatachiBlock1 setAccessibilityLabel:reading];
    [yomikatachiBlock2 setAccessibilityLabel:[StringUnity ReadWordRefinement:AboutLabel.text]];
    [yomikatachiBlock3 setAccessibilityLabel:[StringUnity ReadWordRefinement:refineRead]];
    NSMutableParagraphStyle *paragrahStyle = [[NSMutableParagraphStyle alloc] init];
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:refineRule];
    [paragrahStyle setFirstLineHeadIndent:0.0f];  // First line is the one with bullet point
    [paragrahStyle setHeadIndent:fUse];    // Set the indent for given bullet character and size font
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragrahStyle
                             range:NSMakeRange(0, [refineRule length])];
    
    DetailLabel.attributedText =attributedString;
}


-(id)CheckIfSaved{
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
    [fetchRequest setEntity:entity];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cId=%@", idd];
    [fetchRequest setPredicate:predicate];
    NSError *error = nil;
    NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (fetchedObjects == nil) {
        NSLog(@"Fetch error, something's wrong. %@",error);
        return nil;
    }
    else{
        if([fetchedObjects count]>0){
            return [fetchedObjects objectAtIndex:0];
        }else{
            return nil;
        }
    }
}

-(IBAction)ClickedLowBtn:(id)sender{
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delayDel)
               withObject:nil
               afterDelay:0.1];
}



-(void)delayDel{
    if ([PostMethodUse getBeforeVoiceOut]){
        NSManagedObject* mo = [self CheckIfSaved];
        //Kill
        AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
        [managedObjectContext deleteObject:mo];
        [appDelegate saveContext];
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self performSelector:@selector(delayDel)
                   withObject:nil
                   afterDelay:0.1];
    }
}

-(IBAction)clickedRefresh:(id)sender{
    if([PostMethodUse connectedToInternet]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayRefresh)
                   withObject:nil
                   afterDelay:0.1];
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}

-(void)delayRefresh{
    if([PostMethodUse connectedToInternet]){
        if ([PostMethodUse getBeforeVoiceOut]){
            [self delayRefreshCore];
            UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, [NavItem rightBarButtonItem]);
            [PostMethodUse AfterLoadingLayoutUse];
        }else{
            
            [self performSelector:@selector(delayRefresh)
                       withObject:nil
                       afterDelay:0.1];
        }
    }else{
        [PostMethodUse PopUpNoInternetAlert];
    }
}
-(void) delayRefreshCore{
    //
    {
        NSMutableDictionary* QueryDictA = [PostMethodUse PostMethodWithFunctionString:[NSString stringWithFormat:@"m=search_coupon&cid[]=%@", idd]];
        {
            AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
            NSManagedObjectContext *managedObjectContext= [appDelegate GeneralGetContext];
            
            NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
            NSEntityDescription *entity = [NSEntityDescription entityForName:@"MyCoupon" inManagedObjectContext: managedObjectContext];
            [fetchRequest setEntity:entity];
            
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cId=%@", idd];
            [fetchRequest setPredicate:predicate];
            NSError *error = nil;
            NSArray *fetchedObjects = [ managedObjectContext executeFetchRequest:fetchRequest error:&error];
            if (fetchedObjects == nil) {
                NSLog(@"Fetch error, something's wrong. %@",error);
            }
            else{
                if([fetchedObjects count]>0){
                    for(NSString* key in QueryDictA)
                    {
                        NSMutableDictionary* dict = [QueryDictA objectForKey:key];
                        couponContent = [StringUnity RefinedString:[dict objectForKey:@"couponContent"]];
                        couponName = [StringUnity RefinedString:[dict objectForKey:@"couponName"]];
                        couponRule = [StringUnity RefinedString:[dict objectForKey:@"couponRule"]];
                        couponRestaurant = [StringUnity RefinedString:[dict objectForKey:@"companyName"]];
                        NSString* deadline = [dict objectForKey:@"deadline"];
                        NSString* publishDate = [dict objectForKey:@"publishDate"];
                        NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
                        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                        StartD = [formatter dateFromString:publishDate];
                        StopD = [formatter dateFromString:deadline];
                        NSManagedObject* NSMO = [fetchedObjects objectAtIndex:0];
                        [NSMO setValue:idd forKey:@"cId"];
                        [NSMO setValue:couponContent forKey:@"couponContent"];
                        [NSMO setValue:couponName forKey:@"couponName"];
                        [NSMO setValue:couponRule forKey:@"couponRule"];
                        [NSMO setValue:couponRestaurant forKey:@"couponRestaurant"];
                        [NSMO setValue:StartD forKey:@"startTime"];
                        [NSMO setValue:StopD forKey:@"stopTime"];
                    }
                }else{
                    //NSLog(@"Nothing Left");
                }
            }
            
            [appDelegate saveContext];
        }
    }
    [self ReloadLayout];
}



#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        
        [self ReloadLayout];
        
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,MyPanel.bounds.size.height);
    [myScroll setContentSize:CGSizeMake(0,MyPanel.bounds.size.height)];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    //Location
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

-(void)viewWillAppear:(BOOL)animated{
    [PostMethodUse setIsFavourite:NO];
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self setTabBarOutLook];
    [self setFontSizes];
    
    
    //Load Item Use
    //[self ReloadLayout];   // called in setFont already;
    
    //NSLog(@"");
    
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];}


#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
         [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}
@end
