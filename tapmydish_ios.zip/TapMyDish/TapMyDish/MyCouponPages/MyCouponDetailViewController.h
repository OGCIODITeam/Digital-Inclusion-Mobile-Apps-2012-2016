//
//  MyCouponDetailViewController.h
//  TapMyDish
//
//  Created by BDMacMini1 on 25/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCouponDetailViewController : UIViewController<UITabBarDelegate>


-(void)LoadCouponDetail:(NSString*) cId;

@end
