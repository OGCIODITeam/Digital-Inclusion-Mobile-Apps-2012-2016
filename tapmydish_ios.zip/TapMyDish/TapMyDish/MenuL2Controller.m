//
//  MenuL2Controller.m
//  TapMyDish
//
//  Created by BDMacMini1 on 25/10/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import "MenuL2Controller.h"
#import "StringUnity.h"
#import "TabItemArrow.h"
#import "MenuL3Controller.h"
#import "PostMethodUse.h"
#import "UIImage_withColor.h"

@interface MenuL2Controller (){
    __weak IBOutlet UITabBar* tabBar;
    __weak IBOutlet UIScrollView* myScroll;
    __weak IBOutlet UIView* MyPanel;
    __weak IBOutlet UINavigationItem* NavItem;
    
    
    //Font Size Short Hand
    CGFloat fSUse;
    CGFloat fUse;
    
    
    NSMutableDictionary* QueryDict;
    int ML1ChosenIndex;
    int ML2ChosenIndex;
    
    NSMutableDictionary* M2Dict;
    NSArray* M2DisplayOrder;
}
@end

@implementation MenuL2Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewDidAppear:(BOOL)animated{
    [self setFontSizes];
    [PostMethodUse AfterLoadingLayoutUse];
    UIAccessibilityPostNotification(UIAccessibilityLayoutChangedNotification, self.navigationController.navigationBar);
}

-(void)viewWillAppear:(BOOL)animated{
    UINavigationController* theController = self.navigationController;
    //[theController setNavigationBarHidden:NO];
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self setTabBarOutLook];
    [self setFontSizes];
    
    //Load Item Use
    //[self ReloadLayout];   // called in setFont already;
    
    //NSLog(@"");
    
    
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}


-(void) LoadDataFromML1Page:(NSMutableDictionary*) TheDict andPassKey:(int)index{
    QueryDict = TheDict;
    ML1ChosenIndex = index;
    M2Dict = [[TheDict objectForKey:@"menu"]objectForKey:[NSString stringWithFormat:@"%d",index]];
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([[segue identifier] isEqualToString:@"GoToML3"]){
        MenuL3Controller* dest = segue.destinationViewController;
        [dest LoadDataFromML2Page:QueryDict andPassM1Key:ML1ChosenIndex andPassM2Key:ML2ChosenIndex];
    }
}
-(BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender{
    BOOL b = [PostMethodUse connectedToInternet];
    if (!b){
        //Alert
        [PostMethodUse AfterLoadingLayoutUse];
        [PostMethodUse PopUpNoInternetAlert];
    }
    return b;
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Check valid by codes
    if ([self shouldPerformSegueWithIdentifier:identifier sender:sender] == NO) {
        return;
    }
    
    // If this identifier is OK, call `super` method for `-prepareForSegue:sender:`
    [super performSegueWithIdentifier:identifier sender:sender];
}


-(void) ReloadLayout{
    while ([MyPanel.subviews count]>0){
        [[MyPanel.subviews objectAtIndex:0] removeFromSuperview];
    }
    NSMutableDictionary* m2dictInner =[M2Dict objectForKey:@"m2"];
    NavItem.title = [StringUnity RefinedString:[M2Dict objectForKey:@"t"]];
    NSDate * nowDate = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone localTimeZone]];
    [dateFormatter setDateFormat:@"HH:mm:ss"];
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setTimeZone:[NSTimeZone localTimeZone]];
    [dateFormatter1 setDateFormat:@"yyyy/MM/dd"];
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
    [dateFormatter2 setTimeZone:[NSTimeZone localTimeZone]];
    [dateFormatter2 setDateFormat:@"yyyy/MM/dd HH:mm:ss"];
    NSString * DateHead = [dateFormatter1 stringFromDate:nowDate];
    NSString * DateTail = [dateFormatter stringFromDate:nowDate];
    //Weight
    NSMutableDictionary* KeyOrder = [NSMutableDictionary dictionaryWithCapacity:0];
    for (NSString * key in m2dictInner){
        NSMutableDictionary* nowTargetMenu = [m2dictInner objectForKey:key];
        NSString* ST = [nowTargetMenu objectForKey:@"startTime"];
        NSString* ET = [nowTargetMenu objectForKey:@"endTime"];
        if ([ST isEqualToString:@"00:00:00"] &&[ET isEqualToString:@"00:00:00"]){
            //Full day type1
            //Add 1 day
            NSDate* d = [nowDate dateByAddingTimeInterval:60*60*24];
            NSMutableDictionary* nsd =[[NSMutableDictionary alloc] initWithCapacity:0];
            [nsd setObject:d forKey:@"date"];
            [nsd setObject:key forKey:@"key"];
            [KeyOrder setObject:nsd forKey:key];
        }else
        if ([ST isEqualToString:@"00:00:00"] &&[ET isEqualToString:@"23:59:59"]){
            //Full day type2
            //Add 1 day
            NSDate* d = [nowDate dateByAddingTimeInterval:60*60*24];
            NSMutableDictionary* nsd =[[NSMutableDictionary alloc] initWithCapacity:0];
            [nsd setObject:d forKey:@"date"];
            [nsd setObject:key forKey:@"key"];
            [KeyOrder setObject:nsd forKey:key];
        }
        else{
            //Change to official time value
            ST = [NSString stringWithFormat:@"%@ %@",DateHead,ST];
            ET = [NSString stringWithFormat:@"%@ %@",DateHead,ET];
            NSDate* startDate = [dateFormatter2 dateFromString:ST];
            NSDate* endDate = [dateFormatter2 dateFromString:ET];
            //Start Compare
            if (([startDate compare:nowDate]==NSOrderedAscending || [startDate compare:nowDate] == NSOrderedSame) && ([endDate compare:nowDate]==NSOrderedDescending || [endDate compare:nowDate] == NSOrderedSame)){
                NSDate* d = nowDate;
                NSMutableDictionary* nsd =[[NSMutableDictionary alloc] initWithCapacity:0];
                [nsd setObject:d forKey:@"date"];
                [nsd setObject:key forKey:@"key"];
                [KeyOrder setObject:nsd forKey:key];
            }else if([endDate compare:nowDate]==NSOrderedAscending ){
                NSDate* d = [startDate dateByAddingTimeInterval:60*60*24*2];
                NSMutableDictionary* nsd =[[NSMutableDictionary alloc] initWithCapacity:0];
                [nsd setObject:d forKey:@"date"];
                [nsd setObject:key forKey:@"key"];
                [KeyOrder setObject:nsd forKey:key];
            }else if([startDate compare:nowDate]==NSOrderedDescending){
                NSMutableDictionary* nsd =[[NSMutableDictionary alloc] initWithCapacity:0];
                [nsd setObject:startDate forKey:@"date"];
                [nsd setObject:key forKey:@"key"];
                [KeyOrder setObject:nsd forKey:key];
            }else {
                NSDate* d = [nowDate dateByAddingTimeInterval:60*60*24*3];
                NSMutableDictionary* nsd =[[NSMutableDictionary alloc] initWithCapacity:0];
                [nsd setObject:d forKey:@"date"];
                [nsd setObject:key forKey:@"key"];
                [KeyOrder setObject:nsd forKey:key];
            }
        }
    }
    //Sort
    M2DisplayOrder = [self SortResult:KeyOrder];
    //NSLog(@"%@",M2DisplayOrder);
    //ADD here
    {
        UIView * LastTarget = MyPanel;
        for (int i =0;i<M2DisplayOrder.count; i++){
            NSString* key = [M2DisplayOrder objectAtIndex:i];
            NSMutableDictionary* nowt =  [m2dictInner objectForKey:key];
            TabItemArrow* arrow = [[TabItemArrow alloc] initWithFrame:CGRectZero];
            [arrow setLabelText:[StringUnity RefinedString:[nowt objectForKey:@"t"]]];
            [arrow setFontSize:fUse];
            [arrow.LabelButtonForClick setTag:[key integerValue]];
            [arrow.LabelButtonForClick addTarget:self action:@selector(ClickedItem:) forControlEvents:(UIControlEventTouchUpInside)];
            [MyPanel addSubview:arrow];
            //Position
            [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:MyPanel attribute:NSLayoutAttributeLeft multiplier:1 constant:8]];
            [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:MyPanel attribute:NSLayoutAttributeRight multiplier:1 constant:-8]];
            if (LastTarget == MyPanel){
                [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:MyPanel attribute:NSLayoutAttributeTop multiplier:1 constant:8]];
            }else{
                [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:arrow attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:LastTarget attribute:NSLayoutAttributeBottom multiplier:1 constant:1]];
            }
            //finally
            arrow.translatesAutoresizingMaskIntoConstraints = NO;
            ////Shadow
            arrow.layer.shadowColor = [UIColor grayColor].CGColor;
            arrow.layer.shadowOffset = CGSizeMake(1, 2);
            arrow.layer.shadowOpacity = 0.5;
            arrow.layer.shadowRadius=1.0;
            LastTarget = arrow;
        }
        //Seal, need!!
        
        [MyPanel addConstraint:[NSLayoutConstraint constraintWithItem:LastTarget attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationLessThanOrEqual toItem:MyPanel attribute:NSLayoutAttributeBottom multiplier:1 constant:-8]];
    }
}

-(void)ClickedItem:(id)sender{
    UIButton* btn = (UIButton*)sender;
    ML2ChosenIndex = btn.tag;
    [PostMethodUse BeforeLoadingLayoutUse:YES];
    [self performSelector:@selector(delaySegue:)
               withObject:@"GoToML3"
               afterDelay:0.1];
    //[self performSegueWithIdentifier:@"GoToML3" sender:self];
}


-(NSArray*) SortResult:(NSMutableDictionary*)myDict{
    NSArray *myArray;
    
    myArray = [myDict keysSortedByValueUsingComparator: ^(id obj1, id obj2) {
        
        NSMutableDictionary* nsd1 = obj1;
        NSMutableDictionary* nsd2 = obj2;
        NSDate* o1 = [nsd1 objectForKey:@"date"];
        NSDate* o2 = [nsd2 objectForKey:@"date"];
        if ([o1 compare:o2] == NSOrderedSame){
            NSInteger i1 =[[nsd1 objectForKey:@"key"] integerValue];
            NSInteger i2 =[[nsd2 objectForKey:@"key"] integerValue];
            if (i1 < i2)
                return NSOrderedAscending;
            if (i1 > i2)
                return NSOrderedDescending;
            return NSOrderedSame;
        }
        
        return [o1 compare:o2];
    }];
    return myArray;
}

-(void) delaySegue:(NSString*) segueID{
    if([PostMethodUse getBeforeVoiceOut]){
        [self performSegueWithIdentifier:segueID sender:self];
    }else{
        [self performSelector:@selector(delaySegue:)
                   withObject:segueID
                   afterDelay:0.1];
    }
}

#pragma mark - Fonts
-(void)preferredContentSizeChanged:(NSNotification *)noti
{
    //static const CGFloat textScaleFactor = .8;
    //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
    [self setFontSizes];
}

-(void)setFontSizes
{
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0){
        
        //NSString *sizeString =[[UIApplication sharedApplication] preferredContentSizeCategory];
        UIFont* f = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        UIFont* fh = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        UIFont* fs =[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        //NSLog(@"%g",[f pointSize]);
        CGFloat fontSize = [f pointSize];
        CGFloat fontSizeH = [fh pointSize];
        CGFloat fontSizeS = [fs pointSize];
        
        NSInteger Size = [[NSUserDefaults standardUserDefaults] integerForKey:@"TapMyDishThreeSizes"];
        if (Size == -1){
            fontSize = fontSize*0.8;
            fontSizeH = fontSizeH*0.8;
            fontSizeS = fontSizeS*0.8;
        }else if (Size == 1){
            fontSize = fontSize*1.2;
            fontSizeH = fontSizeH*1.2;
            fontSizeS = fontSizeS*1.2;
        }
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
            fontSize = fontSize*2;
            fontSizeH= fontSizeH*2;
        }
        
        //cvheight.constant = fontSize+40;
        fSUse = fontSizeS;
        fUse = fontSize;
        //[Field2 setFont:[UIFont fontWithName:@"Heiti TC" size:fontSizeS]];
        
        [self ReloadLayout];
        
        //Reset Layout
        [self.view setNeedsLayout];
        [self.view layoutIfNeeded];
        
    }
    //Can only after refresh
    //NSLog(@"%g + %g",myScroll.bounds.size.height,MyPanel.bounds.size.height);
    [myScroll setContentSize:CGSizeMake(0,MyPanel.bounds.size.height)];
}

-(void)willMoveToParentViewController:(UIViewController *)parent{
    if (parent==nil){
        //[self.navigationController setNavigationBarHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    //No animate
    //[self.navigationController setNavigationBarHidden:YES];
    [super viewWillDisappear:animated];
}

#pragma mark - Tab bar outlook
-(void) setTabBarOutLook{
    BOOL isNoColor = [[NSUserDefaults standardUserDefaults] boolForKey:@"TapMyDishColorStyleIsGrey"];
    if (isNoColor){
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.317647 green:0.317647 blue:0.317647 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }else{
        [self.view setBackgroundColor:[UIColor colorWithRed:0.9098 green:0.9098 blue:0.9098 alpha:1]];
        [tabBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [tabBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [tabBar setSelectedImageTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.062745 green:0.341176 blue:0.30196 alpha:1]];
        [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]}];
    }
    // Extra Out
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width/6, tabBar.frame.size.height);
    [tabBar setSelectionIndicatorImage:[UIImage imageWithColor:[UIColor whiteColor] andBounds:rect]];
    //Menu first
    tabBar.items[0].image = [[UIImage imageNamed:@"menu_menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[1].image = [[UIImage imageNamed:@"menu_code"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[2].image = [[UIImage imageNamed:@"menu_favour"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[3].image = [[UIImage imageNamed:@"menu_coupon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[4].image = [[UIImage imageNamed:@"menu_history"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBar.items[5].image = [[UIImage imageNamed:@"menu_setting"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

}

#pragma mark - Tab bar delegate
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    if([item.title isEqualToString:@"QR掃描"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"QRCode"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"美食餐牌"]){
        if([PostMethodUse connectedToInternet]){
            [PostMethodUse BeforeLoadingLayoutUse:YES];
            [self performSelector:@selector(delayGoGoTab:)
                       withObject:@"Menu"
                       afterDelay:0.1];
        }else{
            [PostMethodUse PopUpNoInternetAlert];
        }
    }else if([item.title isEqualToString:@"我的最愛"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Favour"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的優惠"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Coupon"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"我的歷史"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"History"
                   afterDelay:0.1];
    }else if([item.title isEqualToString:@"設定"]){
        [PostMethodUse BeforeLoadingLayoutUse:YES];
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:@"Setting"
                   afterDelay:0.1];
    }
}


-(void) delayGoGoTab:(NSString*) TabName{
    if([PostMethodUse getBeforeVoiceOut]){
        [self.navigationController setViewControllers:[NSArray arrayWithObjects:self.navigationController.viewControllers[0],[self.storyboard instantiateViewControllerWithIdentifier:TabName],nil] animated:NO];
    }else{
        [self performSelector:@selector(delayGoGoTab:)
                   withObject:TabName
                   afterDelay:0.1];
    }
}


-(void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar willBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

-(void)tabBar:(UITabBar *)tabBar didEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}

-(void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}



@end
