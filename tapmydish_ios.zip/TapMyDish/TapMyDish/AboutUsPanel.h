//
//  AboutUsPanel.h
//  TapMyDish
//
//  Created by BDMacMini1 on 25/11/2016.
//  Copyright © 2016年 BigDipperStudio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsPanel : UIView
@property (strong, nonatomic) IBOutlet UIView *view;
@property (weak, nonatomic) IBOutlet UIView *BlackBack;
@property (weak, nonatomic) IBOutlet UIScrollView *myScroll;
@property (weak, nonatomic) IBOutlet UIView *myPanel;
@property (weak, nonatomic) IBOutlet UIView *Slot1;
@property (weak, nonatomic) IBOutlet UIView *Slot2;
@property (weak, nonatomic) IBOutlet UIView *Slot3;
@property (weak, nonatomic) IBOutlet UIView *Slot4;
@property (weak, nonatomic) IBOutlet UIView *ContactUsSlot;
@property (weak, nonatomic) IBOutlet UILabel *Heading1;
@property (weak, nonatomic) IBOutlet UILabel *Slot1P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot1P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading2;
@property (weak, nonatomic) IBOutlet UILabel *Slot2P1;
@property (weak, nonatomic) IBOutlet UILabel *Slot2P2;

@property (weak, nonatomic) IBOutlet UILabel *Heading3;
@property (weak, nonatomic) IBOutlet UILabel *Slot3P1;



@property (weak, nonatomic) IBOutlet UILabel *Slot4P1;
@property (weak, nonatomic) IBOutlet UIButton *WebBtn1;
@property (weak, nonatomic) IBOutlet UILabel *Heading5;
@property (weak, nonatomic) IBOutlet UILabel *Slot5P1;

@property (weak, nonatomic) IBOutlet UILabel *PhoneLabel;
@property (weak, nonatomic) IBOutlet UIButton *PhoneBtn;
@property (weak, nonatomic) IBOutlet UILabel *FaxLabel;
@property (weak, nonatomic) IBOutlet UIButton *FaxBtn;
@property (weak, nonatomic) IBOutlet UILabel *EmailLabel;
@property (weak, nonatomic) IBOutlet UIButton *EmailBtn;
@property (weak, nonatomic) IBOutlet UILabel *WebLabel;
@property (weak, nonatomic) IBOutlet UIButton *WebBtn;
@property (weak, nonatomic) IBOutlet UILabel *FBLabel;
@property (weak, nonatomic) IBOutlet UIButton *FBBtn;
@property (weak, nonatomic) IBOutlet UILabel *AddressLabel;
@property (weak, nonatomic) IBOutlet UIButton *AddressBtn;
@property (weak, nonatomic) IBOutlet UIButton *CloseBtn;

-(void)setFontSize:(CGFloat) FS;
@end
