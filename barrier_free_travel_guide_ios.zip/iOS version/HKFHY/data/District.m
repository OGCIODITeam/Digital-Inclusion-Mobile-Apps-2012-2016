//
//  District.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年8月26日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "District.h"


@implementation District

@dynamic id;
@dynamic lang;
@dynamic parent_id;
@dynamic record_id;
@dynamic seq;
@dynamic title;
@dynamic short_title;

@end
