//
//  Spot.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年9月4日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "Spot.h"


@implementation Spot

@dynamic center_lat;
@dynamic center_lng;
@dynamic content;
@dynamic district_id;
@dynamic id;
@dynamic info;
@dynamic lang;
@dynamic map_lat;
@dynamic map_lng;
@dynamic rate;
@dynamic record_id;
@dynamic seq;
@dynamic short_description;
@dynamic title;
@dynamic top_id;
@dynamic total_rated;
@dynamic transport;
@dynamic type_id;
@dynamic zoom;
@dynamic baidu_map_x;
@dynamic baidu_map_y;
@dynamic baidu_center_x;
@dynamic baidu_center_y;

@end
