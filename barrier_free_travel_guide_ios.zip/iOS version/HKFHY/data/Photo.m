//
//  Photo.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年9月5日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "Photo.h"


@implementation Photo

@dynamic alt_text;
@dynamic file_name;
@dynamic id;
@dynamic lang;
@dynamic parent_id;
@dynamic org_path;

@end
