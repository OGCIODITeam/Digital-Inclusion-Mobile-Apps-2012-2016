//
//  Location.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年9月4日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "Location.h"


@implementation Location

@dynamic content;
@dynamic id;
@dynamic lang;
@dynamic map_lat;
@dynamic map_lng;
@dynamic open_time;
@dynamic record_id;
@dynamic seq;
@dynamic title;
@dynamic type_id;
@dynamic baidu_map_y;
@dynamic baidu_map_x;

@end
