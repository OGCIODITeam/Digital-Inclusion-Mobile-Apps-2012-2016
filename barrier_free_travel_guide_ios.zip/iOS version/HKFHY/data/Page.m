//
//  Page.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年8月23日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "Page.h"


@implementation Page

@dynamic id;
@dynamic record_id;
@dynamic parent_id;
@dynamic title;
@dynamic content;
@dynamic seq;
@dynamic lang;

@end
