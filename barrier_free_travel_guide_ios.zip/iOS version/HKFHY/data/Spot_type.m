//
//  Spot_type.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年8月21日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "Spot_type.h"


@implementation Spot_type

@dynamic id;
@dynamic record_id;
@dynamic title;
@dynamic seq;
@dynamic lang;

@end
