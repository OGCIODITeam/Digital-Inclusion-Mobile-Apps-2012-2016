//
//  Dummy.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年8月31日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "Dummy.h"

@implementation Dummy

@end
