//
//  CustomBMKPointAnnotation.h
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年9月1日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "BMKPointAnnotation.h"

@interface CustomBMKPointAnnotation : BMKPointAnnotation

@property(nonatomic, retain) NSString *refID;

@end
