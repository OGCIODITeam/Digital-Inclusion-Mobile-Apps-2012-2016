//
//  CustomBMKPointAnnotation.m
//  HKFHY
//
//  Created by Tsang Tsz Kit on 13年9月1日.
//  Copyright (c) 2013年 James Tsang. All rights reserved.
//

#import "CustomBMKPointAnnotation.h"

@implementation CustomBMKPointAnnotation

@end
