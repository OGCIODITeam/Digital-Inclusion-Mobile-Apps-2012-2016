/** Automatically generated file. DO NOT MODIFY */
package hk.org.deaf.asrtraining;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}