package bean;

public class DbExam {
	int examId=0;
	String examJson = "";
	long version=0l;
	
	public DbExam (int examId){
		this.examId = examId;
	}
	
	public DbExam (int examId, String examJson){
		this.examId = examId;
		this.examJson = examJson;
	}
	
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public String getExamJson() {
		return examJson;
	}
	public void setExamJson(String examJson) {
		this.examJson = examJson;
	}
	public long getVersion() {
		return version;
	}
	public void setVersion(long version) {
		this.version = version;
	}
}
