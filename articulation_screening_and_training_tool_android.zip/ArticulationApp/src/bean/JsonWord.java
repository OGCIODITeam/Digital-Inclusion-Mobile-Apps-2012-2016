package bean;

public class JsonWord {
  
	int id = 0;
	int questionId = 0;
    int sequence = 0;
    int isCorrect = 0;
    long pictureUploadDate = 0l;
    long soundUploadDate = 0l;
    String initial = "";
    String vowel = "";
    String word = "";
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public int getIsCorrect() {
		return isCorrect;
	}
	public void setIsCorrect(int isCorrect) {
		this.isCorrect = isCorrect;
	}
	public long getPictureUploadDate() {
		return pictureUploadDate;
	}
	public void setPictureUploadDate(long pictureUploadDate) {
		this.pictureUploadDate = pictureUploadDate;
	}
	public long getSoundUploadDate() {
		return soundUploadDate;
	}
	public void setSoundUploadDate(long soundUploadDate) {
		this.soundUploadDate = soundUploadDate;
	}
	public String getInitial() {
		return initial;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public String getVowel() {
		return vowel;
	}
	public void setVowel(String vowel) {
		this.vowel = vowel;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
    
}
