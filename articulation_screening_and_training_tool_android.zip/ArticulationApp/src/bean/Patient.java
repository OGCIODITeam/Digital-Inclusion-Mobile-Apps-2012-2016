package bean;

public class Patient {
	
	public static int id = 0;
	public static String name = "";
	public static String email = "";
	public static int yob = 0;// year of birth
	public static int centerId = 0;
	public static String tel = "";
	
	public static String gender = "";
	public static String hearing = "";
	
	public static void reset(){
		id = 0;
		name = "";
		email = "";
		yob = 0;
		centerId = 0;
		tel = "";
		
		gender = "";
		hearing = "";
	}
}
