package bean;

public class JsonWord_M03 {
	
	int examId = 0;
	String examName = "";
	int wordId = 0;
    int questionId = 0;
    String initial = "";
    String vowel = "";
    String word = "";  
    long pictureUploadDate = 0l;
    long soundUploadDate = 0l;

    
    public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public String getExamName() {
		return examName;
	}
	public void setExamName(String examName) {
		this.examName = examName;
	}
	public int getWordId() {
		return wordId;
	}
	public void setWordId(int wordId) {
		this.wordId = wordId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getInitial() {
		return initial;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public String getVowel() {
		return vowel;
	}
	public void setVowel(String vowel) {
		this.vowel = vowel;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public long getPictureUploadDate() {
		return pictureUploadDate;
	}
	public void setPictureUploadDate(long pictureUploadDate) {
		this.pictureUploadDate = pictureUploadDate;
	}
	public long getSoundUploadDate() {
		return soundUploadDate;
	}
	public void setSoundUploadDate(long soundUploadDate) {
		this.soundUploadDate = soundUploadDate;
	}

}
