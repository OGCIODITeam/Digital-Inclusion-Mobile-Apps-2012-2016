package bean;

public class ReportExam {
	int moduleId = 0;
	int examId = 0;
	String examName = "";
	int isTested = 0; // 1=tested, 0 not test
	int correct = 0; // number of correct question
	int total = 0; // total number of question
	long timeUse = 0l; // in second
	int sugPractice = 0; // 1 needed practice
	
	public ReportExam(){}
	
	public ReportExam(int moduleId, int examId, int correct, int total, long timeUse){
		this.moduleId = moduleId;
		this.examId = examId;
		this.isTested = 1; // set exam tested
		this.correct = correct; 
		this.total = total; 
		this.timeUse = timeUse; 
	}
	//* for exam3 module3 module_initial_a
	public ReportExam(int moduleId, int examId, String examName, int correct, int total){
		this.moduleId = moduleId;
		this.examId = examId;
		this.examName = examName;
		this.correct = correct; // score for m03
		this.total = total; // no of qty for m03
	}
	
	public int getModuleId() {
		return moduleId;
	}
	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	
	public String getExamName() {
		return examName;
	}

	public void setExamName(String examName) {
		this.examName = examName;
	}

	public int getIsTested() {
		return isTested;
	}
	public void setIsTested(int isTested) {
		this.isTested = isTested;
	}
	public int getCorrect() {
		return correct;
	}
	public void setCorrect(int correct) {
		this.correct = correct;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public long getTimeUse() {
		return timeUse;
	}
	public void setTimeUse(long timeUse) {
		this.timeUse = timeUse;
	}
	public int getSugPractice() {
		return sugPractice;
	}
	public void setSugPractice(int sugPractice) {
		this.sugPractice = sugPractice;
	}
	
}
