package bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

public class Current {

	public static String filePath = ""; //**all image, voice, audio file path
	public static int module = 0; // 1=聆聽評估, 2=聆聽練習, 3=前置輔音評估, 4=前置輔音練習,
	public static int conson = 0; // selected consonant
	public static int type = 0; // 1=單字, 2=句子, 3=錄音
	public static int examId = 0; //selected exam
	public static String examName="";
	public static String page="";
	public static String version ="";
	public static String versionDesc="";
	public static String userAge = "";
	public static String patientAge = "";

	// Module
	public static final int module_listen_a = 1; // 聆聽評估
	public static final int module_listen_p = 2; // 聆聽練習
	public static final int module_initial_a = 3; // 前置輔音評估
	public static final int module_initial_p = 4; // 前置輔音練習

	// Type
	public static final int type_word = 1; // 單字
	public static final int type_sentence = 2; // 句子
	public static final int type_record = 3; // 錄音

	//Exam List
	public static ArrayList<JsonExam> examList;
	
	//Question Map
	public static TreeMap<Integer, ArrayList<JsonWord>> qtyMap = null;
	public static TreeMap<Integer, ArrayList<Integer>> ansMap = null;
	public static HashMap<Integer, JsonWord_M03> m03Map = null; //<qtyOd, word>
	
	//For Report
	public static long startTime = 0l;
	public static long endTime = 0l;
	public static HashMap<String, String> correctMap = null;
	public static HashMap<String, String> errorMap = null;
	public static HashMap<Integer, String> practiceList = null;
//	public static ArrayList<Integer> practiceList = null;
	public static TreeMap<Integer, ReportExam> m03Report = null;//for  module 03 report
}
