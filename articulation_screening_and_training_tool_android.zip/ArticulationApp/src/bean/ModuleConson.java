package bean;

public class ModuleConson {

	int moduleId = 0;
	int typeId = 0;
	String consonJson = "";
	long version = 0l;

	public ModuleConson(int moduleId, int typeId){
		this.moduleId = moduleId;
		this.typeId = typeId;
	}
	
	public ModuleConson(int moduleId, int typeId, String consonJson){
		this.moduleId = moduleId;
		this.typeId = typeId;
		this.consonJson = consonJson;
	}
	
	public int getModuleId() {
		return moduleId;
	}

	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getConsonJson() {
		return consonJson;
	}

	public void setConsonJson(String consonJson) {
		this.consonJson = consonJson;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}
}
