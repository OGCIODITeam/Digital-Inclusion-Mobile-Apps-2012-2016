package bean;

public class User {

	public static int id = 0;
	public static String token = "";
	public static String email = "";
	public static String name = "";
	public static String yob="0"; //year of birth
	public static String password = "";
	public static boolean isST = false; 
	public static boolean isAssess = false;
	
	public static String gender = "";
	public static String hearing = "";
	
	public static void reset(){
		id = 0;
		token = "";
		email = "";
		name = "";
		yob="0"; //year of birth
		password = "";
		isST = false;
		isAssess = false;
		
		gender="";
		hearing="";
	}
}
