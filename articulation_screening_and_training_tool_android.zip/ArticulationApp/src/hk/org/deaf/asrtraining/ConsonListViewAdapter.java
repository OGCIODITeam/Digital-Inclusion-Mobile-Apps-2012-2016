package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.JsonExam;

public class ConsonListViewAdapter extends BaseAdapter {

	private static String tag = "ConsonAdapter";
	private Activity act;
	private ArrayList<HashMap<String, JsonExam>> list;

	public ConsonListViewAdapter(Activity act) {
		this.act = act;
		convertList();
	}

	private void convertList() {
		list = new ArrayList<HashMap<String, JsonExam>>();
		if (Current.examList != null) {
			int examSize = Current.examList.size();
			boolean isOdd = false;
			if (examSize % 2 == 1)
				isOdd = true;
			HashMap<String, JsonExam> map = new HashMap<String, JsonExam>();
			for (int i = 1; i <= examSize; i++) {
				if (i % 2 == 1) {
					map = new HashMap<String, JsonExam>();
					map.put("conson01", Current.examList.get(i - 1));
				} else {
					map.put("conson02", Current.examList.get(i - 1));
					list.add(map);
				}
				if (i == examSize && isOdd) {
					list.add(map);
				}
			}
		}
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	private class ViewHolder {
		TextView conson01;
		TextView conson02;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder;
		LayoutInflater inflater = act.getLayoutInflater();
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.cell_conson, null);
			holder = new ViewHolder();
			holder.conson01 = (TextView) convertView
					.findViewById(R.id.text_conson01);
			holder.conson02 = (TextView) convertView
					.findViewById(R.id.text_conson02);
			holder.conson01.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Toast.makeText(act, "01= " + v.getTag().toString(),
							Toast.LENGTH_SHORT).show();
//					ModuleConsonantFragment.examClick();
				}
			});
			holder.conson02.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Toast.makeText(act, "02= " + v.getTag().toString(),
							Toast.LENGTH_SHORT).show();

				}
			});
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		HashMap<String, JsonExam> map = list.get(position);
		holder.conson01.setText(map.get("conson01").getName());
		holder.conson01.setTag(map.get("conson01").getId());
		if (map.get("conson02") != null) {
			holder.conson02.setVisibility(View.VISIBLE);
			holder.conson02.setTag(map.get("conson02").getId());
			holder.conson02.setText(map.get("conson02").getName());
		} else {
			holder.conson02.setVisibility(View.INVISIBLE);
		}

		return convertView;
	}
	
}
