package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;
import manager.AudioCapture;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;
import manager.PageManager;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import bean.Current;
import bean.User;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.Tracker;

import config.Conf;
import config.I;
import config.Link;
import config.URLs;

public class LaunchActivity extends ActionBarActivity {

	private static String tag = "LaunchActivity";
	private LaunchActivity launchAct = this;
	public static int appVersion = 0;
	public static String appVerName="";
	
	// private AudioManager audio;
	private Handler mThreadHandler;
	private HandlerThread mThread;
	
	private SharedPreferences sp;
	private boolean autoLoginSuccess = false;
	
	private TextView text_version;
	private Tracker t;
	
	private CountDownTimer cd;
	
	private AlertDialog daRetry;
	private Boolean isServerError = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(tag, "OS version: " + I.osVersion);
		Log.i(tag, "API Level: " + I.apiLevel);
		Log.i(tag, "Android version: " + I.androidVersion);
		Log.i(tag, "Device: " + I.device);
		Log.i(tag, "Model: " + I.model);
		Log.i(tag, "Product: " + I.model);
		Log.i(tag, "Brand: " + I.brand);

		setContentView(R.layout.activity_launch);
		text_version = (TextView) findViewById(R.id.text_version);
		Current.page = tag;
		//CountDown
		cd = new myCountDown(3000,500);
		
		// get App Version
		try {
			PackageManager manager = this.getPackageManager();
			PackageInfo info = manager.getPackageInfo(this.getPackageName(), 0);
			Log.i(tag, "info= " + info.toString());
			appVersion = info.versionCode;
			appVerName = info.versionName;
			Log.i(tag, "appVersion= " + appVersion+" name= "+appVerName);
			
			setAppVersion();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//init folder
		Current.filePath = getExternalFilesDir(Conf.materialFolder).toString();
		AudioCapture.initAudioFolder();
		
		try {
//			delOldFolder();
		} catch (Exception e){e.printStackTrace();}
		
		// Thread
		mThread = new HandlerThread("LaunchActivityHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		//init User
		sp = getSharedPreferences(Conf.SP_NAME, 0);
		User.id = sp.getInt("id", 0);
		User.token = sp.getString("token", "");
		User.email = sp.getString("email", "");
		User.name = sp.getString("name", "");
		User.yob = sp.getString("yob", "0"); 
		User.isST = sp.getBoolean("isST", false);
		User.gender = sp.getString("gender", "");
		User.hearing = sp.getString("hearing", "");

		//GA
		t = ((MyAnalytics) launchAct.getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		ImageView img_launch = (ImageView) findViewById(R.id.img_launch);
		img_launch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cd.cancel();
				toLogin();
//				LoadingDialog.startDA(launchAct);
//				
//				Intent i = new Intent();
//				if (InternetState.isOnline(launchAct)) {
//					boolean isValid = true;
//					if ( User.id <=0 
//						|| User.token == null || User.token.trim().equals("")
//						|| User.email == null || User.email.trim().equals("")
////						|| User.name == null || User.name.trim().equals("")
//						|| User.yob == null || User.yob.trim().equals("")
//							) {
//						isValid = false;
//					}
//					if (isValid) {
//						try {
//							mThreadHandler.post(executeAutoLogin);
//							synchronized (executeAutoLogin) {
//								executeAutoLogin.wait();
//							}
//						} catch (Exception e) {}
//						if (autoLoginSuccess){
//							// auto login success to module selection page
//							GA_Util.sendBtnEvent(t, tag, "Auto Login");
//							i.setClass(launchAct, ExamActivity.class);
//						} else {
//							// not success to login oage
//							i.setClass(launchAct, LoginActivity.class);
//						}
//					} else {
//						// not valid to login oage
//						i.setClass(launchAct, LoginActivity.class);
//					}
//				} else {
//					// no intent to login oage
//					i.setClass(launchAct, LoginActivity.class);
//				}
//				
//				startActivity(i);
//				overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
//				launchAct.finish();
			}
		});
		
		cd.start();
	}
	
	private Runnable executeAutoLogin = new Runnable(){
		public void run(){
			String url = URLs.getAutoLoginURL(User.id);
			try {
				JSONObject json = GetJSON.doGet(url, true);
				if (json!=null) {
					isServerError = false;
					String result = json.getString("isValid");
					if (result !=null && result.equals("true")) {
						//success case
						autoLoginSuccess = true;
					} else {
						// fail
						autoLoginSuccess = false;
					}
				} else {
					isServerError = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			User.password = null; //* clear password
			synchronized (executeAutoLogin) {
				executeAutoLogin.notify();
			}
		}
	};
	
	private void toLogin(){
//		LoadingDialog.startDA(launchAct);
		Intent i = new Intent();
		if (InternetState.isOnline(launchAct)) {
			boolean isValid = true;
			if ( User.id <=0 
				|| User.token == null || User.token.trim().equals("")
				|| User.email == null || User.email.trim().equals("")
//				|| User.name == null || User.name.trim().equals("")
				|| User.yob == null || User.yob.trim().equals("")
					) {
				isValid = false;
			}
			if (isValid) {
				try {
					mThreadHandler.post(executeAutoLogin);
					synchronized (executeAutoLogin) {
						executeAutoLogin.wait();
					}
					if (!isServerError) {
						if (autoLoginSuccess){
							// auto login success to module selection page
							GA_Util.sendBtnEvent(t, tag, "Auto Login");
							i.setClass(launchAct, ExamActivity.class);
						} else {
							// not success to login oage
							i.setClass(launchAct, LoginActivity.class);
						}
						startActivity(i);
						overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
						launchAct.finish();
					} else {
						showRetry(R.string.network_error);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
//				if (autoLoginSuccess){
//					// auto login success to module selection page
//					GA_Util.sendBtnEvent(t, tag, "Auto Login");
//					i.setClass(launchAct, ExamActivity.class);
//				} else {
//					// not success to login oage
//					i.setClass(launchAct, LoginActivity.class);
//				}
			} else {
				// not valid to login oage
				i.setClass(launchAct, LoginActivity.class);
				startActivity(i);
				overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
				launchAct.finish();
			}
			//20150306
//			startActivity(i);
//			overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
//			launchAct.finish();
		} else {
//			// no intent to login oage
//			i.setClass(launchAct, LoginActivity.class);
			showRetry(R.string.no_network_connection);
		}
		
//		startActivity(i);
//		overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
//		launchAct.finish();
	}
	
	private void showRetry(int msgId) {
		if (daRetry==null) {
			Builder builder = new AlertDialog.Builder(launchAct);
			builder.setTitle(R.string.attention);
			builder.setMessage(msgId);
			builder.setPositiveButton(R.string.retry, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// try resubmit
					if (daRetry !=null) daRetry.dismiss();
					daRetry = null;
					toLogin();
					
				}
			});
			
			builder.setNegativeButton(R.string.leave, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (daRetry !=null) daRetry.dismiss();
					System.exit(0);
				}
			});
			daRetry = builder.create();
		}
		if (daRetry!=null) daRetry.dismiss();
 		daRetry.show();
	}
	
	private class myCountDown extends CountDownTimer {
		public myCountDown(long total, long unit) {
			super(total, unit);
		}

		@Override
		public void onFinish() {
			toLogin();
		}

		@Override
		public void onTick(long millisUntilFinished) {
		}
		
	}

	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (PageManager.setDeviceButtonClickEvent(launchAct, keyCode)) {
			return true;
		} else {
			return super.onKeyDown(keyCode, event);
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.launch, menu);
		// return true;
		return false;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		GoogleAnalytics.getInstance(launchAct).reportActivityStart(launchAct);
//		GA
//		t = ((MyAnalytics) launchAct.getApplication()).getTracker(
//	            TrackerName.APP_TRACKER);
//		GA_Util.sendScreen(launchAct, t, tag);
	}

	@Override
	protected void onStop() {
		super.onStop();
		LoadingDialog.endDA();
		GoogleAnalytics.getInstance(launchAct).reportActivityStop(launchAct);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (daRetry!=null){
			daRetry.dismiss();
			daRetry = null;
		}
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeAutoLogin);
		}
		if (mThread != null) {
			mThread.quit();
		}
	}
	
	private void setAppVersion() {
		// for accessibility
		String[] verArr = appVerName.split("\\.");
		String verStr = "版本 ";
		for (int i=0; i<verArr.length; i++){
			if (i==(verArr.length-1)) verStr += verArr[i];
			else verStr += verArr[i] +"點";
		}
		if (Link.domain.equals(Link.URLDEV)) {
			Current.version = "dev codeVer: "+appVersion+" appVer: "+appVerName;
			text_version.setText(Current.version);
		} if (Link.domain.equals(Link.URLUAT)) {
			Current.version = "3Tech: "+appVerName;
			text_version.setText(Current.version);
		} if (Link.domain.equals(Link.URLPRODM)) {
			Current.version = "v: "+appVerName;
			text_version.setText(Current.version);
		}
		text_version.setContentDescription(verStr);
		Current.versionDesc = verStr;
	}
	//TODO del all old folder, remove function after two version update current 1.0.2
//	private void delOldFolder(){
//		File old = new File(Environment.getExternalStorageDirectory()+"/.ArticulationApp");
//		if (old!=null && old.exists()){
//			DeleteRecursive(old);
//		}
//	}
//	
//	private void DeleteRecursive(File fileOrDirectory) {
//		 if (fileOrDirectory.isDirectory())
//		    for (File child : fileOrDirectory.listFiles())
//		        DeleteRecursive(child);
//		    fileOrDirectory.delete();
//	}

}
