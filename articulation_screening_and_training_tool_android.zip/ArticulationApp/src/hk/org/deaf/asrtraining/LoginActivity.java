package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.Tracker;

import bean.Current;
import bean.User;
import manager.GA_Util;
import manager.MyAnalytics;
import manager.PageManager;
import manager.MyAnalytics.TrackerName;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RadioButton;

public class LoginActivity extends FragmentActivity { // *below 3.0
// *above 3.0 public class LoginActivity extends Activity {
	private final String tag = "LoginActivity";
	private LoginActivity loginAct = this;
	//for About Us page
	public static int tacType=0; //** 1 = about us, 2 = manual, 3 = disclaimer
	private Tracker t;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		Current.page = tag;
		

		
		LoginFragment f = new LoginFragment();
		FragmentTransaction fragmentTransaction = getSupportFragmentManager()
				.beginTransaction();
		fragmentTransaction.replace(R.id.form_content, f); // replace new layout
		// fragmentTransaction.addToBackStack(null); //* not add this function can auto kill app
		fragmentTransaction.commit();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (PageManager.setDeviceButtonClickEvent(loginAct, keyCode)) {
			return true;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}
	@Override
	protected void onStart() {
		super.onStart();
		GoogleAnalytics.getInstance(loginAct).reportActivityStart(loginAct);
//		GA
		t = ((MyAnalytics) loginAct.getApplication()).getTracker(
	            TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
	}

	@Override
	protected void onStop() {
		super.onStop();
		GoogleAnalytics.getInstance(loginAct).reportActivityStop(loginAct);
	}
	public void onGenderButtonClicked(View view) {
	    // Is the button now checked?
	    boolean checked = ((RadioButton) view).isChecked();
	    
	    // Check which radio button was clicked
	    switch(view.getId()) {
	        case R.id.radio_m:
	            if (checked)
	                User.gender = "M";
	            break;
	        case R.id.radio_f:
	            if (checked)
	                User.gender = "F";
	            break;
	    }
	}
	
	public void onHearingButtonClicked(View view) {
	    // Is the button now checked?
	    boolean checked = ((RadioButton) view).isChecked();
	    
	    // Check which radio button was clicked
	    switch(view.getId()) {
	        case R.id.radio_nh:
	            if (checked)
	                User.hearing = "NH";
	            break;
	        case R.id.radio_hi:
	            if (checked)
	                User.hearing = "HI";
	            break;
	    }
	}
	
}
