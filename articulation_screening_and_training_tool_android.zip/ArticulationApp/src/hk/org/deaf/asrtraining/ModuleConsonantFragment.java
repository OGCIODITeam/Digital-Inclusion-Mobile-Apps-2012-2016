package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import manager.ExamManager;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;
import bean.Current;
import bean.DbExam;
import bean.JsonWord;

import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import config.Conf;
import config.URLs;

public class ModuleConsonantFragment extends Fragment {
	private final String tag = "ModuleConsonantFragment";

	private View view;
	private ImageButton btn_back;
	private GridView grid_conson;

	private Handler mThreadHandler;
	private HandlerThread mThread;
	private Handler refresh;

	private SharedPreferences sp;
	private SharedPreferences.Editor spe;
	//db
	private ExamManager examManager;
	private boolean needUpdate = false;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_module_consonant, container,
				false);
		Current.page = tag;
		// Thread
		mThread = new HandlerThread("ModuleConsonantFragment");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		refresh = new Handler(Looper.getMainLooper());
		// SharedPreferences
		sp = getActivity().getSharedPreferences(Conf.SP_NAME, 0);
		spe = sp.edit();
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		initView();
		return view;
	}

	private void initView() {		
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);

		// GridView
		grid_conson = (GridView) view.findViewById(R.id.grid_conson);
		ConsonGridViewAdapter consonGridAdapter = new ConsonGridViewAdapter(
				getActivity());
		grid_conson.setAdapter(consonGridAdapter);
		
		// Listener
		grid_conson.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
//				mThreadHandler.post(executeLoading);	
//				refresh = new Handler(Looper.getMainLooper());
				
//				refresh.post(executeLoading);
				
//				try {
//					refresh.post(executeLoading);
//					synchronized (executeLoading) {
//						executeLoading.wait();
//					}
//				} catch (Exception e) {
//				}
//				synchronized (this){
//					LoadingDialog.startDA(getActivity());
//				}
				
//				Toast.makeText(
//						getActivity(),
//						".....grid position= " + position + " name= "
//								+ Current.examList.get(position).getName()
//								+ " id= "
//								+ Current.examList.get(position).getId(),
//						Toast.LENGTH_SHORT).show();

				Current.examId = Current.examList.get(position).getId(); //*set clicked exam to current exam
				Current.examName = Current.examList.get(position).getName();
				GA_Util.sendBtnEvent(t, tag, Current.examName);
				getQuestionList();
//				mThreadHandler.post(executeEndLoading);		
			}
		});

		btn_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				if (Current.module == Current.module_listen_p) {

					ModuleTypeFragment f = new ModuleTypeFragment();
					fragmentTransaction.replace(R.id.rl_main_content, f);
				} else {
					ModuleFragment f = new ModuleFragment();
					fragmentTransaction.replace(R.id.rl_main_content, f);
				}
				// fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				fragmentTransaction.commit();

			}
		});
	}

	private void getQuestionList() {
		//** any change need to update ReportFragment too
		//check version
		if (InternetState.isOnline(getActivity())) { 
			try {
				mThreadHandler.post(executeGetVersion);
				synchronized (executeGetVersion) {
					executeGetVersion.wait();
				}
			} catch (Exception e) {}
		} else {
			needUpdate = false;//* if no network read from db
		}
		
		Current.qtyMap = null; //reset question list
		Current.ansMap = null; //reset ans list
		
		if (examManager == null) examManager = new ExamManager(getActivity());
		if (!needUpdate && examManager.isExamExist(Current.examId)) { // get exam json from db
			DbExam ex = new DbExam(Current.examId);
			examManager.getExam(ex);
			try{
			JSONObject jo = new JSONObject(ex.getExamJson());
			Gson g = new Gson();
			Current.qtyMap = g.fromJson(jo.getJSONObject("questionMap").toString(),
					new TypeToken<TreeMap<Integer, ArrayList<JsonWord>>>() {}.getType());
			Current.ansMap = g.fromJson(jo.getJSONObject("answerMap").toString(),
					new TypeToken<TreeMap<Integer, ArrayList<Integer>>>() {}.getType());
			} catch (Exception e){
				Log.i(tag, "Convert DB object to json exception");
			}
		}
		if (Current.qtyMap == null || Current.examList.size() == 0){
			if (InternetState.isOnline(getActivity())) { // * getConson from server
				try {
					mThreadHandler.post(executeGetQuestion);
					synchronized (executeGetQuestion) {
						executeGetQuestion.wait();
					}
				} catch (Exception e) {
					Log.i(tag, "Get question json from server exception");
				}
			} else {
				// * Not in db and not internet connection
				Toast.makeText(getActivity(), R.string.no_network_connection,
						Toast.LENGTH_SHORT).show();
			}
		}

		if (Current.qtyMap !=null && Current.qtyMap.size()>0){
			selectFragment();
		} else {
//			LoadingDialog.endDA();
//			refresh.post(executeEndLoading);
//			mThreadHandler.post(executeEndLoading);
			Toast.makeText(getActivity(), R.string.question_empty,
					Toast.LENGTH_SHORT).show();
		}

	}
	
	private void selectFragment() {
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
//		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		if (Current.module == Current.module_listen_a) {
			Exam1Fragment f = new Exam1Fragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		} else if (Current.module == Current.module_listen_p) {
			if (Current.type == Current.type_word){
				Exam1Fragment f = new Exam1Fragment();
				fragmentTransaction.replace(R.id.rl_main_content, f);
			} else if (Current.type == Current.type_sentence){
				Exam2Fragment f = new Exam2Fragment();
				fragmentTransaction.replace(R.id.rl_main_content, f);
			}
		} else if (Current.module == Current.module_initial_a) {
			Exam3Fragment f = new Exam3Fragment();
//			BgNoiseFragment f = new BgNoiseFragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		} else if (Current.module == Current.module_initial_p) {
			Exam3Fragment f = new Exam3Fragment();
//			BgNoiseFragment f = new BgNoiseFragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		}
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}

	private Runnable executeGetQuestion = new Runnable(){
		public void run(){
			// * getQuestionJson from server
			String url = URLs.getQuestionJson(Current.module,
					Current.type, Current.examId);
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json != null) {
					Gson g = new Gson();
					Current.qtyMap = g.fromJson(json.getJSONObject("questionMap").toString(),
							new TypeToken<TreeMap<Integer, ArrayList<JsonWord>>>() {}.getType());
					Current.ansMap = g.fromJson(json.getJSONObject("answerMap").toString(),
							new TypeToken<TreeMap<Integer, ArrayList<Integer>>>() {}.getType());
					
					Log.i(tag, ".............module=" + Current.module
							+ " type=" + Current.type + " examId="+Current.examId+" qtyMap size="
							+ Current.qtyMap.size());
					
					// * save examJson to db
					DbExam de = new DbExam(Current.examId, json.toString());
					if (examManager.isExamExist(Current.examId)) {
						examManager.updateExam(de);
					} else {
						examManager.addExam(de);
					}
				}
			} catch (Exception e) {
				//no toast here
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeGetQuestion) {
				executeGetQuestion.notify();
			}
		}
	};
	
	private Runnable executeGetVersion = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getVersion();
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json!=null) {
					Gson g = new Gson();
					HashMap<String, Long> versionMap = g.fromJson(json.toString(),
							new TypeToken<HashMap<String, Long>>() {
							}.getType());
					String key = "exam"+Current.examId;
					long spDate = sp.getLong(key, 0l);
					long mapDate = 0l;
					if (versionMap !=null && versionMap.get(key) !=null && versionMap.get(key)>0l){
						mapDate = versionMap.get(key);
					} 
					
					if (spDate == 0l || mapDate>spDate){
						needUpdate = true;
						spe.putLong(key, mapDate);
						spe.commit();
					} else {
						needUpdate = false;
					}
				}
			} catch (Exception e) {
				//no toast
				e.printStackTrace();
			}
			synchronized (executeGetVersion) {
				executeGetVersion.notify();
			}
		}
	};
	
	private Runnable executeLoading = new Runnable(){
		public void run(){
			LoadingDialog.startDA(getActivity());
		}
	};
	private Runnable executeEndLoading = new Runnable(){
		public void run(){
			LoadingDialog.endDA();
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		try {
		    if (view.getBackground() != null) {
		        view.getBackground().setCallback(null);
//		        view.setBackgroundDrawable(null);
		        }
		} catch (Exception e) {
		}
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeGetQuestion);
			mThreadHandler.removeCallbacks(executeGetVersion);
		}
		if (mThread != null) mThread.quit();
		if (refresh!=null){
			refresh.removeCallbacks(executeLoading);
			refresh.removeCallbacks(executeEndLoading);
		}
		if (examManager != null) examManager.close();
	}

	@Override
	public void onPause() {
		try {
			view.getBackground().setCallback(null); // test prevent oom
		} catch (Exception e) {
		}
		super.onPause();
	}

	@Override
	public void onStop() {
		super.onStop();
//		refresh.post(executeEndLoading);
//		LoadingDialog.endDA();
	}
}
