package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;
import java.util.HashMap;

import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.ModuleConsonManager;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import config.Conf;
import config.URLs;
import bean.Current;
import bean.JsonExam;
import bean.ModuleConson;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class ModuleTypeFragment extends Fragment {
	private final String tag = "ModuleTypeFragment";

	private View view;
	private Button btn_type_01, btn_type_02;
	private ImageButton btn_back;
	
	private Handler mThreadHandler;
	private HandlerThread mThread;
	private ModuleConsonManager moduleConsonManager;
	private SharedPreferences sp;
	private SharedPreferences.Editor spe;
	private boolean needUpdate=false;
//	private Dialog da;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_module_type, container, false);
		Current.page = tag;
		
		mThread = new HandlerThread("ModuleTypeFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		// SharedPreferences
		sp = getActivity().getSharedPreferences(Conf.SP_NAME, 0);
		spe = sp.edit();
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		
		return view;
	}

	private void initView() {
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		btn_type_01 = (Button) view.findViewById(R.id.btn_type_01);
		btn_type_02 = (Button) view.findViewById(R.id.btn_type_02);

		btn_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
				ModuleFragment f = new ModuleFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				fragmentTransaction.replace(R.id.rl_main_content, f);
//				fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit();

			}
		});
		btn_type_01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoadingDialog.startDA(getActivity());
				GA_Util.sendBtnEvent(t, tag, "????????????");
				Current.type = Current.type_word;
				getConsonList();
			}
		});

		btn_type_02.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoadingDialog.startDA(getActivity());
				GA_Util.sendBtnEvent(t, tag, "????????????");
				Current.type = Current.type_sentence;
				getConsonList();
			}
		});
	}
	
	private void getConsonList() {
		//check version
		if (InternetState.isOnline(getActivity())) { 
			try {
				mThreadHandler.post(executeGetVersion);
				synchronized (executeGetVersion) {
					executeGetVersion.wait();
				}
			} catch (Exception e) {}
		} else {
			needUpdate = false;//* if no network read from db
		}
		
		Current.examList = null; //* reset conson list
		Current.m03Map = null; //* reset module03 question map	
		// * getConson from db
		if (moduleConsonManager == null)
			moduleConsonManager = new ModuleConsonManager(getActivity());
		if (!needUpdate && moduleConsonManager.isConsonExist(Current.module,
				Current.type)) {
			// * conson list exist in db
			ModuleConson mc = new ModuleConson(Current.module,
					Current.type);
			moduleConsonManager.getModuleConson(mc);
			Gson g = new Gson();
			Current.examList = g.fromJson(mc.getConsonJson(),
					new TypeToken<ArrayList<JsonExam>>() {
					}.getType());
		}
		if (Current.examList == null || Current.examList.size() == 0) {
			if (InternetState.isOnline(getActivity())) { // * getConson from server
				try {
					mThreadHandler.post(executeGetConson);
					synchronized (executeGetConson) {
						executeGetConson.wait();
					}
				} catch (Exception e) {
					 e.printStackTrace();
				}
			} else {
				// * Not in db and not internet connection
				Toast.makeText(getActivity(), R.string.no_network_connection,
						Toast.LENGTH_SHORT).show();
			}
		}
		if (Current.examList != null && Current.examList.size() > 0) {
			toConsonSelect();
		} else {
			LoadingDialog.endDA();
			Toast.makeText(getActivity(), R.string.conson_empty,
					Toast.LENGTH_SHORT).show();
		}
	}

	private void toConsonSelect() {
		ModuleConsonantFragment f = new ModuleConsonantFragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.rl_main_content, f);
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}

	private Runnable executeGetConson = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getConsonJson(Current.module,
					Current.type);
			try {
				JSONArray json = GetJSON.doGetJSONArray(url);
				if (json == null) {
					Toast.makeText(getActivity(), R.string.json_error,
							Toast.LENGTH_SHORT).show();
				} else {
					Gson g = new Gson();
					Current.examList = g.fromJson(json.toString(),
							new TypeToken<ArrayList<JsonExam>>() {
							}.getType());
					Log.i(tag, ".............module=" + Current.module
							+ " type=" + Current.type + " list size="
							+ Current.examList.size());
					// * save conson list to db
					ModuleConson mc = new ModuleConson(Current.module,
							Current.type, json.toString());
					if (moduleConsonManager.isConsonExist(Current.module,
							Current.type)) {
						moduleConsonManager.updateModuleConson(mc);
					} else {
						moduleConsonManager.addModuleConson(mc);
					}
				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeGetConson) {
				executeGetConson.notify();
			}
		}
	};

	private Runnable executeGetVersion = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getVersion();
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json!=null) {
					Gson g = new Gson();
					HashMap<String, Long> versionMap = g.fromJson(json.toString(),
							new TypeToken<HashMap<String, Long>>() {
							}.getType());
					String key = "module"+Current.module;
					long spDate = sp.getLong(key, 0l);
					long mapDate = 0l;
					if (versionMap !=null && versionMap.get(key) !=null && versionMap.get(key)>0l){
						mapDate = versionMap.get(key);
					} 
					if (spDate == 0l || mapDate>spDate){
						needUpdate = true;
						spe.putLong(key, mapDate);
						spe.commit();
					} else {
						needUpdate = false;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			synchronized (executeGetVersion) {
				executeGetVersion.notify();
			}
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeGetConson);
			mThreadHandler.removeCallbacks(executeGetVersion);
		}
		if (mThread != null) {
			mThread.quit();
		}
		if (moduleConsonManager != null) {
			moduleConsonManager.close();
		}
	}

	@Override
	public void onStop() {
		super.onStop();
		LoadingDialog.endDA();
	}
}
