package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import bean.Current;
import bean.JsonExam;

public class ConsonGridViewAdapter extends BaseAdapter{

	private Activity act;
	private ArrayList<JsonExam> list;
	
	public ConsonGridViewAdapter(Activity act){
		this.act = act;
		if (Current.examList !=null) list = Current.examList;
		else list = new ArrayList<JsonExam>();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	private class ViewHolder{
		TextView conson;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		LayoutInflater inflater = act.getLayoutInflater();
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.cell_conson_grid, null);
			holder = new ViewHolder();
			holder.conson = (TextView) convertView
					.findViewById(R.id.text_conson);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		JsonExam exam = list.get(position);
		holder.conson.setText(exam.getName());
		holder.conson.setTag(Integer.valueOf(exam.getId()));
		
		return convertView;
	}

}
