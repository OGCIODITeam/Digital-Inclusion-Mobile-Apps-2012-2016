package hk.org.deaf.asrtraining;

import java.util.Calendar;

import hk.org.deaf.asrtraining.R;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import com.google.android.gms.analytics.Tracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import bean.Current;
import bean.User;
import config.Conf;
import config.URLs;

public class RegisterFragment extends Fragment {
	private final String tag = "RegisterFragment";

	private View view;
	private ImageButton btn_back, btn_register;
	private EditText et_name, et_yob, et_email, et_password;

	private Handler mThreadHandler;
	private HandlerThread mThread;
	private boolean regSuccess = false;
	
	private SharedPreferences sp;
	private SharedPreferences.Editor spe;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_register, container, false);
		Current.page = tag;
		mThread = new HandlerThread(tag+"HandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		// SharedPreferences
		sp = getActivity().getSharedPreferences(Conf.SP_NAME, 0);
		spe = sp.edit();
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		return view;
	}
	
	private void initView(){
		//Button
		btn_register = (ImageButton) view.findViewById(R.id.btn_register);
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		//EditText
		et_name = (EditText) view.findViewById(R.id.et_name);
		et_yob = (EditText) view.findViewById(R.id.et_yob);
		et_email = (EditText) view.findViewById(R.id.et_email);
		et_password = (EditText) view.findViewById(R.id.et_password);
		
		//Listener
		btn_register.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				LoadingDialog.startDA(getActivity());
				boolean isValid  = true;
				String name = et_name.getText().toString();
				String yob = et_yob.getText().toString();
				String email = et_email.getText().toString();
				String pwd = et_password.getText().toString();
				if (name!=null && !name.trim().equals("") && name.length()<=50) User.name=name.trim();
				else isValid = false;
				if (yob!=null && !yob.trim().equals("") && yob.length()==4) User.yob=yob.trim();
				else isValid = false;
				if (email!=null && !email.trim().equals("") && email.length()<=100) User.email=email.trim();
				else isValid = false;
				if (pwd!=null && !pwd.trim().equals("") && pwd.length()<=100) User.password=pwd.trim();
				else isValid = false;
				//** Gender and Hearing value handle LoginActivity; value checking here;				
				if (User.gender==null || User.gender.equals("")) isValid = false;	
				if (User.hearing==null || User.hearing.equals("")) isValid = false;	
					
				int year = Calendar.getInstance().get(Calendar.YEAR);
				int age = -1;
				try {
					age = year - Integer.parseInt(yob);
				} catch(Exception e){}
				
				if (!InternetState.isOnline(getActivity())) {
					LoadingDialog.endDA();
					Toast.makeText(getActivity(), R.string.no_network_connection,
							Toast.LENGTH_SHORT).show();
				} else if (isValid){
					try {
						mThreadHandler.post(executeRegister);
						synchronized (executeRegister) {
							executeRegister.wait();
						}
					} catch (Exception e) {}
					if (regSuccess) {
						GA_Util.sendBtnEvent(t, tag, "Register");
						Intent i = new Intent();
						i.setClass(getActivity(), ExamActivity.class);
						startActivity(i);
						getActivity().overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
						getActivity().finish();
					} else {
						// reg error
						LoadingDialog.endDA();
					}
				} else if (age<0 || age>99) {
					LoadingDialog.endDA();
					Toast.makeText(getActivity(), R.string.reg_age_error,
							Toast.LENGTH_SHORT).show();
				} else {
					LoadingDialog.endDA();
					Toast.makeText(getActivity(), R.string.reg_form_error,
							Toast.LENGTH_LONG).show();
				}
			}});
		
		btn_back.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
			    LoginFragment f = new LoginFragment();
			    FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
			    fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
			    fragmentTransaction.replace(R.id.form_content, f);  
//			    fragmentTransaction.addToBackStack(null);
			    fragmentTransaction.addToBackStack(tag);
			    fragmentTransaction.commit(); 
			}});
	}
	
	private Runnable executeRegister = new Runnable(){
		public void run(){
			String url = URLs.postRegisterURL(User.yob, User.name, User.email, User.password, User.gender, User.hearing);
			try {
				JSONObject json = GetJSON.postJSONObject(url, URLs.getNvp(), false);
				if (json!=null) {
					String result = json.getString("result");
					if (result !=null && result.equals("success")) {
						//success case
						JSONObject userJson = json.getJSONObject("user");
						int jsonId = userJson.getInt("id");
						String jsonToken = userJson.getString("token");
						if (jsonId<=0 || jsonToken==null || jsonToken.trim().equals("")){
							Toast.makeText(getActivity(), R.string.json_error, Toast.LENGTH_SHORT).show();
							regSuccess = false;
						} else {
							User.id = jsonId;
							User.token = jsonToken;
							spe.putInt("id", jsonId);
							spe.putString("token",jsonToken);
							spe.putString("yob", User.yob);
							spe.putString("name", User.name);
							spe.putString("email", User.email);
							spe.putString("gender", User.gender);
							spe.putString("hearing", User.hearing);
							spe.commit();
							regSuccess = true;
						}
					} else {
						// fail
						regSuccess = false;
						Toast.makeText(getActivity(), json.getString("reason"), Toast.LENGTH_SHORT).show();
					}
				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			User.password = null; //* clear password
			synchronized (executeRegister) {
				executeRegister.notify();
			}
		}
	};

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeRegister);
		}
		if (mThread != null) mThread.quit();
	}

	@Override
	public void onStop() {
		super.onStop();
		LoadingDialog.endDA();
	}
	
}
