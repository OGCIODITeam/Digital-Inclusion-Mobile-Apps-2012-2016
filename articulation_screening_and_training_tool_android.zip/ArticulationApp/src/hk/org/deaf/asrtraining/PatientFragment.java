package hk.org.deaf.asrtraining;


import hk.org.deaf.asrtraining.R;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.ReportManager;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import com.google.android.gms.analytics.Tracker;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import bean.Current;
import bean.Patient;
import bean.User;
import config.URLs;

public class PatientFragment extends Fragment{
	private final String tag = "PatientFragment";
	
	private View view;
	private Button btn_submit, btn_add_new, btn_close;
	private EditText et_email;
	private ReportManager reportManager;
	
	private Handler mThreadHandler;
	private HandlerThread mThread;
	
	private boolean isSuccess = false;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_patient, container, false);
		Current.page = tag;
		
		mThread = new HandlerThread("PatientFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		
		return view;
	}
	private void initView(){
		btn_submit = (Button) view.findViewById(R.id.btn_submit);
		btn_add_new = (Button) view.findViewById(R.id.btn_add_new);
		btn_close = (Button) view.findViewById(R.id.btn_close);
		et_email = (EditText) view.findViewById(R.id.et_email);
		
		btn_submit.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Submit");
				String email = et_email.getText().toString();
				if (email!=null && !email.trim().equals("")){
					Patient.email = email;
					if (!InternetState.isOnline(getActivity())){
						Toast.makeText(getActivity(), R.string.no_network_connection,
								Toast.LENGTH_SHORT).show();
					} else {
						try {
							LoadingDialog.startDA(getActivity());
							mThreadHandler.post(executeGetPatient);
							synchronized (executeGetPatient) {
								executeGetPatient.wait();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						if (isSuccess) {
							User.isAssess = true;
							delAllReport();
							toExamAct();
						} else {
							LoadingDialog.endDA();
							Patient.reset();
							Toast.makeText(getActivity(), R.string.pa_get_error, Toast.LENGTH_SHORT).show();
						}
					}
				} else {
					Toast.makeText(getActivity(), R.string.pa_email_null, Toast.LENGTH_SHORT).show();
				}
			}});
		
		btn_close.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Close");
				User.isAssess = false;
				toExamAct();
			}});
		
		btn_add_new.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Add New");
				toAddPatient();
			}});
	}
	
	private void delAllReport(){
		//* App report data store by user/patient, need clear when change 
		if (reportManager == null) reportManager = new ReportManager(getActivity());
		reportManager.delAllReportExam();
	}
	
	private void toExamAct(){
		Intent i = new Intent();
		i.setClass(getActivity(), ExamActivity.class);
		startActivity(i);
		getActivity().overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
		getActivity().finish();
	}
	
	private void toAddPatient(){
		AddPatientFragment f = new AddPatientFragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
//		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.form_content, f); 
//		fragmentTransaction.addToBackStack(null);
//		fragmentTransaction.addToBackStack(tag);
		fragmentTransaction.commit(); 
	}
	
	private Runnable executeGetPatient = new Runnable(){
		public void run(){
			
			String url = URLs.getPatientURL(User.email, Patient.email);
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json != null) {
					String result = json.getString("result");
					if (result!=null && result.trim().equals("success")){
						JSONObject jo = json.getJSONObject("client");
						Patient.centerId = jo.getInt("centerId");
						Patient.email = jo.getString("email");
						Patient.id = jo.getInt("id");
						Patient.name = jo.getString("name");
						Patient.tel = jo.getString("tel");
						Patient.yob = jo.getInt("yob");
						if (Patient.id<=0 || Patient.email==null || Patient.email.trim().equals("")){
							// json info error
							isSuccess = false;
						} else {
							isSuccess = true;
						}
					} else {
						//result error
						isSuccess  = false;
					}
				} else {
					//json null
					isSuccess = false;
				}
			} catch (Exception e) {
				isSuccess = false;
				e.printStackTrace();
			}
			synchronized (executeGetPatient) {
				executeGetPatient.notify();
			}
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (reportManager != null){
			reportManager.close();
		} 
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeGetPatient);
		}
		if (mThread != null) mThread.quit();
	}
	@Override
	public void onStop() {
		super.onStop();
		LoadingDialog.endDA();
	}
}
