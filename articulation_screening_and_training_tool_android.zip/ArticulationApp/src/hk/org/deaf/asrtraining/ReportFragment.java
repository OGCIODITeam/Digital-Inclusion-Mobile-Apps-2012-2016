package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import manager.ExamManager;
import manager.GA_Util;
import manager.GPSTracker;
import manager.GetJSON;
import manager.InternetState;
import manager.MyAnalytics;
import manager.ReportManager;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.DbExam;
import bean.JsonWord;
import bean.ReportExam;
import bean.User;

import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import config.Conf;
import config.URLs;

public class ReportFragment extends Fragment {
	private final String tag = "ReportFragment";

	private View view;
	private ImageButton btn_back;
	private ListView list_report;
	private LinearLayout list_header;
	private FrameLayout frame_re_practice, frame_assess;
	private TextView text_rp_msg, text_rp_score;
	
	private ReportManager reportManager;
	private TreeMap<Integer, ReportExam> testedExam;
	
	private Handler mThreadHandler;
	private HandlerThread mThread;

	private ExamManager examManager;
	private boolean needUpdate = false;
	
	private SharedPreferences sp;
	private SharedPreferences.Editor spe;
	
	private GPSTracker gps;
	private double latitude = 0d;
	private double longitude = 0d;
	private Tracker t;
//	private LocationManager locationManager;
//	private String provider;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_report, container, false);
		Current.page = tag;
		// Thread
		mThread = new HandlerThread("ModuleConsonantFragment");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		// SharedPreferences
		sp = getActivity().getSharedPreferences(Conf.SP_NAME, 0);
		spe = sp.edit();
		//GPS
//		locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
//	    Criteria criteria = new Criteria();
//	    provider = locationManager.getBestProvider(criteria, false);
//	    Location location = locationManager.getLastKnownLocation(provider);
		
		
		if (reportManager==null) reportManager = new ReportManager(getActivity());
		testedExam = reportManager.getReportByModule(Current.module);
		
		//* reset the need practice list
		Current.practiceList = new HashMap<Integer, String>(); 
//		Current.practiceList = new ArrayList<Integer>(); 
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		initView();
		if (Current.correctMap != null && Current.errorMap !=null){
//			if (Current.module == Current.module_listen_a 
//					|| Current.module == Current.module_listen_p){
			getGPS();
				if (InternetState.isOnline(getActivity())) { 
					mThreadHandler.post(executeSendReport);
				} else {
					// * Not in db and not internet connection
					Toast.makeText(getActivity(), R.string.no_network_connection,
						Toast.LENGTH_SHORT).show();
				}
//			} else {
//				//TODO send report for module_initial_a and module_initial_p
//			}
		}
		
		if (User.isST){
			ButtomBarFragment.reportStyle();
		}
		return view;
	}
		
	private void initView() {
		//FrameLayout
		frame_re_practice = (FrameLayout) view.findViewById(R.id.frame_re_practice);
		frame_assess = (FrameLayout) view.findViewById(R.id.frame_assess);
		
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		//ListView
		list_report = (ListView) view.findViewById(R.id.list_report);
		//LinearLayout
		list_header = (LinearLayout) view.findViewById(R.id.list_header);
		//TextView
		text_rp_msg = (TextView) view.findViewById(R.id.text_rp_msg);
		text_rp_score = (TextView) view.findViewById(R.id.text_rp_score);

		if (Current.module == Current.module_initial_a || Current.module == Current.module_listen_a){
			//TODO check user
			if (User.isST && User.isAssess) { 
				frame_re_practice = (FrameLayout) view.findViewById(R.id.frame_re_practice);
				frame_re_practice.setVisibility(View.VISIBLE);
			}

			list_report.setVisibility(View.VISIBLE);
			list_header.setVisibility(View.VISIBLE);
			text_rp_msg.setVisibility(View.INVISIBLE);
			text_rp_score.setVisibility(View.INVISIBLE);
			
			if (Current.module == Current.module_listen_a){
				ReportAdapter report_adapter = new ReportAdapter(getActivity(), testedExam, false);
				list_report.setAdapter(report_adapter);
				list_report.setOnItemClickListener(new OnItemClickListener(){
					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						GA_Util.sendBtnEvent(t, tag, "Select Exam");
						Current.examId = Current.examList.get(position).getId(); //*set clicked exam to current exam
						Current.examName = Current.examList.get(position).getName();
						getQuestionList();
					}});
				
				final int selectedPosition = report_adapter.getSelectedExamPosition(Current.examId);
				list_report.post(new Runnable() {
					@Override
					public void run() {
						list_report.smoothScrollToPosition(selectedPosition);
					}
				});
				
			} else {
				// m03 module_initial_a
				frame_assess.setVisibility(View.GONE);
				ReportAdapter report_adapter = new ReportAdapter(getActivity(), Current.m03Report, true);
				list_report.setAdapter(report_adapter);
				list_report.setOnItemClickListener(new OnItemClickListener(){
					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						//TODO m03 report click
//						Current.examId = Current.examList.get(position).getId(); //*set clicked exam to current exam
//						Current.examName = Current.examList.get(position).getName();
//						getQuestionList();
					}});
			}
		} else {
			list_report.setVisibility(View.INVISIBLE);
			list_header.setVisibility(View.INVISIBLE);
			
			ReportExam re = testedExam.get(Current.examId);
			if (re != null){
				if (re.getCorrect() == re.getTotal()) text_rp_msg.setText(R.string.rp_all_correct);
				else text_rp_msg.setText(R.string.rp_finish);
				text_rp_score.setText("????????????: "+Current.examName+"\n??????: "+re.getCorrect()+"/"+re.getTotal());
				text_rp_score.setContentDescription("????????????: "+Current.examName+"\n??????: "+re.getTotal()+"???"+re.getCorrect());
			} else {
				Log.i(tag, " fail to get exam score");
			}
			text_rp_msg.setVisibility(View.VISIBLE);
			text_rp_score.setVisibility(View.VISIBLE);
		}
		
		btn_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
				// temp
				//should check user
//TODO				try{ButtomBarFragment.setBtnVisible(View.INVISIBLE);}catch(Exception e){}
				
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				if (Current.module == Current.module_initial_a) {
					ModuleFragment f = new ModuleFragment();
					fragmentTransaction.replace(R.id.rl_main_content, f);
				} else {
					ModuleConsonantFragment f = new ModuleConsonantFragment();
					fragmentTransaction.replace(R.id.rl_main_content, f);
				} 
//				fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit();
				// end temp

			}
		});

	}

	private void getGPS(){
		gps = new GPSTracker(getActivity());
        if(gps.canGetLocation()){
            
            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
        }else{
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }
	}
	
	private void getQuestionList() {
		//Loading
//		Handler refresh = new Handler(Looper.getMainLooper());
//		refresh.post(new Runnable() {
//			public void run() {
//				LoadingDialog.startDA(getActivity());
//			}
//		});
		//** any change need to update ReportFragment too
		//check version
		if (InternetState.isOnline(getActivity())) { 
			try {
				mThreadHandler.post(executeGetVersion);
				synchronized (executeGetVersion) {
					executeGetVersion.wait();
				}
			} catch (Exception e) {}
		} else {
			needUpdate = false;//* if no network read from db
		}
		
		Current.qtyMap = null; //reset question list
		Current.ansMap = null; //reset ans list
		
		if (examManager == null) examManager = new ExamManager(getActivity());
		if (!needUpdate && examManager.isExamExist(Current.examId)) { // get exam json from db
			DbExam ex = new DbExam(Current.examId);
			examManager.getExam(ex);
			try{
			JSONObject jo = new JSONObject(ex.getExamJson());
			Gson g = new Gson();
			Current.qtyMap = g.fromJson(jo.getJSONObject("questionMap").toString(),
					new TypeToken<TreeMap<Integer, ArrayList<JsonWord>>>() {}.getType());
			Current.ansMap = g.fromJson(jo.getJSONObject("answerMap").toString(),
					new TypeToken<TreeMap<Integer, ArrayList<Integer>>>() {}.getType());
			} catch (Exception e){
				Log.i(tag, "Convert DB object to json exception");
			}
		}
		if (Current.qtyMap == null || Current.examList.size() == 0){
			if (InternetState.isOnline(getActivity())) { // * getConson from server
				try {
					mThreadHandler.post(executeGetQuestion);
					synchronized (executeGetQuestion) {
						executeGetQuestion.wait();
					}
				} catch (Exception e) {
					Log.i(tag, "Get question json from server exception");
				}
			} else {
				// * Not in db and not internet connection
				Toast.makeText(getActivity(), R.string.no_network_connection,
						Toast.LENGTH_SHORT).show();
			}
		}

		if (Current.qtyMap !=null && Current.qtyMap.size()>0){
			selectFragment();
		} else {
			Toast.makeText(getActivity(), R.string.question_empty,
					Toast.LENGTH_SHORT).show();
		}
//		
//		refresh.post(new Runnable() {
//			public void run() {
//				LoadingDialog.endDA();
//			}
//		});
	}
	
	private void selectFragment() {
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		if (Current.module == Current.module_listen_a) {
			Exam1Fragment f = new Exam1Fragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		} else if (Current.module == Current.module_listen_p) {
			if (Current.type == Current.type_word){
				Exam1Fragment f = new Exam1Fragment();
				fragmentTransaction.replace(R.id.rl_main_content, f);
			} else if (Current.type == Current.type_sentence){
				Exam2Fragment f = new Exam2Fragment();
				fragmentTransaction.replace(R.id.rl_main_content, f);
			}
		} else if (Current.module == Current.module_initial_a) {
//			Exam3Fragment f = new Exam3Fragment();
			BgNoiseFragment f = new BgNoiseFragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		} else if (Current.module == Current.module_initial_p) {
//			Exam3Fragment f = new Exam3Fragment();
			BgNoiseFragment f = new BgNoiseFragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		}
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}

	private Runnable executeGetQuestion = new Runnable(){
		public void run(){
			// * getQuestionJson from server
			String url = URLs.getQuestionJson(Current.module,
					Current.type, Current.examId);
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json == null) {
					Toast.makeText(getActivity(), R.string.json_error,
							Toast.LENGTH_SHORT).show();
				} else {
					Gson g = new Gson();
					Current.qtyMap = g.fromJson(json.getJSONObject("questionMap").toString(),
							new TypeToken<TreeMap<Integer, ArrayList<JsonWord>>>() {}.getType());
					Current.ansMap = g.fromJson(json.getJSONObject("answerMap").toString(),
							new TypeToken<TreeMap<Integer, ArrayList<Integer>>>() {}.getType());
					
					Log.i(tag, ".............module=" + Current.module
							+ " type=" + Current.type + " examId="+Current.examId+" qtyMap size="
							+ Current.qtyMap.size());
					
					// * save examJson to db
					DbExam de = new DbExam(Current.examId, json.toString());
					if (examManager.isExamExist(Current.examId)) {
						examManager.updateExam(de);
					} else {
						examManager.addExam(de);
					}
				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeGetQuestion) {
				executeGetQuestion.notify();
			}
		}
	};
	
	private Runnable executeGetVersion = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getVersion();
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json!=null) {
					Gson g = new Gson();
					HashMap<String, Long> versionMap = g.fromJson(json.toString(),
							new TypeToken<HashMap<String, Long>>() {
							}.getType());
					String key = "exam"+Current.examId;
					long spDate = sp.getLong(key, 0l);
					long mapDate = 0l;
					
					if (versionMap !=null &&  versionMap.get(key) !=null && versionMap.get(key)>0l){
						mapDate = versionMap.get(key);
					} 
					if (spDate == 0l || mapDate>spDate){
						needUpdate = true;
						spe.putLong(key, mapDate);
						spe.commit();
					} else {
						needUpdate = false;
					}
				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeGetVersion) {
				executeGetVersion.notify();
			}
		}
	};
	
	private Runnable executeSendReport = new Runnable(){
		public void run(){
			
			String correctStr = new JSONObject(Current.correctMap).toString();
			String errorStr = new JSONObject(Current.errorMap).toString();
			String url = URLs.postReportURL(Current.type, Current.module, Current.examId, correctStr, errorStr, latitude, longitude);
			try {
				JSONObject json = GetJSON.postJSONObject(url, URLs.getNvp(), false);
				if (json!=null) {
					String result = json.getString("result");
					if (result !=null && result.equals("success")) {
						//success case
						Log.i(tag, "executeSendReport success");
					} else {
						// fail
						Log.i(tag, "executeSendReport error");
					}
				}
			} catch (Exception e) {
//				Toast.makeText(getActivity(), R.string.server_error,
//						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}

		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (gps !=null){
			gps.stopUsingGPS();
		}
		
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeGetQuestion);
			mThreadHandler.removeCallbacks(executeGetVersion);
			mThreadHandler.removeCallbacks(executeSendReport);
		}
		if (mThread != null) mThread.quit();
		if (examManager != null) examManager.close();
		if (reportManager !=null) reportManager.close();
		testedExam = null;
		Current.practiceList = null;
		Current.correctMap = null;
		Current.errorMap = null;
		Current.m03Report = null;
		try{
	    if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
	        view.setBackgroundDrawable(null);
	        }
		} catch (Exception e){}
	}

	@Override
	public void onStop() {
		super.onStop();
		if (User.isST){
			ButtomBarFragment.normalStyle();
		}
	}
}
