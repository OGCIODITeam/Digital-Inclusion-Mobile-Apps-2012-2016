package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import bean.Current;
import bean.JsonExam;

public class QuestionGridViewAdapter extends BaseAdapter{

	private Activity act;
	private ArrayList<Integer> list;
	public int selected = 0;
	
	public QuestionGridViewAdapter(Activity act, ArrayList<Integer> arr){
		this.act = act;
		if (arr!=null) list = arr;
		else list = new ArrayList<Integer>();
	}
	
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	private class ViewHolder{
		TextView qty;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		LayoutInflater inflater = act.getLayoutInflater();
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.cell_qty_grid, null);
			holder = new ViewHolder();
			holder.qty = (TextView) convertView
					.findViewById(R.id.text_qty);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

//		JsonExam exam = list.get(position);
		holder.qty.setText(list.get(position).toString());
//		holder.conson.setTag(Integer.valueOf(exam.getId()));
		if (selected==position) holder.qty.setEnabled(false);
		else holder.qty.setEnabled(true);
			
		return convertView;
	}

	@Override
	public boolean areAllItemsEnabled() {
//		return super.areAllItemsEnabled();
		return false;
	}

	@Override
	public boolean isEnabled(int position) {
//		return false;
//		return super.isEnabled(position);
		if (selected==position) return false;
		else return true;
	}

}
