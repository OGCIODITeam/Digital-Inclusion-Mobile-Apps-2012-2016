package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.Patient;
import bean.User;

import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;

import config.URLs;

public class ButtomBarFragment extends Fragment {
	private final String tag = "ButtomBarFragment";

	private View view;
	private static Button btn_submit, btn_mode, btn_change;
	//btn_root_btn;
	private static TextView text_root_info;
	
	private Handler mThreadHandler;
	private HandlerThread mThread;
	private boolean isSuccess = false;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.bottom_bar, container, false);
		mThread = new HandlerThread("ButtomBarFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		initView();
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		return view;
	}
	
	private void initView() {
		//TextView
		text_root_info = (TextView) view.findViewById(R.id.text_root_info);
		//Button
		btn_mode = (Button) view.findViewById(R.id.btn_mode);
		btn_submit = (Button) view.findViewById(R.id.btn_submit);
		btn_change = (Button) view.findViewById(R.id.btn_change);
		
		btn_mode.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Change Mode");
				if (User.isAssess){
					//to exercise mode
					User.isAssess = false;
					moduleStyle();
				} else {
					//to assess mode
					User.isAssess = true;
					toPatient();
				}
			}
		});
		
		btn_submit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (InternetState.isOnline(getActivity())) {
					try {
						mThreadHandler.post(executeSendSuggest);
						synchronized (executeSendSuggest) {
							executeSendSuggest.wait();
							LoadingDialog.endDA();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (isSuccess){
						GA_Util.sendBtnEvent(t, tag, "Submit Suggestion");
						toModuleSel();
						Toast.makeText(getActivity(), R.string.submit_success,
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(getActivity(), R.string.submit_error,
								Toast.LENGTH_SHORT).show();
					} 
				} else {
					Toast.makeText(getActivity(), R.string.no_network_connection,
							Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		btn_change.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Change Patient");
//				Patient.reset();
//				User.isAssess = true;
				toPatient();
			}
		});
	}
	
	private void toPatient(){
		Intent i = new Intent();
		i.setClass(getActivity(), PatientActivity.class);
		startActivity(i);
//		getActivity().overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
		getActivity().finish();
	}
	
	private void toModuleSel(){
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
		ModuleFragment f = new ModuleFragment();
		fragmentTransaction.replace(R.id.rl_main_content, f);
//		fragmentTransaction.addToBackStack(null);
//		fragmentTransaction.addToBackStack(tag);
		fragmentTransaction.commit();
	}
	
	public static void moduleStyle(){
		btn_mode.setEnabled(true);
		btn_submit.setVisibility(View.INVISIBLE);
		if (User.isAssess){
			text_root_info.setText("被評估者: "+Patient.name+"\n出生年份: "+Patient.yob);
			btn_mode.setText(R.string.mode_ass);
			btn_change.setVisibility(View.VISIBLE);
		} else {
			btn_mode.setText(R.string.mode_exe);
			text_root_info.setVisibility(View.INVISIBLE);
			btn_change.setVisibility(View.INVISIBLE);
		}
	}

	public static void normalStyle(){
		btn_mode.setEnabled(false);
		btn_submit.setVisibility(View.INVISIBLE);
		btn_change.setVisibility(View.INVISIBLE);
	}
	
	public static void reportStyle(){
		btn_mode.setEnabled(false);
		if (User.isAssess && (Current.module==Current.module_initial_a || Current.module==Current.module_listen_a)){
			btn_submit.setVisibility(View.VISIBLE);
		} else {
			btn_submit.setVisibility(View.INVISIBLE);
		}
		btn_change.setVisibility(View.INVISIBLE);
	}
	
	private Runnable executeSendSuggest = new Runnable(){
		public void run(){			
			LoadingDialog.startDA(getActivity());
			String examMapStr = new Gson().toJson(Current.practiceList);
			String url = URLs.postSuggestExercise(User.email, Patient.email, Current.module, examMapStr);
			try {
				JSONObject json = GetJSON.postJSONObject(url, URLs.getNvp(), false);
				if (json!=null) {
					String result = json.getString("result");
					if (result !=null && result.equals("success")) {
						//success case
						Log.i(tag, "send suggest exercise success");
						isSuccess = true;
					} else {
						// fail
						isSuccess = false;
						Log.i(tag, "send suggest exercise error");
					}
				}
			} catch (Exception e) {
				isSuccess = false;
				e.printStackTrace();
			}
			synchronized (executeSendSuggest) {
				executeSendSuggest.notify();
			}
		}
	};

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeSendSuggest);
		}
		if (mThread != null) mThread.quit();
	}
}
