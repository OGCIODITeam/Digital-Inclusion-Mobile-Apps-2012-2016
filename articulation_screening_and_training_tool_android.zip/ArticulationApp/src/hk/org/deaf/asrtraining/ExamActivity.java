package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;
import manager.PageManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import bean.Current;
import bean.User;

import com.google.android.gms.analytics.GoogleAnalytics;

public class ExamActivity extends FragmentActivity { // *below 3.0
// *above 3.0 public class LoginActivity extends Activity {
	private final String tag = "ExamActivity";
	private ExamActivity examAct = this;
//	private Tracker t;
//	private static FrameLayout fLoading;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_exam);
		Current.page = tag;
		

		
		FragmentTransaction fragmentTransaction = getSupportFragmentManager()
				.beginTransaction();
		
		if (User.isST){
			ButtomBarFragment f2 = new ButtomBarFragment();
			fragmentTransaction.replace(R.id.rl_root, f2);
		}
		
		ModuleFragment f = new ModuleFragment();	
		fragmentTransaction.replace(R.id.rl_main_content, f); // replace new layout
		
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
		
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (PageManager.setDeviceButtonClickEvent(examAct, keyCode)) {
			return true;
		} else {
			return super.onKeyDown(keyCode, event);
		}

	}

	@Override
	protected void onStart() {
		super.onStart();
		GoogleAnalytics.getInstance(examAct).reportActivityStart(examAct);
////		GA
//		t = ((MyAnalytics) examAct.getApplication()).getTracker(
//	            TrackerName.APP_TRACKER);
//		GA_Util.sendScreen(t, tag);
	}

	@Override
	protected void onStop() {
		super.onStop();
		GoogleAnalytics.getInstance(examAct).reportActivityStop(examAct);
	}
	
}
