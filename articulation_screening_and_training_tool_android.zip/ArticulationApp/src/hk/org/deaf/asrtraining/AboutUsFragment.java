package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import com.google.android.gms.analytics.Tracker;

import manager.GA_Util;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;
import bean.Current;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

public class AboutUsFragment extends Fragment {
	private final String tag = "AboutUsFragment";

	private View view;
	private ImageButton btn_back;
	private TextView text_content;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_about_us, container, false);
		Current.page = tag;
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		initView();
		
		return view;
	}
	
	private void initView() {
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		//TextView
		text_content = (TextView) view.findViewById(R.id.text_content);
		if (LoginActivity.tacType==1){
			//1 = about us
			text_content.setText(Html.fromHtml(getString(R.string.about_us_txt),new ImageGetter_about(), null));
		} else if (LoginActivity.tacType==2) {
			//2 = manual
			text_content.setText(Html.fromHtml(getString(R.string.manual_txt),new ImageGetter_manual(), null));
		} else if (LoginActivity.tacType==3) {
			//2 = disclaimer
			text_content.setText(Html.fromHtml(getString(R.string.disclaimer_txt)));
		}
		
		btn_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
				LoginFragment f = new LoginFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				fragmentTransaction.replace(R.id.form_content, f);
//				fragmentTransaction.addToBackStack(null);
				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit();

			}
		});

	}
	
	private class ImageGetter_about implements Html.ImageGetter {

	    public Drawable getDrawable(String source) {
	        int id;

	        if (source.equals("hksod_logo.jpg")) {
	            id = R.drawable.hksod_logo;
	        }
	        else if (source.equals("hkust_logo.jpg")){
	        	id = R.drawable.hkust_logo;
	        }
	        else {
	            return null;
	        }

	        Drawable d = getResources().getDrawable(id);
	        d.setBounds(0,0,d.getIntrinsicWidth(),d.getIntrinsicHeight());
	        return d;
	    }
	}
	
	private class ImageGetter_manual implements Html.ImageGetter {

	    public Drawable getDrawable(String source) {
	        int id;

	        if (source.equals("conson4.png")) {
	            id = R.drawable.conson4;
	        } else {
	            return null;
	        }
//	        if (source.equals("conson.png")) {
//	            id = R.drawable.conson;
//	        }
//	        else if (source.equals("conson2.png")){
//	        	id = R.drawable.conson2;
//	        }
//	        else if (source.equals("conson3.png")){
//	        	id = R.drawable.conson3;
//	        }
//	        else {
//	            return null;
//	        }
	        Drawable d = getResources().getDrawable(id);
	        d.setBounds(0,0,d.getIntrinsicWidth(),d.getIntrinsicHeight());
	        return d;
	    }
	}
}
