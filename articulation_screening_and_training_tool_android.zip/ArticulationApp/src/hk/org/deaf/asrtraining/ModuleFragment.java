package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.ModuleConsonManager;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.JsonExam;
import bean.JsonWord_M03;
import bean.ModuleConson;
import bean.Patient;
import bean.User;

import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import config.Conf;
import config.URLs;

public class ModuleFragment extends Fragment {
	private final String tag = "ModuleFragment";

	private View view;
	private Button btn_logout;	
	private ImageButton btn_module_01, btn_module_02, btn_module_03, btn_module_04;	
	private TextView text_desc,text_version;
	private Handler mThreadHandler;
	private HandlerThread mThread;	
	private SharedPreferences sp;
	private SharedPreferences.Editor spe;
	private ModuleConsonManager moduleConsonManager;
	private boolean needUpdate=false;
	private Tracker t;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_module, container, false);
		Current.page = tag;
		// Thread
		mThread = new HandlerThread("ModuleFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		// SharedPreferences
		sp = getActivity().getSharedPreferences(Conf.SP_NAME, 0);
		spe = sp.edit();
		
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		if (User.isST){
			ButtomBarFragment.moduleStyle();
		}
		return view;
	}

	private void initView() {
		//FrameLayout
		// TextView
		text_version = (TextView) view.findViewById(R.id.text_version);
		text_version.setText(Current.version);
		text_version.setContentDescription(Current.versionDesc);
		
		text_desc = (TextView) view.findViewById(R.id.text_desc);
		if (User.name != null && !User.name.equals("")) {
			String tempStr = getString(R.string.module_desc);
			tempStr = tempStr.replace("XXX", User.name);
			text_desc.setText(tempStr);
		}
		// Button
		btn_logout = (Button) view.findViewById(R.id.btn_logout);
		btn_logout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Logout");
				//TODO delete report when logout
				if (InternetState.isOnline(getActivity())) { //inform server user logout
					//need synchronized, if not fail to inform server before User reset
					try {									
						mThreadHandler.post(executeLogout);
						synchronized (executeLogout) {	
							executeLogout.wait();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} 
				
				User.reset(); //* reset User
				//* clear SharedPreferences User info
				spe.putInt("id", 0);
				spe.putString("token","");
				spe.putString("email","");
				spe.putString("name", "");
				spe.putString("yob", "0"); 
				
				Intent i = new Intent();
				i.setClass(getActivity(), LoginActivity.class);
				startActivity(i);
//				getActivity().overridePendingTransition( R.anim.down_slide_in, R.anim.down_slide_out );
				getActivity().finish();

			}
		});

		// FrameLayout
		btn_module_01 = (ImageButton) view.findViewById(R.id.btn_module_01);
		btn_module_02 = (ImageButton) view.findViewById(R.id.btn_module_02);
		btn_module_03 = (ImageButton) view.findViewById(R.id.btn_module_03);
		btn_module_04 = (ImageButton) view.findViewById(R.id.btn_module_04);

		btn_module_01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
 
				LoadingDialog.startDA(getActivity());
				GA_Util.sendBtnEvent(t, tag, "????????????");

				Current.module = Current.module_listen_a;
				Current.type = Current.type_word;
				getConsonList();

			}
		});
		btn_module_02.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "????????????");
				Current.module = Current.module_listen_p;
				toModuleType();
			}
		});
		btn_module_03.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoadingDialog.startDA(getActivity());
				updateFileNameInfo();
				GA_Util.sendBtnEvent(t, tag, "??????????????????");
				Current.module = Current.module_initial_a;
				Current.type = Current.type_record;
				Current.examId = -1; //** module03 no exam only list
				getMoudle03QtyList(); //* random list
			}
		});
		btn_module_04.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoadingDialog.startDA(getActivity());
				updateFileNameInfo();
				GA_Util.sendBtnEvent(t, tag, "??????????????????");
				Current.module = Current.module_initial_p;
				Current.type = Current.type_record;
				getConsonList();
			}
		});

	}

	private void updateFileNameInfo() {
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int tmpUserAge = 0;
		int tmpPatientAge = 0;
		//User
		try {
			tmpUserAge = year - Integer.parseInt(User.yob);
		} catch (Exception e) {}
		if (tmpUserAge<0) Current.userAge = "00";
		else if (tmpUserAge>99) Current.userAge = "99";
		else if (tmpUserAge<10) Current.userAge = "0"+tmpUserAge;
		else Current.userAge = tmpUserAge+"";
		if (User.gender==null || User.gender.equals("")) User.gender = "X";
		if (User.hearing==null || User.hearing.equals("")) User.hearing = "XX";
		
		//Patient
		tmpPatientAge = year - Patient.yob;
		if (tmpPatientAge<0) Current.patientAge = "00";
		else if (tmpPatientAge>99) Current.patientAge = "99";
		else if (tmpPatientAge<10) Current.patientAge = "0"+tmpPatientAge;
		else Current.patientAge = tmpPatientAge+"";
		if (Patient.gender==null || Patient.gender.equals("")) Patient.gender = "X";
		if (Patient.hearing==null || Patient.hearing.equals("")) Patient.hearing = "XX";

	}
	private void getConsonList() {
		//check version
		if (InternetState.isOnline(getActivity())) { 
			try {
				mThreadHandler.post(executeGetVersion);
				synchronized (executeGetVersion) {
					executeGetVersion.wait();
				}
			} catch (Exception e) {}
		} else {
			needUpdate = false;//* if no network read from db
		}
		Current.examList = null; //* reset conson list
		Current.m03Map = null; //* reset module03 question map		
		// * getConson from db
		if (moduleConsonManager == null)
			moduleConsonManager = new ModuleConsonManager(getActivity());
		if (!needUpdate && moduleConsonManager.isConsonExist(Current.module, Current.type)) {
			// * conson list exist in db
			ModuleConson mc = new ModuleConson(Current.module,
					Current.type);
			moduleConsonManager.getModuleConson(mc);
			Gson g = new Gson();
			Current.examList = g.fromJson(mc.getConsonJson(),
					new TypeToken<ArrayList<JsonExam>>() {
					}.getType());
		}
		if (Current.examList == null || Current.examList.size() == 0) {
			if (InternetState.isOnline(getActivity())) { 
				// * getConson from server
				try {
					mThreadHandler.post(executeGetConson);
					synchronized (executeGetConson) {
						executeGetConson.wait();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				// * Not in db and not internet connection
				Toast.makeText(getActivity(), R.string.no_network_connection,
						Toast.LENGTH_SHORT).show();
			}
		}

		if (Current.examList != null && Current.examList.size() > 0) {
			toConsonSelect();
//			if (Current.module == Current.module_initial_p) {
//				toBgNoise();
//			} else {
//				toConsonSelect();
//			}
		} else {
			LoadingDialog.endDA();
			Toast.makeText(getActivity(), R.string.conson_empty,
					Toast.LENGTH_SHORT).show();
		}
	}

	private void getMoudle03QtyList() {
		//check version
		if (InternetState.isOnline(getActivity())) {
			try {
				mThreadHandler.post(executeGetVersion);
				synchronized (executeGetVersion) {
					executeGetVersion.wait();
				}
			} catch (Exception e) {}
		} else {
			needUpdate = false;
		}
		Current.examList = null; //* reset conson list
		Current.m03Map = null; //* reset module03 question map		
		// * getConson from db
		if (moduleConsonManager == null)
			moduleConsonManager = new ModuleConsonManager(getActivity());
		if (!needUpdate && moduleConsonManager.isConsonExist(Current.module, Current.type)) {
			// * module 03 question json also store in conson db
			ModuleConson mc = new ModuleConson(Current.module,
					Current.type);
			moduleConsonManager.getModuleConson(mc);
			Gson g = new Gson();
			Current.m03Map = g.fromJson(mc.getConsonJson(),
					new TypeToken<HashMap<Integer, JsonWord_M03>>() {
					}.getType());
		}
		if (Current.m03Map == null || Current.m03Map.size() == 0) {
			if (InternetState.isOnline(getActivity())) { // * getConson from
															// server
				try {
					mThreadHandler.post(executeGetModule03);
					synchronized (executeGetModule03) {
						executeGetModule03.wait();
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				// * Not in db and not internet connection
				Toast.makeText(getActivity(), R.string.no_network_connection,
						Toast.LENGTH_SHORT).show();
			}
		}

		if (Current.m03Map != null && Current.m03Map.size() > 0) {
//			toBgNoise();
			toExam3();
		} else {
			LoadingDialog.endDA();
			Toast.makeText(getActivity(), R.string.conson_empty,
					Toast.LENGTH_SHORT).show();
		}

	}
	
	private void toExam3() {
		Exam3Fragment f = new Exam3Fragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.rl_main_content, f);
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}
	
	private void toConsonSelect() {
		ModuleConsonantFragment f = new ModuleConsonantFragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.rl_main_content, f);
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}

	private void toModuleType() {
		ModuleTypeFragment f = new ModuleTypeFragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.rl_main_content, f);
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}
	
	private void toBgNoise() {
		BgNoiseFragment f = new BgNoiseFragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.rl_main_content, f);
		// fragmentTransaction.addToBackStack(null);
		fragmentTransaction.commit();
	}

	private Runnable executeGetConson = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getConsonJson(Current.module,
					Current.type);
			try {
				JSONArray json = GetJSON.doGetJSONArray(url);
				if (json == null) {
					Toast.makeText(getActivity(), R.string.json_error,
							Toast.LENGTH_SHORT).show();
				} else {
					Gson g = new Gson();
					Current.examList = g.fromJson(json.toString(),
							new TypeToken<ArrayList<JsonExam>>() {
							}.getType());
					Log.i(tag, ".............module=" + Current.module
							+ " type=" + Current.type + " list size="
							+ Current.examList.size());
					// * save conson list to db
					ModuleConson mc = new ModuleConson(Current.module,
							Current.type, json.toString());
					if (moduleConsonManager.isConsonExist(Current.module,
							Current.type)) {
						moduleConsonManager.updateModuleConson(mc);
					} else {
						moduleConsonManager.addModuleConson(mc);
					}

				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeGetConson) {
				executeGetConson.notify();
			}
		}
	};
	
	private Runnable executeGetModule03 = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getModule03Json(Current.module,
					Current.type);
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json!=null) {
					Gson g = new Gson();
					Current.m03Map = g.fromJson(json.toString(),
							new TypeToken<HashMap<Integer, JsonWord_M03>>() {
							}.getType());
					// * save conson list to db
					ModuleConson mc = new ModuleConson(Current.module,
							Current.type, json.toString());
					if (moduleConsonManager.isConsonExist(Current.module,
							Current.type)) {
						moduleConsonManager.updateModuleConson(mc);
					} else {
						moduleConsonManager.addModuleConson(mc);
					}

				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeGetModule03) {
				executeGetModule03.notify();
			}
		}
	};
	
	private Runnable executeGetVersion = new Runnable() {
		public void run() {
			// * getConsonJson
			String url = URLs.getVersion();
			try {
				JSONObject json = GetJSON.doGet(url, false);
				if (json!=null) {
					Gson g = new Gson();
					HashMap<String, Long> versionMap = g.fromJson(json.toString(),
							new TypeToken<HashMap<String, Long>>() {
							}.getType());
					String key = "module"+Current.module;
					long spDate = sp.getLong(key, 0l);
					long mapDate = 0l;
					if (versionMap !=null && versionMap.get(key) !=null && versionMap.get(key)>0l){
						mapDate = versionMap.get(key);
					} 
					if (spDate == 0l || mapDate>spDate){
						needUpdate = true;
						spe.putLong(key, mapDate);
						spe.commit();
					} else {
						needUpdate = false;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			synchronized (executeGetVersion) {
				executeGetVersion.notify();
			}
		}
	};
		
	private Runnable executeLogout = new Runnable(){
		public void run(){
			String url = URLs.deleteLogoutURL(User.id);
			try {
				JSONObject json = GetJSON.doDelete(url, true);
				if (json!=null) {
					String result = json.getString("result");
					if (result !=null && result.equals("success")) {
						//success case
						Log.i(tag, "Logout success, json= "+json.toString());
					} else {
						// fail
						Log.i(tag, "Logout fail, reason= "+json.getString("reason"));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			synchronized (executeLogout) {
				executeLogout.notify();
			}
		}
	};
	
//	private void startDA() {
//		if (da != null) da.dismiss();
//		da = new AlertDialog.Builder(getActivity()).create();
//		da.requestWindowFeature(Window.FEATURE_NO_TITLE);
//		da.getWindow().setBackgroundDrawable(
//				new ColorDrawable(android.graphics.Color.TRANSPARENT));
////		pd.setContentView(R.layout.dialog_loading);
//		da.setCancelable(false);
//		da.show();
//	}
//	
//	private void endDA() {
//		if (da != null)
//			da.dismiss();
//		da = null;
//	}
	
//	Handler handler = new Handler() {
//        @Override  
//        public void handleMessage(Message msg) {// handler???????????????????????????????????????  
//        	switch (msg.what){
//        	case 1:fLoading.setVisibility(View.VISIBLE);
//        	break;
//        	case 2:fLoading.setVisibility(View.INVISIBLE);
//        	break;
//        	default: break;
//        	}
////            if (pd !=null) pd.dismiss();// ??????ProgressDialog  
//        }  
//	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		try {
	    if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
	        view.setBackgroundDrawable(null);
	        }
		} catch (Exception e){}
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeGetConson);
			mThreadHandler.removeCallbacks(executeGetModule03);
			mThreadHandler.removeCallbacks(executeGetVersion);
			mThreadHandler.removeCallbacks(executeLogout);
		}
		if (mThread != null) {
			mThread.quit();
		}
		if (moduleConsonManager != null) {
			moduleConsonManager.close();
		}
	}

	@Override
	public void onStop() {
		super.onStop();
		if (User.isST){
			ButtomBarFragment.normalStyle();
		}
		LoadingDialog.endDA();
	}
}
