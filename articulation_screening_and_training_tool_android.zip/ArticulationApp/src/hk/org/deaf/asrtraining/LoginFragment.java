package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import com.google.android.gms.analytics.Tracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.User;
import config.Conf;
import config.URLs;

public class LoginFragment extends Fragment {
	private final String tag = "LoginFragment";

	// View
	private View view;
	// Buttons
	private ImageButton btn_login, btn_register;
	private EditText et_email, et_password;
	//TextView 
	private TextView text_about_us, text_manual, text_disclaimer;
	// Thread
	private Handler mThreadHandler;
	private HandlerThread mThread;
	//SharedPreferences
	private SharedPreferences sp;
	private SharedPreferences.Editor spe;

	private boolean loginSuccess = false;
	private Tracker t;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_login, container, false);
		Current.page = tag;
		// init Thread
		mThread = new HandlerThread("LoginFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		// SharedPreferences
		sp = getActivity().getSharedPreferences(Conf.SP_NAME, 0);
		spe = sp.edit();
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		return view;
	}

	private void initView() {
		// Button
		btn_login = (ImageButton) view.findViewById(R.id.btn_login);
		btn_register = (ImageButton) view.findViewById(R.id.btn_register);
		// EditText
		et_email = (EditText) view.findViewById(R.id.et_email);
		et_password = (EditText) view.findViewById(R.id.et_password);
		//TextView
		text_about_us = (TextView) view.findViewById(R.id.text_about_us);
		text_manual = (TextView) view.findViewById(R.id.text_manual);
		text_disclaimer = (TextView) view.findViewById(R.id.text_disclaimer);
		// OnClickListener
		btn_login.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoadingDialog.startDA(getActivity());
				String emailStr = et_email.getText().toString(); 
				String pwdStr = et_password.getText().toString();
				
				boolean isValid = true;
				if (emailStr!=null && !emailStr.trim().equals("") && emailStr.length()<=100) User.email = emailStr;
				else isValid = false;
				if (pwdStr!=null && !pwdStr.trim().equals("") && pwdStr.length()<=100) User.password = pwdStr;
				else isValid = false;
				if (!InternetState.isOnline(getActivity())) {
					LoadingDialog.endDA();
					Toast.makeText(getActivity(), R.string.no_network_connection,
							Toast.LENGTH_SHORT).show();
				} else if (isValid){
					try {
						mThreadHandler.post(executeLogin);
						synchronized (executeLogin) {
							executeLogin.wait();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (loginSuccess) {
						GA_Util.sendBtnEvent(t, tag, "Login");
						Intent i = new Intent();
						if (User.isST){
							i.setClass(getActivity(), PatientActivity.class);
						} else{
							i.setClass(getActivity(), ExamActivity.class);
						}
						startActivity(i);
//						getActivity().overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
						getActivity().finish();
					} else {
						//login fail
						LoadingDialog.endDA();
//						Toast.makeText(getActivity(), R.string.login_error,
//								Toast.LENGTH_SHORT).show();
					}
				} else {
					LoadingDialog.endDA();
					Toast.makeText(getActivity(), R.string.login_form_error,
							Toast.LENGTH_SHORT).show();
				}
			}
		});

		btn_register.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "To Register");
				RegisterFragment f = new RegisterFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
				fragmentTransaction.replace(R.id.form_content, f); 
//				fragmentTransaction.addToBackStack(null);
				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit(); // ??????commit??????????????????add
			}
		});
		
		text_disclaimer.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "To Disclaimer");
				LoginActivity.tacType=3;
				AboutUsFragment f = new AboutUsFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
				fragmentTransaction.replace(R.id.form_content, f); 
//				fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit(); // ??????commit??????????????????add
			}
		});
		
		text_manual.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "To Manual");
				LoginActivity.tacType=2;
				AboutUsFragment f = new AboutUsFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
				fragmentTransaction.replace(R.id.form_content, f); 
//				fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit(); // ??????commit??????????????????add
			}
		});
		
		text_about_us.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "To About Us");
				LoginActivity.tacType=1;
				AboutUsFragment f = new AboutUsFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
				fragmentTransaction.replace(R.id.form_content, f);
//				fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit(); // ??????commit??????????????????add
			}
		});
	}

	private Runnable executeLogin = new Runnable(){
		public void run(){
			String url = URLs.postLoginURL(User.email, User.password);
			try {
				JSONObject json = GetJSON.postJSONObject(url, URLs.getNvp(), false);
				Log.i("TIM CHEKCING"," ...........login json= "+json.toString());
				if (json!=null) {
					String result = json.getString("result");
					if (result !=null && result.equals("success")) {
						//success case
						JSONObject userJson = json.getJSONObject("user");
						int jsonId = userJson.getInt("id");
						String jsonToken = userJson.getString("token");
						String jsonYob = userJson.getString("yob");
						String jsonName = userJson.getString("name");
						String jsonEmail = userJson.getString("email");
						String jsonGender = userJson.getString("gender");
						String jsonHearing = userJson.getString("hearing");
						boolean jsonIsST = userJson.getBoolean("isST");
						if (jsonId<=0 
							|| jsonToken==null || jsonToken.trim().equals("")
							|| jsonYob==null || jsonYob.trim().equals("")
//						    || jsonName==null || jsonName.trim().equals("")
							|| jsonEmail==null || jsonEmail.trim().equals("")
							|| jsonGender==null // old data will empty
							|| jsonHearing==null // old data will empry
							){
//							Toast.makeText(getActivity(), R.string.json_error, Toast.LENGTH_SHORT).show();
							loginSuccess = false;
						} else {
							User.id = jsonId;
							User.token = jsonToken;
							User.yob = jsonYob;
							User.name = jsonName;
							User.email = jsonEmail;
							User.isST = jsonIsST;
							User.gender = jsonGender;
							User.hearing = jsonHearing;
									
							spe.putInt("id", jsonId);
							spe.putString("token",jsonToken);
							spe.putString("yob", jsonYob);
							spe.putString("name", jsonName);
							spe.putString("email", jsonEmail);
							spe.putString("gender", jsonGender);
							spe.putString("hearing", jsonHearing);
							spe.putBoolean("isST", jsonIsST);
							spe.commit();
							loginSuccess = true;
						}
					} else {
						// fail
						loginSuccess = false;
						Toast.makeText(getActivity(), json.getString("reason"), Toast.LENGTH_SHORT).show();
					}
				}
			} catch (Exception e) {
				Toast.makeText(getActivity(), R.string.server_error,
						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			User.password = null; //* clear password
			synchronized (executeLogin) {
				executeLogin.notify();
			}
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeLogin);
		}
		if (mThread != null) {
			mThread.quit();
		}
	}

	@Override
	public void onStop() {
		super.onStop();
		LoadingDialog.endDA();
	}

}
