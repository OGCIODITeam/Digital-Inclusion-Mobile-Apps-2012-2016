package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import com.google.android.gms.analytics.Tracker;

import manager.AppDownloadManger;
import manager.GA_Util;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.ReportManager;
import manager.MyAnalytics.TrackerName;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.JsonWord;
import bean.ReportExam;
import config.Conf;

public class Exam2Fragment extends Fragment {
	private final String tag = "Exam2Fragment";

	private View view;
	private ImageButton btn_back, btn_next, btn_replay, btn_submit;
//	private LinearLayout ll_exam2_content;
	private ImageView img_hint, img_exam2_img, img_exam2_img_boder, img_ans1,
			img_ans2, img_ans3, img_ans4, img_ans5, img_ans6, img_ans7,
			img_ans8, img_ans9, img_ans10;
	private TextView text_ans1, text_ans2, text_ans3, text_ans4, text_ans5,
			text_ans6, text_ans7, text_ans8, text_ans9, text_ans10, text_hint;
	private GridView grid_qty;
	
	private MediaPlayer mPlayer;

//	private String[] optionList;
	private ArrayList<Integer> selected;
	private ArrayList<Integer> ans;
	private ArrayList<Integer> qtyNo;
	private ImageView[] imgList;
	private TextView[] textList;
//	private ArrayList<Integer> correctQtyId;
	private int currentQty = 0; // count start from 0
	private static String currentFileName="";
	private Handler mThreadHandler;
	private HandlerThread mThread;
	private ReportManager reportManager;
	private OnClickListener myOnClick;
	private Bitmap bm_sel, bm_n, bm_t, bm_dummy_h;
	private QuestionGridViewAdapter consonGridAdapter;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_exam_type2, container, false);
		Current.page = tag;
		mThread = new HandlerThread("Exam2FragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		
		currentQty = 0;
//		correctQtyId = new ArrayList<Integer>();
		Current.correctMap = new HashMap<String, String>();
		Current.errorMap = new HashMap<String, String>();
		qtyNo = new ArrayList<Integer>(Current.qtyMap.keySet());
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		if (qtyNo==null || qtyNo.size()==0){
			//TODO qty null
			Toast.makeText(getActivity(), R.string.question_empty,
					Toast.LENGTH_SHORT).show();
		} else {
			//get first qtr info
			selectMaterial();
			startPlaying();
			Current.startTime = System.currentTimeMillis(); //Exam start time
		}

		return view;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}



	private void initView() {
		//Bitmap
		bm_sel = BitmapFactory.decodeResource(getResources(), R.drawable.bu_level2_sel);
		bm_n = BitmapFactory.decodeResource(getResources(), R.drawable.bu_level2_n);
		bm_t = BitmapFactory.decodeResource(getResources(), R.drawable.bu_level2_t);
		bm_dummy_h = BitmapFactory.decodeResource(getResources(), R.drawable.dummy_h);
		//Background
//		if (Current.module == Current.module_listen_a) {
//			view.setBackgroundResource(R.drawable.apps_bg_module01);
//		} else if (Current.module == Current.module_listen_p) {
//			view.setBackgroundResource(R.drawable.apps_bg_module02);
//		} else if (Current.module == Current.module_initial_a) {
//			view.setBackgroundResource(R.drawable.apps_bg_module03);
//		} else if (Current.module == Current.module_initial_p) {
//			view.setBackgroundResource(R.drawable.apps_bg_module04);
//		}
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		btn_next = (ImageButton) view.findViewById(R.id.btn_next);
		btn_replay = (ImageButton) view.findViewById(R.id.btn_replay);
		btn_submit = (ImageButton) view.findViewById(R.id.btn_submit);
		// Layout
//		ll_exam2_content = (LinearLayout) view
//				.findViewById(R.id.ll_exam2_content);
		// ImageView
		img_hint = (ImageView) view.findViewById(R.id.img_hint);
		img_exam2_img = (ImageView) view.findViewById(R.id.img_exam2_img);
		img_exam2_img_boder = (ImageView) view
				.findViewById(R.id.img_exam2_img_boder);
		img_ans1 = (ImageView) view.findViewById(R.id.img_ans1);
		img_ans2 = (ImageView) view.findViewById(R.id.img_ans2);
		img_ans3 = (ImageView) view.findViewById(R.id.img_ans3);
		img_ans4 = (ImageView) view.findViewById(R.id.img_ans4);
		img_ans5 = (ImageView) view.findViewById(R.id.img_ans5);
		img_ans6 = (ImageView) view.findViewById(R.id.img_ans6);
		img_ans7 = (ImageView) view.findViewById(R.id.img_ans7);
		img_ans8 = (ImageView) view.findViewById(R.id.img_ans8);
		img_ans9 = (ImageView) view.findViewById(R.id.img_ans9);
		img_ans10 = (ImageView) view.findViewById(R.id.img_ans10);
		imgList = new ImageView[] { img_ans1, img_ans2, img_ans3, img_ans4,
				img_ans5, img_ans6, img_ans7, img_ans8, img_ans9, img_ans10 };
		// TextView
		text_hint = (TextView) view.findViewById(R.id.text_hint);
		text_ans1 = (TextView) view.findViewById(R.id.text_ans1);
		text_ans2 = (TextView) view.findViewById(R.id.text_ans2);
		text_ans3 = (TextView) view.findViewById(R.id.text_ans3);
		text_ans4 = (TextView) view.findViewById(R.id.text_ans4);
		text_ans5 = (TextView) view.findViewById(R.id.text_ans5);
		text_ans6 = (TextView) view.findViewById(R.id.text_ans6);
		text_ans7 = (TextView) view.findViewById(R.id.text_ans7);
		text_ans8 = (TextView) view.findViewById(R.id.text_ans8);
		text_ans9 = (TextView) view.findViewById(R.id.text_ans9);
		text_ans10 = (TextView) view.findViewById(R.id.text_ans10);
		textList = new TextView[] { text_ans1, text_ans2, text_ans3, text_ans4,
				text_ans5, text_ans6, text_ans7, text_ans8, text_ans9,
				text_ans10 };
		// OnClickListener
		initClickListener();
		for (int i=0; i< imgList.length; i++){
			imgList[i].setOnClickListener(myOnClick);
		}
		
		grid_qty = (GridView) view.findViewById(R.id.grid_qty);
		consonGridAdapter = new QuestionGridViewAdapter(
				getActivity(), qtyNo);
		grid_qty.setAdapter(consonGridAdapter);
		// Listener
		grid_qty.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				GA_Util.sendBtnEvent(t, tag, "Qty Sel");
				
				consonGridAdapter.selected = position;
				consonGridAdapter.notifyDataSetChanged();
				currentQty = position;
				
				btn_submit.setVisibility(View.VISIBLE);
				btn_next.setVisibility(View.INVISIBLE);
				selectMaterial();
				startPlaying();
			}
		});
		
		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
//				mThreadHandler.post(executeEndLoading);
				ModuleConsonantFragment f = new ModuleConsonantFragment();

				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				fragmentTransaction.replace(R.id.rl_main_content, f);
				fragmentTransaction.addToBackStack(tag);
				// fragmentTransaction.addToBackStack(null);
				fragmentTransaction.commit();
			}
		});

		btn_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				stopPlaying();
				if (currentQty < qtyNo.size()-1) {
					GA_Util.sendBtnEvent(t, tag, "Next Qty");
					currentQty++;
					//update list view
					consonGridAdapter.selected = currentQty;
					consonGridAdapter.notifyDataSetChanged();
						
					btn_submit.setVisibility(View.VISIBLE);
					btn_next.setVisibility(View.INVISIBLE);
					selectMaterial();
					startPlaying();
				} else {
					GA_Util.sendBtnEvent(t, tag, "To Report");
//					LoadingDialog.startDA(getActivity());
					//Save end exam data
					Current.endTime = System.currentTimeMillis(); //End Exam
					long timeUse = (Current.endTime-Current.startTime) / 1000; // change to second
//					ReportExam e = new ReportExam(Current.module, Current.examId, correctQtyId.size(), qtyNo.size(), timeUse);
					ReportExam e = new ReportExam(Current.module, Current.examId, Current.correctMap.size(), qtyNo.size(), timeUse);
					if (reportManager==null) reportManager = new ReportManager(getActivity());
					if (reportManager.isExist(Current.examId, Current.module)) {
						reportManager.updateReportExam(e);
					} else {
						reportManager.addReportExam(e);
					}
					
					ReportFragment f = new ReportFragment();
					FragmentTransaction fragmentTransaction = getActivity()
							.getSupportFragmentManager().beginTransaction();
					fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
					fragmentTransaction.replace(R.id.rl_main_content, f);
					fragmentTransaction.addToBackStack(tag);
					// fragmentTransaction.addToBackStack(null);
					fragmentTransaction.commit();
				}
			}
		});

		btn_submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Submit");
				btn_next.setVisibility(View.VISIBLE);
				btn_submit.setVisibility(View.INVISIBLE);
				disableClick();
				checkAns();
			}
		});
		
		btn_replay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Replay");
				startPlaying();
			}
		});

	}

	private void initClickListener(){
		myOnClick = new OnClickListener() {

			@Override
			public void onClick(View v) {
				if ( v == img_ans1 ) {
					setClicked(img_ans1, 1);
				} else if ( v == img_ans2 ) {
					setClicked(img_ans2, 2);
				} else if ( v == img_ans3 ) {
					setClicked(img_ans3, 3);
				} else if ( v == img_ans4 ) {
					setClicked(img_ans4, 4);
				} else if ( v == img_ans5 ) {
					setClicked(img_ans5, 5);
				} else if ( v == img_ans6 ) {
					setClicked(img_ans6, 6);
				} else if ( v == img_ans7 ) {
					setClicked(img_ans7, 7);
				} else if ( v == img_ans8 ) {
					setClicked(img_ans8, 8);
				} else if ( v == img_ans9 ) {
					setClicked(img_ans9, 9);
				} else if ( v == img_ans10 ) {
					setClicked(img_ans10, 10);
				}	
			}
			
		};
	}
	
	private void setClicked(ImageView img, int content) {
//		if (img!=null){
//			((BitmapDrawable) img.getDrawable()).getBitmap().recycle();
//		}
		if (selected.contains(content)){
			img.setImageBitmap(bm_n);
			selected.remove(Integer.valueOf(content)); // * if not use Integer.valueOf(int), will remove position not content
		} else {
			img.setImageBitmap(bm_sel);
			selected.add(content);
		}
	}
	
	private void checkAns() {
		if (ans!=null && ans.size()>0){
			boolean isCorrect = true;
			String selectedStr = "";
//			if (selected == null || selected.size() != ans.size()){ 
			if (selected == null || selected.size()==0 
				|| ans==null || ans.size()==0){
				isCorrect = false;
			} else {
				if (selected.size() != ans.size()) isCorrect = false; //*must check here and run for loop, for save data to report
				for (int i=0; i<selected.size(); i++){
					if (!ans.contains(selected.get(i))){ //selected answer not in correct answer list
						isCorrect = false;
					}
					// for submit report to server
					if (selectedStr.length()==0){
						selectedStr += selected.get(i);
					} else{
						selectedStr += "|"+selected.get(i);
					}
				}
				
			}
			
			String qId = ""+Current.qtyMap.get(qtyNo.get(currentQty)).get(0).getQuestionId();
			if (isCorrect){
//				correctQtyId.add(Current.qtyMap.get(qtyNo.get(currentQty)).get(0).getQuestionId());
				Current.correctMap.put(qId, selectedStr);
				//set all correct image border
				img_exam2_img_boder.setImageResource(R.drawable.box_level2_answer_t);
//				img_exam2_img_boder.setContentDescription(getResources().getString(R.string.ans_t));
			} else {
				Current.errorMap.put(qId, selectedStr);
				//set not correct image border
				img_exam2_img_boder.setImageResource(R.drawable.box_level2_answer_f);
//				img_exam2_img_boder.setContentDescription(getResources().getString(R.string.ans_f));
			}
			for (int i=0; i<ans.size(); i++){
				int index = ans.get(i)-1; //imgList start from 0, answer list start from 1
				imgList[index].setImageBitmap(bm_t);
			}
		} else {
			Log.i(tag,"...... Exam type 2 correct answer list empty");
		}
	}
	
	private void startPlaying() {
		if (mPlayer != null)
			mPlayer.start();
		else
			Log.i(tag, "media null");
	}

	private void stopPlaying() {
		if (mPlayer != null && mPlayer.isPlaying()) {
			mPlayer.stop();
			mPlayer.release();
		}
	}

	private synchronized void selectMaterial() {
//		Handler refresh = new Handler(Looper.getMainLooper());
//		refresh.post(new Runnable() {
//			public void run() {
//				LoadingDialog.startDA(getActivity());
//			}
//		});
//		mThreadHandler.post(executeLoading);
		
		selected = new ArrayList<Integer>();
		resetView();
		if (mPlayer == null) mPlayer = new MediaPlayer(); // new MediaPlayer if null
		ArrayList<JsonWord> words = Current.qtyMap.get(qtyNo.get(currentQty));
		ans = Current.ansMap.get(qtyNo.get(currentQty));
		//hint
//		text_hint.setText(Html.fromHtml("<![CDATA["+words.get(0).getInitial()+"]]>"));
		text_hint.setText(Current.examName);
		//words
		setOptionText(words);
		//image
		currentFileName = words.get(0).getInitial()+"_"+words.get(0).getVowel()+".png";
//		currentFileName = words.get(0).getInitial()+"_"+words.get(0).getVowel()+".jpg";
		if (img_exam2_img !=null){
			((BitmapDrawable) img_exam2_img.getDrawable()).getBitmap().recycle();
		}
		img_exam2_img.setImageBitmap(getImage(words.get(0).getPictureUploadDate()));
		//voice
		currentFileName = words.get(0).getInitial()+"_"+words.get(0).getVowel()+".mp3";
		getVoice(words.get(0).getSoundUploadDate());
//		img_hint.setImageResource(R.drawable.bu_1_a_lv1);
//		refresh.post(new Runnable() {
//			public void run() {
//				LoadingDialog.endDA();
//			}
//		});
//		mThreadHandler.post(executeEndLoading);
	}

	private Bitmap getImage(long updateDate){
//		String imgPath = Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.IMAGE_FOLDER;
		String imgPath = Current.filePath + File.separator + Conf.IMAGE_FOLDER;
		Bitmap bm = BitmapFactory.decodeFile(imgPath+"/"+currentFileName);
		File temp = new File (imgPath+"/"+currentFileName);
		if (temp == null || !temp.exists() || temp.lastModified()<updateDate) {
			try {
				mThreadHandler.post(executeDownloadImg);
				synchronized (executeDownloadImg) {
					executeDownloadImg.wait();
				}
				bm = BitmapFactory.decodeFile(imgPath+"/"+currentFileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (bm != null){
			return bm;
		} else {
			if (bm_dummy_h==null || bm_dummy_h.isRecycled()){
				bm_dummy_h = BitmapFactory.decodeResource(getResources(), R.drawable.dummy_h);
			}
			return bm_dummy_h;
		}
	}
	
	private void getVoice(long updateDate){
//		String voicePath = Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.VOICE_FOLDER;
		String voicePath = Current.filePath + File.separator + Conf.VOICE_FOLDER;
		try {
			if (mPlayer!=null) mPlayer.release();
			mPlayer = new MediaPlayer();
			File voice = new File(voicePath+"/"+currentFileName);
			if (voice==null || !voice.exists() || voice.lastModified()<updateDate) {
				mThreadHandler.post(executeDownloadVoice);
				synchronized (executeDownloadVoice) {
					executeDownloadVoice.wait();
				}
			}
			mPlayer.setDataSource(voicePath+"/"+currentFileName);
			mPlayer.prepare();
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	private Runnable executeDownloadImg = new Runnable(){
		public void run(){
			AppDownloadManger.downloadImage(currentFileName);
			synchronized (executeDownloadImg) {
				executeDownloadImg.notify();
			}
		}
	};
	private Runnable executeDownloadVoice = new Runnable(){
		public void run(){
			AppDownloadManger.downloadVoice(currentFileName);
			synchronized (executeDownloadVoice) {
				executeDownloadVoice.notify();
			}
		}
	};
	
	private Runnable executeLoading = new Runnable(){
		public void run(){
			LoadingDialog.startDA(getActivity());
//			synchronized (executeDownloadVoice) {
//				executeDownloadVoice.notify();
//			}
		}
	};
	
	private Runnable executeEndLoading = new Runnable(){
		public void run(){
			LoadingDialog.endDA();
//			synchronized (executeDownloadVoice) {
//				executeDownloadVoice.notify();
//			}
		}
	};
	
	private void setOptionText(ArrayList<JsonWord> list) {
		for (int i = 0; i < list.size(); i++) {
			// TODO ERROR
//			if (imgList[i] !=null){
//				((BitmapDrawable) imgList[i].getDrawable()).getBitmap().recycle();
//			}
			imgList[i].setImageBitmap(bm_n);
//			imgList[i].setImageResource(R.drawable.bu_level2_n);
			imgList[i].setVisibility(View.VISIBLE);
			imgList[i].setContentDescription(list.get(i).getWord());
			textList[i].setText(list.get(i).getWord());
			textList[i].setVisibility(View.VISIBLE);
			textList[i].setContentDescription("\u00A0"); //* disable textview talkback
//need api16 4.1.2			textList[i].setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); //* disable textview talkback
		}
	}

	private void resetView() {
		//TODO ERROR
//		if (img_exam2_img_boder !=null){
//			((BitmapDrawable) img_exam2_img_boder.getDrawable()).getBitmap().recycle();
//		}
		btn_replay.setClickable(true);
		img_exam2_img_boder.setImageResource(R.drawable.box_level2_answer_n);
		img_exam2_img_boder.setContentDescription(getResources().getString(R.string.ans_n));
		for (int i = 0; i < 10; i++) {
			imgList[i].setVisibility(View.INVISIBLE);
			imgList[i].setClickable(true);
			textList[i].setVisibility(View.INVISIBLE);
		}
	}
	private void disableClick() {
		btn_replay.setClickable(false);
		for (int i = 0; i < 10; i++) {
			imgList[i].setClickable(false);
		}
	}

	private void destoryView() {
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
		
		if (bm_sel!=null && !bm_sel.isRecycled()) {
			bm_sel.recycle();
			bm_sel=null;
		}
		if (bm_n!=null && !bm_n.isRecycled()) {
			bm_n.recycle();
			bm_n=null;
		}
		if (bm_t!=null && !bm_t.isRecycled()) {
			bm_t.recycle();
			bm_t=null;
		}
		if (bm_dummy_h!=null && !bm_dummy_h.isRecycled()) {
			bm_dummy_h.recycle();
			bm_dummy_h=null;
		}
		if (img_exam2_img_boder !=null){
			((BitmapDrawable) img_exam2_img_boder.getDrawable()).getBitmap().recycle();
		}
		if (img_exam2_img !=null){
			((BitmapDrawable) img_exam2_img.getDrawable()).getBitmap().recycle();
		}
		try {
			for (int i = 0; i < 10; i++) {
				if (imgList[i]!=null) imgList[i].getDrawable().setCallback(null);
				imgList[i].setImageDrawable(null);
				// imgList[i] = null;
			}
			img_hint.getDrawable().setCallback(null);
			img_hint.setImageDrawable(null);
			// img_hint = null;
			img_exam2_img.getDrawable().setCallback(null);
			img_exam2_img.setImageDrawable(null);
			// img_exam2_img = null;
			img_exam2_img_boder.getDrawable().setCallback(null);
			img_exam2_img_boder.setImageDrawable(null);
			// img_exam2_img_boder = null;

//			optionList = null;
			selected = null;
			imgList = null;
			textList = null;
		} catch (Exception e) {
			e.printStackTrace();
			Log.i(tag,
					".......................destoryView remove img call back exception");
		}
		// view.getBackground().setCallback(null);
		// view.setBackgroundDrawable(null);
		// unbindDrawables(view);
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
//		LoadingDialog.endDA();
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeDownloadImg);
			mThreadHandler.removeCallbacks(executeDownloadVoice);
			mThreadHandler.removeCallbacks(executeLoading);
			mThreadHandler.removeCallbacks(executeEndLoading);
		}
		if (mThread != null) mThread.quit();
		
//		correctQtyId = null;
		if (reportManager !=null){
			reportManager.close();
		}
		try {
	    if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
	        view.setBackgroundDrawable(null);
	        }
		} catch (Exception e){}
		destoryView();
	}

	@Override
	public void onStop() {
		super.onStop();
//		mThreadHandler.post(executeEndLoading);
//		LoadingDialog.endDA();
	}
	
}
