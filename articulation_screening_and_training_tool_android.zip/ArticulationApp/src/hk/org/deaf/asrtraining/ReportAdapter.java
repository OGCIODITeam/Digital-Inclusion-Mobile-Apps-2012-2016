package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import android.app.Activity;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import bean.Current;
import bean.JsonExam;
import bean.ReportExam;
import bean.User;

public class ReportAdapter extends BaseAdapter{

	private String tag = "ReportAdapter";
	private Activity act; 
	private ArrayList<JsonExam> list;
	private ArrayList<ReportExam> m03List;
	private TreeMap<Integer, ReportExam> testedExam;
	private HashMap<Integer, Integer> examPositionMap; // <examId, position>
	private boolean isM03 = false;
	
	private int selectedExam = -1; // position of selected exam
	
	public ReportAdapter (Activity act, TreeMap<Integer, ReportExam> testedExam, boolean isM03) {
		this.act = act;
		this.testedExam = testedExam;
		this.isM03 = isM03;
		examPositionMap = new HashMap<Integer, Integer>();  
				
		if (isM03){
			if (testedExam != null) {
				m03List = new ArrayList<ReportExam>(testedExam.values());
			} else {
				m03List = new ArrayList<ReportExam>();
			}
		} else {
			if (Current.examList !=null) list = Current.examList;
			else list = new ArrayList<JsonExam>();
			for (int i=0; i<list.size(); i++) {
				examPositionMap.put(list.get(i).getId(), i);
			}
		}
	}
	
	@Override
	public int getCount() {
		if (isM03) return m03List.size();
		else return list.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	public int getSelectedExamPosition(int examId) {
		if (examPositionMap !=null && examPositionMap.get(examId)!=null){
			selectedExam = examPositionMap.get(examId);
		} else {
			selectedExam = -1; //default
		}
		return selectedExam;
	}
	
	private class ViewHolder{
		TextView text_conson, text_score, text_time_use, text_assess;
		CheckBox checkBox_re_practice;
		FrameLayout frame_re_practice, frame_assess;
		LinearLayout ll_cell;
	}
	
	private class CheckBoxHolder{
		int examId;
		String examName;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;
		LayoutInflater inflater = act.getLayoutInflater();
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.cell_report, null);
			holder = new ViewHolder();
			holder.ll_cell = (LinearLayout) convertView.findViewById(R.id.ll_cell);
			holder.text_conson = (TextView) convertView.findViewById(R.id.text_conson); 
			holder.text_score = (TextView) convertView.findViewById(R.id.text_score); 
			holder.text_time_use = (TextView) convertView.findViewById(R.id.text_time_use); 
			holder.text_assess = (TextView) convertView.findViewById(R.id.text_assess); 
			holder.checkBox_re_practice = (CheckBox) convertView.findViewById(R.id.checkBox_re_practice); 
			holder.frame_re_practice = (FrameLayout) convertView.findViewById(R.id.frame_re_practice);
			holder.frame_assess = (FrameLayout) convertView.findViewById(R.id.frame_assess);

			holder.checkBox_re_practice.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton buttonView,
						boolean isChecked) {
					CheckBoxHolder cbh  = (CheckBoxHolder) buttonView.getTag();
					if (cbh == null) {
						return;
					}
					if (Current.practiceList == null) Current.practiceList = new HashMap<Integer, String>();
					if (isChecked){
						Current.practiceList.put(cbh.examId, cbh.examName);
					} else {
						try {
							Current.practiceList.remove(cbh.examId); 
						} catch (Exception e) {e.printStackTrace();}
					}

				}});
			
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		CheckBoxHolder cb = new CheckBoxHolder();
//		int examId=-1;
		if (isM03){
			// m03 report
			ReportExam re = m03List.get(position);
			cb.examId = re.getExamId();
			cb.examName = re.getExamName();
//			examId = re.getExamId();
			holder.text_conson.setText(re.getExamName());
			holder.text_score.setText(re.getCorrect()+"/"+re.getTotal());
			holder.text_score.setContentDescription(act.getResources().getString(R.string.score) + re.getTotal() + act.getResources().getString(R.string.fraction) + re.getCorrect());
//			int score = re.getCorrect() *100 / (re.getTotal()*3);
//			holder.text_score.setText(score+"/100");
//			holder.text_score.setContentDescription(100 + act.getResources().getString(R.string.fraction) + score);
			holder.frame_assess.setVisibility(View.GONE);
		} else {
			JsonExam e = list.get(position);
			cb.examId = e.getId();
			cb.examName = e.getName();
//			examId = e.getId();
			holder.text_conson.setText(e.getName());
			if (testedExam.get(e.getId()) !=null) {
				ReportExam re = testedExam.get(e.getId());
				holder.text_score.setText(re.getCorrect()+"/"+re.getTotal());
				holder.text_score.setContentDescription(act.getResources().getString(R.string.score) + re.getTotal() + act.getResources().getString(R.string.fraction) + re.getCorrect());
				holder.text_time_use.setText(re.getTimeUse()+"s");
				holder.text_assess.setText(R.string.re_assess);
			} else {
				holder.text_score.setText("-");
				holder.text_score.setContentDescription(act.getResources().getString(R.string.no_result));
				holder.text_time_use.setText("-");
				holder.text_assess.setText(R.string.start_assess);
			}
		}
		holder.checkBox_re_practice.setTag(cb); //* for onClick use
//		holder.checkBox_re_practice.setTag(Integer.valueOf(examId)); //* for onClick use
//		if (Current.practiceList.contains(Integer.valueOf(examId))) {
		if (Current.practiceList.get(cb.examId)!=null) {
			holder.checkBox_re_practice.setChecked(true);
		} else {
			holder.checkBox_re_practice.setChecked(false);
		}
		if (User.isST && User.isAssess){
			holder.checkBox_re_practice.setVisibility(View.VISIBLE);
			holder.frame_re_practice.setVisibility(View.VISIBLE);
		} else{
			holder.checkBox_re_practice.setVisibility(View.GONE);
			holder.frame_re_practice.setVisibility(View.GONE);
		}
		
		// set current exam selected
		if (position == selectedExam) {
			holder.ll_cell.setBackgroundColor(act.getResources().getColor(R.color.skyblue));
		} else {
			holder.ll_cell.setBackgroundColor(act.getResources().getColor(R.color.transparent));
//			holder.ll_cell.setBackgroundColor(act.getResources().getColor(R.color.report_bg));
		}
		
		return convertView;
	}

}
