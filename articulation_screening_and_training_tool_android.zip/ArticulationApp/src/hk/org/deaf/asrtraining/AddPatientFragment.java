package hk.org.deaf.asrtraining;


import java.util.Calendar;

import hk.org.deaf.asrtraining.R;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.ReportManager;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import com.google.android.gms.analytics.Tracker;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import bean.Current;
import bean.Patient;
import bean.User;
import config.URLs;

public class AddPatientFragment extends Fragment{
	private final String tag = "AddPatientFragment";
	
	private View view;
	private ImageButton btn_back;
	private Button btn_add_new;
	private EditText et_yob, et_name, et_email;
	private boolean addSuccess = false;
	private ReportManager reportManager;
	private Handler mThreadHandler;
	private HandlerThread mThread;
	private Tracker t;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_add_patient, container, false);
		Current.page = tag;
		
		mThread = new HandlerThread("AddPatientFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		initView();
		return view;
	}
	private void initView(){
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		btn_add_new = (Button) view.findViewById(R.id.btn_add_new);
		et_yob = (EditText) view.findViewById(R.id.et_yob);
		et_name = (EditText) view.findViewById(R.id.et_name);
		et_email = (EditText) view.findViewById(R.id.et_email);
		
		btn_back.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Back");
				toPatient();
			}});
		
		btn_add_new.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Add New");
				boolean isValid  = true;
				String name = et_name.getText().toString();
				String yob = et_yob.getText().toString();
				String email = et_email.getText().toString();
				if (name ==null || name.trim().equals("") || name.length()>50) isValid = false;
				if (yob==null || yob.trim().equals("") || yob.length()!=4) isValid = false;
				if (email==null || email.trim().equals("") || email.length()>100) isValid = false;
				
				//** Gender and Hearing value handle PatientActivity; value checking here;				
				if (Patient.gender==null || Patient.gender.equals("")) isValid = false;	
				if (Patient.hearing==null || Patient.hearing.equals("")) isValid = false;	
					
				int year = Calendar.getInstance().get(Calendar.YEAR);
				int age = -1;
				try {
					age = year - Integer.parseInt(yob);
				} catch(Exception e){}
				
				if (isValid){
					// data from form
					Patient.name = name;
					Patient.yob = Integer.parseInt(yob);
					Patient.email = email;
					
					if (!InternetState.isOnline(getActivity())){
						Toast.makeText(getActivity(), R.string.no_network_connection,
								Toast.LENGTH_SHORT).show();
					} else {
						try {
							LoadingDialog.startDA(getActivity());
							mThreadHandler.post(executeAddPatient);
							synchronized (executeAddPatient) {
								executeAddPatient.wait();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						if (addSuccess) {
							User.isAssess = true;
							delAllReport();
							toExamAct();
						} else {
							LoadingDialog.endDA();
							Patient.reset();
							Toast.makeText(getActivity(), R.string.pa_get_error, Toast.LENGTH_SHORT).show();
						}
					}
				} else if (age<0 || age>99) {
					Toast.makeText(getActivity(), R.string.reg_age_error,
							Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(getActivity(), R.string.pa_form_error, Toast.LENGTH_SHORT).show();
				}
			}});
	}
	
	private void delAllReport(){
		//* App report data store by user/patient, need clear when change 
		if (reportManager == null) reportManager = new ReportManager(getActivity());
		reportManager.delAllReportExam();
	}
	
	private void toExamAct(){
		Intent i = new Intent();
		i.setClass(getActivity(), ExamActivity.class);
		startActivity(i);
		getActivity().overridePendingTransition( R.anim.up_slide_in, R.anim.up_slide_out );
		getActivity().finish();
	}
	
	private void toPatient(){
		PatientFragment f = new PatientFragment();
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
//		fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
		fragmentTransaction.replace(R.id.form_content, f); 
//		fragmentTransaction.addToBackStack(null);
//		fragmentTransaction.addToBackStack(tag);
		fragmentTransaction.commit(); 
	}
	
	private Runnable executeAddPatient = new Runnable(){
		public void run(){
			String url = URLs.postAddPatientURL(User.email, Patient.email, Patient.yob, Patient.name, Patient.gender, Patient.hearing);
			try {
				JSONObject json = GetJSON.postJSONObject(url, URLs.getNvp(), true);
				if (json!=null) {
					String result = json.getString("result");
					if (result!=null && result.trim().equals("success")){
						JSONObject jo = json.getJSONObject("client");
						Patient.centerId = jo.getInt("centerId");
						Patient.email = jo.getString("email");
						Patient.id = jo.getInt("id");
						Patient.name = jo.getString("name");
						Patient.tel = jo.getString("tel");
						Patient.yob = jo.getInt("yob");
						Patient.gender = jo.getString("gender");
						Patient.hearing = jo.getString("hearing");
						
						if (Patient.id<=0 || Patient.email==null || Patient.email.trim().equals("")){
							// json info error
							addSuccess = false;
						} else {
							addSuccess = true;
						}
					} else {
						//result error
						addSuccess  = false;
					}
				} else {
					// json null
					addSuccess  = false;
				}
			} catch (Exception e) {
				addSuccess = false;
				e.printStackTrace();
			}
			synchronized (executeAddPatient) {
				executeAddPatient.notify();
			}
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (reportManager != null){
			reportManager.close();
		} 
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeAddPatient);
		}
		if (mThread != null) mThread.quit();
	}
	
	@Override
	public void onStop() {
		super.onStop();
		LoadingDialog.endDA();
	}
}
