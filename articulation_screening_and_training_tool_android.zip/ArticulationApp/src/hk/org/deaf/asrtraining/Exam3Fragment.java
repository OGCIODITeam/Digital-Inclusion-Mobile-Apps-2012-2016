package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import manager.AppDownloadManger;
import manager.AudioCapture;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;
import manager.ReportManager;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.JsonWord;
import bean.JsonWord_M03;
import bean.Patient;
import bean.ReportExam;
import bean.User;

import com.google.android.gms.analytics.Tracker;

import config.Conf;
import config.I;
import config.URLs;

public class Exam3Fragment extends Fragment {
	private final String tag = "Exam3Fragment";

	private View view;
	private Button btn_record_start, btn_record_stop, btn_f;
	private ImageButton btn_back, btn_replay, btn_submit, btn_play, btn_exam3_next;
//	private ImageButton btn_back, btn_replay,  btn_play, btn_exam3_next;
//20150123	btn_record,
	private ImageView img_exam3_img, img_stars;
	//img_mic
//	, img_exam3_img_boder;
	private TextView text_exam3_text, text_qno_hint, text_exam_result; 
	private Chronometer meter_timer;
	private GridView grid_qty;
	private QuestionGridViewAdapter consonGridAdapter;
	private MediaPlayer mPlayer;

	private String audioPath;
	private String audioName;
	private String audioMode;
	private long audioSize;
//	private Boolean audioRecording = false;
//	private Boolean audioPlaying = false;

	private boolean isM03 = false;
	
	private int currentQty = 0; //count start from 0
	private String currentWord = "";
	private String currentInitial = "";
	private String currentVowel = "";
	private String currentFileName="";
	private int qtyId = 0;
	private int wordId = 0;
	private ArrayList<Integer> qtyNo;
	private Handler mThreadHandler;
	private HandlerThread mThread;
	private Bitmap bm_star0, bm_star1, bm_star2, bm_star3, bm_dummy_v;
	private int score = 0; //from server
	private boolean isCorrect = false; //from server
	private boolean isGarbage = false; //from server, if true notify user re record.
	private HashMap<Integer, Integer> scoreMap = null; //** m03: <qtyId, score>, m04 <qtyNo, score>; 20150108 when trure score=1, false score =0;
	private ReportManager reportManager;
	private Tracker t;
	private AlertDialog daRetry, daGarbage;

	private Animation anim_translate, anim_alpha;
	private CountDownTimer cd;
	
	private boolean isRight = true;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_exam_type3, container, false);
		Current.page = tag;
		mThread = new HandlerThread("Exam3FragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		
		cd = new recordingCountDown(3500,500);
		
		scoreMap = new HashMap<Integer, Integer>();
//		initView();
		isM03 = Current.module == Current.module_initial_a; // if  module 03(??????????????????) selected, get the random question list
		currentQty = 0;
		Current.correctMap = new HashMap<String, String>();
		Current.errorMap = new HashMap<String, String>();
		
		if (isM03){
			// set list to random
			if (Current.m03Map !=null && Current.m03Map.size()>0){
				qtyNo = new ArrayList<Integer>(Current.m03Map.keySet());
				java.util.Collections.shuffle(qtyNo);
			}
			audioMode = "ASSESS";
		} else {
			//Module 04 (??????????????????)
			qtyNo = new ArrayList<Integer>(Current.qtyMap.keySet());
			audioMode = "EXERCISE";
		}
		
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		
		if (qtyNo==null || qtyNo.size()==0){
			//TODO qty null
			Toast.makeText(getActivity(), R.string.question_empty, Toast.LENGTH_SHORT).show();
		} else {
			selectMaterial();
			Current.startTime = System.currentTimeMillis(); //Exam start time
		}
		
		return view;
	}

	private void initView() {
		// Animation
		anim_translate = AnimationUtils.loadAnimation(getActivity(), R.anim.translate);
		anim_translate.setFillAfter(true);
		anim_alpha = AnimationUtils.loadAnimation(getActivity(), R.anim.alpha);
		//Bitmap
		bm_star0 = BitmapFactory.decodeResource(getResources(), R.drawable.stars_n);
		bm_star1 = BitmapFactory.decodeResource(getResources(), R.drawable.stars_1);
		bm_star2 = BitmapFactory.decodeResource(getResources(), R.drawable.stars_2);
		bm_star3 = BitmapFactory.decodeResource(getResources(), R.drawable.stars_3);
		bm_dummy_v = BitmapFactory.decodeResource(getResources(), R.drawable.dummy_v);
		// Button
		btn_record_start = (Button) view.findViewById(R.id.btn_record_start);
		btn_record_stop = (Button) view.findViewById(R.id.btn_record_stop);
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		btn_f = (Button) view.findViewById(R.id.btn_f);
//		btn_record = (ImageButton) view.findViewById(R.id.btn_record);
		btn_submit = (ImageButton) view.findViewById(R.id.btn_submit);
		btn_replay = (ImageButton) view.findViewById(R.id.btn_replay);
		btn_play = (ImageButton) view.findViewById(R.id.btn_play);
		btn_exam3_next = (ImageButton) view.findViewById(R.id.btn_exam3_next);
		// ImageView
		img_exam3_img = (ImageView) view.findViewById(R.id.img_exam3_img);
//		img_mic = (ImageView) view.findViewById(R.id.img_mic);
		img_stars = (ImageView) view.findViewById(R.id.img_stars);
		// Chronometer
		meter_timer = (Chronometer) view.findViewById(R.id.meter_timer);
		// TextView
		text_exam3_text = (TextView) view.findViewById(R.id.text_exam3_text);
		text_qno_hint = (TextView) view.findViewById(R.id.text_qno_hint);
		text_exam_result = (TextView) view.findViewById(R.id.text_exam_result);
		
		//GridView
		grid_qty = (GridView) view.findViewById(R.id.grid_qty);

		text_exam_result.setVisibility(View.INVISIBLE);
		if (isM03) {
			text_qno_hint.setVisibility(View.VISIBLE);
			grid_qty.setVisibility(View.INVISIBLE);
		} else {
			grid_qty.setVisibility(View.VISIBLE);
			text_qno_hint.setVisibility(View.INVISIBLE);
			consonGridAdapter = new QuestionGridViewAdapter(
					getActivity(), qtyNo);
			grid_qty.setAdapter(consonGridAdapter);
			// Listener
			grid_qty.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					GA_Util.sendBtnEvent(t, tag, "Select Qty");
					consonGridAdapter.selected = position;
					consonGridAdapter.notifyDataSetChanged();
					currentQty = position;
					selectMaterial();
				}
			});
		}
		
		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
//				mThreadHandler.post(executeEndLoading);
				GA_Util.sendBtnEvent(t, tag, "Back");
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				if (isM03){
					ModuleFragment f = new ModuleFragment();
					fragmentTransaction.replace(R.id.rl_main_content, f);
				} else {
					ModuleConsonantFragment f = new ModuleConsonantFragment();
					fragmentTransaction.replace(R.id.rl_main_content, f);
				}
				fragmentTransaction.addToBackStack(tag);
				// fragmentTransaction.addToBackStack(null);
				fragmentTransaction.commit();
			}
		});

		btn_replay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Replay");
				startPlaying();
			}
		});

		btn_submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				isRight = true;
				if (InternetState.isOnline(getActivity())) {
					submitFunction();
				} else {
					Toast.makeText(getActivity(), R.string.no_network_connection,
							Toast.LENGTH_SHORT).show();
				}

			}
		});
		
		btn_f.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				isRight = false;
				if (InternetState.isOnline(getActivity())) {
					submitFunction();
				} else {
					Toast.makeText(getActivity(), R.string.no_network_connection,
							Toast.LENGTH_SHORT).show();
				}

			}
		});

		btn_record_start.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				if (cd !=null){
					cd.cancel();
					cd.start();
				} else {
					cd = new recordingCountDown(3000,500);
				}
				
				btn_record_start.setEnabled(false);
				GA_Util.sendBtnEvent(t, tag, "Record");
				btn_submit.clearAnimation();
				btn_submit.setVisibility(View.INVISIBLE);
				btn_f.setVisibility(View.INVISIBLE);
				meter_timer.clearAnimation();
				
//				img_mic.setVisibility(View.INVISIBLE);
				img_stars.setVisibility(View.INVISIBLE);
				text_exam_result.setVisibility(View.INVISIBLE);
				btn_exam3_next.setVisibility(View.INVISIBLE);
				//meter
				meter_timer.setBase(SystemClock.elapsedRealtime());
				meter_timer.setVisibility(View.VISIBLE);
				meter_timer.start();
				// audio capture
				if (User.isST && User.isAssess) {
					audioName = Patient.hearing+"_"+currentInitial + "_" + currentVowel + "_"
							+ Patient.id + "_" + Patient.name + "_"+Patient.gender+"_"+Current.patientAge+"_"
							+ android.os.Build.MODEL + "_" + I.now()
							+ Conf.AUDIO_RECORDER_FILE_EXT;
				} else {
					audioName = User.hearing+"_"+currentInitial + "_" + currentVowel + "_"
							+ User.id + "_" + User.name + "_"+User.gender+"_"+Current.userAge+"_"
							+ android.os.Build.MODEL + "_" + I.now()
							+ Conf.AUDIO_RECORDER_FILE_EXT;
				}
				audioPath = AudioCapture.getNewAudioFilePath(audioName); 
				AudioCapture.startRecording(audioPath);
				btn_replay.setEnabled(false);
				btn_play.setEnabled(false);
				btn_record_stop.setEnabled(true);
			}});
		
		btn_record_stop.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				cd.cancel();
				stopRecordFunction();
			}});
		
		
		btn_play.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Play");
				AudioCapture.startPlaying(audioPath);
			}
		});

		btn_exam3_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Next");
				stopPlaying();
				AudioCapture.deleteAllAudio(); //* del all audio file
				if (currentQty < qtyNo.size()-1) { //start from 0 so size-1
					currentQty++;
					if (!isM03){
						consonGridAdapter.selected = currentQty;
						consonGridAdapter.notifyDataSetChanged();
					}
					selectMaterial();
				} else {
//					LoadingDialog.startDA(getActivity());
					Current.endTime = System.currentTimeMillis(); //End Exam
					long timeUse = (Current.endTime-Current.startTime) / 1000; // change to second
					if (isM03) {
						// m03 report
						Current.m03Report = new TreeMap<Integer, ReportExam>();//<examId, report>
						for (Map.Entry<Integer, JsonWord_M03> entry : Current.m03Map.entrySet()){
							int examId = entry.getValue().getExamId();
							String examName = entry.getValue().getExamName();
							int thisScore = scoreMap.get(entry.getValue().getQuestionId());
							ReportExam re = Current.m03Report.get(entry.getValue().getExamId());
							if (re == null) {
								re = new ReportExam(Current.module, examId, examName, thisScore, 1);
								Current.m03Report.put(examId, re);
							} else {
								re.setCorrect(re.getCorrect() + thisScore);
								re.setTotal(re.getTotal() + 1);
								Current.m03Report.put(examId, re);
							}
						}
					} else {
						//report for module 04 module_initial_p
						int sum = 0;
						for ( Map.Entry<Integer, Integer> e : scoreMap.entrySet()){
							sum += e.getValue();
						}
						ReportExam e = new ReportExam(Current.module, Current.examId, sum, qtyNo.size(), timeUse);
//20150108						sum = sum * 100 / (scoreMap.size()*3) ; //temp to %
//20150108						ReportExam e = new ReportExam(Current.module, Current.examId, sum, 100, timeUse);
//						ReportExam e = new ReportExam(Current.module, Current.examId, sum, scoreMap.size()*3, timeUse);
						if (reportManager==null) reportManager = new ReportManager(getActivity());
						if (reportManager.isExist(Current.examId, Current.module)) {
							reportManager.updateReportExam(e);
						} else {
							reportManager.addReportExam(e);
						}
					}
					
					ReportFragment f = new ReportFragment();
					FragmentTransaction fragmentTransaction = getActivity()
							.getSupportFragmentManager().beginTransaction();
					fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
					fragmentTransaction.replace(R.id.rl_main_content, f);
					fragmentTransaction.addToBackStack(tag);
					// fragmentTransaction.addToBackStack(null);
					fragmentTransaction.commit();
				}
			}
		});

		//set disable / visibility
//		btn_exam3_next.setVisibility(View.INVISIBLE);
//		btn_submit.setVisibility(View.INVISIBLE);
//		btn_play.setEnabled(false);
	}

	private void stopRecordFunction(){
		btn_record_stop.setEnabled(false);
		AudioCapture.stopRecording();
		meter_timer.stop();
		meter_timer.startAnimation(anim_translate);
		btn_submit.startAnimation(anim_alpha);
		btn_submit.setVisibility(View.VISIBLE);
		btn_f.setVisibility(View.VISIBLE);
		int time = (int)(SystemClock.elapsedRealtime() - meter_timer.getBase())/1000;
		meter_timer.setContentDescription(time+"???");
		audioSize = AudioCapture.getFileSize(audioPath);
		btn_play.setEnabled(true);
		btn_replay.setEnabled(true);
		btn_record_start.setEnabled(true);
	}
	
	private void submitFunction(){
		meter_timer.clearAnimation();
		btn_submit.clearAnimation();
		
		btn_submit.setVisibility(View.INVISIBLE);
		btn_f.setVisibility(View.INVISIBLE);
		btn_exam3_next.setVisibility(View.VISIBLE);
		meter_timer.setVisibility(View.INVISIBLE);
	
		try {
			mThreadHandler.post(executeUploadAudio);
			synchronized (executeUploadAudio) {
				executeUploadAudio.wait();
			}
			GA_Util.sendBtnEvent(t, tag, "Submit");
		} catch (Exception e) {
		}
//		if (isM03){
//			switch(score){
//			case 0: img_stars.setImageBitmap(bm_star0);
//					img_stars.setContentDescription(getActivity().getResources().getString(R.string.star_n));
//					break;
//			case 1: img_stars.setImageBitmap(bm_star1);
//					img_stars.setContentDescription(getActivity().getResources().getString(R.string.star_1));
//					break;
//			case 2: img_stars.setImageBitmap(bm_star2);
//					img_stars.setContentDescription(getActivity().getResources().getString(R.string.star_2));
//					break;
//			case 3: img_stars.setImageBitmap(bm_star3);
//					img_stars.setContentDescription(getActivity().getResources().getString(R.string.star_3));
//					break;
//			default:img_stars.setImageBitmap(bm_star0);
//					img_stars.setContentDescription(getActivity().getResources().getString(R.string.star_n));
//					break;
//			}	
//			img_stars.setVisibility(View.VISIBLE);
//		} else {
			if (isCorrect) {
//				text_exam_result.setText(R.string.exam_t);
				text_exam_result.setText("Upload Success");
				text_exam_result.setTextColor(getActivity().getResources().getColor(R.color.green));
			} else {
//				text_exam_result.setText(R.string.exam_f);
				text_exam_result.setText("Upload Fail");
				text_exam_result.setTextColor(getActivity().getResources().getColor(R.color.darkred));
			}
			text_exam_result.setVisibility(View.VISIBLE);
//		}
		
		//save data for report 
//		if (isCorrect) {
//			Current.correctMap.put(""+qtyId, ""+wordId);
//			scoreMap.put(qtyNo.get(currentQty), 1);
//		} else {
//			Current.errorMap.put(""+qtyId, ""+wordId);
//			scoreMap.put(qtyNo.get(currentQty), 0);
//		}
		if (isGarbage) {
			showGarbage();
		}
	}
	
	private void startPlaying() {
		if (mPlayer != null)
			mPlayer.start();
		else
			Log.i(tag, "media null");
	}
	private void stopPlaying() {
		if (mPlayer != null && mPlayer.isPlaying()) {
			mPlayer.stop();
			mPlayer.release();
		}
	}
	private void selectMaterial() {
//		mThreadHandler.post(executeLoading);
		
		resetView();
		if (mPlayer == null) mPlayer = new MediaPlayer();
		
		if (isM03){
			// qty no hint
			text_qno_hint.setText((currentQty+1)+"/"+qtyNo.size());
			text_qno_hint.setContentDescription("???"+(currentQty+1)+"???");
			
			JsonWord_M03 w = Current.m03Map.get(qtyNo.get(currentQty));
			currentWord = w.getInitial()+w.getVowel();
			currentInitial = w.getInitial();
			currentVowel = w.getVowel();
			qtyId = w.getQuestionId();
			wordId = w.getWordId();
			//text
			text_exam3_text.setText(w.getWord());
//			//temp
//			mPlayer = MediaPlayer.create(getActivity(), R.raw.ph_1a);
//			img_exam3_img.setImageResource(R.drawable.ph_1a);
//			//end temp
			// TODO get from server when server is ready
			//image
			currentFileName = currentInitial+"_"+currentVowel+".png";
//			currentFileName = currentInitial+"_"+currentVowel+".jpg";
			if (img_exam3_img != null){
				try {
					((BitmapDrawable) img_exam3_img.getDrawable()).getBitmap().recycle();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			img_exam3_img.setImageBitmap(getImage(w.getPictureUploadDate()));
			//voice
			currentFileName = currentInitial+"_"+currentVowel+".mp3";
			getVoice(w.getSoundUploadDate());
		} else {
			//Module 04 (??????????????????)
			ArrayList<JsonWord> words = Current.qtyMap.get(qtyNo.get(currentQty));
			currentWord = words.get(0).getInitial()+words.get(0).getVowel();
			currentInitial = words.get(0).getInitial();
			currentVowel = words.get(0).getVowel();
			qtyId = words.get(0).getQuestionId();
			wordId = words.get(0).getId();
			//text
			text_exam3_text.setText(words.get(0).getWord());
//			//temp
//			mPlayer = MediaPlayer.create(getActivity(), R.raw.ph_1a);
//			img_exam3_img.setImageResource(R.drawable.ph_1a);
//			//end temp
			// TODO get from server when server is ready
			//image
			currentFileName = currentInitial+"_"+currentVowel+".png";
//			currentFileName = currentInitial+"_"+currentVowel+".jpg";
			if (img_exam3_img != null){
				try {
					((BitmapDrawable) img_exam3_img.getDrawable()).getBitmap().recycle();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			img_exam3_img.setImageBitmap(getImage(words.get(0).getPictureUploadDate()));
			//voice
			currentFileName = currentInitial+"_"+currentVowel+".mp3";
			getVoice(words.get(0).getSoundUploadDate());
		}
//		mThreadHandler.post(executeEndLoading);
	}

	private void resetView() {
		btn_exam3_next.setVisibility(View.INVISIBLE);
		btn_submit.setVisibility(View.INVISIBLE);
		btn_f.setVisibility(View.INVISIBLE);
		meter_timer.clearAnimation();
		meter_timer.setVisibility(View.INVISIBLE);
//		img_mic.setVisibility(View.VISIBLE);
		text_exam_result.setVisibility(View.INVISIBLE);
//		if (isM03) {
//			img_stars.setImageBitmap(bm_star0);
//			img_stars.setContentDescription(getActivity().getResources().getString(R.string.star_n));
//			img_stars.setVisibility(View.VISIBLE);
//		} else {
			img_stars.setVisibility(View.INVISIBLE);
//		}
		btn_play.setEnabled(false);
		
		btn_record_start.setEnabled(true);
		btn_record_stop.setEnabled(false);
	}

	private Bitmap getImage(long updateDate){
//		String imgPath = Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.IMAGE_FOLDER;
		String imgPath = Current.filePath + File.separator + Conf.IMAGE_FOLDER;
		Bitmap bm = BitmapFactory.decodeFile(imgPath+"/"+currentFileName);
		File temp = new File (imgPath+"/"+currentFileName);
		if (temp == null || !temp.exists() || temp.lastModified()<updateDate) {
			try {
				mThreadHandler.post(executeDownloadImg);
				synchronized (executeDownloadImg) {
					executeDownloadImg.wait();
				}
				bm = BitmapFactory.decodeFile(imgPath+"/"+currentFileName);
			} catch (Exception e) {}
		}
		if (bm == null){
			if (bm_dummy_v==null || bm_dummy_v.isRecycled()){
				bm_dummy_v = BitmapFactory.decodeResource(getResources(), R.drawable.dummy_v);
			}
			return bm_dummy_v;
		} else{
			return bm;
		}
	}
	
	private void getVoice(long updateDate){
//		String voicePath = Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.VOICE_FOLDER;
		String voicePath = Current.filePath + File.separator + Conf.VOICE_FOLDER;
		try {
			if (mPlayer!=null) mPlayer.release();
			mPlayer = new MediaPlayer();
			File voice = new File(voicePath+"/"+currentFileName);
			if (voice==null || !voice.exists() || voice.lastModified()<updateDate) {
				mThreadHandler.post(executeDownloadVoice);
				synchronized (executeDownloadVoice) {
					executeDownloadVoice.wait();
				}
			}
			mPlayer.setDataSource(voicePath+"/"+currentFileName);
			mPlayer.prepare();
		} catch (Exception e){}
	}
	
	private Runnable executeDownloadImg = new Runnable(){
		public void run(){
			AppDownloadManger.downloadImage(currentFileName);
			synchronized (executeDownloadImg) {
				executeDownloadImg.notify();
			}
		}
	};
	private Runnable executeDownloadVoice = new Runnable(){
		public void run(){
			AppDownloadManger.downloadVoice(currentFileName);
			synchronized (executeDownloadVoice) {
				executeDownloadVoice.notify();
			}
		}
	};
	
	private Runnable executeUploadAudio = new Runnable(){
		public void run(){
			String url = URLs.postAudioFileURL();
			HashMap<String, String> param = new HashMap<String, String>();
			param.put("filename", audioName);
			param.put("filesize", ""+audioSize);
			param.put("filecontent", currentWord.replaceAll("\\d", ""));
//			param.put("filecontent", currentWord);
			param.put("wordId", ""+wordId);
			param.put("mode", audioMode);
			param.put("type", ""+Current.type);
			//** user or patient id, if assess set to patient id
			if (User.isST && User.isAssess){
				param.put("clientId", ""+Patient.id); 
			} else {
				param.put("clientId", ""+User.id); 
			}
			param.put("examId", ""+Current.examId);
			param.put("module", ""+Current.module);
			param.put("questionId", ""+qtyId);
			if (isRight){
				param.put("correct", ""+1);
			} else {
				param.put("correct", ""+0);
			}
			
			try {
				JSONObject json = GetJSON.postAudioFile(url, param, audioPath, "uploadAudio");
				Log.i("TIM CHECKING",".....url= "+url+"             json= "+json);
				if (json!=null) {
//					double temp = json.getDouble("score");
//					score = (int) Math.round(temp);
//					isCorrect = json.getBoolean("isCorrect");
//					isGarbage = json.getBoolean("isGarbage");
					String result = json.getString("result");
					if (result.equals("success")) {
						isCorrect = true;
					} else {
						isCorrect = false;
					}
				} else {
					//json null
					score = 0;
					isCorrect = false;
					isGarbage = false;
				}
			} catch (FileNotFoundException fe) {
				// server down
				score = 0;
				isCorrect = false;
				isGarbage = false;
				fe.printStackTrace();
				
			    getActivity().runOnUiThread(new Runnable() {
			        public void run() {
			        	showRetry();
			        }
			    });
			} catch (SocketTimeoutException se) {
				// timeout
				score = 0;
				isCorrect = false;
				isGarbage = false;
				se.printStackTrace();
			    getActivity().runOnUiThread(new Runnable() {
			        public void run() {
			        	showRetry();
			        }
			    });
			} catch (Exception e) {
				score = 0;
				isCorrect = false;
				isGarbage = false;
				//not show toast in runnable
//				Toast.makeText(getActivity(), R.string.server_error,
//						Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			synchronized (executeUploadAudio) {
				executeUploadAudio.notify();
			}
		}
	};
	
	private Runnable executeLoading = new Runnable(){
		public void run(){
			LoadingDialog.startDA(getActivity());
//			synchronized (executeDownloadVoice) {
//				executeDownloadVoice.notify();
//			}
		}
	};
	private Runnable executeEndLoading = new Runnable(){
		public void run(){
			LoadingDialog.endDA();
//			synchronized (executeDownloadVoice) {
//				executeDownloadVoice.notify();
//			}
		}
	};
	
	
	private void showRetry() {
		if (daRetry==null) {
			Builder builder = new AlertDialog.Builder(getActivity());
			builder.setTitle(R.string.attention);
			builder.setMessage(R.string.network_error);
			builder.setPositiveButton(R.string.retry, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// try resubmit
					submitFunction();
				}
			});
			builder.setNegativeButton(R.string.close, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (daRetry !=null) daRetry.dismiss();
				}
			});
			daRetry = builder.create();
		}
		if (daRetry!=null) daRetry.dismiss();
 		daRetry.show();
	}
	
	private void showGarbage() {
		if (daGarbage==null) {
			Builder builder = new AlertDialog.Builder(getActivity());
			builder.setTitle(R.string.attention);
			builder.setMessage(R.string.garbage_error);
			builder.setNeutralButton(R.string.confirm, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (daGarbage !=null) daGarbage.dismiss();
				}
			});
			daGarbage = builder.create();
		}
		if (daGarbage!=null) daGarbage.dismiss();
		daGarbage.show();
	}
	
	private class recordingCountDown extends CountDownTimer {
		public recordingCountDown(long total, long unit) {
			super(total, unit);
		}

		@Override
		public void onFinish() {
			stopRecordFunction();
		}

		@Override
		public void onTick(long millisUntilFinished) {
		}
		
	}
	
	private void destoryView() {
		if (daRetry!=null){
			daRetry.dismiss();
			daRetry = null;
		}
		if (daGarbage!=null){
			daGarbage.dismiss();
			daGarbage = null;
		}
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
		AudioCapture.stopPlaying();

		try {
			img_exam3_img.getDrawable().setCallback(null);
			img_exam3_img.setImageDrawable(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
		AudioCapture.stopPlaying();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (reportManager !=null){
			reportManager.close();
		}
		Current.m03Map = null; //* reset module03 question map	
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeDownloadImg);
			mThreadHandler.removeCallbacks(executeDownloadVoice);
			mThreadHandler.removeCallbacks(executeUploadAudio);
			mThreadHandler.removeCallbacks(executeLoading);
			mThreadHandler.removeCallbacks(executeEndLoading);
		}
		if (mThread != null) {
			mThread.quit();
		}
		if (bm_star0!=null && !bm_star0.isRecycled()) {
			bm_star0.recycle();
			bm_star0=null;
		}
		if (bm_star1!=null && !bm_star1.isRecycled()) {
			bm_star1.recycle();
			bm_star1=null;
		}
		if (bm_star2!=null && !bm_star2.isRecycled()) {
			bm_star2.recycle();
			bm_star2=null;
		}
		if (bm_star3!=null && !bm_star3.isRecycled()) {
			bm_star3.recycle();
			bm_star3=null;
		}
		if (bm_dummy_v!=null && !bm_dummy_v.isRecycled()) {
			bm_dummy_v.recycle();
			bm_dummy_v=null;
		}
		try {
	    if (view.getBackground() != null) {
	        view.getBackground().setCallback(null);
	        view.setBackgroundDrawable(null);
	        }
		} catch (Exception e){}
		destoryView();
	}

	@Override
	public void onStop() {
		super.onStop();
//		mThreadHandler.post(executeEndLoading);
//		LoadingDialog.endDA();
	}
	
}
