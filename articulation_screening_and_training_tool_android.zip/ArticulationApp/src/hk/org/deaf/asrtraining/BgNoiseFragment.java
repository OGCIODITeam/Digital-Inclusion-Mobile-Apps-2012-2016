package hk.org.deaf.asrtraining;


import hk.org.deaf.asrtraining.R;

import java.util.HashMap;

import manager.AudioCapture;
import manager.GA_Util;
import manager.GetJSON;
import manager.InternetState;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;

import org.json.JSONObject;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import bean.Current;
import bean.Patient;
import bean.User;

import com.google.android.gms.analytics.Tracker;

import config.URLs;

public class BgNoiseFragment extends Fragment {
	private final String tag = "BgNoiseFragment";

	private View view;
	private Button btn_record_start, btn_record_stop;
	private ImageButton btn_back;
//20150123	, btn_record;
	private ImageView image_rec;
	private Chronometer meter_timer;
	private String noisePath;
	private Handler mThreadHandler;
	private HandlerThread mThread;
	private boolean uploadSuccess = false;
	private Tracker t;
	private CountDownTimer cd;
	private AnimationDrawable anim_rec;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_bg_noise, container, false);
		Current.page = tag;
		// Thread
		mThread = new HandlerThread("BgNoiseFragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		//CountDown
		cd = new myCountDown(5000,500);
		
		initView();
		return view;
	}
		
	private void initView() {
		//Image
		image_rec = (ImageView) view.findViewById(R.id.image_rec);
		anim_rec = (AnimationDrawable) image_rec.getBackground();
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
//20150123		btn_record = (ImageButton) view.findViewById(R.id.btn_record);
		btn_record_start = (Button) view.findViewById(R.id.btn_record_start);
		btn_record_stop = (Button) view.findViewById(R.id.btn_record_stop);
		// Chronometer
		meter_timer = (Chronometer) view.findViewById(R.id.meter_timer);
		
		btn_record_start.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				cd.start();
				btn_record_start.setEnabled(false);
				//anim
				anim_rec.start();
				//meter
				meter_timer.setBase(SystemClock.elapsedRealtime());
				meter_timer.setVisibility(View.VISIBLE);
				meter_timer.start();
				
				AudioCapture.deleteAllAudio(); // del all capture
				// noise capture
				noisePath = AudioCapture.getNoiseFilePath(); 
				AudioCapture.startRecording(noisePath);
				
//				audioRecording = true;
				GA_Util.sendBtnEvent(t, tag, "Record BG Noise");
				btn_record_stop.setEnabled(true);
			}});
		
		btn_record_stop.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				cd.cancel();
				anim_rec.stop();
				btn_record_stop.setEnabled(false);
				LoadingDialog.startDA(getActivity());
				meter_timer.stop();
				AudioCapture.stopRecording();
				long time = SystemClock.elapsedRealtime() - meter_timer.getBase();
				meter_timer.setContentDescription((time/1000)+"???");
				if (time>=4500){
					// more than 4.5 second to exam3
					if (InternetState.isOnline(getActivity())) { 
						try {
							mThreadHandler.post(executeUploadNoise);
							synchronized (executeUploadNoise) {
								executeUploadNoise.wait();
							}
							GA_Util.sendBtnEvent(t, tag, "Submit BG Noise");
							if (!uploadSuccess) {
								Toast.makeText(getActivity(), R.string.bg_noise_submit_error, Toast.LENGTH_SHORT).show();
							}
//							toNextPage();
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						// * Not in db and not internet connection
						Toast.makeText(getActivity(), getActivity().getResources().getText(R.string.no_network_connection) +" "+ getActivity().getResources().getText(R.string.bg_noise_not_submit),
								Toast.LENGTH_SHORT).show();
						toNextPage(); // to exam if no network
					}
					toNextPage();
				} else {
					btn_record_start.setEnabled(true);
					LoadingDialog.endDA();
					Toast.makeText(getActivity(), R.string.bg_noise_too_short, Toast.LENGTH_SHORT).show();
				}
				
			}});
		
//** do not del may reuse
//		btn_record.setOnTouchListener(new OnTouchListener(){
//			@Override
//			public boolean onTouch(View v, MotionEvent event) {
//				// Animation
//				
//				if (event.getAction() == MotionEvent.ACTION_DOWN){
//					//Touch
//					//meter
//					meter_timer.setBase(SystemClock.elapsedRealtime());
//					meter_timer.setVisibility(View.VISIBLE);
//					meter_timer.start();
//					
//					AudioCapture.deleteAllAudio(); // del all capture
//					// noise capture
//					noisePath = AudioCapture.getNoiseFilePath(); 
//					AudioCapture.startRecording(noisePath);
////					audioRecording = true;
//					GA_Util.sendBtnEvent(t, tag, "Record BG Noise");
//				} else if (event.getAction() == MotionEvent.ACTION_UP){
//					//Release
//					LoadingDialog.startDA(getActivity());
//					meter_timer.stop();
//					AudioCapture.stopRecording();
//					long time = SystemClock.elapsedRealtime() - meter_timer.getBase();
//					meter_timer.setContentDescription((time/1000)+"???");
//					if (time>=4500){
//						// more than 4.5 second to exam3
//						if (InternetState.isOnline(getActivity())) { 
//							try {
//								mThreadHandler.post(executeUploadNoise);
//								synchronized (executeUploadNoise) {
//									executeUploadNoise.wait();
//								}
//								GA_Util.sendBtnEvent(t, tag, "Submit BG Noise");
//								if (!uploadSuccess) {
//									Toast.makeText(getActivity(), R.string.bg_noise_submit_error, Toast.LENGTH_SHORT).show();
//								}
//								toNextPage();
//							} catch (Exception e) {
//								e.printStackTrace();
//							}
//						} else {
//							// * Not in db and not internet connection
//							Toast.makeText(getActivity(), getActivity().getResources().getText(R.string.no_network_connection) +" "+ getActivity().getResources().getText(R.string.bg_noise_not_submit),
//									Toast.LENGTH_SHORT).show();
//							toNextPage(); // to exam if no network
//						}
//					} else {
//						LoadingDialog.endDA();
//						Toast.makeText(getActivity(), R.string.bg_noise_too_short, Toast.LENGTH_SHORT).show();
//					}
//				}
//				
//				return false;
//			}});
		
		btn_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				cd.cancel();
				anim_rec.stop();
				GA_Util.sendBtnEvent(t, tag, "Back");
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				ModuleFragment f = new ModuleFragment();
				fragmentTransaction.replace(R.id.rl_main_content, f);
//				fragmentTransaction.addToBackStack(null);
//				fragmentTransaction.addToBackStack(tag);
				fragmentTransaction.commit();
			}
		});

	}
	
	private void toNextPage() {
		FragmentTransaction fragmentTransaction = getActivity()
				.getSupportFragmentManager().beginTransaction();
		fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
		if (Current.module == Current.module_initial_a){
			Exam3Fragment f = new Exam3Fragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		} else {
			ModuleConsonantFragment f = new ModuleConsonantFragment();
			fragmentTransaction.replace(R.id.rl_main_content, f);
		}
//		fragmentTransaction.addToBackStack(null);
//		fragmentTransaction.addToBackStack(tag);
		fragmentTransaction.commit();
	}
	
	private class myCountDown extends CountDownTimer {
		public myCountDown(long total, long unit) {
			super(total, unit);
		}

		@Override
		public void onFinish() {
			meter_timer.stop();
			btn_record_stop.setEnabled(false);
			AudioCapture.stopRecording();
			if (InternetState.isOnline(getActivity())) { 
				try {
					mThreadHandler.post(executeUploadNoise);
					synchronized (executeUploadNoise) {
						executeUploadNoise.wait();
					}
					GA_Util.sendBtnEvent(t, tag, "Submit BG Noise");
					if (!uploadSuccess) {
						Toast.makeText(getActivity(), R.string.bg_noise_submit_error, Toast.LENGTH_SHORT).show();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			toNextPage();
		}

		@Override
		public void onTick(long millisUntilFinished) {
		}
	}
	
	private Runnable executeUploadNoise = new Runnable(){
		public void run(){
			String url = URLs.postNoiseFileURL();
			HashMap<String, String> param = new HashMap<String, String>();
			param.put("type", ""+Current.type); 
			//** user or patient id, if assess set to patient id
			if (User.isST && User.isAssess){
				param.put("clientId", ""+Patient.id); 
			} else {
				param.put("clientId", ""+User.id); 
			}
			param.put("module", ""+Current.module);
			
			try {
				JSONObject json = GetJSON.postAudioFile(url, param, noisePath, "uploadAudio");
				if (json!=null) {
					String result = json.getString("result");
					if (result !=null && result.trim().equals("success")){
						uploadSuccess = true;
					} else {
						uploadSuccess = false;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			synchronized (executeUploadNoise) {
				executeUploadNoise.notify();
			}
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeUploadNoise);
		}
		if (mThread != null) {
			mThread.quit();
		}
		try{
			if (view.getBackground() != null) {
				view.getBackground().setCallback(null);
				view.setBackgroundDrawable(null);
	        }
		} catch (Exception e){}
	}
	
	@Override
	public void onStop() {
		super.onStop();
		LoadingDialog.endDA();
	}
}
