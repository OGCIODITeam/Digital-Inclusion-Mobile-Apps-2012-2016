package hk.org.deaf.asrtraining;

import hk.org.deaf.asrtraining.R;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import manager.AppDownloadManger;
import manager.GA_Util;
import manager.LoadingDialog;
import manager.MyAnalytics;
import manager.MyAnalytics.TrackerName;
import manager.ReportManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import bean.Current;
import bean.JsonWord;
import bean.ReportExam;

import com.google.android.gms.analytics.Tracker;

import config.Conf;

public class Exam1Fragment extends Fragment {


	private final String tag = "Exam1Fragment";

	private View view;
	private ImageButton btn_back, btn_reset, btn_ans1_next, btn_ans2_next, btn_replay;
	private LinearLayout ll_ans1, ll_ans2;
	private ImageView  img_ans1_img_boder,
			img_ans2_img_boder;
	private ImageView img_hint, img_ans1_img, img_ans2_img;
	private GridView grid_qty;
	private TextView text_ans1_text, text_ans2_text, text_qno_hint;
	private MediaPlayer mPlayer;
	
	private static int currentQty = 0; //count start from 0
	private static String currentFileName="";
	private ArrayList<Integer> qtyNo;
	private Handler mThreadHandler;
	private HandlerThread mThread;
	
	private ReportManager reportManager;
	private int trueAns = 0; // random answer
	private QuestionGridViewAdapter consonGridAdapter;
	
	private boolean isAssess = false; // if assess show hint and  no menu; module01 is assess
	private Tracker t;
	private Bitmap bm_dummy_v;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_exam_type1, container, false);
		Current.page = tag;
		mThread = new HandlerThread("Exam1FragmentHandlerThread");
		mThread.start();
		mThreadHandler = new Handler(mThread.getLooper());
		
		isAssess = Current.module == Current.module_listen_a;
		
		currentQty = 0;
		Current.correctMap = new HashMap<String, String>();
		Current.errorMap = new HashMap<String, String>();
		
		qtyNo = new ArrayList<Integer>(Current.qtyMap.keySet());
		//GA
		t = ((MyAnalytics) getActivity().getApplication()).getTracker(TrackerName.APP_TRACKER);
		GA_Util.sendScreen(t, tag);
		
		initView();
		if (qtyNo==null || qtyNo.size()==0){
			//TODO qty null
			Toast.makeText(getActivity(), R.string.question_empty,
					Toast.LENGTH_SHORT).show();
		} else {
			selectMaterial();
			startPlaying();
			Current.startTime = System.currentTimeMillis(); //Exam start time
		}
		return view;
	}

	private void initView() {
		//Bitmap
		bm_dummy_v = BitmapFactory.decodeResource(getResources(), R.drawable.dummy_v);
		// Button
		btn_back = (ImageButton) view.findViewById(R.id.btn_back);
		btn_replay = (ImageButton) view.findViewById(R.id.btn_replay);
		btn_reset = (ImageButton) view.findViewById(R.id.btn_reset);
		btn_ans1_next = (ImageButton) view.findViewById(R.id.btn_ans1_next);
		btn_ans2_next = (ImageButton) view.findViewById(R.id.btn_ans2_next);
		
		// RelativeLayout
		ll_ans1 = (LinearLayout) view.findViewById(R.id.ll_ans1);
		ll_ans2 = (LinearLayout) view.findViewById(R.id.ll_ans2);
		// ImageView
		img_ans1_img_boder = (ImageView) view.findViewById(R.id.img_ans1_img_boder);
		img_ans2_img_boder = (ImageView) view.findViewById(R.id.img_ans2_img_boder);


		img_hint = (ImageView) view.findViewById(R.id.img_hint);
		img_ans1_img = (ImageView) view.findViewById(R.id.img_ans1_img);
		img_ans2_img = (ImageView) view.findViewById(R.id.img_ans2_img);
		// TextView
		text_ans1_text = (TextView) view.findViewById(R.id.text_ans1_text);
		text_ans2_text = (TextView) view.findViewById(R.id.text_ans2_text);
		text_qno_hint = (TextView) view.findViewById(R.id.text_qno_hint);
		//GridView
		grid_qty = (GridView) view.findViewById(R.id.grid_qty);
		if (isAssess) {
			grid_qty.setVisibility(View.INVISIBLE);
			text_qno_hint.setVisibility(View.VISIBLE);
			btn_reset.setVisibility(View.VISIBLE);
			btn_reset.setEnabled(false);
//TODO			img_ans1_img_boder.setImageResource(R.drawable.broder_v2_n);
//			img_ans2_img_boder.setImageResource(R.drawable.broder_v2_n);
		} else {
			grid_qty.setVisibility(View.VISIBLE);
			text_qno_hint.setVisibility(View.INVISIBLE);
			btn_reset.setVisibility(View.INVISIBLE);
//TODO			img_ans1_img_boder.setImageResource(R.drawable.box_level1_answer_n);
//			img_ans2_img_boder.setImageResource(R.drawable.box_level1_answer_n);
			
			consonGridAdapter = new QuestionGridViewAdapter(
					getActivity(), qtyNo);
			grid_qty.setAdapter(consonGridAdapter);
			// Listener
			grid_qty.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					GA_Util.sendBtnEvent(t, tag, "Qty Sel");
					consonGridAdapter.selected = position;
					consonGridAdapter.notifyDataSetChanged();
					currentQty = position;
					resetView();
					selectMaterial();
					startPlaying();
				}
			});
		}
		btn_back.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//GA
				GA_Util.sendBtnEvent(t, tag, "Back");
//				mThreadHandler.post(executeEndLoading);
				ModuleConsonantFragment f = new ModuleConsonantFragment();
				FragmentTransaction fragmentTransaction = getActivity()
						.getSupportFragmentManager().beginTransaction();
//				fragmentTransaction.setCustomAnimations(R.anim.down_slide_in, R.anim.down_slide_out);
				fragmentTransaction.replace(R.id.rl_main_content, f);
				fragmentTransaction.addToBackStack(tag);
				// fragmentTransaction.addToBackStack(null);
				fragmentTransaction.commit();
			}
		});

		btn_replay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Replay");
				startPlaying();
			}
		});
		btn_reset.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				resetView();
				selectMaterial();
				startPlaying();
			}
		});

		ll_ans1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Answer 1");
				ll_ans2.setClickable(false);
				btn_ans1_next.setVisibility(View.VISIBLE);
				String qId = "" + Current.qtyMap.get(qtyNo.get(currentQty)).get(0).getQuestionId();
				String w01Id = "" + Current.qtyMap.get(qtyNo.get(currentQty)).get(0).getId();
				String w02Id = "" + Current.qtyMap.get(qtyNo.get(currentQty)).get(1).getId();
				if (trueAns==0){
//TODO					img_ans1_img_boder.setImageResource(R.drawable.broder_v2_t);
					img_ans1_img_boder.setImageResource(R.drawable.box_level1_answer_t);
					Current.correctMap.put(qId, w01Id);
				} else {
//TODO					img_ans2_img_boder.setImageResource(R.drawable.broder_v2_f);
					img_ans2_img_boder.setImageResource(R.drawable.box_level1_answer_f);
					Current.errorMap.put(qId, w02Id);
				}
				if (isAssess) {
					btn_reset.setEnabled(true);
				}
				btn_replay.setEnabled(false);
			}
		});
		ll_ans2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GA_Util.sendBtnEvent(t, tag, "Answer 2");
				ll_ans1.setClickable(false);
				btn_ans2_next.setVisibility(View.VISIBLE);
				String qId = "" + Current.qtyMap.get(qtyNo.get(currentQty)).get(0).getQuestionId();
				String w01Id = "" + Current.qtyMap.get(qtyNo.get(currentQty)).get(0).getId();
				String w02Id = "" + Current.qtyMap.get(qtyNo.get(currentQty)).get(1).getId();
			    if (trueAns==1){
//TODO					img_ans2_img_boder.setImageResource(R.drawable.broder_v2_t);
					img_ans2_img_boder.setImageResource(R.drawable.box_level1_answer_t);
					Current.correctMap.put(qId, w02Id);
				} else {
//TODO					img_ans1_img_boder.setImageResource(R.drawable.broder_v2_f);
					img_ans1_img_boder.setImageResource(R.drawable.box_level1_answer_f);
					Current.errorMap.put(qId, w01Id);
				}
				if (isAssess) {
					btn_reset.setEnabled(true);
				}
				btn_replay.setEnabled(false);
			}
		});
		btn_ans1_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				nextBtnEvent();
			}
		});
		btn_ans2_next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				nextBtnEvent();
			}
		});
	}

	private void startPlaying() {
		if (mPlayer != null)
			mPlayer.start();
		else
			Log.i(tag, "media null");
	}

	private void selectMaterial() {
//		mThreadHandler.post(executeLoading);
		
		if (isAssess){
			text_qno_hint.setText((currentQty+1)+"/"+qtyNo.size());
			text_qno_hint.setContentDescription("???"+(currentQty+1)+"???");
		}
		
		Random r = new Random();
		trueAns = r.nextInt(99)%2; // random answer
		
		if (mPlayer == null) mPlayer = new MediaPlayer(); // new MediaPlayer if null
		ArrayList<JsonWord> words = Current.qtyMap.get(qtyNo.get(currentQty));
		//word01
		text_ans1_text.setText(words.get(0).getWord());
		//image01
//		currentFileName = "s_aam1.png";
		currentFileName = words.get(0).getInitial()+"_"+words.get(0).getVowel()+".png";
//		currentFileName = words.get(0).getInitial()+"_"+words.get(0).getVowel()+".jpg";
//		if (img_ans1_img != null){
//			try { ((BitmapDrawable) img_ans1_img.getDrawable()).getBitmap().recycle(); } catch(Exception e){}
//		}
		img_ans1_img.setImageBitmap(getImage(words.get(0).getPictureUploadDate()));
		//voice01
//		if (words.get(0).getIsCorrect()==1){
		if (trueAns==0){
			currentFileName = words.get(0).getInitial()+"_"+words.get(0).getVowel()+".mp3";
			getVoice(words.get(0).getSoundUploadDate());
		}
		//wod002
		text_ans2_text.setText(words.get(1).getWord());
		//image02
		currentFileName = words.get(1).getInitial()+"_"+words.get(1).getVowel()+".png";
//		currentFileName = words.get(1).getInitial()+"_"+words.get(1).getVowel()+".jpg";
//		if (img_ans2_img != null){
//			try { ((BitmapDrawable) img_ans2_img.getDrawable()).getBitmap().recycle(); } catch(Exception e){}
//		}
		img_ans2_img.setImageBitmap(getImage(words.get(1).getPictureUploadDate()));
		//voice02
//		if (words.get(1).getIsCorrect()==1){
		if (trueAns==1){
			currentFileName = words.get(1).getInitial()+"_"+words.get(1).getVowel()+".mp3";
			getVoice(words.get(1).getSoundUploadDate());
		}

		//		mThreadHandler.post(executeEndLoading);
	}		

	private Bitmap getImage(long updateDate){
//		String imgPath = Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.IMAGE_FOLDER;
		String imgPath = Current.filePath + File.separator + Conf.IMAGE_FOLDER;
		Bitmap bm = BitmapFactory.decodeFile(imgPath+"/"+currentFileName);
		File temp = new File (imgPath+"/"+currentFileName);
		if (temp == null || !temp.exists() || temp.lastModified()<updateDate) {
			try {
				mThreadHandler.post(executeDownloadImg);
				synchronized (executeDownloadImg) {
					executeDownloadImg.wait();
				}
				bm = BitmapFactory.decodeFile(imgPath+"/"+currentFileName);
			} catch (Exception e) {
			}
		}
		if (bm == null){
			if (bm_dummy_v==null || bm_dummy_v.isRecycled()){
				bm_dummy_v = BitmapFactory.decodeResource(getResources(), R.drawable.dummy_v);
			}
			return bm_dummy_v;
		} else{
			return bm;
		}
	}
	
	private void getVoice(long updateDate){
//		String voicePath = Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.VOICE_FOLDER;
		String voicePath = Current.filePath + File.separator + Conf.VOICE_FOLDER;
		try {
			if (mPlayer!=null) mPlayer.release();
			mPlayer = new MediaPlayer();
			File voice = new File(voicePath+"/"+currentFileName);
			if (voice==null || !voice.exists() || voice.lastModified()<updateDate) {
				mThreadHandler.post(executeDownloadVoice);
				synchronized (executeDownloadVoice) {
					executeDownloadVoice.wait();
				}
			}
			mPlayer.setDataSource(voicePath+"/"+currentFileName);
			mPlayer.prepare();
		} catch (Exception e){}
	}
	
	private void nextBtnEvent() {
		if (currentQty < qtyNo.size()-1) { //start from 0 so size-1
			GA_Util.sendBtnEvent(t, tag, "Next Qty");
			currentQty++;
			//update list view
			if (!isAssess) {
				consonGridAdapter.selected = currentQty;
				consonGridAdapter.notifyDataSetChanged();
			}
			resetView();
			selectMaterial();
			startPlaying();
		} else {
			GA_Util.sendBtnEvent(t, tag, "To Report");
//			LoadingDialog.startDA(getActivity());
			//Save end exam data
			Current.endTime = System.currentTimeMillis(); //End Exam
			long timeUse = (Current.endTime-Current.startTime) / 1000; // change to second
//			ReportExam e = new ReportExam(Current.module, Current.examId, correctQtyId.size(), qtyNo.size(), timeUse);
			ReportExam e = new ReportExam(Current.module, Current.examId, Current.correctMap.size(), qtyNo.size(), timeUse);
			if (reportManager==null) reportManager = new ReportManager(getActivity());
			if (reportManager.isExist(Current.examId, Current.module)) {
				reportManager.updateReportExam(e);
			} else {
				reportManager.addReportExam(e);
			}
			// to report fragment
			ReportFragment f = new ReportFragment();
			FragmentTransaction fragmentTransaction = getActivity()
					.getSupportFragmentManager().beginTransaction();
			fragmentTransaction.setCustomAnimations(R.anim.up_slide_in, R.anim.up_slide_out);
			fragmentTransaction.replace(R.id.rl_main_content, f);
			// fragmentTransaction.addToBackStack(null);
			fragmentTransaction.commit();
		}
	}
	
	private Runnable executeDownloadImg = new Runnable(){
		public void run(){
			AppDownloadManger.downloadImage(currentFileName);
			synchronized (executeDownloadImg) {
				executeDownloadImg.notify();
			}
		}
	};

	private Runnable executeDownloadVoice = new Runnable(){
		public void run(){
			AppDownloadManger.downloadVoice(currentFileName);
			synchronized (executeDownloadVoice) {
				executeDownloadVoice.notify();
			}
		}
	};
	
	private Runnable executeLoading = new Runnable(){
		public void run(){
			LoadingDialog.startDA(getActivity());
		}
	};
	private Runnable executeEndLoading = new Runnable(){
		public void run(){
			LoadingDialog.endDA();
		}
	};
	
	private void resetView() {
		ll_ans1.setClickable(true);
		ll_ans2.setClickable(true);
		btn_ans1_next.setVisibility(View.INVISIBLE);
		btn_ans2_next.setVisibility(View.INVISIBLE);
//TODO		img_ans1_img_boder.setImageResource(R.drawable.broder_v2_n);
//TODO		img_ans2_img_boder.setImageResource(R.drawable.broder_v2_n);
		img_ans1_img_boder.setImageResource(R.drawable.box_level1_answer_n);
		img_ans2_img_boder.setImageResource(R.drawable.box_level1_answer_n);
		if (isAssess) {
			btn_reset.setEnabled(false);
		}
		btn_replay.setEnabled(true);
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
//		correctQtyId = null;
		if (reportManager !=null){
			reportManager.close();
		}
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
		if (mThreadHandler != null) {
			mThreadHandler.removeCallbacks(executeDownloadImg);
			mThreadHandler.removeCallbacks(executeDownloadVoice);
			mThreadHandler.removeCallbacks(executeLoading);
			mThreadHandler.removeCallbacks(executeEndLoading);
		}
		if (mThread != null) mThread.quit();
		if (bm_dummy_v!=null && !bm_dummy_v.isRecycled()) {
			bm_dummy_v.recycle();
			bm_dummy_v=null;
		}
		try {
		    if (view.getBackground() != null) {
		        view.getBackground().setCallback(null);
		        view.setBackgroundDrawable(null);
		    }
			img_ans1_img_boder.getDrawable().setCallback(null);
			img_ans1_img_boder.setImageDrawable(null);
			img_ans2_img_boder.getDrawable().setCallback(null);
			img_ans2_img_boder.setImageDrawable(null);
			img_hint.getDrawable().setCallback(null);
			img_hint.setImageDrawable(null);
			img_ans1_img.getDrawable().setCallback(null);
			img_ans1_img.setImageDrawable(null);
			img_ans2_img.getDrawable().setCallback(null);
			img_ans2_img.setImageDrawable(null);
		} catch (Exception e) {
			Log.i(tag,".......................destoryView remove img call back exception");
		}
	}
	
	@Override
	public void onStop() {
		super.onStop();
//		mThreadHandler.post(executeEndLoading);
//		LoadingDialog.endDA();
	}
}
