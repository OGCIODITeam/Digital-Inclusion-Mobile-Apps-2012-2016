package config;

import java.text.SimpleDateFormat;

public class I {
	
	//TODO Date format
	private static SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmsss");
	
	public static String now() {
		return df.format(System.currentTimeMillis());
	}

	
	//TODO Device Info
    public static String osVersion = System.getProperty("os.version");
    public static String apiLevel = ""+android.os.Build.VERSION.SDK_INT;
    public static String androidVersion = android.os.Build.VERSION.RELEASE;
    public static String device = android.os.Build.DEVICE;
    public static String model = android.os.Build.MODEL;
    public static String product = android.os.Build.PRODUCT;
    public static String brand = android.os.Build.BRAND;
}
