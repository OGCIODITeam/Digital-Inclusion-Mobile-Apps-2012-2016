package config;

public class Conf {
	
	private final String tag = "Conf";
	
	public static final String materialFolder = "ArticulationApp";
	
	//TODO audio file type setting
	public static final String AUDIO_RECORDER_FILE_EXT = ".wav";
	public static final String AUDIO_RECORDER_FOLDER = "Audio"; // for recording and bg noise
	public static final int RECORDER_SAMPLERATE = 16000; // 8000, 16000 and 44100 Hz for WAV
	public static final int RECORDER_CHANNELS = 1; // 1 (mono) or 2 (stereo)
	public static final int RECORDER_AUDIO_BitRate = 16; // 8 or 16 bit for WAV
	
	public static final String IMAGE_FOLDER = "Image";
	public static final String VOICE_FOLDER = "Voice"; // exam sound files
//save to Audio file	public static final String NOISE_FOLDER = "Noise"; // device background noise
	
	public static final String SP_NAME = "ArticulationApp_SP"; //SharedPreferences name
}
