package config;

public class Link {
	public final static String URLPRODM = "XXXXXX";
	public final static String URLUAT = "XXXXXX";
	public final static String URLDEV = "XXXXXX";
	public final static String USTDEV = "XXXXXXX";

	public final static String[] URLArray = {"", URLPRODM, URLUAT, URLDEV, USTDEV};
	public final static String domain = URLArray[3];
	
	public final static String URLRest = domain +"rest/";
	public final static String URLImage = domain.replace("articulation/", "") + "RESOURCES/ARTICULATION/images/"; 
	public final static String URLVoice = domain.replace("articulation/","") + "RESOURCES/ARTICULATION/voices/"; 
	
}
