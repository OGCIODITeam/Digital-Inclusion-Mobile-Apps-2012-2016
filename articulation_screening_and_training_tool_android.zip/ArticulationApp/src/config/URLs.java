package config;

import hk.org.deaf.asrtraining.LaunchActivity;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import bean.Patient;
import bean.User;
import android.util.Log;

public class URLs {
	
	private static ArrayList<NameValuePair> nvp = null;
	public static ArrayList<NameValuePair> getNvp() {
		if (nvp==null) {
			nvp = new ArrayList<NameValuePair>();
			Log.i("URLs", "URLS getNvp() null");
		}
		return nvp;
	}
	//POST
	public static String postRegisterURL(String yob, String name, String email, String password, String gender, String hearing) {
		String url = Link.URLRest + "register";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("yob", yob));
		nvp.add(new BasicNameValuePair("name", name));
		nvp.add(new BasicNameValuePair("email", email));
		nvp.add(new BasicNameValuePair("password", password));
		nvp.add(new BasicNameValuePair("gender", gender));
		nvp.add(new BasicNameValuePair("hearing", hearing));
		
		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return url;
	}
	
	public static String postLoginURL(String email, String password) {
		String loginURL = Link.URLRest + "accesstoken";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("login", email));
		nvp.add(new BasicNameValuePair("password", password));
		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return loginURL;
	}
	
	public static String postAddPatientURL(String stEmail, String clientEmail, int yob, String clientName, String gender, String hearing) {
		String url = Link.URLRest + "center";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("stEmail", stEmail));
		nvp.add(new BasicNameValuePair("clientEmail", clientEmail));
		nvp.add(new BasicNameValuePair("yob", ""+yob));
		nvp.add(new BasicNameValuePair("name", clientName));
		nvp.add(new BasicNameValuePair("gender", gender));
		nvp.add(new BasicNameValuePair("hearing", hearing));
		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return url;
	}
	
	public static String postAudioFileURLv2(String filename, String filesize, String filecontent, String wordId, String mode, String type, String clientId, String examId, String module, String questionId, String uploadAudio) { //v2
		String URL = Link.URLRest + "audios";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("filename", filename));
		nvp.add(new BasicNameValuePair("filesize", filesize));
		nvp.add(new BasicNameValuePair("filecontent", filecontent));
		nvp.add(new BasicNameValuePair("wordId", wordId));
		nvp.add(new BasicNameValuePair("mode", mode));
		nvp.add(new BasicNameValuePair("type", type));
		nvp.add(new BasicNameValuePair("clientId", clientId));
		nvp.add(new BasicNameValuePair("module", module));
		nvp.add(new BasicNameValuePair("examId", examId));
		nvp.add(new BasicNameValuePair("questionId", questionId));
		nvp.add(new BasicNameValuePair("uploadAudio", uploadAudio));
		
		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return URL;
	}
	
//20150408
	public static String postAudioFileURL() {
		String URL = Link.URLRest + "grepRecord";
		return URL;
	}
	
	public static String postNoiseFileURL() {
		String URL = Link.URLRest + "bgnoise";
		return URL;
	}
	
	public static String postReportURL(int moduleType, int moduleId, int examId, String correctStr, String errorStr, double latitude, double longitude) {
		String url = Link.URLRest + "saveRecord";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("type", ""+moduleType));
		//** user or patient id, if assess set to patient id
		if (User.isST && User.isAssess){
			nvp.add(new BasicNameValuePair("clientId", ""+Patient.id));
		} else {
			nvp.add(new BasicNameValuePair("clientId", ""+User.id));
		}
		nvp.add(new BasicNameValuePair("examId", ""+examId));
		nvp.add(new BasicNameValuePair("module", ""+moduleId));
		nvp.add(new BasicNameValuePair("tMap", correctStr));
		nvp.add(new BasicNameValuePair("fMap", errorStr));
		nvp.add(new BasicNameValuePair("latitude", ""+latitude));
		nvp.add(new BasicNameValuePair("longitude", ""+longitude));
		
		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return url;
	}
	
	public static String postSuggestExercise(String stEmail, String clientEmail, int module, String examMapStr) {
		String url = Link.URLRest + "suggestExercise";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("stEmail", stEmail));
		nvp.add(new BasicNameValuePair("clientEmail", clientEmail));
		nvp.add(new BasicNameValuePair("module", ""+module));
		nvp.add(new BasicNameValuePair("eMap", examMapStr));

		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return url;
	}
	
	public static String postExamVersionURL(int moduleId, int moduleType) {
		String url = Link.URLRest + "examVersion";
		nvp = new ArrayList<NameValuePair>();
		nvp.add(new BasicNameValuePair("module", ""+moduleId));
		nvp.add(new BasicNameValuePair("type", ""+moduleType));
		//** user or patient id, if assess set to patient id
		if (User.isST && User.isAssess){
			nvp.add(new BasicNameValuePair("clientId", ""+Patient.id));
		} else {
			nvp.add(new BasicNameValuePair("clientId", ""+User.id));
		}		
		nvp.add(new BasicNameValuePair("device", "android("
				+ android.os.Build.MODEL + ")"));
		nvp.add(new BasicNameValuePair("os", android.os.Build.VERSION.RELEASE));
		nvp.add(new BasicNameValuePair("appVersion", ""+LaunchActivity.appVersion));
		return url;
	}
	// GET
	public static String getConsonJson (int moduleId, int typeId) {
		return Link.URLRest + "exams.json?module="+moduleId+"&type="+typeId;
	}
	
	public static String getQuestionJson (int moduleId, int typeId, int examId) {
		return Link.URLRest + "questions.json?module="+moduleId+"&type="+typeId+"&examId="+examId;
	}
	
	public static String getModule03Json (int moduleId, int typeId) {
		return Link.URLRest + "consonants.json?module="+moduleId+"&type="+typeId;
	}
	
	public static String getVersion () {
		return Link.URLRest + "versions.json";
	}
	
	public static String getAutoLoginURL(int userId) {
		String url = Link.URLRest + "accesstoken"+"/"+userId+"/isValid";
		return url;
	}
	
	public static String getPatientURL(String stEmail, String clientEmail) {
		String url = Link.URLRest + "sTClient.json"+"?stEmail="+stEmail+"&clientEmail="+clientEmail;
		return url;
	}
	
	public static String getPersonalScore(int clientId) {
		String url = Link.URLRest + "personalScore.json"+"?clientId="+clientId;
		return url;
	}
	
	public static String getRanking(int clientId) {
		String url = Link.URLRest + "ranking.json"+"?clientId="+clientId;
		return url;
	}
	
	public static String getASRVersion() {
		String url = Link.URLRest + "aSRVersion.json";
		return url;
	}
	
	//Delete
	public static String deleteLogoutURL(int userId) {
		String url = Link.URLRest + "accesstoken"+"/"+userId;
		return url;
	}
}
