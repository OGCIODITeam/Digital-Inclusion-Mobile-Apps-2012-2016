package database;

import manager.ExamManager;
import manager.ModuleConsonManager;
import manager.ReportManager;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

	private static final String db_name = "articulation.db";
	private static final int VERSION = 2; //** add or delete column must update Version

	private static SQLiteDatabase  sqlDB;
	
	public DatabaseHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
	}

	public static SQLiteDatabase getDB(Context context) {
		if (sqlDB ==null || !sqlDB.isOpen()) {
			sqlDB = new DatabaseHelper(context, db_name, null, VERSION).getWritableDatabase();
		}
		return sqlDB;
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(ModuleConsonManager.createStmt);
		db.execSQL(ExamManager.createStmt);
		db.execSQL(ReportManager.createStmt);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// ** if version updated must drop database and re-build
		db.execSQL(ModuleConsonManager.delStmt);
		db.execSQL(ExamManager.delStmt);
		db.execSQL(ReportManager.delStmt);
		
		onCreate(db);
	}

}
