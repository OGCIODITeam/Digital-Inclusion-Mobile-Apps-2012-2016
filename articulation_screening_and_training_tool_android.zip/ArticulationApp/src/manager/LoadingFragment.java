package manager;

import hk.org.deaf.asrtraining.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public class LoadingFragment extends DialogFragment {
	
//	public static LoadFragment newInstance() {
//		LoadFragment frag = new LoadFragment ();
//		return frag;
//	}
	
	
//	private Activity act;
//	private int theme;
//	
//	public LoadingFragment(Activity act){
//		this.act  = act;
//	}
//	
//	public LoadingFragment() {
//
//	}
// 
////    @Override
////    public Dialog onCreateDialog(Bundle savedInstanceState)
////    {
////        ProgressDialog dialog = new ProgressDialog(act);
////        dialog.setTitle("");
////        dialog.setMessage("");
////        dialog.setIndeterminate(true);
////        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
////        return dialog;
////    }
//
//	@Override
//	public View onCreateView(LayoutInflater inflater, ViewGroup container,
//			Bundle savedInstanceState) {
//		
//		View view = inflater.inflate(R.layout.dialog_loading, container);
//		
//		getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
//		getDialog().getWindow().setBackgroundDrawable(
//				new ColorDrawable(android.graphics.Color.TRANSPARENT));
//		getDialog().setCancelable(false);
//		
//		return view;
//	}
//    

    public static LoadingFragment newInstance(int title) {
    	LoadingFragment frag = new LoadingFragment();
        Bundle args = new Bundle();
        args.putInt("title", title);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        int title = getArguments().getInt("title");

        return new AlertDialog.Builder(getActivity())
//                .setIcon(R.drawable.alert_dialog_icon)
//                .setTitle(title)
//                .setPositiveButton(R.string.alert_dialog_ok,
//                    new DialogInterface.OnClickListener() {
//                        public void onClick(DialogInterface dialog, int whichButton) {
//                            ((FragmentAlertDialog)getActivity()).doPositiveClick();
//                        }
//                    }
//                )
//                .setNegativeButton(R.string.alert_dialog_cancel,
//                    new DialogInterface.OnClickListener() {
//                        public void onClick(DialogInterface dialog, int whichButton) {
//                            ((FragmentAlertDialog)getActivity()).doNegativeClick();
//                        }
//                    }
//                )
                .create();
    }

	public static LoadingFragment newInstance(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void show(FragmentManager fragmentManager, String string) {
		// TODO Auto-generated method stub
		
	}

}
