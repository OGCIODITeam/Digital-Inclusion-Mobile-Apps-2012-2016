package manager;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import bean.Current;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.util.Log;
import config.Conf;
import config.Link;

public class AppDownloadManger {


	public static void downloadImage (String fileName){
//		File direct = new File(Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.IMAGE_FOLDER);
		File direct = new File(Current.filePath + File.separator + Conf.IMAGE_FOLDER);
		if (!direct.exists()){
			direct.mkdirs();
		}
        try
        {
        	//Download
        	URL url = new URL(Link.URLImage+fileName);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            //Save
            FileOutputStream stream = new FileOutputStream(new File(direct+File.separator+fileName));
            ByteArrayOutputStream outstream = new ByteArrayOutputStream();
            myBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outstream);
            byte[] byteArray = outstream.toByteArray();

            stream.write(byteArray);
            stream.close();
            connection.disconnect();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}
	
	public static void downloadVoice (String fileName){
//		File direct = new File(Environment.getExternalStorageDirectory() + File.separator + Conf.materialFolder + File.separator + Conf.VOICE_FOLDER);
		File direct = new File(Current.filePath + File.separator + Conf.VOICE_FOLDER);
		if (!direct.exists()){
			direct.mkdirs();
		}
		int count;
        try
        {
            URL url = new URL(Link.URLVoice+fileName);
            URLConnection connection = url.openConnection();
            connection.connect();
            // this will be useful so that you can show a tipical 0-100% progress bar
//            int lenghtOfFile = connection.getContentLength();

            // downlod the file
            InputStream input = new BufferedInputStream(url.openStream());
            OutputStream output = new FileOutputStream(new File(direct+File.separator+fileName));

            byte data[] = new byte[1024];

//            long total = 0;

            while ((count = input.read(data)) != -1) {
//                total += count;
                // publishing the progress....
//                publishProgress((int)(total*100/lenghtOfFile));
                output.write(data, 0, count);
            }

            output.flush();
            output.close();
            input.close();
//            connection.disconnect();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}
}
