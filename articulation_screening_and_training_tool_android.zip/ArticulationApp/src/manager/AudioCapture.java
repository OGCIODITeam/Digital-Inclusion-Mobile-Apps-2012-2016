package manager;

import java.io.File;

import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.util.Log;
import bean.Current;
import bean.Patient;
import bean.User;
import config.Conf;
import config.I;

public class AudioCapture {
	private final static String tag = "AudioCapture";

	private static MediaRecorder mRecorder = null;
	private static MediaPlayer mPlayer = null;

	private static File file;

//	private static String mFileName = null;
	private static ExtAudioRecorder extAudioRecorder;
	
	public static void initAudioFolder() {
//		file = new File(Environment.getExternalStorageDirectory()
//				+ File.separator + Conf.materialFolder + File.separator
//				+ Conf.AUDIO_RECORDER_FOLDER);
		file = new File(Current.filePath + File.separator
				+ Conf.AUDIO_RECORDER_FOLDER);
		if (!file.exists()) {
			file.mkdirs();
			// refresh android file list MediaScannerConnection.scanFile(this,
			// new String[] { file.getAbsolutePath() }, null, null);
			Log.i(tag, "audio folder created at " + I.now());
		}
	}

	public static String getNewAudioFilePath(String fileName) {
		if (file == null)
			initAudioFolder();
		// e.g. b_baa_Age_VolunteerName_DeviceModel_Timestamp.wav
		String path = file.getAbsolutePath() + File.separator + fileName;
		return path;
	}

	public static String getNoiseFilePath() {
		if (file == null)
			initAudioFolder();
		// e.g. noise_user/patient id_DeviceModel_Timestamp.wav
		int id=0;
		if (User.isST && User.isAssess){
			id = Patient.id;
		} else {
			id = User.id;
		}
		String path = file.getAbsolutePath() + File.separator + "noise_"+id+"_"
				+ android.os.Build.MODEL + "_"
				+ I.now() + Conf.AUDIO_RECORDER_FILE_EXT;
		return path;
	}
	
	public static void startRecording(String path) {
		extAudioRecorder = ExtAudioRecorder.getInstanse(false);
		extAudioRecorder.setOutputFile(path);
		extAudioRecorder.prepare();
		extAudioRecorder.start();
	}
	
	public static void stopRecording() {
		// Stop recording
		extAudioRecorder.stop();
		extAudioRecorder.release();
	}
	
//	public static void startRecording(String path) {
//	mRecorder = new MediaRecorder();
//	mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
//	mRecorder.setAudioSamplingRate(Conf.RECORDER_SAMPLERATE);
//	mRecorder.setAudioChannels(Conf.RECORDER_CHANNELS);
//	mRecorder.setAudioEncodingBitRate(Conf.RECORDER_AUDIO_BitRate);
//	mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
//	mRecorder.setOutputFile(path);
//	// mRecorder.setOutputFile(mFileName);
//	mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
//	Log.i(tag, "filePath= " + path);
//	try {
//		mRecorder.prepare();
//	} catch (Exception e) {
//		Log.e(tag, "prepare() failed");
//		e.printStackTrace();
//	}
//	mRecorder.start();
//}
//
//public static void stopRecording() {
//	try {
//		mRecorder.stop();
//		mRecorder.release();
//		mRecorder = null;
////refresh android file list			MediaScannerConnection.scanFile(this, new String[] { mFileName }, null, null);
//	} catch (Exception e) {
//		e.printStackTrace();
//	}
//}
	
	public static void startPlaying(String path) {
		if (mPlayer!=null && mPlayer.isPlaying()) stopPlaying();
		mPlayer = new MediaPlayer();
		try {
			Log.i(tag, "play recorded audio file path: " + path);
			mPlayer.setDataSource(path);
			mPlayer.prepare();
			mPlayer.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void stopPlaying() {
		try {
			if (mPlayer !=null)  mPlayer.release();
		} catch (Exception e) {
			e.printStackTrace();
		}
		mPlayer = null;
	}
	
	public static void deleteAllAudio() {
		if (file!=null && file.exists() && file.isDirectory()) {
			String[] children = file.list();
	        for (int i = 0; i < children.length; i++) {
	            new File(file, children[i]).delete();
	        }
		} 
	}
	
	public static long getFileSize(String path) {
		if (path == null || path.trim().equals("")) return 0l;
	    File temp = new File(path);
	    return temp.length();
	}
}
