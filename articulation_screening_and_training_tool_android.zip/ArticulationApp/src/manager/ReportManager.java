package manager;

import java.util.TreeMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import bean.ReportExam;
import database.DatabaseHelper;

public class ReportManager {

	public static final String tag = "ReportManager";
	public static String tableName = "Report";

	private static SQLiteDatabase db;

	public ReportManager(Context context) {
		db = DatabaseHelper.getDB(context);
	}

	public void close() {

		if (db!=null && db.isOpen()) db.close();

	}

	public static final String createStmt = "CREATE TABLE Report ( "
			+ " moduleId INTEGER NOT NULL, "
			+ " examId INTEGER NOT NULL, "
			+ " isTested INTEGER DEFAULT 0, "
			+ " correct INTEGER DEFAULT 0, "
			+ " total INTEGER DEFAULT 0, "
			+ " timeUse INTEGER DEFAULT 0, "
			+ " sugPractice INTEGER DEFAULT 0, "
			+ " PRIMARY KEY (moduleId, examId) "
			+ " )";

	public static final String delStmt = "DROP TABLE IF EXISTS Report";

	public boolean addReportExam(ReportExam e) {
		ContentValues cv = new ContentValues();
		cv.put("moduleId", e.getModuleId());
		cv.put("examId", e.getExamId());
		cv.put("isTested", e.getIsTested());
		cv.put("correct", e.getCorrect());
		cv.put("total", e.getTotal());
		cv.put("timeUse", e.getTimeUse());
		cv.put("sugPractice", e.getSugPractice());
		return db.insert(tableName, null, cv) > 0;
	}

	public boolean updateReportExam(ReportExam e) {
		ContentValues cv = new ContentValues();
		cv.put("isTested", e.getIsTested());
		cv.put("correct", e.getCorrect());
		cv.put("total", e.getTotal());
		cv.put("timeUse", e.getTimeUse());
//		cv.put("sugPractice", e.getSugPractice()); //not update by this function
		String where = " examId = " + e.getExamId()+" AND moduleId= "+e.getModuleId();

		return db.update(tableName, cv, where, null) > 0;
	}
	
	public boolean updateSugPractice(int[] examList) {
		ContentValues cv = new ContentValues();
		cv.put("sugPractice", 1);
		
		String where ="";
		if (examList==null || examList.length<=0){
			return false;
		} else if (examList.length == 1) {
			where  = ""+examList[0];
		} else {
			for (int i=0; i<=examList.length; i++){
				if (i== (examList.length-1)){
					//the last
					where += examList[i];
				} else {
					where += examList[i] + ", ";
				}
			}
		}
		
		where = " examId IN (" + where +")";
		return db.update(tableName, cv, where, null) > 0;
	}

//	public boolean getExam(DbExam e) {
//		String sql = "SELECT * FROM Exam WHERE examId=" + e.getExamId();
//		Cursor c = db.rawQuery(sql, null);
//		if (c != null && c.moveToNext()) {
//			// c.moveToFirst();
//			e.setExamJson(c.getString(c.getColumnIndex("examJson")));
//			e.setVersion(c.getInt(c.getColumnIndex("version")));
//			return true;
//		} else {
//			return false;
//		}
//	}
	
	public void delAllReportExam() {
		db.delete(tableName, null, null);
	}
	
	public TreeMap<Integer, ReportExam> getReportByModule(int moduleId) {
		TreeMap<Integer, ReportExam> result = new TreeMap<Integer, ReportExam>();
		String sql = "SELECT * FROM "+tableName+" WHERE moduleId= "+moduleId;
		Cursor c = db.rawQuery(sql, null);
		if (c!=null){
			while (c.moveToNext()){
				ReportExam e  = new ReportExam();
				e.setModuleId(moduleId);
				e.setExamId(c.getInt(c.getColumnIndex("examId")));
				e.setIsTested(c.getInt(c.getColumnIndex("isTested")));
				e.setCorrect(c.getInt(c.getColumnIndex("correct")));
				e.setTotal(c.getInt(c.getColumnIndex("total")));
				e.setTimeUse(c.getLong(c.getColumnIndex("timeUse")));
				e.setSugPractice(c.getInt(c.getColumnIndex("sugPractice")));
				result.put(e.getExamId(), e);
			}
		}
		return result;
	}
	
	public boolean isExist(int examId, int moduleId) {
		String sql = "SELECT count(1) FROM "+tableName+" WHERE examId=" + examId + " AND moduleId= "+moduleId;
		Cursor c = db.rawQuery(sql, null);
		if (c != null && c.moveToNext() && c.getInt(0)>0) {
			Log.i(tag, "isExist, count= " + c.getInt(0));
			return true;
		} else {
			return false;
		}
	}
}
