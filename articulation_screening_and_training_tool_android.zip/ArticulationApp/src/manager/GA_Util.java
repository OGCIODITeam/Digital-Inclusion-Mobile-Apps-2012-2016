package manager;

import android.app.Application;

import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

public class GA_Util extends Application {
	private String tag = "GA_Util";
	
	public static void sendScreen(Tracker t, String screenName){
		t.setScreenName(screenName);
		t.send(new HitBuilders.AppViewBuilder().build());
	}
	
	public static void sendBtnEvent(Tracker t, String screenName, String action){
		t.setScreenName(screenName);
		t.send(new HitBuilders.EventBuilder()
		.setCategory("Button")
		.setAction(action)
		.build());
	}
}
