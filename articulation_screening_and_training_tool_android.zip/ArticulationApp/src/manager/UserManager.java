package manager;

import org.json.JSONObject;

import bean.User;

public class UserManager {
	public void setUserByJson(JSONObject json) throws Exception {
		if (json==null) return;
		User.id =json.getInt("id");
		User.token = json.getString("token");
		User.email = json.getString("email");
		User.name = json.getString("name");
//		User.role = json.getInt("role");
//		User.result = json.getString("result");
//		User.reason = json.getString("reason");
	}
}
