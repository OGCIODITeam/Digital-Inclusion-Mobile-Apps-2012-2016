package manager;

import database.DatabaseHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import bean.DbExam;

public class ExamManager {

	public static final String tag = "ExamManager";
	public static String tableName = "Exam";

	private static SQLiteDatabase db;

	public ExamManager(Context context) {
		db = DatabaseHelper.getDB(context);
	}

	public void close() {

		if (db!=null && db.isOpen()) db.close();

	}

	public static final String createStmt = "CREATE TABLE Exam ( "
			+ " examId INTEGER PRIMARY KEY, " + " examJson TEXT, "
			+ " version INTEGER " + " )";

	public static final String delStmt = "DROP TABLE IF EXISTS Exam";

	public boolean addExam(DbExam e) {
		ContentValues cv = new ContentValues();
		cv.put("examId", e.getExamId());
		cv.put("examJson", e.getExamJson());
		cv.put("version", e.getVersion());
		return db.insert(tableName, null, cv) > 0;
	}

	public boolean updateExam(DbExam e) {
		ContentValues cv = new ContentValues();
		cv.put("examJson", e.getExamJson());
		cv.put("version", e.getVersion());
		String where = " examId = " + e.getExamId();

		return db.update(tableName, cv, where, null) > 0;
	}

	public boolean getExam(DbExam e) {
		String sql = "SELECT * FROM Exam WHERE examId=" + e.getExamId();
		Cursor c = db.rawQuery(sql, null);
		if (c != null && c.moveToNext()) {
			// c.moveToFirst();
			e.setExamJson(c.getString(c.getColumnIndex("examJson")));
			e.setVersion(c.getInt(c.getColumnIndex("version")));
			return true;
		} else {
			return false;
		}
	}

	public boolean isExamExist(int examId) {
		String sql = "SELECT count(1) FROM Exam WHERE examId=" + examId;
		Cursor c = db.rawQuery(sql, null);
		if (c != null && c.moveToNext() && c.getInt(0)>0) {
			Log.i(tag, "isConsonExist, count= " + c.getInt(0));
			return true;
		} else {
			return false;
		}
	}
}
