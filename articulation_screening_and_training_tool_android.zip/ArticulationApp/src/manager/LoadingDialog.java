package manager;

import hk.org.deaf.asrtraining.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.Window;

public class LoadingDialog {
	public static Dialog daloading;

	public static void startDA(Context targetContext) {
		if (daloading != null)
			daloading.dismiss();
		daloading = new Dialog(targetContext);
		daloading.requestWindowFeature(Window.FEATURE_NO_TITLE);
		daloading.getWindow().setBackgroundDrawable(
				new ColorDrawable(android.graphics.Color.TRANSPARENT));
		daloading.setContentView(R.layout.dialog_loading);
		daloading.setCancelable(false);
		daloading.show();
	}

	public static void endDA() {
		if (daloading != null)
			daloading.dismiss();
		daloading = null;
	}

	// test01
	public static Dialog newLoading(Activity act){
		Dialog da = new Dialog(act);
		da.requestWindowFeature(Window.FEATURE_NO_TITLE);
		da.setContentView(R.layout.dialog_loading);
		da.getWindow().setBackgroundDrawable(
				new ColorDrawable(android.graphics.Color.TRANSPARENT));
		da.setCancelable(false);
		return da;
	}
	
	//test02
	private static Dialog da2;
	public static void executeLoading(Context context, boolean isShow){
		if (isShow) showDa2(context);
		else endDa2();	
	}
	
	private static void showDa2(Context context){
		AlertDialog.Builder builder = new Builder(context);
		builder.setTitle("show 02");
		builder.setMessage("show 02 msg");
//		builder.setPositiveButton(R.string.exit, new OnClickListener(){
//
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				dialog.dismiss();
//				System.exit(0);// kill app; * all activity must killed before this function
//			}});
//		builder.setNegativeButton(R.string.cancel, new OnClickListener(){
//
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				dialog.dismiss();
//			}});
		
//		builder.create().show();
		da2 = builder.create();
		da2.show();
		
	}
	
	private static void endDa2(){
		if  (da2 != null) da2.dismiss();
		da2 = null;
	}
	
	//test 04
	
	public static ProgressDialog pdLoading( Activity act){
		ProgressDialog pd;
		AlertDialog.Builder builder = new AlertDialog.Builder(act);
		builder.setView(act.getLayoutInflater().inflate(R.layout.dialog_loading, null));
		pd = (ProgressDialog) builder.create();
		pd.requestWindowFeature(Window.FEATURE_NO_TITLE);
		return pd;
	}
}
