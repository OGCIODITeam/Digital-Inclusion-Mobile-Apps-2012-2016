package manager;

import bean.Current;
import hk.org.deaf.asrtraining.R;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.media.AudioManager;
import android.util.Log;
import android.view.KeyEvent;

public class PageManager {
	private final static String tag = "PageManager";

	private static AudioManager audio;

	// TODO override device button
	public static boolean setDeviceButtonClickEvent(Context context, int keyCode) {
		audio = (AudioManager) context.getSystemService(context.AUDIO_SERVICE);
		switch (keyCode) {
		case KeyEvent.KEYCODE_VOLUME_UP:
			audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
					AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
			return true;
		case KeyEvent.KEYCODE_VOLUME_DOWN:
			audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
					AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
			return true;
		case KeyEvent.KEYCODE_BACK:
			if (Current.page.equals("ModuleFragment")){
				exitDialog(context);
			}
			return true;
//				return true;
//			} else {
//				return false;
//			}
		default:
			Log.i(tag, "............KeyCode= "+keyCode);
			return false;
		}
	}

	// TODO page control
	public static final int LaunchActivity = 1000;

	public static final int LoginActivity = 2000;
	public static final int LoginFragment = 2100;
	public static final int RegisterFragment = 2200;
	public static final int PatientFragment = 2300;

	public static final int ExamActivity = 3000;
	public static final int Exam1Fragment = 3100;
	public static final int Exam2Fragment = 3200;
	public static final int Exam3Fragment = 3300;

	public static final int ModuleFragment = 4000;
	public static final int ModuleTypeFragment = 4100;

	public static final int ReportFragment = 5000;

	private boolean backPageControl(int currentPage) {
		boolean result = false;
		 switch(currentPage){
		
		 	default:
		 		break;
		 }
		return result;
	}

	private static void exitDialog(Context context) {
		AlertDialog.Builder builder = new Builder(context);
		builder.setTitle(R.string.exit);
		builder.setMessage(R.string.exit_msg);
		builder.setPositiveButton(R.string.exit, new OnClickListener(){

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				System.exit(0);// kill app; * all activity must killed before this function
			}});
		builder.setNegativeButton(R.string.cancel, new OnClickListener(){

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}});
		builder.create().show();
	 }
}
