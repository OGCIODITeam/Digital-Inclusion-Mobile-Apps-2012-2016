package manager;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import bean.User;
import android.util.Log;

public class GetJSON {
	private static String tag = "GetJSON";
	private static int timeoutConnection = 15000;//5000;
	private static int timeoutSocket = 30000;
	
//	public static DefaultHttpClient httpClient;
	
//	public static JSONObject postJSONObject(String URLst, List<NameValuePair> param, boolean needHeader)
//			throws org.apache.http.conn.ConnectTimeoutException,
//			ClientProtocolException, IOException, JSONException {
	public static JSONObject postJSONObject(String URLst, List<NameValuePair> param, boolean needHeader)
			throws Exception {
		HttpPost post = new HttpPost(URLst);
		post.setEntity(new UrlEncodedFormEntity(param, HTTP.UTF_8));
		// 先封装一个 JSON 对象
		// 绑定到请求 Entry
		// 发送请求
		//Header value
		if (needHeader) {
			post.addHeader("id", ""+User.id); //must string string
			post.addHeader("token", User.token);
		}
		
		HttpParams httpParameters = new BasicHttpParams();
//		int timeoutConnection = 5000;
//		int timeoutSocket = 30000;
		HttpConnectionParams.setConnectionTimeout(httpParameters,
				timeoutConnection);
		HttpConnectionParams.setSoTimeout(httpParameters, timeoutSocket);
		DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);
		
		HttpResponse httpResponse = httpClient.execute(post);
		// 得到应答的字符串，这也是一个 JSON 格式保存的数据
		String retSrc = "";
		if (httpResponse.getStatusLine().getStatusCode() == 200) {
			retSrc = EntityUtils.toString(httpResponse.getEntity());
		}
		// 生成 JSON 对象
		JSONObject result = new JSONObject(retSrc);
		return result;
	}
	
//	public static JSONObject postAudioFile(String url, Map<String, String> params,
//			String filePath, String fileParam) throws IOException, JSONException {
	public static JSONObject postAudioFile(String url, Map<String, String> params,
			String filePath, String fileParam) throws Exception {		
		Log.i(tag, "url= "+url+" filePath= "+filePath);
		String BOUNDARY = java.util.UUID.randomUUID().toString();
		String PREFIX = "--", LINEND = "\r\n";
		String MULTIPART_FROM_DATA = "multipart/form-data";
		String CHARSET = "UTF-8";

		URL uri = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) uri.openConnection();
		conn.setReadTimeout(10 * 1000); // 缓存的最长时间
		conn.setDoInput(true);// 允许输入
		conn.setDoOutput(true);// 允许输出
		conn.setUseCaches(false); // 不允许使用缓存
		conn.setRequestMethod("POST");
		conn.setRequestProperty("connection", "keep-alive");
		conn.setRequestProperty("Charsert", "UTF-8");
		conn.setRequestProperty("Content-Type", MULTIPART_FROM_DATA
				+ ";boundary=" + BOUNDARY);
		conn.setConnectTimeout(timeoutConnection);
		
//		if (!Member.id.equals("") && !Member.token.equals("")) {
//			conn.setRequestProperty("bi", Member.id);
//			conn.setRequestProperty("bt", Member.token);
//		}

		// 首先组拼文本类型的参数
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, String> entry : params.entrySet()) {
			sb.append(PREFIX);
			sb.append(BOUNDARY);
			sb.append(LINEND);
			sb.append("Content-Disposition: form-data; name=\""
					+ entry.getKey() + "\"" + LINEND);
			sb.append("Content-Type: text/plain; charset=" + CHARSET + LINEND);
			sb.append("Content-Transfer-Encoding: 8bit" + LINEND);
			sb.append(LINEND);
			sb.append(entry.getValue());
			sb.append(LINEND);

		}

		DataOutputStream outStream = new DataOutputStream(
				conn.getOutputStream());
		outStream.write(sb.toString().getBytes());
		// 发送文件数据
		if (filePath != null && !filePath.trim().equals("")) {
			Log.i("postAudioFile", "filePath= "+filePath);
				File file = new File (filePath);
				
				if (file==null) Log.i(tag, "file null");
				else if (!file.exists()) Log.i(tag,"file not exists");
				else if (!file.canRead()) Log.i(tag,"file cannot read");
				
				StringBuilder sb1 = new StringBuilder();
				sb1.append(PREFIX);
				sb1.append(BOUNDARY);
				sb1.append(LINEND);
				sb1.append("Content-Disposition: form-data; name=\""+fileParam+"\"; filename=\""+file.getName()+"\""
						+ LINEND);
				sb1.append("Content-Type: application/octet-stream; charset="
						+ CHARSET + LINEND);
				sb1.append(LINEND);
				outStream.write(sb1.toString().getBytes());
				InputStream is = new FileInputStream(file);
				byte[] buffer = new byte[1024];
				int len = 0;
				while ((len = is.read(buffer)) != -1) {
					outStream.write(buffer, 0, len);
				}

				is.close();
				outStream.write(LINEND.getBytes());
			}

		// 请求结束标志
		byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINEND).getBytes();
		outStream.write(end_data);
		outStream.flush();
		// 得到响应码
		int res = conn.getResponseCode();
		InputStream in = conn.getInputStream();
		StringBuilder sb2 = new StringBuilder();
		if (res == 200) {
			int ch;
			while ((ch = in.read()) != -1) {
				sb2.append((char) ch);
			}
		}
		outStream.close();
		conn.disconnect();
		String temp = sb2.toString();
		JSONObject jo = new JSONObject(temp);
		return jo;
	}
	

	public static JSONObject doGet(String url, boolean needHeader) throws Exception{
		JSONObject json = null;
		HttpClient httpclient = new DefaultHttpClient();
		// Prepare a request object
		HttpGet httpget = new HttpGet(url);
		// Accept JSON
		// httpget.addHeader("accept", "application/json");
		if (needHeader) {
			httpget.addHeader("id", ""+User.id); //must string string
			httpget.addHeader("token", User.token);
		}
		// Execute the request
		HttpResponse response;
		try {
			response = httpclient.execute(httpget);
			// Get the response entity
			HttpEntity entity = response.getEntity();
			// If response entity is not null
			if (entity != null) {
				// get entity contents and convert it to string
				InputStream instream = entity.getContent();
				String result = convertStreamToString(instream);
				// Log.i("JSON result", result);
				// construct a JSON object with result
				//if(result!=null) {
					json = new JSONObject(result);
				//}
				// Closing the input stream will trigger connection release
				instream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		// Return the json
		return json;
	}
	
	public static JSONArray doGetJSONArray(String url)
			throws Exception {
		JSONArray jsonArray = null;
		HttpClient httpclient = new DefaultHttpClient();
		// Prepare a request object
		HttpGet httpget = new HttpGet(url);
		// Accept JSON
		// httpget.addHeader("accept", "application/json");
//		if (!Member.id.equals("") && !Member.token.equals("")) {
//			httpget.addHeader("bi", Member.id);
//			httpget.addHeader("bt", Member.token);
//		}

		// Execute the request
		HttpResponse response;
		try {
			response = httpclient.execute(httpget);
			// Get the response entity
			HttpEntity entity = response.getEntity();
			// If response entity is not null
			if (entity != null) {
				// get entity contents and convert it to string
				InputStream instream = entity.getContent();
				String result = convertStreamToString(instream);
				// Log.i("JSON result", result);
				// construct a JSON object with result
				jsonArray = new JSONArray(result);
				// Closing the input stream will trigger connection release
				instream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		// Return the json
		return jsonArray;
	}
	
	public static JSONObject doDelete(String url, boolean needHeader) throws Exception{
		JSONObject json = null;
		HttpClient httpclient = new DefaultHttpClient();
		// Prepare a request object
		HttpDelete delete = new HttpDelete(url);
		// Accept JSON
		// httpget.addHeader("accept", "application/json");
		
		if (needHeader) {
			delete.addHeader("id", ""+User.id);
			delete.addHeader("token", User.token);
		}

		// Execute the request
		HttpResponse response;
		try {
			response = httpclient.execute(delete);
			// Get the response entity
			HttpEntity entity = response.getEntity();
			// If response entity is not null
			if (entity != null) {
				// get entity contents and convert it to string
				InputStream instream = entity.getContent();
				String result = convertStreamToString(instream);
				// Log.i("JSON result", result);
				// construct a JSON object with result
				json = new JSONObject(result);
				// Closing the input stream will trigger connection release
				instream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		// Return the json
		return json;
	}
	
	public static String convertStreamToString(InputStream is) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line = null;

		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}

		is.close();

		return sb.toString();
	}
}
