package manager;

import database.DatabaseHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import bean.ModuleConson;

public class ModuleConsonManager {
	
	private static final String tag = "ModuleConsonManager";
	private static String tableName = "Consonant";
	
	private static SQLiteDatabase db;
	public 	ModuleConsonManager(Context context){
		db = DatabaseHelper.getDB(context);
	}
	
	public void close() {
		if (db!=null && db.isOpen()) db.close();
	}
	
	
	public static final String createStmt = "CREATE TABLE Consonant ( "
			+ " moduleId INTEGER NOT NULL, "
			+ " typeId INTEGER NOT NULL, "
			+ " consonJson TEXT, "
			+ " version INTEGER, "
			+ " PRIMARY KEY (moduleId, typeId) "
			+ " )";  

	public static final String delStmt = "DROP TABLE IF EXISTS Consonant";

	public boolean addModuleConson(ModuleConson mc){
		ContentValues cv = new ContentValues();
		cv.put("moduleId", mc.getModuleId());
		cv.put("typeId", mc.getTypeId());
		cv.put("consonJson", mc.getConsonJson());
		cv.put("version", mc.getVersion());
		return db.insert(tableName, null, cv) >0;
	}
	
	public boolean updateModuleConson(ModuleConson mc){
		ContentValues cv = new ContentValues();
//		cv.put("moduleId", mc.getmoduleId());
//		cv.put("typeId", mc.getTypeId());
		cv.put("consonJson", mc.getConsonJson());
		cv.put("version", mc.getVersion());
		String where = " moduleId = "+mc.getModuleId()+" AND typeId = "+mc.getTypeId();
		
		return db.update(tableName, cv, where, null) >0;
	}
	
	public boolean getModuleConson(ModuleConson mc) {
		String sql = "SELECT * FROM Consonant WHERE moduleId="+mc.getModuleId()+" AND typeId= "+mc.getTypeId();
		Cursor c = db.rawQuery(sql, null);
		if (c!=null && c.moveToNext()){
//			c.moveToFirst();
			mc.setConsonJson(c.getString(c.getColumnIndex("consonJson")));
			mc.setVersion(c.getInt(c.getColumnIndex("version")));
			return true;
		}else {
			return false;
		}
	} 
	
	public boolean isConsonExist(int moduleId, int typeId) {
		String sql = "SELECT count(1) FROM Consonant WHERE moduleId="+moduleId+" AND typeId= "+typeId;
		Cursor c = db.rawQuery(sql, null);
		if (c!=null && c.moveToNext() && c.getInt(0)>0){ //count = c.getInt(0) if count>0 conson exist
			Log.i(tag, "isConsonExist, count= "+c.getInt(0));
			return true;
		}else {
			return false;
		}
	} 
}
