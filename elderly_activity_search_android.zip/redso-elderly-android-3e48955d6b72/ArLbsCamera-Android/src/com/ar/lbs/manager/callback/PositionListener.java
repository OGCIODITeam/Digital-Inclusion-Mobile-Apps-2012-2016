package com.ar.lbs.manager.callback;

public interface PositionListener {
	public void onCompassChanged(float degree, double lat, double lon);
}
