package com.ar.lbs.manager;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.view.WindowManager;

import com.ar.lbs.manager.callback.PositionListener;

public class PositionManager implements SensorEventListener {
	// LocationManager.NETWORK_PROVIDER;
	// LocationManager.GPS_PROVIDER;
	// LocationManager.PASSIVE_PROVIDER;
	private Context mContext;
	private static PositionManager positionManager;
	private PositionListener listener;

	// Location
	private LocationManager locationManager;
	private boolean isTestingMode = false;
	private Location testingLocation;
	private Location gpsLocation;
	private Location networkLocation;
	private Location bestLocation = null;
	private LocationListener gpsListener;
	private LocationListener networkListener;
	private float displayRange = -Integer.MAX_VALUE;
	private float discoveryRange = -Integer.MAX_VALUE;
	boolean gpsEnabled = false;
	boolean networkEnabled = false;

	// Sensor
	private SensorManager mSensorManager;
	private Sensor accelerometerSensor;
	private Sensor magnetometerSensor;
	private final int TWO_MINUTES = 1000 * 60 * 2;
	private static int screenRotation;

	private static void logCat(String string) {
		Log.d("com.gt.halloween.ar", "Sensor >>> " + string);
	}

	public PositionManager(Context context)
	{
		this.mContext = context;
	}

	public static PositionManager getInstance(Context context) {
		if (positionManager == null)
		{
			positionManager = new PositionManager(context);
		}

		screenRotation = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
		return positionManager;
	}

	public void start() {
		setupLocationManager();
		setupSensor();
	}

	public void stop() {
		try
		{
			mSensorManager.unregisterListener(this);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		if (locationManager == null)
		{
			locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
		}

		if (gpsListener != null)
		{
			locationManager.removeUpdates(gpsListener);
		}
		if (networkListener != null)
		{
			locationManager.removeUpdates(networkListener);
		}

		positionManager = null;
	}

	public void setListener(PositionListener listener) {
		logCat("setListener >>> " + listener);
		this.listener = listener;
	}

	// ================================

	private final void initLocationListener() {
		gpsListener = new LocationListener()
		{
			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				if (status != LocationProvider.AVAILABLE)
				{
					logCat("gpsListener >>> onStatusChanged 1");
					gpsLocation = null;
				}
				else
				{
					logCat("gpsListener >>> onStatusChanged 2");
				}
			}

			@Override
			public void onProviderEnabled(String provider) {
				logCat("gpsListener >>> onProviderEnabled");
			}

			@Override
			public void onProviderDisabled(String provider) {
				logCat("gpsListener >>> onProviderDisabled");
				gpsLocation = null;
			}

			@Override
			public void onLocationChanged(Location location) {
				logCat("gpsListener >>> onLocationChanged " + location);
				gpsLocation = location;
			}
		};

		networkListener = new LocationListener()
		{
			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				if (status != LocationProvider.AVAILABLE)
				{
					logCat("networkListener >>> onStatusChanged 1");
					networkLocation = null;
				}
				else
				{
					logCat("networkListener >>> onStatusChanged 2");
				}
			}

			@Override
			public void onProviderEnabled(String provider) {
				logCat("networkListener >>> onProviderEnabled");
			}

			@Override
			public void onProviderDisabled(String provider) {
				logCat("networkListener >>> onProviderDisabled");
				networkLocation = null;
			}

			@Override
			public void onLocationChanged(Location location) {
				logCat("networkListener >>> onLocationChanged " + location);
				networkLocation = location;
			}
		};
	}

	private final void setupLocationManager() {
		logCat("setupLocationManager");

		initLocationListener();
		locationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);

		// exceptions will be thrown if provider is not permitted.
		try
		{
			gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		try
		{
			networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}

		//
		logCat("setupLocationManager gps: " + gpsEnabled + " , net: " + networkEnabled);
		if (gpsEnabled)
			locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, gpsListener);
		if (networkEnabled)
			locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, networkListener);
		logCat("setupLocationManager 1 gps: " + gpsLocation + " , net: " + networkLocation);

		//
		gpsLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		networkLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
		logCat("setupLocationManager 2 gps: " + gpsLocation + " , net: " + networkLocation);
	}

	private Location getCurrentLocation() {
		if (isTestingMode)
		{
			bestLocation = testingLocation;
		}
		else
		{
			if (isBetterLocation(gpsLocation, bestLocation))
			{
				bestLocation = gpsLocation;
			}
			if (isBetterLocation(networkLocation, bestLocation))
			{
				bestLocation = networkLocation;
			}
		}

		if (bestLocation == null)
		{
			bestLocation = new Location(LocationManager.NETWORK_PROVIDER);
		}
		// logCat("getCurrentLocation >>> " + location);
		return bestLocation;
	}

	protected boolean isBetterLocation(Location location,
			Location currentBestLocation) {
		if (location == null)
		{
			return false;
		}
		else if (currentBestLocation == null)
		{
			// A new location is always better than no location
			return true;
		}

		// Check whether the new location fix is newer or older
		long timeDelta = location.getTime() - currentBestLocation.getTime();
		boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
		boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
		boolean isNewer = timeDelta > 0;

		// If it's been more than two minutes since the current location, use
		// the new location
		// because the user has likely moved
		if (isSignificantlyNewer)
		{
			return true;
			// If the new location is more than two minutes older, it must be
			// worse
		}
		else if (isSignificantlyOlder)
		{
			return false;
		}

		// Check whether the new location fix is more or less accurate
		int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
		boolean isLessAccurate = accuracyDelta > 0;
		boolean isMoreAccurate = accuracyDelta < 0;
		boolean isSignificantlyLessAccurate = accuracyDelta > 200;

		// Check if the old and new location are from the same provider
		boolean isFromSameProvider = isSameProvider(location.getProvider(), currentBestLocation.getProvider());

		// Determine location quality using a combination of timeliness and
		// accuracy
		if (isMoreAccurate)
		{
			return true;
		}
		else if (isNewer && !isLessAccurate)
		{
			return true;
		}
		else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider)
		{
			return true;
		}
		return false;
	}

	/** Checks whether two providers are the same */
	private boolean isSameProvider(String provider1, String provider2) {
		if (provider1 == null)
		{
			return provider2 == null;
		}
		return provider1.equals(provider2);
	}

	public float getDisplayRange() {
		return displayRange;
	}

	public void setDisplayRange(float displayRange) {
		this.displayRange = displayRange;
	}

	public float getDiscoveryRange() {
		return discoveryRange;
	}

	public void setDiscoveryRange(float discoveryRange) {
		this.discoveryRange = discoveryRange;
	}

	public void setMockLocation(Location mockLocation) {
		isTestingMode = (mockLocation != null);
		this.testingLocation = mockLocation;
	}

	public double getLongitude() {
		if (getCurrentLocation() != null)
		{
			return getCurrentLocation().getLongitude();
		}
		return 0;
	}

	public double getLatitude() {
		if (getCurrentLocation() != null)
		{
			return getCurrentLocation().getLatitude();
		}
		return 0;
	}

	// ==================
	private final void setupSensor() {
		logCat("setupSensor");
		mSensorManager = (SensorManager) mContext.getSystemService(Context.SENSOR_SERVICE);
		accelerometerSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		magnetometerSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
		mSensorManager.registerListener(this, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
		mSensorManager.registerListener(this, magnetometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
	}

	public int getCurrentDegrees() {
		int result = 0;
		if (mOrientationValues != null)
		{
			result = Math.round(mOrientationValues[0]);
		}
		return result;
	}

	public static int covertAzimutDegreesInt(float value) {
		int result = Math.round(Math.round(Math.toDegrees(value)));
		result += 180;

		while (result < 0)
		{
			result += 360;
		}
		while (result > 360)
		{
			result -= 360;
		}
		return result;
	}

	// TODO ying: testing
	private final float alpha = 0.8f;
	private float[] gravity;
	private float[] geomagnetic;
	private float[] mOrientationValues;

	@Override
	public void onSensorChanged(SensorEvent event) {
		switch (event.sensor.getType())
		{
			case Sensor.TYPE_ACCELEROMETER:
				if (gravity == null)
				{
					gravity = event.values.clone();
				}
				gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
				gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
				gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];
				break;
			case Sensor.TYPE_MAGNETIC_FIELD:
				geomagnetic = event.values.clone();
				break;
		}

		if (gravity != null && geomagnetic != null)
		{
			float R[] = new float[9];
			float outR[] = new float[9];

			boolean b = SensorManager.getRotationMatrix(R, null, gravity, geomagnetic);
			if (b)
			{
				switch (screenRotation)
				{
					case Surface.ROTATION_0:
					case Surface.ROTATION_180:
						SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_Z, outR);
						break;
					case Surface.ROTATION_90:
					case Surface.ROTATION_270:
						SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_Z, SensorManager.AXIS_X, outR);
						break;
				}

				mOrientationValues = new float[3];
				SensorManager.getOrientation(outR, mOrientationValues);
				mOrientationValues[0] = covertAzimutDegreesInt(mOrientationValues[0]);
				mOrientationValues[1] = (int) Math.toDegrees(mOrientationValues[1]);
				mOrientationValues[2] = (int) Math.toDegrees(mOrientationValues[2]);
				// logCat("azimut: " + mOrientationValues[0] + ", pitch: " +
				// mOrientationValues[1] + ", roll: " + mOrientationValues[2]);

				if (listener != null)
				{
					listener.onCompassChanged(mOrientationValues[0], getCurrentLocation().getLatitude(), getCurrentLocation().getLongitude());
				}
			}
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
	}
}
