package com.ar.lbs.pojo;

public class PositionInfo {

	private double latitude;
	private double longitude;
	private double distanceToUser = 0;
	private double degreesToUser = 0;

	public float getDistanceToUserF() {
		return Math.round(distanceToUser);
	}

	public double getDistanceToUser() {
		return distanceToUser;
	}

	public void setDistanceToUser(double distanceToUser) {
		this.distanceToUser = distanceToUser;
	}

	public double getDegreesToUser() {
		return degreesToUser;
	}

	public void setDegreesToUser(double degreesToUser) {
		this.degreesToUser = degreesToUser;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		return "[distance=" + Math.round(distanceToUser) + ", degrees=" + Math.round(degreesToUser) + ", Lat=" + latitude + ", Lon=" + longitude + "]";
	}

}
