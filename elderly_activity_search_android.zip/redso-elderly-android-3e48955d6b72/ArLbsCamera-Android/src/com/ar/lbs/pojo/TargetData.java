package com.ar.lbs.pojo;

import com.ar.lbs.pojo.callback.TargetDataOnDrawListener;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

public class TargetData extends PositionInfo {

	private TargetDataOnDrawListener listener;

	private int index;
	private Bitmap bitmap;
	private Matrix matrix = new Matrix();
	private float movingOffset;

	public TargetData(int index)
	{
		this.index = index;
	}

	public void updateDraw(Canvas canvas, Paint paint) {
		if (listener != null)
		{
			listener.onDrawCallback(canvas, paint, index, getDistanceToUserF(), (float) canvas.getWidth(), (float) canvas.getHeight(), movingOffset);
		}
		else
		{
			// draw
			if (bitmap != null)
			{
				// mid x
				matrix.setTranslate(movingOffset - (bitmap.getWidth() / 2F), canvas.getHeight() / 2F);
				canvas.drawBitmap(bitmap, matrix, paint);
			}
			else
			{
				canvas.drawRect(movingOffset, 0, movingOffset + 30, 30, paint);
			}
		}
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}

	public float getMovingOffset() {
		return movingOffset;
	}

	public void setMovingOffset(float movingOffset) {
		this.movingOffset = movingOffset;
	}

	public void setListener(TargetDataOnDrawListener listener) {
		this.listener = listener;
	}

}
