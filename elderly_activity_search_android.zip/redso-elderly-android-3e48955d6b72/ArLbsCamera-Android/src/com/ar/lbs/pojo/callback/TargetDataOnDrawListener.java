package com.ar.lbs.pojo.callback;

import android.graphics.Canvas;
import android.graphics.Paint;

public interface TargetDataOnDrawListener {
	public void onDrawCallback(Canvas canvas, Paint paint, int index,
			float userDistance, float screenX, float screenY, float movement);
}
