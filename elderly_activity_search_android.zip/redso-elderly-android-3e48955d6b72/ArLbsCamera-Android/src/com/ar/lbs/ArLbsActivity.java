package com.ar.lbs;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.ar.lbs.manager.PositionManager;
import com.ar.lbs.pojo.TargetData;
import com.ar.lbs.ui.CampassDrawingView;

//com.ar.lbs.ArLbsActivity
public class ArLbsActivity extends Activity {

	protected CampassDrawingView campassDrawingView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

		//
		setContentView(R.layout.ar_lbs_view);
		campassDrawingView = (CampassDrawingView) super.findViewById(R.id.ar_lbs_display_view);
		campassDrawingView.setTestingMode(true);
		addDummyData();

		// TODO HK GT: 22.309908, 114.221581
		// PositionManager.getInstance(this).setMockLocation(getMockLocation());
		PositionManager.getInstance(this).setDisplayRange(10000);
	}

	private Location getMockLocation() {
		Location mockLocation = new Location(LocationManager.NETWORK_PROVIDER);
		mockLocation.setLatitude(22.309908);
		mockLocation.setLongitude(114.221581);
		return mockLocation;
	}

	private void addDummyData() {
		// me: 22.309908,114.221581

		// red 22.309719,114.221785
		TargetData data0 = new TargetData(0);
		data0.setLatitude(22.309719);
		data0.setLongitude(114.221785);
		data0.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.test_image1));
		campassDrawingView.getAllDataList().add(data0);

		// blue 22.309789,114.221235
		TargetData data1 = new TargetData(1);
		data1.setLatitude(22.309789);
		data1.setLongitude(114.221235);
		data1.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.test_image2));
		campassDrawingView.getAllDataList().add(data1);
	}

	@Override
	protected void onResume() {
		super.onResume();
		campassDrawingView.onResume();
	}

	@Override
	protected void onPause() {
		campassDrawingView.onPause();
		super.onPause();
	}
}