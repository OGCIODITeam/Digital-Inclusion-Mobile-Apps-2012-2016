package com.ar.lbs.ui;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ar.lbs.manager.PositionManager;
import com.ar.lbs.manager.callback.PositionListener;
import com.ar.lbs.pojo.PositionInfo;
import com.ar.lbs.pojo.TargetData;

//com.ar.lbs.ui.CampassDrawingView
public class CampassDrawingView extends RelativeLayout implements
		PositionListener {

	private boolean isTestingMode = false;
	private TextView degreeTextView;
	private final int screenViewPortDegrees = 60;
	private Paint paint = new Paint();

	// list
	private List<TargetData> allDataList = new ArrayList<TargetData>();
	private List<TargetData> displayDataList = new ArrayList<TargetData>();
	private List<TargetData> discoveryDataList = new ArrayList<TargetData>();

	public CampassDrawingView(Context context, AttributeSet attrs, int defStyle)
	{
		super(context, attrs, defStyle);
		init();
	}

	public CampassDrawingView(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		init();
	}

	public CampassDrawingView(Context context)
	{
		super(context);
		init();
	}

	private void init() {
		paint.setAntiAlias(true);
		paint.setColor(Color.BLACK);
		setKeepScreenOn(true);
		setWillNotDraw(false);

		PositionManager.getInstance(getContext()).setListener(this);

		degreeTextView = new TextView(getContext());
		degreeTextView.setTextColor(Color.RED);
		degreeTextView.setTextSize(16);
		addView(degreeTextView);
	}

	//
	public void onResume() {
		PositionManager.getInstance(getContext()).start();
	}

	public void onPause() {
		PositionManager.getInstance(getContext()).stop();
	}

	public List<TargetData> getAllDataList() {
		if (allDataList == null)
		{
			allDataList = new ArrayList<TargetData>();
		}
		return allDataList;
	}

	public boolean isTestingMode() {
		return isTestingMode;
	}

	public void setTestingMode(boolean isTestingMode) {
		this.isTestingMode = isTestingMode;
	}

	@Override
	public synchronized void onCompassChanged(float myDegrees,
			double myLatitude, double myLongitude) {

		if (isTestingMode)
		{
			degreeTextView.setText(" Degree: " + Math.round(myDegrees) + " Lat: " + (int) myLatitude + " Lon: " + (int) myLongitude);
		}

		if (allDataList != null && !allDataList.isEmpty())
		{
			displayDataList.clear();
			discoveryDataList.clear();

			// allDataList
			for (TargetData allData : allDataList)
			{
				calculateTargetPositionInfo(allData, myDegrees, myLatitude, myLongitude, true);

				Log.d("", "onCompassChanged >>> " + allData);
			}

			// sort
			sortTargetDatasToRangeList();

			Log.d("", "displayDataList " + displayDataList.size());

			// call draw
			invalidate();
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		// displayDataList
		if (displayDataList != null && !displayDataList.isEmpty())
		{
			for (TargetData displayData : displayDataList)
			{
				Log.d("", "onDraw >>> " + displayDataList.size() + " " + displayData.getDegreesToUser());

				displayData.setMovingOffset(calculateOffsetOnScreen(canvas.getWidth(), screenViewPortDegrees, displayData.getDegreesToUser()));

				// draw
				displayData.updateDraw(canvas, paint);
			}
		}
	}

	private void sortTargetDatasToRangeList() {
		if (allDataList != null && !allDataList.isEmpty())
		{
			displayDataList.clear();
			discoveryDataList.clear();

			for (TargetData data : allDataList)
			{
				if (data.getDistanceToUser() <= PositionManager.getInstance(getContext()).getDisplayRange()//
						&& (data.getDegreesToUser() <= screenViewPortDegrees / 2F || data.getDegreesToUser() >= 360 - screenViewPortDegrees / 2F))
				{
					displayDataList.add(data);
				}
				else if (data.getDistanceToUser() <= PositionManager.getInstance(getContext()).getDiscoveryRange())
				{
					discoveryDataList.add(data);
				}
			}
		}
	}

	private synchronized PositionInfo calculateTargetPositionInfo(
			PositionInfo dataPositionInfo, float degrees, double latitude,
			double longitude, boolean isCalculateOrientation) {

		// cal distance between target
		double earthRadius = 6371; // km
		double dLat = Math.toRadians(dataPositionInfo.getLatitude() - latitude);
		double dLon = Math.toRadians(dataPositionInfo.getLongitude() - longitude);
		double lat1 = Math.toRadians(latitude);
		double lat2 = Math.toRadians(dataPositionInfo.getLatitude());
		double a = Math.sin(dLat / 2F) * Math.sin(dLat / 2F) + Math.sin(dLon / 2F) * Math.sin(dLon / 2F) * Math.cos(lat1) * Math.cos(lat2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		double distance = earthRadius * c;

		// km to m
		distance = distance * 1000;
		dataPositionInfo.setDistanceToUser(distance);

		// cal degree between target
		if (isCalculateOrientation)
		{
			double y = Math.sin(dLon) * Math.cos(lat2);
			double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
			double bearing = Math.toDegrees(Math.atan2(y, x));
			double dgreesToUser = degrees - bearing;

			while (dgreesToUser < 0)
			{
				dgreesToUser += 360;
			}
			while (dgreesToUser > 360)
			{
				dgreesToUser -= 360;
			}

			dataPositionInfo.setDegreesToUser(dgreesToUser);
		}

		return dataPositionInfo;
	}

	private synchronized int calculateOffsetOnScreen(double screenSize,
			double screenViewPortDegrees, double degreesToUser) {

		// cal degree
		double targetDegrees = degreesToUser + screenViewPortDegrees / 2F;
		while (targetDegrees < 0)
		{
			targetDegrees += 360;
		}
		while (targetDegrees > 360)
		{
			targetDegrees -= 360;
		}
		targetDegrees = screenViewPortDegrees - targetDegrees;

		// add out size screen padding for draw flag
		double screenOutPad = screenSize * 0.3F;
		double tempScreenSize = screenSize + screenOutPad;

		// movingOffset of screen
		double movingOffset = 0;
		movingOffset = tempScreenSize / screenViewPortDegrees * targetDegrees;
		movingOffset -= (screenOutPad / 2F);

		Log.d("", "calculateOffset >>> " + movingOffset + " targetDegrees " + (int) targetDegrees);
		return Math.round(Math.round(movingOffset));
	}
}
