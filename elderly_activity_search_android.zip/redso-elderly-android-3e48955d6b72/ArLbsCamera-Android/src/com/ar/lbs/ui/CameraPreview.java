package com.ar.lbs.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.Size;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;

// com.ar.lbs.ui.CameraPreview
public class CameraPreview extends RelativeLayout implements
		SurfaceHolder.Callback {

	private SurfaceHolder.Callback callback;

	private SurfaceView mSurfaceView;
	private SurfaceHolder mHolder;
	private Display display;
	private Camera mCamera;

	private int deviceOrientation;
	private int rotation = 0;
	private Size bestPreviewSize;
	private Size bestPictureSize;

	private boolean isSurfaceCreated = false;
	private boolean isAllowPreview = true;
	private boolean isFrontCamera = false;

	private void logCat(String string) {
		Log.d("CameraPreview", "CameraPreview >>> " + string);
	}

	public CameraPreview(Context context, AttributeSet attrs, int defStyle)
	{
		super(context, attrs, defStyle);
		init();
	}

	public CameraPreview(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		init();
	}

	public CameraPreview(Context context)
	{
		super(context);
		init();
	}

	private void init() {
		// Display
		display = ((WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();

		// rotation
		// Orientation
		// normal landscape: 0
		// normal portrait: 90
		// upside-down landscape: 180
		// upside-down portrait: 270
		rotation = 0;
		deviceOrientation = getDeviceDefaultOrientation(getContext());
		switch (display.getRotation())
		{
			case Surface.ROTATION_0:
			case Surface.ROTATION_180:
				rotation = (deviceOrientation == Configuration.ORIENTATION_PORTRAIT) ? 90 : 0;
				break;
			case Surface.ROTATION_90:
			case Surface.ROTATION_270:
				rotation = (deviceOrientation == Configuration.ORIENTATION_LANDSCAPE) ? 90 : 0;
				break;
			default:
				rotation = 0;
				break;
		}

		// logCat("initPreview >>> getDeviceName: " + getDeviceName());
		logCat("initPreview >>> calRotation " + rotation + ", Orientation " + deviceOrientation + ", Rotation " + display.getRotation());

		// mSurfaceView
		mSurfaceView = new SurfaceView(getContext());
		RelativeLayout.LayoutParams surfaceParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		surfaceParams.addRule(RelativeLayout.CENTER_IN_PARENT);
		addView(mSurfaceView, surfaceParams);

		// mHolder
		mHolder = mSurfaceView.getHolder();
		mHolder.addCallback(this);
		// mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

		// mCamera
		initCamera();
	}

	/**
	 * @Override
	 */

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		logCat("surface >>> surfaceCreated");
		initCamera();

		if (callback != null)
		{
			callback.surfaceCreated(holder);
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		logCat("surface >>> surfaceDestroyed");
		isSurfaceCreated = false;
		if (mCamera != null)
		{
			mCamera.setPreviewCallback(null);
			mCamera.stopPreview();
			mCamera.release();
			mCamera = null;
		}

		if (callback != null)
		{
			callback.surfaceDestroyed(holder);
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		logCat("surface >>> surfaceChanged");
		isSurfaceCreated = true;
		if (mCamera != null)
		{
			cameraSetPreviewDisplayHolder(holder);

			mCamera.stopPreview();
			mCamera.setDisplayOrientation(rotation);
			setRotation(rotation);
			setPreviewSize(bestPreviewSize);
			setPictureSize(bestPictureSize);
			setPictureFormat();
			mCamera.startPreview();
		}

		if (callback != null)
		{
			callback.surfaceChanged(holder, format, width, height);
		}
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// We purposely disregard child measurements because act as a
		// wrapper to a SurfaceView that centers the camera preview instead
		// of stretching it.
		final int width = resolveSize(getSuggestedMinimumWidth(), widthMeasureSpec);
		final int height = resolveSize(getSuggestedMinimumHeight(), heightMeasureSpec);
		setMeasuredDimension(width, height);
		logCat("onMeasure " + width + " " + height);
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		logCat("onLayout " + changed + " " + l + " " + t + " " + r + " " + b);
		logCat("onLayout getChildCount " + getChildCount());

		if (changed && getChildCount() > 0)
		{
			final View child = getChildAt(0);

			logCat("onLayout child " + child);

			final int width = r - l;
			final int height = b - t;

			int previewWidth = width;
			int previewHeight = height;
			if (bestPreviewSize != null)
			{
				// width <- height , height <- width : because camera
				// orientation 90 angle
				previewWidth = bestPreviewSize.height;
				previewHeight = bestPreviewSize.width;
			}

			logCat("onLayout size >>> " + width + "X" + height);
			logCat("onLayout preview size >>> " + previewWidth + "X" + previewHeight);

			// Center the child SurfaceView within the parent.
			if (width * previewHeight < height * previewWidth)
			{
				final int scaledChildWidth = previewWidth * height / previewHeight;
				child.layout(Math.round((width - scaledChildWidth) / 2F), 0, Math.round((width + scaledChildWidth) / 2F), height);
			}
			else
			{
				final int scaledChildHeight = previewHeight * width / previewWidth;
				child.layout(0, Math.round((height - scaledChildHeight) / 2F), width, Math.round((height + scaledChildHeight) / 2F));
			}
		}
	}

	/**
	 * private
	 */

	private void initCamera() {
		if (mCamera != null)
		{
			surfaceDestroyed(mHolder);
		}

		int cameraId = 0;
		int numCamera = Camera.getNumberOfCameras();
		CameraInfo info = new CameraInfo();
		for (int i = 0; i < numCamera; i++)
		{
			Camera.getCameraInfo(i, info);
			if (info.facing == CameraInfo.CAMERA_FACING_BACK)
			{
				cameraId = i;
			}
		}
		// ying: check using camera
		Camera.getCameraInfo(cameraId, info);
		isFrontCamera = (info.facing == CameraInfo.CAMERA_FACING_FRONT);

		mCamera = Camera.open(cameraId);
		Camera.Parameters parameters = mCamera.getParameters();
		bestPreviewSize = getBestPreviewSize(parameters);
		bestPictureSize = getBestPictureSize(bestPreviewSize, parameters);

		logCat("Camera: " + parameters.flatten());
		requestLayout();
	}

	private Size getBestPictureSize(Size bestPreviewSize, Parameters parameters) {
		Size result = null;

		float bestPreviewSizeRatio = bestPreviewSize.width / bestPreviewSize.height;
		List<Size> cacheSizeList = new ArrayList<Camera.Size>();
		for (Size size : parameters.getSupportedPictureSizes())
		{
			if ((float) size.width / (float) size.height == bestPreviewSizeRatio)
			{
				cacheSizeList.add(size);
			}
		}

		if (cacheSizeList.isEmpty())
		{
			cacheSizeList.addAll(parameters.getSupportedPictureSizes());
		}

		// get biggest one
		float oldRatio = 0;
		float newRatio = 0;
		for (Size size : cacheSizeList)
		{
			if (result == null)
			{
				result = size;
			}
			else
			{
				oldRatio = result.width * result.height;
				newRatio = size.width * size.height;
				if (newRatio > oldRatio)
				{
					result = size;
				}
			}
		}

		return result;
	}

	private Size getBestPreviewSize(Parameters parameters) {
		Size result = null;
		int oldRatio = 0;
		int newRatio = 0;
		for (Size size : parameters.getSupportedPreviewSizes())
		{
			if (result == null)
			{
				result = size;
			}
			else
			{
				oldRatio = result.width * result.height;
				newRatio = size.width * size.height;
				if (newRatio > oldRatio)
				{
					result = size;
				}
			}
		}
		return result;
	}

	private void cameraSetPreviewDisplayHolder(SurfaceHolder holder) {
		logCat("surface >>> cameraSetPreviewDisplayHolder");
		if (mCamera != null && holder != null)
		{
			try
			{
				mCamera.setPreviewDisplay(holder);
			}
			catch (IOException exception)
			{
				logCat("surface >>> cameraSetPreviewDisplayHolder error: " + exception.toString());
			}
		}
	}

	private void setPictureFormat() {
		logCat("surface >>> cameraSetPreviewSize");
		if (mCamera != null)
		{
			try
			{
				Parameters parameters = mCamera.getParameters();
				parameters.setPictureFormat(ImageFormat.JPEG);
				parameters.set("jpeg-quality", 100);
				mCamera.setParameters(parameters);
			}
			catch (Exception e)
			{
				logCat("surface >>> cameraSetPreviewSize error: " + e.toString());
			}
		}
	}

	private void setPictureSize(Size size) {
		logCat("surface >>> cameraSetPreviewSize");
		if (mCamera != null && size != null)
		{
			try
			{
				Parameters parameters = mCamera.getParameters();
				parameters.setPictureSize(size.width, size.height);
				mCamera.setParameters(parameters);
			}
			catch (Exception e)
			{
				logCat("surface >>> cameraSetPreviewSize error: " + e.toString());
			}
		}
	}

	private void setPreviewSize(Size size) {
		logCat("surface >>> cameraSetPreviewSize");
		if (mCamera != null && size != null)
		{
			try
			{
				Parameters parameters = mCamera.getParameters();
				parameters.setPreviewSize(size.width, size.height);
				mCamera.setParameters(parameters);
			}
			catch (Exception e)
			{
				logCat("surface >>> cameraSetPreviewSize error: " + e.toString());
			}
		}
	}

	private void setRotation(int degrees) {
		logCat("surface >>> cameraSetRotation");
		if (mCamera != null)
		{
			try
			{
				Parameters parameters = mCamera.getParameters();
				parameters.setRotation(degrees);
				mCamera.setParameters(parameters);
			}
			catch (Exception e)
			{
				logCat("surface >>> cameraSetRotation error: " + e.toString());
			}
		}
	}

	// private Size getOptimalPreviewSize(List<Size> sizes, float w, float h) {
	// final double ASPECT_TOLERANCE = 0.05;
	// double targetRatio = (double) w / h;
	// if (sizes == null)
	// return null;
	//
	// Size optimalSize = null;
	// double minDiff = Double.MAX_VALUE;
	//
	// float targetHeight = h;
	//
	// // Try to find an size match aspect ratio and size
	// for (Size size : sizes)
	// {
	// double ratio = (double) size.width / size.height;
	// if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE)
	// continue;
	// if (Math.abs(size.height - targetHeight) < minDiff)
	// {
	// optimalSize = size;
	// minDiff = Math.abs(size.height - targetHeight);
	// }
	// }
	//
	// // Cannot find the one match the aspect ratio, ignore the requirement
	// if (optimalSize == null)
	// {
	// minDiff = Double.MAX_VALUE;
	// for (Size size : sizes)
	// {
	// if (Math.abs(size.height - targetHeight) < minDiff)
	// {
	// optimalSize = size;
	// minDiff = Math.abs(size.height - targetHeight);
	// }
	// }
	// }
	// return optimalSize;
	// }

	/**
	 * public
	 */

	public void setSurfaceHolderCallback(SurfaceHolder.Callback callback) {
		this.callback = callback;
	}

	public void onResume(PreviewCallback previewCallback) {
		if (mCamera != null && isSurfaceCreated && isAllowPreview)
		{
			mCamera.startPreview();
			mCamera.setPreviewCallback(previewCallback);
		}
	}

	public void onPause() {
		if (mCamera != null)
		{
			mCamera.setPreviewCallback(null);
			mCamera.stopPreview();
		}
	}

	public void switchFlashOn() {
		if (null == mCamera)
			return;
		mCamera.stopPreview();
		try
		{
			Parameters p = mCamera.getParameters();
			p.setFlashMode(Parameters.FLASH_MODE_TORCH);
			mCamera.setParameters(p);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logCat("switchFlashOn >>> error: " + e.toString());
		}
		mCamera.startPreview();
	}

	public void switchFlashOff() {
		if (null == mCamera)
			return;
		mCamera.stopPreview();
		try
		{
			Parameters p = mCamera.getParameters();
			p.setFlashMode(Parameters.FLASH_MODE_OFF);
			mCamera.setParameters(p);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logCat("switchFlashOff >>> error: " + e.toString());
		}
		mCamera.startPreview();
	}

	public Size getBestPreviewSize() {
		return bestPreviewSize;
	}

	public Size getBestPictureSize() {
		return bestPictureSize;
	}

	public Camera getCamera() {
		return mCamera;
	}

	public void stopPreview() {
		isAllowPreview = false;
		if (mCamera != null)
		{
			mCamera.setPreviewCallback(null);
			mCamera.stopPreview();
		}
	}

	public void startPreview(PreviewCallback previewCallback) {
		isAllowPreview = true;
		if (mCamera != null)
		{
			mCamera.startPreview();
			mCamera.setPreviewCallback(previewCallback);
		}
	}

	public boolean isFrontCamera() {
		return isFrontCamera;
	}

	public int getDeviceDefaultOrientation(Context context) {
		WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		Configuration config = context.getResources().getConfiguration();
		int rotation = windowManager.getDefaultDisplay().getRotation();

		if (((rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) && config.orientation == Configuration.ORIENTATION_LANDSCAPE)//
				|| ((rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) && config.orientation == Configuration.ORIENTATION_PORTRAIT))
		{
			return Configuration.ORIENTATION_LANDSCAPE;
		}
		else
		{
			return Configuration.ORIENTATION_PORTRAIT;
		}
	}
}
