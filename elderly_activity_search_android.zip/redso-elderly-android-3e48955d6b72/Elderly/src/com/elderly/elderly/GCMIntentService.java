package com.elderly.elderly;

import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.activity.SplashActivity;
import com.gt.gcm.GCMManager;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class GCMIntentService extends com.gt.gcm.GCMIntentService {

	private static final String TAG = "GCMIntentService";

	public static final String NOTIFICATION_NEWSPOJO = "NOTIFICATION_NEWSPOJO";

	// key >> message value >> android test title -02
	// key >> collapse_key value >> 1
	// key >> from value >> 532137519697
	// key >> tid value >> 4
	// key >> nid value >> 1008740
	private static final String MES_TEXT_KEY = "Push Test";

	private ElderlyApplication application;
	private boolean isAppRunning;// App 是否正在运行。

	@Override
	public void onCreate() {
		Log.i(TAG, "onCreate>>>>>>>>>>>");
		super.onCreate();
		application = (ElderlyApplication) getApplication();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	@Override
	protected void onRegistered(Context context, String registrationId) {
		Log.i(TAG, "onRegistered>>>registrationId=" + registrationId);
		application.setRegisterToken(registrationId);
		// 发出 广播 告知 Server 注册 Token。
		// Intent in = new Intent(Constants.ALREADY_REGISTERED_TOKEN_BOADCAST);
		// context.sendBroadcast(in);
	}

	@Override
	protected void onMessage(Context context, Intent intent) {
		for (String key : intent.getExtras().keySet()) {
			Log.i(TAG, "onMessage>>>  key  >> " + key + "  value >>  " + intent.getExtras().get(key));
		}

		String message = intent.getStringExtra(MES_TEXT_KEY);
		Log.e(TAG, "message >>" + message);
		if (message == null) {
			Log.e(TAG, "message is null.");
		} else {
			
			
//			GCMManager.showNotification(context,application.isLeaveSplashActivity()?MainActivity.class:SplashActivity.class , R.string.common_dialog_title, R.drawable.icon_app, message);
			
			long when = System.currentTimeMillis();
	        NotificationManager notificationManager = (NotificationManager)
	                context.getSystemService(Context.NOTIFICATION_SERVICE);
	        Notification notification = new Notification(R.drawable.icon_app, message, when);
	        String title = context.getString(R.string.application_name);
	        Intent notificationIntent = new Intent(context, application.isLeaveSplashActivity()?MainActivity.class:SplashActivity.class);
	        // set intent so it does not start a new activity
	        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
	                Intent.FLAG_ACTIVITY_SINGLE_TOP);
	        PendingIntent intent1 = PendingIntent.getActivity(context, 0, notificationIntent, 0);
	        notification.setLatestEventInfo(context, title, message, intent1);
	        notification.flags |= Notification.FLAG_AUTO_CANCEL;
	        notificationManager.notify(0, notification);
		}

	}

}
