package com.elderly.elderly.component;

import com.elderly.elderly.R;
import com.elderly.elderly.adapter.BannerPagerAdapter;
import com.elderly.elderly.adapter.NewsActivityAdapter;
import com.elderly.elderly.component.ElderlyViewPager.ElderlyViewPagerLintener;
import com.gt.cl.component.imageview.bitmapview.CLBitmapView;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

public class ElderlyListBanner extends LinearLayout {
	private View mImgVPhotoArrowLeft;
	private View mImgVPhotoArrowRight;
	private BannerPagerAdapter mBannerAdapter;
	private ElderlyViewPager mViewPager;
	private ElderlyCirclePageIndicator mViewPagerIndicator;

	public ElderlyListBanner(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupView();
	}

	public ElderlyListBanner(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater.from(getContext()).inflate(R.layout.view_list_banner, this, true);
		setOrientation(VERTICAL);
		mImgVPhotoArrowLeft = findViewById(R.id.page_news_activity_mImgVPhotoArrowLeft);
		mImgVPhotoArrowRight = findViewById(R.id.page_news_activity_mImgVPhotoArrowRight);
		mViewPager = (ElderlyViewPager) findViewById(R.id.page_news_activity_mViewPager);
		mViewPagerIndicator = (ElderlyCirclePageIndicator) findViewById(R.id.page_news_activity_mViewPagerIndicator);
		mViewPagerIndicator.setSnap(true);
		mViewPager.setLooper(false);
		
		mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
		mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
		setupListener();
	}

	private void setupListener() {
		mViewPager.setViewPagerLintener(new ElderlyViewPagerLintener() {

			@Override
			public void onPageSelected(int position) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPageScrolled(final int position, final float positionOffset, int positionOffsetPixels) {
				showArrow(position);
				mViewPager.postDelayed(new Runnable() {

					@Override
					public void run() {
						if (mViewPager.isLooper()) {
							if (positionOffset == 0) {
								if (position == 0) {
									mViewPager.setCurrentItem(mViewPager.getAdapter().getCount() - 2, false);
								} else if (position == mViewPager.getAdapter().getCount() - 1) {
									mViewPager.setCurrentItem(1, false);
								}
							}
						}

					}
				}, 10);

			}

			@Override
			public void onPageScrollStateChanged(int state) {

			}

			@Override
			public void onRestoreInstanceState(Parcelable state) {
				showArrow(mViewPager.getCurrentItem());

			}
		});

	}

	public ElderlyViewPager getViewPager() {
		return mViewPager;
	}

	public ElderlyCirclePageIndicator getmViewPagerIndicator() {
		return mViewPagerIndicator;
	}

	public void setBannerAdapter(BannerPagerAdapter mBannerAdapter) {
		this.mBannerAdapter = mBannerAdapter;
		mViewPager.setAdapter(mBannerAdapter);
		mViewPagerIndicator.setSnap(true);
		mViewPagerIndicator.setViewPager(mViewPager);
		mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
		mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
	}

	public void showArrow(int position) {
		if (mViewPager == null || mViewPager.getAdapter() == null) {
			return;
		}
		if (mViewPager.getAdapter().getCount() < 2) {
			mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
			mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
		} else {
			if (position == 0) {
				mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
				mImgVPhotoArrowRight.setVisibility(View.VISIBLE);
			} else if (position == (mViewPager.getAdapter().getCount() - 1)) {
				mImgVPhotoArrowLeft.setVisibility(View.VISIBLE);
				mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
			} else {
				mImgVPhotoArrowLeft.setVisibility(View.VISIBLE);
				mImgVPhotoArrowRight.setVisibility(View.VISIBLE);
			}
		}

	}

	public void destory() {
		if (mViewPagerIndicator != null) {
			mViewPagerIndicator.setViewPager(null);
		}
		if (mViewPager != null) {
			mViewPager.release();
			int size = mViewPager.getChildCount();
			for (int i = 0; i < size; i++) {
				View view = mViewPager.getChildAt(i);
				if (view instanceof CLBitmapView) {
					((CLBitmapView) view).unRegisterBitmapInfoListener();
				}
			}
			mViewPager.setAdapter(null);
		}
	}

}
