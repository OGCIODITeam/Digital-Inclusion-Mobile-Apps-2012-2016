package com.elderly.elderly.component;

import com.elderly.elderly.R;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ElderlyCommonActivityCell extends LinearLayout {
	private TextView mTxtTitle;
	private TextView mTxtActivityType;
	private TextView mTxtDate;
	private TextView mTxtTime;
	private TextView mTxtCost;
	private ImageView mBtnMore;

	public ElderlyCommonActivityCell(Context context) {
		super(context);
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_common_activity_cell, this, true);
		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER_VERTICAL);
		mTxtTitle = (TextView) findViewById(R.id.view_last_activity_cell_mTxtTitle);
		mTxtDate = (TextView) findViewById(R.id.view_last_activity_cell_mTxtDate);
		mTxtActivityType = (TextView) findViewById(R.id.view_last_activity_cell_mTxtActivityType);
		mTxtTime = (TextView) findViewById(R.id.view_last_activity_cell_mTxtTime);
		mTxtCost = (TextView) findViewById(R.id.view_last_activity_cell_mTxtCost);
		mBtnMore = (ImageView) findViewById(R.id.view_last_activity_cell_btn_more);
	}

	public TextView getmTxtTitle() {
		return mTxtTitle;
	}

	public TextView getmTxtActivityType() {
		return mTxtActivityType;
	}

	public TextView getmTxtDate() {
		return mTxtDate;
	}

	public TextView getmTxtTime() {
		return mTxtTime;
	}

	public TextView getmTxtCost() {
		return mTxtCost;
	}

	public void setBtnMoreContentDescription(String content){
		mBtnMore.setContentDescription(content);
	}
}
