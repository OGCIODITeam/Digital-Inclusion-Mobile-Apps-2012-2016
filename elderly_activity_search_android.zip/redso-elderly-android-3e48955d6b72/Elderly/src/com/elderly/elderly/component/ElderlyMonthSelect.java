package com.elderly.elderly.component;

import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.gt.cl.util.CLDateUtil;

public class ElderlyMonthSelect extends LinearLayout {
	private static final String TAG = "ElderlyMonthSelect";

	private long mShowCalendarTime = System.currentTimeMillis();
	private int mDayItemHeight;
	private TextView mHeaderTitle;
	private View mLayerPreviousMonth;
	private View mLayerNextMonth;
	private LinearLayout mLayerMonths;
	private Calendar mToDayCalendar;
	private Calendar mCurrentPageCalendar;
	private Calendar mSelectedCalendar;

	private int mCurrentPageYear;
	private int mCurrentPageMonth;
	private int mCalendarDivider;

	private OnCalendarClickListener mOnCalendarClickListener;

	public ElderlyMonthSelect(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupView();
	}

	public ElderlyMonthSelect(Context context) {
		super(context);
		setupView();
	}

	private void init() {
		setClickable(true);
		mCalendarDivider = Math.round(getResources().getDimension(R.dimen.view_calendar_divider));
		Log.v(TAG, "mCalendarDivider>>" + mCalendarDivider);
	}

	private void setupView() {
		init();
		mDayItemHeight = Math.round(getResources().getDimension(R.dimen.view_calendar_item_height));
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_month_select, this);
		mLayerMonths = (LinearLayout) findViewById(R.id.view_month_select_mLayerMonths);
		mLayerPreviousMonth = findViewById(R.id.view_month_select_mLayerPreviousYear);
		mLayerNextMonth = findViewById(R.id.view_month_select_mLayerNextYear);
		mHeaderTitle = (TextView) findViewById(R.id.view_month_select_mTxtHeaderTitle);
		initData();
		setupListener();
		// mLayerDays.setBackgroundColor(0xffb3b3b3);
		// mLayerWeek.setBackgroundColor(0xff5e5e5e);
		mHeaderTitle.setTextColor(Color.WHITE);
		mHeaderTitle.setBackgroundColor(0xff5e5e5e);
	}

	private void setupListener() {
		mLayerPreviousMonth.setOnClickListener(mMonthSelectListener);
		mLayerNextMonth.setOnClickListener(mMonthSelectListener);
	}

	private View.OnClickListener mMonthSelectListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			int tmpYear = mCurrentPageYear;
			int currentYear = mToDayCalendar.get(Calendar.YEAR);
			if (v.getId() == mLayerPreviousMonth.getId()) {
				if (currentYear - 50 > tmpYear) {
					tmpYear = currentYear + 50;
				} else {
					tmpYear -= 1;
				}
			} else {
				if (currentYear + 50 < tmpYear) {
					tmpYear = currentYear - 50;
				} else {
					tmpYear += 1;
				}
			}
			mCurrentPageYear = tmpYear;
			updateCalendar();
		}
	};

	private void initData() {
		mCurrentPageCalendar = Calendar.getInstance();
		mCurrentPageCalendar.setMinimalDaysInFirstWeek(7);
		mSelectedCalendar = Calendar.getInstance();
		mToDayCalendar = Calendar.getInstance();
		mToDayCalendar.setTimeInMillis(mShowCalendarTime);
		mToDayCalendar.setMinimalDaysInFirstWeek(7);
		mCurrentPageMonth = mSelectedCalendar.get(Calendar.MONTH);
		mCurrentPageYear = mSelectedCalendar.get(Calendar.YEAR);
		updateSelectedCalendar(mToDayCalendar.get(Calendar.YEAR), mToDayCalendar.get(Calendar.MONTH),
				mToDayCalendar.get(Calendar.DATE));
	}

	/**
	 * 
	 * @param year
	 * @param month limit 0~11
	 * @param day
	 * @author jianfeng.lao
	 * @CreateDate 2013-8-5
	 */
	public void updateSelectedCalendar(int year, int month, int day) {
		mSelectedCalendar.set(year, month, day);
		mSelectedCalendar.set(Calendar.HOUR_OF_DAY, 1);
		mSelectedCalendar.set(Calendar.MINUTE, 0);
		mSelectedCalendar.set(Calendar.SECOND, 0);
		mSelectedCalendar.set(Calendar.MILLISECOND, 0);
		mCurrentPageMonth = mSelectedCalendar.get(Calendar.MONTH);
		mCurrentPageYear = mSelectedCalendar.get(Calendar.YEAR);
	}

	public void updateSelectedCalendar(Date date) {
		if (date == null) {
			date = mToDayCalendar.getTime();
		}
		mSelectedCalendar.setTime(date);
		mSelectedCalendar.set(Calendar.HOUR_OF_DAY, 1);
		mSelectedCalendar.set(Calendar.MINUTE, 0);
		mSelectedCalendar.set(Calendar.SECOND, 0);
		mSelectedCalendar.set(Calendar.MILLISECOND, 0);
		mCurrentPageMonth = mSelectedCalendar.get(Calendar.MONTH);
		mCurrentPageYear = mSelectedCalendar.get(Calendar.YEAR);
	}

	public void updateCalendar() {

		mLayerMonths.removeAllViews();
		mCurrentPageCalendar.setTimeInMillis(mShowCalendarTime);
		mCurrentPageCalendar.set(Calendar.DAY_OF_MONTH, 1);
		mCurrentPageCalendar.set(Calendar.MONTH, Calendar.JANUARY);
		mCurrentPageCalendar.set(Calendar.YEAR, mCurrentPageYear);
		mCurrentPageCalendar.set(Calendar.HOUR_OF_DAY, 1);
		mCurrentPageCalendar.set(Calendar.MINUTE, 0);
		mCurrentPageCalendar.set(Calendar.SECOND, 0);
		mCurrentPageCalendar.set(Calendar.MILLISECOND, 0);
		mHeaderTitle
				.setText(CLDateUtil.formatDate(mCurrentPageCalendar.getTime(), Constants.DATE_FORMAT_PATTERN_SHOW3));
		String[] months = getResources().getStringArray(R.array.month_number);
		int lineCount = 4;
		int line = 3;
		for (int i = 0; i < line; i++) {
			LinearLayout weekdayLayer = new LinearLayout(getContext());
			weekdayLayer.setOrientation(LinearLayout.HORIZONTAL);
			weekdayLayer.setWeightSum(lineCount);
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
					mDayItemHeight);
			lp.topMargin = mCalendarDivider;
			View tmp = null;
			weekdayLayer.setLayoutParams(lp);
			for (int x = 0; x < lineCount; x++) {
				int currentYear = mCurrentPageCalendar.get(Calendar.YEAR);
				int currentMonth = mCurrentPageCalendar.get(Calendar.MONTH);
				int selectYear = mSelectedCalendar.get(Calendar.YEAR);
				int selectMonth = mSelectedCalendar.get(Calendar.MONTH);
				Log.v(TAG, "currentYear>>" + currentYear + ",currentMonth>>" + currentMonth + ",selectYear>>"
						+ selectYear + ",selectMonth>>" + selectMonth);
				TextView dayText = new TextView(getContext());
				dayText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
				dayText.setTextColor(Color.WHITE);
				LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT);
				tlp.weight = 1;
				dayText.setBackgroundColor(getResources().getColor(R.color.dark_green));
				if (x != lineCount - 1) {
					tlp.rightMargin = mCalendarDivider;
				}
				if (currentYear == selectYear && currentMonth == selectMonth) {
					dayText.setBackgroundColor(0xffffffff);
					dayText.setTextColor(0xff5b5b5b);
				}
				dayText.setText(months[(i * 4 + x)]);
				dayText.setTag("" + currentMonth);
				dayText.setGravity(Gravity.CENTER);
				dayText.setLayoutParams(tlp);
				weekdayLayer.addView(dayText);
				if ((i * 4 + x) < 11) {
					mCurrentPageCalendar.set(Calendar.MONTH, (i * 4 + x + 1));// 下一个月
				}
				dayText.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (v.getTag() != null) {
							updateSelectedCalendar(mCurrentPageCalendar.get(Calendar.YEAR),
									Integer.valueOf((String) v.getTag()), 1);
							updateCalendar();
							if (mOnCalendarClickListener != null) {
								mOnCalendarClickListener.onClick(mSelectedCalendar.getTime());
							}
						}

					}
				});
			}
			mLayerMonths.addView(weekdayLayer);
		}
		requestLayout();
	}

	public interface OnCalendarClickListener {
		public void onClick(Date selectDay);
	}

	public void setOnCalendarClickListener(OnCalendarClickListener mOnCalendarClickListener) {
		this.mOnCalendarClickListener = mOnCalendarClickListener;
	}

}
