package com.elderly.elderly.component;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.elderly.elderly.R;

public class ElderlyExpandListView extends FrameLayout {
	private static final String TAG = "ElderlyExpandListView";
	private static final String KEY_EXPANDABLELISTVIEW_STATE = "expandablelistview_state";
	private ExpandableListView mListView;
	private View mLayerBottomArrow;
	private View mLayerTopArrow;
	private View mLayerEmptyTip;
	private ListOnScrollListener mListOnScrollListener;
	private View mFooterView;

	public ElderlyExpandListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupView();

	}

	private void setupView() {
		LayoutInflater.from(getContext()).inflate(R.layout.view_expand_list_view, this, true);
		mListView = (ExpandableListView) findViewById(R.id.view_expand_list_view_mListView);
		mLayerBottomArrow = findViewById(R.id.view_expand_list_view_mLayerBottomArrow);
		mLayerTopArrow = findViewById(R.id.view_expand_list_view_mLayertTopArrow);
		mLayerEmptyTip = findViewById(R.id.view_expand_list_view_mLayerEmptyTip);
		mFooterView = LayoutInflater.from(getContext()).inflate(R.layout.view_expand_list_footer, null);
		setupListener();
	}
	
	public void setState(int groupId){
		mListView.collapseGroup(groupId);
	}

	private void setupListener() {
		mListView.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (scrollState == OnScrollListener.SCROLL_STATE_FLING) {

				} else if (scrollState == OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {

				} else {

				}

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// Log.i("Test scroll", firstVisibleItem+"..."+visibleItemCount+"..."+totalItemCount);
				int ptp = view.pointToPosition(0, 0);
				// 没有东西的时候totalItemCount和visibleItemCount也有1...
				if (totalItemCount == 0 || totalItemCount == 1) {
					mLayerEmptyTip.setVisibility(View.VISIBLE);
					mLayerEmptyTip.requestFocus();
					mLayerTopArrow.setVisibility(View.INVISIBLE);
					mLayerBottomArrow.setVisibility(View.INVISIBLE);
				} else {
					mLayerEmptyTip.setVisibility(View.GONE);
				}
				if (totalItemCount > 0) {
					if (ptp != AdapterView.INVALID_POSITION) {
						Rect topRect = new Rect();
						Rect bottomRect = new Rect();
						View topChildview = view.getChildAt(0);
						topChildview.getHitRect(topRect);
						View bottomChildview = view.getChildAt(view.getChildCount() - 1);
						bottomChildview.getHitRect(bottomRect);
						if (view.getFirstVisiblePosition() == 0
								&& view.getLastVisiblePosition() == (view.getCount() - 1) && topRect.top == 0 &&
								bottomRect.bottom <= getHeight()) {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
							mLayerBottomArrow.setVisibility(View.INVISIBLE);
						} else if (view.getFirstVisiblePosition() == 0
								&& topRect.top == 0
								&& (view.getLastVisiblePosition() != (view.getCount() - 1) ||
								(view.getLastVisiblePosition() == (view.getCount() - 1))
										&& bottomRect.bottom > getHeight())) {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
							mLayerBottomArrow.setVisibility(View.VISIBLE);
						} else if (view.getFirstVisiblePosition() == 0 && topRect.top == 0) {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
						} else if (view.getLastVisiblePosition() == (view.getCount() - 1)
								&& bottomRect.bottom == getHeight()) {
							mLayerTopArrow.setVisibility(View.VISIBLE);
							mLayerBottomArrow.setVisibility(View.INVISIBLE);
							if (mListOnScrollListener != null) {
								mListOnScrollListener
										.onScrollEnd(view, firstVisibleItem, visibleItemCount, totalItemCount);
							}
						} else {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
							mLayerBottomArrow.setVisibility(View.VISIBLE);
						}
					}
					if (mListOnScrollListener != null) {
						mListOnScrollListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
					}
				} else {
					mLayerTopArrow.setVisibility(View.INVISIBLE);
					mLayerBottomArrow.setVisibility(View.INVISIBLE);
				}
			}
		});
	}

	public ExpandableListView getExpandableListView() {
		return mListView;
	}

	public void setAdapter(BaseExpandableListAdapter adapter) {
		// mListView.removeFooterView(mFooterView);
		// mFooterView.setBackgroundColor(0xff005500);
		mListView.removeFooterView(mFooterView);
		if (adapter != null) {
			mListView.addFooterView(mFooterView, null, false);
		}
		mListView.setAdapter(adapter);
	}

	public interface ListOnScrollListener {
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount);

		public void onScrollEnd(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount);
	}

	public void setListOnScrollListener(ListOnScrollListener mListOnScrollListener) {
		this.mListOnScrollListener = mListOnScrollListener;
	}

	public void setTipsContent(int resId) {
		((TextView) mLayerEmptyTip).setText(getContext().getString(resId));
		mLayerEmptyTip.setContentDescription(getContext().getString(resId));
	}

	@Override
	protected Parcelable onSaveInstanceState() {
		Parcelable superState = super.onSaveInstanceState();
		
		Parcelable listViewState = mListView.onSaveInstanceState();
		SavedState savedState = new SavedState(superState);
		int gid = ExpandableListView.getPackedPositionGroup(mListView.getExpandableListPosition(mListView
				.getFirstVisiblePosition()));
		// 当前第一行的子ID
		int cid = ExpandableListView.getPackedPositionChild(mListView.getExpandableListPosition(mListView
				.getFirstVisiblePosition()));
		savedState.childPosition = cid;
		savedState.groupPosition = gid;
		savedState.firstVisiblePosition = mListView.getFirstVisiblePosition();
		if (cid >= 0) {
			Rect rect = new Rect();
			View childView = mListView.getChildAt(0);
			childView.getHitRect(rect);
			savedState.firstVisibleItemYOffset = rect.top;
		}
		return savedState;
	}

	@Override
	protected void onRestoreInstanceState(Parcelable state) {
		
		SavedState savedState = (SavedState) state;
		Log.v(TAG,"savedState>>"+savedState.groupPosition+","+savedState.childPosition);
		super.onRestoreInstanceState(savedState.getSuperState());
		mListView.getFlatListPosition(ExpandableListView.getPackedPositionForChild(savedState.groupPosition,
				savedState.childPosition));
		if (savedState.childPosition >= 0) {
			mListView.setSelectionFromTop(savedState.firstVisiblePosition, savedState.firstVisibleItemYOffset);
		}
	}
	/**
	 * preserve ExpandListView position 
	 * 
	 * @author jianfeng.lao
	 * @version 1.0
	 * @CreateDate 2013-10-24
	 */
	static class SavedState extends BaseSavedState {
		int groupPosition;
		int childPosition;
		int firstVisiblePosition;
		int firstVisibleItemYOffset;

		public SavedState(Parcelable superState) {
			super(superState);
		}

		private SavedState(Parcel in) {
			super(in);
			childPosition = in.readInt();
			groupPosition = in.readInt();
			firstVisiblePosition = in.readInt();
			firstVisibleItemYOffset = in.readInt();
		}

		@Override
		public void writeToParcel(Parcel dest, int flags) {
			super.writeToParcel(dest, flags);
			dest.writeInt(childPosition);
			dest.writeInt(groupPosition);
			dest.writeInt(firstVisiblePosition);
			dest.writeInt(firstVisibleItemYOffset);
		}

		public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
			@Override
			public SavedState createFromParcel(Parcel in) {
				return new SavedState(in);
			}

			@Override
			public SavedState[] newArray(int size) {
				return new SavedState[size];
			}
		};
	}

}
