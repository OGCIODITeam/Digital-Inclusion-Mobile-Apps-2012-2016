package com.elderly.elderly.component;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Paint.FontMetrics;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;
import com.elderly.elderly.pojo.ao.KeyWordAO;
import com.elderly.elderly.util.ElderlyUtil;

public class ElderlyHotTextLayer extends ViewGroup {
	private static final String TAG = "ElderlyHotTextLayer";
	private List<TextView> textViews;
	// private String[] hotKey = new String[] { "太極", "蓝球", "电脑", "Android软件", "facebook", "康樂及運動", "八段錦", "騎馬", "手工藝"
	// };
	private List<KeyWordAO> mHotKey;
	private int mLastY = 0;
	private int mLastX = 0;

	private int mMargin;
	private HotKeyClickListener mHotKeyClickListener;
	FontMetrics fm;

	boolean isLayout;// 解决stackoverflow

	public ElderlyHotTextLayer(Context context, AttributeSet attrs) {
		super(context, attrs);
		int margin = (int) ElderlyUtil.dip2px(getContext(), 10);
		mMargin = margin;
		textViews = new ArrayList<TextView>();
		// setBackgroundColor(0x88552200);
	}

	private void addAndMeasureView() {
		for (int i = 0; i < textViews.size(); i++) {
			MarginLayoutParams mlp = new MarginLayoutParams(MarginLayoutParams.WRAP_CONTENT,
					MarginLayoutParams.WRAP_CONTENT);
			addViewInLayout(textViews.get(i), i, mlp, false);
		}
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		// Log.v(TAG, "onMeasure>>"+MeasureSpec.getSize(widthMeasureSpec)+","+MeasureSpec.getSize(heightMeasureSpec));
		for (int i = 0; i < getChildCount(); i++) {
			View child = getChildAt(i);
			measureChild(child, widthMeasureSpec, heightMeasureSpec);
		}
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		Log.v(TAG, "onLayout>>" + l + "," + t + "," + r + "," + b + "," + changed);
		mLastX = l;
		mLastY = t;
		for (int i = 0; i < getChildCount(); i++) {
			Rect rect = new Rect();
			TextView child = textViews.get(i);
			String text = child.getText().toString();
			fm = child.getPaint().getFontMetrics();
			child.getPaint().getTextBounds(text, 0, text.length(), rect);
			int top = mLastY;
			int left = mLastX;
			int bottom = (int) (mLastY + Math.ceil(fm.descent - fm.ascent)) + child.getPaddingBottom()
					+ child.getPaddingTop();
			int right = mLastX + child.getMeasuredWidth();
			if (right <= getMeasuredWidth() - mMargin) {
				child.layout(left, top, right, bottom);
				Log.v(TAG, "同行text>>right <= getMeasuredWidth()>>>>>>>>" + left + "..." + top + "..." + right + "..."
						+ bottom);
			} else {
				mLastX = l;
				mLastY = (int) (mLastY + Math.ceil(fm.descent - fm.ascent)) + mMargin + child.getPaddingBottom()
						+ child.getPaddingTop();
				top = mLastY;
				left = mLastX;
				bottom = (int) (mLastY + Math.ceil(fm.descent - fm.ascent)) + child.getPaddingBottom()
						+ child.getPaddingTop();
				right = mLastX + child.getMeasuredWidth();
				child.layout(left, top, right, bottom);
				Log.v(TAG, "换行text>>right > getMeasuredWidth()>>>>>>>>" + left + "..." + top + "..." + right + "..."
						+ bottom);
			}
			mLastX = mMargin + right;
			// Log.v(TAG, "text>>" + text + ",rect>>" + rect + ",width>>" + child.getMeasuredWidth());
		}
		int padding = 0;
		int bottom = 0;

		if (fm != null) {
			padding = (int) ElderlyUtil.dip2px(getContext(), 10) * 2;
			bottom = (int) (mLastY + Math.ceil(fm.descent - fm.ascent) + mMargin + padding);
		}
		// if (!changed) {

		// getParent().requestLayout();
		// }
		if (changed) {
			Log.i(TAG, "changed>>mLastY != b>>>>>>>>" + l + "..." + t + "..." + r + "..." + bottom);

			layout(l, t, r, bottom);
			ViewGroup.LayoutParams lp = getLayoutParams();
			lp.height = bottom - t;
			setLayoutParams(lp);

			// super.layout(l, t, r, b);
			// getParent().requestLayout();
			// invalidate();
		} else if (isLayout) {
			isLayout = false;
			Log.i(TAG, "isLayout>>mLastY != b>>>>>>>>" + l + "..." + t + "..." + r + "..." + bottom);
			layout(l, t, r, bottom);
		}
	}

	public void setHotKey(List<KeyWordAO> data) {
		this.mHotKey = data;
		mLastX = 0;
		mLastY = 0;
		removeAllViews();
		if (mHotKey != null) {
			for (int i = 0; i < mHotKey.size(); i++) {
				TextView tmp = new TextView(getContext());
				int padding = (int) ElderlyUtil.dip2px(getContext(), 10);
				tmp.setPadding(padding, padding, padding, padding);
				tmp.setTextAppearance(getContext(), R.style.common_btn);
				tmp.setBackgroundResource(R.drawable.shape_hot_key_bg);
				tmp.setGravity(Gravity.CENTER);
				tmp.setText(mHotKey.get(i).getCode());
				tmp.setContentDescription(mHotKey.get(i).getCode() + "按钮");
				textViews.add(tmp);
				tmp.setTag(mHotKey.get(i));
				tmp.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (mHotKeyClickListener != null) {
							mHotKeyClickListener.onClick((KeyWordAO) v.getTag());
						}

					}
				});
			}
		}
		addAndMeasureView();
		requestLayout();
	}

	public void setHotKeyClickListener(HotKeyClickListener mHotKeyClickListener) {
		this.mHotKeyClickListener = mHotKeyClickListener;
	}

	public interface HotKeyClickListener {
		public void onClick(KeyWordAO keyword);
	}

	public void setIsLayout() {
		isLayout = true;
	}

}
