package com.elderly.elderly.component;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;

public class ElderlyCommunityCentreCell extends LinearLayout {
	private TextView mTxtTitle1;
//	private TextView mTxtTitle2;
	private ImageView mImgVSelect;
	public ElderlyCommunityCentreCell(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater.from(getContext()).inflate(R.layout.view_community_centre_cell, this);
		mTxtTitle1=(TextView) findViewById(R.id.view_community_centre_mTxtTitle1);
//		mTxtTitle2=(TextView) findViewById(R.id.view_community_centre_mTxtTitle2);
		mImgVSelect=(ImageView) findViewById(R.id.view_community_centre_mImgVSelect);
	}

	public TextView getTxtTitle1() {
		return mTxtTitle1;
	}
	
//	public TextView getTxtTitle2() {
//		return mTxtTitle2;
//	}

	public ImageView getIcon() {
		return mImgVSelect;
	}
	
	

}
