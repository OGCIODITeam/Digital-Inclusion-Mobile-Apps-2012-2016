package com.elderly.elderly.component;

import java.io.IOException;

import twitter4j.Status;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.lib.twitter.OnTimeoutListener;
import com.gt.lib.twitter.OnTweetListener;
import com.gt.lib.twitter.TwitterApp;
import com.gt.lib.twitter.TwitterListener;
import com.gt.lib.twitter.TwitterUtil;

public class ItemShareInTwitterDialog extends Dialog implements android.view.View.OnClickListener, TextWatcher {

	private final String TAG = "ItemShareInTwitterDialog";
	private final int WORD_MAX = 139;

	private ViewGroup mDialogLayout;
	// private TextView mContentPrefix;
	private EditText mContentSuffix;
	private TextView mWordCountorText;
	private Button mShareButton;
	private Button mCancelButton;
	private View mCloseButton;

	private int mWordCount = WORD_MAX;

	private TwitterApp mTwitterApp;

	private AlertDialog mTimeoutDialog;
	private Context mContext;

	public ItemShareInTwitterDialog(Context context) {
		super(context, R.style.share_dialog_style);
		mContext = context;
		// mTimeoutDialog = ElderlyUtil.showElderlyDialog(getContext(), 0, 0, R.string.common_network_failure,
		// R.string.common_ok, 0, null, null);
		mTwitterApp = new TwitterApp(context, Constants.TWITTER_CONSUMER_KEY, Constants.TWITTER_CONSUMER_SECRET);
		mTwitterApp.setQuietMode(true);
		mTwitterApp.setTimeout(60);
		// mTwitterApp.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/DroidSans.ttf"));
		mTwitterApp.setTwitterListener(new TwitterListener() {

			@Override
			public void onAuthorizeSuccess() {
				Log.d(TAG, "onAuthorizeSuccess");
			}

			@Override
			public void onAuthorizeFail() {
				Log.d(TAG, "onAuthorizeFail");
				((Activity) mContext).runOnUiThread(new Runnable() {

					@Override
					public void run() {
						showNetworkExceptionDialog();
					}
				});
			}
		});
		mTwitterApp.setOnTimeoutListener(new OnTimeoutListener() {

			@Override
			public void onTimeout() {
				Log.d(TAG, "onTimeout");
				((Activity) mContext).runOnUiThread(new Runnable() {

					@Override
					public void run() {
						showNetworkExceptionDialog();
					}
				});
			}
		});
		initComponent();
	}

	private void initComponent() {
		LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mDialogLayout = (ViewGroup) inflater.inflate(R.layout.dialog_share_twitter, null);

		int padding = (int) ElderlyUtil.dip2px(getContext(), 15);
		mDialogLayout.setPadding(padding, padding, padding, padding);
		setContentView(mDialogLayout);
		getWindow().setLayout(android.view.WindowManager.LayoutParams.FILL_PARENT, android.view.WindowManager.LayoutParams.FILL_PARENT);

		// mContentPrefix = (TextView) findViewById(R.id.dialog_share_twitter_content_prefix);
		mContentSuffix = (EditText) findViewById(R.id.dialog_share_twitter_content_suffix);
		mWordCountorText = (TextView) findViewById(R.id.dialog_share_twitter_word_countor);
		mShareButton = (Button) findViewById(R.id.dialog_share_twitter_share_btn);
		mCancelButton = (Button) findViewById(R.id.dialog_share_twitter_cancel_btn);
		mCloseButton = findViewById(R.id.dialog_share_twitter_close_btn);

		mWordCountorText.setText(String.valueOf(WORD_MAX));
		mContentSuffix.addTextChangedListener(this);
		mShareButton.setOnClickListener(this);
		mCancelButton.setOnClickListener(this);
		mCloseButton.setOnClickListener(this);
	}

	@Override
	protected void onStart() {
		Log.e(TAG, "Dialog start..");
		super.onStart();
	}

	@Override
	protected void onStop() {
		Log.e(TAG, "Dialog stop..");
		super.onStop();
	}

	@Override
	public void afterTextChanged(Editable text) {
		if (mWordCount - text.length() < 0) {
			Log.i(TAG, "mWordCountorText>>>>afterTextChanged1" + mWordCount);
			CharSequence finalText = text.subSequence(0, mWordCount);
			int selection = mContentSuffix.getSelectionStart();
			selection = Math.min(selection, finalText.length());
			selection = Math.max(0, selection);
			mContentSuffix.setText(finalText);
			mContentSuffix.setSelection(selection);
		} else {
			Log.i(TAG, "mWordCountorText>>>>afterTextChanged2" + (mWordCount - text.length()));
			mWordCountorText.setText(String.valueOf(mWordCount - text.length()));
		}
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.dialog_share_twitter_share_btn:
			String shareContent = mContentSuffix.getText().toString();
			if (isConnect(mContext)) {
				if (shareContent.length() < 1) {
					((Activity) mContext).runOnUiThread(new Runnable() {
						@Override
						public void run() {
							ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.share_twitter_empty,
									R.string.common_confirm, 0, null, null);
						}
					});

				} else {
					int length = Math.min(shareContent.length(), WORD_MAX);
					shareContent = shareContent.substring(0, length);
					mTwitterApp.tweet(shareContent, new OnTweetListener() {

						@Override
						public void onTweetSuccess(Status status) {
							((Activity) mContext).runOnUiThread(new Runnable() {

								@Override
								public void run() {
									showShareSuccessDialog();
								}
							});

							dismiss();
						}

						@Override
						public void onTweetFail(final Status status) {
							((Activity) mContext).runOnUiThread(new Runnable() {

								@Override
								public void run() {
									showShareFailDialog();
								}
							});

						}
					});
				}
			} else {
				((Activity) mContext).runOnUiThread(new Runnable() {

					@Override
					public void run() {
						showNetworkExceptionDialog();
					}
				});
			}
			break;

		case R.id.dialog_share_twitter_cancel_btn:
		case R.id.dialog_share_twitter_close_btn:
			dismiss();
			break;
		}
	}

	public void share(final String context) {
		if (isConnect(mContext)) {
			if (context == null) {
				return;
			}
			if (!mTwitterApp.hasAccessToken()) {
				mTwitterApp.setTwitterListener(new TwitterListener() {

					@Override
					public void onAuthorizeSuccess() {
						shareToTwitter(context);
					}

					@Override
					public void onAuthorizeFail() {
						((Activity) mContext).runOnUiThread(new Runnable() {

							@Override
							public void run() {
								showNetworkExceptionDialog();
							}
						});
					}
				});
				mTwitterApp.authorize();
			} else {
				shareToTwitter(context);
			}
		} else {
			((Activity) mContext).runOnUiThread(new Runnable() {

				@Override
				public void run() {
					showNetworkExceptionDialog();
				}
			});
		}
	}

	private void shareToTwitter(String context) {
		// mWordCount = WORD_MAX - context.length();
		Log.i(TAG, "mWordCountorText>>>>shareToT" + mWordCount);
		mContentSuffix.setText(context);
		new GetShortenUrlTask().execute(context);
		show();
	}

	class GetShortenUrlTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			String shortenUrl = null;
			try {
				shortenUrl = TwitterUtil.translateShortenUrl(params[0]);
			} catch (IOException e) {
				shortenUrl = "";
				e.printStackTrace();
			}
			Log.i(TAG, "shortenUrl>>>>>>" + shortenUrl);
			return shortenUrl;
		}

		@Override
		protected void onPostExecute(String result) {
			synchronized (mContentSuffix) {
				mWordCount = WORD_MAX - result.length();
				mWordCount = Math.max(0, mWordCount);
				Log.i(TAG, "mWordCountorText>>>>onPostExecute" + mWordCount);
				mWordCountorText.setText(String.valueOf(mWordCount - mContentSuffix.length()));
			}
			super.onPostExecute(result);
		}
	}

	public static boolean isConnect(Context context) {
		// 获取手机所有连接管理对象（包括对wi-fi,net等连接的管理）
		try {
			ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivity != null) {
				// 获取网络连接管理的对象
				NetworkInfo info = connectivity.getActiveNetworkInfo();
				if (info != null && info.isConnected()) {
					// 判断当前网络是否已经连接
					if (info.getState() == NetworkInfo.State.CONNECTED) {
						return true;
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			Log.v("error", e.toString());
		}
		return false;
	}
	
	private void showShareSuccessDialog(){
		ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.share_sucess, R.string.common_ok, 0, null,
				null);
	}
	
	private void showNetworkExceptionDialog(){
		ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.common_network_failure, R.string.common_ok, 0, null, null);
	}
	
	private void showShareFailDialog(){
		ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.share_fail, R.string.common_ok, 0, null,
				null);
	}
}
