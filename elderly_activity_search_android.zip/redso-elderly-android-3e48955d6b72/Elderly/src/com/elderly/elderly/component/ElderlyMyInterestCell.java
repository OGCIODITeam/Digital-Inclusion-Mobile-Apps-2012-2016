package com.elderly.elderly.component;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;

public class ElderlyMyInterestCell extends LinearLayout {
	private TextView mTxtTitle;
	private ImageView mImgVSelect;
	public ElderlyMyInterestCell(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater.from(getContext()).inflate(R.layout.view_my_interect_cell, this);
		mTxtTitle=(TextView) findViewById(R.id.view_my_interest_mTxtTitle);
		mImgVSelect=(ImageView) findViewById(R.id.view_my_interest_mImgVSelect);
	}

	public TextView getTxtTitle() {
		return mTxtTitle;
	}

	public ImageView getIcon() {
		return mImgVSelect;
	}
	
	

}
