package com.elderly.elderly.component;

import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyLocationWheel.LocationWheelListener;

import android.text.Html;
import android.util.Log;
import android.view.View.OnClickListener;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ElderlyLinkPanel extends LinearLayout implements OnClickListener {

	private View mLayerConfirm;
	private View mLayerCancel;
	private View mlayerControlBar;
	private TextView mContent;
	private LocationWheelListener mLocationWheelListener;

	public ElderlyLinkPanel(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		setFocusable(true);
		setFocusableInTouchMode(true);
		setOrientation(LinearLayout.VERTICAL);
		LayoutInflater.from(getContext()).inflate(R.layout.view_link_panel, this, true);
		mLayerConfirm = findViewById(R.id.view_simple_wheel_mLayerConfirm);
		mLayerCancel = findViewById(R.id.view_simple_wheel_mLayerCancel);
		mlayerControlBar = findViewById(R.id.view_simple_wheel_mLayerControlBar);
		mContent = (TextView) findViewById(R.id.view_link_panel_mContent);
		setupListener();
	}

	private void setupListener() {
		mLayerCancel.setOnClickListener(this);
		mLayerConfirm.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		boolean isConfirm = false;
		if (v.getId() == mLayerCancel.getId()) {
			isConfirm = false;
		} else if (v.getId() == mLayerConfirm.getId()) {
			isConfirm = true;
		}
		if (mLocationWheelListener != null) {
			mLocationWheelListener.onClick(isConfirm);
		}
	}

	public void setControlBarBgColor(int colorId) {
		mlayerControlBar.setBackgroundColor(getResources().getColor(colorId));
	}

	public void setConfirmBgColor(int colorId) {
		mLayerConfirm.setBackgroundColor(getResources().getColor(colorId));
	}
	
	public interface LocationWheelListener {
		public void onClick(boolean isConfirm);
	}

	public void setLocationWheelListener(LocationWheelListener mLocationWheelListener) {
		this.mLocationWheelListener = mLocationWheelListener;
	}
	
	public void setContentText(String text){
		mContent.setText(Html.fromHtml(text));
		mContent.setContentDescription(mContent.getText());
	}
	
	public void setContentDescription(String text){
		mContent.setContentDescription(text);
	}
}
