package com.elderly.elderly.component;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.R;

public class ElderlyGroupCell extends LinearLayout {
	private TextView mTxtTitle;
	private ImageView mImgVArrow;

	public ElderlyGroupCell(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_list_group, this, true);
		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER_VERTICAL);
		mTxtTitle = (TextView) findViewById(R.id.view_list_group_mTxtTitle);
		mImgVArrow = (ImageView) findViewById(R.id.view_list_group_mImgVArrow);

	}

	public TextView getTxtTitle() {
		return mTxtTitle;
	}

	public ImageView getImgVArrow() {
		return mImgVArrow;
	}
	
	

}
