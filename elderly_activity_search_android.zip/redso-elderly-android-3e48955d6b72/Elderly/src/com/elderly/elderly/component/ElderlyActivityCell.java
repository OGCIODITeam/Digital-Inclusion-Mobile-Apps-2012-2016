package com.elderly.elderly.component;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;

public class ElderlyActivityCell extends LinearLayout {
	private TextView mTxtTitle;
	private TextView mTxtDate;
	private TextView mTxtTime;
	private TextView mTxtCost;
	private TextView mTxtActivityType;
	private TextView mTxtActivityArea;
	private ImageView mImgChildDivider;
	private ImageView mBtnMore;

	public ElderlyActivityCell(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_activity_cell, this, true);
		setOrientation(LinearLayout.VERTICAL);
		setGravity(Gravity.CENTER_VERTICAL);
		mTxtTitle = (TextView) findViewById(R.id.view_activity_cell_mTxtTitle);
		mTxtDate = (TextView) findViewById(R.id.view_activity_cell_mTxtDate);
		mTxtTime = (TextView) findViewById(R.id.view_activity_cell_mTxtTime);
		mTxtCost = (TextView) findViewById(R.id.view_activity_cell_mTxtCost);
		mTxtActivityType = (TextView) findViewById(R.id.view_activity_cell_mTxtActivityType);
		mTxtActivityArea = (TextView) findViewById(R.id.view_activity_cell_mTxtActivityArea);
		mImgChildDivider = (ImageView) findViewById(R.id.view_activity_cell_child_divider);
		mBtnMore = (ImageView) findViewById(R.id.view_activity_cell_btn_more);
	}

	public TextView getTxtTitle() {
		return mTxtTitle;
	}

	public TextView getTxtDate() {
		return mTxtDate;
	}

	public TextView getTxtTime() {
		return mTxtTime;
	}

	public TextView getTxtCost() {
		return mTxtCost;
	}

	public TextView getTxtActivityType() {
		return mTxtActivityType;
	}

	public TextView getTxtActivityArea() {
		return mTxtActivityArea;
	}

	public void hideDivider() {
		mImgChildDivider.setVisibility(View.INVISIBLE);
	}
	
	public void setBtnMoreContentDescription(String content,OnClickListener onClickListener){
		mBtnMore.setContentDescription(content);
		mBtnMore.setOnClickListener(onClickListener);
	}
//	public void setBtnMoreContentDescription(String content){
//		mBtnMore.setContentDescription(content);
//	}
}
