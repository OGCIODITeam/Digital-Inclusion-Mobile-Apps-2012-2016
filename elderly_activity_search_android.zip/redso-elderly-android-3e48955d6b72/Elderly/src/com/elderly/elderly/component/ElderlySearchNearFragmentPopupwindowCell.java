package com.elderly.elderly.component;

import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.PopupWindow;

import com.elderly.elderly.R;

public class ElderlySearchNearFragmentPopupwindowCell extends LinearLayout {

	private ListView mListView;
	private ArrayAdapter otherAdapter;

	private String[] rangeList = new String[] { "2英里范围内", "4英里范围内", "8英里范围内" };

	public ElderlySearchNearFragmentPopupwindowCell(Context context, final PopupWindow popupwindow) {
		super(context);
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_search_near_popupwindow_cell, this, true);
		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER_VERTICAL);

		mListView = (ListView) findViewById(R.id.view_search_near_popupwindow_cell_mListView);

		otherAdapter = new ArrayAdapter<String>(getContext(), R.layout.view_range_list_cell, rangeList);
		mListView.setAdapter(otherAdapter);
		
//		mListView.setOnTouchListener(new OnTouchListener() {
//			
//			@Override
//			public boolean onTouch(View v, MotionEvent event) {
//				if(event.getAction()==MotionEvent.ACTION_DOWN){
//					popupwindow.setFocusable(true);
//				}else if(event.getAction()==MotionEvent.ACTION_UP){
//					popupwindow.setFocusable(false);
//				}
//				return false;
//			}
//		});

		mListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.v("KK", "setOnItemClickListener>>");
				popupwindow.dismiss();

			}

		});

	}
}
