package com.elderly.elderly.component;

import android.content.Context;
import android.graphics.Camera;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Transformation;
import android.widget.Gallery;

import com.elderly.elderly.util.ElderlyUtil;

public class ElderlyGallery extends Gallery {
	private static final String TAG = "ElderlyGallery";
	private Camera mCamera;
	private int mMaxDown = 0;
	private boolean mIsScrolling;
	private long lastScrollTime;
	private boolean mIsTouchDown;

	public ElderlyGallery(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ElderlyGallery(Context context) {
		super(context);
		init();
	}

	private void init() {
		mCamera = new Camera();
		mMaxDown = (int) ElderlyUtil.dip2px(getContext(), 20);
		setStaticTransformationsEnabled(true);
	}

	@Override
	protected boolean getChildStaticTransformation(View child, Transformation t) {
		Rect rect = new Rect();
		child.getGlobalVisibleRect(rect);

		t.clear();
		float startX = getMeasuredWidth() / 4;
		float endX = getMeasuredWidth() - startX;
		float centerX = getMeasuredWidth() / 2;
		float viewCenterX = rect.centerX();
		float percent = 1.0f;
		float initScale = 0.9f;
		float translateY = 0;
		float alpha = 0.6f;
		if (viewCenterX <= endX && viewCenterX >= startX) {
			if (viewCenterX >= centerX) {
				percent = (1.0f - (viewCenterX - centerX) / (endX - centerX));
				translateY = percent * mMaxDown;
				initScale = percent * 0.2f + initScale;
				alpha = percent * 0.4f + alpha;
			} else {
				percent = (1f - (centerX - viewCenterX) / (centerX - startX));
				translateY = percent * mMaxDown;
				initScale = percent * 0.2f + initScale;
				alpha = percent * 0.4f + alpha;
			}

		} 
		// Log.v(TAG, "rect>>" + rect + ",range(" + startX + "," + endX + ")" + ",center X>>" + centerX +
		// ",center view X"
		// + viewCenterX);
		mCamera.save();
		t.setTransformationType(Transformation.TYPE_BOTH);
		t.setAlpha(alpha);
		mCamera.translate(0.0f, -translateY, 0.0f);
		Matrix matrix = t.getMatrix();
		mCamera.getMatrix(matrix);
		if (translateY != 0) {
			matrix.postScale(initScale, initScale, child.getWidth() / 2, child.getHeight() / 2);
		} else {
			matrix.postScale(initScale, initScale, child.getWidth() / 2, child.getHeight() / 2);
		}

		mCamera.restore();
		if (mIsScrolling) {
			child.invalidate();
		}
		return true;
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		mIsScrolling = true;
		return super.onScroll(e1, e2, distanceX, distanceY);
	}

	@Override
	public void computeScroll() {
		// Log.v(TAG, "computeScroll>>");
		mIsScrolling = true;
		lastScrollTime = System.currentTimeMillis();
		removeCallbacks(mScrollRunnable);
		postDelayed(mScrollRunnable, 100);
		super.computeScroll();
	}

	Runnable mScrollRunnable = new Runnable() {

		@Override
		public void run() {
//			Log.v(TAG, "computeScroll>> scroll end");

			if (System.currentTimeMillis() - lastScrollTime > 100 && !mIsTouchDown) {
				mIsScrolling = false;
			} else {
				postDelayed(mScrollRunnable, 50);
			}
		}
	};

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			mIsScrolling = true;
			mIsTouchDown = true;
			for (int i = 0; i < getChildCount(); i++) {
				getChildAt(i).invalidate();
				if (getChildCount() - 1 <= i) {
					break;
				}
			}
			break;
		case MotionEvent.ACTION_UP:
			mIsTouchDown = false;
			break;
		}
		return super.onTouchEvent(event);
	}

}
