package com.elderly.elderly.component;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;
import com.elderly.elderly.util.ElderlyUtil;

public class ElderlyWeatherForecastCell extends LinearLayout {
	private ImageView mImgVWeatherIcon;
	private TextView mTxtDate;
	private TextView mTxtWeatherStatus;

	public ElderlyWeatherForecastCell(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		setOrientation(LinearLayout.HORIZONTAL);
//		LayoutParams lp=new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
//		setLayoutParams(lp);
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_weather_forecast_cell, this, true);
		mImgVWeatherIcon = (ImageView) findViewById(R.id.view_weather_forecast_cell_mImgVWeatherIcon);
		mTxtDate = (TextView) findViewById(R.id.view_weather_forecast_cell_mTxtDate);
		mTxtWeatherStatus = (TextView) findViewById(R.id.view_weather_forecast_cell_mTxtWeatherStatus);
		setBackgroundColor(getResources().getColor(R.color.weatherforecast_bg_txt));
		int padding=(int) getResources().getDimension(R.dimen.view_weather_forecast_cell_padding);
		setPadding(padding, padding, padding, padding);
	}

	public ImageView getImgVWeatherIcon() {
		return mImgVWeatherIcon;
	}

	public TextView getTxtDate() {
		return mTxtDate;
	}

	public TextView getTxtWeatherStatus() {
		return mTxtWeatherStatus;
	}
	
	

}
