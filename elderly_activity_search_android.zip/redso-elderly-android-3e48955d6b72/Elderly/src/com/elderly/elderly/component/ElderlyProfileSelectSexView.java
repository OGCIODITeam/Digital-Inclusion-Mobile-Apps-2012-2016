package com.elderly.elderly.component;

import com.elderly.elderly.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;

public class ElderlyProfileSelectSexView extends LinearLayout{
	
	private Button maleBtn;
	private Button femaleBtn;
	private Button ignoreBtn;
	
	public ElderlyProfileSelectSexView(Context context) {
		super(context);
		initView();
	}

	public ElderlyProfileSelectSexView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initView();
	}
	
	private void initView(){
		LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(R.layout.view_profile_select_sex, this);
		
		maleBtn = (Button) view.findViewById(R.id.view_profile_select_sex_maleBtn);
		femaleBtn = (Button) view.findViewById(R.id.view_profile_select_sex_femaleBtn);
		ignoreBtn = (Button) view.findViewById(R.id.view_profile_select_sex_ignoreBtn);
	}

	public Button getMaleBtn() {
		return maleBtn;
	}

	public void setMaleBtn(Button maleBtn) {
		this.maleBtn = maleBtn;
	}

	public Button getFemaleBtn() {
		return femaleBtn;
	}

	public void setFemaleBtn(Button femaleBtn) {
		this.femaleBtn = femaleBtn;
	}

	public Button getIgnoreBtn() {
		return ignoreBtn;
	}

	public void setIgnoreBtn(Button ignoreBtn) {
		this.ignoreBtn = ignoreBtn;
	}
	
	

}
