package com.elderly.elderly.component;

import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.gt.cl.util.CLDateUtil;

public class ElderlyDayPicker extends LinearLayout {
	private View mLayerNextDay;
	private View mLayerPreviousDay;
	private TextView mTxtDate;
	private Calendar mCalendar;
	private DayPickerListener mDayPickerListener;

	public ElderlyDayPicker(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupView();
	}

	public ElderlyDayPicker(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_day_picker, this, true);
		setBackgroundColor(getResources().getColor(R.color.dark_green));
		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER_VERTICAL);
		mLayerNextDay = findViewById(R.id.view_day_picker_mLayerNextDay);
		mLayerPreviousDay = findViewById(R.id.view_day_picker_mLayerPreviousDay);
		mTxtDate = (TextView) findViewById(R.id.view_day_picker_mTxtDate);
		setupData();
		setupListener();
	}

	private void setupData() {
		mCalendar = Calendar.getInstance();
		mCalendar.setFirstDayOfWeek(Calendar.SUNDAY);
		showDate();
	}

	public void setDate(Date date) {
		mCalendar.setTime(date);
		showDate();
	}

	private void setupListener() {
		mLayerNextDay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int day=mCalendar.get(Calendar.DAY_OF_MONTH);
				mCalendar.set(Calendar.DAY_OF_MONTH, (day+1));
				showDate();
				if(mDayPickerListener!=null){
					mDayPickerListener.onPickerDateChange(getDate());
				}
			}
		});
		mLayerPreviousDay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int day=mCalendar.get(Calendar.DAY_OF_MONTH);
				mCalendar.set(Calendar.DAY_OF_MONTH, (day-1));
				showDate();
				if(mDayPickerListener!=null){
					mDayPickerListener.onPickerDateChange(getDate());
				}
			}
		});
		mTxtDate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(mDayPickerListener!=null){
					mDayPickerListener.onClick(v, getDate());
				}
				
			}
		});
	}
	
	private void showDate(){
		String date=CLDateUtil.formatDate(getDate(), Constants.DATE_FORMAT_PATTERN_SHOW);
		mTxtDate.setText(date);
	}

	public Date getDate() {
		return mCalendar.getTime();
	}
	
	public interface DayPickerListener{
		public void onClick(View view,Date currentDate);
		public void onPickerDateChange(Date currentData);
	}

	public void setDayPickerListener(DayPickerListener mDayPickerListener) {
		this.mDayPickerListener = mDayPickerListener;
	}
	
	

}
