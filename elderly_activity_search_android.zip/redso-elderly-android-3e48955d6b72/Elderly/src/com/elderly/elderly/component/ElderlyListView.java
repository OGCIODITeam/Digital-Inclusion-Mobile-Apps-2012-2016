package com.elderly.elderly.component;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;

import com.elderly.elderly.R;
import com.gt.cl.component.listview.CLImageListView;
import com.gt.cl.component.listview.CLImageListView.OnListViewScrollListener;

public class ElderlyListView extends FrameLayout {
	private static final String TAG = "ElderlyListView";
	private CLImageListView mListView;
	private View mLayerBottomArrow;
	private View mLayerTopArrow;
	private View mLayerEmptyTip;
	private ListOnScrollListener mListOnScrollListener;
	private View mFooterView;
	private boolean isHideEmptyTip = false;
	private View mHeaderView;

	public ElderlyListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupView();

	}

	private void setupView() {
		LayoutInflater.from(getContext()).inflate(R.layout.view_list_view, this, true);
		mListView = (CLImageListView) findViewById(R.id.view_list_view_mListView);
		mLayerBottomArrow = findViewById(R.id.view_list_view_mLayerBottomArrow);
		mLayerTopArrow = findViewById(R.id.view_list_view_mLayertTopArrow);
		mLayerEmptyTip = findViewById(R.id.view_list_view_mLayerEmptyTip);
		mFooterView = LayoutInflater.from(getContext()).inflate(R.layout.view_list_footer, null);
		setupListener();
	}

	private void setupListener() {
		mListView.setOnListViewScrollListener(new OnListViewScrollListener() {

			@Override
			public void onScrollWidthDelay(int firstVisibleItem, int visibleItemCount) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				Log.v(TAG, "totalItemCount>>" + totalItemCount + "," + view.getVisibility() + "," + mLayerEmptyTip.getVisibility() + "," + getHeight());
				int ptp = view.pointToPosition(0, 0);
				// 没有东西的时候totalItemCount和visibleItemCount也有1...
				if ((totalItemCount == 1 || totalItemCount == 0 || (mHeaderView != null && totalItemCount == 2)) && !isHideEmptyTip) {
					mLayerEmptyTip.setVisibility(View.VISIBLE);
					mLayerEmptyTip.setVisibility(View.VISIBLE);
					Log.i(TAG, "visible empty tip>>" + isHideEmptyTip + "," + mLayerEmptyTip.getVisibility());
				} else {
					Log.i(TAG, "gone empty tip>>" + isHideEmptyTip);
					mLayerEmptyTip.setVisibility(View.INVISIBLE);
				}
				if (totalItemCount > 0) {
					if (ptp != AdapterView.INVALID_POSITION) {
						Rect topRect = new Rect();
						Rect bottomRect = new Rect();
						View topChildview = view.getChildAt(0);
						topChildview.getHitRect(topRect);
						View bottomChildview = view.getChildAt(view.getChildCount() - 1);
						bottomChildview.getHitRect(bottomRect);
						if (view.getFirstVisiblePosition() == 0 && view.getLastVisiblePosition() == (view.getCount() - 1) && topRect.top == 0 && bottomRect.bottom <= getHeight()) {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
							mLayerBottomArrow.setVisibility(View.INVISIBLE);
						} else if (view.getFirstVisiblePosition() == 0 && topRect.top == 0 && (view.getLastVisiblePosition() != (view.getCount() - 1) || (view.getLastVisiblePosition() == (view.getCount() - 1)) && bottomRect.bottom > getHeight())) {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
							mLayerBottomArrow.setVisibility(View.VISIBLE);
						} else if (view.getFirstVisiblePosition() == 0 && topRect.top == 0) {
							mLayerTopArrow.setVisibility(View.INVISIBLE);
						} else if (view.getLastVisiblePosition() == (view.getCount() - 1) && bottomRect.bottom == getHeight()) {
							requestLayout();

							mLayerBottomArrow.setVisibility(View.INVISIBLE);
							mLayerTopArrow.setVisibility(View.VISIBLE);
							if (mListOnScrollListener != null) {
								mListOnScrollListener.onScrollEnd(view, firstVisibleItem, visibleItemCount, totalItemCount);
							}
						} else {
							requestLayout();
							mLayerTopArrow.setVisibility(View.INVISIBLE);
							mLayerBottomArrow.setVisibility(View.VISIBLE);
						}
					}
					if (mListOnScrollListener != null) {
						mListOnScrollListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
					}
				} else {
					mLayerTopArrow.setVisibility(View.INVISIBLE);
					mLayerBottomArrow.setVisibility(View.INVISIBLE);
				}

			}
		});
	}

	public ListView getListView() {
		return mListView;
	}

	public void setAdapter(BaseAdapter adapter) {
		// mListView.removeFooterView(mFooterView);
		// mFooterView.setBackgroundColor(0xff005500);
		mListView.removeFooterView(mFooterView);

		// JF 留下來，不知道有什麽用，某些機會報空指針
		// if (mHeaderView != null) {
		// mListView.removeHeaderView(mHeaderView);
		// mListView.addHeaderView(mHeaderView);
		// }

		if (adapter != null) {
			mListView.addFooterView(mFooterView, null, false);
		}
		mListView.setAdapter(adapter);
	}

	public void setHeaderView(View headerView) {
		this.mHeaderView = headerView;
		if (mHeaderView != null) {
			mListView.removeHeaderView(mHeaderView);
			mListView.addHeaderView(mHeaderView);
		}
	}

	public interface ListOnScrollListener {
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount);

		public void onScrollEnd(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount);
	}

	public void setListOnScrollListener(ListOnScrollListener mListOnScrollListener) {
		this.mListOnScrollListener = mListOnScrollListener;
	}

	public void setIsHideEmptyTip(boolean isHided) {
		// Log.i("test", "listview elderly》》》hide..." + isHideEmptyTip);
		isHideEmptyTip = isHided;
	}

	public View getHeaderView() {
		return mHeaderView;
	}

}
