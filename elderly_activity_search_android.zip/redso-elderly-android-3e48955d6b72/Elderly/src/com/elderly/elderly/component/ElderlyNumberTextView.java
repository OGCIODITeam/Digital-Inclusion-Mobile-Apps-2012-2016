package com.elderly.elderly.component;

import com.elderly.elderly.R;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class ElderlyNumberTextView extends View {
	private static final String TAG = "ElderlyNumberTextView";
	private float mFontSize;
	private String mText;
	private Paint mPaint;

	public ElderlyNumberTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ElderlyNumberTextView(Context context) {
		super(context);
		init();
	}

	private void init() {
		mPaint = new Paint();
		mPaint.setTextSize(getResources().getDimension(R.dimen.page_main_fragment_current_temperature));
		mPaint.setShadowLayer(2, 1, 1, Color.BLACK);
		mPaint.setColor(Color.WHITE);
		mPaint.setAntiAlias(true);
		mPaint.setTypeface(Typeface.DEFAULT);

	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		
		FontMetrics fontMetrics = mPaint.getFontMetrics();
		Log.v(TAG, "fontMetrics>>" + "" + fontMetrics.leading + "," + fontMetrics.ascent + "," + fontMetrics.descent
				+ "," + fontMetrics.bottom + "," + fontMetrics.top);
		if (mText != null) {
			canvas.drawText(mText, 0, -mPaint.getFontMetrics().ascent - (fontMetrics.bottom - fontMetrics.descent),
					mPaint);
		}
	}

	public void setText(String mText) {
		this.mText = mText;
		postInvalidate();
	}

}
