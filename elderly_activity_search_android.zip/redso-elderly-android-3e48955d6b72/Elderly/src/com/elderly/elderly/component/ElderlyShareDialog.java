package com.elderly.elderly.component;

import lib.gt.ga.v2.GAManager;

import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.elderly.elderly.util.ElderlyUtil;
import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.facebook.gt.facebook.FacebookManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.util.Log;
import android.view.View;

public abstract class ElderlyShareDialog extends Dialog {

	private Context mContext;
	private View mLayoutFacebook;
	private View mLayoutWeibo;
	private View mLayoutTwitter;
	private View mLayoutWhatsapp;
	private View mLayoutSMS;
	private View mLayoutEmail;
	private View mLayoutCancel;
	private ProgressDialog mDialog;
	private ActivityDetailAO mActivityDetailAO;
	private int mColorId;
	private String downloadAppLink = "";
	private String shareContent1 = "";
	private String shareContent2 = "";
	private String shareContent3 = "";
	private boolean isClickFBSend;

	public ElderlyShareDialog(Context context, int colorId, ActivityDetailAO activityDetailAO) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		this.mContext = context;
		this.mActivityDetailAO = activityDetailAO;
		this.mColorId = colorId;
		FacebookManager.getInstance().setHandler(facebookHandler);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.view_share_panel);
		mLayoutFacebook = findViewById(R.id.view_share_panel_mLayerFacebook);
		mLayoutWeibo = findViewById(R.id.view_share_panel_mLayerWeibo);
		mLayoutTwitter = findViewById(R.id.view_share_panel_mLayerTwitter);
		mLayoutWhatsapp = findViewById(R.id.view_share_panel_mLayerWhatsapp);
		mLayoutSMS = findViewById(R.id.view_share_panel_mLayerSMS);
		mLayoutEmail = findViewById(R.id.view_share_panel_mLayerEmail);
		mLayoutCancel = findViewById(R.id.view_share_panel_mLayerCancel);

		shareContent1 = mContext.getString(R.string.share_content_header1);
		shareContent2 = mContext.getString(R.string.share_content_header2);
		shareContent3 = mContext.getString(R.string.share_content_header3);
		setupCommonBtnBgColor(mLayoutCancel, mColorId);
		setupListener();
	}

	private void setupListener() {
		mLayoutFacebook.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.SHARE_ACTIVITYDETAILSHARE, Constants.GA_ACTION_FACEBOOK,
						mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());

				shareFacebook();
				ElderlyShareDialog.this.cancel();
			}
		});
		mLayoutWeibo.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.SHARE_ACTIVITYDETAILSHARE, Constants.GA_ACTION_WEIBO,
						mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());
				onSinaWeiboShare();
				ElderlyShareDialog.this.cancel();
			}
		});
		mLayoutTwitter.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.SHARE_ACTIVITYDETAILSHARE, Constants.GA_ACTION_TWITTER,
						mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());
				ItemShareInTwitterDialog inTwitterDialog = new ItemShareInTwitterDialog(mContext);
				String title = mActivityDetailAO.getTitle();
				String detail =  mActivityDetailAO.getActivityDetail();
				String link = mActivityDetailAO.getLink();
				if (title==null) {
					title="";
				}
				if (detail==null) {
					detail="";
				}
				if (link==null) {
					link="";
				}
				inTwitterDialog.share(title + " " + detail + " "
						+ link);
				ElderlyShareDialog.this.cancel();
			}
		});

		mLayoutWhatsapp.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.SHARE_ACTIVITYDETAILSHARE, Constants.GA_ACTION_WHATSAPP,
						mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());
				PackageManager pm = mContext.getPackageManager();
				String packageName = "com.whatsapp";
				Intent intent = pm.getLaunchIntentForPackage(packageName);
				if (intent != null) {
					// open whatsapp
					Intent waIntent = new Intent(Intent.ACTION_SEND);
					waIntent.setType("text/plain");
					String body = shareContent1 + mActivityDetailAO.getTitle() + shareContent2 + mActivityDetailAO.getLink()
							+ shareContent3 + downloadAppLink;
					waIntent.setPackage("com.whatsapp");
					if (waIntent != null) {
						waIntent.putExtra(Intent.EXTRA_TEXT, body);
						mContext.startActivity(Intent.createChooser(waIntent, "Whatsapp"));
					}
				} else {
					// open google play store
					Intent googlePlayIntent = new Intent(Intent.ACTION_VIEW, Uri
							.parse("https://play.google.com/store/apps/details?id=com.whatsapp&hl=zh_CN"));
					mContext.startActivity(googlePlayIntent);
				}

				ElderlyShareDialog.this.cancel();
			}
		});
		mLayoutSMS.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.SHARE_ACTIVITYDETAILSHARE, Constants.GA_ACTION_SMS,
						mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());
				Uri uri = Uri.parse("smsto:");
				Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
				String body = shareContent1 + mActivityDetailAO.getTitle() + shareContent2 + mActivityDetailAO.getLink()
				+ shareContent3 + downloadAppLink;
				intent.putExtra("sms_body", body);
				mContext.startActivity(intent);
				ElderlyShareDialog.this.cancel();
			}
		});
		mLayoutEmail.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.SHARE_ACTIVITYDETAILSHARE, Constants.GA_ACTION_EMAIL,
						mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());
				Intent intent = new Intent(Intent.ACTION_SEND);
				intent.setType("text/html");
				intent.putExtra(android.content.Intent.EXTRA_SUBJECT, mActivityDetailAO.getTitle());
				String link_val = mActivityDetailAO.getLink();
				String body = shareContent1+""+mActivityDetailAO.getTitle() + "" + shareContent2 + " <a href=\"" + link_val + "\">" + link_val
						+ "</a> " + shareContent3 + " <a href=\"" + downloadAppLink + "\">" + downloadAppLink + "</a>";
				intent.putExtra(android.content.Intent.EXTRA_TEXT, Html.fromHtml(body));
				mContext.startActivity(Intent.createChooser(intent, mContext.getResources().getString(R.string.view_share_email_select)));
				ElderlyShareDialog.this.cancel();
			}
		});
		mLayoutCancel.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				ElderlyShareDialog.this.cancel();
			}
		});

	}

	public void setupCommonBtnBgColor(View view, int colorId) {
		Drawable tmp;
		tmp = view.getBackground();
		Log.v("shape", "tmp" + tmp);
		if (tmp != null && tmp instanceof GradientDrawable) {
			GradientDrawable gd = (GradientDrawable) tmp;
			gd.setColor(mContext.getResources().getColor(colorId));
		}
	}

	protected abstract void onSinaWeiboShare();

	// Facebook>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	protected void shareFacebook() {
		if (!checkShareStatus()) {
			return;
		}
		// 处理FB 逻辑。
		if (!FacebookManager.getInstance().isLogin()) {
			//
			facebookLogin();
		} else {
			shareFaceBookContent(mActivityDetailAO.getLink(), mActivityDetailAO.getTitle(), mActivityDetailAO.getActivityDetail());
		}
	}

	public boolean checkShareStatus() {
		boolean isEnable = false;
		// 检查是否有权限查看文章，并且文章实体是否不为空。
		if (true) {// TODO
			isEnable = true;
		}
		return isEnable;
	}

	// 插件定义 开始。
	public void facebookLogin() {
		if (!FacebookManager.getInstance().isLogin()) {
			FacebookManager.setResIdTextLoading(R.string.share_facebook_tip_waiting);
			FacebookManager.getInstance().login((Activity) mContext);
		}
	}

	public void faceBookLogout() {
		if (FacebookManager.getInstance().isLogin()) {
			showWaitDialog(R.string.share_facebook_tip_logout);
			FacebookManager.getInstance().logout();
		}
	}

	private Handler facebookHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			Log.i("Sdialog", msg.what + ".................");
			switch (msg.what) {
			case FacebookManager.MSG_LOGIN_END:
				shareFaceBookContent(mActivityDetailAO.getLink(), mActivityDetailAO.getTitle(), mActivityDetailAO.getActivityDetail());
				break;
			case FacebookManager.MSG_LOGOUT_END:
			case FacebookManager.MSG_LOGOUT_IO_ERROR:
			case FacebookManager.MSG_LOGIN_ERROR:
			case FacebookManager.MSG_LOGIN_TIMEOUT:
				ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.common_network_failure,
						R.string.common_confirm, 0, null, null);
				break;
			case FacebookManager.MSG_SHARE_ACTION_END:
				Log.i("Sdialog", "MSG_SHARE_ACTION_END>>>>>>>>");
				break;
			case FacebookManager.MSG_SHARE_ACTION_ERROR:
				ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.common_network_failure,
						R.string.common_confirm, 0, null, null);
				break;
			case FacebookManager.MSG_SHARE_ACTION_FB_ERROR:
				ElderlyUtil.showElderlyDialog(mContext, R.string.common_dialog_title, 0, R.string.share_fail, R.string.common_confirm, 0,
						null, null);
				break;
			case FacebookManager.MSG_SHARE_ACTION_CANCEL:
				Log.i("Sdialog", "MSG_SHARE_ACTION_CANCEL>>>>>>>>");
				break;
			case FacebookManager.MSG_SHARE_ACTION_IO_ERROR:
				break;
			case FacebookManager.MSG_SHARE_ACTION_TIMEOUT:
				ElderlyUtil.showElderlyDialog(mContext, R.string.application_name, 0, R.string.common_network_failure,
						R.string.common_confirm, 0, null, null);
				break;
			default:
				break;
			}
			hideWaitDialog();
			super.handleMessage(msg);
		}
	};

	private void shareFaceBookContent(String link, String title, String description) {
		if (link==null) {
			link="";
		}
		if (title==null) {
			title="";
		}
		if (description==null) {
			description="";
		}
		FacebookManager.getInstance().shareActionWithDialog(mContext, link, null, title, "", description);
	}

	public void showWaitDialog(int message) {
		if (mDialog == null) {
			mDialog = new ProgressDialog(mContext);
			mDialog.setMessage(mContext.getString(message));
			mDialog.setOnCancelListener(new OnCancelListener() {
				@Override
				public void onCancel(DialogInterface dialog) {
					FacebookManager.getInstance().setHandler(null);
					mDialog = null;
				}
			});
		}
		mDialog.show();
	}

	public void hideWaitDialog() {
		if (mDialog != null) {
			mDialog.dismiss();
			mDialog = null;
		}
	}

	// 插件定义 结束。
	// Facebook>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
