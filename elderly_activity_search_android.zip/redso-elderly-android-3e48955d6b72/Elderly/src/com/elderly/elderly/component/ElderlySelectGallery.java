package com.elderly.elderly.component;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.Gallery;
import android.widget.ImageView;

public class ElderlySelectGallery extends Gallery {
	private static final String TAG = "ElderlySelectGallery";
	private int mSelectIconId;
	private ImageView mImgVIcon;
	private Drawable mDrawable;

	public ElderlySelectGallery(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ElderlySelectGallery(Context context) {
		super(context);
		init();
	}

	private void init() {

	}

	@Override
	protected void dispatchDraw(Canvas canvas) {
		super.dispatchDraw(canvas);
		if (mDrawable != null) {
			if(mImgVIcon.getHeight()>getHeight()&&getLayoutParams()!=null){
				getLayoutParams().height=mImgVIcon.getHeight();
				requestLayout();
			}
			canvas.save();
			canvas.translate(getWidth()/2-mImgVIcon.getWidth()/2, getHeight()/2-mImgVIcon.getHeight()/2);
			canvas.clipRect(0, 0, mImgVIcon.getWidth(), mImgVIcon.getHeight());
			mImgVIcon.draw(canvas);
			canvas.restore();
		}
	}

	public void setSelectIcon(int id) {
		this.mSelectIconId = id;
		if (mImgVIcon == null) {
			mImgVIcon = new ImageView(getContext());
		}
		mDrawable=getResources().getDrawable(mSelectIconId);
		mImgVIcon.setImageDrawable(mDrawable);
		int widthSpec = MeasureSpec.makeMeasureSpec(mDrawable.getMinimumWidth(), MeasureSpec.EXACTLY);
		int heightSpec = MeasureSpec.makeMeasureSpec(mDrawable.getMinimumHeight(), MeasureSpec.EXACTLY);
		mImgVIcon.measure(widthSpec, heightSpec);
		mImgVIcon.layout(0, 0, mDrawable.getMinimumWidth(),mDrawable.getMinimumHeight());
		invalidate();
	}

}
