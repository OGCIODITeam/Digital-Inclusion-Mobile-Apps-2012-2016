package com.elderly.elderly.component;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebView;

public class ElderlyWebView extends WebView {
	
	private OnScrollChangeListener mOnScrollChangeListener;

	public ElderlyWebView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public ElderlyWebView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public ElderlyWebView(Context context) {
		super(context);
	}
	
	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		// TODO Auto-generated method stub
		super.onScrollChanged(l, t, oldl, oldt);
		if(mOnScrollChangeListener!=null){
			mOnScrollChangeListener.onScrollChanged(l, t, oldl, oldt);
		}
	}
	
	
	
	public void setOnScrollChangeListener(OnScrollChangeListener mOnScrollChangeListener) {
		this.mOnScrollChangeListener = mOnScrollChangeListener;
	}



	public interface OnScrollChangeListener{
		public void onScrollChanged(int l, int t, int oldl, int oldt);
	}

}
