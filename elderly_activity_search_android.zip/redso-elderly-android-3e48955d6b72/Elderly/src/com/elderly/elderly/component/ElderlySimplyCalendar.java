package com.elderly.elderly.component;

import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.gt.cl.util.CLDateUtil;

public class ElderlySimplyCalendar extends LinearLayout {
	private static final String TAG = "SimplyCalendar";

	private int mWeekOfFirstDay = Calendar.SUNDAY;
	private long mShowCalendarTime = System.currentTimeMillis();
	private int mDayItemHeight;
	private TextView mHeaderTitle;
	private View mLayerPreviousMonth;
	private View mLayerNextMonth;
	private LinearLayout mLayerWeek;
	private LinearLayout mLayerDays;
	private int mWeekOrder[] = new int[7];
	private Calendar mToDayCalendar;
	private Calendar mCurrentPageCalendar;
	private Calendar mSelectedCalendar;

	private int mCurrentPageYear;
	private int mCurrentPageMonth;
	private Paint gridPaint;
	private Rect mLayerWeekRect;
	private Rect mLayerDaysRect;
	private int mCalendarDivider;
	
	private OnCalendarClickListener mOnCalendarClickListener;

	public ElderlySimplyCalendar(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupView();
	}

	public ElderlySimplyCalendar(Context context) {
		super(context);
		setupView();
	}

	private void init() {
		setClickable(true);
		gridPaint = new Paint();
		mLayerWeekRect = new Rect();
		mLayerDaysRect = new Rect();
		gridPaint.setAntiAlias(true);
		gridPaint.setStyle(Style.FILL);
		gridPaint.setColor(getResources().getColor(R.color.dark_green));
		mCalendarDivider = Math.round(getResources().getDimension(R.dimen.view_calendar_divider));
		gridPaint.setStrokeWidth(mCalendarDivider);
		Log.v(TAG, "mCalendarDivider>>" + mCalendarDivider);
	}

	private void setupView() {
		init();
		mDayItemHeight = Math.round(getResources().getDimension(R.dimen.view_calendar_item_height));
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_calendar, this);
		mLayerWeek = (LinearLayout) findViewById(R.id.view_calendar_mLayerWeek);
		mLayerDays = (LinearLayout) findViewById(R.id.view_calendar_mLayerDays);
		mLayerPreviousMonth = findViewById(R.id.view_calendar_header_mLayerPreviousMonth);
		mLayerNextMonth = findViewById(R.id.view_calendar_header_mLayerNextMonth);
		mHeaderTitle = (TextView) findViewById(R.id.view_calendar_header_mTxtHeaderTitle);
		mLayerWeek.setWeightSum(7);
		initData();
		setupListener();
		// mLayerDays.setBackgroundColor(0xffb3b3b3);
		// mLayerWeek.setBackgroundColor(0xff5e5e5e);
		mHeaderTitle.setTextColor(Color.WHITE);
		mHeaderTitle.setBackgroundColor(0xff5e5e5e);
	}

	private void setupListener() {
		mLayerPreviousMonth.setOnClickListener(mMonthSelectListener);
		mLayerNextMonth.setOnClickListener(mMonthSelectListener);
	}

	private View.OnClickListener mMonthSelectListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			int tmpMonth = mCurrentPageMonth;
			int tmpYear = mCurrentPageYear;
			int currentYear = mToDayCalendar.get(Calendar.YEAR);
			if (v.getId() == R.id.view_calendar_header_mLayerPreviousMonth) {
				if ((tmpMonth - 1) < 0) {
					tmpMonth = 11;
					tmpYear = tmpYear - 1;
				} else {
					tmpMonth = tmpMonth - 1;
				}
				if (currentYear - 50 > tmpYear) {
					tmpMonth = 0;
					tmpYear = currentYear - 50;
				}
			} else {
				if ((tmpMonth + 1) > 11) {
					tmpMonth = 0;
					tmpYear = tmpYear + 1;
				} else {
					tmpMonth = tmpMonth + 1;
				}
				if (currentYear + 50 < tmpYear) {
					tmpMonth = 11;
					tmpYear = currentYear + 50;
				}
			}
			mCurrentPageMonth = tmpMonth;
			mCurrentPageYear = tmpYear;
			updateCalendar();
		}
	};

	private void initData() {
		mCurrentPageCalendar = Calendar.getInstance();
		mCurrentPageCalendar.setMinimalDaysInFirstWeek(7);
		mSelectedCalendar = Calendar.getInstance();
		mToDayCalendar = Calendar.getInstance();
		mToDayCalendar.setTimeInMillis(mShowCalendarTime);
		mToDayCalendar.setMinimalDaysInFirstWeek(7);
		mToDayCalendar.setFirstDayOfWeek(mWeekOfFirstDay);
		mCurrentPageMonth = mSelectedCalendar.get(Calendar.MONTH);
		mCurrentPageYear = mSelectedCalendar.get(Calendar.YEAR);
		updateSelectedCalendar(mToDayCalendar.get(Calendar.YEAR), mToDayCalendar.get(Calendar.MONTH),
				mToDayCalendar.get(Calendar.DATE));
	}

	/**
	 * 
	 * @param year
	 * @param month limit 0~11
	 * @param day
	 * @author jianfeng.lao
	 * @CreateDate 2013-8-5
	 */
	public void updateSelectedCalendar(int year, int month, int day) {
		mSelectedCalendar.set(year, month, day);
		mSelectedCalendar.set(Calendar.HOUR_OF_DAY, 1);
		mSelectedCalendar.set(Calendar.MINUTE, 0);
		mSelectedCalendar.set(Calendar.SECOND, 0);
		mSelectedCalendar.set(Calendar.MILLISECOND, 0);
		mCurrentPageMonth = mSelectedCalendar.get(Calendar.MONTH);
		mCurrentPageYear = mSelectedCalendar.get(Calendar.YEAR);
	}

	public void updateSelectedCalendar(Date date) {
		if(date==null){
			date=mToDayCalendar.getTime();
		}
		mSelectedCalendar.setTime(date);
		mSelectedCalendar.set(Calendar.HOUR_OF_DAY, 1);
		mSelectedCalendar.set(Calendar.MINUTE, 0);
		mSelectedCalendar.set(Calendar.SECOND, 0);
		mSelectedCalendar.set(Calendar.MILLISECOND, 0);
		mCurrentPageMonth = mSelectedCalendar.get(Calendar.MONTH);
		mCurrentPageYear = mSelectedCalendar.get(Calendar.YEAR);
	}
	

	public void setWeekOfFirstDay(int mWeekOfFirstDay) {
		this.mWeekOfFirstDay = mWeekOfFirstDay;
		mLayerWeek.removeAllViews();
		if (mWeekOfFirstDay >= 8 || mWeekOfFirstDay <= 0) {
			mWeekOfFirstDay = Calendar.SUNDAY;
		}
		for (int i = 0; i < 7; i++) {
			if (mWeekOfFirstDay + i > 7) {
				mWeekOrder[i] = mWeekOfFirstDay + i - 7;
			} else {
				mWeekOrder[i] = mWeekOfFirstDay + i;
			}
			TextView textView = new TextView(getContext());
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT);
			lp.weight = 1;
			if (i != 6) {
				lp.rightMargin = mCalendarDivider;
			}

			textView.setTextColor(Color.WHITE);
			textView.setGravity(Gravity.CENTER);
			textView.setBackgroundColor(0xff5e5e5e);
			textView.setLayoutParams(lp);
			textView.setText("" + getWeekTxtByInt(mWeekOrder[i]));
			mLayerWeek.addView(textView);
		}
	}

	public void updateCalendar() {

		mLayerDays.removeAllViews();
		
		mCurrentPageCalendar.setFirstDayOfWeek(mWeekOfFirstDay);
		mCurrentPageCalendar.setTimeInMillis(mShowCalendarTime);
		mCurrentPageCalendar.set(Calendar.DAY_OF_MONTH, 1);
		mCurrentPageCalendar.set(Calendar.MONTH, mCurrentPageMonth);
		mCurrentPageCalendar.set(Calendar.YEAR, mCurrentPageYear);
		mCurrentPageCalendar.set(Calendar.HOUR_OF_DAY, 1);
		mCurrentPageCalendar.set(Calendar.MINUTE, 0);
		mCurrentPageCalendar.set(Calendar.SECOND, 0);
		mCurrentPageCalendar.set(Calendar.MILLISECOND, 0);
		mHeaderTitle.setText(CLDateUtil.formatDate(mCurrentPageCalendar.getTime(), "yyyy年MM月"));
//		mHeaderTitle.setText(getMonthTxtByInt(mCurrentPageCalendar.get(Calendar.MONTH)));
		// Log.v(TAG, mCurrentPageCalendar.get(Calendar.YEAR) + " " + (mCurrentPageCalendar.get(Calendar.MONTH) + 1) +
		// " " + mCurrentPageCalendar.get(Calendar.DATE)
		// + ",mDayItemHeight>>" + mDayItemHeight);
		// Log.d(TAG, "days>>" + mCurrentPageCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));// 本月份的天数
		// Log.d(TAG, "weeks>>" + mCurrentPageCalendar.getActualMaximum(Calendar.WEEK_OF_MONTH));//
		// 本月份有多少个星期,setFirstDayOfWeek()会影响结果
		// Log.d(TAG, "今日系本月第几个星期>>" + mCurrentPageCalendar.get(Calendar.WEEK_OF_MONTH));
		// Log.v(TAG, "今日系星期几>>" + getWeekTxtByInt(mCurrentPageCalendar.get(Calendar.DAY_OF_WEEK)));
		int weeksOfMonth = mCurrentPageCalendar.getActualMaximum(Calendar.WEEK_OF_MONTH);
		int days = mCurrentPageCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		for (int i = 0; i < weeksOfMonth; i++) {
			LinearLayout weekdayLayer = new LinearLayout(getContext());
			weekdayLayer.setOrientation(LinearLayout.HORIZONTAL);
			weekdayLayer.setWeightSum(mWeekOrder.length);
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
					mDayItemHeight);
			lp.topMargin = mCalendarDivider;
			View tmp = null;
			weekdayLayer.setLayoutParams(lp);
			for (int x = 0; x < mWeekOrder.length; x++) {
				if (tmp == null) {
					int currentDay = mCurrentPageCalendar.get(Calendar.DATE);
					int currentWeek = mCurrentPageCalendar.get(Calendar.WEEK_OF_MONTH);
					int currentDayOfWeek = mCurrentPageCalendar.get(Calendar.DAY_OF_WEEK);
					TextView dayText = new TextView(getContext());
					dayText.setTextColor(Color.WHITE);
					LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT);
					tlp.weight = 1;
					dayText.setBackgroundColor(getResources().getColor(R.color.dark_green));
					if (x != 6) {
						tlp.rightMargin = mCalendarDivider;
					}
					dayText.setGravity(Gravity.CENTER);

					if (mSelectedCalendar.compareTo(mCurrentPageCalendar) == 0) {
						dayText.setBackgroundColor(0xffffffff);
						dayText.setTextColor(0xff5b5b5b);
					}
					if (currentWeek == i + 1 && mWeekOrder[x] == currentDayOfWeek) {
						dayText.setText("" + currentDay);
						dayText.setTag("" + currentDay);
						mCurrentPageCalendar.set(Calendar.DATE, currentDay + 1 <= days ? currentDay + 1 : days);
						dayText.setVisibility(View.VISIBLE);
					} else {
						dayText.setVisibility(View.INVISIBLE);
					}

					dayText.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							if (v.getTag() != null) {
								updateSelectedCalendar(mCurrentPageCalendar.get(Calendar.YEAR),
										mCurrentPageCalendar.get(Calendar.MONTH), Integer.valueOf((String) v.getTag()));
								updateCalendar();
								if(mOnCalendarClickListener!=null){
									mOnCalendarClickListener.onClick(mSelectedCalendar.getTime());
								}
							}
						}
					});
					dayText.setLayoutParams(tlp);
					weekdayLayer.addView(dayText);
				}
			}
			mLayerDays.addView(weekdayLayer);
		}
		requestLayout();
	}

	@Override
	protected void dispatchDraw(Canvas canvas) {
		super.dispatchDraw(canvas);
		Rect tmpRect = new Rect();
		canvas.save();
		Rect viewRect = new Rect();
		getGlobalVisibleRect(viewRect);
		for (int i = 0; i < mLayerDays.getChildCount(); i++) {
			ViewGroup childGroup = (ViewGroup) mLayerDays.getChildAt(i);
			childGroup.getHitRect(tmpRect);
			Rect firstInVisibleViewRect = null;
			Rect lastInVisibleViewRect = null;
			for (int x = 0; x < childGroup.getChildCount(); x++) {
				View child = childGroup.getChildAt(x);
				if (child.getVisibility() == View.INVISIBLE) {
					if (firstInVisibleViewRect == null) {
						firstInVisibleViewRect = new Rect();
						child.getGlobalVisibleRect(firstInVisibleViewRect);
					} else {
						if (lastInVisibleViewRect == null) {
							lastInVisibleViewRect = new Rect();
						}
						child.getGlobalVisibleRect(lastInVisibleViewRect);
					}
				}
			}
			if (firstInVisibleViewRect != null && lastInVisibleViewRect != null) {
				int left = firstInVisibleViewRect.left - viewRect.left;
				int top = firstInVisibleViewRect.top - viewRect.top;
				int right = lastInVisibleViewRect.left - viewRect.left + lastInVisibleViewRect.width();
				int bottom = lastInVisibleViewRect.top - viewRect.top + lastInVisibleViewRect.height();
				canvas.drawRect(left, top, right, bottom, gridPaint);
			} else if (firstInVisibleViewRect != null) {
				int left = firstInVisibleViewRect.left - viewRect.left;
				int top = firstInVisibleViewRect.top - viewRect.top;
				int right = left + firstInVisibleViewRect.width();
				int bottom = top + firstInVisibleViewRect.height();
				canvas.drawRect(left, top, right, bottom, gridPaint);
			}

		}
		canvas.restore();

	}
	
	
	public interface OnCalendarClickListener{
		public void onClick(Date selectDay);
	}
	
	

	public void setOnCalendarClickListener(OnCalendarClickListener mOnCalendarClickListener) {
		this.mOnCalendarClickListener = mOnCalendarClickListener;
	}

	public static String getWeekTxtByInt(int id) {
		switch (id) {
		case Calendar.SUNDAY:
			return "日";
		case Calendar.MONDAY:
			return "一";
		case Calendar.TUESDAY:
			return "二";
		case Calendar.WEDNESDAY:
			return "三";
		case Calendar.THURSDAY:
			return "四";
		case Calendar.FRIDAY:
			return "五";
		case Calendar.SATURDAY:
			return "六";
		}
		return null;
	}
	
	
	public static String getMonthTxtByInt(int month){
		switch (month) {
		case 0:
			return "一月";
		case 1:
			return "二月";
		case 2:
			return "三月";
		case 3:
			return "四月";
		case 4:
			return "五月";
		case 5:
			return "六月";
		case 6:
			return "七月";
		case 7:
			return "八月";
		case 8:
			return "九月";
		case 9:
			return "十月";
		case 10:
			return "十一月";
		case 11:
			return "十二月";
		}
		return null;
	}

}
