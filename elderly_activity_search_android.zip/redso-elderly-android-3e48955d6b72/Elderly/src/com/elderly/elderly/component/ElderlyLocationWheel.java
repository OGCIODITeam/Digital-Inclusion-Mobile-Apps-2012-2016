package com.elderly.elderly.component;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

import com.elderly.elderly.R;
import com.elderly.elderly.adapter.WheelTextAdapter;

import java.util.List;

import kankan.wheel.widget.OnWheelChangedListener;
import kankan.wheel.widget.SimpleWheelView;
import kankan.wheel.widget.WheelView;

public class ElderlyLocationWheel<T> extends LinearLayout implements OnWheelChangedListener, OnClickListener {
	private static final String TAG = "ElderlyLocationWheel";
	private View mLayerConfirm;
	private View mLayerCancel;
	private View mlayerControlBar;
	private SimpleWheelView mSimpleWheelView;
	private WheelTextAdapter mAdapter;
	private LocationWheelListener mLocationWheelListener;
int selected;
	public ElderlyLocationWheel(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		setOrientation(LinearLayout.VERTICAL);
		setFocusable(true);
		setFocusableInTouchMode(true);
		setContentDescription("     ");//在voice的状态下,为了消除wheel的焦点
		LayoutInflater.from(getContext()).inflate(R.layout.view_simple_wheel, this, true);
		mLayerConfirm = findViewById(R.id.view_simple_wheel_mLayerConfirm);
		mLayerCancel = findViewById(R.id.view_simple_wheel_mLayerCancel);
		mlayerControlBar = findViewById(R.id.view_simple_wheel_mLayerControlBar);
		mSimpleWheelView = (SimpleWheelView) findViewById(R.id.view_simple_wheel_mWheelView);
		setupListener();
	}

	public void setupData(List<T> mData, T hightKey) {
		if (mAdapter == null) {
			mAdapter = new WheelTextAdapter(getContext());
		}
		mAdapter.setData(mData.toArray());
		mSimpleWheelView.setViewAdapter(mAdapter);
		int index = 0;
		if (hightKey != null) {
			index = mData.indexOf(hightKey);
			if (index == -1) {
				index = 0;
			}
		}
//		Log.v(TAG, "hightKey>>" + hightKey + ",index >>" + index);
		mSimpleWheelView.setCurrentItem(index);
	}

	public void setListContentDescription(Object[] data){
		if(mAdapter==null){
			mAdapter=new WheelTextAdapter(getContext());
		}
		mAdapter.setDataContentDescription(data);
	}

	private void setupListener() {
		mSimpleWheelView.addChangingListener(this);
		mLayerCancel.setOnClickListener(this);
		mLayerConfirm.setOnClickListener(this);
		mSimpleWheelView.setOnFocusChangeListener(new OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
//				Log.v(TAG, "onFocusChange>>"+hasFocus);
				if(!hasFocus){
					requestFocus();
				}
			}
		});
	}

	public void setControlBarBgColor(int colorId) {
		mlayerControlBar.setBackgroundColor(getResources().getColor(colorId));
	}

	public void setConfirmBgColor(int colorId) {
		mLayerConfirm.setBackgroundColor(getResources().getColor(colorId));
	}

	public WheelTextAdapter getAdapter() {
		return mAdapter;
	}

	@Override
	public void onChanged(WheelView wheel, int oldValue, int newValue) {
		if (mAdapter != null) {
			mAdapter.setSelectedIndex(newValue);
		}
	}

	public interface LocationWheelListener {
		public void onClick(boolean isConfirm, Object data);
	}

	public void setLocationWheelListener(LocationWheelListener mLocationWheelListener) {
		this.mLocationWheelListener = mLocationWheelListener;
	}

	@Override
	public void onClick(View v) {
		boolean isConfirm = false;
		if (v.getId() == mLayerCancel.getId()) {
			isConfirm = false;
		} else if (v.getId() == mLayerConfirm.getId()) {
			isConfirm = true;
		}
		if (mLocationWheelListener != null) {
            selected=mSimpleWheelView.getCurrentItem();
			Object data = mAdapter.getData(mSimpleWheelView.getCurrentItem());

			mLocationWheelListener.onClick(isConfirm, data);
		}

	}

	public void setSelectDrawable(int id){
		if(mSimpleWheelView!=null){
			mSimpleWheelView.setSelectBitmap(id);
		}
	}

	public void releaseWheel(){
		if(mSimpleWheelView!=null){
			mSimpleWheelView.release();
		}
	}

	public int getCurrentIndex(){
		if(mSimpleWheelView!=null){
			return mSimpleWheelView.getCurrentItem();
		}else{
			return 0;
		}
	}
    public int getSelected() {
        return selected;
    }

}
