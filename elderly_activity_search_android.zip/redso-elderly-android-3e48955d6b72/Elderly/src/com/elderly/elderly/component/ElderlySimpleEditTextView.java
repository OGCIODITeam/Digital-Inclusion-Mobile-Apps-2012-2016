package com.elderly.elderly.component;

import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyCirclePageIndicator.SavedState;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.widget.EditText;
import android.widget.FrameLayout;

/**
 * 简写:EditText
 * 
 * @author jianfeng.lao
 * @version 1.0
 * @CreateDate 2013-5-20
 */
public class ElderlySimpleEditTextView extends FrameLayout {
	private static final String TAG="ElderlySimpleEditTextView";
	private EditText mEdTxt;
	private TMTPEditTextViewListener mListener;
	private View mViewClear;
	private OnSimpleTextChangeListener onSimpleTextChangeListener;
	private String mStrContext;

	public ElderlySimpleEditTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ElderlySimpleEditTextView(Context context) {
		super(context);
		init();
	}

	public void setText(String text) {
		mEdTxt.setText(text);
	}

	private void init() {
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_simple_edit_text, this, true);
		setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		mViewClear = findViewById(R.id.view_simple_edit_text_mViewClear);
		mEdTxt = (EditText) findViewById(R.id.view_simple_edit_text_mEdTxt);
		mEdTxt.addTextChangedListener(mTextWatcher);

		mViewClear.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mEdTxt.setText(null);
				if (onSimpleTextChangeListener != null) {
					onSimpleTextChangeListener.onSimpleClear();
				}
			}
		});
	}

	public interface TMTPEditTextViewListener {
		public void onTextChange(String text);
	}

	public void setTMTPEditTextViewListener(TMTPEditTextViewListener mListener) {
		this.mListener = mListener;
	}

	public Editable getText() {
		return mEdTxt.getText();
	}

	public void setPasswordStyle() {
		mEdTxt.setTransformationMethod(PasswordTransformationMethod.getInstance());
	}

	public void setImeOptions(int imeOptions) {
		mEdTxt.setImeOptions(imeOptions);
	}

	public void clearFocus() {
		mEdTxt.clearFocus();
	}

	public EditText getEditText() {
		return mEdTxt;
	}

	public void setHint(int hint) {
		mEdTxt.setHint(hint);
	}

	public interface OnSimpleTextChangeListener {
		public void onSimpleTextChange();

		public void onSimpleClear();
	}

	public void setOnSimpleTextChangeListener(OnSimpleTextChangeListener onSimpleTextChangeListener) {
		this.onSimpleTextChangeListener = onSimpleTextChangeListener;
	}

	public void setEdittextFocusable(boolean focusable) {
		mEdTxt.setFocusable(focusable);
	}

	public EditText getSimpleEditText() {
		return mEdTxt;
	}

	@Override
	protected Parcelable onSaveInstanceState() {
		Log.v(TAG, "mEdTxt>>"+mEdTxt);
		Parcelable superState = super.onSaveInstanceState();
		SavedState savedState = new SavedState(superState);
		savedState.text = mStrContext;
		return savedState;
	}

	@Override
	protected void onRestoreInstanceState(Parcelable state) {
		SavedState savedState = (SavedState) state;
		super.onRestoreInstanceState(savedState.getSuperState());
		mStrContext = savedState.text;
		Log.v(TAG, "mStrContext>>"+savedState.text);
		mEdTxt.setText(mStrContext);
	}

	static class SavedState extends BaseSavedState {
		public String text;

		public SavedState(Parcelable superState) {
			super(superState);
		}

		private SavedState(Parcel in) {
			super(in);
			text = in.readString();
		}

		@Override
		public void writeToParcel(Parcel dest, int flags) {
			super.writeToParcel(dest, flags);
			dest.writeString(text);
		}

		public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
			@Override
			public SavedState createFromParcel(Parcel in) {
				return new SavedState(in);
			}

			@Override
			public SavedState[] newArray(int size) {
				return new SavedState[size];
			}
		};
	}
	
	private TextWatcher mTextWatcher=new TextWatcher() {

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {

		}

		@Override
		public void afterTextChanged(Editable s) {
			if (onSimpleTextChangeListener != null) {
				onSimpleTextChangeListener.onSimpleTextChange();
			}
			mStrContext = s.toString();
			if (s.length() > 0) {
				mViewClear.setVisibility(View.VISIBLE);
			} else {
				mViewClear.setVisibility(View.GONE);
			}
			if (mListener != null) {
				mListener.onTextChange(s.toString());
			}
		}
	};
	
	public void release(){
		mEdTxt.removeTextChangedListener(mTextWatcher);
		onSimpleTextChangeListener=null;
	}
	
	public void changeStyle(){
		mEdTxt.getLayoutParams().height = LayoutParams.MATCH_PARENT;
		mEdTxt.getLayoutParams().width = LayoutParams.MATCH_PARENT;
		mEdTxt.setSingleLine(false);
	}
}
