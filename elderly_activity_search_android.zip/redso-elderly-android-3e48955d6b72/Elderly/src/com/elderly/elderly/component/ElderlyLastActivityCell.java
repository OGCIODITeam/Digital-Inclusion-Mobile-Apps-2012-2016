package com.elderly.elderly.component;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;

public class ElderlyLastActivityCell extends LinearLayout {
	private TextView mTxtTitle;
	private TextView mTxtDate;
	private TextView mTxtLocation;
	private TextView mTxtCost;
	private ImageView mBtnMore;
	
	public ElderlyLastActivityCell(Context context) {
		super(context);
		setupView();
	}

	private void setupView() {
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(R.layout.view_last_activity_cell, this, true);
		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER_VERTICAL);
		mTxtTitle=(TextView) findViewById(R.id.view_last_activity_cell_mTxtTitle);
		mTxtDate=(TextView) findViewById(R.id.view_last_activity_cell_mTxtDate);
		mTxtCost=(TextView) findViewById(R.id.view_last_activity_cell_mTxtCost);
		mTxtLocation=(TextView) findViewById(R.id.view_last_activity_cell_mTxtLocation);
		mBtnMore = (ImageView) findViewById(R.id.view_last_activity_cell_btn_more);
	}

	public TextView getTxtTitle() {
		return mTxtTitle;
	}

	public TextView getTxtDate() {
		return mTxtDate;
	}

	public TextView getTxtLocation() {
		return mTxtLocation;
	}

	public TextView getTxtCost() {
		return mTxtCost;
	}
	
	public ImageView getBtnMore(){
		return mBtnMore;
	}
	
	public void setBtnMoreContentDescription(String content){
		mBtnMore.setContentDescription(content);
	}

}
