package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.pojo.po.ActivityCategoryPo;

public class ActivityCategoryParser extends BaseParser {
	public static final String NODE_ROOT = "category";
	public static final String NODE_ITEM = "item";
	public static final String NODE_KEY = "key";
	public static final String NODE_NAME_TC = "name_tc";
	public static final String NODE_NAME_SC = "name_sc";
	private ArrayList<ActivityCategoryPo> datas;
	private String startTag;
	private ActivityCategoryPo activityCategoryPo;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (activityCategoryPo != null&&startTag!=null) {
				if (startTag.equals(NODE_KEY)) {
					activityCategoryPo.setKey(parser.getText());
				} else if (startTag.equals(NODE_NAME_SC)) {
					activityCategoryPo.setNameSc(parser.getText());
				} else if (startTag.equals(NODE_NAME_TC)) {
					activityCategoryPo.setNameTc(parser.getText());
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_ITEM)) {
				activityCategoryPo = new ActivityCategoryPo();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName.equals(NODE_ITEM)) {
				datas.add(activityCategoryPo);
				activityCategoryPo = null;
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			datas = new ArrayList<ActivityCategoryPo>();
			startTag = null;
			break;
		}
	}

	public List<ActivityCategoryPo> getData() {
		return datas;
	}
}
