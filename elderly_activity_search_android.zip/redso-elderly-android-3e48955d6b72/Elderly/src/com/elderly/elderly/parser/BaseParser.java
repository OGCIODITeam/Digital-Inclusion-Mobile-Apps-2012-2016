package com.elderly.elderly.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.util.Xml;

import com.gt.cl.util.CLFileUtil;

public abstract class BaseParser {
	protected static final String TAG="BaseParser";
	private XmlPullParser parser;
	private InputStream mInputStream;

	public void parser(String filePath) throws XmlPullParserException {
		File file = new File(filePath);
		try {
			mInputStream = new FileInputStream(file);
			parser = Xml.newPullParser();

			parser.setInput(mInputStream, "utf-8");
			if (parser != null) {
				int eventType;
				eventType = parser.getEventType();
				while (eventType != XmlPullParser.END_DOCUMENT) {
					String nodeName = parser.getName();
					handlingTag(eventType, nodeName, parser);
					eventType = parser.next();
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			close();
		}

	}

	public void parser(InputStream mInputStream) throws XmlPullParserException {
		try {
			parser = Xml.newPullParser();
			parser.setInput(mInputStream, "UTF-8");
			if (parser != null) {
				int eventType;
				eventType = parser.getEventType();
				while (eventType != XmlPullParser.END_DOCUMENT) {
					String nodeName = parser.getName();
					handlingTag(eventType, nodeName, parser);
					eventType = parser.next();
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			close();
		}

	}

	public void close() {
		CLFileUtil.closeIOStream(mInputStream);
	}

	protected abstract void handlingTag(int eventType, String nodeName,
			XmlPullParser parser);

	// switch (eventType) {
	// case XmlPullParser.TEXT:
	// break;
	// case XmlPullParser.START_TAG:
	// startTag = nodeName;
	// break;
	// case XmlPullParser.END_TAG:
	// startTag = null;
	// break;
	// case XmlPullParser.START_DOCUMENT:
	// startTag = null;
	// break;
	// }
}
