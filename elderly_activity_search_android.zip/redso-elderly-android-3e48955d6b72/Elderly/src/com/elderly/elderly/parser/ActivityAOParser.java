package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.ActivityAO;

public class ActivityAOParser extends BaseParser {
	private static final String NODE_ACTIVITY = "activity";
	private static final String NODE_ID = "id";
	private static final String NODE_NID = "nid";
	private static final String NODE_TITLE = "title";
	private static final String NODE_DATE = "date";
	private static final String NODE_END_DATE = "endDate";
	private static final String NODE_START_TIME = "startTime";
	private static final String NODE_END_TIME = "endTime";
	private static final String NODE_ACTIVE_AREA = "activeArea";
	private static final String NODE_MEMBER_FEE = "memberFee";
	private static final String NODE_NONMENBER_FEE = "nonmenberFee";
	private static final String NODE_FEE = "fee";
	private static final String NODE_EVENT_TYPE = "eventType";
	private String startTag;
	private List<ActivityAO> mData;
	private ActivityAO mActivtiyAO;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null && mActivtiyAO != null) {
				if (startTag.equals(NODE_ID)) {
					mActivtiyAO.setId(parser.getText());
				} else if (startTag.equals(NODE_NID)) {
					mActivtiyAO.setNid(parser.getText());
				} else if (startTag.equals(NODE_TITLE)) {
					mActivtiyAO.setTitle_tc(parser.getText());
					mActivtiyAO.setTitle_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_DATE)) {
					mActivtiyAO.setDate(parser.getText());
				} else if (startTag.equals(NODE_END_DATE)) {
					mActivtiyAO.setEndDate(parser.getText());
				}else if (startTag.equals(NODE_START_TIME)) {
					mActivtiyAO.setStartTime(parser.getText());
				} else if (startTag.equals(NODE_END_TIME)) {
					mActivtiyAO.setEndTime(parser.getText());
				} else if (startTag.equals(NODE_ACTIVE_AREA)) {
					mActivtiyAO.setActiveArea_tc(parser.getText());
					mActivtiyAO.setActiveArea_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_MEMBER_FEE)) {
					mActivtiyAO.setMemberFee_tc(parser.getText());
					mActivtiyAO.setMemberFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_NONMENBER_FEE)) {
					mActivtiyAO.setNonmenberFee_tc(parser.getText());
					mActivtiyAO.setNonmenberFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_FEE)) {
					mActivtiyAO.setFee_tc(parser.getText());
					mActivtiyAO.setFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_EVENT_TYPE)) {
					mActivtiyAO.setEventType_tc(parser.getText());
					mActivtiyAO.setEventType_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_ACTIVITY)) {
				mActivtiyAO = new ActivityAO();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName.equals(NODE_ACTIVITY)) {
				mData.add(mActivtiyAO);
				mActivtiyAO = null;
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			startTag = null;
			mData = new ArrayList<ActivityAO>();
			break;
		}
	}

	public List<ActivityAO> getData() {
		return mData;
	}

}
