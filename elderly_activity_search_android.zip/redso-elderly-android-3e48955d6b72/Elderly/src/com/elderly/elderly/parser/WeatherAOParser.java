package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.WeatherAO;
import com.elderly.elderly.pojo.ao.WeatherAO.ForecastWeather;

public class WeatherAOParser extends BaseParser {
	private static final String TAG = "WeatherVOParser";

	public static final String NODE_CURRENTWEATHER = "currentWeather";
	public static final String NODE_DATE = "date";
	public static final String NODE_CODE = "code";
	public static final String NODE_NAME = "name";
	public static final String NODE_TYPE = "type";
	public static final String NODE_TEMPERATURE = "temperature";
	public static final String NODE_MAXTEMPERATURE = "maxTemperature";
	public static final String NODE_MINTEMPERATURE = "minTemperature";
	public static final String NODE_WARNING = "warning";
	public static final String NODE_UVRADIATION = "uvRadiation";
	public static final String NODE_HUMIDITY = "humidity";
	public static final String NODE_FORECASTWEATHERLIST = "forecastWeatherList";
	public static final String NODE_FORECASTWEATHER = "forecastWeather";
	private WeatherAO vo;
	private String node = null;
	private List<ForecastWeather> list = new ArrayList<ForecastWeather>();
	private ForecastWeather forecastWeather;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (vo != null && node != null)
				if (node.equals(NODE_DATE)) {
					if (forecastWeather != null) {
						forecastWeather.setDate(parser.getText());
					} else {
						vo.setDate(parser.getText());
					}
				} else if (node.equals(NODE_CODE)) {
					if (forecastWeather != null) {
						forecastWeather.setCode(parser.getText());
					} else {
						vo.setCode(parser.getText());
					}

				} else if (node.equals(NODE_NAME)) {
					if (forecastWeather != null) {
						forecastWeather.setName_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
						forecastWeather.setName(parser.getText());
					} else {
						vo.setName_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
						vo.setName(parser.getText());
					}
				}  else if (node.equals(NODE_TYPE)) {
					if (forecastWeather != null) {
						forecastWeather.setType(parser.getText());
					} else {
						vo.setType(parser.getText());
					}
				} else if (node.equals(NODE_TEMPERATURE)) {
					vo.setTemperature(parser.getText());
				} else if (node.equals(NODE_MAXTEMPERATURE)) {
					if (forecastWeather != null) {
						forecastWeather.setMaxTemperature(parser.getText());
					} else {
						vo.setMaxTemperature(parser.getText());
					}
				} else if (node.equals(NODE_MINTEMPERATURE)) {
					if (forecastWeather != null) {
						forecastWeather.setMinTemperature(parser.getText());
					} else {
						vo.setMinTemperature(parser.getText());
					}
				} else if (node.equals(NODE_WARNING)) {
					vo.setWarning(parser.getText());
				} else if (node.equals(NODE_UVRADIATION)) {
					vo.setUvRadiation(parser.getText());
				} else if (node.equals(NODE_HUMIDITY)) {
					vo.setHumidity(parser.getText());
				}
			break;
		case XmlPullParser.START_TAG:
			node = nodeName;
			if (node.equals(NODE_FORECASTWEATHERLIST)) {
				list = new ArrayList<WeatherAO.ForecastWeather>();
			} else if (node.equals(NODE_FORECASTWEATHER)) {
				forecastWeather = new ForecastWeather();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName != null) {
				if (nodeName.equals(NODE_FORECASTWEATHERLIST)) {
					vo.setWeatherList(list);
					list = null;
				} else if (nodeName.equals(NODE_FORECASTWEATHER)) {
					list.add(forecastWeather);
					forecastWeather = null;
				}
			}
			node = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			vo = new WeatherAO();
			break;
		}
	}

	public WeatherAO getWeatherAO() {
		return vo;
	}
}
