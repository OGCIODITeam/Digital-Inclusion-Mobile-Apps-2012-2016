package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;

public class CommunityCentreAOParser extends BaseParser {
	public static final String NODE_CONTENTTYPESERVICEUNIT = "contentTypeServiceUnit";
	public static final String NODE_INDEX = "index";
	public static final String NODE_VID = "vid";
	public static final String NODE_NID = "nid";
	public static final String NODE_LATITUDE = "latitude";
	public static final String NODE_LONGITUDE = "longitude";
	public static final String NODE_FIELDELDERLYLOCATIONVALUE = "fieldElderlyLocationValue";
	public static final String NODE_FIELDELDERLYORGANIZATIONVALUE = "fieldElderlyOrganizationValue";
	public static final String NODE_FIELDELDERLYCATEGORIESVALUE = "fieldElderlyCategoriesValue";
	public static final String NODE_FIELDELDERLYDISTRICTVALUE = "fieldElderlyDistrictValue";
	public static final String NODE_FIELDELDERLYCENTREVALUE = "fieldElderlyCentreValue";
	private String startTag = null;
	private List<CommunityCentreAO> data;
	private CommunityCentreAO ao;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null && ao != null) {
				if (startTag.equals(NODE_NID)) {
					ao.setNid(parser.getText());
				} else if (startTag.equals(NODE_VID)) {
					ao.setVid(parser.getText());
				} else if (startTag.equals(NODE_LATITUDE)) {
					ao.setLatitude(parser.getText());
				} else if (startTag.equals(NODE_LONGITUDE)) {
					ao.setLongitude(parser.getText());
				} else if (startTag.equals(NODE_FIELDELDERLYLOCATIONVALUE)) {
					ao.setFieldElderlyLocationValue(parser.getText());
					ao.setFieldElderlyLocationValue_sc(LanguageTranslateManager.getInstance().conver(parser.getText(),
							0));
				} else if (startTag.equals(NODE_FIELDELDERLYORGANIZATIONVALUE)) {
					ao.setFieldElderlyOrganizationValue_tc(parser.getText());
					ao.setFieldElderlyOrganizationValue_sc(LanguageTranslateManager.getInstance().conver(
							parser.getText(), 0));
				} else if (startTag.equals(NODE_FIELDELDERLYCATEGORIESVALUE)) {
					ao.setFieldElderlyCategoriesValue_tc(parser.getText());
					ao.setFieldElderlyCategoriesValue_sc(LanguageTranslateManager.getInstance().conver(
							parser.getText(), 0));
				} else if (startTag.equals(NODE_FIELDELDERLYDISTRICTVALUE)) {
					ao.setFieldElderlyDistrictValue_tc(parser.getText());
					ao.setFieldElderlyDistrictValue_sc(LanguageTranslateManager.getInstance().conver(parser.getText(),
							0));
				}else if (startTag.equals(NODE_FIELDELDERLYCENTREVALUE)) {
					ao.setFieldElderlyCentreValue_tc(parser.getText());
					ao.setFieldElderlyCentreValue_sc(LanguageTranslateManager.getInstance().conver(parser.getText(),
							0));
				}else if(startTag.equals(NODE_INDEX)){
					ao.setIndex(Integer.parseInt(parser.getText()));
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_CONTENTTYPESERVICEUNIT)) {
				ao = new CommunityCentreAO();
			}
			break;
		case XmlPullParser.END_TAG:
			if (ao != null && nodeName.equals(NODE_CONTENTTYPESERVICEUNIT)) {
				data.add(ao);
				ao = null;
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			data = new ArrayList<CommunityCentreAO>();
			startTag = null;
			break;
		}
	}

	public List<CommunityCentreAO> getData() {
		return data;
	}

}
