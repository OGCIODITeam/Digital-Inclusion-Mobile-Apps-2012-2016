package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.BannerAO;

public class BannerAOParser extends BaseParser {
	private static final String NODE_BANNER = "banner";
	private static final String NODE_ID = "id";
	private static final String NODE_TITLE = "title";
	private static final String NODE_DESCRIPTION = "description";
	private static final String NODE_IMAGE = "image";
	private static final String NODE_LINK = "link";
	private static final String NODE_TYPE = "type";
	private String startTag;
	private List<BannerAO> mData;
	private BannerAO mBannerAO;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if(startTag!=null&&mBannerAO!=null){
				if(startTag.equals(NODE_ID)){
					mBannerAO.setId(parser.getText());
				}else if(startTag.equals(NODE_TITLE)){
					mBannerAO.setTitle_tc(parser.getText());
					mBannerAO.setTitle_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				}else if(startTag.equals(NODE_DESCRIPTION)){
					mBannerAO.setDescription_tc(parser.getText());
					mBannerAO.setDescription_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				}else if(startTag.equals(NODE_IMAGE)){
					mBannerAO.setImage(parser.getText());
				}else if(startTag.equals(NODE_LINK)){
					mBannerAO.setLink(parser.getText());
				}else if(startTag.equals(NODE_TYPE)){
					mBannerAO.setType(parser.getText());
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_BANNER)) {
				mBannerAO = new BannerAO();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName.equals(NODE_BANNER)) {
				mData.add(mBannerAO);
				mBannerAO = null;
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			startTag = null;
			mData = new ArrayList<BannerAO>();
			break;
		}
	}

	public List<BannerAO> getData() {
		return mData;
	}
	
	

}
