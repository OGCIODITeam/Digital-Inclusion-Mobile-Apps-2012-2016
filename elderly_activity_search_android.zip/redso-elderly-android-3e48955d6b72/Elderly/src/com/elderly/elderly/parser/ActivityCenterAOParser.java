package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.ActivityCenterAO;

public class ActivityCenterAOParser extends BaseParser {
	private static final String NODE_ACTIVITY_CENTER = "activityCenter";
	private static final String NODE_ORGANIZATION = "organization";
	private static final String NODE_ACTIVITY_CENTER_NAME = "activityCenterName";
	private static final String NODE_NID = "nid";
	private static final String NODE_ID = "id";
	private static final String NODE_LONGITUDE = "longitude";
	private static final String NODE_LATITUDE = "latitude";
	private static final String NODE_ACTIVITY_LIST = "activityList";
	private static final String NODE_ACTIVITY = "activity";
	private static final String NODE_TITLE = "title";
	private static final String NODE_EVENT_TYPE = "eventType";
	private static final String NODE_DATE = "date";
	private static final String NODE_START_TIME = "startTime";
	private static final String NODE_END_TIME = "endTime";
	private static final String NODE_ACTIVE_AREA = "activeArea";
	private static final String NODE_MEMBERFEE = "memberFee";
	private static final String NODE_NONMENBERFEE = "nonmenberFee";

	private String startTag;
	private List<ActivityCenterAO> mData;
	private ActivityCenterAO mActivityCenterAO;
	private List<ActivityAO> activityList;
	private ActivityAO mActivityAO;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null && mActivityCenterAO != null) {
				if (startTag.equals(NODE_ORGANIZATION)) {
					mActivityCenterAO.setOrganization_tc(parser.getText());
					mActivityCenterAO.setOrganization_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_ACTIVITY_CENTER_NAME)) {
					mActivityCenterAO.setActivityCenterName_tc(parser.getText());
					mActivityCenterAO.setActivityCenterName_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_NID)) {
					if (mActivityAO != null) {
						mActivityAO.setNid(parser.getText());
					} else {
						mActivityCenterAO.setNid(parser.getText());
					}
				} else if (startTag.equals(NODE_ID)) {
					if (mActivityAO != null) {
						mActivityAO.setId(parser.getText());
					} else {
						mActivityCenterAO.setId(parser.getText());
					}
				} else if (startTag.equals(NODE_LONGITUDE)) {
					mActivityCenterAO.setLongitude(parser.getText());
				} else if (startTag.equals(NODE_LATITUDE)) {
					mActivityCenterAO.setLatitude(parser.getText());
				} else if (startTag.equals(NODE_TITLE)) {
					if (mActivityAO != null) {
						mActivityAO.setTitle_tc(parser.getText());
						mActivityAO.setTitle_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
					}
				} else if (startTag.equals(NODE_EVENT_TYPE)) {
					if (mActivityAO != null) {
						mActivityAO.setEventType_tc(parser.getText());
						mActivityAO.setEventType_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
					}
				} else if (startTag.equals(NODE_DATE)) {
					if (mActivityAO != null) {
						mActivityAO.setDate(parser.getText());
					}
				} else if (startTag.equals(NODE_START_TIME)) {
					if (mActivityAO != null) {
						mActivityAO.setStartTime(parser.getText());
					}
				} else if (startTag.equals(NODE_END_TIME)) {
					if (mActivityAO != null) {
						mActivityAO.setEndTime(parser.getText());
					}
				} else if (startTag.equals(NODE_ACTIVE_AREA)) {
					if (mActivityAO != null) {
						mActivityAO.setActiveArea_tc(parser.getText());
						mActivityAO.setActiveArea_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
					}
				} else if (startTag.equals(NODE_MEMBERFEE)) {
					if (mActivityAO != null) {
						mActivityAO.setMemberFee_tc(parser.getText());
						mActivityAO.setMemberFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
					}
				} else if (startTag.equals(NODE_NONMENBERFEE)) {
					if (mActivityAO != null) {
						mActivityAO.setNonmenberFee_tc(parser.getText());
						mActivityAO.setNonmenberFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
					}
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (startTag.equals(NODE_ACTIVITY_CENTER)) {
				mActivityCenterAO = new ActivityCenterAO();
			} else if (startTag.equals(NODE_ACTIVITY_LIST)) {
				activityList = new ArrayList<ActivityAO>();
			} else if (startTag.equals(NODE_ACTIVITY)) {
				mActivityAO = new ActivityAO();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName != null) {
				if (nodeName.equals(NODE_ACTIVITY_CENTER)) {
					mData.add(mActivityCenterAO);
					mActivityCenterAO = null;
				} else if (nodeName.equals(NODE_ACTIVITY_LIST)) {
					mActivityCenterAO.setActivityList(activityList);
					activityList = null;
				} else if (nodeName.equals(NODE_ACTIVITY)) {
					activityList.add(mActivityAO);
					mActivityAO = null;
				}
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			startTag = null;
			mData = new ArrayList<ActivityCenterAO>();
			break;
		}
	}

	public List<ActivityCenterAO> getData() {
		return mData;
	}
}
