package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

import com.elderly.elderly.pojo.ao.DateAO;

public class DateAOParser extends BaseParser {
	private static final String NOTE_DATE = "date";

	private String startTag;
	private List<DateAO> mData;
	private DateAO mDateAO;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null && mDateAO != null) {
				mDateAO.setDateStr(parser.getText());
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (startTag.equals(NOTE_DATE)) {
				mDateAO = new DateAO();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName != null) {
				if (nodeName.equals(NOTE_DATE)) {
					mData.add(mDateAO);
					mDateAO = null;
				}
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			startTag = null;
			mData = new ArrayList<DateAO>();
			break;
		}
	}

	public List<DateAO> getData() {
		return mData;
	}
}
