package com.elderly.elderly.parser;

import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

import com.elderly.elderly.pojo.ao.VersionAO;

public class VersionAOParser extends BaseParser {

	public static final String NODE_ID = "id";
	public static final String NODE_LINK = "link";
	public static final String NODE_TYPE = "type";
	public static final String NODE_VERSION_NUM = "versionNum";
	public static final String NODE_IPHONE_MSG = "msg";
	public static final String NODE_VERSION = "version";
	public static final String NODE_MSG = "msg";
	public static final String NODE_STATUS = "status";

	private VersionAO mAo;
	private String startTag = null;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null && mAo != null) {
				Log.i(TAG, parser.getText()+"...TEXT");
				if (startTag.equals(NODE_ID)) {
					mAo.setId(parser.getText());
				} else if (startTag.equals(NODE_LINK)) {
					mAo.setLink(parser.getText());
				} else if (startTag.equals(NODE_TYPE)) {
					mAo.setType(parser.getText());
				} else if (startTag.equals(NODE_VERSION_NUM)) {
					mAo.setVersionNum(parser.getText());
				} else if (startTag.equals(NODE_IPHONE_MSG)) {
					mAo.setIphoneMsg(parser.getText());
				} else if (startTag.equals(NODE_STATUS)) {
					mAo.setStatus(parser.getText());
				} else if (startTag.equals(NODE_MSG)) {
					mAo.setMsg(parser.getText());
				} 
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			break;
		case XmlPullParser.END_TAG:
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			mAo = new VersionAO();
			Log.i(TAG, parser.getText()+"...START_DOCUMENT");
			break;
		}
	}

	public VersionAO getData() {
		return mAo;
	}
}
