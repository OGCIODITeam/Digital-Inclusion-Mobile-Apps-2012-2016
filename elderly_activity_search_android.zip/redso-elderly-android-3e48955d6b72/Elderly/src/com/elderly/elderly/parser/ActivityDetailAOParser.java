package com.elderly.elderly.parser;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;

public class ActivityDetailAOParser extends BaseParser {
	private static final String NODE_ACTIVITY = "activity";
	private static final String NODE_ID = "id";
	private static final String NODE_NID = "nid";
	private static final String NODE_TITLE = "title";
	private static final String NODE_DATE = "date";
	private static final String NODE_START_TIME = "startTime";
	private static final String NODE_END_TIME = "endTime";
	private static final String NODE_ACTIVE_AREA = "activeArea";
	private static final String NODE_MEMBER_FEE = "memberFee";
	private static final String NODE_NONMENBER_FEE = "nonmenberFee";
	private static final String NODE_FEE = "fee";
	private static final String NODE_EVENT_TYPE = "eventType";
	private static final String NODE_CENTER_ID = "centerId";
	private static final String NODE_CENTER_NID = "centerNid";
	private static final String NODE_ACTIVITY_CENTER_NAME = "activityCenterName";
	private static final String NODE_ACTIVITY_DETAIL = "activityDetail";
	private static final String NODE_LOCATION = "location";
	private static final String NODE_ORGANIZATION = "organization";
	private static final String NODE_APPLICATIONMETHOD = "applicationMethod";
	private static final String NODE_ACTIVITY_TARGET = "activityTarget";
	private static final String NODE_AGE_LOWER_LIMIT = "ageLowerLimit";
	private static final String NODE_REMARK = "remark";
	private static final String NODE_LONGITUDE = "longitude";
	private static final String NODE_LATITUDE = "latitude";
	private static final String NODE_LINK = "link";
	private static final String NODE_END_DATE="endDate";

	private String startTag;
	private ActivityDetailAO mActivtiyAO;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null && mActivtiyAO != null) {
				if (startTag.equals(NODE_ID)) {
					mActivtiyAO.setId(parser.getText());
				} else if (startTag.equals(NODE_NID)) {
					mActivtiyAO.setNid(parser.getText());
				} else if (startTag.equals(NODE_TITLE)) {
					mActivtiyAO.setTitle_tc(parser.getText());
					mActivtiyAO.setTitle_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_DATE)) {
					mActivtiyAO.setDate(parser.getText());
				} else if (startTag.equals(NODE_START_TIME)) {
					mActivtiyAO.setStartTime(parser.getText());
				} else if (startTag.equals(NODE_END_TIME)) {
					mActivtiyAO.setEndTime(parser.getText());
				} else if (startTag.equals(NODE_ACTIVE_AREA)) {
					mActivtiyAO.setActiveArea_tc(parser.getText());
					mActivtiyAO.setActiveArea_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_MEMBER_FEE)) {
					mActivtiyAO.setMemberFee_tc(parser.getText());
					mActivtiyAO.setMemberFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_NONMENBER_FEE)) {
					mActivtiyAO.setNonmenberFee_tc(parser.getText());
					mActivtiyAO.setNonmenberFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_FEE)) {
					mActivtiyAO.setFee_tc(parser.getText());
					mActivtiyAO.setFee_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_EVENT_TYPE)) {
					mActivtiyAO.setEventType_tc(parser.getText());
					mActivtiyAO.setEventType_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_CENTER_ID)) {
					mActivtiyAO.setCenterId(parser.getText());
				} else if (startTag.equals(NODE_CENTER_NID)) {
					mActivtiyAO.setCenterNid(parser.getText());
				} else if (startTag.equals(NODE_ACTIVITY_CENTER_NAME)) {
					mActivtiyAO.setActivityCenterName_tc(parser.getText());
					mActivtiyAO.setActivityCenterName_sc(LanguageTranslateManager.getInstance().conver(
							parser.getText(), 0));
				} else if (startTag.equals(NODE_ACTIVITY_DETAIL)) {
					mActivtiyAO.setActivityDetail_tc(parser.getText());
					mActivtiyAO
							.setActivityDetail_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_LOCATION)) {
					mActivtiyAO.setLocation_tc(parser.getText());
					mActivtiyAO.setLocation_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_ORGANIZATION)) {
					mActivtiyAO.setOrganization_tc(parser.getText());
					mActivtiyAO.setOrganization_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_APPLICATIONMETHOD)) {
					mActivtiyAO.setApplicationMethod_tc(parser.getText());
					mActivtiyAO.setApplicationMethod_sc(LanguageTranslateManager.getInstance().conver(parser.getText(),
							0));
				} else if (startTag.equals(NODE_ACTIVITY_TARGET)) {
					mActivtiyAO.setActivityTarget_tc(parser.getText());
					mActivtiyAO
							.setActivityTarget_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_AGE_LOWER_LIMIT)) {
					mActivtiyAO.setAgeLowerLimint_tc(parser.getText());
					mActivtiyAO
							.setAgeLowerLimint_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_REMARK)) {
					mActivtiyAO.setRemark_tc(parser.getText());
					mActivtiyAO.setRemark_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
				} else if (startTag.equals(NODE_LATITUDE)) {
					mActivtiyAO.setLatitude(parser.getText());
				} else if (startTag.equals(NODE_LONGITUDE)) {
					mActivtiyAO.setLongitude(parser.getText());
				} else if (startTag.equals(NODE_LINK)) {
					mActivtiyAO.setLink(parser.getText());
				} else if(startTag.equals(NODE_END_DATE)){
					mActivtiyAO.setEndDate(parser.getText());
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_ACTIVITY)) {
				mActivtiyAO = new ActivityDetailAO();
			}
			break;
		case XmlPullParser.END_TAG:
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			startTag = null;
			break;
		}
	}

	public ActivityDetailAO getData() {
		return mActivtiyAO;
	}

}
