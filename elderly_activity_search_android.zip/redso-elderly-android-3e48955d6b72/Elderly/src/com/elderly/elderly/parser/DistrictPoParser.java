package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;

public class DistrictPoParser extends BaseParser {
	public static final String NODE_ROOT = "DistrictList";
	public static final String NODE_District = "District";
	public static final String NODE_KEY = "key";
	public static final String NODE_NAME_TC = "name_tc";
	public static final String NODE_NAME_SC = "name_sc";
	public static final String NODE_REGION = "Region";
	public static final String NODE_REGION_LIST = "RegionList";
	public static final String NODE_VALUE="value";
	private ArrayList<DistrictPo> data = new ArrayList<DistrictPo>();
	private ArrayList<LocationPo> subList = null;
	private DistrictPo districtPo;
	private LocationPo regionPo;
	private String startTag = null;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null) {
				if (subList == null) {
					if (startTag.equals(NODE_KEY)) {
						districtPo.setKey(parser.getText());
					} else if (startTag.equals(NODE_NAME_TC)) {
						districtPo.setNameTc(parser.getText());
					} else if (startTag.equals(NODE_NAME_SC)) {
						districtPo.setNameSc(parser.getText());
					}
				} else {
					if (regionPo != null) {
						if (startTag.equals(NODE_KEY)) {
							regionPo.setKey(parser.getText());
						} else if (startTag.equals(NODE_NAME_TC)) {
							regionPo.setNameTc(parser.getText());
						} else if (startTag.equals(NODE_NAME_SC)) {
							regionPo.setNameSc(parser.getText());
						}else if(startTag.equals(NODE_VALUE)){
							regionPo.setValue(parser.getText());
						}
					}
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_District)) {
				districtPo = new DistrictPo();
			} else if (nodeName.equals(NODE_REGION_LIST)) {
				subList = new ArrayList<LocationPo>();
			} else if (nodeName.equals(NODE_REGION)) {
				regionPo = new LocationPo();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName.equals(NODE_District)) {
				data.add(districtPo);
				districtPo = null;
			} else if (nodeName.equals(NODE_REGION_LIST)) {
				districtPo.setRegions(subList);
				subList = null;
			} else if (nodeName.equals(NODE_REGION)) {
				subList.add(regionPo);
				regionPo = null;
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			break;
		}
	}

	public List<DistrictPo> getData() {
		return data;
	}

}
