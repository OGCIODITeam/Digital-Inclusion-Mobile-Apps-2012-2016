package com.elderly.elderly.parser;

import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.manager.LanguageTranslateManager;
import com.elderly.elderly.pojo.ao.KeyWordAO;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;

public class KeyWordAOParser extends BaseParser {
	public static final String NODE_KEYWORD = "keyword";
	public static final String NODE_ID = "id";
	public static final String NODE_SEQ = "seq";
	public static final String NODE_CODE = "code";
	private ArrayList<KeyWordAO> data = new ArrayList<KeyWordAO>();
	private KeyWordAO ao;
	private String startTag = null;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null) {

				if (ao != null) {
					if (startTag.equals(NODE_ID)) {
						ao.setId(parser.getText());
					} else if (startTag.equals(NODE_SEQ)) {
						ao.setSeq(parser.getText());
					} else if (startTag.equals(NODE_CODE)) {
						ao.setCode_tc(parser.getText());
						ao.setCode_sc(LanguageTranslateManager.getInstance().conver(parser.getText(), 0));
					}
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			if (nodeName.equals(NODE_KEYWORD)) {
				ao = new KeyWordAO();
			}
			break;
		case XmlPullParser.END_TAG:
			if (nodeName.equals(NODE_KEYWORD)) {
				data.add(ao);
				ao = null;
			}
			startTag = null;
			break;
		case XmlPullParser.START_DOCUMENT:
			break;
		}
	}

	public List<KeyWordAO> getData() {
		return data;
	}

}
