package com.elderly.elderly.parser;

import org.xmlpull.v1.XmlPullParser;

import com.elderly.elderly.pojo.ao.GetTokenAO;

public class GetTokenParser extends BaseParser {
	private static final String NODE_STATUS = "status";
	private static final String NODE_MSG = "msg";
	private GetTokenAO mGetTokenAO;
	private String startTag;

	@Override
	protected void handlingTag(int eventType, String nodeName, XmlPullParser parser) {
		switch (eventType) {
		case XmlPullParser.TEXT:
			if (startTag != null) {
				if (startTag.equals(NODE_MSG)) {
					mGetTokenAO.setMessage(parser.getText());
				} else if (startTag.equals(NODE_STATUS)) {
					mGetTokenAO.setStatus(parser.getText());
				}
			}
			break;
		case XmlPullParser.START_TAG:
			startTag = nodeName;
			break;
		case XmlPullParser.END_TAG:
			startTag=null;
			break;
		case XmlPullParser.START_DOCUMENT:
			mGetTokenAO = new GetTokenAO();
			break;
		}
	}

	public GetTokenAO getGetTokenAO() {
		return mGetTokenAO;
	}
	
	

}
