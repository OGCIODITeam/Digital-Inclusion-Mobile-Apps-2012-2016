package com.elderly.elderly.ar;

import android.content.Context;
import android.widget.FrameLayout;

public class ArItemView extends FrameLayout {

	private int mLongitude;// 经度
	private int mLatitude;// 纬度

	public ArItemView(Context context) {
		super(context);
	}

	public int getmLongitude() {
		return mLongitude;
	}

	/**
	 * 
	 * @param mLongitude 经度
	 * @author jianfeng.lao
	 * @CreateDate 2013-9-4
	 */
	public void setmLongitude(int mLongitude) {
		this.mLongitude = mLongitude;
	}

	public int getmLatitude() {
		return mLatitude;
	}

	/**
	 * 
	 * @param mLatitude 纬度
	 * @author jianfeng.lao
	 * @CreateDate 2013-9-4
	 */
	public void setmLatitude(int mLatitude) {
		this.mLatitude = mLatitude;
	}

}
