package com.elderly.elderly.ar;

import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class ArCameraView extends SurfaceView implements Callback {
	private static final String TAG = "ArCameraView";
	private Camera camera;
	private boolean hasStartPrevious = false;
	private boolean hasInitCamera = false;

	public ArCameraView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ArCameraView(Context context) {
		super(context);
		init();
	}

	private void init() {
		getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		getHolder().addCallback(this);
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		Log.v(TAG, "surfaceCreated>>");
		releaseCamera();
		if (!isInitCamera() && !isStartPrevious()) {
			openCamera();
		}
		if (camera == null) {
			return;
		}
		try {
			Log.i(TAG, "surfaceCreated>>");
			// 开启摄像头（2.3版本后支持多摄像头,需传入参数）
			// Log.v(TAG, "Camera getNumberOfCameras >>" + Camera.getNumberOfCameras());
			if (hasCameraHardware(getContext())) {
				// camera = Camera.open(openCameraId);
				// set the surface to be used for live preview
				setupCamera();
				camera.setPreviewDisplay(getHolder());
				camera.startPreview();
			} else {
				throw new NullPointerException("device has not camera feature");
			}
		} catch (Exception ex) {
			if (null != camera) {
				camera.release();
				camera = null;
			}
			// Log.i(TAG + "initCamera", ex.printStackTrace());
			ex.printStackTrace();
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		Log.v(TAG, "surfaceChanged>>" + width + "," + height);
		
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		Log.v(TAG, "surfaceDestroyed>>");
		releaseCamera();
	}

	private void openCamera() {
		Log.v(TAG,"openCamera>>");
		try {
			if (hasCameraHardware(getContext())) {
				if (Build.VERSION.SDK_INT == 8) {
					camera = Camera.open();
				} else {
					camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
				}
			}
		} catch (Exception e) {
			if (null != camera) {
				camera.release();
				camera = null;
			}
			// Log.i(TAG + "initCamera", ex.printStackTrace());
			e.printStackTrace();
		}
	}

	private void releaseCamera() {
		if (camera != null) {
			camera.cancelAutoFocus();
			camera.autoFocus(null);
			camera.setPreviewCallback(null); // ！！这个必须在前，不然退出出错
			camera.stopPreview();
			hasStartPrevious = false;
			hasInitCamera = false;
			camera.release();
			camera = null;
		}
	}

	private void setupCamera() {
		if (camera == null) {
			return;
		}
		hasInitCamera = false;
		Log.i(TAG, "going into initCamera");
		if (hasStartPrevious) {
			stopPreView();
		}
		if (camera != null) {
			Camera.Parameters parameters = camera.getParameters();
			camera.setDisplayOrientation(getCameraOrientation());
			parameters.set("orientation", "portrait");
			hasInitCamera = true;
		}
	}

	public void startPreivew() {
		if (camera != null) {
			camera.startPreview();
			hasStartPrevious = true;
		}
	}

	public void stopPreView() {
		if (camera != null) {
			camera.stopPreview();

		}
		hasStartPrevious = false;
	}

	/**
	 * adjust device have front camera
	 * 
	 * @return
	 */
	public static boolean hasCameraHardware(Context context) {
		if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
			// this device has a camera
			return true;
		} else {
			// no camera on this device
			return false;
		}
	}

	public static boolean hasCameraAutoFocusHardware(Context context) {
		if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_AUTOFOCUS)) {
			// this device has a camera
			return true;
		} else {
			// no camera on this device
			return false;
		}
	}

	public boolean isStartPrevious() {
		return hasStartPrevious;
	}

	public boolean isInitCamera() {
		return hasInitCamera;
	}

	public int getCameraOrientation() {
		int degrees = 0;
		switch (getDeviceRotation()) {
		case Surface.ROTATION_0:
			degrees = 0;
			break;
		case Surface.ROTATION_90:
			degrees = 90;
			break;
		case Surface.ROTATION_180:
			degrees = 180;
			break;
		case Surface.ROTATION_270:
			degrees = 270;
			break;
		}
		int result = degrees;
		if (Build.VERSION.SDK_INT <= 8) {
			return result + 90;
		} else {
			CameraInfo info = new CameraInfo();
			Camera.getCameraInfo(0, info);

			if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
				result = (info.orientation + degrees) % 360;
				result = (360 - result) % 360;
			} else {
				result = (info.orientation - degrees + 360) % 360;
			}
			// Log.i(TAG, "getCameraOrientation>>" + result + " CameraInfo>>" + info.orientation);
		}
		// Log.i(TAG, "getCameraOrientation>>" + result);
		return result;
	}

	public int getDeviceRotation() {
		WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
		return wm.getDefaultDisplay().getRotation();
	}

}
