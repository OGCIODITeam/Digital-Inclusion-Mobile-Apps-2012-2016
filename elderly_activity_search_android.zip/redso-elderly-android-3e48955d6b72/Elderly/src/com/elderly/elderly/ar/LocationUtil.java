package com.elderly.elderly.ar;

import android.location.Location;

public class LocationUtil {
	public static double getDistance(double lat1, double lon1, double lat2, double lon2) {
		float[] results = new float[1];
		Location.distanceBetween(lat1, lon1, lat2, lon2, results);
		return results[0];
	}

	public static double gps2d(double lat_a, double lng_a, double lat_b, double lng_b) {
		double d = 0;
		lat_a = lat_a * Math.PI / 180;
		lng_a = lng_a * Math.PI / 180;
		lat_b = lat_b * Math.PI / 180;
		lng_b = lng_b * Math.PI / 180;

		d = Math.sin(lat_a) * Math.sin(lat_b) + Math.cos(lat_a) * Math.cos(lat_b) * Math.cos(lng_b - lng_a);
		d = Math.sqrt(1 - d * d);
		d = Math.cos(lat_b) * Math.sin(lng_b - lng_a) / d;
		d = Math.asin(d) * 180 / Math.PI;
		// d=Math.round(d*10000);
		return d;
	}
	/**
	 * 计算点A 和 点B的经纬度，B相对于点A的方位
	 * @param longitude 
	 * @param latitude
	 * @param longitude_b
	 * @param latitude_b
	 * @return
	 * @author jianfeng.lao
	 * @CreateDate 2013-9-3
	 */
	public static double angle(double longitude, double latitude, double longitude_b, double latitude_b) {
		double Rc = 6378137;  // 赤道半径
		double Rj = 6356725;  // 极半径
		double m_LoDeg, m_LoMin, m_LoSec;  // longtitude 经度
		double m_LaDeg, m_LaMin, m_LaSec;//纬度
		double m_Longitude, m_Latitude;
		double m_RadLo, m_RadLa;
		double Ec;
		double Ed;

		double m_LoDeg_b, m_LoMin_b, m_LoSec_b;
		double m_LaDeg_b, m_LaMin_b, m_LaSec_b;
		double m_Longitude_b, m_Latitude_b;
		double m_RadLo_b, m_RadLa_b;
		double Ec_b;
		double Ed_b;

		m_LoDeg = (int) longitude;
		m_LoMin = (int) ((longitude - m_LoDeg) * 60);
		m_LoSec = (longitude - m_LoDeg - m_LoMin / 60.) * 3600;
		m_LaDeg = (int) latitude;
		m_LaMin = (int) ((latitude - m_LaDeg) * 60);
		m_LaSec = (latitude - m_LaDeg - m_LaMin / 60.) * 3600;
		m_Longitude = longitude;
		m_Latitude = latitude;
		m_RadLo = longitude * Math.PI / 180.;
		m_RadLa = latitude * Math.PI / 180.;
		Ec = Rj + (Rc - Rj) * (90. - m_Latitude) / 90.;
		Ed = Ec * Math.cos(m_RadLa);

		m_LoDeg_b = (int) longitude_b;
		m_LoMin_b = (int) ((longitude_b - m_LoDeg_b) * 60);
		m_LoSec_b = (longitude_b - m_LoDeg_b - m_LoMin_b / 60.) * 3600;
		m_LaDeg_b = (int) latitude_b;
		m_LaMin_b = (int) ((latitude_b - m_LaDeg_b) * 60);
		m_LaSec_b = (latitude_b - m_LaDeg_b - m_LaMin_b / 60.) * 3600;
		m_Longitude_b = longitude_b;
		m_Latitude_b = latitude_b;
		m_RadLo_b = longitude_b * Math.PI / 180.;
		m_RadLa_b = latitude_b * Math.PI / 180.;
		Ec_b = Rj + (Rc - Rj) * (90. - m_Latitude_b) / 90.;
		Ed_b = Ec_b * Math.cos(m_RadLa_b);

		double dx = (m_RadLo_b - m_RadLo) * Ed;
		double dy = (m_RadLa_b - m_RadLa) * Ec;
		double angle = 0.0;
		angle = Math.atan(Math.abs(dx / dy)) * 180. / Math.PI;
		double dLo = m_Longitude_b - m_Longitude;
		double dLa = m_Latitude_b - m_Latitude;
		if (dLo > 0 && dLa <= 0) {
			angle = (90. - angle) + 90.;
		}
		else if (dLo <= 0 && dLa < 0) {
			angle = angle + 180.;
		}
		else if (dLo < 0 && dLa >= 0) {
			angle = (90. - angle) + 270;
		}
		return angle;

	}

}
