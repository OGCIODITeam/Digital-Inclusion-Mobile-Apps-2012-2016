package com.elderly.elderly.ar;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Transformation;
import android.widget.FrameLayout;

public class ArWorkPlaceLayer extends FrameLayout {
	private int mSearchAngle=45;
	private List<ArItemView> mChildView;
	private int mMyLocationLongitude;
	private int mMyLocationLatitude;

	public ArWorkPlaceLayer(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ArWorkPlaceLayer(Context context) {
		super(context);
		init();
	}

	private void init() {
		mChildView=new ArrayList<ArItemView>();
		setStaticTransformationsEnabled(true);
		setupView();
	}

	private void setupView() {
		
	}
	
	@Override
	protected boolean getChildStaticTransformation(View child, Transformation t) {
		return super.getChildStaticTransformation(child, t);
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		for (int i = 0; i < getChildCount(); i++) {
			View child = getChildAt(i);
			measureChild(child, widthMeasureSpec, heightMeasureSpec);
		}
	}
	
	

}
