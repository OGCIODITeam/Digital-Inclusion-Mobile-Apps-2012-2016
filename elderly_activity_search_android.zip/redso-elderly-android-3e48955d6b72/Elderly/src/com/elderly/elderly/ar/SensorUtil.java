package com.elderly.elderly.ar;

import java.util.Arrays;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;

public class SensorUtil implements SensorEventListener {
	private static final String TAG = "SensorUtil";
	private OrientationChangeListener mOrientationChangeListener;

	private static SensorUtil mInstance;
	private Context mContext;
	private SensorManager mSensorManager;
	private Sensor mOrientationSensor;// 方向传感器
	private Sensor mGravitySensor;// 重力感应器
	private Sensor mMagneticSensor;// 地磁传感器

	private float[] mAccelerometerValues = new float[3];

	private float[] mMagneticFieldValues = new float[3];

	private float[] mOrientationFieldValues = new float[3];

	private float mLastOrientation;
	
	

	private SensorUtil(Context mContext) {
		this.mContext = mContext;
		mSensorManager = (SensorManager) mContext.getSystemService(Context.SENSOR_SERVICE);
		mOrientationSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		mGravitySensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		mMagneticSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
	}

	public static void init(Context mContext) {
		if (mInstance == null) {
			mInstance = new SensorUtil(mContext);
		}
	}

	public static SensorUtil getInstance() {
		return mInstance;
	}

	public void start() {
		new Thread() {
			public void run() {
				mSensorManager.registerListener(SensorUtil.this, mOrientationSensor, 3 * 100 * 1000);
				mSensorManager.registerListener(SensorUtil.this, mGravitySensor, 10 * 100 * 1000);
				mSensorManager.registerListener(SensorUtil.this, mMagneticSensor, 10 * 100 * 1000);
			}
		}.start();

	}

	public void stop() {
		mSensorManager.unregisterListener(this, mOrientationSensor);
		mSensorManager.unregisterListener(this, mGravitySensor);
		mSensorManager.unregisterListener(this, mMagneticSensor);
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_ORIENTATION) {
			mOrientationFieldValues = event.values;
			mLastOrientation = mOrientationFieldValues[0];
			if (mOrientationChangeListener != null) {
				mOrientationChangeListener.onChange(mOrientationFieldValues);
			}
			Log.v(TAG, "" + Arrays.toString(event.values));
		} else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
			mMagneticFieldValues = event.values;
		} else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
			mAccelerometerValues = event.values;
		}

	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

	private void calculateOrientation() {
		float[] values = new float[3];
		float[] R = new float[9];
		SensorManager.getRotationMatrix(R, null, mAccelerometerValues, mMagneticFieldValues);
		SensorManager.getOrientation(R, values);
		values[0] = (float) Math.toDegrees(values[0]);
		Log.i(TAG, "orientation>>" + values[0]);
	}

	public float[] getOrientationFieldValues() {
		return mOrientationFieldValues;
	}

	public interface OrientationChangeListener {
		public void onChange(float[] value);
	}

	public void setOrientationChangeListener(OrientationChangeListener mOrientationChangeListener) {
		this.mOrientationChangeListener = mOrientationChangeListener;
	}

}
