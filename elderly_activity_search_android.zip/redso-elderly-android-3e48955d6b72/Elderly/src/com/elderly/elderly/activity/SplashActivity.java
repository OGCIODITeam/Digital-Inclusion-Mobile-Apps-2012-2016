package com.elderly.elderly.activity;

import lib.gt.ga.v2.GAManager;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.VideoView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.VersionAO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;

public class SplashActivity extends ElderlyActivity {
	private static final String TAG = "SplashActivity";

	private View mImgV01;
	private View mImgV02;
	private View mImgV03;
	private VideoView mVideoView;
	private View mLayerBg;

	private static int ANIM_ACTION_ONE = 1;
	private static int ANIM_ACTION_TWO = 2;
	private static int ANIM_ACTION_THREE = 3;
	private static int ANIM_ACTION_END = 4;

	public static final int ANIM_DELAY = 800;

	private VersionAO mVersionAO;
	private boolean mCallingApi = false;
	private boolean mNeedToUpdate = false;// 控制进不进app
	private boolean mTest = false;

	private int mVideoId;
	private boolean isEnable = false;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		getElderlyApplication().setLeaveSplashActivity(false);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.page_splash);
		mImgV01 = findViewById(R.id.page_splash_mImgV01);
		mImgV02 = findViewById(R.id.page_splash_mImgV02);
		mImgV03 = findViewById(R.id.page_splash_mImgV03);
		mVideoView = (VideoView) findViewById(R.id.page_splash_mVideoView);
		mLayerBg = findViewById(R.id.page_splash_mLayerWhitePanel);
		mVideoView.setOnCompletionListener(new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer mp) {
				callApi();
			}
		});
		mVideoView.setOnErrorListener(new OnErrorListener() {

			@Override
			public boolean onError(MediaPlayer mp, int what, int extra) {
				callApi();
				return false;
			}
		});
		mVideoView.setOnPreparedListener(new OnPreparedListener() {

			@Override
			public void onPrepared(MediaPlayer mp) {
				isEnable = true;
				mVideoView.setVisibility(View.VISIBLE);
				mLayerBg.postDelayed(new Runnable() {

					@Override
					public void run() {
						mLayerBg.setVisibility(View.GONE);
						mVideoView.start();

					}
				}, 500);
			}
		});
		mVideoId = R.raw.splash_screen_480_800;
		if (getResources().getDisplayMetrics().widthPixels >= 800) {
			mVideoId = R.raw.splash_screen_800_1280;
		} else if (getResources().getDisplayMetrics().widthPixels >= 720) {
			mVideoId = R.raw.splash_screen_720_1280;
		}
		mVideoView.setVideoURI(Uri.parse("android.resource://com.elderly.elderly/" + mVideoId));
		if (mTest) {
			goToMainPage();
			return;
		}
		mVideoView.setZOrderOnTop(false);
		mVideoView.getHolder().setFormat(PixelFormat.TRANSPARENT);
		mVideoView.start();

		GAManager.getInstance().trackView(Constants.SPLASH_SCREEN);
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (!mVideoView.isPlaying() && isEnable) {
			mVideoView.start();
		}
		// if (mVersionAO != null && !mNeedToUpdate && !mCallingApi) {
		// clearHandlerMsg();
		// mHandler.sendEmptyMessage(ANIM_ACTION_ONE);
		// }
	}

	public void callApi() {
		if (!mCallingApi) {
			mCallingApi = true;
			mNeedToUpdate = false;
			new ElderlyAsyncTask<Void, Void, Void>(this) {

				@Override
				protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
					try {
						mVersionAO = ApiManager.getInstance().getVersion();
						// Log.i("SplashActivity", mVersionAO.getLink());
					} catch (Exception e) {
						mVersionAO = null;
						e.printStackTrace();
					}
					mCallingApi = false;
					return null;
				}

				@Override
				protected void doOnSuccess(Void result) {
					mCallingApi = false;
					if (mVersionAO != null) {
						try {
							checkVersion();
							if (!mNeedToUpdate) {
								goToMainPage();
								// clearHandlerMsg();
								// mHandler.sendEmptyMessage(ANIM_ACTION_ONE);
							}
						} catch (NameNotFoundException e) {
							e.printStackTrace();
						}
					} else {
						Dialog dialog=ElderlyUtil.showElderlyDialog(SplashActivity.this, R.string.common_dialog_title, 0,
								R.string.common_network_failure,
								R.string.common_retry, R.string.common_offline_model, new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog, int which) {
										callApi();

									}
								}, new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog, int which) {
										goToMainPage();
									}
								});
						dialog.setOnKeyListener(new OnKeyListener() {
							
							@Override
							public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
								if(keyCode==KeyEvent.KEYCODE_BACK){
									return true;
								}
								return false;
							}
						});
					}

				}

			}.execute((Void) null);
		}
	}

	// 检测更新，提示用户选择
	protected void checkVersion() throws NameNotFoundException {
		mNeedToUpdate = false;
		if (mVersionAO.getLink() != null && mVersionAO.getVersionNum() != null) {
			PackageManager pm = this.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(this.getPackageName(), 0);
			if (!pi.versionName.equals(mVersionAO.getVersionNum())) {
				// 版本不一样，提示
				mNeedToUpdate = true;
				Dialog dialog=ElderlyUtil.showElderlyDialog(SplashActivity.this, R.string.common_dialog_title, 0,
						getString(R.string.tip_need_update, mVersionAO.getVersionNum(), pi.versionName),
						R.string.common_update, R.string.common_no_thanks, new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog, int which) {
								// 更新
								Intent intent = new Intent();
								intent.setData(Uri.parse(mVersionAO.getLink()));
								startActivity(intent);
							}
						}, new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog, int which) {
								// 进app
								// clearHandlerMsg();
								// mHandler.sendEmptyMessage(ANIM_ACTION_ONE);
								goToMainPage();
							}
						});
				dialog.setOnKeyListener(new OnKeyListener() {
					
					@Override
					public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
						if(keyCode==KeyEvent.KEYCODE_BACK){
							return true;
						}
						return false;
					}
				});
			}
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
		// clearHandlerMsg();
		if (mVideoView.isPlaying()) {
			mVideoView.pause();
		}
	};

	private void clearHandlerMsg() {
		if (mHandler != null) {
			mHandler.removeMessages(ANIM_ACTION_END);
			mHandler.removeMessages(ANIM_ACTION_ONE);
			mHandler.removeMessages(ANIM_ACTION_TWO);
			mHandler.removeMessages(ANIM_ACTION_THREE);
		}
	}

	private Runnable mSleepRunnable = new Runnable() {

		@Override
		public void run() {
			goToMainPage();
		}
	};;

	private void goToMainPage() {
		Intent intent = new Intent(SplashActivity.this, MainActivity.class);
		startActivity(intent);
		SplashActivity.this.finish();
		getElderlyApplication().setLeaveSplashActivity(true);
	}

	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == ANIM_ACTION_ONE) {
				mImgV01.setVisibility(View.VISIBLE);
				mImgV02.setVisibility(View.GONE);
				mImgV03.setVisibility(View.GONE);
				sendEmptyMessageDelayed(ANIM_ACTION_TWO, ANIM_DELAY);
			} else if (msg.what == ANIM_ACTION_TWO) {
				Animation fadeOut = AnimationUtils.loadAnimation(SplashActivity.this, R.anim.fade_out);
				Animation fadeIn = AnimationUtils.loadAnimation(SplashActivity.this, R.anim.fade_in);
				mImgV01.setVisibility(View.VISIBLE);
				mImgV02.setVisibility(View.VISIBLE);
				mImgV03.setVisibility(View.GONE);
				mImgV01.clearAnimation();
				mImgV02.clearAnimation();
				mImgV01.startAnimation(fadeOut);
				mImgV02.startAnimation(fadeIn);
				fadeIn.setAnimationListener(new AnimationListener() {

					@Override
					public void onAnimationStart(Animation animation) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onAnimationRepeat(Animation animation) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onAnimationEnd(Animation animation) {
						mImgV01.setVisibility(View.GONE);
						mImgV02.setVisibility(View.VISIBLE);
						mImgV03.setVisibility(View.GONE);
						sendEmptyMessageDelayed(ANIM_ACTION_THREE, ANIM_DELAY);
					}
				});
			} else if (msg.what == ANIM_ACTION_THREE) {
				Animation fadeOut = AnimationUtils.loadAnimation(SplashActivity.this, R.anim.fade_out);
				Animation fadeIn = AnimationUtils.loadAnimation(SplashActivity.this, R.anim.fade_in);
				mImgV01.setVisibility(View.GONE);
				mImgV02.setVisibility(View.VISIBLE);
				mImgV03.setVisibility(View.VISIBLE);
				mImgV03.clearAnimation();
				mImgV02.clearAnimation();
				mImgV02.startAnimation(fadeOut);
				mImgV03.startAnimation(fadeIn);
				fadeIn.setAnimationListener(new AnimationListener() {

					@Override
					public void onAnimationStart(Animation animation) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onAnimationRepeat(Animation animation) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onAnimationEnd(Animation animation) {
						mImgV01.setVisibility(View.GONE);
						mImgV02.setVisibility(View.GONE);
						mImgV03.setVisibility(View.VISIBLE);
						sendEmptyMessageDelayed(ANIM_ACTION_END, ANIM_DELAY);
					}
				});
			} else if (msg.what == ANIM_ACTION_END) {
				postDelayed(mSleepRunnable, ANIM_DELAY);
			}
		}
	};
	
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		return false;
	}
}
