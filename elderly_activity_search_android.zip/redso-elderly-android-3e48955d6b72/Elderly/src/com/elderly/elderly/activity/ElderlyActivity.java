package com.elderly.elderly.activity;

import com.elderly.elderly.ElderlyApplication;
import com.gt.cl.util.CLLog;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class ElderlyActivity extends FragmentActivity {
	private static final String TAG="ElderlyActivity";
	@Override
	protected void onResume() {
		super.onResume();
		getElderlyApplication().updateLanguage(this);
		getElderlyApplication().updateFontSize(this);
	}

	public ElderlyApplication getElderlyApplication() {
		return (ElderlyApplication) getApplication();
	}
	
	public boolean hideKeyBoard() {
		if (getCurrentFocus() != null&& getCurrentFocus() instanceof EditText) {
			((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
					.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
			getCurrentFocus().clearFocus();
			return true;
		} else {
			InputMethodManager imm=((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
			if(imm!=null&&imm.isActive()&&getCurrentFocus()!=null){
				imm.hideSoftInputFromInputMethod(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
			}
			CLLog.v(TAG, "hideKeyBoard>>getCurrentFocus()==null");
			return false;

		}
	}
}
