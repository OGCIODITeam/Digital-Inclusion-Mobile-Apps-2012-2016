package com.elderly.elderly.activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;

import com.elderly.elderly.R;
import com.elderly.elderly.fragment.NavigationFragment;
import com.elderly.elderly.fragment.main.MainFragment;
import com.elderly.elderly.util.ElderlyUtil;

public class MainActivity extends ElderlyActivity {
    private ActivityResultListener mActivityResultListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_main);
        if (savedInstanceState == null) {
            getNavigationFragment().setRootFragment(new MainFragment());
        }
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        Log.i("mainAc", "onKeyUp");
        if (keyCode == KeyEvent.KEYCODE_ENTER) {
            hideKeyBoard();
        } else if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (hideKeyBoard()) {

            } else if (!getNavigationFragment().getCurrentFragment().onKeyUp(keyCode, event)) {
                if (!getNavigationFragment().popFragment()) {
                    showExitDialog();
                }
            }
            return true;
        } else if (getNavigationFragment().getCurrentFragment().onKeyUp(keyCode, event)) {
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    public NavigationFragment getNavigationFragment() {
        return (NavigationFragment) getSupportFragmentManager().findFragmentById(R.id.page_main_mTabNavigationFragment);
    }

    public void showExitDialog() {
        ElderlyUtil.showElderlyDialog(this, R.string.common_dialog_title, R.drawable.icon_app, R.string.common_exit_app,
                R.string.common_cancel, R.string.common_exit, null, new OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        // CLBitmapLoader.getInstance().getBitmapCache().destory();
                        System.exit(0);
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mActivityResultListener != null) {
            mActivityResultListener.onMainActivityResult(requestCode, resultCode, data);
        }
    }

    public void setActivityResultListener(ActivityResultListener mActivityResultListener) {
        this.mActivityResultListener = mActivityResultListener;
    }

    public interface ActivityResultListener {
        public void onMainActivityResult(int requestCode, int resultCode, Intent data);
    }

}
