package com.elderly.elderly.anim;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Animation;
import android.view.animation.Transformation;

/**
 * Class for handling collapse and expand animations.
 * @author Esben Gaarsmand
 *
 */
public class MarginTopAnimation extends Animation {
    private View mAnimatedView;
    private int toMarginTop;
    private int startMarginTop;
    private ViewGroup.MarginLayoutParams lp;

    /**
     * Initializes expand collapse animation. If the passed view is invisible/gone the animation will be a drop down, 
     * if it is visible the animation will be collapse from bottom
     * @param view The view to animate
     * @param duration
     */ 
    public MarginTopAnimation(ViewGroup view, int duration,int toMarginTop) {
        setDuration(duration);
        mAnimatedView = view;
        this.toMarginTop=toMarginTop;
        if(mAnimatedView!=null&&mAnimatedView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){
        	lp=(MarginLayoutParams) mAnimatedView.getLayoutParams();
        	startMarginTop=lp.topMargin;
        }
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        super.applyTransformation(interpolatedTime, t);
        if (interpolatedTime < 1.0f) {
        	if(toMarginTop>=startMarginTop){
        		lp.topMargin=startMarginTop+(int) ((toMarginTop-startMarginTop)*interpolatedTime);
        	}else{
        		lp.topMargin=startMarginTop-(int) ((startMarginTop-toMarginTop)*interpolatedTime);
        	}
        } else {
        	lp.topMargin=toMarginTop;
        }
        mAnimatedView.setLayoutParams(lp);
        mAnimatedView.requestLayout();
    }

}