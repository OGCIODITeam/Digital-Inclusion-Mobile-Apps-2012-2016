package com.elderly.elderly;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;

import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.Constants.FontSize;
import com.elderly.elderly.Constants.Language;
import com.elderly.elderly.ar.SensorUtil;
import com.elderly.elderly.manager.SettingsManager;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.manager.db.DBManager;
import com.elderly.elderly.pojo.ao.GetTokenAO;
import com.facebook.gt.facebook.FacebookManager;
import com.google.android.gcm.GCMRegistrar;
import com.gt.cl.component.imageview.bitmapview.cache.CLDefalutBitmapCache;
import com.gt.cl.component.imageview.bitmapview.download.CLBitmapDownLoadManager;
import com.gt.cl.component.imageview.bitmapview.loader.CLBitmapLoader;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLCrashUtil;
import com.gt.gcm.GCMManager;
import com.gt.lib.twitter.TwitterDialog;

import org.xmlpull.v1.XmlPullParserException;

import java.util.Locale;

import lib.gt.ga.v2.GAManager;

public class ElderlyApplication extends Application {
    private static final String TAG = "ElderlyApplication";
    private LanguageChangeListener mLanguageChangeListener;
    private FontSizeChangeListener mFontSizeChangeListener;
    private SharedPreferences mDefaultSharedPreferences;
    private static final String DEFAULT_SHARE_PREFERENCES_NAME = "Elderly.sp";
    private String mRegisterToken;
    private boolean mIsCallGetTokenApi = false;
    private boolean mLeaveSplashActivity = false;
    ;
    public static String APP_NAME = "Elderly";
    public static ElderlyApplication me;

    @Override
    public void onCreate() {
        super.onCreate();
        me = this;
        mLeaveSplashActivity = false;
        mIsCallGetTokenApi = false;
        mDefaultSharedPreferences = getSharedPreferences(DEFAULT_SHARE_PREFERENCES_NAME, MODE_WORLD_WRITEABLE);
        SensorUtil.init(this);
        CLCrashUtil.getInstance().init(this);
        // init Bitmap manager
        CLBitmapDownLoadManager.getInstance().setContext(this);
        CLBitmapLoader.getInstance().setContext(this, 0);
        CLBitmapLoader.getInstance().setBitmapCache(CLDefalutBitmapCache.getInstance());

        ApiManager.init(this);

        SettingsManager.init(this);
        // init language
        String settingsLanguage = SettingsManager.getInstance().getLanguageFromSettings();
        if (settingsLanguage == null) {
            loadLanguageFromCurrentLocale();
        } else {
            Language.CurrentLanguage = Language.valueOf(settingsLanguage);
        }
        updateLanguage(this);
        // init font size
        String fontSize = SettingsManager.getInstance().getFontSizeFromSettings();
        if (fontSize == null) {
            FontSize.CurrentFontSize = FontSize.Normal;
        } else {
            FontSize.CurrentFontSize = FontSize.valueOf(fontSize);
        }
        // init color theme
        String colorTheme = SettingsManager.getInstance().getColorThemeFromSettings();
        if (colorTheme == null) {
            ColorTheme.CurrentColorTheme = ColorTheme.ColorTheme1;
        } else {
            ColorTheme.CurrentColorTheme = ColorTheme.valueOf(colorTheme);
        }
        updateFontSize(this);
        UserProfileManager.init(this);
        DBManager.init(this);
        initGcmFun();
        FacebookManager.init(this, Constants.FACEBOOK_ID);
        FacebookManager.setResIdTextLoading(R.string.facebook_login_loading);
        TwitterDialog.setResIdDialogMessage(R.string.common_loading);
        com.gt.lib.twitter.ResourceManager.anim_progressLoading = R.anim.dialog_progress_loading;
        com.gt.lib.twitter.ResourceManager.drawable_close = R.drawable.close;
        com.gt.lib.twitter.ResourceManager.drawable_dialogBackground = R.drawable.dialog_bg;
        com.gt.lib.twitter.ResourceManager.id_dialogIcon = R.id.icon;
        com.gt.lib.twitter.ResourceManager.id_dialogMessage = R.id.message;
        com.gt.lib.twitter.ResourceManager.layout_progressDialog = R.layout.dialog_progress;

        GAManager.init(getApplicationContext(), Constants.GOOGLE_ANALYTICS_TRACKING_ID);
        GAManager.getInstance().enableReportUncaughtException();
        GAManager.getInstance().setDebugable(true);
    }

    public interface LanguageChangeListener {
        public void onLanguageUpdate();
    }

    public interface FontSizeChangeListener {
        public void onFontSizeUpdate();
    }

    public void setLanguageChangeListener(LanguageChangeListener mLanguageChangeListener) {
        this.mLanguageChangeListener = mLanguageChangeListener;
    }

    public void updateLanguage(Context context) {
        Resources resource = context.getResources();
        Configuration config = resource.getConfiguration();
        DisplayMetrics dm = resource.getDisplayMetrics();
        // Log.v(TAG,"CurrentLanguage>>"+Language.CurrentLanguage.name());
        if (Language.CurrentLanguage == Language.TranditionalChinese) {
            config.locale = Locale.CHINESE;
        } else {
            config.locale = Locale.CHINA;
        }
        resource.updateConfiguration(config, dm);
        if (mLanguageChangeListener != null) {
            mLanguageChangeListener.onLanguageUpdate();
        }

    }

    public void updateFontSize(Context context) {
        Resources resource = context.getResources();
        Configuration config = resource.getConfiguration();
        DisplayMetrics dm = resource.getDisplayMetrics();
        float fontScale = 1.0f;
        if (FontSize.CurrentFontSize == FontSize.Normal) {
            fontScale = 1.0f;
        } else if (FontSize.CurrentFontSize == FontSize.Small) {
            fontScale = 0.9f;
        } else {
            fontScale = 1.1f;
        }
        config.fontScale = fontScale;
        resource.updateConfiguration(config, dm);

    }

    public void loadLanguageFromCurrentLocale() {
        Locale curLocale = getResources().getConfiguration().locale;
        // Log.i(TAG, "loadLanguageFromCurrentLocale >> " + curLocale);
        if (curLocale.equals(Locale.CHINA) || curLocale.equals(Locale.SIMPLIFIED_CHINESE)) {
            Language.CurrentLanguage = Language.Chinese;
        } else {
            Language.CurrentLanguage = Language.TranditionalChinese;
        }
        SettingsManager.getInstance().saveLanguageToSettings(Language.CurrentLanguage);
    }

    public SharedPreferences getDefaultSharedPreferences() {
        return mDefaultSharedPreferences;
    }

    public void setFontSizeChangeListener(FontSizeChangeListener mFontSizeChangeListener) {
        this.mFontSizeChangeListener = mFontSizeChangeListener;
    }

    public String getRegisterToken() {
        // 兼容每次启动都需要Add Push Notification Info。
        if (mRegisterToken == null || mRegisterToken.trim().equals("")) {
            mRegisterToken = SettingsManager.getInstance().getPropertyForGCMRegisterToken();
        }
        return mRegisterToken;
    }

    public void setRegisterToken(String token) {
        if (token != null && !(token.trim().equals(""))) {
            SettingsManager.getInstance().setPropertyForGCMRegisterToken(token);
        }
        this.mRegisterToken = token;
        sendTokenToServcie();
    }

    private void initGcmFun() {
        // Push notification.
        GCMManager.onCreate(this, Constants.PUSH_NOTIFICATION_SEND_ID);
        GCMRegistrar.checkDevice(this);
        GCMRegistrar.checkManifest(this);
        mRegisterToken = GCMRegistrar.getRegistrationId(this);
        Log.v(TAG, "mRegisterToken>" + mRegisterToken);
        GCMManager.startGetRegisterId();
        sendTokenToServcie();

    }

    private void sendTokenToServcie() {
        if (!mIsCallGetTokenApi) {
            mIsCallGetTokenApi = true;
            new Thread() {

                @Override
                public void run() {
                    super.run();
                    try {
                        if (mRegisterToken != null && !mRegisterToken.equals("")) {
                            GetTokenAO ao = ApiManager.getInstance().sendTokenToService(mRegisterToken);
                            Log.v(TAG, "GetToken result>>" + ao);
                        }

                    } catch (CLConnectionException e) {
                        e.printStackTrace();
                    } catch (CLInvalidNetworkException e) {
                        e.printStackTrace();
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }
                    mIsCallGetTokenApi = false;
                }

            }.start();
        }
    }

    public boolean isLeaveSplashActivity() {
        return mLeaveSplashActivity;
    }

    public void setLeaveSplashActivity(boolean mLeaveSplashActivity) {
        this.mLeaveSplashActivity = mLeaveSplashActivity;
    }


    public void savePref(String pref, String value) {
        Log.d("setp"+"_pref:"+pref,"  _value:"+value);
        SharedPreferences settings = getSharedPreferences(APP_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(pref, value);
        editor.commit();
    }

    public String getPref(String pref) {
        SharedPreferences settings = getSharedPreferences(APP_NAME, 0);

        Log.d("getp"+"_pref:"+pref,"  _value:"+settings.getString(pref, ""));

        return settings.getString(pref, "");
    }

}
