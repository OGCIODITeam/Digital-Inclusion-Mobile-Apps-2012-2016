package com.elderly.elderly.fragment.profile;

import java.util.List;

import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlySimpleEditTextView;
import com.elderly.elderly.component.ElderlySimpleEditTextView.OnSimpleTextChangeListener;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.elderly.elderly.util.ElderlyUtil;

public class ProfileMyCommunityFragment extends TempleteFragment {
	private static final String TAG = "ProfileMyCommunityFragment";
	public static final String KEY_STORE_INDEX = "key_store_index";
	private ElderlySimpleEditTextView mTxtMyCommunity1;
	private ElderlySimpleEditTextView mTxtMyCommunity2;
	private ElderlySimpleEditTextView mTxtMyCommunity3;
	private View mLayerSumbit;
	private FrameLayout mOverView;
	private List<CommunityCentreAO> mMyCommunityCentres;
	String tempMyCommunityCenter1 = "";
	String tempMyCommunityCenter2 = "";
	String tempMyCommunityCenter3 = "";
	CommunityCentreAO ao1;
	CommunityCentreAO ao2;
	CommunityCentreAO ao3;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		setTitle(R.string.header_my_community);
		setHeaderBgColor(R.color.header_ProfileSetting);
		inflater.inflate(R.layout.page_profile_my_community, mLayerContextView);
		mTxtMyCommunity1 = (ElderlySimpleEditTextView) mLayerContextView.findViewById(R.id.page_profile_my_community_mTxtMyCommunity1);
		mTxtMyCommunity2 = (ElderlySimpleEditTextView) mLayerContextView.findViewById(R.id.page_profile_my_community_mTxtMyCommunity2);
		mTxtMyCommunity3 = (ElderlySimpleEditTextView) mLayerContextView.findViewById(R.id.page_profile_my_community_mTxtMyCommunity3);

		mTxtMyCommunity1.setHint(R.string.profile_input_hint_choice_my_community);
		mTxtMyCommunity2.setHint(R.string.profile_input_hint_choice_my_community);
		mTxtMyCommunity3.setHint(R.string.profile_input_hint_choice_my_community);

		mTxtMyCommunity1.changeStyle();
		mTxtMyCommunity2.changeStyle();
		mTxtMyCommunity3.changeStyle();
		mTxtMyCommunity1.setEdittextFocusable(false);
		mTxtMyCommunity2.setEdittextFocusable(false);
		mTxtMyCommunity3.setEdittextFocusable(false);
		mLayerSumbit = mLayerContextView.findViewById(R.id.page_profile_my_community_mLayerConfirm);
		setupCommonBtnBgColor(mLayerSumbit, R.color.header_ProfileSetting);
		setupData();
		setupListener();
	}

	private void setupData() {
		mMyCommunityCentres = UserProfileManager.getInstance().readMyCommunityCentre();
		if (mMyCommunityCentres != null) {
			Log.v(TAG, "mMyCommunityCentres>>" + mMyCommunityCentres.size());
			for (int i = 0; i < mMyCommunityCentres.size(); i++) {
				CommunityCentreAO ao = mMyCommunityCentres.get(i);
				Log.v(TAG, "CommunityCentreAO>>" + ao);
				String tempMyCommunityCenter = "";
				if ("".equals(ao.getFieldElderlyOrganizationValue())) {
					tempMyCommunityCenter = ao.getFieldElderlyCentreValue();
				} else if ("".equals(ao.getFieldElderlyCentreValue())) {
					tempMyCommunityCenter = ao.getFieldElderlyOrganizationValue();
				} else {
					tempMyCommunityCenter = ao.getFieldElderlyOrganizationValue() + "\n" + ao.getFieldElderlyCentreValue();
				}
				if (ao.getIndex() == 0) {
					ao1 = ao;
					tempMyCommunityCenter1 = tempMyCommunityCenter;
					mTxtMyCommunity1.setText(tempMyCommunityCenter1);
				} else if (ao.getIndex() == 1) {
					ao2 = ao;
					tempMyCommunityCenter2 = tempMyCommunityCenter;
					mTxtMyCommunity2.setText(tempMyCommunityCenter2);
				} else if (ao.getIndex() == 2) {
					ao3 = ao;
					tempMyCommunityCenter3 = tempMyCommunityCenter;
					mTxtMyCommunity3.setText(tempMyCommunityCenter3);
				}
			}
		}

	}

	@Override
	public void onResume() {
		super.onResume();
		mTxtMyCommunity1.getSimpleEditText().setText(tempMyCommunityCenter1);
		mTxtMyCommunity2.getSimpleEditText().setText(tempMyCommunityCenter2);
		mTxtMyCommunity3.getSimpleEditText().setText(tempMyCommunityCenter3);
	}

	private void setupListener() {
		mLayerSumbit.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

			@Override
			public void onGlobalLayout() {
				mLayerSumbit.getViewTreeObserver().removeGlobalOnLayoutListener(this);
				if (UserProfileManager.getInstance().isNeedShowUserCommunityDetailPart1Tip()) {
					showPart1Tip();
				} else if (UserProfileManager.getInstance().isNeedShowUserCommunityDetailPart2Tip()) {
					showPart2Tip(false);
				}
			}
		});
		mLayerSumbit.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				getTabNavigationFragment().pop();

			}
		});
		mTxtMyCommunity1.getSimpleEditText().setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				ProfileSearchCommunityFragment pscf = new ProfileSearchCommunityFragment();
				Bundle bundle = new Bundle();
				pscf.setArguments(bundle);
				bundle.putInt(KEY_STORE_INDEX, 0);
				getTabNavigationFragment().push(pscf);
				UserProfileManager.getInstance().alReadlyShowUserCommunityDetailPart2Tip();
			}
		});

		mTxtMyCommunity2.getSimpleEditText().setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				ProfileSearchCommunityFragment pscf = new ProfileSearchCommunityFragment();
				Bundle bundle = new Bundle();
				bundle.putInt(KEY_STORE_INDEX, 1);
				pscf.setArguments(bundle);
				getTabNavigationFragment().push(pscf);
			}
		});

		mTxtMyCommunity3.getSimpleEditText().setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				ProfileSearchCommunityFragment pscf = new ProfileSearchCommunityFragment();
				Bundle bundle = new Bundle();
				bundle.putInt(KEY_STORE_INDEX, 2);
				pscf.setArguments(bundle);
				getTabNavigationFragment().push(pscf);
			}
		});
		mTxtMyCommunity1.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

			@Override
			public void onSimpleTextChange() {

			}

			@Override
			public void onSimpleClear() {
				UserProfileManager.getInstance().removeOneCommunity(ao1);
			}
		});
		mTxtMyCommunity2.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

			@Override
			public void onSimpleTextChange() {
			}

			@Override
			public void onSimpleClear() {
				UserProfileManager.getInstance().removeOneCommunity(ao2);
			}
		});
		mTxtMyCommunity3.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

			@Override
			public void onSimpleTextChange() {
			}

			@Override
			public void onSimpleClear() {
				UserProfileManager.getInstance().removeOneCommunity(ao3);
			}
		});
	}

	// 添加guidview的圖片指導圖
	private void addGuidView(int marginTop, int resId, int gravity, boolean anim,int which) {
		mOverView = showOverContextView(marginTop, anim);
		mOverView.removeAllViews();
		ImageView sexGuidView = new ImageView(getActivity());
		FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		parms.gravity = gravity;
		parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
		sexGuidView.setImageResource(resId);
		if (which==8) {
			sexGuidView.setContentDescription("提示：请选择你的长者中心（最多可选三个）");
		}else if (which==9) {
			sexGuidView.setContentDescription("提示：请按 选择我的长者中心 键");
		}
		mOverView.addView(sexGuidView, parms);
	}

	private void showPart1Tip() {
		addGuidView(0, Constants.getGuide(8), Gravity.CENTER, false,8);
		UserProfileManager.getInstance().alReadlyShowUserCommunityDetailPart1Tip();
		mOverView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showPart2Tip(true);
			}
		});
	}

	private void showPart2Tip(boolean anim) {
		Rect rect = new Rect();
		mTxtMyCommunity1.getGlobalVisibleRect(rect);
		int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
		addGuidView(sexCoverViewHeight, Constants.getGuide(9), Gravity.TOP | Gravity.CENTER_HORIZONTAL, anim,9);
	}

	@Override
	public void onDestroyView() {
		mTxtMyCommunity1.release();
		mTxtMyCommunity2.release();
		mTxtMyCommunity3.release();
		mTxtMyCommunity1.setOnSimpleTextChangeListener(null);
		mTxtMyCommunity2.setOnSimpleTextChangeListener(null);
		mTxtMyCommunity3.setOnSimpleTextChangeListener(null);
		super.onDestroyView();
	}
}
