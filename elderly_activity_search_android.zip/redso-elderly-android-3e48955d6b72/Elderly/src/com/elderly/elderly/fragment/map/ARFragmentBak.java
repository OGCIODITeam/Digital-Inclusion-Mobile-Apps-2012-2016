package com.elderly.elderly.fragment.map;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.elderly.elderly.R;
import com.elderly.elderly.ar.SensorUtil;
import com.elderly.elderly.fragment.templete.TempleteFragment;

public class ARFragmentBak extends TempleteFragment {

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		showBackBtn(true);
		hideRightBtn();
		setTitle(R.string.page_googlemap_ar);
		inflater.inflate(R.layout.page_ar, mLayerContextView);
	}
	
	@Override
	public void onResume() {
		super.onResume();
	}
	
	@Override
	public void onStop() {
		super.onStop();
	}

}
