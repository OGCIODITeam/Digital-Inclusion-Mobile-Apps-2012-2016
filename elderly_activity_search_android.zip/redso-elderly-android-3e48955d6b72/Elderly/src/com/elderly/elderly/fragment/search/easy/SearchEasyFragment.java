package com.elderly.elderly.fragment.search.easy;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;

import com.elderly.elderly.Constants;
import com.elderly.elderly.ElderlyApplication;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.SearchEasyActivityTypeAdapter;
import com.elderly.elderly.adapter.SearchEasyDistrictAdapter;
import com.elderly.elderly.adapter.SearchEasyMonthAdapter;
import com.elderly.elderly.adapter.SearchEasyRegionAdapter;
import com.elderly.elderly.component.ElderlySelectGallery;
import com.elderly.elderly.fragment.search.SearchResultFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.SettingsManager;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.DateAO;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.pojo.po.UserProfilePo;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

import org.xmlpull.v1.XmlPullParserException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import lib.gt.ga.v2.GAManager;

public class SearchEasyFragment extends TempleteFragment {
    private static final String TAG = "SearchEasyFragment";
    private ElderlySelectGallery mGalleryActivityType;
    private ElderlySelectGallery mGalleryDistrict;
    private ElderlySelectGallery mGalleryRegion;
    private ElderlySelectGallery mGalleryMonth;
    private SearchEasyDistrictAdapter mDistrictAdapter;
    private SearchEasyRegionAdapter mRegionAdapter;
    private View mLayerSearch;
    private String tempDistrict;
    private UserProfilePo user;
    private List<ActivityCategoryPo> tempActivityCategoryPos;
    private List<DateAO> mDatesL;// 康文署
    private List<DateAO> mDatesE;// 長者中心活動
    private boolean mCallApiing;
    private String dateCurrentMonth;
    private String eventType;
    private String activityArea;
    private String dateL;// 顯示康文署
    private String dateE;// 顯示中心活動
    private int currentMonth;
    // private Time time;
    private boolean isFirst = true;
    private ElderlyAsyncTask mAsyncTask;
    View view;

    Button mButtonActivity;
    Button mButtonDistrict;
    Button mButtonRegion;
    Button mButtonMonth;

    boolean horizontalMode;

    ArrayList<String> tempActLists, tempDistrictLists, tempRegionLists, tempMonthLists;

    String tempActName, tempDistrsictName, tempRegionName, tempMonthName;
    int tempActIndex, tempDistrsictIndex, tempRegionIndex, tempMonthIndex;

    @Override
    public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
        inflater.inflate(R.layout.page_search_easy, mLayerContextView);
        setTitle(R.string.header_search_easy);
        if (SettingsManager.getInstance().getSearchModeSettings() != null) {
            horizontalMode = SettingsManager.getInstance().getSearchModeSettings().toString().equals("Horizontal") ? true : false;
        } else {
            horizontalMode = false;
        }

        mGalleryActivityType = (ElderlySelectGallery) mLayerContextView.findViewById(R.id.page_search_easy_mGalleryActivityType);
        mGalleryDistrict = (ElderlySelectGallery) mLayerContextView.findViewById(R.id.page_search_easy_mGalleryDistrict);
        mGalleryRegion = (ElderlySelectGallery) mLayerContextView.findViewById(R.id.page_search_easy_mGalleryRegion);
        mGalleryMonth = (ElderlySelectGallery) mLayerContextView.findViewById(R.id.page_search_easy_mGalleryMonth);

        mButtonActivity = (Button) mLayerContextView.findViewById(R.id.page_search_easy_mButtonActivityType);
        mButtonDistrict = (Button) mLayerContextView.findViewById(R.id.page_search_easy_mButtonDistrictType);
        mButtonRegion = (Button) mLayerContextView.findViewById(R.id.page_search_easy_mButtonRegionType);
        mButtonMonth = (Button) mLayerContextView.findViewById(R.id.page_search_easy_mButtonMonthType);

        if (!horizontalMode) {
            mGalleryActivityType.setVisibility(View.GONE);
            mGalleryDistrict.setVisibility(View.GONE);
            mGalleryRegion.setVisibility(View.GONE);
            mGalleryMonth.setVisibility(View.GONE);

            mButtonActivity.setVisibility(View.VISIBLE);
            mButtonDistrict.setVisibility(View.VISIBLE);
            mButtonRegion.setVisibility(View.VISIBLE);
            mButtonMonth.setVisibility(View.VISIBLE);
            setupButtonData();
        } else {
            mGalleryActivityType.setVisibility(View.VISIBLE);
            mGalleryDistrict.setVisibility(View.VISIBLE);
            mGalleryRegion.setVisibility(View.VISIBLE);
            mGalleryMonth.setVisibility(View.VISIBLE);

            mButtonActivity.setVisibility(View.GONE);
            mButtonDistrict.setVisibility(View.GONE);
            mButtonRegion.setVisibility(View.GONE);
            mButtonMonth.setVisibility(View.GONE);
            setupGalleryData();
        }


        mLayerSearch = mLayerContextView.findViewById(R.id.page_search_easy_mLayerSearch);
        view = mLayerContextView;
        setupCommonBtnBgColor(mLayerSearch, getSchemeColorId());

        GAManager.getInstance().trackView(Constants.EASY_PG_EASYSEARCH);
    }


    private void setupButtonData() {
        Log.d("setupButtonData", "setupButtonData");
        user = UserProfileManager.getInstance().getUserProfile();

        tempActivityCategoryPos = UserProfileManager.getInstance().getAllInterestList();

        tempActLists = new ArrayList<String>();
        for (int i = 0; i < tempActivityCategoryPos.size(); i++) {
            tempActLists.add(tempActivityCategoryPos.get(i).getName());

        }
        tempActName = tempActivityCategoryPos.get(0).getName();
        mButtonActivity.setText(tempActName);
        tempActIndex = 0;

        final List<DistrictPo> tempDistrictPos = UserProfileManager.getInstance().getDistrictPoList();
        tempDistrictLists = new ArrayList<String>();
        for (int i = 0; i < tempDistrictPos.size(); i++) {
            tempDistrictLists.add(tempDistrictPos.get(i).getName());

        }
        tempDistrict = tempDistrictPos.get(0).getKey();
        tempDistrsictName = tempDistrictPos.get(0).getName();
        mButtonDistrict.setText(tempDistrsictName);
        tempDistrsictIndex = 0;


        tempMonthLists = new ArrayList(Arrays.asList(getActivity().getResources().getStringArray(R.array.month)));

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {

                if (isFirst) {
                    Log.d("setupButtonData", "isFirst");

                    tempActivityCategoryPos = UserProfileManager.getInstance().getMyInterestList();
                    ElderlyApplication.me.savePref("easysearch_act", 0 + "");
                    ActivityCategoryPo tempActivityCategoryPo = null;
                    if (tempActivityCategoryPos != null && tempActivityCategoryPos.size() > 0) {
                        tempActivityCategoryPo = tempActivityCategoryPos.get(0);
                        tempActName = tempActivityCategoryPos.get(0).getName();
                        mButtonActivity.setText(tempActName);
                        tempActIndex = 0;
                        ElderlyApplication.me.savePref("easysearch_act", 0 + "");
                    }


                    mButtonDistrict.setText(tempDistrictPos.get(0).getName());
                    ElderlyApplication.me.savePref("easysearch_dist", 0 + "");
                    if (user.getDistrict() != null) {
                        for (int i = 0; i < tempDistrictPos.size(); i++) {

                            if (user.getDistrict().equals(tempDistrictPos.get(i).getKey())) {

                                tempDistrict = tempDistrictPos.get(i).getKey();
                                tempDistrsictName = tempDistrictPos.get(i).getName();
                                mButtonDistrict.setText(tempDistrsictName);
                                tempDistrsictIndex = i;
                                ElderlyApplication.me.savePref("easysearch_dist", i + "");
                                Log.i(TAG, "i>>>>>>tempDistrictPos" + i);
                                break;
                            }
                        }
                    }


                    List<LocationPo> tempLocationPos = UserProfileManager.getInstance().getRegionList(tempDistrict);

                    tempRegionLists = new ArrayList<String>();
                    if (tempLocationPos != null) {
                        for (int i = 0; i < tempLocationPos.size(); i++) {
                            tempRegionLists.add(tempLocationPos.get(i).getName());

                        }
                    }


                    tempRegionName = tempLocationPos.get(0).getName();
                    tempRegionIndex = 0;
                    mButtonRegion.setText(tempRegionName);
                    ElderlyApplication.me.savePref("easysearch_region", 0 + "");
                    for (int i = 0; i < tempLocationPos.size(); i++) {
                        if (user.getRegion() != null) {
                            if (user.getRegion().equals(tempLocationPos.get(i).getKey())) {
                                tempRegionName = tempLocationPos.get(i).getName();
                                ElderlyApplication.me.savePref("easysearch_region", i + "");
                                tempRegionIndex = i;
                                mButtonRegion.setText(tempRegionName);
                                break;
                            }
                        }

                    }

                    currentMonth = Calendar.getInstance().get(Calendar.MONTH);
                    ElderlyApplication.me.savePref("easysearch_month", currentMonth + "");

                    tempMonthName = tempMonthLists.get(currentMonth);
                    tempMonthIndex = currentMonth;
                    mButtonMonth.setText(tempMonthName);

                    isFirst = false;
                } else {
                    Log.d("setupButtonData", "!isFirst");

                    if (ElderlyApplication.me.getPref("easysearch_act") != null) {


                        tempActIndex = Integer.valueOf(ElderlyApplication.me.getPref("easysearch_act"));

                        tempMonthName = tempActivityCategoryPos.get(tempActIndex).getName();
                        mButtonActivity.setText(tempMonthName);

                    }
                    if (ElderlyApplication.me.getPref("easysearch_month") != null) {
                        tempMonthIndex = Integer.valueOf(ElderlyApplication.me.getPref("easysearch_month"));
                        tempMonthName = tempMonthLists.get(tempMonthIndex);
                        mButtonMonth.setText(tempMonthName);
                    }
                    if (ElderlyApplication.me.getPref("easysearch_dist") != null) {
                        tempDistrsictIndex = Integer.valueOf(ElderlyApplication.me.getPref("easysearch_dist"));
                        tempDistrict = tempDistrictPos.get(tempDistrsictIndex).getKey();
                        tempMonthName = tempDistrictPos.get(tempDistrsictIndex).getName();
                        mButtonDistrict.setText(tempMonthName);

                        List<LocationPo> tempLocationPos = UserProfileManager.getInstance().getRegionList(tempDistrict);
                        tempRegionLists = new ArrayList<String>();
                        for (int i = 0; i < tempLocationPos.size(); i++) {
                            tempRegionLists.add(tempLocationPos.get(i).getName());

                        }
                        tempRegionIndex = Integer.valueOf(ElderlyApplication.me.getPref("easysearch_region"));
                        tempRegionName = tempLocationPos.get(tempRegionIndex).getName();

                        mButtonRegion.setText(tempRegionName);
                    }
                    if (ElderlyApplication.me.getPref("easysearch_region") != null) {
                        tempDistrsictIndex = Integer.valueOf(ElderlyApplication.me.getPref("easysearch_dist"));
                        tempDistrict = tempDistrictPos.get(tempDistrsictIndex).getKey();
                        tempMonthName = tempDistrictPos.get(tempDistrsictIndex).getName();
                        mButtonDistrict.setText(tempMonthName);

                        List<LocationPo> tempLocationPos = UserProfileManager.getInstance().getRegionList(tempDistrict);
                        tempRegionLists = new ArrayList<String>();
                        for (int i = 0; i < tempLocationPos.size(); i++) {
                            tempRegionLists.add(tempLocationPos.get(i).getName());

                        }
                        tempRegionIndex = Integer.valueOf(ElderlyApplication.me.getPref("easysearch_region"));
                        tempRegionName = tempLocationPos.get(tempRegionIndex).getName();

                        mButtonRegion.setText(tempRegionName);
                    }


                }

                setupListener();

            }


        }, 200);


        mButtonDistrict.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                goSearchOptionList(tempDistrictLists, Integer.valueOf(ElderlyApplication.me.getPref("easysearch_dist")), getActivity().getString(R.string.header_search_district));
            }
        });
        mButtonActivity.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                goSearchOptionList(tempActLists, Integer.valueOf(ElderlyApplication.me.getPref("easysearch_act")), getActivity().getString(R.string.header_search_interest));
            }
        });
        mButtonRegion.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                goSearchOptionList(tempRegionLists, Integer.valueOf(ElderlyApplication.me.getPref("easysearch_region")), getActivity().getString(R.string.header_search_region));
            }
        });
        mButtonMonth.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                goSearchOptionList(tempMonthLists, Integer.valueOf(ElderlyApplication.me.getPref("easysearch_month")), getActivity().getString(R.string.header_search_month));
            }
        });
    }


    private void setupGalleryData() {
        Log.d("setupGalleryData", "setupGalleryData");
        user = UserProfileManager.getInstance().getUserProfile();
        mGalleryActivityType.setSelectIcon(R.drawable.area_selected01);
        mGalleryDistrict.setSelectIcon(R.drawable.area_selected02);
        mGalleryRegion.setSelectIcon(R.drawable.area_selected02);
        mGalleryMonth.setSelectIcon(R.drawable.area_selected03);
        mGalleryActivityType.setUnselectedAlpha(1f);
        mGalleryDistrict.setUnselectedAlpha(1f);
        mGalleryRegion.setUnselectedAlpha(1f);
        mGalleryMonth.setUnselectedAlpha(1f);
        // 解决进入的时候读主页全部的语音问题
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                mGalleryActivityType.setAdapter(new SearchEasyActivityTypeAdapter(getActivity()));
                mGalleryMonth.setAdapter(new SearchEasyMonthAdapter(getActivity()));


                mRegionAdapter = new SearchEasyRegionAdapter(getActivity());
                mDistrictAdapter = new SearchEasyDistrictAdapter(getActivity());


                mGalleryDistrict.setAdapter(mDistrictAdapter);
                mGalleryRegion.setAdapter(mRegionAdapter);

                tempActivityCategoryPos = UserProfileManager.getInstance().getMyInterestList();

                if (isFirst) {
                    Log.d("setupGalleryData", "isFirst");
                    ActivityCategoryPo tempActivityCategoryPo = null;
                    if (tempActivityCategoryPos != null && tempActivityCategoryPos.size() > 0) {
                        tempActivityCategoryPo = tempActivityCategoryPos.get(0);
                    }


                    tempActivityCategoryPos = UserProfileManager.getInstance().getAllInterestList();
                    if (tempActivityCategoryPo != null) {
                        for (int i = 0; i < tempActivityCategoryPos.size(); i++) {
                            if (tempActivityCategoryPo.getKey().equals(tempActivityCategoryPos.get(i).getKey())) {
                                mGalleryActivityType.setSelection(i);
                                Log.i(TAG, "i>>>>>>tempActivityCategoryPos" + i);
                            }
                        }
                    }

                    List<DistrictPo> tempDistrictPos = UserProfileManager.getInstance().getDistrictPoList();
                    tempDistrict= tempDistrictPos.get(0).getKey();
                    tempDistrsictIndex = 0;
                    if (user.getDistrict() != null) {
                        for (int i = 0; i < tempDistrictPos.size(); i++) {
                            if (user.getDistrict().equals(tempDistrictPos.get(i).getKey())) {
                                mGalleryDistrict.setSelection(i);
                                tempDistrict = tempDistrictPos.get(i).getKey();
                                tempDistrsictIndex = i;
                                Log.i(TAG, "i>>>>>>tempDistrictPos" + i);
                                ElderlyApplication.me.savePref("easysearch_dist", i + "");
                                break;
                            }
                        }
                    }


                    List<LocationPo> data = UserProfileManager.getInstance().getRegionList(tempDistrict);
                    mRegionAdapter.setColor(mDistrictAdapter.getItem(tempDistrsictIndex).getKey());
                    mRegionAdapter.setupData(data);
                    List<LocationPo> tempLocationPos = UserProfileManager.getInstance().getRegionList(tempDistrict);
                    mGalleryRegion.setSelection(0);

                    if (user.getRegion() != null) {
                        for (int i = 0; i < tempLocationPos.size(); i++) {
                            if (user.getRegion().equals(tempLocationPos.get(i).getKey())) {
                                Log.i(TAG, "i>>>>>tempLocationPos" + i);
                                mGalleryRegion.setSelection(i);

                                break;
                            }
                        }
                    }

                    currentMonth = Calendar.getInstance().get(Calendar.MONTH);
                    mGalleryMonth.setSelection(currentMonth);
                    isFirst = false;
                } else {
                    Log.d("setupGalleryData", "!isFirst");
                    if (ElderlyApplication.me.getPref("easysearch_act") != null) {
                        mGalleryActivityType.setSelection(Integer.valueOf(ElderlyApplication.me.getPref("easysearch_act")));
                    }
                    if (ElderlyApplication.me.getPref("easysearch_month") != null) {
                        mGalleryMonth.setSelection(Integer.valueOf(ElderlyApplication.me.getPref("easysearch_month")));
                    }
                    if (ElderlyApplication.me.getPref("easysearch_dist") != null) {
                        List<DistrictPo> tempDistrictPos = UserProfileManager.getInstance().getDistrictPoList();
                        tempDistrict = tempDistrictPos.get(Integer.valueOf(ElderlyApplication.me.getPref("easysearch_dist"))).getKey();
                        mGalleryDistrict.setSelection(Integer.valueOf(ElderlyApplication.me.getPref("easysearch_dist")));
                    }
                    if (ElderlyApplication.me.getPref("easysearch_region") != null) {
                        List<DistrictPo> tempDistrictPos = UserProfileManager.getInstance().getDistrictPoList();
                        tempDistrict = tempDistrictPos.get(Integer.valueOf(ElderlyApplication.me.getPref("easysearch_dist"))).getKey();
                        List<LocationPo> data = UserProfileManager.getInstance().getRegionList(tempDistrict);
                        mRegionAdapter.setColor(mDistrictAdapter.getItem(tempDistrsictIndex).getKey());
                        mRegionAdapter.setupData(data);

                        mGalleryRegion.setSelection(Integer.valueOf(ElderlyApplication.me.getPref("easysearch_region")));
                    }

                }
                setupListener();

            }
        }, 200);
    }

    private void goSearchOptionList(ArrayList<String> options, int current, String type) {
        SearchOptionListFragment sopf = new SearchOptionListFragment();
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("options", options);
        bundle.putInt("current", current);
        bundle.putString("type", type);
        sopf.setArguments(bundle);
        getTabNavigationFragment().push(sopf);

    }

    private void setupListener() {
        Log.d("setupListener", "setupListener");

        mGalleryActivityType.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ElderlyApplication.me.savePref("easysearch_act", position + "");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mGalleryMonth.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ElderlyApplication.me.savePref("easysearch_month", position + "");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        mGalleryRegion.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ElderlyApplication.me.savePref("easysearch_region", position + "");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        mGalleryDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Log.v(TAG,"onItemSelected>>"+position);

                if (tempDistrsictIndex != position) {
                    tempDistrsictIndex = position;
                    ElderlyApplication.me.savePref("easysearch_dist", position + "");
                    List<DistrictPo> tempDistrictPos = UserProfileManager.getInstance().getDistrictPoList();
                    tempDistrict = tempDistrictPos.get(position).getKey();

                    List<LocationPo> data = UserProfileManager.getInstance().getRegionList(tempDistrict);
                    mRegionAdapter.setColor(mDistrictAdapter.getItem(tempDistrsictIndex).getKey());
                    mRegionAdapter.setupData(data);

                    mGalleryRegion.setSelection(0);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mLayerSearch.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                GAManager.getInstance().trackEvent(Constants.EASY_SEARCHBUTTON, Constants.GA_ACTION_CLICK, "");
                if (ElderlyUtil.isConnectNetWork(getMainActivity())) {
                    goToSearchResult();
                }

                // callDataListApi();
            }
        });
    }

    private void callDataListApi() {
        if (!mCallApiing) {
            mCallApiing = true;
            mAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity()) {

                @Override
                protected Void doInBackground(Void params) throws CLConnectionException, CLInvalidNetworkException {
                    List<LocationPo> data = UserProfileManager.getInstance().getRegionList(mDistrictAdapter.getItem(mGalleryDistrict.getSelectedItemPosition()).getKey());
                    activityArea = data.get(mGalleryRegion.getSelectedItemPosition()).getValue();
                    dateCurrentMonth = getSearchMonth();
                    Log.i(TAG, "dateCurrentMonth" + dateCurrentMonth);
                    eventType = tempActivityCategoryPos.get(mGalleryActivityType.getSelectedItemPosition()).getNameTc();
                    try {
                        mDatesL = ApiManager.getInstance().getDateList(dateCurrentMonth, eventType, activityArea, null, null, null, null, "L");
                        mDatesE = ApiManager.getInstance().getDateList(dateCurrentMonth, eventType, activityArea, null, null, null, null, "E");
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void doOnSuccess(Void result) {
                    mCallApiing = false;
//                    setDates();
                    goToSearchResult();
                }

                @Override
                protected boolean showCustomLoading() {
                    return true;
                }

                @Override
                protected void callCustomLoading() {
                    showLoadingView();
                }

                @Override
                protected void cancelCustomLoading() {
                    hideLoadingView();
                    super.cancelCustomLoading();
                }

                @Override
                protected void onCancelled() {
                    ApiManager.getInstance().cancelCallDateList();
                    super.onCancelled();
                }
            };
            setCurrentAsyncTask(mAsyncTask);
            mAsyncTask.execute((Void) null);
            ;

        }
    }


    protected void goToSearchResult() {
        SearchResultFragment srf = new SearchResultFragment();
        List<LocationPo> data;
        if (!horizontalMode) {
            data = UserProfileManager.getInstance().getRegionList(tempDistrict);

        } else {
            data = UserProfileManager.getInstance().getRegionList(mDistrictAdapter.getItem(mGalleryDistrict.getSelectedItemPosition()).getKey());
        }

        if (!horizontalMode) {
            activityArea = data.get(tempRegionIndex).getValue();
        } else {
            activityArea = data.get(mGalleryRegion.getSelectedItemPosition()).getValue();
        }
        tempActivityCategoryPos = UserProfileManager.getInstance().getAllInterestList();
        if (!horizontalMode) {
            eventType = tempActivityCategoryPos.get(tempActIndex).getNameTc();
        } else {
            eventType = tempActivityCategoryPos.get(mGalleryActivityType.getSelectedItemPosition()).getNameTc();
        }


        Bundle bundle = new Bundle();
        bundle.putString(HEADER_TYPE, getHeaderType().name());
        bundle.putString(SearchResultFragment.KEY_ACTIVE_AREA, activityArea);
        bundle.putString(SearchResultFragment.KEY_TITLE_NAME, getString(R.string.header_search_result_easy));
        Log.i(TAG, "goToSearchResult>>>>" + activityArea + "..." + eventType + "..." + ElderlyUtil.getCurrentDate() + "..." + dateE + "..." + dateL);
        dateL = getSearchMonthByDate();
        dateE = getSearchMonthByDate();
        if (dateL == null) {
            bundle.putString(SearchResultFragment.KEY_DATE_L, ElderlyUtil.getCurrentDate());
        } else {
            bundle.putString(SearchResultFragment.KEY_DATE_L, dateL);
        }

        if (dateE == null) {
            bundle.putString(SearchResultFragment.KEY_DATE_E, ElderlyUtil.getCurrentDate());
        } else {
            bundle.putString(SearchResultFragment.KEY_DATE_E, dateE);
        }
        bundle.putBoolean(SearchResultFragment.KEY_MONTH_TYPE, true);
        bundle.putString(SearchResultFragment.KEY_EVENT_TYPE, eventType);
        Log.i(TAG, "tempSelectMonth..." + eventType + "..." + activityArea + "" + ElderlyUtil.getCurrentDate() + "..." + dateL + "..." + dateE);
        srf.setArguments(bundle);
        getTabNavigationFragment().push(srf);
    }

    protected String getSearchMonth() {
        String tempMonthString = "";
        // int tempSelectMonth = mGalleryMonth.getSelectedItemPosition();
        // tempSelectMonth += 1;
        // if (currentMonth - tempSelectMonth > 5) {
        // tempMonthString = (time.year + 1) + "-";
        // } else if (currentMonth - tempSelectMonth < -6) {
        // tempMonthString = (time.year - 1) + "-";
        // } else {
        // tempMonthString = (time.year) + "-";
        // }
        // if (tempSelectMonth < 10) {
        // tempMonthString += ("0" + tempSelectMonth);
        // } else {
        // tempMonthString += tempSelectMonth;
        // }
        return tempMonthString;
    }

    protected String getSearchMonthByDate() {
        int tempSelectMonth;
        if (!horizontalMode) {
            tempSelectMonth = tempMonthIndex;
        } else {
            tempSelectMonth = mGalleryMonth.getSelectedItemPosition();
        }

        Calendar calendar = Calendar.getInstance();
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DATE, 1);// 把日期设置为当月第一天
        calendar.set(Calendar.MONTH, getMonth(tempSelectMonth));
        calendar.roll(Calendar.DATE, -1);// 日期回滚一天，也就是最后一天
        int maxDate = calendar.get(Calendar.DATE);
        int currentMonth = calendar.get(Calendar.MONTH);// 0~11 0是一月
        int currentYear = calendar.get(Calendar.YEAR);
        int tmpYear = currentYear;
        if (currentMonth - tempSelectMonth > 5) {
            calendar.set(Calendar.YEAR, currentYear + 1);
        } else if (currentMonth - tempSelectMonth < -6) {
            calendar.set(Calendar.YEAR, currentYear - 1);
        }
        if (maxDate < currentDay) {
            calendar.set(Calendar.DATE, maxDate);
        }

        Log.i(TAG, "tempSelectMonth>>>" + tempSelectMonth + ",maxDate>>" + maxDate);
        String date = CLDateUtil.formatDate(calendar.getTime(), Constants.DATE_FORMAT_PATTERN_API);
        Log.i(TAG, "tempSelectMonth>>>" + date);
        return date;
    }

    private int getMonth(int index) {
        switch (index) {
            case 0:
                return Calendar.JANUARY;
            case 1:
                return Calendar.FEBRUARY;
            case 2:
                return Calendar.MARCH;
            case 3:
                return Calendar.APRIL;
            case 4:
                return Calendar.MAY;
            case 5:
                return Calendar.JUNE;
            case 6:
                return Calendar.JULY;
            case 7:
                return Calendar.AUGUST;
            case 8:
                return Calendar.SEPTEMBER;
            case 9:
                return Calendar.OCTOBER;
            case 10:
                return Calendar.NOVEMBER;
            case 11:
                return Calendar.DECEMBER;
        }
        return 0;
    }

}
