package com.elderly.elderly.fragment.profile;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.component.imageview.bitmapview.CLBitmapView;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo;

public class ProfileChoosePhotoFragment extends TempleteFragment implements OnClickListener{

	private Button mBtnNextStep;
	private Button mChangePhotoBtn;
	private FrameLayout mOverView;
	private CLBitmapView mBitmapView;
	
	@Override
	public void setupContextView(LayoutInflater inflater,
			ViewGroup mLayerContextView) {
		
		View view = inflater.inflate(R.layout.page_profile_choose_photo, mLayerContextView);	
		setTitle(R.string.header_profile);
		setHeaderBgColor(R.color.header_ProfileSetting);
		
		mBtnNextStep = (Button) view.findViewById(R.id.page_profile_choose_photo_mBtnNextStep);
		mChangePhotoBtn= (Button) view.findViewById(R.id.page_profile_choose_photo_mBtnChangePhoto);
		mBitmapView=(CLBitmapView) view.findViewById(R.id.page_profile_choose_photo_mBitmapView);
		mBitmapView.setUserDefalutBitmap(R.drawable.photo_none, true);
		mBitmapView.setDefalutBitmap();
		mBitmapView.setOnLongClickListener(new OnLongClickListener() {
			
			@Override
			public boolean onLongClick(View v) {
				if (UserProfileManager.getInstance().isSetPhoto()) {
					ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.profile_delete_photo,
							R.string.common_cancel, R.string.common_confirm, null, new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {
									UserProfileManager.getInstance().updateUserPicture(null);
									mBitmapView.setBitmapInfo(null, null, null, null);
									mBitmapView.loadImageOneByOne();
								}
							});
					return true;
				}
				return false;
			}
		});
		mBtnNextStep.setOnClickListener(this);
		mChangePhotoBtn.setOnClickListener(this);
		setupDatas();
		showDeletePhotoTip();
	}

	private void setupDatas() {
		setupCommonBtnBgColor(mBtnNextStep, R.color.header_ProfileSetting);
		setupCommonBtnBgColor(mChangePhotoBtn, R.color.header_ProfileSetting);
//		setupCommonBtnSelectorBgColor(mChangePhotoBtn, R.color.header_ProfileSetting);
		String pic = UserProfileManager.getInstance().getUserProfile().getPicture();
		if (pic != null) {
			CLBitmapInfo.Options options = new CLBitmapInfo.Options();
			options.height = getResources().getDimension(R.dimen.page_profile_user_picture_size);
			options.width = getResources().getDimension(R.dimen.page_profile_user_picture_size);
			options.autoOrientation = true;
			mBitmapView.setBackgroundResource(R.drawable.bg_photo);
			mBitmapView.setBitmapInfo(pic, null, pic, options);
			mBitmapView.loadImageOneByOne();
		}
	}

	@Override
	public void onClick(View v) {
		if(v.getId() == mBtnNextStep.getId()){
			ProfileInformationFragment informationFragment = new ProfileInformationFragment();
            Bundle bundle = new Bundle();
            bundle.putString("type", "setProfile");
            informationFragment.setArguments(bundle);
			getTabNavigationFragment().push(informationFragment);
		}else if(v.getId()==mChangePhotoBtn.getId()){
			ProfilePictureFragment ppf=new ProfilePictureFragment();
			Bundle bundle=new Bundle();
			bundle.putBoolean(ProfilePictureFragment.KEY_STORE_CHNAGE_PICTURE, true);
			ppf.setArguments(bundle);
			getTabNavigationFragment().push(ppf);
		}
		
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		if(mBitmapView!=null){
			mBitmapView.unRegisterBitmapInfoListener();
		}
	}
	
	private void showDeletePhotoTip(){
		if (UserProfileManager.getInstance().isNeedShowUserDeletePhoto()) {
			UserProfileManager.getInstance().alReadlyShowUserDeletePhoto();
			addGuidView(0, Constants.getGuide(13));
			mOverView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					hideOverContextView();
				}
			});
		} else {
			hideOverContextView();
		}
	}
	
	// 添加guidview的圖片指導圖
	private void addGuidView(int marginTop, int resId) {
		mOverView = showOverContextView(marginTop, false);
		mOverView.removeAllViews();
		ImageView sexGuidView = new ImageView(getActivity());
		FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		parms.gravity = Gravity.CENTER;
		parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
		sexGuidView.setImageResource(resId);
		sexGuidView.setContentDescription("提示：长按相片可以进行删除");
		mOverView.addView(sexGuidView, parms);
	}
}
