package com.elderly.elderly.fragment.setting;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.Constants.FontSize;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.Constants.Language;
import com.elderly.elderly.R;
import com.elderly.elderly.fragment.BrowseFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.SettingsManager;

import java.util.Locale;

import lib.gt.ga.v2.GAManager;

public class SettingFragment extends TempleteFragment {
    private TextView mTxtFontSizeNormal;
    private TextView mTxtFontSizeSmall;
    private TextView mTxtFontSizeLarge;
    private TextView mTxtLanguageCN;
    private TextView mTxtLanguageTC;
    private TextView mTxtColor1;
    private TextView mTxtColor2;
    private TextView mTxtVertical;
    private TextView mTxtHorizontal;
    private TextView mTxtAboutUs;
    private FrameLayout mOverView;

    //弱智的需求，垃圾项目，读nmb
    TextToSpeech textToSpeech;
    Runnable speechRunnable;
    Handler mHandler = new Handler();
    boolean isFirst = true;
    String allText = "字体大小    小按钮    中按钮    大 按钮   语言    繁体按钮    简体按钮    颜色    色彩1按钮    色彩2按钮  搜寻模式 直倒 橫倒 关于我们按钮";
    String fontSmallText = "你现在选择的字体大小为小";
    String fontNormalText = "你现在选择的字体大小为中";
    String fontLargeText = "你现在选择的字体大小为大";
    String fantiText = "你现在选择的语言为繁体";
    String jiantiText = "你现在选择的语言为简体";
    String color1Text = "你现在选择的颜色为色彩1";
    String color2Text = "你现在选择的颜色为色彩2";
    String verticalText = "你现在选择的搜寻模式为直倒";
    String horizontalText = "你现在选择的搜寻模式为橫倒";

    String speakText = "";
    boolean horizontalMode;

    @Override
    public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
        inflater.inflate(R.layout.page_setting, mLayerContextView);
        mTxtFontSizeNormal = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtFontSizeNormal);
        mTxtFontSizeSmall = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtFontSizeSmall);
        mTxtFontSizeLarge = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtFontSizeLarge);
        mTxtLanguageCN = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtLanguageCN);
        mTxtLanguageTC = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtLanguageTC);
        mTxtColor1 = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtColor1);
        mTxtColor2 = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtColor2);

        mTxtVertical = (TextView) mLayerContextView.findViewById(R.id.page_setting_mVertical);
        mTxtHorizontal = (TextView) mLayerContextView.findViewById(R.id.page_setting_mHorizontal);

        mTxtAboutUs = (TextView) mLayerContextView.findViewById(R.id.page_setting_mTxtAboutUs);

        hideRightBtn();
        setHeaderBgColor(R.color.header_Setting);
        setTitle(R.string.header_setting);
        setupData();
        setupListener();
        GAManager.getInstance().trackView(Constants.SETTING_PG_SETTING);

        textToSpeech = new TextToSpeech(getMainActivity(), new OnInitListener() {

            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = textToSpeech.setLanguage(Locale.CHINESE);
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("SettingFragment", "not support ot missing data");
                    }
                }
            }
        });

        if (isFirst) {
            speakText = allText;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        AccessibilityManager am = (AccessibilityManager) getMainActivity().getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (am.isEnabled()) {
            if (isFirst) {
                isFirst = false;
                speechRunnable = new Runnable() {

                    @Override
                    public void run() {
                        textToSpeech.speak(speakText, TextToSpeech.QUEUE_FLUSH, null);
                    }
                };
                mHandler.postDelayed(speechRunnable, 1000);
            } else {
                speechRunnable = new Runnable() {

                    @Override
                    public void run() {
                        textToSpeech.speak(speakText, TextToSpeech.QUEUE_FLUSH, null);
                    }
                };
                mHandler.postDelayed(speechRunnable, 0);
            }
        }
    }

    private void setupData() {
        if (FontSize.CurrentFontSize == FontSize.Small) {
            mTxtFontSizeSmall.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtFontSizeSmall.setSelected(true);
            mTxtFontSizeNormal.setSelected(false);
            mTxtFontSizeLarge.setSelected(false);
        } else if (FontSize.CurrentFontSize == FontSize.Normal) {
            mTxtFontSizeNormal.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtFontSizeSmall.setSelected(false);
            mTxtFontSizeNormal.setSelected(true);
            mTxtFontSizeLarge.setSelected(false);
        } else {
            mTxtFontSizeLarge.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtFontSizeSmall.setSelected(false);
            mTxtFontSizeNormal.setSelected(false);
            mTxtFontSizeLarge.setSelected(true);
        }

        if (Language.CurrentLanguage == Language.Chinese) {
            mTxtLanguageCN.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtLanguageCN.setSelected(true);
            mTxtLanguageTC.setSelected(false);
        } else {
            mTxtLanguageTC.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtLanguageCN.setSelected(false);
            mTxtLanguageTC.setSelected(true);
        }

        if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
            mTxtColor1.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtColor1.setSelected(true);
            mTxtColor2.setSelected(false);
        } else {
            mTxtColor2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtColor1.setSelected(false);
            mTxtColor2.setSelected(true);
        }

        if (SettingsManager.getInstance().getSearchModeSettings() != null) {
            horizontalMode = SettingsManager.getInstance().getSearchModeSettings().toString().equals("Horizontal") ? true : false;
        } else {
            horizontalMode = false;
        }

        if (!horizontalMode) {
            mTxtVertical.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtVertical.setSelected(true);
            mTxtHorizontal.setSelected(false);
        } else {
            mTxtHorizontal.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            mTxtVertical.setSelected(false);
            mTxtHorizontal.setSelected(true);
        }


    }

    private void setupListener() {

        mTxtLanguageCN.setOnClickListener(mLanguageClickListener);
        mTxtLanguageTC.setOnClickListener(mLanguageClickListener);
        mTxtFontSizeSmall.setOnClickListener(mFontSizeClickListener);
        mTxtFontSizeNormal.setOnClickListener(mFontSizeClickListener);
        mTxtFontSizeLarge.setOnClickListener(mFontSizeClickListener);
        mTxtColor1.setOnClickListener(mColorThemeClickListener);
        mTxtColor2.setOnClickListener(mColorThemeClickListener);

        mTxtVertical.setOnClickListener(mSearchModeClickListener);
        mTxtHorizontal.setOnClickListener(mSearchModeClickListener);

        mTxtAboutUs.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                BrowseFragment aboutFragment = new BrowseFragment();
                Bundle bundle = new Bundle();
                bundle.putBoolean(BrowseFragment.KEY_SHOW_ARROW, true);
                bundle.putInt(HEADER_TITLE_ID, R.string.page_setting_about_us);
                bundle.putString(HEADER_TYPE, HeaderType.Setting.name());
                bundle.putString(BrowseFragment.KEY_STORE_URL, Constants.getStringInLanguage(Constants.LINK_ABOUT_US_TC, Constants.LINK_ABOUT_US_SC));
                aboutFragment.setArguments(bundle);
                getTabNavigationFragment().push(aboutFragment);
            }
        });
    }

    private View.OnClickListener mFontSizeClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.page_setting_mTxtFontSizeSmall) {
                GAManager.getInstance().trackEvent(Constants.SETTING_SMALLFONTSIZE, Constants.GA_ACTION_CLICK, "");
                FontSize.CurrentFontSize = FontSize.Small;
                speakText = fontSmallText;
                mTxtFontSizeSmall.setContentDescription(fontSmallText);
                mTxtFontSizeNormal.setContentDescription(getString(R.string.voice_setting_font_size_normal));
                mTxtFontSizeLarge.setContentDescription(getString(R.string.voice_setting_font_size_large));
            } else if (v.getId() == R.id.page_setting_mTxtFontSizeNormal) {
                GAManager.getInstance().trackEvent(Constants.SETTING_MEDIUMFONTSIZE, Constants.GA_ACTION_CLICK, "");
                FontSize.CurrentFontSize = FontSize.Normal;
                speakText = fontNormalText;
                mTxtFontSizeSmall.setContentDescription(getString(R.string.voice_setting_font_size_small));
                mTxtFontSizeNormal.setContentDescription(fontNormalText);
                mTxtFontSizeLarge.setContentDescription(getString(R.string.voice_setting_font_size_large));
            } else {
                GAManager.getInstance().trackEvent(Constants.SETTING_LARGEFONTSIZE, Constants.GA_ACTION_CLICK, "");
                FontSize.CurrentFontSize = FontSize.Large;
                speakText = fontLargeText;
                mTxtFontSizeSmall.setContentDescription(getString(R.string.voice_setting_font_size_small));
                mTxtFontSizeNormal.setContentDescription(getString(R.string.voice_setting_font_size_normal));
                mTxtFontSizeLarge.setContentDescription(fontLargeText);
            }
            SettingsManager.getInstance().saveFontSizeToSettings(FontSize.CurrentFontSize);
            getMainActivity().getElderlyApplication().updateFontSize(getMainActivity());
            getTabNavigationFragment().restartCurrentFragment();
        }
    };


    private View.OnClickListener mSearchModeClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            if (v.getId() == R.id.page_setting_mVertical) {
                Constants.SearchMode.CurrentsearchMode = Constants.SearchMode.Vertical;
                speakText = verticalText;
                mTxtVertical.setContentDescription(verticalText);
                mTxtHorizontal.setContentDescription(getString(R.string.setting_horizontal));
            } else {

                Constants.SearchMode.CurrentsearchMode = Constants.SearchMode.Horizontal;
                speakText = horizontalText;
                mTxtVertical.setContentDescription(getString(R.string.setting_horizontal));
                mTxtHorizontal.setContentDescription(horizontalText);
            }

            SettingsManager.getInstance().saveSearchModeSettings(Constants.SearchMode.CurrentsearchMode
            );

            getTabNavigationFragment().restartCurrentFragment();

        }
    };


    private View.OnClickListener mLanguageClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            if (v.getId() == R.id.page_setting_mTxtLanguageCN) {
                GAManager.getInstance().trackEvent(Constants.SETTING_SIMPLIFIEDCHINESE, Constants.GA_ACTION_CLICK, "");
                Language.CurrentLanguage = Language.Chinese;
                speakText = jiantiText;
                mTxtLanguageCN.setContentDescription(jiantiText);
                mTxtLanguageTC.setContentDescription(getString(R.string.voice_setting_chinese));
            } else {
                GAManager.getInstance().trackEvent(Constants.SETTING_TRADITIONALCHINESE, Constants.GA_ACTION_CLICK, "");
                Language.CurrentLanguage = Language.TranditionalChinese;
                speakText = fantiText;
                mTxtLanguageCN.setContentDescription(fantiText);
                mTxtLanguageTC.setContentDescription(getString(R.string.voice_setting_tranditional_chinese));
            }

            SettingsManager.getInstance().saveLanguageToSettings(Language.CurrentLanguage);
            getMainActivity().getElderlyApplication().updateLanguage(getMainActivity());
            getTabNavigationFragment().restartCurrentFragment();

        }
    };

    private View.OnClickListener mColorThemeClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.page_setting_mTxtColor1) {
                GAManager.getInstance().trackEvent(Constants.SETTING_COLOUR1, Constants.GA_ACTION_CLICK, "");
                showColorPanel(R.string.page_setting_color1, ColorTheme.ColorTheme1);
                speakText = color1Text;
                mTxtColor1.setContentDescription(color1Text);
                mTxtColor2.setContentDescription(getString(R.string.voice_page_setting_color1));
            } else {
                GAManager.getInstance().trackEvent(Constants.SETTING_COLOUR2, Constants.GA_ACTION_CLICK, "");
                showColorPanel(R.string.page_setting_color2, ColorTheme.ColorTheme2);
                speakText = color2Text;
                mTxtColor1.setContentDescription(getString(R.string.voice_page_setting_color2));
                mTxtColor2.setContentDescription(color2Text);
            }

            // if (v.getId() == R.id.page_setting_mTxtColor1) {
            // ColorTheme.CurrentColorTheme = ColorTheme.ColorTheme1;
            // } else {
            // ColorTheme.CurrentColorTheme = ColorTheme.ColorTheme2;
            // }
            // if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
            // mTxtColor1.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            // mTxtColor2.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            // mTxtColor1.setSelected(true);
            // mTxtColor2.setSelected(false);
            // } else {
            // mTxtColor1.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            // mTxtColor2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
            // mTxtColor1.setSelected(false);
            // mTxtColor2.setSelected(true);
            // }
            // SettingsManager.getInstance().saveColorThemeToSettings(ColorTheme.CurrentColorTheme);

        }
    };

    private void showColorPanel(int titleId, final ColorTheme theme) {
        mOverView = showOverContextView(0, false);

        View subView = LayoutInflater.from(getActivity()).inflate(R.layout.view_setting_color_panel, null);
        subView.setFocusable(true);
        subView.setFocusableInTouchMode(true);
        TextView title = (TextView) subView.findViewById(R.id.view_setting_color_panel_mTxtTitle);
        ImageView icon = (ImageView) subView.findViewById(R.id.view_setting_color_panel_mImgVIcon);
        View submitBtn = subView.findViewById(R.id.view_setting_color_panel_mLayerConfirm);
        title.setText(titleId);
        setupCommonBtnBgColor(submitBtn, R.color.header_Setting);
        if (theme == ColorTheme.ColorTheme1) {
            if (Language.CurrentLanguage == Language.Chinese) {
                icon.setImageResource(R.drawable.color01_sc);
            } else {
                icon.setImageResource(R.drawable.color01_tc);
            }
        } else {
            if (Language.CurrentLanguage == Language.Chinese) {
                icon.setImageResource(R.drawable.color02_sc);
            } else {
                icon.setImageResource(R.drawable.color02_tc);
            }
        }
        submitBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                ColorTheme.CurrentColorTheme = theme;
                if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
                    mTxtColor1.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
                    mTxtColor2.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                    mTxtColor1.setSelected(true);
                    mTxtColor2.setSelected(false);
                } else {
                    mTxtColor1.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                    mTxtColor2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_sure, 0, 0, 0);
                    mTxtColor1.setSelected(false);
                    mTxtColor2.setSelected(true);
                }
                SettingsManager.getInstance().saveColorThemeToSettings(ColorTheme.CurrentColorTheme);
                hideOverContextView();
            }
        });

        mOverView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                hideOverContextView();

            }
        });

        mOverView.addView(subView);
        subView.requestFocus();
    }

    @Override
    public void onDestroyView() {
        mHandler.removeCallbacks(speechRunnable);
        textToSpeech.stop();
        textToSpeech.shutdown();
        super.onDestroyView();
    }
}
