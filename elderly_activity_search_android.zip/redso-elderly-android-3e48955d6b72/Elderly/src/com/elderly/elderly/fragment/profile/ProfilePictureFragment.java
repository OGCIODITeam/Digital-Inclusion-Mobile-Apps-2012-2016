package com.elderly.elderly.fragment.profile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.os.Build.VERSION;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.elderly.elderly.R;
import com.elderly.elderly.activity.MainActivity.ActivityResultListener;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.gt.cl.component.imageview.bitmapview.CLBitmapView;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfoManager;
import com.gt.cl.component.imageview.bitmapview.loader.CLBitmapLoader;
import com.gt.cl.util.CLFileUtil;
import com.gt.cl.util.CLLog;

public class ProfilePictureFragment extends TempleteFragment implements OnClickListener, ActivityResultListener {
	private static final String TAG = "ProfilePictureFragment";
	private static final int CHOESE_IMAGE_TYPE_LOCAL_PICTURE = 9999;
	private static final int CHOESE_IMAGE_TYPE_TAKE_PICTURE = 9998;
	private static final int DO_CROP_PICTURE = 9997;
	public static final String KEY_STORE_CHNAGE_PICTURE = "change_picture";
	private Button mTakePhotoBtn;
	private Button mSelectPhotoBtn;
	private Button mSkipPhotoBtn;
	private String mImagePath;
	private File mTempFile;
	private boolean mChangePicture;
	private CLBitmapView mBitmapView;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		View view = inflater.inflate(R.layout.page_profile_picture, mLayerContextView);

		setTitle(R.string.header_profile);
		setHeaderBgColor(R.color.header_ProfileSetting);

		mTakePhotoBtn = (Button) view.findViewById(R.id.page_profile_picture_takePhotoBtn);
		mSelectPhotoBtn = (Button) view.findViewById(R.id.page_profile_picture_selectPhotoBtn);
		mSkipPhotoBtn = (Button) view.findViewById(R.id.page_profile_picture_skipBtn);
		mBitmapView = (CLBitmapView) view.findViewById(R.id.page_profile_picture_mBitmapView);
		mBitmapView.setUserDefalutBitmap(R.drawable.photo_none, true);
		mBitmapView.setDefalutBitmap();
		mTakePhotoBtn.setOnClickListener(this);
		mSelectPhotoBtn.setOnClickListener(this);
		mSkipPhotoBtn.setOnClickListener(this);
		getMainActivity().setActivityResultListener(this);
		setupDatas();
	}

	private void setupDatas() {
		if (getArguments() != null) {
			mChangePicture = getArguments().getBoolean(KEY_STORE_CHNAGE_PICTURE, false);
		}

		String pic = UserProfileManager.getInstance().getUserProfile().getPicture();
		if (pic != null) {
			CLBitmapInfo.Options options = new CLBitmapInfo.Options();
			options.height = getResources().getDimension(R.dimen.page_profile_user_picture_size);
			options.width = getResources().getDimension(R.dimen.page_profile_user_picture_size);
			options.autoOrientation = true;
			mBitmapView.setBackgroundResource(R.drawable.bg_photo);
			mBitmapView.setBitmapInfo(pic, null, pic, options);
			mBitmapView.loadImageOneByOne();
		}

			try{new File(Environment.getExternalStorageDirectory(),"/Elderly").mkdirs();
			}catch (Exception e) {
				Log.e(TAG, "File Create Fail!");
			}
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == mTakePhotoBtn.getId()) {
			boolean isSDCardExist = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
			if (isSDCardExist) {
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				mTempFile = new File(Environment.getExternalStorageDirectory(), "/Elderly/temp.jpg");
				if (mTempFile.exists()) {
					CLLog.e(TAG, "exists");
				}
				mTempFile.delete();
				intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mTempFile));
				getMainActivity().startActivityForResult(intent, CHOESE_IMAGE_TYPE_TAKE_PICTURE);
			} else {
				Toast.makeText(getMainActivity(), "请插入SD Card", Toast.LENGTH_SHORT).show();
			}
		} else if (v.getId() == mSelectPhotoBtn.getId()) {
			Intent intent = new Intent(Intent.ACTION_GET_CONTENT, null);
			intent.setType("image/*");
			getMainActivity().startActivityForResult(intent, CHOESE_IMAGE_TYPE_LOCAL_PICTURE);
		} else if (v.getId() == mSkipPhotoBtn.getId()) {
			changePage();

		}

	}

	@Override
	public void onMainActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == CHOESE_IMAGE_TYPE_LOCAL_PICTURE) {
				CLLog.i(TAG, "local picture");
				if (data != null) {
					CLLog.i(TAG, "Path >>>" + data.getData().getPath());
					Uri uri = data.getData();
					String[] proj = { MediaStore.Images.Media.DATA };
					Cursor cursor = getMainActivity().managedQuery(uri, proj, null, null, null);
					int column = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
					cursor.moveToFirst();
					mImagePath = cursor.getString(column);
					CLLog.i(TAG, "real Path >>>" + mImagePath);

					// 有些图片的real path以https开头等，需要特殊处理
					if (mImagePath != null && mImagePath.length() > 0 && mImagePath.charAt(0) != '/') {
						mImagePath = null;
					}

					if (mImagePath == null) {
						Bitmap bitmap = null;
						ContentResolver resolver = getMainActivity().getContentResolver();
						Uri originalUri = data.getData();
						FileOutputStream fOut = null;
						try {
							bitmap = MediaStore.Images.Media.getBitmap(resolver, originalUri);
							mTempFile = new File(Environment.getExternalStorageDirectory(), "/Elderly/temp.jpg");
							fOut = new FileOutputStream(mTempFile);
							bitmap.compress(Bitmap.CompressFormat.PNG, 90, fOut);
							fOut.flush();
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							mImagePath = mTempFile.getAbsolutePath();
							CLFileUtil.closeIOStream(fOut);
						}
					}
					doCropPhoto(new File(mImagePath));
				}
			} else if (requestCode == CHOESE_IMAGE_TYPE_TAKE_PICTURE) {
				CLLog.i(TAG, "photograph");
				mTempFile = new File(Environment.getExternalStorageDirectory(), "/Elderly/temp.jpg");
				doCropPhoto(mTempFile);
			} else if (requestCode == DO_CROP_PICTURE) {
				if (VERSION.SDK_INT>=11&&VERSION.SDK_INT<=13) {
					if (data!=null) {
						Bitmap bitmap = (Bitmap) data.getExtras().get("data");
						FileOutputStream fOut = null;
						try {
							mTempFile = new File(Environment.getExternalStorageDirectory(), "/Elderly/temp1.jpg");
							fOut = new FileOutputStream(mTempFile);
							bitmap.compress(Bitmap.CompressFormat.PNG, 90, fOut);
							fOut.flush();
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							mImagePath = mTempFile.getAbsolutePath();
							CLFileUtil.closeIOStream(fOut);
						}
					}
				}
				savePictureFromPath(mTempFile.getAbsolutePath());
				// if (data != null) {
				// mTempFile = new File(Environment.getExternalStorageDirectory(), "temp.jpg");
				// Bitmap cropImage = data.getParcelableExtra("data");
				// if (cropImage != null) {
				// OutputStream os = null;
				// try {
				// os = new FileOutputStream(mTempFile);
				// cropImage.compress(CompressFormat.jpg, 0, os);
				// os.flush();
				// } catch (FileNotFoundException never) {
				// never.printStackTrace();
				// } catch (IOException e) {
				// e.printStackTrace();
				// } finally {
				// CLFileUtil.closeIOStream(os);
				// }
				// savePictureFromPath(mTempFile.getAbsolutePath());
				// }
				// }
			}
		}
	}

	private void doCropPhoto(File f) {
		try {
			final Intent intent = getCropImageIntent(Uri.fromFile(f));
			getMainActivity().startActivityForResult(intent, DO_CROP_PICTURE);
		} catch (Exception e) {
			Log.v(TAG, "裁剪图片失败!");
			e.printStackTrace();
		}
	}

	private Intent getCropImageIntent(Uri photoUri) {
		Log.i(TAG, "getCropImageIntent>>");
		mTempFile = new File(Environment.getExternalStorageDirectory(), "/Elderly/temp1.jpg");
		final int imageSize = getResources().getDisplayMetrics().widthPixels / 2;
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(photoUri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		intent.putExtra("outputX", imageSize);
		intent.putExtra("outputY", imageSize);
		intent.putExtra("scale", true);
		if (VERSION.SDK_INT<11||VERSION.SDK_INT>13) {
			intent.putExtra("return-data", false);
			intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mTempFile));
			intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
		}else{
			intent.putExtra("return-data", true);
		}
		return intent;
	}

	private void savePictureFromPath(String path) {
		if (path != null) {
			CLFileUtil.deleteCacheFile("profile/photo.jpg", getMainActivity());
			String saveFile = CLFileUtil.createCacheFile("profile/photo.jpg", getMainActivity());
			CLFileUtil.copyFile(new File(path), new File(saveFile));
			UserProfileManager.getInstance().updateUserPicture(saveFile);
			
			Uri fileUri = Uri.fromFile(mTempFile);
			Intent localIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, fileUri);
			getMainActivity().sendBroadcast(localIntent);
			
			Log.v(TAG, "save path>>" + saveFile);
			CLBitmapInfo info = CLBitmapInfoManager.getInstance().getBitmapInfo(saveFile);
			if (info != null) {
				CLBitmapLoader.getInstance().getBitmapCache().destoryItem(info);
			}
			changePage();
		}
	}

	private void changePage() {
		if (mChangePicture) {
			getTabNavigationFragment().pop();
		} else {
			ProfileChoosePhotoFragment settingFragment = new ProfileChoosePhotoFragment();
			getTabNavigationFragment().pushWidthDestoryCurrentFragment(settingFragment);
		}
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		if (mBitmapView != null) {
			mBitmapView.unRegisterBitmapInfoListener();
		}
	}
}
