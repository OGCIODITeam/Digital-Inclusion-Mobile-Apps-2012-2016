package com.elderly.elderly.fragment.events;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.BannerPagerAdapter;
import com.elderly.elderly.adapter.BannerPagerAdapter.OnMyItemClickListener;
import com.elderly.elderly.component.ElderlyCirclePageIndicator;
import com.elderly.elderly.component.ElderlyLinkPanel;
import com.elderly.elderly.component.ElderlyLinkPanel.LocationWheelListener;
import com.elderly.elderly.component.ElderlyShareDialog;
import com.elderly.elderly.component.ElderlyViewPager;
import com.elderly.elderly.component.ElderlyViewPager.ElderlyViewPagerLintener;
import com.elderly.elderly.fragment.BrowseFragment;
import com.elderly.elderly.fragment.map.MapFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.manager.db.DBManager;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.elderly.elderly.pojo.ao.BannerAO;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.component.imageview.bitmapview.CLBitmapView;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lib.gt.ga.v2.GAManager;

public class ActivityDetailFragment extends TempleteFragment {
	private static final String TAG = "ActivityDetailFragment";
	public static final String TYPE_LCSD = "L";
	public static final String TYPE_ELDERLY = "E";
	// public static final String KEY_STORE_TYPE = "type";
	// public static final String KEY_STORE_ID = "id";
	public static final String KEY_STORE_ACTIVITY_DETAIL = "key_store_activity_detail";

	private static final int MSG_SCROLL_VIEW_HANDLER = 0x00000001;
	private static final int MSG_SCROLL_VIEW_AUTO_HANDLER = 0x00000002;

	private View mTxtItemActivityContent;
	private View mTxtItemOriganization;
	private View mTxtItemDate;
	private View mTxtItemTime;
	private View mTxtItemLocation;
	private View mTxtItemFee;
	private View mTxtItemSignUp;
	private View mTxtItemActivityObject;
	private View mTxtItemAgeLimit;
	private View mTxtItemRemark;

	private TextView mTxtAddActivity;
	private TextView mTxtLink;
	private TextView mTxtShare;
	private TextView mTxtMap;
	private TextView mTxtActivityContent;
	private TextView mTxtOriganization;
	private TextView mTxtTitle;
	private TextView mTxtDescription;
	private TextView mTxtDate;
	private TextView mTxtTime;
	private TextView mTxtLocation;
	private TextView mTxtFee;
	private TextView mTxtSignUp;
	private TextView mTxtActivityObject;
	private TextView mTxtAgeLimit;
	private TextView mTxtRemark;

	private View mImgVPhotoArrowLeft;
	private View mImgVPhotoArrowRight;

	private ElderlyViewPager mViewPager;
	private ElderlyCirclePageIndicator mViewPagerIndicator;
	private BannerPagerAdapter mBannerAdapter;
	private List<BannerAO> mBannerData;

	private String mApiId;
	private String mApiType;
	private ActivityDetailAO mActivityDetailAO;

	private View mLayerBottomArrow;
	private View mLayerTopArrow;
	private ScrollView mScrollView;
	private View mLlScrollChild;
	private int mScrollLastY;
	private boolean isClick = false;
	// private SinaShareDialog sinaShareDialog;
	private FrameLayout mOverView;
	private ElderlyLinkPanel mElderlyLinkPanel;

	// private ElderlyAsyncTask<Void, Void, Void> mCallActivityDetailAsyncTask;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_activity_detail, mLayerContextView);
		setTitle(R.string.header_activity_detail);
		if (getArguments() != null) {
			// mApiId = getArguments().getString(KEY_STORE_ID);
			// mApiType = getArguments().getString(KEY_STORE_TYPE);
			mActivityDetailAO = (ActivityDetailAO) getArguments().getSerializable(KEY_STORE_ACTIVITY_DETAIL);
			mApiType = mActivityDetailAO.getActivityType();
			Log.v(TAG, "id>>" + mActivityDetailAO.getId() + ",type>>" + mApiType);
		}
		mImgVPhotoArrowLeft = mLayerContextView.findViewById(R.id.page_activity_detail_mImgVPhotoArrowLeft);
		mImgVPhotoArrowRight = mLayerContextView.findViewById(R.id.page_activity_detail_mImgVPhotoArrowRight);
		mTxtItemActivityContent = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemActivityContent);
		mTxtItemOriganization = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemOriganization);
		mTxtItemDate = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemDate);
		mTxtItemTime = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemTime);
		mTxtItemFee = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemFee);
		mTxtItemActivityObject = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemActivityObject);
		mTxtItemAgeLimit = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemAgeLimit);
		mTxtItemRemark = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemRemark);
		mTxtItemLocation = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemLocation);
		mTxtItemSignUp = mLayerContextView.findViewById(R.id.page_activity_detail_mTxtItemSignUp);

		mTxtActivityContent = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtActivityContent);
		mTxtOriganization = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtOriganization);
		mTxtTitle = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtTitle);
		mTxtDescription = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtDescription);
		mTxtDate = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtDate);
		mTxtTime = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtTime);
		mTxtLocation = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtLocation);
		mTxtFee = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtFee);
		mTxtSignUp = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtSignUp);
		mTxtActivityObject = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtActivityObject);
		mTxtAgeLimit = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtAgeLimit);
		mTxtRemark = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtRemark);

		mTxtAddActivity = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtAddActivity);
		mTxtLink = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtLink);
		mTxtShare = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtShare);
		mTxtMap = (TextView) mLayerContextView.findViewById(R.id.page_activity_detail_mTxtMap);
//        mTxtMap.setContentDescription(getString(R.string.page_activity_detail_map)+mActivityDetailAO.getLocation());
		mScrollView = (ScrollView) mLayerContextView.findViewById(R.id.page_activity_detail_mScrollView);
		mLayerBottomArrow = mLayerContextView.findViewById(R.id.page_activity_detail_mLayerBottomArrow);
		mLayerTopArrow = mLayerContextView.findViewById(R.id.page_activity_detail_mLayerTopArrow);
		mLlScrollChild = mLayerContextView.findViewById(R.id.page_activity_detail_mLlScrollChild);

		mViewPager = (ElderlyViewPager) mLayerContextView.findViewById(R.id.page_activity_detail_mViewPager);
		mViewPagerIndicator = (ElderlyCirclePageIndicator) mLayerContextView.findViewById(R.id.page_activity_detail_mViewPagerIndicator);
		if (mBannerAdapter == null) {
			mBannerAdapter = new BannerPagerAdapter(getActivity(), this);
		}

		mViewPager.setAdapter(mBannerAdapter);
		mViewPagerIndicator.setSnap(true);
		mViewPagerIndicator.setViewPager(mViewPager);

		mBannerAdapter.setOnMyItemClickListener(new OnMyItemClickListener() {

			@Override
			public void onMyItemClick() {
				isClick = true;
			}
		});

		mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
		mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
		setupCommonBtnBgColor(mTxtAddActivity, getSchemeColorId());
		setupCommonBtnBgColor(mTxtLink, getSchemeColorId());
		setupCommonBtnBgColor(mTxtShare, getSchemeColorId());
		setupCommonBtnBgColor(mTxtMap, getSchemeColorId());
		mTxtTitle.setTextColor(getResources().getColor(getSchemeColorId()));
		mTxtItemActivityContent.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemOriganization.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemDate.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemTime.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemFee.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemActivityObject.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemAgeLimit.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemRemark.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemLocation.setBackgroundColor(getResources().getColor(getSchemeColorId()));
		mTxtItemSignUp.setBackgroundColor(getResources().getColor(getSchemeColorId()));

		callBannerApi();
		setupListener();
		mScrollViewHandler.sendEmptyMessageDelayed(MSG_SCROLL_VIEW_AUTO_HANDLER, 500);

		// TODO weibo
		// mWeibo = Weibo.getInstance(APP_KEY, REDIRECT_URL);
		// mAccessToken = AccessTokenKeeper.readAccessToken(getMainActivity());
		// if (mAccessToken.isSessionValid()) {
		// Log.i(TAG, "oncreate token is ok");
		// }

		if (TYPE_LCSD.equals(mApiType)) {
			mTxtMap.setVisibility(View.GONE);
		}
		// if (mActivityDetailAO == null) {
		// callActivityDetailApi();
		// }
		setupData();
		GAManager.getInstance().trackView(Constants.DETAIL_PG_ACTIVITYDETAIL_ACTIVITYNUMBER_ACTIVITYTITLE);
	}

	private void setupData() {
		if (mActivityDetailAO != null) {
			// mTxtDescription.setText()//未有数据
			setText(mTxtTitle, mActivityDetailAO.getTitle(), null);
			setText(mTxtActivityContent, mActivityDetailAO.getActivityDetail(), mTxtItemActivityContent);
			String tempMyCommunityCenter = "";
			if (mActivityDetailAO.getOrganization() != null && !mActivityDetailAO.getOrganization().equals("") && mActivityDetailAO.getActivityCenterName() != null && !mActivityDetailAO.getActivityCenterName().equals("")) {
				tempMyCommunityCenter = mActivityDetailAO.getOrganization() + "\n" + mActivityDetailAO.getActivityCenterName();
			} else if (mActivityDetailAO.getOrganization() != null && !mActivityDetailAO.getOrganization().equals("")) {
				tempMyCommunityCenter = mActivityDetailAO.getOrganization();
			} else {
				tempMyCommunityCenter = mActivityDetailAO.getActivityCenterName();
			}
			setText(mTxtOriganization, tempMyCommunityCenter, mTxtItemOriganization);
			if (mApiType.equals(TYPE_ELDERLY)) {
				if (mActivityDetailAO.getDate() != null) {
					String[] dates = mActivityDetailAO.getDate().split(",");
					StringBuffer sb = new StringBuffer();
					Calendar mCalendar = Calendar.getInstance();
					for (int i = 0; i < dates.length; i++) {
						String day = dates[i];
						Date date = CLDateUtil.formatDate(day, Constants.DATE_FORMAT_PATTERN_API);
						mCalendar.setTime(date);
						String weekDay = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
						sb.append(CLDateUtil.formatDate(date, Constants.DATE_FORMAT_PATTERN_SHOW + " (") + weekDay + ")");
						if (i != dates.length - 1) {
							sb.append("\n");
						}
					}
					setText(mTxtDate, sb.toString(), mTxtItemDate);
				} else {
					setText(mTxtDate, null, mTxtItemDate);
				}
			} else {
				if (mActivityDetailAO.getDate() != null && mActivityDetailAO.getEndDate() != null) {
					Calendar mCalendar = Calendar.getInstance();
					Date startDate = CLDateUtil.formatDate(mActivityDetailAO.getDate(), Constants.DATE_FORMAT_PATTERN_API);
					Date endDate = CLDateUtil.formatDate(mActivityDetailAO.getEndDate(), Constants.DATE_FORMAT_PATTERN_API);
					mCalendar.setTime(startDate);
					String startDateWeekDay = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
					mCalendar.setTime(endDate);
					String endDateWeekDay = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
					StringBuffer sb = new StringBuffer();
					sb.append(CLDateUtil.formatDate(startDate, Constants.DATE_FORMAT_PATTERN_SHOW + " (") + startDateWeekDay + ")");
					sb.append("\n                  至\n");
					sb.append(CLDateUtil.formatDate(endDate, Constants.DATE_FORMAT_PATTERN_SHOW + " (") + endDateWeekDay + ")");
					setText(mTxtDate, sb.toString(), mTxtItemDate);
				} else if (mActivityDetailAO.getDate() != null) {
					Calendar mCalendar = Calendar.getInstance();
					Date startDate = CLDateUtil.formatDate(mActivityDetailAO.getDate(), Constants.DATE_FORMAT_PATTERN_API);
					String startDateWeekDay = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
					StringBuffer sb = new StringBuffer();
					sb.append(CLDateUtil.formatDate(startDate, Constants.DATE_FORMAT_PATTERN_SHOW + " (") + startDateWeekDay + ")");
					setText(mTxtDate, sb.toString(), mTxtItemDate);
				} else {
					setText(mTxtDate, null, mTxtItemDate);
				}
			}
			if (mActivityDetailAO.getStartTime() != null && mActivityDetailAO.getEndTime() != null) {
				setText(mTxtTime, mActivityDetailAO.getStartTime() + " - " + mActivityDetailAO.getEndTime(), mTxtItemTime);
			} else if (mActivityDetailAO.getStartTime() != null) {
				setText(mTxtTime, mActivityDetailAO.getStartTime(), mTxtItemTime);
			} else {
				setText(mTxtTime, mActivityDetailAO.getEndTime(), mTxtItemTime);
			}
			setText(mTxtLocation, mActivityDetailAO.getLocation(), mTxtItemLocation);

			setCostText(mActivityDetailAO);

			mTxtSignUp.setTag("AUTO_LINK");
			setText(mTxtSignUp, mActivityDetailAO.getApplicationMethod(), mTxtItemSignUp);
			setText(mTxtActivityObject, mActivityDetailAO.getActivityTarget(), mTxtItemActivityObject);
			setText(mTxtAgeLimit, mActivityDetailAO.getAgeLowerLimit(), mTxtItemAgeLimit);
			setText(mTxtRemark, mActivityDetailAO.getRemark(), mTxtItemRemark);
			// File test = CLFileUtil.createFile(Environment.getExternalStorageDirectory()+"/testElderly/aa.txt");
			// byte[] b=mActivityDetailAO.getRemark().getBytes();
			// BufferedOutputStream stream = null;
			// File file = null;
			// try {
			// file = new File(Environment.getExternalStorageDirectory()+"/testElderly/aa.txt");
			// FileOutputStream fstream = new FileOutputStream(file);
			// stream = new BufferedOutputStream(fstream);
			// stream.write(b);
			// } catch (Exception e) {
			// e.printStackTrace();
			// } finally {
			// if (stream != null) {
			// try {
			// stream.close();
			// } catch (IOException e1) {
			// e1.printStackTrace();
			// }
			// }
			// }
		}
	}

	private void setCostText(ActivityDetailAO activityDetailAO) {
		String tempFeeString = "";
		if (activityDetailAO.getFee() == null && activityDetailAO.getMemberFee() == null && activityDetailAO.getNonmemberFee() == null) {

		} else {
			if (activityDetailAO.getFee() != null) {
				try {
					if (Double.valueOf(activityDetailAO.getFee()) == 0) {
						tempFeeString = getString(R.string.page_activity_free);
					} else {
						tempFeeString = "$" + activityDetailAO.getFee();
					}
				} catch (Exception e) {
					tempFeeString = activityDetailAO.getFee();
				}
			}
			if (activityDetailAO.getMemberFee() != null) {
				if (tempFeeString != null && !"".equals(tempFeeString)) {
					tempFeeString += "\n";
				}
				try {
					if (Double.valueOf(activityDetailAO.getMemberFee()) == 0) {
						tempFeeString += getMainActivity().getString(R.string.page_activity_memfee_no);
					} else {
						tempFeeString += getMainActivity().getString(R.string.page_activity_memfee, activityDetailAO.getMemberFee());
					}
				} catch (Exception e) {
					tempFeeString += getMainActivity().getString(R.string.page_activity_memfee_nomark, activityDetailAO.getMemberFee());
				}
			}
			if (activityDetailAO.getNonmemberFee() != null) {
				if (tempFeeString != null && !"".equals(tempFeeString)) {
					tempFeeString += "\n";
				}
				try {
					if (Double.valueOf(activityDetailAO.getNonmemberFee()) == 0) {
						tempFeeString += getMainActivity().getString(R.string.page_activity_no_memfee_no);
					} else {
						tempFeeString += getMainActivity().getString(R.string.page_activity_no_memfee, activityDetailAO.getNonmemberFee());
					}
				} catch (Exception e) {
					tempFeeString += getMainActivity().getString(R.string.page_activity_no_memfee_nomark, activityDetailAO.getNonmemberFee());
				}
			}
		}
		setText(mTxtFee, tempFeeString, mTxtItemFee);
	}

	/**
	 * 
	 * @author Wency
	 * @CreateDate 2013-9-26
	 */
	private void setupListener() {
		mScrollView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_MOVE) {
					onHandleScrollView();
					mScrollViewHandler.sendEmptyMessage(MSG_SCROLL_VIEW_HANDLER);
				}
				return false;
			}
		});

		mTxtShare.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!isClick) {
					isClick = true;
					mBannerAdapter.setIsClick(isClick);

					GAManager.getInstance().trackEvent(Constants.DETAIL_SHAREBUTTON, Constants.GA_ACTION_CLICK, "");

					ElderlyShareDialog shareDialog = new ElderlyShareDialog(getMainActivity(), getSchemeColorId(), mActivityDetailAO) {

						@Override
						protected void onSinaWeiboShare() {
							// TODO weibo
							// if (mAccessToken.isSessionValid()) {
							// sinaShareDialog = new SinaShareDialog(getMainActivity(), mActivityDetailAO, mAccessToken)
							// {
							//
							// @Override
							// public void onSend(String shareContent) {
							// reqMultiMsg(shareContent);
							// }
							// };
							// sinaShareDialog.show();
							// } else {
							// loginSina();
							// }
						}
					};
					shareDialog.setOnDismissListener(new OnDismissListener() {

						@Override
						public void onDismiss(DialogInterface dialog) {
							isClick = false;
							mBannerAdapter.setIsClick(isClick);
						}
					});
					shareDialog.show();
				}
			}
		});

		mTxtMap.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!isClick) {
					isClick = true;
					mBannerAdapter.setIsClick(isClick);

					GAManager.getInstance().trackEvent(Constants.DETAIL_MAPBUTTON, Constants.GA_ACTION_CLICK, mActivityDetailAO.getId() + "_" + mActivityDetailAO.getTitle());

					MapFragment sef = new MapFragment();
					Bundle bundle = new Bundle();
					bundle.putString(TempleteFragment.HEADER_TYPE, getHeaderType() != null ? getHeaderType().name() : null);
					Log.i(TAG, "mActivityDetailAO.getLatitude()>>>>" + mActivityDetailAO.getLatitude() + "..." + mActivityDetailAO.getLongitude());
					bundle.putSerializable(MapFragment.KEY_ACTIVITY_DETAIL, mActivityDetailAO);
					sef.setArguments(bundle);
					getTabNavigationFragment().push(sef);


				}
			}
		});
		mTxtLink.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!isClick) {
					isClick = true;
					mBannerAdapter.setIsClick(isClick);
					showLocationWheel();
				}
			}
		});
		mTxtAddActivity.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!isClick) {
					isClick = true;
					mBannerAdapter.setIsClick(isClick);

					GAManager.getInstance().trackEvent(Constants.DETAIL_ADDBUTTON, Constants.GA_ACTION_CLICK, "");

					if (mActivityDetailAO != null && mActivityDetailAO.getActivityType() != null && mActivityDetailAO.getId() != null) {
						if (!DBManager.getInstance().isContainActivityDetail(mActivityDetailAO)) {
							DBManager.getInstance().inseartActivityDetail(mActivityDetailAO);
							AlertDialog alertDialog = ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.common_add_activity, R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}, null);
							alertDialog.setOnDismissListener(new OnDismissListener() {

								@Override
								public void onDismiss(DialogInterface dialog) {
									isClick = false;
									mBannerAdapter.setIsClick(isClick);
								}
							});
						} else {
							AlertDialog alertDialog = ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.common_add_activity_already, R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}, null);
							alertDialog.setOnDismissListener(new OnDismissListener() {

								@Override
								public void onDismiss(DialogInterface dialog) {
									isClick = false;
									mBannerAdapter.setIsClick(isClick);
								}
							});
						}
					}
				}
			}
		});
		mViewPager.setViewPagerLintener(new ElderlyViewPagerLintener() {

			@Override
			public void onPageSelected(int position) {

			}

			@Override
			public void onPageScrolled(final int position, final float positionOffset, int positionOffsetPixels) {
				showArrow(position);
				mViewPager.postDelayed(new Runnable() {

					@Override
					public void run() {
						if (mViewPager.isLooper()) {
							if (positionOffset == 0) {
								if (position == 0) {
									mViewPager.setCurrentItem(mViewPager.getAdapter().getCount() - 2, false);
								} else if (position == mViewPager.getAdapter().getCount() - 1) {
									mViewPager.setCurrentItem(1, false);
								}
							}
						}

					}
				}, 10);

			}

			@Override
			public void onPageScrollStateChanged(int state) {

			}

			@Override
			public void onRestoreInstanceState(Parcelable state) {
				showArrow(mViewPager.getCurrentItem());

			}
		});

	}

	private void setText(TextView view, String data, View content) {
		if (data == null || data.equals("")) {
			// view.setText(R.string.page_activity_detail_none);
			view.setVisibility(View.GONE);
			if (content != null) {
				content.setVisibility(View.GONE);
			}
		} else {
			if ("AUTO_LINK".equals(view.getTag())) {
				Spanned afterConvertData = convertData(data);
				if (afterConvertData == null) {
					view.setText(data);
				} else {
					view.setText(afterConvertData);
					view.setMovementMethod(LinkMovementMethod.getInstance());
				}
			} else {
				view.setText(data);
			}
		}
	}

	private Spanned convertData(String data) {
		Pattern pattern = Pattern.compile("\\d{4}-\\d{4}|\\d{8}|\\d{4} \\d{4}");
		Matcher matcher = pattern.matcher(data);
		if (matcher.find()) {
			String oldString = matcher.group(0);
			String temp = data.replaceAll(oldString, "<a href=\"tel:" + oldString + "\">" + oldString + "</a>");
			return Html.fromHtml(temp);
		} else {
			return null;
		}
	}

	private void callBannerApi() {
		if (mBannerData != null) {
			return;
		}
		new ElderlyAsyncTask<Void, Void, Void>(getActivity(), false) {

			@Override
			protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
				try {
					mBannerData = ApiManager.getInstance().getBannerList("A");
					Log.v(TAG, "mBanner>>" + mBannerData.size());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return null;
			}

			@Override
			protected void doOnSuccess(Void result) {
				if (mBannerData == null) {
					mBannerData = ApiManager.getInstance().getBannerListFormHistory("A");
				}
				if (mBannerData != null) {
					mViewPager.setLooper(false);
					mViewPagerIndicator.setViewPager(mViewPager);
					mBannerAdapter.setData(mBannerData);
					showArrow(0);
				}

			}

			@Override
			protected boolean handleException(Exception ex) {
				return false;
			}

		}.execute((Void) null);
	}

	@Override
	public void onDestroyView() {
		removeScrollHandler();
		if (mViewPager != null) {
			mViewPager.release();
			int size = mViewPager.getChildCount();
			for (int i = 0; i < size; i++) {
				View view = mViewPager.getChildAt(i);
				if (view instanceof CLBitmapView) {
					((CLBitmapView) view).unRegisterBitmapInfoListener();
				}
			}
		}
		isClick = false;
		mBannerAdapter.setIsClick(isClick);
		super.onDestroyView();
	}

	private void showArrow(int position) {
		if (mViewPager.getAdapter().getCount() < 2) {
			mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
			mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
		} else {
			if (position == 0) {
				mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
				mImgVPhotoArrowRight.setVisibility(View.VISIBLE);
			} else if (position == (mViewPager.getAdapter().getCount() - 1)) {
				mImgVPhotoArrowLeft.setVisibility(View.VISIBLE);
				mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);
			} else {
				mImgVPhotoArrowLeft.setVisibility(View.VISIBLE);
				mImgVPhotoArrowRight.setVisibility(View.VISIBLE);
			}
		}
	}

	private Handler mScrollViewHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == MSG_SCROLL_VIEW_HANDLER) {
				if (mScrollLastY == mScrollView.getScrollY()) {
					onHandleScrollView();
				} else {
					sendEmptyMessageDelayed(MSG_SCROLL_VIEW_HANDLER, 30);
					mScrollLastY = mScrollView.getScrollY();
				}
			} else if (msg.what == MSG_SCROLL_VIEW_AUTO_HANDLER) {
				onHandleScrollView();
			}
		}

	};

	private void removeScrollHandler() {
		if (mScrollViewHandler != null) {
			mScrollViewHandler.removeMessages(MSG_SCROLL_VIEW_AUTO_HANDLER);
			mScrollViewHandler.removeMessages(MSG_SCROLL_VIEW_HANDLER);
		}
	}

	private void onHandleScrollView() {

		Rect rect = new Rect();
		getRootView().getHitRect(rect);
		Rect rect1 = new Rect();

		mLlScrollChild.getHitRect(rect1);
		// Log.v(TAG, "rect>>"+rect);
		// Log.i(TAG, "rect1>>"+rect1);
		if (rect1.height() <= rect.height()) {
			mLayerBottomArrow.setVisibility(View.INVISIBLE);
			mLayerTopArrow.setVisibility(View.INVISIBLE);
		} else {
			if (mScrollView.getScrollY() == 0) {
				mLayerBottomArrow.setVisibility(View.VISIBLE);
				mLayerTopArrow.setVisibility(View.INVISIBLE);
			} else if ((mScrollView.getScrollY() + mScrollView.getHeight()) >= rect1.height()) {
				mLayerBottomArrow.setVisibility(View.INVISIBLE);
				mLayerTopArrow.setVisibility(View.VISIBLE);
			} else {
				mLayerBottomArrow.setVisibility(View.VISIBLE);
				mLayerTopArrow.setVisibility(View.INVISIBLE);
			}
		}
	}

	private void showLocationWheel() {
		if (mActivityDetailAO.getTitle() != null) {
			mOverView = showOverContextView(0, false, true);
			List<LocationPo> mLocation = new ArrayList<LocationPo>();
			List<DistrictPo> mDistricts = UserProfileManager.getInstance().getDistrictPoList();
			for (int i = 0; i < mDistricts.size(); i++) {
				mLocation.addAll(mDistricts.get(i).getRegions());
			}
			mElderlyLinkPanel = new ElderlyLinkPanel(getActivity());
			int margin = (int) ElderlyUtil.dip2px(getActivity(), 20);

			mElderlyLinkPanel.setControlBarBgColor(getSchemeColorId());
			mElderlyLinkPanel.setConfirmBgColor(getSchemeHightColorId());
			String tmp = Integer.toHexString(getResources().getColor(getSchemeColorId())).substring(1);
			String title = mActivityDetailAO.getTitle();
			if (title.length() > 16) {
				title = title.substring(0, 16) + "...";
			}
			mElderlyLinkPanel.setContentText(getString(R.string.page_activity_detail_link_description, tmp, title));
			// mElderlyLinkPanel.setContentDescription(title);
			mElderlyLinkPanel.setLocationWheelListener(new LocationWheelListener() {
				@Override
				public void onClick(boolean isConfirm) {
					isClick = false;
					mBannerAdapter.setIsClick(isClick);
					if (isConfirm) {
						BrowseFragment bf = new BrowseFragment();
						Bundle bundle = new Bundle();
						bundle.putString(TempleteFragment.HEADER_TYPE, getHeaderType() != null ? getHeaderType().name() : null);
						bundle.putString(BrowseFragment.KEY_STORE_URL, mActivityDetailAO.getLink());
						Log.i(TAG, "mActivityDetailAO.getLink()>>>" + mActivityDetailAO.getLink());
						bf.setArguments(bundle);
						getTabNavigationFragment().push(bf);
					}
					hideOverContextView();
				}
			});
			FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
			lp.gravity = Gravity.CENTER;
			lp.rightMargin = margin;
			lp.leftMargin = margin;
			mOverView.addView(mElderlyLinkPanel, lp);
			mElderlyLinkPanel.requestFocus();
		}
	}

	// Sina>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	// @Override
	// public void onActivityResult(int requestCode, int resultCode, Intent data) {
	// super.onActivityResult(requestCode, resultCode, data);
	// Log.i(TAG, "onActivityResult>>>>>>>>>>>>>>>>>>>start");
	// if (mSsoHandler != null) {
	// mSsoHandler.authorizeCallBack(requestCode, resultCode, data);
	// }
	// }
	//
	// /** 微博API接口类，提供登陆等功能 */
	// private Weibo mWeibo;
	//
	// /** 封装了 "access_token"，"expires_in"，"refresh_token"，并提供了他们的管理功能 */
	// private Oauth2AccessToken mAccessToken;
	//
	// /** 注意：SsoHandler 仅当sdk支持sso时有效 */
	// private SsoHandler mSsoHandler;
	// // 应用的key 请到官方申请正式的appkey替换APP_KEY
	// public static final String APP_KEY = "966056985";
	//
	// // 替换为开发者REDIRECT_URL
	// public static final String REDIRECT_URL = "http://www.sina.com";
	//
	// // 新支持scope：支持传入多个scope权限，用逗号分隔
	// public static final String SCOPE = "email,direct_messages_read,direct_messages_write," +
	// "friendships_groups_read,friendships_groups_write,statuses_to_me_read," + "follow_app_official_microblog," +
	// "invitation_write";
	//
	// protected void loginSina() {
	// mSsoHandler = new SsoHandler(getMainActivity(), mWeibo);
	// mSsoHandler.authorize(new AuthDialogListener());
	// }
	//
	// /**
	// * 微博认证授权回调类。
	// * 1. SSO登陆时，需要在{@link #onActivityResult}中调用mSsoHandler.authorizeCallBack后，
	// * 该回调才会被执行。
	// * 2. 非SSO登陆时，当授权后，就会被执行。
	// * 当授权成功后，请保存该access_token、expires_in等信息到SharedPreferences中。
	// */
	// class AuthDialogListener implements WeiboAuthListener {
	//
	// @Override
	// public void onComplete(Bundle values) {
	//
	// String token = values.getString("access_token");
	// String expires_in = values.getString("expires_in");
	// mAccessToken = new Oauth2AccessToken(token, expires_in);
	// if (mAccessToken.isSessionValid()) {
	// AccessTokenKeeper.keepAccessToken(getMainActivity(), mAccessToken);
	// sinaShareDialog = new SinaShareDialog(getMainActivity(), mActivityDetailAO, mAccessToken) {
	//
	// @Override
	// public void onSend(String shareContent) {
	// reqMultiMsg(shareContent);
	// }
	//
	// };
	// sinaShareDialog.show();
	// }
	// }
	//
	// @Override
	// public void onError(WeiboDialogError e) {
	// ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.sina_auth_fail,
	// R.string.common_confirm, 0, null, null);
	// }
	//
	// @Override
	// public void onCancel() {
	//
	// }
	//
	// @Override
	// public void onWeiboException(WeiboException e) {
	// ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.sina_auth_fail,
	// R.string.common_confirm, 0, null, null);
	// }
	// }
	//
	// private void reqMultiMsg(String shareContent) {
	// StatusesAPI statusesAPI = new StatusesAPI(mAccessToken);
	// statusesAPI.update(shareContent, "", "", new RequestListener() {
	//
	// @Override
	// public void onIOException(IOException arg0) {
	// sinaShareDialog.closeLoading();
	// getActivity().runOnUiThread(new Runnable() {
	//
	// @Override
	// public void run() {
	// ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.share_fail,
	// R.string.common_confirm, 0, null, null);
	// }
	// });
	// }
	//
	// @Override
	// public void onError(WeiboException arg0) {
	// sinaShareDialog.closeLoading();
	// getActivity().runOnUiThread(new Runnable() {
	//
	// @Override
	// public void run() {
	// ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.share_fail,
	// R.string.common_confirm, 0, null, null);
	// }
	// });
	// }
	//
	// @Override
	// public void onComplete(String arg0) {
	// sinaShareDialog.closeLoading();
	// sinaShareDialog.cancel();
	// getActivity().runOnUiThread(new Runnable() {
	//
	// @Override
	// public void run() {
	// ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.share_sucess,
	// R.string.common_confirm, 0, null, null);
	// }
	// });
	// }
	// });
	// }
	// Sina>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
