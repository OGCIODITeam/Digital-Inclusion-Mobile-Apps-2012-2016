package com.elderly.elderly.fragment.search.near;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyLocationWheel;
import com.elderly.elderly.component.ElderlyLocationWheel.LocationWheelListener;
import com.elderly.elderly.fragment.search.SearchResultFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.DateAO;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.pojo.po.UserProfilePo;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

import org.xmlpull.v1.XmlPullParserException;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import lib.gt.ga.v2.GAManager;

public class SearchNearFragment extends TempleteFragment implements ConnectionCallbacks, OnConnectionFailedListener, LocationListener {
	private static final String TAG = "SearchNearFragment";
	private TextView mTxtNowlocation;
	private TextView mTxtLivelocation;
	private View mLayerSearch;
	private TextView mTxtRange;
	private TextView mTxtRangeTip;
	private String[] mRangeData;
	private FrameLayout mOverView;
	private String mSelectData;
	private ElderlyLocationWheel mElderlyRangeWheel;
	private boolean mSelectLiveLocation = false;
	private View mImgLiveLocation;
	private View mImgNowLocation;

	private List<DateAO> mDatesL;// 康文署
	private List<DateAO> mDatesE;// 長者中心活動
	private boolean mCallApiing;
	private String mDateL;// 康文署 活动最近的日期
	private String mDateE;// 長者中心 活动最近的日期
	private LocationPo mSelectLocationPo;// 用户设置的居住位置

	/*
	 * GPS
	 */
	private LocationClient mLocationClient;
	private LocationRequest mLocationRequest;
	private Location mLastLocation;

	private int mSelectRangeIndex = 0;
	private String mSearchDistance;
	private boolean mTestLocation = false;

	private ElderlyAsyncTask mAsyncTask;

	TextToSpeech textToSpeech;
	Runnable speechRunnable;
	Handler mHandler = new Handler();

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_search_near, mLayerContextView);
		setTitle(R.string.header_search_near);
		mImgNowLocation = mLayerContextView.findViewById(R.id.page_search_near_mImgNowLocation);
		mImgLiveLocation = mLayerContextView.findViewById(R.id.page_search_near_mImgLiveLocation);
		mTxtNowlocation = (TextView) mLayerContextView.findViewById(R.id.page_search_near_mTxtNowlocation);
		mTxtLivelocation = (TextView) mLayerContextView.findViewById(R.id.page_search_near_mTxtLivelocation);
		mLayerSearch = mLayerContextView.findViewById(R.id.page_search_near_mLayerSearch);
		mTxtRange = (TextView) mLayerContextView.findViewById(R.id.page_search_near_mTxtRange);
		mTxtRangeTip = (TextView) mLayerContextView.findViewById(R.id.page_search_near_mTxtRangeTip);
		mRangeData = getResources().getStringArray(R.array.search_range);
		setupCommonBtnBgColor(mTxtNowlocation, getSchemeColorId());
		setupCommonBtnBgColor(mTxtLivelocation, getSchemeColorId());
		setupCommonBtnBgColor(mLayerSearch, getSchemeColorId());
		mSelectData = mRangeData[mSelectRangeIndex];
		mTxtRange.setText(mSelectData);
		mTxtRange.setContentDescription("你现在选择了"+mSelectData);
		setupListener();
		hightLightSelect();

		GAManager.getInstance().trackView(Constants.NEAR_PG_SEARCHNEARBY);
		
		textToSpeech = new TextToSpeech(getMainActivity(), new OnInitListener() {

			@Override
			public void onInit(int status) {
				if (status == TextToSpeech.SUCCESS) {
					int result = textToSpeech.setLanguage(Locale.CHINESE);
					if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
						Log.e("SearchNearFragment", "not support ot missing data");
					}
				}
			}
		});
	}

	@Override
	public void onResume() {
		super.onResume();
		if (!mSelectLiveLocation && checkGpsStatus()) {
			getLocation();
		}
	}

	public void seapk(final String text) {
		AccessibilityManager am = (AccessibilityManager) getMainActivity().getSystemService(Context.ACCESSIBILITY_SERVICE);
		if (am.isEnabled()) {
			speechRunnable = new Runnable() {

				@Override
				public void run() {
					textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
				}
			};
			mHandler.postDelayed(speechRunnable, 0);
		}
	}

	private void setupListener() {
		mTxtNowlocation.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.NEAR_CURRENTLOCATIONBUTTON, Constants.GA_ACTION_CLICK, "");
				if (checkGpsStatus()) {
					getLocation();
				}
				mSelectLiveLocation = false;
				hightLightSelect();
				seapk("你会于现在位置作附近搜寻");
			}
		});
		mTxtLivelocation.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.NEAR_LIVINGLOCATIONBUTTON, Constants.GA_ACTION_CLICK, "");
				mSelectLiveLocation = true;
				hightLightSelect();
				if (checkLiveStatus()) {
					disableGps();
				}
				seapk("你会于居住位置作附近搜寻");
			}
		});
		mTxtRange.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.NEAR_SELECTDISTANCEBUTTON, Constants.GA_ACTION_CLICK, "");
				showRangeWheel();
			}
		});
		mLayerSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!mTestLocation && !mSelectLiveLocation && mLastLocation == null) {
					ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.tip_location_failure, R.string.common_cancel, 0, null, null);
					return;
				} else if (ElderlyUtil.isConnectNetWork(getMainActivity())) {
					callDateListApi();
				}

			}
		});

	}

	public void switchDrawable(View view) {
		Drawable tmp;
		tmp = view.getBackground();
		// Log.v("shape", "tmp" + tmp);
		if (tmp != null && tmp instanceof GradientDrawable) {
			GradientDrawable gd = (GradientDrawable) tmp;
			gd.setColor(getResources().getColor(getSchemeColorId()));
			tmp = null;
		}
	}

	public void showRangeWheel() {
		mOverView = showOverContextView(0, false);
		mElderlyRangeWheel = new ElderlyLocationWheel(getActivity());
		mElderlyRangeWheel.setupData(Arrays.asList(mRangeData), mSelectData);
		int drawableId = R.drawable.search_nearby_on;
		if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme2) {
			drawableId = R.drawable.search_nearby_on2;
		}
		mElderlyRangeWheel.setSelectDrawable(drawableId);
		mElderlyRangeWheel.setControlBarBgColor(getSchemeColorId());
		mElderlyRangeWheel.setConfirmBgColor(getSchemeHightColorId());
		mElderlyRangeWheel.setLocationWheelListener(new LocationWheelListener() {
			@Override
			public void onClick(boolean isConfirm, Object data) {
				if (isConfirm) {
					mSelectData = (String) data;
					mTxtRange.setText(mSelectData);
					mTxtRange.setContentDescription("你现在选择了"+mSelectData);
					mSelectRangeIndex = mElderlyRangeWheel.getCurrentIndex();
				}
				hideOverContextView();
				mElderlyRangeWheel.releaseWheel();
			}
		});
		int margin = (int) ElderlyUtil.dip2px(getActivity(), 20);

		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
		lp.gravity = Gravity.CENTER;
		lp.rightMargin = margin;
		lp.leftMargin = margin;
		mOverView.addView(mElderlyRangeWheel, lp);
		mElderlyRangeWheel.requestFocus();
	}

	private void hightLightSelect() {
		if (mSelectLiveLocation) {
			mImgLiveLocation.setVisibility(View.VISIBLE);
			mImgNowLocation.setVisibility(View.INVISIBLE);
		} else {
			mImgLiveLocation.setVisibility(View.INVISIBLE);
			mImgNowLocation.setVisibility(View.VISIBLE);
		}
	}

	private boolean checkGpsStatus() {
		boolean isVaild = false;
		isVaild = ElderlyUtil.isGPSAvailable(getActivity());
		if (!isVaild) {
			ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.tip_please_enable_location_service, R.string.common_cancel, R.string.common_setting, null, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
					startActivity(intent);

				}
			});
		}
		return isVaild;

	}

	private boolean checkLiveStatus() {
		UserProfilePo user = UserProfileManager.getInstance().getUserProfile();
		boolean isValid = false;
		if (user.getDistrict() != null && user.getRegion() != null) {
			mSelectLocationPo = UserProfileManager.getInstance().getRegionByKey(user.getDistrict(), user.getRegion());
			if (mSelectLocationPo != null) {
				isValid = true;
			}
		}
		if (!isValid) {
			ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.tip_please_select_live_location, R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					mSelectLiveLocation = false;
					hightLightSelect();
				}
			}, null);

		}
		return isValid;
	}

	private void getLocation() {
		if (mLocationClient != null && (mLocationClient.isConnecting() || mLocationClient.isConnected())) {
			return;
		}
		mLocationClient = new LocationClient(getActivity(), this, this);
		mLocationClient.connect();
	}

	private void disableGps() {
		if (mLocationClient != null && (mLocationClient.isConnecting() || mLocationClient.isConnected())) {
			mLocationClient.removeLocationUpdates(this);
			mLocationClient.unregisterConnectionCallbacks(this);
			mLocationClient.unregisterConnectionFailedListener(this);
			mLocationClient.disconnect();

		}
	}

	private String getSearchDistance() {
		if (mSelectRangeIndex == 0) {
			return "2000";
		} else if (mSelectRangeIndex == 1) {
			return "4000";
		} else {
			return "8000";
		}
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {

	}

	@Override
	public void onConnected(Bundle bundle) {
		Log.v(TAG, "GPS >> onConnected");
		mLocationRequest = LocationRequest.create().setInterval(2 * 1000).setFastestInterval(100).setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
		mLocationClient.requestLocationUpdates(mLocationRequest, this);
		mLastLocation = mLocationClient.getLastLocation();
	}

	@Override
	public void onDisconnected() {
		Log.v(TAG, "GPS >> onDisconnected");

	}

	@Override
	public void onLocationChanged(Location location) {
		// Log.v(TAG, "GPS onLocationChanged >>"+location.getLatitude()+","+location.getLongitude());
		mLastLocation = location;
	}

	@Override
	public void onDestroyView() {
		mHandler.removeCallbacks(speechRunnable);
		textToSpeech.stop();
		textToSpeech.shutdown();
		super.onDestroyView();
		disableGps();
	}

	private void callDateListApi() {
		if (!mCallApiing) {
			mCallApiing = true;
			mAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity()) {

				@Override
				protected Void doInBackground(Void params) throws CLConnectionException, CLInvalidNetworkException {
					String date = getDate();
					try {
						Log.v(TAG, "api date>>" + date);
						if (mSelectLiveLocation) {
							mDatesL = ApiManager.getInstance().getDateList(date, null, mSelectLocationPo.getValue(), null, null, null, null, "L");
							mDatesE = ApiManager.getInstance().getDateList(date, null, mSelectLocationPo.getValue(), null, null, null, null, "E");
						} else {
							String latitude = "0.0";
							String longitude = "0.0";
							// String latitude = "22.318319";
							// String longitude = "114.228973";
							if (mLastLocation != null) {
								latitude = String.valueOf(mLastLocation.getLatitude());
								longitude = String.valueOf(mLastLocation.getLongitude());
							}
							if (mTestLocation) {
								latitude = "22.311212";
								longitude = "114.222486";
							}
							mDatesE = ApiManager.getInstance().getDateListByCoordinate(date, getSearchDistance(), latitude, longitude);
						}
					} catch (XmlPullParserException e) {
						e.printStackTrace();
					}
					return null;
				}

				@Override
				protected boolean handleException(Exception ex) {
					mCallApiing = false;
					return super.handleException(ex);
				}

				@Override
				protected void doOnSuccess(Void result) {
					mCallApiing = false;
					searchBestDate();
					goToSearchResult();
				}

				@Override
				protected boolean showCustomLoading() {
					return true;
				}

				@Override
				protected void callCustomLoading() {
					showLoadingView();
				}

				@Override
				protected void cancelCustomLoading() {
					hideLoadingView();
					super.cancelCustomLoading();
				}

				@Override
				protected void onCancelled() {
					ApiManager.getInstance().cancelCallDateList();
					ApiManager.getInstance().cancelCallDateListByCoordinate();

					super.onCancelled();
				}
			};
			mAsyncTask.execute((Void) null);

		}
	}

	private String getDate() {
		Date date = new Date();
		return CLDateUtil.formatDate(date, Constants.DATE_FORMAT_PATTERN_API2);

	}

	private void searchBestDate() {
		// Calendar calendar = Calendar.getInstance();
		// calendar.set(Calendar.DAY_OF_MONTH, 30);
		// Date currentDate = calendar.getTime();
		Date currentDate = CLDateUtil.formatDate(CLDateUtil.now(Constants.DATE_FORMAT_PATTERN_API), Constants.DATE_FORMAT_PATTERN_API);
		Date tmpDate = null;
		Log.v(TAG, "current date>>" + CLDateUtil.formatDate(currentDate, Constants.DATE_FORMAT_PATTERN_API));
		if (mDatesE != null && mDatesE.size() > 0) {
			for (int i = 0; i < mDatesE.size(); i++) {
				DateAO ao = mDatesE.get(i);
				Log.v(TAG, "date>>" + CLDateUtil.formatDate(ao.getDate(), Constants.DATE_FORMAT_PATTERN_API));
				if (ao.getDate().compareTo(currentDate) == 0) {
					// Log.v(TAG, "has today");
					tmpDate = ao.getDate();
					break;
				} else if (ao.getDate().after(currentDate)) {
					if (tmpDate == null || tmpDate.before(currentDate)) {
						tmpDate = ao.getDate();
					} else if (tmpDate.after(ao.getDate())) {
						tmpDate = ao.getDate();
					}
				} else {
					if (tmpDate != null && tmpDate.after(currentDate)) {
						continue;
					} else if (ao.getDate().before(currentDate)) {
						if (tmpDate == null) {
							tmpDate = ao.getDate();
						} else if (tmpDate.before(ao.getDate())) {
							tmpDate = ao.getDate();
						}
					}
				}
			}
			mDateE = CLDateUtil.formatDate(tmpDate, Constants.DATE_FORMAT_PATTERN_API);
			Log.v(TAG, "best day>>" + mDateE);
		} else {
			mDateE = CLDateUtil.formatDate(currentDate, Constants.DATE_FORMAT_PATTERN_API);
			Log.v(TAG, "mDatesE== null best day>>" + mDateE);
		}
		if (mSelectLiveLocation && mDatesL != null && mDatesL.size() > 0) {
			for (int i = 0; i < mDatesL.size(); i++) {
				DateAO ao = mDatesL.get(i);
				if (currentDate.compareTo(ao.getDate()) == 0) {
					tmpDate = ao.getDate();
					break;
				} else if (ao.getDate().after(currentDate)) {
					if (tmpDate == null || tmpDate.before(currentDate)) {
						tmpDate = ao.getDate();
					} else if (tmpDate.after(ao.getDate())) {
						tmpDate = ao.getDate();
					}
				} else {
					if (tmpDate != null && tmpDate.after(currentDate)) {
						continue;
					} else if (ao.getDate().before(currentDate)) {
						if (tmpDate == null) {
							tmpDate = ao.getDate();
						} else if (tmpDate.before(ao.getDate())) {
							tmpDate = ao.getDate();
						}
					}
				}
			}
			mDateL = CLDateUtil.formatDate(tmpDate, Constants.DATE_FORMAT_PATTERN_API);
		} else {
			mDateL = ElderlyUtil.getCurrentDate();
		}
	}

	private void goToSearchResult() {
		SearchResultFragment srf = new SearchResultFragment();
		Bundle bundle = new Bundle();
		bundle.putString(HEADER_TYPE, getHeaderType().name());
		bundle.putString(SearchResultFragment.KEY_TITLE_NAME, getString(R.string.header_search_result_near));
		bundle.putBoolean(SearchResultFragment.KEY_SEARCH_NEARBY_LIVE_LOCATION, mSelectLiveLocation);
		if (mSelectLiveLocation) {
			bundle.putString(SearchResultFragment.KEY_DATE_E, mDateE);
			bundle.putString(SearchResultFragment.KEY_DATE_L, mDateL);
			if (mSelectLocationPo != null) {
				bundle.putString(SearchResultFragment.KEY_ACTIVE_AREA, mSelectLocationPo.getValue());
			}
		} else {
			bundle.putString(SearchResultFragment.KEY_SEARCH_DISTANCE, getSearchDistance());

			String latitude = "0.0";
			String longitude = "0.0";

			// String latitude = "22.318319";
			// String longitude = "114.228973";

			if (mLastLocation != null) {
				latitude = String.valueOf(mLastLocation.getLatitude());
				longitude = String.valueOf(mLastLocation.getLongitude());
			}
			if (mTestLocation) {
				latitude = "22.311212";
				longitude = "114.222486";
			}
			bundle.putString(SearchResultFragment.KEY_DATE_E, mDateE);
			bundle.putString(SearchResultFragment.KEY_LATITUDE, latitude);
			bundle.putString(SearchResultFragment.KEY_LONGITUDE, longitude);
		}
		srf.setArguments(bundle);
		getTabNavigationFragment().push(srf);
	}

}
