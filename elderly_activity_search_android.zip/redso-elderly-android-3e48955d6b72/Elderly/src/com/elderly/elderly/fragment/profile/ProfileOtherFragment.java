package com.elderly.elderly.fragment.profile;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.fragment.search.easy.SearchEasyFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.util.ElderlyUtil;

import lib.gt.ga.v2.GAManager;

public class ProfileOtherFragment extends TempleteFragment {
    private View mBtnMyInterest;
    private View mBtnMyCommunity;
    private View mBtnDone;
    private FrameLayout mOverView;
    String type;

    @Override
    public void setupContextView(LayoutInflater inflater,
                                 ViewGroup mLayerContextView) {
        View view = inflater.inflate(R.layout.page_profile_other, mLayerContextView);
        mBtnMyInterest = view.findViewById(R.id.page_profile_other_mBtnMyInterest);
        mBtnMyCommunity = view.findViewById(R.id.page_profile_other_mBtnMyCommunity);
        mBtnDone = view.findViewById(R.id.page_profile_other_mBtnDone);
        setTitle(R.string.header_profile);
        setHeaderBgColor(R.color.header_ProfileSetting);
        type = getArguments().getString("type");
        mBtnDone.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mBtnDone.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                if (UserProfileManager.getInstance().isNeedShowUserInterestTip()) {
                    showUserInterestTip();
                } else if (UserProfileManager.getInstance().isNeedShowUserCommunityTip()) {
                    showUserCommunityTip();
                }
            }

        });
        setupCommonBtnBgColor(mBtnDone, R.color.header_ProfileSetting);
        setupCommonBtnBgColor(mBtnMyCommunity, R.color.header_ProfileSetting);
        setupCommonBtnBgColor(mBtnMyInterest, R.color.header_ProfileSetting);
        setupListener();
    }

    private void setupListener() {
        mBtnMyInterest.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                ProfileMyInterestFragment pmif = new ProfileMyInterestFragment();
                getTabNavigationFragment().push(pmif);
            }
        });
        mBtnMyCommunity.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                UserProfileManager.getInstance().alReadlyShowUserCommunityTip();
                ProfileMyCommunityFragment pmif = new ProfileMyCommunityFragment();
                getTabNavigationFragment().push(pmif);

            }
        });

        mBtnDone.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                if (type.equals("setSearchOption")) {
                    GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_EASYSEARCHBUTTON, Constants.GA_ACTION_CLICK, "");

                    SearchEasyFragment sef = new SearchEasyFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString(TempleteFragment.HEADER_TYPE, Constants.HeaderType.SearchEasy.name());
                    sef.setArguments(bundle);
                    getTabNavigationFragment().push(sef);
                } else if (type.equals("setProfile")) {
                    getTabNavigationFragment().popToRootFragment();
                }


            }
        });

    }

    private void showUserInterestTip() {
        if (UserProfileManager.getInstance().isNeedShowUserInterestTip()) {
            Rect rect = new Rect();
            mBtnMyInterest.getGlobalVisibleRect(rect);
            int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(
                    getActivity(), 10));
            addGuidView(sexCoverViewHeight, Constants.getGuide(5), 5);
        } else {
            hideOverContextView();
        }
    }

    private void showUserCommunityTip() {
        if (UserProfileManager.getInstance().isNeedShowUserCommunityTip()) {
            Rect rect = new Rect();
            mBtnMyCommunity.getGlobalVisibleRect(rect);
            int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(
                    getActivity(), 10));
            addGuidView(sexCoverViewHeight, Constants.getGuide(7), 7);
        } else {
            hideOverContextView();
        }
    }

    // 添加guidview的圖片指導圖
    private void addGuidView(int marginTop, int resId, int which) {
        mOverView = showOverContextView(marginTop, false);
        mOverView.removeAllViews();
        ImageView sexGuidView = new ImageView(getActivity());
        FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT);
        parms.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
        sexGuidView.setImageResource(resId);
        if (which == 5) {
            sexGuidView.setContentDescription("提示：请按 我的兴趣 键");
        } else if (which == 7) {
            sexGuidView.setContentDescription("提示：请按 我的长者中心 键");
        }
        mOverView.addView(sexGuidView, parms);
    }

}
