package com.elderly.elderly.fragment.search.advance;

import java.io.Serializable;
import java.util.List;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.MyInterestAdapter;
import com.elderly.elderly.adapter.SelectInterestAdapter;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;
import com.elderly.elderly.util.ElderlyUtil;

public class SelectInterestFragment extends TempleteFragment {
	private ElderlyListView mElderlyListView;
	private View mLayerConfirm;
	private FrameLayout mOverView;
	private SelectInterestAdapter mAdapter;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		setTitle(R.string.page_search_adv_activity_category);
		setHeaderBgColor(getSchemeColorId());
		inflater.inflate(R.layout.page_select_interest, mLayerContextView);
		mElderlyListView = (ElderlyListView) mLayerContextView.findViewById(R.id.page_select_interest_mElderlyListView);
		mLayerConfirm = mLayerContextView.findViewById(R.id.page_select_interest_mLayerConfirm);
		setupCommonBtnBgColor(mLayerConfirm, getSchemeColorId());
		mAdapter = new SelectInterestAdapter(getActivity());
		mElderlyListView.getListView().setDividerHeight((int) getResources().getDimensionPixelSize(R.dimen.divider_line_height));
		mElderlyListView.setAdapter(mAdapter);
		setupListener();
		showInterestTip();
		Bundle bundle = getArguments();
		
		if (bundle != null) {
			mAdapter.setHightLightDatas((List<ActivityCategoryPo>) bundle.getSerializable(SearchAdvanceFragment.KEY_STORE_ACTIVITY_CATEGORY));
		}
	}

	private void setupListener() {
		mLayerConfirm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Bundle bundle = new Bundle();
				bundle.putSerializable(SearchAdvanceFragment.KEY_STORE_ACTIVITY_CATEGORY, (Serializable) mAdapter.getHightLightDatas());
				getTabNavigationFragment().pop(bundle);
			}
		});
	}

	private void showInterestTip() {
		if (UserProfileManager.getInstance().isNeedShowSelectInterestTip()) {
			UserProfileManager.getInstance().alReadlyShowSelectInterestTip();
			addGuidView(0, Constants.getGuide(6));
			mOverView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					hideOverContextView();

				}
			});
		} else {
			hideOverContextView();
		}
	}

	private void addGuidView(int marginTop, int resId) {
		mOverView = showOverContextView(marginTop, false);
		mOverView.removeAllViews();
		ImageView sexGuidView = new ImageView(getActivity());
		FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		parms.gravity = Gravity.CENTER;
		parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
		sexGuidView.setImageResource(resId);
		sexGuidView.setContentDescription("提示：请选择你的兴趣（可选多于一个）");
		mOverView.addView(sexGuidView, parms);
	}

}
