package com.elderly.elderly.fragment.profile;

import android.content.DialogInterface;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.elderly.elderly.R;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.component.ElderlyLocationWheel;
import com.elderly.elderly.component.ElderlyLocationWheel.LocationWheelListener;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.util.ElderlyUtil;

public class ProfileSearchCommunityFragment extends TempleteFragment {
	private TextView mTxtRegion;
	private TextView mTxtDistrict;
	private View mLayerSearch;
	private FrameLayout mOverView;
	private DistrictPo mSelectDistrictPo;
	private LocationPo mSelectLocationPo;
	private ElderlyLocationWheel mElderlyLocationWheel;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		setTitle(R.string.header_my_community);
		setHeaderBgColor(R.color.header_ProfileSetting);
		inflater.inflate(R.layout.page_profile_search_community, mLayerContextView);
		mTxtRegion = (TextView) mLayerContextView.findViewById(R.id.page_profile_search_community_mTxtRegion);
		mTxtDistrict = (TextView) mLayerContextView.findViewById(R.id.page_profile_search_community_mTxtDistrict);
		mLayerSearch = mLayerContextView.findViewById(R.id.page_profile_search_community_mLayerSearch);
		setupData();

		setupCommonBtnBgColor(mLayerSearch, R.color.header_ProfileSetting);
	}

	private void setupData() {
		if (mSelectDistrictPo != null) {
			mTxtDistrict.setText(mSelectDistrictPo.getName());
		}
		if (mSelectLocationPo != null) {
			mTxtRegion.setText(mSelectLocationPo.getName());
		}

		mTxtRegion.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (mSelectDistrictPo != null) {
					addRegionView(false);
				} else {
					ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.profile_no_district_search,
							R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}, null);
				}

			}
		});
		mTxtDistrict.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				addDistrictView(false);

			}
		});
		mLayerSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mSelectLocationPo != null) {
					if(!ElderlyUtil.isConnectNetWork(getMainActivity())){
						return ;
					}
					ProfileCommunityListFragment pclf = new ProfileCommunityListFragment();
					Bundle bundle = new Bundle();
					bundle.putSerializable(ProfileCommunityListFragment.KEY_STORE_LOCATION, mSelectLocationPo);
					bundle.putString(HEADER_TYPE, HeaderType.ProfileSetting.name());
					bundle.putBoolean(ProfileCommunityListFragment.Key_STORE_SAVE_LOCATION_CENTRE, true);
					if (getArguments() != null) {
						bundle.putAll(getArguments());
					}
					pclf.setArguments(bundle);
					getTabNavigationFragment().push(pclf);
				} else {
					ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.profile_no_region_search,
							R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {

								}
							}, null);
				}

			}
		});
	}

	// 添加區域模塊的選擇按鈕
	private void addDistrictView(boolean anim) {
		mElderlyLocationWheel = new ElderlyLocationWheel(getActivity());
		mElderlyLocationWheel.setSelectDrawable(R.drawable.setting_area_on);
		mElderlyLocationWheel.setupData(UserProfileManager.getInstance().getDistrictPoList(), mSelectDistrictPo);
		mElderlyLocationWheel.setControlBarBgColor(R.color.header_ProfileSetting);
		mElderlyLocationWheel.setConfirmBgColor(R.color.header_ProfileSetting_HeightLight);
		mElderlyLocationWheel.setLocationWheelListener(new LocationWheelListener() {
			@Override
			public void onClick(boolean isConfirm, Object data) {
				if (isConfirm) {
					if (mSelectDistrictPo != null && !mSelectDistrictPo.equals(data)) {
						mTxtRegion.setText(null);
						mSelectLocationPo = null;
					}
					mSelectDistrictPo = (DistrictPo) data;
					mTxtDistrict.setText(mSelectDistrictPo.getName());
				}
				hideOverContextView();
				mElderlyLocationWheel.releaseWheel();
				UserProfileManager.getInstance().alReadlyShowUserRegionTip();
			}
		});
		Rect rect = new Rect();
		mTxtDistrict.getGlobalVisibleRect(rect);
		int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
				FrameLayout.LayoutParams.WRAP_CONTENT);
		lp.gravity = Gravity.CENTER;
		addOverContentView(sexCoverViewHeight, mElderlyLocationWheel, anim, lp);
	}

	// 添加地區模塊的選擇按鈕
	private void addRegionView(boolean anim) {
		mElderlyLocationWheel = new ElderlyLocationWheel(getActivity());
		mElderlyLocationWheel.setSelectDrawable(R.drawable.setting_area_on);
		mElderlyLocationWheel.setupData(UserProfileManager.getInstance().getRegionList(mSelectDistrictPo.getKey()), mSelectLocationPo);
		mElderlyLocationWheel.setControlBarBgColor(R.color.header_ProfileSetting);
		mElderlyLocationWheel.setConfirmBgColor(R.color.header_ProfileSetting_HeightLight);
		mElderlyLocationWheel.setLocationWheelListener(new LocationWheelListener() {
			@Override
			public void onClick(boolean isConfirm, Object data) {
				if (isConfirm) {
					mSelectLocationPo = (LocationPo) data;
					mTxtRegion.setText(mSelectLocationPo.getName());
				}
				hideOverContextView();
				mElderlyLocationWheel.releaseWheel();
				UserProfileManager.getInstance().alReadlyShowUserRegionTip();
			}
		});
		Rect rect = new Rect();
		mTxtRegion.getGlobalVisibleRect(rect);
		int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
				FrameLayout.LayoutParams.WRAP_CONTENT);
		lp.gravity = Gravity.CENTER;
		addOverContentView(sexCoverViewHeight, mElderlyLocationWheel, anim, lp);
	}

	// 添加guidview的圖片指導圖
	private void addOverContentView(int marginTop, View view, boolean anim, FrameLayout.LayoutParams params) {
		mOverView = showOverContextView(marginTop, anim);
		mOverView.removeAllViews();
		int margin = (int) ElderlyUtil.dip2px(getActivity(), 20);
		params.rightMargin = margin;
		params.leftMargin = margin;
		mOverView.addView(view, params);
	}

}
