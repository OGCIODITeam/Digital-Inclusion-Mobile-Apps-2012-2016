package com.elderly.elderly.fragment.map;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.ar.lbs.manager.PositionManager;
import com.ar.lbs.pojo.TargetData;
import com.ar.lbs.pojo.callback.TargetDataOnDrawListener;
import com.ar.lbs.ui.CampassDrawingView;
import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.elderly.elderly.util.ElderlyUtil;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.model.LatLng;

public class ARFragment extends TempleteFragment implements TargetDataOnDrawListener {

	// list
	private List<ActivityDetailAO> detailAOList = new ArrayList<ActivityDetailAO>();

	// Lbs
	private CampassDrawingView campassDrawingView;

	// onDraw
	private Bitmap bgBitmap;
	private Paint textPaint;
	private String distanceMark = "";
	private float targetWidth;
	private float targetHeight;
	private float textSizeStd = 0;
	private ActivityDetailAO activityDetailAO;

	private void logCat(String string) {
		Log.d("", "Ar >>> " + string);
	}

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		locationManager = (LocationManager) getMainActivity().getSystemService(Context.LOCATION_SERVICE);
		checkGooglePlayServiceAvailability(4056);
		restartLocationClient();
		showBackBtn(true);
		hideRightBtn();
		setTitle(R.string.page_googlemap_ar);
		inflater.inflate(R.layout.ar_lbs_view, mLayerContextView);
		campassDrawingView = (CampassDrawingView) mLayerContextView.findViewById(R.id.ar_lbs_display_view);

		// testing mode for display compass degree
		campassDrawingView.setTestingMode(false);

		initDrawParams();
		initAR();
	}

	@Override
	public void onResume() {
		super.onResume();
		campassDrawingView.onResume();
	}

	@Override
	public void onStop() {
		super.onStop();
		campassDrawingView.onPause();
		removeAllLocationUpdates();
		if (locationClient.isConnected()) {
			locationClient.disconnect();
		}
	}

	private void initDrawParams() {
		textPaint = new Paint();
		textPaint.setAntiAlias(true);
		textPaint.setColor(Color.WHITE);
		textPaint.setStrokeWidth(getResources().getDimension(R.dimen.page_ar_center_line_size));
		textPaint.setTextSize(textSizeStd);
		distanceMark = getString(R.string.common_metter);
		textSizeStd = getResources().getDimension(R.dimen.page_ar_txt_distance_text);
		bgBitmap = BitmapFactory.decodeResource(getResources(), Constants.getArBackGound(getHeaderType()));
		targetWidth = ElderlyUtil.getScreenWidth(getActivity()) * 0.7F;
		targetHeight = targetWidth / bgBitmap.getWidth() * bgBitmap.getHeight();
	}

	private void initAR() {
		// TODO setMockLocation for testing HKGT: 22.309908, 114.221581

		Bundle bundle = getArguments();

		if (bundle != null) {
			activityDetailAO = (ActivityDetailAO) bundle.getSerializable(MapFragment.KEY_ACTIVITY_DETAIL);
		}

		if (activityDetailAO != null) {
			detailAOList.add(activityDetailAO);
		}
//		PositionManager.getInstance(getActivity()).setMockLocation(getMockLocation());
		// testing range = 10000m
		PositionManager.getInstance(getActivity()).setDisplayRange(100000);
		setupDisplayList();
	}

	private Location getMockLocation() {
		// HKGT: 22.309908, 114.221581
		Location mockLocation = new Location(LocationManager.NETWORK_PROVIDER);
		// try {
		// mockLocation.setLatitude(Double.parseDouble(activityDetailAO.getLatitude()));
		// mockLocation.setLongitude(Double.parseDouble(activityDetailAO.getLongitude()));
		// } catch (Exception e) {
		mockLocation.setLatitude(23.131344);
		mockLocation.setLongitude(113.312931);
		// }
		return mockLocation;
	}

	private void addDummyActivityDetailAOList() {
		// 22.309719,114.221785
		// ActivityDetailAO object0 = new ActivityDetailAO();
		// object0.setActiveArea_tc("1.香港仔街坊會");
		// object0.setActivityCenterName_tc("街街街街街街街街街街街街街街中心111");
		// object0.setLocation_tc("九龍旺角新世界廣場1111");
		// object0.setLatitude("22.309719");
		// object0.setLongitude("114.221785");
		// detailAOList.add(object0);

		// 22.309789,114.221235
		// ActivityDetailAO object1 = new ActivityDetailAO();
		// object1.setActiveArea_tc("2.旺角街坊會");
		// object1.setActivityCenterName_tc("街街街街街中心222");
		// object1.setLocation_tc("九龍旺角新世界廣場222");
		// object1.setLatitude("22.309789");
		// object1.setLongitude("114.221235");
		// detailAOList.add(object1);
	}

	private void setupDisplayList() {
		// TODO
		addDummyActivityDetailAOList();

		// convert ActivityDetailAO to TargetData
		TargetData targetData;
		for (int i = 0; i < detailAOList.size(); i++) {
			targetData = new TargetData(i);
			targetData.setListener(this);

			try {
				targetData.setLatitude(Double.parseDouble(detailAOList.get(i).getLatitude()));
				targetData.setLongitude(Double.parseDouble(detailAOList.get(i).getLongitude()));
			} catch (Exception e) {
				e.printStackTrace();
			}
			campassDrawingView.getAllDataList().add(targetData);

			logCat("monsterData: " + i + " " + targetData.getLatitude() + " " + targetData.getLongitude());
		}
	}

	/**
	 * onDraw
	 */
	@Override
	public synchronized void onDrawCallback(Canvas canvas, Paint paint, int index, float userDistance, float screenX, float screenY, float movement) {
		logCat("dataOnDraw: index " + index);

		if (index < detailAOList.size()) {
			ActivityDetailAO detailAO = detailAOList.get(index);
			logCat("dataOnDraw: detailAO " + detailAO);

			// bg image
			RectF bgRectF = new RectF();
			bgRectF.left = (float) movement - (float) targetWidth / 2F;
			bgRectF.top = (float) screenY / 2F - (float) targetHeight * 1.2F;
			bgRectF.right = bgRectF.left + targetWidth;
			bgRectF.bottom = bgRectF.top + targetHeight;

			Matrix bgMatrix = new Matrix();
			bgMatrix.postScale(targetWidth / bgBitmap.getWidth(), targetHeight / bgBitmap.getHeight());
			bgMatrix.postTranslate(bgRectF.left, bgRectF.top);
			canvas.drawBitmap(bgBitmap, bgMatrix, paint);

			// line
			float paddingWidth = bgRectF.width() * 0.05F;
			float linePosY = bgRectF.top + bgRectF.height() * 0.42F;
			canvas.drawLine(bgRectF.left + paddingWidth, linePosY, bgRectF.right - paddingWidth, linePosY, textPaint);

			Rect textRect = new Rect();
			String displayText = "";

			// top text 2 - center name
			displayText = detailAO.getActivityCenterName();
			calTextSizeLimit(bgRectF.width(), displayText, textRect);
			float topText2PosY = linePosY - textRect.height() * 0.51F;
			canvas.drawText(displayText, bgRectF.left + bgRectF.width() / 2F - textRect.width() / 2F, topText2PosY, textPaint);

			// top text 1 - organization name
			displayText = detailAO.getActiveArea();
			float topText1PosY = linePosY - textRect.height() * 1.51F;
			calTextSizeLimit(bgRectF.width(), displayText, textRect);
			topText1PosY -= textRect.height() * 0.51F;
			canvas.drawText(displayText, bgRectF.left + bgRectF.width() / 2F - textRect.width() / 2F, topText1PosY, textPaint);

			// bottom text 1 - distance in meter
			displayText = userDistance + distanceMark;
			calTextSizeLimit(bgRectF.width(), displayText, textRect);
			float bottomText1PosY = linePosY + textRect.height() * 1.51F;
			canvas.drawText(displayText, bgRectF.left + bgRectF.width() / 2F - textRect.width() / 2F, bottomText1PosY, textPaint);

			// bottom text 2 - location address
			displayText = detailAO.getActivityCenterName();
			calTextSizeLimit(bgRectF.width(), displayText, textRect);
			float bottomText2PosY = bottomText1PosY + textRect.height() * 1.51F;
			canvas.drawText(displayText, bgRectF.left + bgRectF.width() / 2F - textRect.width() / 2F, bottomText2PosY, textPaint);
		}
	}

	private void calTextSizeLimit(float width, String text, Rect textRect) {
		textPaint.setTextSize(textSizeStd);
		textPaint.getTextBounds(text, 0, text.length(), textRect);
		while (textRect.width() > width * 0.95F) {
			textPaint.setTextSize(textPaint.getTextSize() - 0.2F);
			textPaint.getTextBounds(text, 0, text.length(), textRect);
		}
	}

	/////////////////////获取当前位置lat lot 然后设定mockposition为此值/////////////////////
	
	private Location lastLocation;
	private LocationManager locationManager;
	private LocationClient locationClient;
	private LocationCallback mLocationCallback = new LocationCallback();
	private android.location.LocationListener gpsListener = new LocManagerListener();
	private android.location.LocationListener networkListener = new LocManagerListener();

	private class LocationCallback implements LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			if (location == null) {
				Log.v("ARFragment", "onLocationChanged: location == null");
				return;
			}
			if (!location.equals(lastLocation)) {
				handleLocation(location);
				lastLocation = location;
			}

		}
	}

	private class LocManagerListener implements android.location.LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			if (!location.equals(lastLocation)) {
				handleLocation(location);
				lastLocation = location;
			}
		}

		@Override
		public void onStatusChanged(String s, int i, Bundle bundle) {

		}

		@Override
		public void onProviderEnabled(String s) {

		}

		@Override
		public void onProviderDisabled(String s) {

		}
	}

	private void handleLocation(Location location) {
		// Update the mLocationStatus with the lat/lng of the location
		double latitude = location.getLatitude();
		double longitude = location.getLongitude();
		Location mockLocation = new Location(LocationManager.NETWORK_PROVIDER);
		mockLocation.setLatitude(latitude);
		mockLocation.setLongitude(longitude);
		PositionManager.getInstance(getActivity()).setMockLocation(mockLocation);
	}

	private boolean haveLocationProvider() {
		return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
	}

	private void removeAllLocationUpdates() {
		if (locationClient.isConnected()) { // verify that locationClient is connected and remove updates
			locationClient.removeLocationUpdates(mLocationCallback);
		}

		// remove updates from location manager
		locationManager.removeUpdates(gpsListener);
		locationManager.removeUpdates(networkListener);

	}

	private void init() {
		// initializing, connecting locationClient
		if (locationClient == null) {
			locationClient = new LocationClient(getMainActivity(), connectionListener, failedListener);
			if (!(locationClient.isConnected() || locationClient.isConnecting())) {
				locationClient.connect();
			}
		}
	}

	private void restartLocationClient() {
		if (!(locationClient.isConnected() || locationClient.isConnecting())) {
			locationClient.connect();
			return;
		}
		// already connected, ok to request updates
		requestAllLocationUpdates();
	}

	private void requestAllLocationUpdates() {
		requestFusedLocationUpdates();
		requestGpsLocationUpdates();
		requestNetworkLocationUpdates();
	}

	private void requestFusedLocationUpdates() {
		// verify location client is connected, then request updates
		if (locationClient.isConnected()) {
			LocationRequest request = LocationRequest.create().setInterval(10000).setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
			locationClient.requestLocationUpdates(request, mLocationCallback);
		}
	}

	private void requestGpsLocationUpdates() {
		// request gps updates with no minimum movement time requirements
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, gpsListener);
	}

	private void requestNetworkLocationUpdates() {
		// request gps updates with no minimum movement time requirements
		locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, networkListener);
	}

	private ConnectionCallbacks connectionListener = new ConnectionCallbacks() {

		@Override
		public void onDisconnected() {
			// play services disconnected
		}

		@Override
		public void onConnected(Bundle arg0) {
			// play services connected

			// connected, move map to last known location
			Location location = locationClient.getLastLocation();
			if (location != null) {
				LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
				handleLocation(location);
			}

			// request location updates
			requestAllLocationUpdates();

		}
	};
	private OnConnectionFailedListener failedListener = new OnConnectionFailedListener() {

		@Override
		public void onConnectionFailed(ConnectionResult connectionResult) {
		}

	};

	private void checkGooglePlayServiceAvailability(int requestCode) {
		// Query for the status of Google Play services on the device
		int statusCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getMainActivity());

		if (statusCode == ConnectionResult.SUCCESS) {
			// GooglePlayService available, initialize locationClient
			init();
		} else {
			if (GooglePlayServicesUtil.isUserRecoverableError(statusCode)) {
				// play service has a recoverable error, show dialog
			} else {}
		}
	}
}
