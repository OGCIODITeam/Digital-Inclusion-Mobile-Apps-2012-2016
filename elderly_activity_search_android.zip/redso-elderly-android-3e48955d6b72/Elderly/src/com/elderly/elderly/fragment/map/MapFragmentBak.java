package com.elderly.elderly.fragment.map;

import java.util.List;

import android.content.Context;
import android.location.Criteria;
import android.location.GpsStatus;
import android.location.GpsStatus.Listener;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.elderly.elderly.R;
import com.elderly.elderly.ar.ArCameraView;
import com.elderly.elderly.ar.LocationUtil;
import com.elderly.elderly.ar.SensorUtil;
import com.elderly.elderly.ar.SensorUtil.OrientationChangeListener;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationChangeListener;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapFragmentBak extends TempleteFragment implements ConnectionCallbacks, OnConnectionFailedListener,
		LocationListener, OnMyLocationChangeListener, android.location.LocationListener, InfoWindowAdapter, OnMarkerClickListener, OnInfoWindowClickListener, OrientationChangeListener {
	private static final String TAG = "MapFragment";
	private GoogleMap mGoogleMap;
	private static final String MAP_KEY = "MapFragment";
	private boolean mIsSupportGoogleMap;
	private SupportMapFragment mGoogleMapFragment;
	private LocationClient mLocationClient;
	private LocationRequest mLocationRequest;
	private boolean mIsFirstToMyLocation;
	// 定义LocationManager对象
	private LocationManager mLocationManager;
	private Location mLocation;
	private String mBestProvider;
	private double workplace[] = new double[] { 23.128491, 113.318705 };//第一个参数是纬度,第二个参数是经度
	private double school[] = new double[] { 23.129345,113.320106 };

//	private View mLayerLoading;
	private View mLayerMap;
	private ArCameraView mLayerAR;
	private View mLayerContext;
	private View mBtnAR;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
//		setHeaderBgColor(R.color.header_Setting);
		
		double angle=LocationUtil.angle(23.129991, 113.318705, 23.129992, 113.318706);
		Log.v(TAG, "angle>>"+angle);
		double distance=LocationUtil.getDistance(23.129991, 113.318705, 23.129991, 113.318701);
		Log.v(TAG, "distance>>"+distance);
		inflater.inflate(R.layout.page_map, mLayerContextView);
//		mLayerLoading = mLayerContextView.findViewById(R.id.page_map_mLayerLoading);
		mLayerMap = mLayerContextView.findViewById(R.id.page_map_mLayerMap);
		mLayerContext=mLayerContextView.findViewById(R.id.page_map_mLayerContext);
//		mLayerAR=(ArCameraView) mLayerContextView.findViewById(R.id.page_map_mLayerAR);
		mBtnAR=mLayerContextView.findViewById(R.id.page_map_mBtnAR);
		
//		mLayerLoading.setVisibility(View.VISIBLE);
//		mLayerMap.setVisibility(View.INVISIBLE);
//		mLayerContext.setVisibility(View.INVISIBLE);
		showLocation(true);
		setTitle(R.string.header_map);
		mIsFirstToMyLocation = false;
		int result = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity());
		if (result == ConnectionResult.SUCCESS) {
			mIsSupportGoogleMap = true;
		} else {
			mIsSupportGoogleMap = false;
		}
		if (mIsSupportGoogleMap) {
			GoogleMapOptions gmo = new GoogleMapOptions();
			gmo.compassEnabled(false);
			gmo.rotateGesturesEnabled(false);
			gmo.zoomControlsEnabled(false);
			gmo.zOrderOnTop(false);
			gmo.useViewLifecycleInFragment(true);
			gmo.mapType(GoogleMap.MAP_TYPE_NORMAL);
			mGoogleMapFragment = SupportMapFragment.newInstance(gmo);
			FragmentTransaction ft = getChildFragmentManager().beginTransaction();
			// ft.attach(mGoogleMapFragment);
			ft.add(mLayerMap.getId(), mGoogleMapFragment, MAP_KEY);
			ft.commitAllowingStateLoss();

		}
		setupListener();
	}

	private void setupListener() {
		mBtnAR.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(mLayerAR.getVisibility()==View.VISIBLE){
					mLayerAR.setVisibility(View.GONE);
				}else{
					mLayerAR.setVisibility(View.VISIBLE);
				}
			}
		});
	}

	@Override
	public void onResume() {
		super.onResume();
		SensorUtil.getInstance().setOrientationChangeListener(this);
		SensorUtil.getInstance().start();
//		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//
//			@Override
//			public void run() {
//				mLayerLoading.setVisibility(View.INVISIBLE);
//				mLayerContext.setVisibility(View.VISIBLE);
//				mLayerMap.setVisibility(View.VISIBLE);
//
//			}
//		}, 800);
		if (mGoogleMapFragment != null) {
			mGoogleMap = mGoogleMapFragment.getMap();
			// Log.v(TAG, "google map>>"+mGoogleMap);
			if (mGoogleMap != null) {
				mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
				mGoogleMap.setMyLocationEnabled(true);
				mGoogleMap.setInfoWindowAdapter(this);
				mGoogleMap.setOnInfoWindowClickListener(this);
				mGoogleMap.setOnMarkerClickListener(this);
				mGoogleMap.setOnMyLocationChangeListener(MapFragmentBak.this);
				if (!mIsFirstToMyLocation && mGoogleMap.getMyLocation() != null) {
					initToMyLocation(mGoogleMap.getMyLocation());
				}
				mGoogleMap.moveCamera(CameraUpdateFactory.zoomTo(18));
				mGoogleMap.addMarker(new MarkerOptions().position(new LatLng(workplace[0], workplace[1]))
						.icon(BitmapDescriptorFactory.fromResource(R.drawable.ico_position_blue)).title("三新大厦"));
				mLocationClient = new LocationClient(getActivity(), MapFragmentBak.this, MapFragmentBak.this);
				mLocationClient.connect();
				// initProvider();
			} else {
				Log.v(TAG, "google map == null");
			}
		}

	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		mIsFirstToMyLocation = false;
		if (mIsSupportGoogleMap && mGoogleMapFragment != null) {
			FragmentTransaction ft = getChildFragmentManager().beginTransaction();
			ft.remove(mGoogleMapFragment);
		}
		if (mLocationClient != null && mLocationClient.isConnected()) {
			mLocationClient.removeLocationUpdates(this);
			mLocationClient.disconnect();
		}
		if (mLocationManager != null) {
			mLocationManager.removeUpdates(this);
			mLocationManager.removeGpsStatusListener(mGpsStatusListner);
		}
		mGoogleMap = null;

	}
	
	@Override
	public void onStop() {
		super.onStop();
		SensorUtil.getInstance().setOrientationChangeListener(null);
		SensorUtil.getInstance().stop();
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		Log.v(TAG, "onConnectionFailed>>");
	}

	@Override
	public void onConnected(Bundle bundle) {
		// TODO Auto-generated method stub
//		Log.v(TAG, "onConnected>>" + bundle);
		mLocationRequest = LocationRequest.create()
				.setInterval(10 * 1000)
				.setFastestInterval(100)
				.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
		mLocationClient.requestLocationUpdates(mLocationRequest, this);
		if (mLocationClient.getLastLocation() != null) {
			Log.v(TAG, "get last location>>" + mLocationClient.getLastLocation().getLatitude() + ","
					+ mLocationClient.getLastLocation().getLongitude());
		}
		if (mGoogleMap != null && mLocationClient != null && mLocationClient.getLastLocation() != null
				&& !mIsFirstToMyLocation) {
			initToMyLocation(mLocationClient.getLastLocation());
		}
	}

	@Override
	public void onDisconnected() {
		Log.v(TAG, "onDisconnected>>");

	}

	@Override
	public void onLocationChanged(Location location) {
		if (location != null) {
//			Log.v(TAG, "onLocationChanged>>" + location.getLatitude() + "," + location.getLongitude());
			if (mGoogleMap != null && !mIsFirstToMyLocation) {
				initToMyLocation(location);
			}
		}
	}

	private void initToMyLocation(Location location) {
		if (mGoogleMap != null) {
			mIsFirstToMyLocation = true;
			mGoogleMap
					.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(location.getLatitude(), location
							.getLongitude())));
		}
	}

	private void animToMyLocation(Location location) {
		mIsFirstToMyLocation = true;
		mGoogleMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(location.getLatitude(), location
				.getLongitude())));
	}

	@Override
	public void headerBtnClick(View view) {
		super.headerBtnClick(view);
		if (view.getId() == R.id.page_templete_mBtnLocation) {
			if (mGoogleMap != null && mGoogleMap.getMyLocation() != null) {
				animToMyLocation(mGoogleMap.getMyLocation());
			}

		}
	}

	@Override
	public void onMyLocationChange(Location location) {
//		Log.v(TAG, "onMyLocationChange>>" + location.getLatitude() + "," + location.getLongitude());
		if (location != null) {
			if (!mIsFirstToMyLocation) {
				initToMyLocation(location);
			}
		}
	}

	private void initProvider() {
		// 创建LocationManager对象
		mLocationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
		// List all providers:
		List<String> providers = mLocationManager.getAllProviders();
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_MEDIUM); // 高精度
		criteria.setAltitudeRequired(false);
		criteria.setBearingRequired(false);
		criteria.setCostAllowed(true);
		mBestProvider = mLocationManager.getBestProvider(criteria, false);
		mLocation = mLocationManager.getLastKnownLocation(mBestProvider);
		if (mLocation != null) {
			Log.v(TAG, "经度：" + mLocation.getLatitude() + "  纬度：" + mLocation.getLongitude());
		}
		mLocationManager.addGpsStatusListener(mGpsStatusListner);
		mLocationManager.requestLocationUpdates(mBestProvider, 5 * 1000, 10, this);
		if (mGoogleMap != null && mLocation != null) {
			mGoogleMap.addMarker(new MarkerOptions().icon(
					BitmapDescriptorFactory.fromResource(R.drawable.ico_position_blue)).position(
					new LatLng(mLocation.getLatitude(), mLocation.getLongitude())));
		}
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		Log.i(TAG, "onStatusChanged>>" + provider + ",status>>" + status);
	}

	@Override
	public void onProviderEnabled(String provider) {
		Log.i(TAG, "onProviderEnabled>>" + provider);
	}

	@Override
	public void onProviderDisabled(String provider) {
		Log.i(TAG, "onProviderDisabled>>" + provider);
	}

	Listener mGpsStatusListner = new Listener() {

		@Override
		public void onGpsStatusChanged(int event) {
			switch (event) {
			case GpsStatus.GPS_EVENT_STARTED:
				Log.i(TAG, "onGpsStatusChanged>>GPS_EVENT_STARTED");
				break;
			case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
				Log.i(TAG, "onGpsStatusChanged>>GPS_EVENT_SATELLITE_STATUS");
				mLocation = mLocationManager.getLastKnownLocation(mBestProvider);
				if (mLocation != null) {
					Log.v(TAG, "经度：" + mLocation.getLatitude() + "  纬度：" + mLocation.getLongitude());
				}
				break;
			case GpsStatus.GPS_EVENT_FIRST_FIX:
				Log.i(TAG, "onGpsStatusChanged>>GPS_EVENT_FIRST_FIX");
				break;
			case GpsStatus.GPS_EVENT_STOPPED:
				Log.i(TAG, "onGpsStatusChanged>>GPS_EVENT_STOPPED");
				break;
			default:
				Log.v(TAG, "other GPS status");
			}
		}
	};

	@Override
	public View getInfoContents(Marker marker) {
		TextView view=new TextView(getActivity());
		view.setText("aaaaaaa\naaaaaaa");
		view.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getActivity(), "click aaa", Toast.LENGTH_SHORT).show();
			}
		});
		return view;
	}

	@Override
	public View getInfoWindow(Marker marker) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean onMarkerClick(Marker marker) {
		Log.v(TAG, "onMarkerClick>>"+marker.getTitle()+",mGoogleMap>>"+mGoogleMap.getProjection().getVisibleRegion());
		return false;
	}

	@Override
	public void onInfoWindowClick(Marker marker) {
		Log.v(TAG, "onInfoWindowClick>>"+marker.getTitle());
		
	}

	@Override
	public void onChange(float[] value) {
		double angle=LocationUtil.angle(workplace[1], workplace[0],school[1], school[0]);
		Log.v(TAG, "value>>"+value[0]+",angle>>"+angle);
	}


}
