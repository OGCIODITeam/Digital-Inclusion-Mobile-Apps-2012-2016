package com.elderly.elderly.fragment;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyWebView;
import com.elderly.elderly.component.ElderlyWebView.OnScrollChangeListener;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.util.ElderlyUtil;

public class BrowseFragment extends TempleteFragment {
	private static final String TAG = "BrowseFragment";
	public static final String KEY_STORE_URL = "key_store_url";
	public static final String KEY_SHOW_ARROW = "key_show_arrow";
	private ElderlyWebView mWebView;
	private String mUrl;
	ProgressDialog progressDialog;
	private View mLayerBottomArrow;
	private View mLayerTopArrow;
	private boolean mShowArrow;
    LinearLayout rootView;
	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_browse, mLayerContextView);
		hideRightBtn();
		if (getTitleId() <= 0) {
			setTitle(R.string.header_app_browse);
		} else {
			setTitle(getTitleId());
		}
		if (getArguments() != null) {
			mUrl = getArguments().getString(KEY_STORE_URL);
			mShowArrow = getArguments().getBoolean(KEY_SHOW_ARROW, true);
		}
		mWebView = (ElderlyWebView) mLayerContextView.findViewById(R.id.page_browse_mWebView);
        rootView = (LinearLayout) mLayerContextView.findViewById(R.id.root);

        mLayerBottomArrow = mLayerContextView.findViewById(R.id.page_browse_mLayerBottomArrow);
		mLayerTopArrow = mLayerContextView.findViewById(R.id.page_browse_mLayerTopArrow);
		WebSettings settings = mWebView.getSettings();
		settings.setJavaScriptEnabled(true);
		settings.setUseWideViewPort(true);
		settings.setSupportZoom(true);
		settings.setBuiltInZoomControls(true);
		settings.setDomStorageEnabled(true);
		settings.setLoadWithOverviewMode(true);
		if (Build.VERSION.SDK_INT >= 11) {
			mWebView.setLayerType(WebView.LAYER_TYPE_SOFTWARE, null);
		}
		mWebView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				super.onProgressChanged(view, newProgress);
				if (newProgress > 80) {
					closeLoading();
					hideLoadingView();
				}
				checkScrollState();
			}
		});


		mWebView.setWebViewClient(new WebViewClient() {

			@Override
			public void onFormResubmission(WebView view, Message dontResend, Message resend) {
				resend.sendToTarget();
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				Log.v(TAG, "onPageStarted>>" + url);
				super.onPageStarted(view, url, favicon);
				// showLoading(true);
				showLoadingView();
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				Log.v(TAG, "onPageFinished>>" + url);
				super.onPageFinished(view, url);
				// closeLoading();
				hideLoadingView();
				if (mWebView != null) {
					mWebView.postDelayed(mCheckScrollStatusRunnable, 500);
				}

			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				Log.v(TAG, "shouldOverrideUrlLoading>>" + url);
				if (url != null && (url.startsWith("tel:") || url.startsWith("mailto:"))) {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					startActivity(intent);
					return true;
				} else {
					mShowArrow = false;
				}
				view.loadUrl(url);
				return true;
			}
		});
		mWebView.setOnScrollChangeListener(new OnScrollChangeListener() {

			@Override
			public void onScrollChanged(int l, int t, int oldl, int oldt) {
				checkScrollState();
			}
		});
		
		ElderlyUtil.isConnectNetWork(getActivity());
		if (mUrl != null) {
			mWebView.loadUrl(mUrl);
		}

//        rootView.setContentDescription(getString(R.string.voice_about));
        rootView.requestFocus();

    }

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		mWebView.removeCallbacks(mCheckScrollStatusRunnable);
		if (mWebView != null) {
			mWebView.stopLoading();
			mWebView.clearCache(true);
		}
		mWebView = null;
		if (progressDialog != null) {
			progressDialog.cancel();
		}
	}

	Runnable mCheckScrollStatusRunnable = new Runnable() {

		@Override
		public void run() {
			checkScrollState();

		}
	};

	private void showLoading(boolean canCloseDialog) {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(getMainActivity());
			progressDialog.setTitle(R.string.common_dialog_title);
			progressDialog.setMessage(getMainActivity().getString(R.string.common_loading));
			progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			progressDialog.setCanceledOnTouchOutside(false);
			progressDialog.setCanceledOnTouchOutside(false);
			if (!canCloseDialog) {
				progressDialog.setOnKeyListener(new OnKeyListener() {
					@Override
					public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
						if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) { // 按下的如果是BACK，同时没有重复
							return true;
						}
						return false;

					}
				});
			}

		}

		progressDialog.show();
	}

	private void closeLoading() {

		if (progressDialog != null) {
			try {
				progressDialog.hide();
				progressDialog.cancel();
				progressDialog = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent keyEvent) {
		if (keyCode == KeyEvent.KEYCODE_BACK && isShowLoadingView()) {
			hideLoadingView();
			return true;
		}
		return super.onKeyUp(keyCode, keyEvent);
	}

	private void checkScrollState() {
		if (mShowArrow) {
			if(mWebView==null){
				return;
			}
			float webViewContentHeight = mWebView.getContentHeight() * mWebView.getScale();
			float webViewCurrentHeight = (mWebView.getHeight() + mWebView.getScrollY());
			Log.v(TAG, "checkScrollState>>" + webViewContentHeight + "," + webViewCurrentHeight);
			if (webViewContentHeight > mWebView.getHeight()) {
				if (webViewContentHeight == webViewCurrentHeight) {
					showTopArrow();
				} else {
					showBottomArrow();
				}
			} else {
				hideArrow();
			}
		} else {
			hideArrow();
		}
	}

	private void showTopArrow() {
		mLayerTopArrow.setVisibility(View.VISIBLE);
		mLayerBottomArrow.setVisibility(View.INVISIBLE);

	}

	private void showBottomArrow() {
		mLayerTopArrow.setVisibility(View.INVISIBLE);
		mLayerBottomArrow.setVisibility(View.VISIBLE);

	}

	private void hideArrow() {
		mLayerTopArrow.setVisibility(View.INVISIBLE);
		mLayerBottomArrow.setVisibility(View.INVISIBLE);
	}

}
