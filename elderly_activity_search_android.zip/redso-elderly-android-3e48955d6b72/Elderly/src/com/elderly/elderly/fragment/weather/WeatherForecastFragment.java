package com.elderly.elderly.fragment.weather;

import java.util.Calendar;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ListView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.WeatherForecastAdapter;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.ao.WeatherAO;
import com.gt.cl.util.CLDateUtil;

public class WeatherForecastFragment extends TempleteFragment {
	private WeatherAO mWeatherAO;
	public static final String STORE_KEY_DATA="store_key_data";
	private ListView mLvWeather;
	private WeatherForecastAdapter mAdapter;
	private Calendar mCalendar;
	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_weather_forecast, mLayerContextView);
		mLvWeather=(ListView) mLayerContextView.findViewById(R.id.page_weather_forecast_mLvWeather);
		setupData();
		setHeaderBgColor(R.color.header_trasparent);
		setTitle(R.string.header_weather_forecast);
	}
	private void setupData() {
		mAdapter=new WeatherForecastAdapter(getActivity());
		if(getArguments()!=null){
			mWeatherAO=(WeatherAO) getArguments().getSerializable(STORE_KEY_DATA);
			mAdapter.setWeatherAO(mWeatherAO);
		}
		mCalendar = Calendar.getInstance();
		int hour = mCalendar.get(Calendar.HOUR_OF_DAY);
		if (hour >= 19 || hour <= 6) {
			getRootView().setBackgroundResource(R.drawable.bg_night_sun);
		} else {
			getRootView().setBackgroundResource(R.drawable.bg_daytime_sun);
		}
		mLvWeather.setAdapter(mAdapter);
		
	}

}
