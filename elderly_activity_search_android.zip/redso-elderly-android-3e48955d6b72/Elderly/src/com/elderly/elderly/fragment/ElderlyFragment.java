package com.elderly.elderly.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;

import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.util.ElderlyAsyncTask;

public class ElderlyFragment extends Fragment implements AnimationListener {
	private static final String TAG = "ElderlyFragment";
	private int mAnimationId = 0;
	private FragmentAnimationEndListener mFragmentAnimationEndListener;
	private ElderlyAsyncTask mCurrentAsyncTask;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		getMainActivity().getElderlyApplication().updateLanguage(getMainActivity());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		getMainActivity().getElderlyApplication().updateLanguage(getMainActivity());
		Log.v(TAG, "onCreateView>>" + getTag());
		if (mCurrentAsyncTask != null) {
			mCurrentAsyncTask.checkStatus();
		} else {
			Log.v(TAG, "mCurrentAsyncTask>>null");
		}
		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
		if (getView() != null) {
			if (mAnimationId != 0) {
				getView().clearAnimation();
				Animation animation = null;
				animation = AnimationUtils.loadAnimation(getActivity(), mAnimationId);
				if (animation != null) {
					animation.setAnimationListener(this);
					getView().startAnimation(animation);
				}
				mAnimationId = 0;
				return null;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public void setAnimationAction(int mAnimationId) {
		this.mAnimationId = mAnimationId;
	}

	public MainActivity getMainActivity() {
		return (MainActivity) getActivity();
	}

	@Override
	public void onAnimationStart(Animation animation) {

	}

	@Override
	public void onAnimationEnd(Animation animation) {
		if (mFragmentAnimationEndListener != null) {
			mFragmentAnimationEndListener.onAnimationEnd(this);
			mFragmentAnimationEndListener = null;
		}
	}

	@Override
	public void onAnimationRepeat(Animation animation) {

	}

	public interface FragmentAnimationEndListener {
		public void onAnimationEnd(ElderlyFragment fragment);
	}

	public void setFragmentAnimationEndListener(FragmentAnimationEndListener mFragmentAnimationEndListener) {
		this.mFragmentAnimationEndListener = mFragmentAnimationEndListener;
	}

	public NavigationFragment getTabNavigationFragment() {
		return (NavigationFragment) getParentFragment();
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		Log.v(TAG, "onDestroyView>>" + getTag());
	}

	public boolean onKeyUp(int keyCode, KeyEvent keyEvent) {
		return false;
	}

	protected void onFragmentPop() {
		if (mCurrentAsyncTask != null) {
			mCurrentAsyncTask.cancel(true);
		}
	}

	protected void onFragmentPush(){
		if(mCurrentAsyncTask!=null&&mCurrentAsyncTask.isRunning()&&mCurrentAsyncTask.cancelOnFragmentPush()){
			mCurrentAsyncTask.cancel(true);
		}
	}

	public void setCurrentAsyncTask(ElderlyAsyncTask mCurrentAsyncTask) {
		this.mCurrentAsyncTask = mCurrentAsyncTask;
	}

}
