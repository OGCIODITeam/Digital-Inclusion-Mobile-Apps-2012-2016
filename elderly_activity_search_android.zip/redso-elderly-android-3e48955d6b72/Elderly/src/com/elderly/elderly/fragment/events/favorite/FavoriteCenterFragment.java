package com.elderly.elderly.fragment.events.favorite;

import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.FrameLayout;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.MyFavoriteCenterAdapter;
import com.elderly.elderly.component.ElderlyExpandListView;
import com.elderly.elderly.component.ElderlyMonthPicker;
import com.elderly.elderly.component.ElderlyMonthSelect;
import com.elderly.elderly.component.ElderlySimplyCalendar;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

import org.xmlpull.v1.XmlPullParserException;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import lib.gt.ga.v2.GAManager;

public class FavoriteCenterFragment extends TempleteFragment {
    private static final String TAG = "FavoriteCenterFragment";

    protected ElderlyMonthPicker mElderlyMonthPicker;
    private ElderlyMonthSelect mElderlyMonthSelect;
    protected ElderlySimplyCalendar mElderlySimplyCalendar;
    protected ElderlyExpandListView mElderlyExpandListView;
    protected FrameLayout mOverContextView;
    private List<CommunityCentreAO> mMyCommunityCentreAO;
    private List<CommunityCentreAO> mValidCommunityCentreAO;
    private TreeMap<String, List<ActivityAO>> mActivityData;
    private MyFavoriteCenterAdapter mAdapter;
    private ElderlyAsyncTask<Void, Void, Void> mAsyncTask;
    private Date mLastCallApiMonth;

    @Override
    public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {

        inflater.inflate(R.layout.page_favour_centre_activity, mLayerContextView);
        mElderlyMonthPicker = (ElderlyMonthPicker) mLayerContextView
                .findViewById(R.id.page_my_activity_mElderlyMonthPicker);
        mElderlyExpandListView = (ElderlyExpandListView) mLayerContextView
                .findViewById(R.id.page_favour_centre_mElderlyExpandListView);
        setTitle(R.string.header_favorite_center);

        // set no reuslt tip
        if (UserProfileManager.getInstance().readMyCommunityCentre() == null
                || UserProfileManager.getInstance().readMyCommunityCentre().size() == 0) {
            mElderlyExpandListView.setTipsContent(R.string.common_favoriteCenter_no_result);
        }

        mMyCommunityCentreAO = UserProfileManager.getInstance().readMyCommunityCentre();
        if (mAdapter == null) {
            mAdapter = new MyFavoriteCenterAdapter(getMainActivity(), getHeaderType(), mElderlyExpandListView.getExpandableListView());
        }
        mElderlyExpandListView.setAdapter(mAdapter);
        if (mLastCallApiMonth != null) {
            mElderlyMonthPicker.setDate(mLastCallApiMonth);
        }
        if (mValidCommunityCentreAO == null) {
            mValidCommunityCentreAO = new ArrayList<CommunityCentreAO>();
        }
        setupListener();
        if (mActivityData == null) {
            callApi();
        }

        GAManager.getInstance().trackView(Constants.FAV_PG_FAVOURITECENTER);
    }

    private void setupListener() {
        if (mElderlyExpandListView != null) {
            mElderlyExpandListView.getExpandableListView().setOnChildClickListener(new OnChildClickListener() {

                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition,
                                            long id) {
                    ActivityAO ao = mAdapter.getChild(groupPosition, childPosition);
                    if (ao != null && ao.getId() != null) {
                        callActivityDetailApi(ao.getId(), ActivityDetailFragment.TYPE_ELDERLY);
//						Bundle bundle = new Bundle();
//						bundle.putString(ActivityDetailFragment.KEY_STORE_ID, ao.getId());
//						bundle.putString(ActivityDetailFragment.KEY_STORE_TYPE, "E");
//						bundle.putString(HEADER_TYPE, getHeaderType().name());
//						ActivityDetailFragment adf = new ActivityDetailFragment();
//						adf.setArguments(bundle);
//						getTabNavigationFragment().push(adf);
                    }
                    return false;
                }
            });
        }


        mElderlyMonthPicker.setMonthPickerListener(new ElderlyMonthPicker.MonthPickerListener() {

            @Override
            public void onPickerDateChange(Date currentData) {
                GAManager.getInstance().trackEvent(Constants.MY_DATE,
                        Constants.GA_ACTION_CLICK, "");
                onDateChange(currentData);
            }

            @Override
            public void onClick(View view, Date currentDate) {
                GAManager.getInstance().trackEvent(Constants.MY_DATE,
                        Constants.GA_ACTION_CLICK, "");
                mOverContextView = showOverContextView(0, false);
                if (mElderlyMonthSelect == null) {
                    mElderlyMonthSelect = new ElderlyMonthSelect(
                            getMainActivity());
                    mElderlyMonthSelect
                            .setOnCalendarClickListener(new ElderlyMonthSelect.OnCalendarClickListener() {

                                @Override
                                public void onClick(Date selectDay) {
                                    mElderlyMonthPicker.setDate(selectDay);
                                    hideOverContextView();
                                    onPickerDateChange(selectDay);
                                }
                            });

                }
                mElderlyMonthSelect.updateSelectedCalendar(currentDate);
                mElderlyMonthSelect.updateCalendar();
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT);
                lp.gravity = Gravity.CENTER;
                lp.leftMargin = (int) getResources().getDimension(
                        R.dimen.view_calendar_margin_horizontal);
                lp.rightMargin = (int) getResources().getDimension(
                        R.dimen.view_calendar_margin_horizontal);
                mOverContextView.addView(mElderlyMonthSelect, lp);
                mOverContextView.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        hideOverContextView();

                    }
                });
                mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).setFocusable(true);
                mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).setFocusableInTouchMode(true);
                mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).requestFocus();
            }
        });

        new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

            }
        };


    }


//		mElderlyDayPicker.setDayPickerListener(new DayPickerListener() {
//
//			@Override
//			public void onClick(View view, Date currentDate) {
//				GAManager.getInstance().trackEvent(Constants.FAV_DATE, Constants.GA_ACTION_CLICK, "");
//				mOverContextView = showOverContextView(0, false);
//				if (mElderlySimplyCalendar == null) {
//					mElderlySimplyCalendar = new ElderlySimplyCalendar(getMainActivity());
//					mElderlySimplyCalendar.setWeekOfFirstDay(Calendar.SUNDAY);
//					mElderlySimplyCalendar.setOnCalendarClickListener(new OnCalendarClickListener() {
//
//						@Override
//						public void onClick(Date selectDay) {
//							mElderlyDayPicker.setDate(selectDay);
//							hideOverContextView();
//							mOverContextView.removeAllViews();
//							onPickerDateChange(selectDay);
//						}
//					});
//
//				}
//				mElderlySimplyCalendar.updateSelectedCalendar(currentDate);
//				mElderlySimplyCalendar.updateCalendar();
//				FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT,
//						LayoutParams.WRAP_CONTENT);
//				lp.gravity = Gravity.CENTER;
//				lp.leftMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
//				lp.rightMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
//				mOverContextView.addView(mElderlySimplyCalendar, lp);
//				mOverContextView.setOnClickListener(new View.OnClickListener() {
//
//					@Override
//					public void onClick(View v) {
//						hideOverContextView();
//
//					}
//				});
//				mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).setFocusable(true);
//				mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).setFocusableInTouchMode(true);
//				mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).requestFocus();
//			}
//
//			@Override
//			public void onPickerDateChange(Date currentData) {
//				GAManager.getInstance().trackEvent(Constants.FAV_DATE, Constants.GA_ACTION_CLICK, "");
//				onDateChange(currentData);
//			}
//		});
//	}


    private void callApi() {
        mAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity()) {

            @Override
            protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
                if (mMyCommunityCentreAO != null && mMyCommunityCentreAO.size() > 0) {
                    List<String> centreIds = new ArrayList<String>();
                    for (int i = 0; i < mMyCommunityCentreAO.size(); i++) {
                        CommunityCentreAO ao = mMyCommunityCentreAO.get(i);
                        if (ao.getVid() != null) {
                            Log.i(TAG, "centreIds>>>>>>" + ao.getNid());
                            centreIds.add(ao.getNid());
                        }
                    }
                    Date date = mElderlyMonthPicker.getDate();
                    mLastCallApiMonth = date;
                    String apiDate = CLDateUtil.formatDate(date, Constants.DATE_FORMAT_PATTERN_API2);
                    try {
                        mActivityData = ApiManager.getInstance().getMyFavouriteCentreActivity(apiDate, centreIds);
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }

                }
                return null;
            }

            @Override
            protected void doOnSuccess(Void result) {
                setupData();
            }

            @Override
            protected boolean showCustomLoading() {
                return true;
            }

            @Override
            protected void callCustomLoading() {
                showLoadingView();
            }

            @Override
            protected void cancelCustomLoading() {
                hideLoadingView();
                super.cancelCustomLoading();
            }

            @Override
            protected void onCancelled() {
                ApiManager.getInstance().cancelCallMyFavouriteCentre();
                super.onCancelled();
            }
        };
        setCurrentAsyncTask(mAsyncTask);
        mAsyncTask.execute((Void) null);
    }

    public void onDateChange(Date date) {
        mLastCallApiMonth = date;
        callApi();
    }

    private void setupData() {
        if (mMyCommunityCentreAO != null && mActivityData != null) {
            Log.v(TAG, "change data");
            mValidCommunityCentreAO.clear();
            for (int i = 0; i < mMyCommunityCentreAO.size(); i++) {
                CommunityCentreAO ao = mMyCommunityCentreAO.get(i);
                Iterator<Entry<String, List<ActivityAO>>> iterator = mActivityData.entrySet().iterator();
                while (iterator.hasNext()) {
                    Entry<String, List<ActivityAO>> data = iterator.next();
                    if (data.getKey().equals(ao.getNid())) {
                        mValidCommunityCentreAO.add(ao);
                        break;
                    }
                }

            }
            // Log.v(TAG,"mValidCommunityCentreAO>>"+mValidCommunityCentreAO.size());
            mAdapter.setGroupData(mValidCommunityCentreAO);

//            ValueComparator bvc =  new ValueComparator(mActivityData);
//            TreeMap<String, List<ActivityAO>> sorted_map = new TreeMap<String, List<ActivityAO>>(bvc);
            mAdapter.setTargetMonth(mLastCallApiMonth);
            mAdapter.setChildData(mActivityData, mLastCallApiMonth);


        }
    }




//    class ValueComparator implements Comparator<String> {
//
//        Map<String, List<ActivityAO>> base;
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//
//        public ValueComparator(Map<String, List<ActivityAO>> base) {
//            this.base = base;
//        }
//
//        // Note: this comparator imposes orderings that are inconsistent with equals.
//        public int compare(String a, String b) {
//            Date dateA = null;
//            Date dateB = null;
//            try {
//                dateA = sdf.parse(((ActivityAO) base.get(a)).getLatestDate());
//                dateB = sdf.parse(((ActivityAO) base.get(b)).getLatestDate());
//            } catch (ParseException e) {
//                e.printStackTrace();
//            }
//
//            if (dateA.after(dateB)) {
//                return -1;
//            } else {
//                return 1;
//            }
//
//        }
//    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mOverContextView != null) {
            mOverContextView.removeAllViews();
        }
        if (mElderlyExpandListView != null) {
            mElderlyExpandListView.setAdapter((MyFavoriteCenterAdapter) null);
        }
        if (mMyCommunityCentreAO != null) {
            mMyCommunityCentreAO.clear();
            mMyCommunityCentreAO = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mLastCallApiMonth = null;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent keyEvent) {
        if (isOverContextViewVisible()) {
            hideOverContextView();
            return true;
        }
        return false;
    }
}
