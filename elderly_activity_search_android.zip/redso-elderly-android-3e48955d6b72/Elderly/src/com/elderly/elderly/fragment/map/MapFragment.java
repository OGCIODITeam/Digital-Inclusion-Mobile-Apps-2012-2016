package com.elderly.elderly.fragment.map;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationChangeListener;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.gt.cl.util.CLDateUtil;

import java.util.Calendar;
import java.util.Date;

import lib.gt.ga.v2.GAManager;

public class MapFragment extends TempleteFragment implements ConnectionCallbacks, OnConnectionFailedListener, LocationListener, OnMyLocationChangeListener, InfoWindowAdapter, OnMarkerClickListener, OnInfoWindowClickListener {
	public static final String KEY_ACTIVITY_DETAIL = "key_activity_detail";

	private static final String TAG = "MapFragment";
	private GoogleMap mGoogleMap;
	private static final String MAP_KEY = "MapFragment";
	private boolean mIsSupportGoogleMap;
	private SupportMapFragment mGoogleMapFragment;
	private LocationClient mLocationClient;
	private LocationRequest mLocationRequest;
	private double workplace[] = new double[] { 23.128491, 113.318705 };// 第一个参数是纬度,第二个参数是经度
	private double school[] = new double[] { 23.129345, 113.320106 };

	// private View mLayerLoading;
	private FrameLayout mLayerMap,root;
	private View mLayerContext;
	private View mBtnAR;

	private LatLng mActivityLatLng;
	private View mInfoWindow;
	private ActivityDetailAO activityDetailAO;
	private TextView mTxtActivityName;
	private TextView mTxtDate;
	private TextView mTxtTime;
	private TextView mTxtLocation;
	private TextView mTxtMethod;
	private TextView mTxtDetail;
	private LinearLayout mOutside;

	//
	// protected MockTargetAdapter mArTargetAdapter;
	// protected MonsterExplorerView mArExplorerView;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		// setHeaderBgColor(R.color.header_Setting);

		// double angle = LocationUtil.angle(23.129991, 113.318705, 23.129992, 113.318706);
		// Log.v(TAG, "angle>>" + angle);
		// double distance = LocationUtil.getDistance(23.129991, 113.318705, 23.129991, 113.318701);
		// Log.v(TAG, "distance>>" + distance);
		inflater.inflate(R.layout.page_map, mLayerContextView);
		mInfoWindow = inflater.inflate(R.layout.view_googlemap_infowindow, null);
		// mLayerLoading = mLayerContextView.findViewById(R.id.page_map_mLayerLoading);
		mLayerMap = (FrameLayout) mLayerContextView.findViewById(R.id.page_map_mLayerMap);
        root = (FrameLayout) mLayerContextView.findViewById(R.id.root);
		mLayerContext = mLayerContextView.findViewById(R.id.page_map_mLayerContext);
		mBtnAR = mLayerContextView.findViewById(R.id.page_map_mBtnAR);
		// mArExplorerView=(MonsterExplorerView) mLayerContextView.findViewById(R.id.page_map_mArExplorerView);
		mOutside = (LinearLayout) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mOutside);
		mOutside.setLayoutParams(new LayoutParams((int) (getResources().getDisplayMetrics().widthPixels * 0.9), LayoutParams.WRAP_CONTENT));
		mTxtActivityName = (TextView) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mTxtActivityName);
		mTxtDate = (TextView) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mTxtDate);
		mTxtTime = (TextView) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mTxtTime);
		mTxtLocation = (TextView) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mTxtLocation);

		mTxtMethod = (TextView) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mTxtMethod);
		mTxtDetail = (TextView) mInfoWindow.findViewById(R.id.view_googlemap_infowindow_mTxtDetail);

		setupCommonBtnBgColor(mTxtDetail, getSchemeColorId());

		showLocation(true);
		setTitle(R.string.header_map);

		// boolean test1 = isGoogleMapsV1Supported();
		// boolean test2 = isGoogleMapsV2Supported(getMainActivity());
		//
		// if (test1 && test2) {
		// Toast.makeText(getMainActivity(), "Support Google map v1 & v2", Toast.LENGTH_LONG).show();
		// } else if (!test1 && test2) {
		// Toast.makeText(getMainActivity(), "Support Google map v2", Toast.LENGTH_LONG).show();
		// } else if (test1 && !test2) {
		// Toast.makeText(getMainActivity(), "Support Google map v1", Toast.LENGTH_LONG).show();
		// } else {
		// Toast.makeText(getMainActivity(), "Not Support Google map", Toast.LENGTH_LONG).show();
		// }

		int result = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity());
		if (result == ConnectionResult.SUCCESS) {
			mIsSupportGoogleMap = true;
		} else {
			mIsSupportGoogleMap = false;
			GooglePlayServicesUtil.getErrorDialog(result, getMainActivity(), 1).show();
		}

		Log.v(TAG, "mIsSupportGoogleMap>>" + mIsSupportGoogleMap);
		Fragment fragment = getChildFragmentManager().findFragmentByTag(MAP_KEY);
		if (mIsSupportGoogleMap && fragment == null && savedInstanceState == null) {
			// mGoogleMapFragment=(SupportMapFragment)
			// getChildFragmentManager().findFragmentById(R.id.page_map_mAndroidMapFragment);
			GoogleMapOptions gmo = new GoogleMapOptions();
			gmo.compassEnabled(false);
			gmo.rotateGesturesEnabled(false);
			gmo.zoomControlsEnabled(false);
			gmo.zOrderOnTop(false);
			gmo.useViewLifecycleInFragment(true);
			gmo.mapType(GoogleMap.MAP_TYPE_NORMAL);
			mGoogleMapFragment = SupportMapFragment.newInstance(gmo);
			FragmentTransaction ft = getChildFragmentManager().beginTransaction();
			ft.add(mLayerMap.getId(), mGoogleMapFragment, MAP_KEY);
			ft.commit();
		}
		setupListener();

		Bundle bundle = getArguments();
		if (bundle != null) {
			activityDetailAO = (ActivityDetailAO) bundle.getSerializable(KEY_ACTIVITY_DETAIL);
			if (activityDetailAO != null && activityDetailAO.getLatitude() != null && activityDetailAO.getLongitude() != null) {
				try {
					mActivityLatLng = new LatLng(Double.valueOf(activityDetailAO.getLatitude()), Double.valueOf(activityDetailAO.getLongitude()));
				} catch (Exception e) {
					mActivityLatLng = new LatLng(0, 0);
				}
			}
		}

	}

	private void setupListener() {
		mBtnAR.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.MAP_ARBUTTON, Constants.GA_ACTION_CLICK, activityDetailAO.getId() + "_" + activityDetailAO.getTitle());

				ARFragment arFragment = new ARFragment();
				Bundle bundle = new Bundle();
				bundle.putSerializable(KEY_ACTIVITY_DETAIL, activityDetailAO);
				bundle.putString(HEADER_TYPE, getHeaderType().name());
				arFragment.setArguments(bundle);

				// ARFragmentBak arFragment = new ARFragmentBak();
				getTabNavigationFragment().push(arFragment);

			}
		});
	}

	@Override
	public void onResume() {
		super.onResume();
		if (mGoogleMapFragment != null) {
			mGoogleMap = mGoogleMapFragment.getMap();
			if (mGoogleMap != null) {
				mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
				mGoogleMap.setMyLocationEnabled(true);
				mGoogleMap.setInfoWindowAdapter(this);
				mGoogleMap.setOnInfoWindowClickListener(this);
				mGoogleMap.setOnMarkerClickListener(this);
				mGoogleMap.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {

					@Override
					public void onInfoWindowClick(Marker arg0) {
						GAManager.getInstance().trackEvent(Constants.MAP_ACTIVITYDETAILBUTTON, Constants.GA_ACTION_CLICK, activityDetailAO.getId() + "_" + activityDetailAO.getTitle());
						getTabNavigationFragment().pop();
					}
				});
				// mGoogleMap.setOnMyLocationChangeListener(MapFragment.this);
				// if (!mIsFirstToMyLocation && mGoogleMap.getMyLocation() != null) {
				// initToMyLocation(mGoogleMap.getMyLocation());
				// }
				// mGoogleMap.moveCamera(CameraUpdateFactory.zoomTo(18));
				if (mActivityLatLng != null) {
                    root.setContentDescription(activityDetailAO.getLocation());
                    mLayerMap.setContentDescription(activityDetailAO.getLocation());
                    getTitle().setContentDescription(activityDetailAO.getLocation());
                    root.requestFocus();

                    mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mActivityLatLng, 18f));
					mGoogleMap.addMarker(new MarkerOptions().position(mActivityLatLng).icon(BitmapDescriptorFactory.fromResource(R.drawable.icon_location)));
				}
				mLocationClient = new LocationClient(getActivity(), MapFragment.this, MapFragment.this);
				// mLocationClient.connect();
				// initProvider();
			} else {
				Log.v(TAG, "google map == null");
			}
		}

	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		if (mIsSupportGoogleMap && mGoogleMapFragment != null) {
			FragmentTransaction ft = getChildFragmentManager().beginTransaction();
			ft.remove(mGoogleMapFragment);
		}
		if (mLocationClient != null && mLocationClient.isConnected()) {
			mLocationClient.removeLocationUpdates(this);
			mLocationClient.disconnect();
		}
		mGoogleMap = null;

	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		Log.v(TAG, "onConnectionFailed>>");
	}

	@Override
	public void onConnected(Bundle bundle) {
		mLocationRequest = LocationRequest.create().setInterval(10 * 1000).setFastestInterval(100).setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
		mLocationClient.requestLocationUpdates(mLocationRequest, this);
		if (mLocationClient.getLastLocation() != null) {
			Log.v(TAG, "get last location>>" + mLocationClient.getLastLocation().getLatitude() + "," + mLocationClient.getLastLocation().getLongitude());
		}
	}

	@Override
	public void onDisconnected() {
		Log.v(TAG, "onDisconnected>>");

	}

	@Override
	public void onLocationChanged(Location location) {
	}

	private void initToMyLocation(Location location) {
		if (mGoogleMap != null) {
			mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(location.getLatitude(), location.getLongitude())));
		}
	}

	private void animToMyLocation(Location location) {
		mGoogleMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(location.getLatitude(), location.getLongitude())));
	}

	@Override
	public void headerBtnClick(View view) {
		super.headerBtnClick(view);
		if (view.getId() == R.id.page_templete_mBtnLocation) {
			if (mGoogleMap != null && mGoogleMap.getMyLocation() != null) {
				GAManager.getInstance().trackEvent(Constants.MAP_CURRENTLOCATIONBUTTON, Constants.GA_ACTION_CLICK, "");
				animToMyLocation(mGoogleMap.getMyLocation());
			}
		}
	}

	@Override
	public void onMyLocationChange(Location location) {
	}

	@Override
	public View getInfoContents(Marker marker) {
		return null;
	}

	@Override
	public View getInfoWindow(Marker marker) {
		setText(mTxtActivityName, R.string.page_googlemap_activity_name, activityDetailAO.getTitle());
		if (activityDetailAO.getDate() != null) {
			String[] dates = activityDetailAO.getDate().split(",");
			StringBuffer sb = new StringBuffer();
			Calendar mCalendar = Calendar.getInstance();
			for (int i = 0; i < dates.length; i++) {
				String day = dates[i];
				Date date = CLDateUtil.formatDate(day, Constants.DATE_FORMAT_PATTERN_API);
				mCalendar.setTime(date);
				String weekDay = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
				sb.append(CLDateUtil.formatDate(date, Constants.DATE_FORMAT_PATTERN_SHOW + " (") + weekDay + ")");
				if (i != dates.length - 1) {
					sb.append("\n");
				}
			}
			setText(mTxtDate, R.string.page_googlemap_date, sb.toString());
		} else {
			setText(mTxtDate, R.string.page_googlemap_date, "");
		}
		setText(mTxtTime, R.string.page_googlemap_time, activityDetailAO.getStartTime() + "-" + activityDetailAO.getEndTime());
		setText(mTxtLocation, R.string.page_googlemap_location, activityDetailAO.getLocation());
		setText(mTxtMethod, R.string.page_googlemap_method, activityDetailAO.getApplicationMethod());
		return mInfoWindow;
	}

	@Override
	public boolean onMarkerClick(Marker marker) {
		if (activityDetailAO != null) {
			GAManager.getInstance().trackEvent(Constants.MAP_PIN, Constants.GA_ACTION_CLICK, activityDetailAO.getId() + "_" + activityDetailAO.getTitle());
		}
		return false;
	}

	@Override
	public void onInfoWindowClick(Marker marker) {
		Log.v(TAG, "onInfoWindowClick>>" + marker.getTitle());
	}

	private void setText(TextView view, int tip, String data) {
		if (data == null || data.equals("")) {
			view.setVisibility(View.GONE);
		} else {
			view.setText(getResources().getString(tip, data));
		}
	}

	public static boolean isGoogleMapsV1Supported() {
		try {
			Class.forName("com.google.android.maps.MapActivity");
			return true;
		} catch (final Throwable e) {}
		return false;
	}

	public static boolean isGoogleMapsV2Supported(final Context aContext) {
		try {
			// first check if Google Play Services is available
			int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(aContext);
			if (resultCode == ConnectionResult.SUCCESS) {
				// then check if OpenGL ES 2.0 is available
				final ActivityManager activityManager = (ActivityManager) aContext.getSystemService(Context.ACTIVITY_SERVICE);
				final ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
				return configurationInfo.reqGlEsVersion >= 0x20000;
			}
		} catch (Throwable e) {}
		return false;
	}

}
