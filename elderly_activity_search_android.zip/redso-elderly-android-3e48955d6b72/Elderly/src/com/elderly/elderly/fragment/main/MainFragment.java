package com.elderly.elderly.fragment.main;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import lib.gt.ga.v2.GAManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.Constants.Language;
import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyNumberTextView;
import com.elderly.elderly.fragment.BrowseFragment;
import com.elderly.elderly.fragment.events.favorite.FavoriteCenterFragment;
import com.elderly.elderly.fragment.events.my.MyActivityFragment;
import com.elderly.elderly.fragment.events.news.NewsActivityFragment;
import com.elderly.elderly.fragment.profile.ProfileChoosePhotoFragment;
import com.elderly.elderly.fragment.profile.ProfilePictureFragment;
import com.elderly.elderly.fragment.search.advance.SearchAdvanceFragment;
import com.elderly.elderly.fragment.search.easy.SearchEasyFragment;
import com.elderly.elderly.fragment.search.near.SearchNearFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.fragment.weather.WeatherForecastFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.BannerAO;
import com.elderly.elderly.pojo.ao.WeatherAO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.component.imageview.bitmapview.CLBitmapView;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

public class MainFragment extends TempleteFragment {
	private static final String TAG = "MainFragment";
	private ImageView mImgVNewActivity;
	private ImageView mImgVMyFavoriteCenter;
	private ImageView mImgVMyActivity;
	private ImageView mImgVSearchNear;
	private ImageView mImgVEasySearch;
	private ImageView mImgVAdSearch;
	private TextView mTxtWeatherStatus;
	private TextView mTxtWeatherHightest;
	private TextView mTxtWeatherLowest;
	private TextView mTxtWeatherHumidity;
	private LinearLayout mLayerWraning1;
	private LinearLayout mLayerWraning2;
	private ElderlyNumberTextView mNumberTxtWeatherTemperature;
	private TextView mTxtDate;
	private TextView mTxtWeatherForecast;
	private CLBitmapView mBitmapViewUserPhoto;
	private View mLayerBannerLoadingView;
	private View mLayerWeatherLoadingView;
	private View mLayerLastActivity;
	private ElderlyAsyncTask<Void, Void, Void> mWeatherAsynTask;
	private ElderlyAsyncTask<Void, Void, Void> mBannerAsynTask;

	private WeatherAO mWeatherAO;
	private Calendar mCalendar;

	private TextView mTxtBannerTitle;
	private TextView mTxtBannerDescription;
	private TextView mTxtBannerDetail;

	private List<BannerAO> mBannerData;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_main_fragment, mLayerContextView);
		mImgVNewActivity = (ImageView) mLayerContextView.findViewById(R.id.page_main_fragment_mImgVNewActivity);
		mImgVMyFavoriteCenter = (ImageView) mLayerContextView
				.findViewById(R.id.page_main_fragment_mImgVMyFavoriteCenter);
		mImgVMyActivity = (ImageView) mLayerContextView.findViewById(R.id.page_main_fragment_mImgVMyActivity);
		mImgVSearchNear = (ImageView) mLayerContextView.findViewById(R.id.page_main_fragment_mImgVSearchNear);
		mImgVEasySearch = (ImageView) mLayerContextView.findViewById(R.id.page_main_fragment_mImgVEasySearch);
		mImgVAdSearch = (ImageView) mLayerContextView.findViewById(R.id.page_main_fragment_mImgVAdSearch);
		mTxtWeatherStatus = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtWeatherStatus);
		mTxtWeatherHightest = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtWeatherHightest);
		mTxtWeatherLowest = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtWeatherLowest);
		mTxtWeatherHumidity = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtWeatherHumidity);
		mNumberTxtWeatherTemperature = (ElderlyNumberTextView) mLayerContextView
				.findViewById(R.id.page_main_fragment_mNumberTxtWeatherTemperature);
		mTxtDate = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtDate);
		mTxtWeatherForecast = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtWeatherForecast);
		mBitmapViewUserPhoto = (CLBitmapView) mLayerContextView
				.findViewById(R.id.page_main_fragment_mBitmapViewUserPhoto);
		mBitmapViewUserPhoto.setUserDefalutBitmap(R.drawable.photo_none, true);
		mBitmapViewUserPhoto.setDefalutBitmap();
		mLayerLastActivity = mLayerContextView.findViewById(R.id.page_main_fragment_mLayerLastActivity);
		mLayerWraning1 = (LinearLayout) mLayerContextView.findViewById(R.id.page_main_fragment_mLayerWarning1);
		mLayerWraning2 = (LinearLayout) mLayerContextView.findViewById(R.id.page_main_fragment_mLayerWarning2);
		mLayerBannerLoadingView = mLayerContextView.findViewById(R.id.page_main_fragment_mLayerBannerLoadingView);
		mLayerWeatherLoadingView = mLayerContextView.findViewById(R.id.page_main_fragment_mLayerWeatherLoadingView);
		mTxtBannerTitle = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtBannerTitle);
		mTxtBannerDescription = (TextView) mLayerContextView
				.findViewById(R.id.page_main_fragment_mTxtBannerDescription);
		mTxtBannerDetail = (TextView) mLayerContextView.findViewById(R.id.page_main_fragment_mTxtBannerDetail);
		setTitle(R.string.header_main_page);
		setHeaderBgColor(R.color.header_trasparent);
		mLayerLastActivity.setBackgroundColor(getResources().getColor(R.color.main_page_new_activity_bg));
		if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
			setSchemeGridColor1();
		} else {
			setSchemeGridColor2();
		}
		setupData();
		setupListener();
		callBannerApi();

		GAManager.getInstance().trackView(Constants.MAIN_PAGE_PG_MAINPAGE);
	}

	private void setupData() {
		mLayerWraning1.removeAllViews();
		mLayerWraning2.removeAllViews();
		mCalendar = Calendar.getInstance();
		int hour = mCalendar.get(Calendar.HOUR_OF_DAY);
		if (hour >= 18 || hour <= 6) {
			getRootView().setBackgroundResource(R.drawable.bg_night_sun);
		} else {
			getRootView().setBackgroundResource(R.drawable.bg_daytime_sun);
		}
		callWeatherApi();
		String pic = UserProfileManager.getInstance().getUserProfile().getPicture();
		if (pic != null) {
			CLBitmapInfo.Options options = new CLBitmapInfo.Options();
			options.height = getResources().getDimension(R.dimen.page_main_fragment_user_pic_size);
			options.width = getResources().getDimension(R.dimen.page_main_fragment_user_pic_size);
			options.autoOrientation = true;
			mBitmapViewUserPhoto.setBackgroundResource(R.drawable.bg_photo);
			mBitmapViewUserPhoto.setBitmapInfo(pic, null, pic, options);
			mBitmapViewUserPhoto.loadImageOneByOne();
		}
		setupGridIcon();
	}

	private void setupListener() {
		mBitmapViewUserPhoto.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_PHOTOBUTTON, Constants.GA_ACTION_CLICK, "");

				String pic = UserProfileManager.getInstance().getUserProfile().getPicture();
				if (pic == null) {
					ProfilePictureFragment ppf = new ProfilePictureFragment();
					getTabNavigationFragment().push(ppf);
				} else {
					ProfileChoosePhotoFragment settingFragment = new ProfileChoosePhotoFragment();
					getTabNavigationFragment().push(settingFragment);
				}
			}
		});
		mTxtWeatherForecast.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_WEATHERFORECASTBUTTON,
						Constants.GA_ACTION_CLICK, "");

				if (mWeatherAO != null) {
					WeatherForecastFragment wff = new WeatherForecastFragment();
					Bundle bundle = new Bundle();
					bundle.putSerializable(WeatherForecastFragment.STORE_KEY_DATA, mWeatherAO);
					wff.setArguments(bundle);
					getTabNavigationFragment().push(wff);
				}
			}
		});
		mImgVNewActivity.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isShowOfflineTip(R.string.header_news_activity)){
					return;
				}
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_LATESTACTIVITYBUTTON, Constants.GA_ACTION_CLICK,
						"");

				NewsActivityFragment naf = new NewsActivityFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE, HeaderType.NewsActivity.name());
				naf.setArguments(bundle);
				getTabNavigationFragment().push(naf);
			}
		});
		mImgVMyFavoriteCenter.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isShowOfflineTip(R.string.header_favorite_center)){
					return;
				}
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_FAVOURITECENTERBUTTON,
						Constants.GA_ACTION_CLICK, "");

				FavoriteCenterFragment fcf = new FavoriteCenterFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE, HeaderType.FavoriteCenter.name());
				fcf.setArguments(bundle);
				getTabNavigationFragment().push(fcf);

			}
		});
		mImgVMyActivity.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_MYACTIVITYBUTTON, Constants.GA_ACTION_CLICK, "");

				MyActivityFragment maf = new MyActivityFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE, HeaderType.MyActivity.name());
				maf.setArguments(bundle);
				getTabNavigationFragment().push(maf);

			}
		});
		mImgVSearchNear.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isShowOfflineTip(R.string.header_search_near)){
					return;
				}
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_SEARCHNEARBYBUTTON, Constants.GA_ACTION_CLICK,
						"");

				SearchNearFragment snf = new SearchNearFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE, HeaderType.SearchNear.name());
				snf.setArguments(bundle);
				getTabNavigationFragment().push(snf);
			}
		});
		mImgVEasySearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isShowOfflineTip(R.string.header_search_easy)){
					return;
				}
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_EASYSEARCHBUTTON, Constants.GA_ACTION_CLICK, "");

				SearchEasyFragment sef = new SearchEasyFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE, HeaderType.SearchEasy.name());
				sef.setArguments(bundle);
				getTabNavigationFragment().push(sef);
			}
		});
		mImgVAdSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(isShowOfflineTip(R.string.header_search_advance)){
					return;
				}
				
				GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_ADVANCEDSEARCHBUTTON, Constants.GA_ACTION_CLICK,
						"");
				
				SearchAdvanceFragment saf = new SearchAdvanceFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE,
						HeaderType.SearchAdvance.name());
				saf.setArguments(bundle);
				getTabNavigationFragment().push(saf);
			}
		});

		mTxtBannerDetail.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mBannerData != null && mBannerData.size() > 0) {
					BrowseFragment browseFragment = new BrowseFragment();
					Bundle bundle = new Bundle();
					bundle.putString(BrowseFragment.KEY_STORE_URL, mBannerData.get(0).getLink());
					bundle.putString(HEADER_TYPE, HeaderType.MainActivityToWebView.name());
					browseFragment.setArguments(bundle);
					getTabNavigationFragment().push(browseFragment);
				}

			}
		});
		mLayerLastActivity.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mBannerData != null && mBannerData.size() > 0) {
					GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_BANNER, Constants.GA_ACTION_CLICK,
							mBannerData.get(0).getId() + "_" + mBannerData.get(0).getTitle());

					BrowseFragment browseFragment = new BrowseFragment();
					Bundle bundle = new Bundle();
					bundle.putString(BrowseFragment.KEY_STORE_URL, mBannerData.get(0).getLink());
					bundle.putString(HEADER_TYPE, HeaderType.MainActivityToWebView.name());
					browseFragment.setArguments(bundle);
					getTabNavigationFragment().push(browseFragment);
				}
			}
		});
	}

	private void setSchemeGridColor1() {
		mImgVNewActivity.setBackgroundColor(getResources().getColor(R.color.header_scheme1_NewActivity));
		mImgVMyFavoriteCenter.setBackgroundColor(getResources().getColor(R.color.header_scheme1_FavoriteCenter));
		mImgVMyActivity.setBackgroundColor(getResources().getColor(R.color.header_scheme1_MyActivity));
		mImgVSearchNear.setBackgroundColor(getResources().getColor(R.color.header_scheme1_SearchNear));
		mImgVEasySearch.setBackgroundColor(getResources().getColor(R.color.header_scheme1_SearchSimply));
		mImgVAdSearch.setBackgroundColor(getResources().getColor(R.color.header_scheme1_SearchAdvanced));
	}

	private void setSchemeGridColor2() {
		mImgVNewActivity.setBackgroundColor(getResources().getColor(R.color.header_scheme2_NewActivity));
		mImgVMyFavoriteCenter.setBackgroundColor(getResources().getColor(R.color.header_scheme2_FavoriteCenter));
		mImgVMyActivity.setBackgroundColor(getResources().getColor(R.color.header_scheme2_MyActivity));
		mImgVSearchNear.setBackgroundColor(getResources().getColor(R.color.header_scheme2_SearchNear));
		mImgVEasySearch.setBackgroundColor(getResources().getColor(R.color.header_scheme2_SearchSimply));
		mImgVAdSearch.setBackgroundColor(getResources().getColor(R.color.header_scheme2_SearchAdvanced));
	}

	private void setupGridIcon() {
		if (Language.CurrentLanguage == Language.Chinese) {
			mImgVNewActivity.setImageResource(R.drawable.btn_new_activity_sc);
			mImgVMyFavoriteCenter.setImageResource(R.drawable.btn_favo_center_sc);
			mImgVMyActivity.setImageResource(R.drawable.btn_my_activity_sc);
			mImgVSearchNear.setImageResource(R.drawable.btn_locator_sc);
			mImgVEasySearch.setImageResource(R.drawable.btn_easy_search_sc);
			mImgVAdSearch.setImageResource(R.drawable.btn_ad_search_sc);
		} else {
			mImgVNewActivity.setImageResource(R.drawable.btn_new_activity_tc);
			mImgVMyFavoriteCenter.setImageResource(R.drawable.btn_favo_center_tc);
			mImgVMyActivity.setImageResource(R.drawable.btn_my_activity_tc);
			mImgVSearchNear.setImageResource(R.drawable.btn_locator_tc);
			mImgVEasySearch.setImageResource(R.drawable.btn_easy_search_tc);
			mImgVAdSearch.setImageResource(R.drawable.btn_ad_search_tc);
		}
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		// if (mWeatherAsynTask != null && !mWeatherAsynTask.getStatus().equals(AsyncTask.Status.FINISHED)) {
		// ApiManager.getInstance().cancelCheckWeather();
		// mWeatherAsynTask.cancel(true);
		// mWeatherAsynTask = null;
		// }
		//
		// if (mBannerAsynTask != null && !mBannerAsynTask.getStatus().equals(AsyncTask.Status.FINISHED)) {
		// mBannerAsynTask.cancel(true);
		// mBannerAsynTask = null;
		// }
		if (mBitmapViewUserPhoto != null) {
			mBitmapViewUserPhoto.unRegisterBitmapInfoListener();
		}
	}

	private void setupWeatherInfo() {
		if (mWeatherAO != null) {
			String tmpCurrentTemperature = mWeatherAO.getTemperature() != null ? mWeatherAO.getTemperature()  +"°C": "";//℃ 摄氏度
			String minTemperature = mWeatherAO.getMinTemperature() != null ? mWeatherAO.getMinTemperature() + "°" : "";
			String maxTemperature = mWeatherAO.getMaxTemperature() != null ? mWeatherAO.getMaxTemperature() + "°" : "";
			String tmpHumidity = mWeatherAO.getHumidity() != null ? mWeatherAO.getHumidity() + "%" : "";
			String tmpStr = tmpCurrentTemperature.replace("℃", "度");

			mNumberTxtWeatherTemperature.setText(tmpCurrentTemperature);
			mNumberTxtWeatherTemperature.setContentDescription(getResources().getString(
					R.string.voice_current_temperature, tmpStr));

			tmpStr = minTemperature.replace("°", "度");
			mTxtWeatherLowest.setText(minTemperature);
			mTxtWeatherLowest
					.setContentDescription(getResources().getString(R.string.voice_lowest_temperature, tmpStr));

			tmpStr = maxTemperature.replace("°", "度");
			mTxtWeatherHightest.setText(maxTemperature);
			mTxtWeatherHightest.setContentDescription(getResources().getString(R.string.voice_hightest_temperature,
					tmpStr));

			tmpStr = tmpHumidity;
			mTxtWeatherHumidity.setText(tmpHumidity);
			mTxtWeatherHumidity.setContentDescription(getResources().getString(R.string.voice_humidity, tmpStr));

			mTxtWeatherStatus.setText(mWeatherAO.getName());
			if (mWeatherAO.getCode() != null) {
				int id = Constants.getWeatherIcon(Integer.parseInt(mWeatherAO.getCode()));
				mTxtWeatherStatus.setCompoundDrawablesWithIntrinsicBounds(id, 0, 0, 0);
			}
			mCalendar = Calendar.getInstance();
			int hour = mCalendar.get(Calendar.HOUR_OF_DAY);
			if (mWeatherAO.getDate() != null) {
				Date tmpDate = CLDateUtil.formatDate(mWeatherAO.getDate(), Constants.DATE_FORMAT_PATTERN_API);
				mCalendar.setTime(tmpDate);
				mCalendar.set(Calendar.HOUR_OF_DAY, hour);
				String weekDay = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
				String date = CLDateUtil.formatDate(mCalendar.getTime(), "dd/MM");

				tmpStr = CLDateUtil.formatDate(tmpDate, Constants.DATE_FORMAT_PATTERN_SHOW);
				mTxtDate.setText(weekDay + " " + date);
				mTxtDate.setContentDescription(tmpStr + " " + weekDay);
			}

			if (mWeatherAO.getWarning() != null) {
				String tmp[] = mWeatherAO.getWarning().split(",");
				for (int i = 0; i < 6; i++) {
					ImageView icon = new ImageView(getActivity());
					LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT);
					lp.weight = 1;
					if (i < 3) {
						int tmpIndex = 2 - i;
						if (tmpIndex < tmp.length) {
							int code = Integer.parseInt(tmp[tmpIndex]);
							Log.v(TAG, "wraning>>" + tmp[tmpIndex] + "," + Constants.getWarningIcon(code));
							icon.setImageResource(Constants.getWarningIcon(code));
						}
					} else {
						int tmpIndex = i;
						if (tmpIndex == 5) {
							tmpIndex = 3;
						} else if (tmpIndex == 3) {
							tmpIndex = 5;
						}
						if (tmpIndex < tmp.length) {
							int code = Integer.parseInt(tmp[tmpIndex]);
							Log.v(TAG, "wraning>>" + tmp[tmpIndex] + "," + Constants.getWarningIcon(code));
							icon.setImageResource(Constants.getWarningIcon(code));
						}
					}

					if (i < 3) {
						mLayerWraning1.addView(icon, lp);
					} else {
						mLayerWraning2.addView(icon, lp);
					}
				}
			}
			if (mWeatherAO.getCode() != null) {
				int code = Integer.parseInt(mWeatherAO.getCode());
				if (hour >= 18 || hour <= 6) {
					if (code > 61 && code < 65) {
						getRootView().setBackgroundResource(R.drawable.bg_night_rain);
					} else {
						getRootView().setBackgroundResource(R.drawable.bg_night_sun);
					}
				} else {
					if (code > 61 && code < 65) {
						getRootView().setBackgroundResource(R.drawable.bg_daytime_rain);
					} else {
						getRootView().setBackgroundResource(R.drawable.bg_daytime_sun);
					}
				}
			}
		} else {
			mNumberTxtWeatherTemperature.setText(null);
			mTxtWeatherHightest.setText(null);
			mTxtWeatherLowest.setText(null);
			mTxtWeatherHumidity.setText(null);
			mTxtWeatherStatus.setText(null);
			mTxtWeatherStatus.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
		}

	}

	private void callBannerApi() {
		mLayerBannerLoadingView.setVisibility(View.INVISIBLE);
		mTxtBannerTitle.setVisibility(View.INVISIBLE);
		mTxtBannerDetail.setVisibility(View.INVISIBLE);
		mTxtBannerDescription.setVisibility(View.INVISIBLE);
		if (mBannerData != null) {
			setupBannerData();
			return;
		}
		mBannerAsynTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity(), false) {

			@Override
			protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
				try {
					mBannerData = ApiManager.getInstance().getBannerList("M");
				} catch (Exception e) {
					e.printStackTrace();
				}
				return null;
			}

			@Override
			protected void doOnSuccess(Void result) {
				if (mBannerData == null) {
					mBannerData = ApiManager.getInstance().getBannerListFormHistory("M");
				}
				setupBannerData();

			}

			@Override
			protected boolean showCustomLoading() {
				return true;
			}

			@Override
			protected void callCustomLoading() {
				mLayerBannerLoadingView.setVisibility(View.VISIBLE);
				super.callCustomLoading();
			}

			@Override
			protected void cancelCustomLoading() {
				mLayerBannerLoadingView.setVisibility(View.INVISIBLE);
				super.cancelCustomLoading();
			}

			@Override
			protected boolean handleException(Exception ex) {
				return false;
			}

		};
		mBannerAsynTask.execute((Void) null);
	}

	private void callWeatherApi() {
		if (mWeatherAO == null) {
			mWeatherAsynTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity(), false) {
				@Override
				protected void doOnSuccess(Void result) {
					if (mWeatherAO == null) {
						mWeatherAO = ApiManager.getInstance().getWeatherFormHistory();
					}
					setupWeatherInfo();
				}

				@Override
				protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
					try {
						mWeatherAO = null;
						mWeatherAO = ApiManager.getInstance().checkWeather();
					} catch (Exception e) {
						e.printStackTrace();
					}
					return null;
				}

				@Override
				protected boolean handleException(Exception ex) {
					return false;
				}

				@Override
				protected boolean showCustomLoading() {
					return true;
				}

				@Override
				protected void callCustomLoading() {
					mLayerWeatherLoadingView.setVisibility(View.VISIBLE);
					super.callCustomLoading();
				}

				@Override
				protected void cancelCustomLoading() {
					mLayerWeatherLoadingView.setVisibility(View.INVISIBLE);
					super.cancelCustomLoading();
				}

			};
			mWeatherAsynTask.execute((Void) null);
		} else {
			setupWeatherInfo();
		}
	}

	private void setupBannerData() {
		if (mBannerData != null && mBannerData.size() > 0) {
			BannerAO ao = mBannerData.get(0);
			mTxtBannerTitle.setVisibility(View.VISIBLE);
			mTxtBannerDetail.setVisibility(View.VISIBLE);
			mTxtBannerDescription.setVisibility(View.VISIBLE);
			mTxtBannerTitle.setText(ao.getTitle());
			mTxtBannerTitle.setContentDescription("连结 "+ao.getTitle());
			mTxtBannerDescription.setText(ao.getDescription());
			mTxtBannerDescription.setContentDescription("连结 "+ao.getDescription());
		} else {
			mBannerData = null;
		}
	}

	private boolean isShowOfflineTip(int strId) {
		if (!ElderlyUtil.isNetworkAvailable(getActivity())) {
			Dialog dialog=new AlertDialog.Builder(getActivity()).setCancelable(false).setTitle(R.string.common_dialog_title)
					.setMessage(getString(R.string.tip_offline_function,getString(strId))).setPositiveButton(R.string.common_ok, null).create();
			dialog.show();
			TextView messageText = (TextView) dialog.findViewById(android.R.id.message);
			messageText.setGravity(Gravity.CENTER);
			return true;
		}
		return false;
	}

}
