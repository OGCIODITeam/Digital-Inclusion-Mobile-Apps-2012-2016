package com.elderly.elderly.fragment.profile;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.ElderlyApplication;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.MyInterestAdapter;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.util.ElderlyUtil;

public class ProfileMyInterestFragment extends TempleteFragment {
    private ElderlyListView mElderlyListView;
    private View mLayerConfirm;
    private FrameLayout mOverView;
    private MyInterestAdapter mAdapter;
    int selected;

    @Override
    public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
        setTitle(R.string.header_my_interest);
        setHeaderBgColor(R.color.header_ProfileSetting);
        inflater.inflate(R.layout.page_profile_my_interest, mLayerContextView);
        mElderlyListView = (ElderlyListView) mLayerContextView
                .findViewById(R.id.page_profile_my_interest_mElderlyListView);

        mLayerConfirm = mLayerContextView.findViewById(R.id.page_profile_my_interest_mLayerConfirm);
        mLayerConfirm.setBackgroundResource(R.drawable.shape_common_btn_bg);
        setupCommonBtnBgColor(mLayerConfirm, R.color.header_ProfileSetting);
        if (mAdapter == null) {
            mAdapter = new MyInterestAdapter(getActivity());
        }
        mElderlyListView.getListView().setDividerHeight((int) getResources().getDimensionPixelSize(R.dimen.divider_line_height));
        mElderlyListView.setAdapter(mAdapter);
        setupListener();
        showInterestTip();
        UserProfileManager.getInstance().alReadlyShowUserInterestTip();
    }

    private void setupListener() {
        mLayerConfirm.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                UserProfileManager.getInstance().setMyInterestList(mAdapter.getHightLightDatas());

                ElderlyApplication.me.savePref("easysearch_act", mAdapter.getSelected() + "");

                getTabNavigationFragment().pop();
            }
        });
    }

    private void showInterestTip() {
        if (UserProfileManager.getInstance().isNeedShowUserInterestDetailTip()) {
            UserProfileManager.getInstance().alReadlyShowUserInteresDetailtTip();
            addGuidView(0, Constants.getGuide(6));
            mOverView.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {

                    hideOverContextView();

                }
            });
        } else {
            hideOverContextView();
        }
    }

    // 添加guidview的圖片指導圖
    private void addGuidView(int marginTop, int resId) {
        mOverView = showOverContextView(marginTop, false);
        mOverView.removeAllViews();
        ImageView sexGuidView = new ImageView(getActivity());
        FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT);
        parms.gravity = Gravity.CENTER;
        parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
        sexGuidView.setImageResource(resId);
        sexGuidView.setContentDescription("提示：请选择你的兴趣（可选多于一个）");
        mOverView.addView(sexGuidView, parms);
    }

}
