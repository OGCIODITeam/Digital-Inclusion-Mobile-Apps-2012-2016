package com.elderly.elderly.fragment;

import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.elderly.elderly.R;

import java.util.ArrayList;
import java.util.List;

public class NavigationFragment extends ElderlyFragment {
	private static final String TAG = "NavigationFragment";
	private static final String KEY_PREFIX = TAG + "_KEY_PREFIX";
	private static final String STORE_KEY_HISTORY_LIST = "STORE_KEY_HISTORY_LIST";
	private ArrayList<String> mHistoryList = new ArrayList<String>();
	private int mContentLayoutId;
	private ElderlyFragment mRootFragment;
	private boolean mEnablePopOrPush = true;;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// Log.v(TAG, "onCreateView>>" + this.getTag() + "," + savedInstanceState);
		super.onCreateView(inflater, container, savedInstanceState);
		mContentLayoutId = R.id.page_navigation_content;
		if (savedInstanceState != null) {
			mHistoryList = savedInstanceState.getStringArrayList(STORE_KEY_HISTORY_LIST);

		} else {
			if (mHistoryList == null) {
				mHistoryList = new ArrayList<String>();
			}
		}
		mEnablePopOrPush = true;
		Log.v(TAG, "mHistoryList size>>" + mHistoryList.size());
		return inflater.inflate(R.layout.page_navigation, container, false);
	}

	public String push(ElderlyFragment fragment) {
		// Log.v(TAG, "push>>");
		String key = KEY_PREFIX + "_" + SystemClock.currentThreadTimeMillis();
		if (mEnablePopOrPush) {
			FragmentTransaction transaction = getChildFragmentManager().beginTransaction();

			ElderlyFragment currentFragment = getCurrentFragment();
			if (currentFragment != null) {
				currentFragment.onFragmentPush();
				currentFragment.setAnimationAction(R.anim.slide_out_left);
				transaction.hide(currentFragment);
				currentFragment.setFragmentAnimationEndListener(new FragmentAnimationEndListener() {

					@Override
					public void onAnimationEnd(ElderlyFragment fragment) {
						FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
						transaction.show(fragment);
						transaction.detach(fragment);
						transaction.commit();
						getActivity().getWindow().getDecorView().postDelayed(new Runnable() {

							@Override
							public void run() {
								mEnablePopOrPush = true;
							}
						}, 50);
						Log.v(TAG, "push onAnimationEnd>>" + fragment.getTag());
					}
				});
			}
			fragment.setAnimationAction(R.anim.slide_in_right);
			transaction.add(mContentLayoutId, fragment, key);
			transaction.commitAllowingStateLoss();
			mHistoryList.add(key);
			mEnablePopOrPush = false;
		}
		return key;
	}

	public void pushWidthDestoryCurrentFragment(ElderlyFragment fragment) {

		if (mEnablePopOrPush) {
			String key = KEY_PREFIX + "_" +SystemClock.currentThreadTimeMillis();
			Log.v(TAG, "pushWidthDestoryCurrentFragment>>"+key);
			FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
			ElderlyFragment currentFragment = getCurrentFragment();
			if (currentFragment != null) {
				currentFragment.onFragmentPush();
				currentFragment.setAnimationAction(R.anim.slide_out_left);
				transaction.hide(currentFragment);
				mHistoryList.remove(currentFragment.getTag());
				currentFragment.setFragmentAnimationEndListener(new FragmentAnimationEndListener() {
					@Override
					public void onAnimationEnd(ElderlyFragment fragment) {
						FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
						transaction.show(fragment);
						transaction.remove(fragment);
						transaction.commit();
						getActivity().getWindow().getDecorView().postDelayed(new Runnable() {

							@Override
							public void run() {
								mEnablePopOrPush = true;
							}
						}, 50);
						Log.v(TAG, "pushWidthDestoryCurrentFragment onAnimationEnd>>" + fragment.getTag());
					}
				});
			}
			fragment.setAnimationAction(R.anim.slide_in_right);
			transaction.add(mContentLayoutId, fragment, key);
			transaction.commitAllowingStateLoss();
			mHistoryList.add(key);
			mEnablePopOrPush = false;
		}
	}

	public void pop() {
		if (mHistoryList.size() > 1) {
			String key = mHistoryList.get(mHistoryList.size() - 2);
			popToFragmentByKey(key,null);
		}
	}

	public void popPrevious(Bundle bundle) {
		if (mHistoryList.size() > 1) {
			String key = mHistoryList.get(mHistoryList.size() - 3);
			popToFragmentByKey(key,bundle);
		}
	}

	public void pop(Bundle bundle) {
		if (mHistoryList.size() > 1) {
			String key = mHistoryList.get(mHistoryList.size() - 2);
			popToFragmentByKey(key,bundle);
		}
	}

	public void popToRootFragment() {
		if (mHistoryList.size() > 0) {
			String key = mHistoryList.get(0);
			popToFragmentByKey(key,null);
		}
	}

	public void popToFragmentByKey(String key,Bundle bundle) {
		if (mEnablePopOrPush) {
			int keyIndex = mHistoryList.indexOf(key);
			if (keyIndex >= 0) {

				if (keyIndex == mHistoryList.size() - 1) {
					return;
				}

				List<String> removeKeyList = new ArrayList<String>();
				ElderlyFragment currentFragment = getCurrentFragment();
				if(currentFragment!=null){
					currentFragment.onFragmentPop();
				}
				FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
				for (int i = keyIndex + 1; i < mHistoryList.size(); i++) {

					String tag = mHistoryList.get(i);
					Log.v(TAG, "pop remove tag>>" + tag);
					removeKeyList.add(tag);
					Fragment fragment = getChildFragmentManager().findFragmentByTag(tag);
					if (fragment instanceof ElderlyFragment) {
						ElderlyFragment elderlyFragment = (ElderlyFragment) fragment;

						if (!tag.equals(currentFragment.getTag())) {
							elderlyFragment.setAnimationAction(0);
							transaction.remove(fragment);
						} else {
							elderlyFragment.setAnimationAction(R.anim.slide_out_right);
							transaction.hide(elderlyFragment);
							elderlyFragment.setFragmentAnimationEndListener(new FragmentAnimationEndListener() {
								@Override
								public void onAnimationEnd(ElderlyFragment fragment) {
									FragmentTransaction transaction = NavigationFragment.this.getChildFragmentManager()
											.beginTransaction();
									transaction.remove(fragment);
									transaction.commitAllowingStateLoss();
									getActivity().getWindow().getDecorView().postDelayed(new Runnable() {

										@Override
										public void run() {
											mEnablePopOrPush = true;
										}
									}, 50);

									Log.v(TAG, "pop onAnimationEnd>>" + fragment.getTag());
								}
							});
						}
					}
				}

				mHistoryList.removeAll(removeKeyList);
				ElderlyFragment fragment = (ElderlyFragment) getChildFragmentManager().findFragmentByTag(key);
				Log.v(TAG, "to show >>" + fragment.getTag());
				fragment.setAnimationAction(R.anim.slide_in_left);
				if(bundle!=null){
					if(fragment.getArguments()!=null){
						fragment.getArguments().putAll(bundle);
					}else{
						fragment.setArguments(bundle);
					}
				}
				transaction.attach(fragment);
				transaction.commitAllowingStateLoss();
				mEnablePopOrPush = false;
			}
		}
	}

	public ElderlyFragment getCurrentFragment() {
		ElderlyFragment fragment = null;
		if (mHistoryList.size() > 0) {
			String currentKey = mHistoryList.get(mHistoryList.size() - 1);
			fragment = (ElderlyFragment) getChildFragmentManager().findFragmentByTag(currentKey);
		}
		return fragment;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putStringArrayList(STORE_KEY_HISTORY_LIST, mHistoryList);
		super.onSaveInstanceState(outState);
	}

	public void setRootFragment(ElderlyFragment mRootFragment) {
		FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
		if (mHistoryList != null) {
			for (int i = 0; i < mHistoryList.size(); i++) {
				String tag = mHistoryList.get(i);
				Fragment fragment = getChildFragmentManager().findFragmentByTag(tag);
				transaction.remove(fragment);
			}
		}
		String fragmentKey = KEY_PREFIX + "_"+SystemClock.currentThreadTimeMillis();
		transaction.add(mContentLayoutId, mRootFragment, fragmentKey);
		transaction.commit();
		mHistoryList.add(fragmentKey);
	}

	public void restartCurrentFragment() {
		FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
		Fragment currentFragment = getCurrentFragment();
		transaction.detach(currentFragment);
		// transaction.add(mContentLayoutId, currentFragment, mHistoryList.get(mHistoryList.size() - 1));
		transaction.attach(currentFragment);
		transaction.commit();
	}

	public boolean popFragment() {
		if (mHistoryList.size() >= 2) {
			pop();
			return true;
		} else {
			return false;
		}
	}

	public int getHistoryListSize() {
		return mHistoryList.size();
	}
}
