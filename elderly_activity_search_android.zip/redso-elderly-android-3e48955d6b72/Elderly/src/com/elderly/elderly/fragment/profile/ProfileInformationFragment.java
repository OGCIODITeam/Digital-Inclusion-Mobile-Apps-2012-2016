package com.elderly.elderly.fragment.profile;

import android.content.DialogInterface;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.elderly.elderly.Constants;
import com.elderly.elderly.ElderlyApplication;
import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyLocationWheel;
import com.elderly.elderly.component.ElderlyLocationWheel.LocationWheelListener;
import com.elderly.elderly.component.ElderlyProfileSelectSexView;
import com.elderly.elderly.component.ElderlySimpleEditTextView;
import com.elderly.elderly.component.ElderlySimpleEditTextView.OnSimpleTextChangeListener;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.pojo.po.UserProfilePo;
import com.elderly.elderly.util.ElderlyUtil;

public class ProfileInformationFragment extends TempleteFragment implements OnClickListener {

    private static final String TAG = "ProfileInformationFragment";
    private Button mBtnNextStep;
    private ElderlySimpleEditTextView mEdTxtName;
    private ElderlySimpleEditTextView mTxtSex;
    private ElderlySimpleEditTextView mTxtDistrict;
    private ElderlySimpleEditTextView mTxtRegion;
    private FrameLayout mOverView;
    // private InputMethodManager im;
    private DistrictPo mSelectDistrictPo = null;
    private LocationPo mSelectLocationPo = null;
    private ElderlyLocationWheel mElderLyLocationWheel;
    private RelativeLayout outsideLayout;
    private boolean isKeyboardShow;
    //
    String type;
    LinearLayout page_profile_information_dimView;

    @Override
    public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
        View view = inflater.inflate(R.layout.page_profile_information, mLayerContextView);

        setTitle(R.string.header_profile);
        setHeaderBgColor(R.color.header_ProfileSetting);

        // im = ((InputMethodManager) getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE));
        type = getArguments().getString("type");
        mBtnNextStep = (Button) view.findViewById(R.id.page_profile_information_mBtnNextStep);
        mEdTxtName = (ElderlySimpleEditTextView) view.findViewById(R.id.page_profile_information_mEdTxtName);
        mTxtSex = (ElderlySimpleEditTextView) view.findViewById(R.id.page_profile_information_mTxtSex);
        mTxtDistrict = (ElderlySimpleEditTextView) view.findViewById(R.id.page_profile_information_mTxtArea);
        mTxtRegion = (ElderlySimpleEditTextView) view.findViewById(R.id.page_profile_information_mTxtRegion);

        page_profile_information_dimView = (LinearLayout) view.findViewById(R.id.page_profile_information_dimView);

        if (type.equals("setProfile")||type.equals("setSearchOption")) {

            page_profile_information_dimView.setVisibility(View.VISIBLE);
            mBtnNextStep.setText(R.string.profile_next_step);

        } else if (type.equals("setLocation")) {

            mBtnNextStep.setText(R.string.profile_finish_step);
            page_profile_information_dimView.setVisibility(View.INVISIBLE);

        }
        mEdTxtName.setHint(R.string.profile_input_name);
        mTxtSex.setHint(R.string.profile_input_sex);
        mTxtDistrict.setHint(R.string.profile_input_area);
        mTxtRegion.setHint(R.string.profile_input_region);

        mEdTxtName.setEdittextFocusable(true);
        mTxtSex.setEdittextFocusable(false);
        mTxtDistrict.setEdittextFocusable(false);
        mTxtRegion.setEdittextFocusable(false);

        outsideLayout = (RelativeLayout) view.findViewById(R.id.outsidelayout);
        outsideLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {
                Rect r = new Rect();
                outsideLayout.getWindowVisibleDisplayFrame(r);

                int screenHeight = outsideLayout.getRootView().getHeight();
                Log.i(TAG, "screenHeight.........r.bottom" + screenHeight + "..." + r.bottom);
                if (screenHeight > r.bottom) {
                    Log.i(TAG, "screenHeight > r.bottom");
                    isKeyboardShow = true;
                } else {
                    Log.i(TAG, "screenHeight < r.bottom");
                    if (isKeyboardShow) {
                        Log.i(TAG, "isKeyboardShow = true");
                        isKeyboardShow = false;
                        mEdTxtName.getSimpleEditText().clearFocus();
                        showUserSexTip(true);
                    }
                }
            }
        });
    }

    private void setupListener() {
        mBtnNextStep.setOnClickListener(this);
        mBtnNextStep.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mBtnNextStep.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                if (UserProfileManager.getInstance().isNeedShowUserNameTip()) {
                    showUserNameTip(false);
                } else if (UserProfileManager.getInstance().isNeedShowUserSexTip()) {
                    showUserSexTip(false);
                } else if (UserProfileManager.getInstance().isNeedShowUserDistrictTip()) {
                    showUserRegionTip(false);
                } else if (UserProfileManager.getInstance().isNeedShowUserRegionTip()) {
                    showUserLocationTip(false);
                }
            }
        });

        mEdTxtName.getSimpleEditText().setOnFocusChangeListener(new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    addNameConfirmView();
                } else {
                    getMainActivity().hideKeyBoard();
                    // mEdTxtName.getSimpleEditText().clearFocus();
                    // im.hideSoftInputFromWindow(mEdTxtName.getSimpleEditText().getWindowToken(),
                    // InputMethodManager.HIDE_NOT_ALWAYS);
                    UserProfileManager.getInstance().alReadlyShowUserNameTip();
                    showUserSexTip(true);
                }

            }
        });
        mEdTxtName.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

            @Override
            public void onSimpleTextChange() {
                UserProfileManager.getInstance().updateUserName(mEdTxtName.getText().toString());
            }

            @Override
            public void onSimpleClear() {
            }
        });
        mTxtSex.getSimpleEditText().setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                addSexSelectView();
            }
        });
        mTxtSex.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

            @Override
            public void onSimpleTextChange() {
            }

            @Override
            public void onSimpleClear() {
                UserProfileManager.getInstance().updateUserSex(mTxtSex.getText().toString());
            }
        });
        mTxtDistrict.getSimpleEditText().setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                addDistrictView();
            }
        });
        mTxtDistrict.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

            @Override
            public void onSimpleTextChange() {
            }

            @Override
            public void onSimpleClear() {
                mTxtRegion.setText(null);
                UserProfileManager.getInstance().updateUserDistrict(mTxtDistrict.getText().toString());
                UserProfileManager.getInstance().updateUserRegion(mTxtRegion.getText().toString());
            }
        });
        mTxtRegion.getSimpleEditText().setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mTxtDistrict.getText().toString() == null || mTxtDistrict.getText().toString().equals("")) {
                    ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.profile_no_district_search, R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }, null);
                } else {
                    addRegionView();
                }
            }
        });
        mTxtRegion.setOnSimpleTextChangeListener(new OnSimpleTextChangeListener() {

            @Override
            public void onSimpleTextChange() {
            }

            @Override
            public void onSimpleClear() {
                UserProfileManager.getInstance().updateUserRegion(mTxtRegion.getText().toString());
            }
        });
    }

    private void setupData() {
        setupCommonBtnBgColor(mBtnNextStep, R.color.header_ProfileSetting);
        UserProfilePo user = UserProfileManager.getInstance().getUserProfile();
        if (user.getName() != null) {
            mEdTxtName.setText(user.getName());
        }
        if (user.getSex() != null) {
            mTxtSex.setText(user.getSex());
        }
        if (user.getDistrict() != null) {
            mSelectDistrictPo = UserProfileManager.getInstance().getDistrictPoByKey(user.getDistrict());
            mTxtDistrict.setText(mSelectDistrictPo != null ? mSelectDistrictPo.getName() : null);
        }
        if (user.getDistrict() != null && user.getRegion() != null) {
            mSelectLocationPo = UserProfileManager.getInstance().getRegionByKey(user.getDistrict(), user.getRegion());
            mTxtRegion.setText(mSelectLocationPo != null ? mSelectLocationPo.getName() : null);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == mBtnNextStep.getId()) {

            if (type.equals("setProfile")||type.equals("setSearchOption")) {
                ProfileOtherFragment otherFragment = new ProfileOtherFragment();
                Bundle bundle=new Bundle();
                bundle.putString("type",type);
                otherFragment.setArguments(bundle);
                getTabNavigationFragment().push(otherFragment);
            } else if (type.equals("setLocation")) {
                if (getMainActivity() != null) {
                    getMainActivity().hideKeyBoard();
                }
                getTabNavigationFragment().pop();
            }


        } else if (v.getId() == mTxtSex.getId()) {
            addSexSelectView();
        } else if (v.getId() == mTxtDistrict.getId()) {
            addDistrictView();
        } else if (v.getId() == mTxtRegion.getId()) {
            addRegionView();
        }
    }

    // 添加guidview的圖片指導圖
    private void addGuidView(int marginTop, int resId, boolean anim, int which) {

        mOverView = showOverContextView(marginTop, anim);
        ImageView sexGuidView = new ImageView(getActivity());
        FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        parms.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
        sexGuidView.setImageResource(resId);
        switch (which) {
            case 1:
                sexGuidView.setContentDescription("提示：请按 输入姓名 键");
                break;
            case 2:
                sexGuidView.setContentDescription("提示：请按 输入性别 键");
                break;
            case 3:
                sexGuidView.setContentDescription("提示：请按 输入区域 键");
                break;
            case 4:
                sexGuidView.setContentDescription("提示：请按 输入地区 键");
                break;
        }
        mOverView.addView(sexGuidView, parms);
    }

    // 添加guidview的子控件
    private void addActionView(View view, boolean isCenter, int marginTop, FrameLayout.LayoutParams params, boolean anim) {
        mOverView = showOverContextView(marginTop, anim);
        int margin = (int) ElderlyUtil.dip2px(getActivity(), 20);
        if (isCenter) {
            params.gravity = Gravity.CENTER;
        } else {
            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            params.topMargin = margin;
        }
        params.rightMargin = margin;
        params.leftMargin = margin;
        mOverView.addView(view, params);
    }

    // 添加userName模塊的確認按鈕
    private void addNameConfirmView() {

        Rect rect = new Rect();
        mEdTxtName.getGlobalVisibleRect(rect);
        int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));

        mOverView = showOverContextView(sexCoverViewHeight, false);
        mOverView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
            }
        });

    }

    // 添加性別模塊的選擇按鈕
    private void addSexSelectView() {
        ElderlyProfileSelectSexView sexSelectView = new ElderlyProfileSelectSexView(getActivity());
        Rect rect = new Rect();
        mTxtSex.getGlobalVisibleRect(rect);
        int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
        addActionView(sexSelectView, true, sexCoverViewHeight, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT), false);
        sexSelectView.getMaleBtn().setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                UserProfileManager.getInstance().alReadlyShowUserSexTip();
                UserProfileManager.getInstance().updateUserSex(getString(R.string.profile_male_label));
                mTxtSex.setText(getString(R.string.profile_male_label));
                showUserRegionTip(true);

            }
        });

        sexSelectView.getFemaleBtn().setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                UserProfileManager.getInstance().alReadlyShowUserSexTip();
                UserProfileManager.getInstance().updateUserSex(getString(R.string.profile_female_label));
                mTxtSex.setText(getString(R.string.profile_female_label));
                showUserRegionTip(true);
            }
        });

        sexSelectView.getIgnoreBtn().setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                UserProfileManager.getInstance().alReadlyShowUserSexTip();
                UserProfileManager.getInstance().updateUserSex(null);
                mTxtSex.setText(null);
                showUserRegionTip(true);
            }
        });
    }

    // 添加區域模塊的選擇按鈕
    private void addDistrictView() {

        mElderLyLocationWheel = new ElderlyLocationWheel(getActivity());
        mElderLyLocationWheel.setSelectDrawable(R.drawable.setting_area_on);
        UserProfilePo po = UserProfileManager.getInstance().getUserProfile();
        mElderLyLocationWheel.setupData(UserProfileManager.getInstance().getDistrictPoList(), mSelectDistrictPo);
        mElderLyLocationWheel.setControlBarBgColor(R.color.header_ProfileSetting);
        mElderLyLocationWheel.setConfirmBgColor(R.color.header_ProfileSetting_HeightLight);
        mElderLyLocationWheel.setLocationWheelListener(new LocationWheelListener() {

            @Override
            public void onClick(boolean isConfirm, Object data) {
                if (isConfirm) {
                    mTxtDistrict.setText(((DistrictPo) data).getName());
                    if (mSelectDistrictPo != null && !mSelectDistrictPo.equals(data)) {
                        mTxtRegion.setText(null);
                        mSelectLocationPo = null;
                    }
                    mSelectDistrictPo = ((DistrictPo) data);
                    UserProfileManager.getInstance().updateUserDistrict(((DistrictPo) data).getKey());
                    ElderlyApplication.me.savePref("easysearch_dist", mElderLyLocationWheel.getSelected() + "");
                    ElderlyApplication.me.savePref("easysearch_region", 0 + "");

                }
                hideOverContextView();
                mElderLyLocationWheel.releaseWheel();
                UserProfileManager.getInstance().alReadlyShowUserDirstrictTip();
                showUserLocationTip(true);
            }
        });
        Rect rect = new Rect();
        mTxtDistrict.getGlobalVisibleRect(rect);
        int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));

        addActionView(mElderLyLocationWheel, true, sexCoverViewHeight, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT), false);
    }

    // 添加地區模塊的選擇按鈕
    private void addRegionView() {
        if (mSelectDistrictPo == null) {
            ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.profile_no_district_search, R.string.common_confirm, 0, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            }, null);
            return;
        }
        mElderLyLocationWheel = new ElderlyLocationWheel(getActivity());
        mElderLyLocationWheel.setSelectDrawable(R.drawable.setting_area_on);
        mElderLyLocationWheel.setupData(UserProfileManager.getInstance().getRegionList(mSelectDistrictPo.getKey()), mSelectLocationPo);
        mElderLyLocationWheel.setControlBarBgColor(R.color.header_ProfileSetting);
        mElderLyLocationWheel.setConfirmBgColor(R.color.header_ProfileSetting_HeightLight);
        mElderLyLocationWheel.setLocationWheelListener(new LocationWheelListener() {
            @Override
            public void onClick(boolean isConfirm, Object data) {
                if (isConfirm) {
                    mSelectLocationPo = (LocationPo) data;
                    mTxtRegion.setText(((LocationPo) data).getName());
                    UserProfileManager.getInstance().updateUserRegion(((LocationPo) data).getKey());
                    ElderlyApplication.me.savePref("easysearch_region", mElderLyLocationWheel.getSelected() + "");


                }
                hideOverContextView();
                mElderLyLocationWheel.releaseWheel();
                UserProfileManager.getInstance().alReadlyShowUserRegionTip();
            }
        });
        Rect rect = new Rect();
        mTxtRegion.getGlobalVisibleRect(rect);
        int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
        addActionView(mElderLyLocationWheel, true, sexCoverViewHeight, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT), false);
    }

    private void showUserNameTip(boolean anim) {
        if (UserProfileManager.getInstance().isNeedShowUserNameTip()) {
            Rect rect = new Rect();
            mEdTxtName.getGlobalVisibleRect(rect);
            int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
            addGuidView(sexCoverViewHeight, Constants.getGuide(1), anim, 1);
        } else {
            hideOverContextView();
        }
    }

    private void showUserSexTip(boolean anim) {
        if (UserProfileManager.getInstance().isNeedShowUserSexTip()) {
            Rect rect = new Rect();
            mTxtSex.getGlobalVisibleRect(rect);
            int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
            addGuidView(sexCoverViewHeight, Constants.getGuide(2), anim, 2);
        } else {
            hideOverContextView();
        }
    }

    private void showUserRegionTip(boolean anim) {
        if (UserProfileManager.getInstance().isNeedShowUserDistrictTip()) {
            Rect rect = new Rect();
            mTxtDistrict.getGlobalVisibleRect(rect);
            int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
            addGuidView(sexCoverViewHeight, Constants.getGuide(3), anim, 3);
        } else {
            hideOverContextView();
        }
    }

    private void showUserLocationTip(boolean anim) {
        if (UserProfileManager.getInstance().isNeedShowUserRegionTip()) {
            Rect rect = new Rect();
            mTxtRegion.getGlobalVisibleRect(rect);
            int sexCoverViewHeight = (int) (rect.bottom - getLayerHeaderRect().bottom + ElderlyUtil.dip2px(getActivity(), 10));
            addGuidView(sexCoverViewHeight, Constants.getGuide(4), anim, 4);
        } else {
            hideOverContextView();
        }
    }

    @Override
    public void onDestroyView() {
        mTxtSex.release();
        mEdTxtName.release();
        mTxtDistrict.release();
        mTxtRegion.release();
        mTxtSex.setOnSimpleTextChangeListener(null);
        mEdTxtName.setOnSimpleTextChangeListener(null);
        mTxtDistrict.setOnSimpleTextChangeListener(null);
        mTxtRegion.setOnSimpleTextChangeListener(null);
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        setupData();
        setupListener();
    }

}
