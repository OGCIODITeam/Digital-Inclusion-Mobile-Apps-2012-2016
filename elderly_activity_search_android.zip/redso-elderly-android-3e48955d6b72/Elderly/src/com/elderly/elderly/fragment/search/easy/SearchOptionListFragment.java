package com.elderly.elderly.fragment.search.easy;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.elderly.elderly.ElderlyApplication;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.SearchOptionAdapter;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.fragment.templete.TempleteFragment;

import java.util.ArrayList;

public class SearchOptionListFragment extends TempleteFragment {
    private ElderlyListView mElderlyListView;
    private View mLayerConfirm;
    private FrameLayout mOverView;
    private SearchOptionAdapter mAdapter;

    String title;
    ArrayList<String> options;
    int current;
int target;
    @Override
    public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
        title=getArguments().getString("type");
        options=getArguments().getStringArrayList("options");
        current=getArguments().getInt("current");

        setTitle(title);
        setHeaderBgColor(R.color.header_ProfileSetting);
        inflater.inflate(R.layout.page_profile_my_interest, mLayerContextView);
        mElderlyListView = (ElderlyListView) mLayerContextView
                .findViewById(R.id.page_profile_my_interest_mElderlyListView);

        mLayerConfirm = mLayerContextView.findViewById(R.id.page_profile_my_interest_mLayerConfirm);
        mLayerConfirm.setBackgroundResource(R.drawable.shape_common_btn_bg);
        setupCommonBtnBgColor(mLayerConfirm, R.color.header_ProfileSetting);
        if (mAdapter == null) {
            mAdapter = new SearchOptionAdapter(getActivity());
        }
        mElderlyListView.getListView().setDividerHeight((int) getResources().getDimensionPixelSize(R.dimen.divider_line_height));
        mElderlyListView.setAdapter(mAdapter);

        mAdapter.seData(options,current);
		setupListener();


    }

	private void setupListener() {
		mLayerConfirm.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
              int selected=  mAdapter.getSelected();


                if(title.equals(getActivity().getString(R.string.header_search_interest))){
                    ElderlyApplication.me.savePref("easysearch_act", selected + "");
                }else if(title.equals(getActivity().getString(R.string.header_search_district))){
                    ElderlyApplication.me.savePref("easysearch_dist", selected + "");
                    ElderlyApplication.me.savePref("easysearch_region", 0 + "");
                }
                else if(title.equals(getActivity().getString(R.string.header_search_region))){
                    ElderlyApplication.me.savePref("easysearch_region", selected + "");

                }
                else if(title.equals(getActivity().getString(R.string.header_search_month))){
                    ElderlyApplication.me.savePref("easysearch_month", selected + "");
                }
				getTabNavigationFragment().pop();
			}
		});
	}


}
