package com.elderly.elderly.fragment.profile;

import java.util.List;

import org.xmlpull.v1.XmlPullParserException;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.CommunityListAdapter;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.component.ElderlyListView.ListOnScrollListener;
import com.elderly.elderly.fragment.search.advance.SearchAdvanceFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;

public class ProfileCommunityListFragment extends TempleteFragment {
	private static final String TAG = "ProfileCommunityListFragment";
	public static final String KEY_STORE_LOCATION = "key_store_location";
	public static final String Key_STORE_SAVE_LOCATION_CENTRE = "key_store_save_local_centre";
	private ElderlyListView mElderlyListView;
	private View mLayerConfirm;
	private FrameLayout mOverView;
	private CommunityListAdapter mAdapter;
	private List<CommunityCentreAO> mData;
	private List<CommunityCentreAO> mLastCallData;
	private int mOffset = 0;// 最后一次call api 数据offset
	private LocationPo mLocationPo;
	private boolean mCallApiing;
	private int mSaveDataIndex;// 用于保存本地数据的index
	private boolean mNoResult = false;
	private boolean mSaveLocalCentre;
	private ElderlyAsyncTask mElderlyAsyncTask;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		if (getArguments() != null) {
			mLocationPo = (LocationPo) getArguments().getSerializable(KEY_STORE_LOCATION);
			mSaveDataIndex = getArguments().getInt(ProfileMyCommunityFragment.KEY_STORE_INDEX);
			mSaveLocalCentre = getArguments().getBoolean(Key_STORE_SAVE_LOCATION_CENTRE, false);
		}
		setTitle(R.string.header_my_community);
		inflater.inflate(R.layout.page_profile_my_interest, mLayerContextView);
		mElderlyListView = (ElderlyListView) mLayerContextView
				.findViewById(R.id.page_profile_my_interest_mElderlyListView);

		mLayerConfirm = mLayerContextView.findViewById(R.id.page_profile_my_interest_mLayerConfirm);
		mLayerConfirm.setBackgroundResource(R.drawable.shape_common_btn_bg);
		setupCommonBtnBgColor(mLayerConfirm, getSchemeColorId());
		if (mAdapter == null) {
			mAdapter = new CommunityListAdapter(getActivity(), getHeaderType());
		}
		mElderlyListView.getListView().setDividerHeight(
				(int) getResources().getDimensionPixelSize(R.dimen.divider_line_height));
		mElderlyListView.setAdapter(mAdapter);
		mAdapter.setData(mData);
		setupListener();
		showInterestTip();
		UserProfileManager.getInstance().alReadlyShowUserInterestTip();
		callApi();
	}

	private void setupListener() {
		mLayerConfirm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				CommunityCentreAO ao = mAdapter.getSelectData();
				if (mSaveLocalCentre) {
					Log.i(TAG, ">>>>>>mSaveLocalCentre");
					if (ao != null) {
						List<CommunityCentreAO> mMyCommunityCentres = UserProfileManager.getInstance()
								.readMyCommunityCentre();
						boolean findCentreInLocal = false;
						if (mMyCommunityCentres != null) {
							for (int i = 0; i < mMyCommunityCentres.size(); i++) {
								if (mMyCommunityCentres.get(i).getVid() != null && ao.getVid() != null) {
									if (mMyCommunityCentres.get(i).getVid().equals(ao.getVid())) {
										findCentreInLocal = true;
										break;
									}
								}
							}
						}
						if (!findCentreInLocal) {
							Log.i(TAG, ">>>>>>mSaveLocalCentre>>>!findCentreInLocal");
							ao.setIndex(mSaveDataIndex);
							UserProfileManager.getInstance().saveMyCommunityCentre(ao);
							getTabNavigationFragment().popPrevious(null);
						} else {
							Log.i(TAG, ">>>>>>mSaveLocalCentre>>>findCentreInLocal");
							ElderlyUtil.showElderlyDialog(getActivity(), R.string.common_dialog_title, 0,
									R.string.tip_already_has_center, R.string.common_confirm, 0, null, null);
						}
					}else{
						getTabNavigationFragment().popPrevious(null);
					}
				} else {
					Log.i(TAG, ">>>>>>!mSaveLocalCentre");
					Bundle bundle = new Bundle();
					bundle.putSerializable(SearchAdvanceFragment.KEY_STORE_ORGANIZER, ao);
					getTabNavigationFragment().pop(bundle);
				}
			}
		});
		mElderlyListView.setListOnScrollListener(new ListOnScrollListener() {

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
			}

			@Override
			public void onScrollEnd(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				callApi();

			}
		});
	}

	private void showInterestTip() {
		if (UserProfileManager.getInstance().isNeedShowUserCommunityDetailPart3Tip()) {
			UserProfileManager.getInstance().alReadlyShowUserCommunityDetailPart3Tip();
			addGuidView(0, Constants.getGuide(10));
			mOverView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					hideOverContextView();

				}
			});
		} else {
			hideOverContextView();
		}
	}

	// 添加guidview的圖片指導圖
	private void addGuidView(int marginTop, int resId) {
		mOverView = showOverContextView(marginTop, false);
		mOverView.removeAllViews();
		ImageView sexGuidView = new ImageView(getActivity());
		FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		parms.gravity = Gravity.CENTER;
		parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
		sexGuidView.setImageResource(resId);
		sexGuidView.setContentDescription("提示：请选择一间长者中心");
		mOverView.addView(sexGuidView, parms);
	}

	private void callApi() {
		Log.v(TAG, "call api");
		if (!mCallApiing) {
			mCallApiing = true;
			if (mNoResult) {
				return;
			}
			mElderlyAsyncTask=new ElderlyAsyncTask<Void, Void, Void>(getActivity()) {

				@Override
				protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {

					// int offset = 0;
					// if (mData != null) {
					// offset = mData.size();
					// }
					if (mLastCallData != null) {
						Log.v(TAG, "mLastCallData>>" + mLastCallData.size());
					}

					// mOffset = offset;
					try {
						mLastCallData = ApiManager.getInstance()
								.getCommunityCentreList(mLocationPo.getValue(), mOffset, 20);

					} catch (XmlPullParserException e) {
						e.printStackTrace();
					} finally {
						mCallApiing = false;
					}
					return null;
				}

				@Override
				protected void doOnSuccess(Void result) {
					if (mData == null) {
						mData = mLastCallData;
						mAdapter.setData(mData);
					} else {
						mData.addAll(mLastCallData);
						mAdapter.addData(mLastCallData);
					}
					if (mLastCallData != null && mLastCallData.size() == 0) {
						mNoResult = true;
					} else {
						mNoResult = false;
					}
					mOffset += mLastCallData.size();
					mLastCallData = null;
				}
				
				@Override
				protected boolean showCustomLoading() {
					return true;
				}
				@Override
				protected void callCustomLoading() {
					showLoadingView();
				}
				
				@Override
				protected void cancelCustomLoading() {
					hideLoadingView();
					super.cancelCustomLoading();
				}
				
				@Override
				protected void onCancelled() {
					ApiManager.getInstance().cancelCallCommunityCentreList();
					super.onCancelled();
				}

			};
			setCurrentAsyncTask(mElderlyAsyncTask);
			mElderlyAsyncTask.execute((Void) null);

		}
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
	}

}
