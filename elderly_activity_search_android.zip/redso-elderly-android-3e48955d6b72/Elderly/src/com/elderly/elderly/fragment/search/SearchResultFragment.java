package com.elderly.elderly.fragment.search;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import lib.gt.ga.v2.GAManager;

import org.xmlpull.v1.XmlPullParserException;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.FrameLayout;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.MyLCSDSimpleAdapter;
import com.elderly.elderly.adapter.SearchResultAdapter;
import com.elderly.elderly.component.ElderlyDayPicker;
import com.elderly.elderly.component.ElderlyDayPicker.DayPickerListener;
import com.elderly.elderly.component.ElderlyExpandListView;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.component.ElderlyMonthPicker;
import com.elderly.elderly.component.ElderlyMonthPicker.MonthPickerListener;
import com.elderly.elderly.component.ElderlyMonthSelect;
import com.elderly.elderly.component.ElderlySimplyCalendar;
import com.elderly.elderly.component.ElderlySimplyCalendar.OnCalendarClickListener;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.ActivityCenterAO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

public class SearchResultFragment extends TempleteFragment {
	private static final String TAG = "SearchResultFragment";

	public static final String KEY_EVENT_TYPE = "key_event_type";
	public static final String KEY_ACTIVE_AREA = "key_active_type";
	public static final String KEY_DATE_L = "key_date_l";
	public static final String KEY_DATE_E = "key_date_e";
	public static final String KEY_AGE = "key_age";
	public static final String KEY_FEE = "key_fee";
	public static final String KEY_ORGANIZATION = "key_organization";
	public static final String KEY_KEYWORD = "key_keyword";
	public static final String KEY_TITLE_NAME = "key_title_name";
	public static final String KEY_LATITUDE = "key_latitude";
	public static final String KEY_LONGITUDE = "key_longitude";
	public static final String KEY_SEARCH_DISTANCE = "key_search_distance";
	public static final String KEY_MONTH_TYPE = "key_month_type";// 按月搜索

	public static final String NEAR_RESULT_TITLE = "NEAR_RESULT_TITLE";
	public static final String ADVANCE_RESULT_TITLE = "ADVANCE_RESULT_TITLE";
	public static final String EASY_RESULT_TITLE = "NEAR_RESULT_TITLE";

	public static final String KEY_SEARCH_NEARBY_LIVE_LOCATION = "key_search_nearby";

	private View mLayerTab;
	private View mTxtElderlyCentre;
	private View mTxtLCSD;
	private View mLayerDivider;
	private ElderlyDayPicker mElderlyDayPicker;
	private FrameLayout mOverContextView;
	private ElderlySimplyCalendar mElderlySimplyCalendar;
	private ElderlyExpandListView mElderlyExpandListView;
	private ElderlyMonthSelect mElderlyMonthSelect;
	private ElderlyMonthPicker mElderlyMonthPicker;
	private ElderlyListView mElderlyListView;
	private SearchResultAdapter mElderlyAdapter;
	private MyLCSDSimpleAdapter myLCSDAdapter;
	private boolean mSelectLCSD = false;
	private List<ActivityCenterAO> mActivityCenterAOs;
	private List<ActivityCenterAO> mLastCallActivityCenterAOs;
	private List<ActivityAO> mActivityAOs;
	private List<ActivityAO> mLastCallActivityAOs;
	private Date mLastChangeDate;

	private Date dateE;// 长者活动时间
	private Date dateL;// 康文处活动时间
	private String activeArea;// 活动区域
	private String eventType;// 活动类型
	private String age;
	private String fee;
	private String organization;// 活动机构
	private String keyword;
	private int mElderlyOffset;// 长者活动偏移offset
	private int mLCSDOffset;// 康文处活动偏移offset
	private String mApiType;
	private String titleName;
	private boolean mSearchNearlyByLiveLocation = false;
	private String mLatitude;
	private String mLongitude;
	private String mSearchDistance;// 公里
	private boolean mShowMonthPicker;

	private boolean mNoElderlyResult = false;
	private boolean mNoLCSDResult = false;
	private boolean mCallingApi = false;
	private ElderlyAsyncTask mAsyncTask;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_search_result, mLayerContextView);
		mLayerTab = mLayerContextView.findViewById(R.id.page_search_result_mLayerTab);
		mTxtElderlyCentre = mLayerContextView.findViewById(R.id.page_search_result_mTxtElderlyCentre);
		mTxtLCSD = mLayerContextView.findViewById(R.id.page_search_result_mTxtLCSD);
		mLayerDivider = mLayerContextView.findViewById(R.id.page_search_result_mLayerDivider);
		mElderlyDayPicker = (ElderlyDayPicker) mLayerContextView
				.findViewById(R.id.page_search_result_mElderlyDayPicker);
		mElderlyExpandListView = (ElderlyExpandListView) mLayerContextView
				.findViewById(R.id.page_search_result_mElderlyExpandListView);
		mElderlyListView = (ElderlyListView) mLayerContextView.findViewById(R.id.page_search_result_mElderlyListView);
		mElderlyMonthPicker = (ElderlyMonthPicker) mLayerContextView
				.findViewById(R.id.page_search_result_mElderlyMonthPicker);
		if (mElderlyAdapter == null) {
			mElderlyAdapter = new SearchResultAdapter(getMainActivity(), getHeaderType(),mElderlyExpandListView.getExpandableListView());
		}
		if (myLCSDAdapter == null) {
			myLCSDAdapter = new MyLCSDSimpleAdapter(getMainActivity());
		}
		mElderlyExpandListView.setAdapter(mElderlyAdapter);
		mElderlyListView.setAdapter(myLCSDAdapter);

		if (mLastChangeDate != null) {
			mElderlyDayPicker.setDate(mLastChangeDate);
		} else {
			mLastChangeDate = mElderlyDayPicker.getDate();
		}

		Bundle bundle = getArguments();
		if (bundle != null) {
			mShowMonthPicker = bundle.getBoolean(KEY_MONTH_TYPE, false);
			mSearchNearlyByLiveLocation = bundle.getBoolean(KEY_SEARCH_NEARBY_LIVE_LOCATION, true);
			activeArea = bundle.getString(KEY_ACTIVE_AREA);
			if (dateL == null) {
				if (bundle.getString(KEY_DATE_L) != null) {
					dateL = CLDateUtil.formatDate(bundle.getString(KEY_DATE_L), Constants.DATE_FORMAT_PATTERN_API);
				} else {
					dateL = new Date();
				}
			}
			if (dateE == null) {
				if (bundle.getString(KEY_DATE_E) != null) {
					dateE = CLDateUtil.formatDate(bundle.getString(KEY_DATE_E), Constants.DATE_FORMAT_PATTERN_API);
				} else {
					dateE = new Date();
				}
			}
			if (mShowMonthPicker) {
				mElderlyMonthPicker.setVisibility(View.VISIBLE);
				mElderlyDayPicker.setVisibility(View.INVISIBLE);
			} else {
				mElderlyMonthPicker.setVisibility(View.INVISIBLE);
				mElderlyDayPicker.setVisibility(View.VISIBLE);
			}
			mLatitude = bundle.getString(KEY_LATITUDE);
			mLongitude = bundle.getString(KEY_LONGITUDE);
			mSearchDistance = bundle.getString(KEY_SEARCH_DISTANCE);
			eventType = bundle.getString(KEY_EVENT_TYPE);
			age = bundle.getString(KEY_AGE);
			fee = bundle.getString(KEY_FEE);
			organization = bundle.getString(KEY_ORGANIZATION);
			keyword = bundle.getString(KEY_KEYWORD);
			titleName = bundle.getString(KEY_TITLE_NAME);
			Log.i(TAG, "test>>" + CLDateUtil.formatDate(dateE,
					Constants.DATE_FORMAT_PATTERN_API)
					+ "1..." + eventType
					+ "2..." + activeArea + "3..." + age + "4..." + fee + "5..." + organization
					+ "6..." + keyword);
		}
		if (mSearchNearlyByLiveLocation) {
			mLayerDivider.setBackgroundColor(getResources().getColor(getSchemeHightColorId()));
			mLayerTab.setVisibility(View.VISIBLE);
		} else {
			mLayerDivider.setBackgroundColor(getResources().getColor(R.color.transparent));
			mLayerTab.setVisibility(View.GONE);
		}
		if (titleName != null) {
			setTitle(titleName);
		}

		setupListener();
		selectTab();
	}

	private void callApi() {
		Log.v(TAG, "call api>>" + mCallingApi);
		if (!mCallingApi) {
			mCallingApi = true;
			if (!mSearchNearlyByLiveLocation && mNoElderlyResult) {
				mCallingApi = false;
				return;
			} else {
				if (!mSelectLCSD) {
					if (mNoElderlyResult) {
						mCallingApi = false;
						return;
					}
				} else {
					if (mNoLCSDResult) {
						mCallingApi = false;
						return;
					}
				}
			}

			mAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity()) {

				@Override
				protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
					try {
						if (!mSearchNearlyByLiveLocation) {
							// Log.i(TAG, "mSearchNearlyByLiveLocation>>" + CLDateUtil.formatDate(dateE,
							// Constants.DATE_FORMAT_PATTERN_API)
							// + "1..." + eventType
							// + "2..." + activeArea + "3..." + age + "4..." + fee + "5..." + organization
							// + "6..." + keyword);
							if (mNoElderlyResult) {
								return null;
							}
							mLastCallActivityCenterAOs = ApiManager.getInstance().getSearchNearbyList(mSearchDistance,
									mLatitude, mLongitude,
									CLDateUtil.formatDate(dateE, Constants.DATE_FORMAT_PATTERN_API), null,
									mElderlyOffset);
						} else {
							if (!mSelectLCSD) {
								if (mNoElderlyResult) {
									return null;
								}
								if (mShowMonthPicker) {
									if (keyword != null) {
										mLastCallActivityCenterAOs = ApiManager.getInstance().getSearchElderlyList(
												CLDateUtil.formatDate(dateE, Constants.DATE_FORMAT_PATTERN_API2), null,
												null, null, null, null, keyword, mElderlyOffset);
									} else {
										mLastCallActivityCenterAOs = ApiManager.getInstance().getElderlyEasySearchList(
												CLDateUtil.formatDate(dateE, Constants.DATE_FORMAT_PATTERN_API2),
												mElderlyOffset, eventType, activeArea);
									}
								} else {
									mLastCallActivityCenterAOs = ApiManager.getInstance().getSearchElderlyList(
											CLDateUtil.formatDate(dateE, Constants.DATE_FORMAT_PATTERN_API), eventType,
											activeArea, age, fee,
											organization, keyword, mElderlyOffset);
								}
							} else {
								// Log.i(TAG, "callapi>>" + dateL);
								if (mNoLCSDResult) {
									return null;
								}
								if (mShowMonthPicker) {
									if (keyword != null) {
										mLastCallActivityAOs = ApiManager.getInstance().getSearchLcsdListByKeyword(
												CLDateUtil.formatDate(dateL, Constants.DATE_FORMAT_PATTERN_API2),
												keyword, mLCSDOffset);
									} else {
										mLastCallActivityAOs = ApiManager.getInstance().getLCSDEasySearchList(
												CLDateUtil.formatDate(dateL, Constants.DATE_FORMAT_PATTERN_API2),
												mLCSDOffset, eventType, activeArea);
									}
								} else {
									mLastCallActivityAOs = ApiManager.getInstance().getSearchLcsdList(
											CLDateUtil.formatDate(dateL, Constants.DATE_FORMAT_PATTERN_API), eventType,
											activeArea, age, fee,
											organization, keyword, mLCSDOffset);
								}
							}
						}
					} catch (XmlPullParserException e) {
						e.printStackTrace();
					}
					return null;
				}

				@Override
				protected boolean handleException(Exception ex) {
					mCallingApi = false;
					return super.handleException(ex);
				}

				@Override
				protected void doOnSuccess(Void result) {
					setupData();
					mCallingApi = false;
				}

				@Override
				protected boolean showCustomLoading() {
					return true;
				}

				@Override
				protected void callCustomLoading() {
					showLoadingView();
				}

				@Override
				protected void cancelCustomLoading() {
					hideLoadingView();
					super.cancelCustomLoading();
				}

				@Override
				protected void onCancelled() {
					ApiManager.getInstance().cancelCallSearchLcsdList();
					ApiManager.getInstance().cancelCallSearchElderlyList();
					ApiManager.getInstance().cancelCallSearchNearbyList();
					ApiManager.getInstance().cancelCallSearchLcsdListByKeyword();
					ApiManager.getInstance().cancelCallElderlyEasySearchList();
					ApiManager.getInstance().cancelCallLCSDEasySearchList();
					
					super.onCancelled();
				}
			};
			setCurrentAsyncTask(mAsyncTask);
			mAsyncTask.execute((Void) null);
		}
	}

	protected void setupData() {
		Log.v(TAG, "setupData>>");
		// Log.i(TAG, "mActivityCenterAOs" +
		// mActivityCenterAOs.size()+"..."+mActivityCenterAOs.get(0).getActivityCenterName_tc());

		Log.i(TAG, "setupData>>" + dateE + "...dateL+dateE..." + dateL);
		if (!mSelectLCSD) {
			if (mActivityCenterAOs == null) {
				mActivityCenterAOs = mLastCallActivityCenterAOs;
				mElderlyAdapter.setData(mActivityCenterAOs, dateE);
			} else if (mActivityCenterAOs != null && mLastCallActivityCenterAOs != null) {
				mActivityCenterAOs.addAll(mLastCallActivityCenterAOs);
				mElderlyAdapter.addData(mLastCallActivityCenterAOs);
			}

			if ((mLastCallActivityCenterAOs != null && mLastCallActivityCenterAOs.size() == 0)) {
				mNoElderlyResult = true;
			} else {
				mNoElderlyResult = false;
			}
			if (mLastCallActivityCenterAOs != null) {
				// int offset = 0;
				// for (int i = 0; i < mLastCallActivityCenterAOs.size(); i++) {
				// List<ActivityAO> subList = mLastCallActivityCenterAOs.get(i).getActivityList();
				// if (subList != null) {
				// offset += subList.size();
				// }
				//
				// }
				mElderlyOffset += mLastCallActivityCenterAOs.size();
			}
			mApiType = ActivityDetailFragment.TYPE_ELDERLY;
			mElderlyDayPicker.setDate(dateE);
			mElderlyExpandListView.setVisibility(View.VISIBLE);
			mElderlyListView.setVisibility(View.GONE);
		} else {

			if (mActivityAOs == null) {
				mActivityAOs = mLastCallActivityAOs;
				myLCSDAdapter.setData(mLastCallActivityAOs, dateL);
			} else if (mActivityCenterAOs != null && mLastCallActivityCenterAOs != null) {
				mActivityAOs.addAll(mLastCallActivityAOs);
				myLCSDAdapter.addData(mLastCallActivityAOs);
			}

			if ((mLastCallActivityAOs != null && mLastCallActivityAOs.size() == 0)) {
				mNoLCSDResult = true;
			} else {
				mNoLCSDResult = false;
			}
			if (mLastCallActivityAOs != null) {
				mLCSDOffset += mLastCallActivityAOs.size();
			}
			mApiType = ActivityDetailFragment.TYPE_LCSD;
			mElderlyDayPicker.setDate(dateL);
			mElderlyListView.setVisibility(View.VISIBLE);
			mElderlyExpandListView.setVisibility(View.GONE);
		}
	}

	private void setupListener() {

		mElderlyExpandListView.getExpandableListView().setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
				ActivityAO ao = mActivityCenterAOs.get(groupPosition).getActivityList().get(childPosition);
				callActivityDetailApi(ao.getId(), mApiType);
				// Bundle bundle = new Bundle();
				// bundle.putString(ActivityDetailFragment.KEY_STORE_ID, ao.getId());
				// bundle.putString(ActivityDetailFragment.KEY_STORE_TYPE, mApiType);
				// bundle.putString(HEADER_TYPE, getHeaderType().name());
				// ActivityDetailFragment adf = new ActivityDetailFragment();
				// adf.setArguments(bundle);
				// getTabNavigationFragment().push(adf);
				return false;
			}
		});

		mElderlyExpandListView.setListOnScrollListener(new ElderlyExpandListView.ListOnScrollListener() {

			@Override
			public void onScrollEnd(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				callApi();
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub

			}
		});

		mElderlyListView.getListView().setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				ActivityAO ao = mActivityAOs.get(position);
				callActivityDetailApi(ao.getId(), mApiType);
				// Bundle bundle = new Bundle();
				// Log.i(TAG,ao.getId()+"...mApiType..."+mApiType);
				// bundle.putString(ActivityDetailFragment.KEY_STORE_ID, ao.getId());
				// bundle.putString(ActivityDetailFragment.KEY_STORE_TYPE, mApiType);
				// bundle.putString(HEADER_TYPE, getHeaderType().name());
				// ActivityDetailFragment adf = new ActivityDetailFragment();
				// adf.setArguments(bundle);
				// getTabNavigationFragment().push(adf);
			}
		});
		mElderlyListView.setListOnScrollListener(new ElderlyListView.ListOnScrollListener() {

			@Override
			public void onScrollEnd(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				callApi();
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub

			}
		});
		mElderlyDayPicker.setDayPickerListener(new DayPickerListener() {

			@Override
			public void onClick(View view, Date currentDate) {
				mOverContextView = showOverContextView(0, false);
				if (mElderlySimplyCalendar == null) {
					mElderlySimplyCalendar = new ElderlySimplyCalendar(getMainActivity());
					mElderlySimplyCalendar.setWeekOfFirstDay(Calendar.SUNDAY);
					mElderlySimplyCalendar.setOnCalendarClickListener(new OnCalendarClickListener() {

						@Override
						public void onClick(Date selectDay) {
							mElderlyDayPicker.setDate(selectDay);
							hideOverContextView();
							mOverContextView.removeAllViews();
							onPickerDateChange(selectDay);
						}
					});

				}
				mElderlySimplyCalendar.updateSelectedCalendar(currentDate);
				mElderlySimplyCalendar.updateCalendar();
				FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT);
				lp.gravity = Gravity.CENTER;
				lp.leftMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
				lp.rightMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
				mOverContextView.addView(mElderlySimplyCalendar, lp);
				mOverContextView.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						hideOverContextView();

					}
				});
				mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).setFocusable(true);
				mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).setFocusableInTouchMode(true);
				mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).requestFocus();
			}

			@Override
			public void onPickerDateChange(Date currentData) {
				onDateChange(currentData);

			}
		});

		mElderlyMonthPicker.setMonthPickerListener(new MonthPickerListener() {

			@Override
			public void onPickerDateChange(Date currentData) {
				GAManager.getInstance().trackEvent(Constants.MY_DATE, Constants.GA_ACTION_CLICK, "");
				onDateChange(currentData);
			}

			@Override
			public void onClick(View view, Date currentDate) {
				GAManager.getInstance().trackEvent(Constants.MY_DATE, Constants.GA_ACTION_CLICK, "");
				mOverContextView = showOverContextView(0, false);
				if (mElderlyMonthSelect == null) {
					mElderlyMonthSelect = new ElderlyMonthSelect(getMainActivity());
					mElderlyMonthSelect.setOnCalendarClickListener(new ElderlyMonthSelect.OnCalendarClickListener() {

						@Override
						public void onClick(Date selectDay) {
							mElderlyMonthPicker.setDate(selectDay);
							hideOverContextView();
							onPickerDateChange(selectDay);
						}
					});

				}
				mElderlyMonthSelect.updateSelectedCalendar(currentDate);
				mElderlyMonthSelect.updateCalendar();
				FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
						FrameLayout.LayoutParams.WRAP_CONTENT);
				lp.gravity = Gravity.CENTER;
				lp.leftMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
				lp.rightMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
				mOverContextView.addView(mElderlyMonthSelect, lp);
				mOverContextView.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						hideOverContextView();

					}
				});
				mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).setFocusable(true);
				mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).setFocusableInTouchMode(true);
				mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).requestFocus();
			}
		});
		mTxtElderlyCentre.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mSelectLCSD = false;
				selectTab();
			}
		});
		mTxtLCSD.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mSelectLCSD = true;
				selectTab();
			}
		});

	}

	protected void onDateChange(Date currentData) {
		// mLastChangeDate = currentData;
		if (mSelectLCSD) {
			mLCSDOffset = 0;
			mNoLCSDResult = false;
			myLCSDAdapter.setData(null, null);
			if (mActivityAOs != null) {
				mActivityAOs.clear();
				mActivityAOs = null;
			}

			dateL = currentData;
			Log.i(TAG, "onDateChange>>" + dateL);
		} else {
			mNoElderlyResult = false;
			mElderlyOffset = 0;
			mElderlyAdapter.setData(null, null);
			if (mActivityCenterAOs != null) {
				mActivityCenterAOs.clear();
				mActivityCenterAOs = null;
			}
			dateE = currentData;
			Log.i(TAG, "onDateChange>>" + dateE);
		}
		callApi();
	}

	private void selectTab() {
		if (mSelectLCSD) {
			mApiType = ActivityDetailFragment.TYPE_LCSD;
			mElderlyExpandListView.setVisibility(View.GONE);
			mElderlyListView.setVisibility(View.VISIBLE);
			if (dateL != null) {
				mElderlyDayPicker.setDate(dateL);
				mElderlyMonthPicker.setDate(dateL);
			}
			setupCommonBtnBgColor(mTxtElderlyCentre, getSchemeColorId());
			setupCommonBtnBgColor(mTxtLCSD, getSchemeHightColorId());
			if (mActivityAOs == null) {
				callApi();
			}
		} else {
			mApiType = ActivityDetailFragment.TYPE_ELDERLY;
			mElderlyExpandListView.setVisibility(View.VISIBLE);
			mElderlyListView.setVisibility(View.GONE);
			if (dateE != null) {
				mElderlyDayPicker.setDate(dateE);
				mElderlyMonthPicker.setDate(dateE);
			}
			setupCommonBtnBgColor(mTxtElderlyCentre, getSchemeHightColorId());
			setupCommonBtnBgColor(mTxtLCSD, getSchemeColorId());
			if (mActivityCenterAOs == null) {
				callApi();
			}
		}

	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent keyEvent) {
		if (isOverContextViewVisible()) {
			hideOverContextView();
			return true;
		}
		return false;
	}
	
	public void callActivityDetailApi(String id){
		callActivityDetailApi(id,mApiType);
	}
}
