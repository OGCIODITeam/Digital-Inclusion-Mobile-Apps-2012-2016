package com.elderly.elderly.fragment.events.my;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.Language;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.MyElderlyCentreAdapter;
import com.elderly.elderly.adapter.MyLCSDAdapter;
import com.elderly.elderly.component.ElderlyExpandListView;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.component.ElderlyMonthPicker;
import com.elderly.elderly.component.ElderlyMonthPicker.MonthPickerListener;
import com.elderly.elderly.component.ElderlyMonthSelect;
import com.elderly.elderly.component.ElderlySimplyCalendar;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.db.DBManager;
import com.elderly.elderly.pojo.dbo.ActivityDetailDBO;
import com.elderly.elderly.pojo.dbo.ElderlyCenterDBO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import lib.gt.ga.v2.GAManager;

public class MyActivityFragment extends TempleteFragment {
	private View mTxtElderlyCentre;
	private View mTxtLCSD;
	private View mLayerDivider;

	private ElderlyMonthPicker mElderlyMonthPicker;
	private FrameLayout mOverContextView;
	private ElderlySimplyCalendar mElderlySimplyCalendar;
	private ElderlyMonthSelect mElderlyMonthSelect;
	private ElderlyExpandListView mElderlyExpandListView;
	private ElderlyListView mElderlyListView;

	private MyLCSDAdapter mLCSDAdapter;
	private List<ActivityDetailDBO> mLCSDData;
	private MyElderlyCentreAdapter mElderlyCentreAdapter;
	private List<ElderlyCenterDBO> mElderlyCenterData;
	private HashMap<String, List<ActivityDetailDBO>> mElderlyActivityData;
	private boolean mSelectLCSD = false, isFirstTimeIn;
	private Date mLastLCSDSelectDate;
	private Date mLastElderlySelectDate;
	private ElderlyAsyncTask mAsyncTask;
	private FrameLayout myOverView;
	private SharedPreferences sf;
	private String FirstTimeIn = "FirstTimeIn", TimeIn = "TimeIn";

	@Override
	public void setupContextView(LayoutInflater inflater,
			ViewGroup mLayerContextView) {
		setTitle(R.string.header_my_activity);
		inflater.inflate(R.layout.page_my_activity, mLayerContextView);
		sf = getActivity().getSharedPreferences(FirstTimeIn,
				Context.MODE_PRIVATE);
		mTxtElderlyCentre = mLayerContextView
				.findViewById(R.id.page_my_activity_mTxtElderlyCentre);
		mTxtLCSD = mLayerContextView
				.findViewById(R.id.page_my_activity_mTxtLCSD);
		mLayerDivider = mLayerContextView
				.findViewById(R.id.page_my_activity_mLayerDivider);
		mElderlyExpandListView = (ElderlyExpandListView) mLayerContextView
				.findViewById(R.id.page_my_activity_mElderlyExpandListView);
		mElderlyListView = (ElderlyListView) mLayerContextView
				.findViewById(R.id.page_my_activity_mElderlyListView);
		mElderlyMonthPicker = (ElderlyMonthPicker) mLayerContextView
				.findViewById(R.id.page_my_activity_mElderlyMonthPicker);
		mLayerDivider.setBackgroundColor(getResources().getColor(
				getSchemeHightColorId()));
		if (mLastLCSDSelectDate == null) {
			mLastLCSDSelectDate = mElderlyMonthPicker.getDate();
		}
		if (mLastElderlySelectDate == null) {
			mLastElderlySelectDate = mElderlyMonthPicker.getDate();
		}
		if (mElderlyCentreAdapter == null) {
			mElderlyCentreAdapter = new MyElderlyCentreAdapter(
					getMainActivity(), getHeaderType(),mElderlyExpandListView.getExpandableListView());
		}
		if (mLCSDAdapter == null) {
			mLCSDAdapter = new MyLCSDAdapter(getActivity());
		}
		mElderlyListView.setAdapter(mLCSDAdapter);
		mElderlyExpandListView.setAdapter(mElderlyCentreAdapter);
		setupListener();
		selectTab();

		GAManager.getInstance().trackView(Constants.MY_PG_MYACTIVITY);

	}

	String failToDelete;
	private void showDeleteDialog(final int[] pos , String title){
		String titleL = ""; 
		if (Language.CurrentLanguage != Language.Chinese) {
			titleL = "是否刪除【"+title+"】？";
			failToDelete = "刪除失敗！";
		}else {
			titleL = "是否删除【"+title+"】？";
			failToDelete = "删除失败！";
		}
		ElderlyUtil.showElderlyDialog(getActivity(), R.string.common_dialog_title, 0, titleL,
				R.string.common_cancel, R.string.common_ok, null, new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						int result = 0;
						if (pos.length == 1) {
							int posistion = pos[0];
							String id =  mLCSDData.get(posistion).getId();
							result = DBManager.getInstance().delete(id);
							if (result == 1) {
								mLCSDData.remove(posistion);
								mLCSDAdapter.notifyDataSetChanged();
							}else {
								Toast.makeText(getActivity(), failToDelete, Toast.LENGTH_SHORT).show();
							}
//							obtainData();
						}else{
							int groupPosition = pos[0];
							int childPosition = pos[1];
							String id = mElderlyCentreAdapter.getChild(groupPosition, childPosition).getId();
							result = DBManager.getInstance().delete(id);
							if (result == 1) {
								String key = mElderlyCenterData.get(groupPosition).getCenterId();
								mElderlyActivityData.get(key).remove(childPosition);
								if (mElderlyActivityData.get(key).size() < 1) {
									mElderlyCenterData.remove(groupPosition);
									mElderlyActivityData.remove(key);
									mElderlyExpandListView.setState(groupPosition);
								}
							}else {
								Toast.makeText(getActivity(), failToDelete, Toast.LENGTH_SHORT).show();
							}
							mElderlyCentreAdapter.notifyDataSetChanged();
//							obtainData();
						}
					}

				});
	}
	
	private void setupListener() {
		mElderlyListView.getListView().setOnItemClickListener(
				new OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						ActivityDetailDBO ao = mLCSDData.get(position);
						Bundle bundle = new Bundle();
						bundle.putSerializable(
								ActivityDetailFragment.KEY_STORE_ACTIVITY_DETAIL,
								ao);
						// bundle.putString(ActivityDetailFragment.KEY_STORE_ID,
						// ao.getId());
						// bundle.putString(ActivityDetailFragment.KEY_STORE_TYPE,
						// "L");
						bundle.putString(HEADER_TYPE, getHeaderType().name());
						ActivityDetailFragment adf = new ActivityDetailFragment();
						adf.setArguments(bundle);
						getTabNavigationFragment().push(adf);
					}
				});
		mElderlyListView.getListView().setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int position, long id) {
				ActivityDetailDBO ao = mLCSDData.get(position);
				showDeleteDialog(new int[]{position},ao.getTitle());
				return true;
			}
			
		});
		mElderlyExpandListView.getExpandableListView().setOnChildClickListener(
				new OnChildClickListener() {

					@Override
					public boolean onChildClick(ExpandableListView parent,
							View v, int groupPosition, int childPosition,
							long id) {
						Log.e("groupPosition", ""+groupPosition);
						Log.e("childPosition", ""+childPosition);
						ActivityDetailDBO ao = mElderlyCentreAdapter.getChild(
								groupPosition, childPosition);
						if (ao != null) {
							Bundle bundle = new Bundle();
							bundle.putSerializable(
									ActivityDetailFragment.KEY_STORE_ACTIVITY_DETAIL,
									ao);
							bundle.putString(HEADER_TYPE, getHeaderType()
									.name());
							ActivityDetailFragment adf = new ActivityDetailFragment();
							adf.setArguments(bundle);
							getTabNavigationFragment().push(adf);
						}
						return false;
					}
				});
		mElderlyExpandListView.getExpandableListView().setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int position, long id) {
				if(arg1.getTag() != null){
					int pos = arg1.getTag().toString().indexOf("-");
					if(pos != -1){
						String str = arg1.getTag().toString();
						String[] ss = str.split("-");
						int groupPosition = Integer.parseInt(ss[0]);
						int childPosition = Integer.parseInt(ss[1]);
//						Log.e("Lon ggroupPosition", ""+groupPosition);
//						Log.e("childPosition", ""+childPosition);
						ActivityDetailDBO ao = mElderlyCentreAdapter.getChild(
								groupPosition, childPosition);
						if (ao != null) {
							showDeleteDialog(new int[]{groupPosition,childPosition},ao.getTitle());
						}
						return true;
					}else{
						return false;
					}
				}else{
					return false;
				}
			}
			
		});


		mElderlyMonthPicker.setMonthPickerListener(new MonthPickerListener() {

			@Override
			public void onPickerDateChange(Date currentData) {
				GAManager.getInstance().trackEvent(Constants.MY_DATE,
						Constants.GA_ACTION_CLICK, "");
				onDateChange(currentData);
			}

			@Override
			public void onClick(View view, Date currentDate) {
				GAManager.getInstance().trackEvent(Constants.MY_DATE,
						Constants.GA_ACTION_CLICK, "");
				mOverContextView = showOverContextView(0, false);
				if (mElderlyMonthSelect == null) {
					mElderlyMonthSelect = new ElderlyMonthSelect(
							getMainActivity());
					mElderlyMonthSelect
							.setOnCalendarClickListener(new ElderlyMonthSelect.OnCalendarClickListener() {

								@Override
								public void onClick(Date selectDay) {
									mElderlyMonthPicker.setDate(selectDay);
									hideOverContextView();
									onPickerDateChange(selectDay);
								}
							});

				}
				mElderlyMonthSelect.updateSelectedCalendar(currentDate);
				mElderlyMonthSelect.updateCalendar();
				FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
						FrameLayout.LayoutParams.MATCH_PARENT,
						FrameLayout.LayoutParams.WRAP_CONTENT);
				lp.gravity = Gravity.CENTER;
				lp.leftMargin = (int) getResources().getDimension(
						R.dimen.view_calendar_margin_horizontal);
				lp.rightMargin = (int) getResources().getDimension(
						R.dimen.view_calendar_margin_horizontal);
				mOverContextView.addView(mElderlyMonthSelect, lp);
				mOverContextView.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						hideOverContextView();

					}
				});
				mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).setFocusable(true);
				mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).setFocusableInTouchMode(true);
				mElderlyMonthSelect.findViewById(R.id.view_month_select_focus).requestFocus();
			}
		});
		mTxtElderlyCentre.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				mSelectLCSD = false;
				selectTab();
			}
		});
		new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
			}
		};
		mTxtLCSD.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				mSelectLCSD = true;
				selectTab();
			}
		});

	}

	protected void onDateChange(Date currentData) {
		// mLastChangeDate = currentData;
		if (mSelectLCSD) {
			mLastLCSDSelectDate = currentData;
		} else {
			mLastElderlySelectDate = currentData;
		}
		obtainData();
	}
	
	private void selectTab() {
		if (mSelectLCSD) {
			mElderlyExpandListView.setVisibility(View.INVISIBLE);
			mElderlyListView.setVisibility(View.VISIBLE);
			setupCommonBtnBgColor(mTxtElderlyCentre, getSchemeColorId());
			setupCommonBtnBgColor(mTxtLCSD, getSchemeHightColorId());
			mElderlyMonthPicker.setDate(mLastLCSDSelectDate);
			if (mLCSDData == null) {
				obtainData();
			}
		} else {
			mElderlyExpandListView.setVisibility(View.VISIBLE);
			mElderlyListView.setVisibility(View.INVISIBLE);
			setupCommonBtnBgColor(mTxtElderlyCentre, getSchemeHightColorId());
			setupCommonBtnBgColor(mTxtLCSD, getSchemeColorId());
			mElderlyMonthPicker.setDate(mLastElderlySelectDate);
			if (mElderlyActivityData == null) {
				obtainData();
			}

		}

	}

	private void obtainData() {
		mAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity()) {

			@Override
			protected Void doInBackground(Void params)
					throws CLInvalidNetworkException, CLConnectionException {
				if (mSelectLCSD) {
					mLCSDData = DBManager.getInstance().getLCSDData(
							mLastLCSDSelectDate);
				} else {
					mElderlyCenterData = DBManager.getInstance()
							.getElderlyGroupList(mLastElderlySelectDate);
					mElderlyActivityData = DBManager.getInstance()
							.getElderlyActvitys(mLastElderlySelectDate,
									mElderlyCenterData);
				}
				return null;
			}

			@Override
			protected void doOnSuccess(Void result) {
				isFirstTimeIn = sf.getBoolean(TimeIn, false);
				if (!isFirstTimeIn)
					showDeleteTips();
				if (mSelectLCSD) {
					mElderlyListView.setAdapter(null);
					mLCSDAdapter.setData(mLCSDData, mLastLCSDSelectDate);
					mElderlyListView.setAdapter(mLCSDAdapter);
				} else {
					mElderlyExpandListView
							.setAdapter((BaseExpandableListAdapter) null);
					mElderlyCentreAdapter.setGroupData(mElderlyCenterData,
							mElderlyActivityData, mLastElderlySelectDate);
					mElderlyExpandListView.setAdapter(mElderlyCentreAdapter);
				}

			}

			@Override
			protected boolean showCustomLoading() {
				return true;
			}

			@Override
			protected void callCustomLoading() {
				showLoadingView();
			}

			@Override
			protected void cancelCustomLoading() {
				hideLoadingView();
				super.cancelCustomLoading();
			}

		};
		setCurrentAsyncTask(mAsyncTask);
		mAsyncTask.execute((Void) null);
	}

	/**
	 * 显示删除功能操作提示
	 */
	private void showDeleteTips() {
		myOverView = showOverContextView(
				(int) ElderlyUtil.dip2px(getActivity(), 0), false);
		ImageView sexGuidView = new ImageView(getActivity());
		FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		parms.gravity = Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL;
		parms.topMargin = (int) ElderlyUtil.dip2px(getActivity(), 10);
		if (Language.CurrentLanguage != Language.Chinese) {
			sexGuidView.setImageResource(R.drawable.guide12_tc);
		}else {
			sexGuidView.setImageResource(R.drawable.guide12_sc);
		}
		sexGuidView.setContentDescription("提示：长按活动名称可以删除");
		myOverView.addView(sexGuidView, parms);
		sf.edit().putBoolean(TimeIn, true).commit();
		myOverView.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				hideOverContextView();
			}
		});
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent keyEvent) {
		if (isOverContextViewVisible()) {
			hideOverContextView();
			return true;
		}
		return false;
	}
}
