package com.elderly.elderly.fragment.search.advance;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import lib.gt.ga.v2.GAManager;

import org.xmlpull.v1.XmlPullParserException;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyHotTextLayer;
import com.elderly.elderly.component.ElderlyHotTextLayer.HotKeyClickListener;
import com.elderly.elderly.component.ElderlyLocationWheel;
import com.elderly.elderly.component.ElderlyLocationWheel.LocationWheelListener;
import com.elderly.elderly.component.ElderlySimplyCalendar;
import com.elderly.elderly.component.ElderlySimplyCalendar.OnCalendarClickListener;
import com.elderly.elderly.fragment.profile.ProfileCommunityListFragment;
import com.elderly.elderly.fragment.search.SearchResultFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.elderly.elderly.pojo.ao.KeyWordAO;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLDateUtil;

public class SearchAdvanceFragment extends TempleteFragment {
	private static final String TAG = "SearchAdvanceFragment";
	public static final String KEY_STORE_ACTIVITY_CATEGORY = "key_store_activity_category";
	public static final String KEY_STORE_ORGANIZER = "key_store_organizer";
	private TextView mTxtSearchActivity;
	private TextView mTxtSearchHot;
	private View mLayerDivider;
	private ElderlyHotTextLayer mHotTextLayer;
	private View mLayerSearch;
	private View mTableLayout;

	private TextView mTxtActivityCategory;
	private TextView mTxtActivityCategoryTip;
	private TextView mTxtLocation;
	private TextView mTxtLocationTip;
	private TextView mTxtOrganizers;
	private TextView mTxtOrganizersTip;
	private TextView mTxtMonth;
	private TextView mTxtMonthTip;
	private EditText mTxtAge;
	private TextView mTxtAgeTip;
	private TextView mTxtCost;
	private TextView mTxtCostTip;
	private EditText mTxtKeyWord;
	private TextView mTxtKeyWordTip;
	private FrameLayout mOverView;
	private ElderlyLocationWheel mElderlyLocationWheel;
	private View mScrollLayer;

	private List<ActivityCategoryPo> mSelectInterestList;
	private List<KeyWordAO> mKeyWordData;
	private LocationPo mSelectLocationPo;
	private String mSelectFeeForSearch;// for search
	private String mSelectFee;// for show
	private boolean mSelectHotKey = false;
	private ElderlySimplyCalendar mElderlySimplyCalendar;
	private Date mLastSelectDate;
	private CommunityCentreAO mSelectCommunityCentreAO;
	private ElderlyAsyncTask mHotKeyAsyncTask;

	private TextWatcher mTextWatcher;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		setTitle(R.string.header_search_advance);
		inflater.inflate(R.layout.page_search_advance, mLayerContextView);
		mTxtSearchActivity = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtSearchActivity);
		mTxtSearchHot = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtSearchHot);
		mLayerDivider = mLayerContextView.findViewById(R.id.page_search_advance_mLayerDivider);
		mHotTextLayer = (ElderlyHotTextLayer) mLayerContextView.findViewById(R.id.page_search_advance_mHotTextLayer);
		mLayerSearch = mLayerContextView.findViewById(R.id.page_search_advance_mLayerSearch);
		mTableLayout = mLayerContextView.findViewById(R.id.page_search_advance_mTableLayout);
		mTxtActivityCategory = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtActivityCategory);
		mTxtActivityCategoryTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtActivityCategoryTip);
		mTxtLocation = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtLocation);
		mTxtLocationTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtLocationTip);
		mTxtOrganizers = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtOrganizers);
		mTxtOrganizersTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtOrganizersTip);
		mTxtMonth = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtMonth);
		mTxtMonthTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtMonthTip);
		mTxtAge = (EditText) mLayerContextView.findViewById(R.id.page_search_advance_mTxtAge);
		mTxtAgeTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtAgeTip);
		mTxtCost = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtCost);
		mTxtCostTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtCostTip);
		mTxtKeyWord = (EditText) mLayerContextView.findViewById(R.id.page_search_advance_mTxtKeyWord);
		mTxtKeyWordTip = (TextView) mLayerContextView.findViewById(R.id.page_search_advance_mTxtKeyWordTip);
		mScrollLayer = mLayerContextView.findViewById(R.id.page_search_advance_mScrollLayer);
		// mHotTextLayer.setHotKey(data);

		mLayerDivider.setBackgroundColor(getResources().getColor(getSchemeHightColorId()));

		setupListener();
		selectTab();

		setupData();

		setupCommonBtnBgColor(mLayerSearch, getSchemeColorId());
		setTipColor(getSchemeColorId());
		setTxtColor(R.color.black);

		if (mKeyWordData != null) {
			mHotTextLayer.setHotKey(mKeyWordData);
		} else {
			callKeyWorkApi();
		}

		GAManager.getInstance().trackView(Constants.ADV_ACTIVITYLOCATION);
	}

	private void setupData() {
		StringBuffer mActivityCategorys = new StringBuffer();
		if (getArguments() != null) {
			mSelectInterestList = (List<ActivityCategoryPo>) getArguments().getSerializable(KEY_STORE_ACTIVITY_CATEGORY);
			if (mSelectInterestList != null && mSelectInterestList.size() > 0) {
				mActivityCategorys.append(mSelectInterestList.get(0).getName());
				for (int i = 1; i < mSelectInterestList.size(); i++) {
					mActivityCategorys.append("丶");
					mActivityCategorys.append(mSelectInterestList.get(i).getName());
				}
			}

			mSelectCommunityCentreAO = (CommunityCentreAO) getArguments().getSerializable(KEY_STORE_ORGANIZER);
			if (mSelectCommunityCentreAO != null) {
				String data = mSelectCommunityCentreAO.getFieldElderlyOrganizationValue();
				if (data == null || data.equals("")) {
					data = mSelectCommunityCentreAO.getFieldElderlyCentreValue();
				}
				mTxtOrganizers.setText(data);
			}

		}

		mTxtActivityCategory.setText(mActivityCategorys.toString());
		if (mSelectLocationPo != null) {
			mTxtLocation.setText(mSelectLocationPo.getName());
		}
		if (mLastSelectDate != null) {
			String date = CLDateUtil.formatDate(mLastSelectDate, Constants.DATE_FORMAT_PATTERN_API);
			mTxtMonth.setText(date);
		}
		if (mSelectFee != null) {
			mTxtCost.setText(mSelectFee);
		}

		if (!"".equals(mTxtActivityCategory.getText()) && mTxtActivityCategory.getText() != null) {
			mTxtActivityCategory.setContentDescription(null);
		} else {
			mTxtActivityCategory.setContentDescription(getString(R.string.voice_page_search_adv_activity_category));
		}
		if (!"".equals(mTxtLocation.getText()) && mTxtLocation.getText() != null) {
			mTxtLocation.setContentDescription(null);
		} else {
			mTxtLocation.setContentDescription(getString(R.string.voice_page_search_adv_activity_location));
		}
		if (!"".equals(mTxtOrganizers.getText()) && mTxtOrganizers.getText() != null) {
			mTxtOrganizers.setContentDescription(null);
		} else {
			mTxtOrganizers.setContentDescription(getString(R.string.voice_page_search_adv_organizers));
		}
		if (!"".equals(mTxtMonth.getText()) && mTxtMonth.getText() != null) {
			mTxtMonth.setContentDescription(null);
		} else {
			mTxtMonth.setContentDescription(getString(R.string.voice_page_search_adv_month));
		}
		if (!"".equals(mTxtCost.getText()) && mTxtCost.getText() != null) {
			mTxtCost.setContentDescription(null);
		} else {
			mTxtCost.setContentDescription(getString(R.string.voice_page_search_adv_cost));
		}
		mTxtAge.addTextChangedListener(mTextWatcher);
	}

	private void setupListener() {
		mTxtKeyWord.setOnFocusChangeListener(new OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				GAManager.getInstance().trackEvent(Constants.ADV_KEYWORD, Constants.GA_ACTION_CLICK, "");
				if (!hasFocus) {
					getMainActivity().hideKeyBoard();
				}
			}
		});

		mTxtAge.setOnFocusChangeListener(new OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				GAManager.getInstance().trackEvent(Constants.ADV_AGE, Constants.GA_ACTION_CLICK, "");
				if (!hasFocus) {
					getMainActivity().hideKeyBoard();
				}
			}
		});
		mTxtSearchActivity.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mSelectHotKey = false;
				selectTab();

			}
		});
		mTxtSearchHot.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_HOTKEY, Constants.GA_ACTION_CLICK, "");
				mSelectHotKey = true;
				selectTab();

			}
		});
		mTxtActivityCategory.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_ACTIVITYTYPE, Constants.GA_ACTION_CLICK, "");

				getMainActivity().hideKeyBoard();
				SelectInterestFragment sif = new SelectInterestFragment();
				Bundle bundle = new Bundle();
				bundle.putString(TempleteFragment.HEADER_TYPE, HeaderType.SearchAdvance.name());
				bundle.putSerializable(SearchAdvanceFragment.KEY_STORE_ACTIVITY_CATEGORY, (Serializable) mSelectInterestList);
				sif.setArguments(bundle);
				getTabNavigationFragment().push(sif);

			}
		});
		mTxtLocation.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_ACTIVITYLOCATION, Constants.GA_ACTION_CLICK, "");
				showLocationWheel();
			}
		});
		mTxtMonth.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_DATE, Constants.GA_ACTION_CLICK, "");
				showMonthWheel();

			}
		});
		mLayerSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_SEARCHBUTTON, Constants.GA_ACTION_CLICK, "");
				getMainActivity().hideKeyBoard();
				if (!ElderlyUtil.isConnectNetWork(getMainActivity())) {
					return;
				}
				SearchResultFragment srf = new SearchResultFragment();
				Bundle bundle = new Bundle();
				bundle.putString(HEADER_TYPE, getHeaderType().name());
				bundle.putString(SearchResultFragment.KEY_TITLE_NAME, getString(R.string.header_search_result_advance));
				String tempCategory = "";
				if (mSelectInterestList != null) {
					for (ActivityCategoryPo temp : mSelectInterestList) {
						tempCategory += (temp.getNameTc() + ",");
					}
				}
				Log.i(TAG, "tempCategory>>>" + tempCategory + "...");

				if (mLastSelectDate != null) {
					bundle.putString(SearchResultFragment.KEY_DATE_E, CLDateUtil.formatDate(mLastSelectDate, Constants.DATE_FORMAT_PATTERN_API));
					bundle.putString(SearchResultFragment.KEY_DATE_L, CLDateUtil.formatDate(mLastSelectDate, Constants.DATE_FORMAT_PATTERN_API));
					Log.i(TAG, "mLastSelectDate>>>" + mLastSelectDate);
				} else {
					String currentDate = ElderlyUtil.getCurrentDate();
					bundle.putString(SearchResultFragment.KEY_DATE_E, currentDate);
					bundle.putString(SearchResultFragment.KEY_DATE_L, currentDate);
					Log.i(TAG, "currentDate>>>" + currentDate);
				}
				if (mSelectLocationPo != null) {
					bundle.putString(SearchResultFragment.KEY_ACTIVE_AREA, mSelectLocationPo.getValue());
					Log.i(TAG, "mSelectLocationPo>>>" + mSelectLocationPo.getNameTc());
				}

				if (!"".equals(mTxtAge.getText().toString().trim())) {
					bundle.putString(SearchResultFragment.KEY_AGE, mTxtAge.getText().toString().trim());
					Log.i(TAG, "mTxtAge>>>" + mTxtAge.getText().toString().trim());
				}

				if (!"".equals(tempCategory)) {
					bundle.putString(SearchResultFragment.KEY_EVENT_TYPE, tempCategory);
					Log.i(TAG, "tempCategory>>>" + tempCategory);
				}

				if (!"".equals(mSelectFeeForSearch)) {
					bundle.putString(SearchResultFragment.KEY_FEE, mSelectFeeForSearch);
					Log.i(TAG, "mTxtCost>>>" + mTxtCost.getText().toString().trim() + "...mSelectFeeForSearch..." + mSelectFeeForSearch);
				}

				if (!"".equals(mTxtKeyWord.getText().toString().trim())) {
					bundle.putString(SearchResultFragment.KEY_KEYWORD, mTxtKeyWord.getText().toString().trim());
					Log.i(TAG, "mTxtKeyWord>>>" + mTxtKeyWord.getText().toString().trim());
				}

				if (mSelectCommunityCentreAO != null) {
					bundle.putString(SearchResultFragment.KEY_ORGANIZATION, mSelectCommunityCentreAO.getNid());
					Log.i(TAG, "mSelectCommunityCentreAO>>>" + mSelectCommunityCentreAO.getNid());
				}
				srf.setArguments(bundle);
				getTabNavigationFragment().push(srf);
			}
		});
		mHotTextLayer.setHotKeyClickListener(new HotKeyClickListener() {

			@Override
			public void onClick(KeyWordAO keyword) {
				SearchResultFragment srf = new SearchResultFragment();
				Bundle bundle = new Bundle();
				bundle.putString(HEADER_TYPE, getHeaderType().name());
				bundle.putBoolean(SearchResultFragment.KEY_MONTH_TYPE, true);
				bundle.putString(SearchResultFragment.KEY_KEYWORD, keyword.getCode_tc());
				bundle.putString(SearchResultFragment.KEY_TITLE_NAME, getString(R.string.header_search_result_advance));
				String currentDate = ElderlyUtil.getCurrentDate();
				bundle.putString(SearchResultFragment.KEY_DATE_E, currentDate);
				bundle.putString(SearchResultFragment.KEY_DATE_L, currentDate);
				Log.i(TAG, "Search KeyWord>>>>>>>" + currentDate + "......" + keyword.getCode_tc());
				srf.setArguments(bundle);
				getTabNavigationFragment().push(srf);
			}
		});
		mTxtOrganizers.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_ORGANIZATION, Constants.GA_ACTION_CLICK, "");
				getMainActivity().hideKeyBoard();
				if (mSelectLocationPo != null) {
					if (!ElderlyUtil.isConnectNetWork(getMainActivity())) {
						return;
					}
					ProfileCommunityListFragment pclf = new ProfileCommunityListFragment();
					Bundle bundle = new Bundle();
					bundle.putSerializable(ProfileCommunityListFragment.KEY_STORE_LOCATION, mSelectLocationPo);
					bundle.putString(HEADER_TYPE, getHeaderType().name());
					bundle.putBoolean(ProfileCommunityListFragment.Key_STORE_SAVE_LOCATION_CENTRE, false);
					pclf.setArguments(bundle);
					getTabNavigationFragment().push(pclf);
				} else {
					ElderlyUtil.showElderlyDialog(getMainActivity(), R.string.common_dialog_title, 0, R.string.page_activity_organize_tip, R.string.common_confirm, 0, null, null);
				}
			}
		});

		mTxtCost.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.ADV_PRICE, Constants.GA_ACTION_CLICK, "");
				mTxtCost.requestFocus();
				showFeeWheel();
			}
		});

		mTextWatcher = new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				if (!"".equals(s.toString()) && s.toString() != null) {
					mTxtAge.setContentDescription(null);
				} else {
					mTxtAge.setContentDescription(getString(R.string.voice_page_search_adv_age));
				}
			}
		};
	}

	private void selectTab() {
		hideKeyBoard();
		if (mSelectHotKey) {
			setupCommonBtnBgColor(mTxtSearchActivity, getSchemeColorId());
			setupCommonBtnBgColor(mTxtSearchHot, getSchemeHightColorId());
			mScrollLayer.setVisibility(View.VISIBLE);
			mHotTextLayer.setIsLayout();
			mHotTextLayer.setVisibility(View.VISIBLE);
			mLayerSearch.setVisibility(View.GONE);
			mTableLayout.setVisibility(View.GONE);
		} else {
			setupCommonBtnBgColor(mTxtSearchActivity, getSchemeHightColorId());
			setupCommonBtnBgColor(mTxtSearchHot, getSchemeColorId());
			mScrollLayer.setVisibility(View.GONE);
			mHotTextLayer.setVisibility(View.GONE);
			mLayerSearch.setVisibility(View.VISIBLE);
			mTableLayout.setVisibility(View.VISIBLE);
		}
	}

	private void setTipColor(int colorId) {
		setTextColor(mTxtActivityCategoryTip, colorId);
		setTextColor(mTxtLocationTip, colorId);
		setTextColor(mTxtOrganizersTip, colorId);
		setTextColor(mTxtMonthTip, colorId);
		setTextColor(mTxtAgeTip, colorId);
		setTextColor(mTxtCostTip, colorId);
		setTextColor(mTxtKeyWordTip, colorId);
	}

	private void setTxtColor(int colorId) {
		setTextColor(mTxtActivityCategory, colorId);
		setTextColor(mTxtLocation, colorId);
		setTextColor(mTxtOrganizers, colorId);
		setTextColor(mTxtMonth, colorId);
		setTextColor(mTxtAge, colorId);
		setTextColor(mTxtCost, colorId);
		setTextColor(mTxtKeyWord, colorId);
	}

	private void setTextColor(TextView view, int colorId) {
		if (view != null) {
			view.setTextColor(getResources().getColor(colorId));
		}
	}

	private void showLocationWheel() {
		mOverView = showOverContextView(0, false, true);
		List<LocationPo> mLocation = new ArrayList<LocationPo>();
		List<DistrictPo> mDistricts = UserProfileManager.getInstance().getDistrictPoList();
		for (int i = 0; i < mDistricts.size(); i++) {
			mLocation.addAll(mDistricts.get(i).getRegions());
		}
		mElderlyLocationWheel = new ElderlyLocationWheel(getActivity());
		int drawableId = R.drawable.search_area_selected;
		if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme2) {
			drawableId = R.drawable.search_area_selected2;
		}
		mElderlyLocationWheel.setSelectDrawable(drawableId);
		mElderlyLocationWheel.setupData(mLocation, mSelectLocationPo);
		mElderlyLocationWheel.setControlBarBgColor(getSchemeColorId());
		mElderlyLocationWheel.setConfirmBgColor(getSchemeHightColorId());
		mElderlyLocationWheel.setLocationWheelListener(new LocationWheelListener() {
			@Override
			public void onClick(boolean isConfirm, Object data) {
				if (isConfirm) {
					mSelectLocationPo = (LocationPo) data;
					mTxtLocation.setText(mSelectLocationPo.getName());
				}
				hideOverContextView();
				mElderlyLocationWheel.releaseWheel();
			}
		});
		int margin = (int) ElderlyUtil.dip2px(getActivity(), 20);

		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
		lp.gravity = Gravity.CENTER;
		lp.rightMargin = margin;
		lp.leftMargin = margin;
		mOverView.addView(mElderlyLocationWheel, lp);
		mElderlyLocationWheel.requestFocus();
	}

	private void showMonthWheel() {
		getMainActivity().hideKeyBoard();
		mOverView = showOverContextView(0, false, true);
		if (mElderlySimplyCalendar == null) {
			mElderlySimplyCalendar = new ElderlySimplyCalendar(getMainActivity());
			mElderlySimplyCalendar.setWeekOfFirstDay(Calendar.SUNDAY);
			mElderlySimplyCalendar.setOnCalendarClickListener(new OnCalendarClickListener() {

				@Override
				public void onClick(Date selectDay) {
					hideOverContextView();
					mLastSelectDate = selectDay;
					if (mLastSelectDate != null) {
						String date = CLDateUtil.formatDate(mLastSelectDate, Constants.DATE_FORMAT_PATTERN_SHOW_SPECIAL);
						mTxtMonth.setText(date);
					}
				}
			});

		}
		mElderlySimplyCalendar.updateSelectedCalendar(mLastSelectDate);
		mElderlySimplyCalendar.updateCalendar();
		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		lp.gravity = Gravity.CENTER;
		lp.leftMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
		lp.rightMargin = (int) getResources().getDimension(R.dimen.view_calendar_margin_horizontal);
		mOverView.addView(mElderlySimplyCalendar, lp);
		mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).setFocusable(true);
		mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).setFocusableInTouchMode(true);
		mElderlySimplyCalendar.findViewById(R.id.view_calendar_focus).requestFocus();
	}

	private void showFeeWheel() {
		mOverView = showOverContextView(0, false, true);
		final List<String> mFee = new ArrayList<String>();
		String[] fees = getResources().getStringArray(R.array.fee);
		String[] feesDescription = getResources().getStringArray(R.array.voice_fee);
		for (int i = 0; i < fees.length; i++) {
			mFee.add(fees[i]);
		}
		mElderlyLocationWheel = new ElderlyLocationWheel(getActivity());
		int drawableId = R.drawable.search_area_selected3;
		if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme2) {
			drawableId = R.drawable.search_area_selected4;
		}
		mElderlyLocationWheel.setSelectDrawable(drawableId);
		mElderlyLocationWheel.setListContentDescription(feesDescription);
		mElderlyLocationWheel.setupData(mFee, mSelectFeeForSearch);
		mElderlyLocationWheel.setControlBarBgColor(getSchemeColorId());
		mElderlyLocationWheel.setConfirmBgColor(getSchemeHightColorId());
		mElderlyLocationWheel.setLocationWheelListener(new LocationWheelListener() {
			@Override
			public void onClick(boolean isConfirm, Object data) {
				if (isConfirm) {
					String[] feeForSearch = getResources().getStringArray(R.array.fee_for_search);
					mSelectFee = (String) data;
					int i = mFee.indexOf((String) data);
					mSelectFeeForSearch = feeForSearch[i];
					Log.i(TAG, "feeforsearch>>>>>" + mSelectFeeForSearch);
					mTxtCost.setText((String) data);
				}
				hideOverContextView();
				mElderlyLocationWheel.releaseWheel();
			}
		});
		int margin = (int) ElderlyUtil.dip2px(getActivity(), 20);

		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
		lp.gravity = Gravity.CENTER;
		lp.rightMargin = margin;
		lp.leftMargin = margin;
		mOverView.addView(mElderlyLocationWheel, lp);
		mElderlyLocationWheel.requestFocus();
	}

	public void callKeyWorkApi() {
		mHotKeyAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getMainActivity(), true) {

			@Override
			protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
				try {
					mKeyWordData = ApiManager.getInstance().getKeyWordList();
					Log.i(TAG, "mKeyWordData>>>" + mKeyWordData.get(0).getCode());
				} catch (XmlPullParserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return null;
			}

			@Override
			protected void doOnSuccess(Void result) {
				if (mKeyWordData != null) {
					// Log.i(TAG, "mKeyWordData>>>" + mKeyWordData.get(1).getCode());
					mHotTextLayer.setHotKey(mKeyWordData);
				}

			}

			@Override
			protected boolean showCustomLoading() {
				return true;
			}

			@Override
			protected void callCustomLoading() {
				showLoadingView();
			}

			@Override
			protected void cancelCustomLoading() {
				hideLoadingView();
				super.cancelCustomLoading();
			}

			@Override
			protected void onCancelled() {
				ApiManager.getInstance().cancelCallKeyWordList();
				super.onCancelled();
			}
		};
		setCurrentAsyncTask(mHotKeyAsyncTask);
		mHotKeyAsyncTask.execute((Void) null);
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent keyEvent) {
		if (isOverContextViewVisible()) {
			hideOverContextView();
			return true;
		}
		return false;
	}

	@Override
	public void onDestroyView() {
		if (mTxtAge != null) {
			mTxtAge.removeTextChangedListener(mTextWatcher);
		}
		hideKeyBoard();
		super.onDestroyView();
	}

	private void hideKeyBoard() {
		getMainActivity().hideKeyBoard();
	}

	@Override
	protected int getWindowSoftInputMode() {
		return WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
	}

}
