package com.elderly.elderly.fragment.templete;

import android.app.Activity;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.R;
import com.elderly.elderly.anim.MarginTopAnimation;
import com.elderly.elderly.fragment.ElderlyFragment;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.events.favorite.FavoriteCenterFragment;
import com.elderly.elderly.fragment.profile.ProfileInformationFragment;
import com.elderly.elderly.fragment.profile.ProfileMyCommunityFragment;
import com.elderly.elderly.fragment.search.easy.SearchEasyFragment;
import com.elderly.elderly.fragment.search.near.SearchNearFragment;
import com.elderly.elderly.fragment.setting.SettingFragment;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;

import org.xmlpull.v1.XmlPullParserException;

import lib.gt.ga.v2.GAManager;

public abstract class TempleteFragment extends ElderlyFragment {
    private static final String TAG = "TempleteFragment";
    public static final String HEADER_TYPE = "header_type";
    public static final String HEADER_TITLE_ID = "header_title";
    private View mLayerHeader;
    private TextView mTxtHeaderTitle;
    private View mBtnBack;
    private View mBtnLocation;
    private View mBtnSetting;
    private View mRootView;
    private FrameLayout mLayerContextView;
    private FrameLayout mLayerOverContextView;
    private FrameLayout mLayerLoadingView;
    private Rect mLayerHeaderRect;
    private int mSchemeColorId;
    private int mSchemeHightColorId;
    protected Bundle savedInstanceState;
    private HeaderType mHeaderType;
    private int mTitleId = -1;
    private ElderlyAsyncTask<Void, Void, Void> mCallActivityDetailAsyncTask;

    public TempleteFragment curFragment;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.v(TAG, "onCreateView>>" + getTag() + "," + savedInstanceState);
        getActivity().getWindow().setSoftInputMode(getWindowSoftInputMode());
        this.savedInstanceState = savedInstanceState;
        mRootView = inflater.inflate(R.layout.page_templete, container, false);
        mLayerHeaderRect = new Rect();
        mLayerHeader = mRootView.findViewById(R.id.page_templete_mLayerHeader);
        mBtnBack = mRootView.findViewById(R.id.page_templete_mBtnBack);
        mBtnLocation = mRootView.findViewById(R.id.page_templete_mBtnLocation);
        mBtnSetting = mRootView.findViewById(R.id.page_templete_mBtnSetting);
        mTxtHeaderTitle = (TextView) mRootView.findViewById(R.id.page_templete_mTxtHeaderTitle);
        mLayerContextView = (FrameLayout) mRootView.findViewById(R.id.page_templete_mLayerContextView);
        mLayerOverContextView = (FrameLayout) mRootView.findViewById(R.id.page_templete_mLayerOverContextView);
        mLayerLoadingView = (FrameLayout) mRootView.findViewById(R.id.page_templete_mLayerLoadingView);
        mBtnBack.setOnClickListener(mHeaderClick);
        mBtnSetting.setOnClickListener(mHeaderClick);
        mBtnLocation.setOnClickListener(mHeaderClick);
        if (getTabNavigationFragment().getHistoryListSize() > 1) {
            showBackBtn(true);
        } else {
            showBackBtn(false);
        }
        Bundle bundle = getArguments();
        if (bundle != null) {
            String headerType = bundle.getString(HEADER_TYPE);
            mTitleId = bundle.getInt(HEADER_TITLE_ID);
            if (headerType != null) {
                mHeaderType = HeaderType.valueOf(headerType);
                if (mHeaderType != null) {
                    mSchemeColorId = Constants.getSchemeColorIdByHeaderType(mHeaderType);
                    mSchemeHightColorId = Constants.getSchemeHightLightColorIdByHeaderType(mHeaderType);
                    setHeaderBgColor(mSchemeColorId);
                }
            }
        }
        setupContextView(LayoutInflater.from(getActivity()), mLayerContextView);
        curFragment = this;
        super.onCreateView(inflater, container, savedInstanceState);
        return mRootView;
    }

    public abstract void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView);

    public void showBackBtn(boolean isShow) {
        if (mBtnBack != null) {
            if (isShow) {
                mBtnBack.setVisibility(View.VISIBLE);
            } else {
                mBtnBack.setVisibility(View.INVISIBLE);
            }
        }
    }

    public void showLocation(boolean isShow) {
        if (mBtnLocation != null && mBtnSetting != null) {
            if (isShow) {
                mBtnLocation.setVisibility(View.VISIBLE);
                mBtnSetting.setVisibility(View.GONE);
            } else {
                mBtnLocation.setVisibility(View.GONE);
                mBtnSetting.setVisibility(View.VISIBLE);
            }
        }
    }

    public void showSetting(boolean isShow) {
        if (mBtnLocation != null && mBtnSetting != null) {
            if (!isShow) {
                mBtnLocation.setVisibility(View.VISIBLE);
                mBtnSetting.setVisibility(View.GONE);
            } else {
                mBtnLocation.setVisibility(View.GONE);
                mBtnSetting.setVisibility(View.VISIBLE);
            }
        }
    }

    public void hideRightBtn() {
        if (mBtnLocation != null && mBtnSetting != null) {
            mBtnLocation.setVisibility(View.GONE);
            mBtnSetting.setVisibility(View.GONE);
        }
    }

    private View.OnClickListener mHeaderClick = new OnClickListener() {

        @Override
        public void onClick(View v) {
            headerBtnClick(v);
        }
    };

    public void headerBtnClick(View view) {
        if (view.getId() == R.id.page_templete_mBtnBack) {

//
//            if (curFragment != null) {
//
//                if (curFragment instanceof SearchResultFragment) {
//////                  GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_SETTINGBUTTON, Constants.GA_ACTION_CLICK, "");
////                    ProfileInformationFragment targetFragment = new ProfileInformationFragment();
////                    getTabNavigationFragment().push(targetFragment);
//                } else {
//                    if (getMainActivity() != null) {
//                        getMainActivity().hideKeyBoard();
//                    }
//                    getTabNavigationFragment().pop();
//                }
//
//            } else {
            if (getMainActivity() != null) {
                getMainActivity().hideKeyBoard();
            }
            getTabNavigationFragment().pop();
//            }


        } else if (view.getId() == R.id.page_templete_mBtnSetting) {
            if (getMainActivity() != null) {
                getMainActivity().hideKeyBoard();
            }
            if (curFragment != null) {
                if (curFragment instanceof SearchNearFragment || curFragment instanceof SearchEasyFragment) {
//                    GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_SETTINGBUTTON, Constants.GA_ACTION_CLICK, "");
                    ProfileInformationFragment targetFragment = new ProfileInformationFragment();
                    Bundle bundle = new Bundle();
                    if (curFragment instanceof SearchNearFragment) {
                        bundle.putString("type", "setLocation");
                    } else if (curFragment instanceof SearchEasyFragment) {
                        bundle.putString("type", "setSearchOption");
                    }

                    targetFragment.setArguments(bundle);
                    getTabNavigationFragment().push(targetFragment);
                } else if (curFragment instanceof FavoriteCenterFragment) {
//                    GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_SETTINGBUTTON, Constants.GA_ACTION_CLICK, "");
                    ProfileMyCommunityFragment targetFragment = new ProfileMyCommunityFragment();
                    getTabNavigationFragment().push(targetFragment);
                } else {
                    GAManager.getInstance().trackEvent(Constants.MAIN_PAGE_SETTINGBUTTON, Constants.GA_ACTION_CLICK, "");
                    SettingFragment sf = new SettingFragment();
                    getTabNavigationFragment().push(sf);
                }
            }
        }
    }

    public void setTitle(String str) {
        if (mTxtHeaderTitle != null) {
            mTxtHeaderTitle.setText(str);
            mTxtHeaderTitle.setFocusable(true);
            mTxtHeaderTitle.setContentDescription(str);
        }
    }

    public void setTitle(int id) {
        if (mTxtHeaderTitle != null) {
            mTxtHeaderTitle.setText(id);
            mTxtHeaderTitle.setFocusable(true);
            mTxtHeaderTitle.setContentDescription(getResources().getString(id));
        }
    }

    public TextView getTitle() {
        return mTxtHeaderTitle;
    }

    public void setHeaderBgColor(int colorId) {
        if (mLayerHeader != null) {
            mLayerHeader.setBackgroundColor(getResources().getColor(colorId));
        }
    }

    public View getRootView() {
        return mRootView;
    }

    public FrameLayout showOverContextView(int marginTop, boolean isNeedAnim, boolean hideKeyBoard) {
        if (hideKeyBoard) {
            getMainActivity().hideKeyBoard();
        }
        return showOverContextView(marginTop, isNeedAnim);
    }

    public FrameLayout showOverContextView(int marginTop, boolean isNeedAnim) {
        mLayerOverContextView.removeAllViews();
        mLayerOverContextView.setVisibility(View.VISIBLE);
        mLayerOverContextView.setClickable(true);

        final int oldMarginTop = ((RelativeLayout.LayoutParams) mLayerOverContextView.getLayoutParams()).topMargin;
        if (isNeedAnim && oldMarginTop != marginTop) {
            MarginTopAnimation animation = new MarginTopAnimation(mLayerOverContextView, 300, marginTop);
            mLayerOverContextView.startAnimation(animation);
        } else {
            ((RelativeLayout.LayoutParams) mLayerOverContextView.getLayoutParams()).topMargin = marginTop;
        }

        mLayerOverContextView.setBackgroundColor(getResources().getColor(R.color.templete_over_content_view_bg));
        mLayerOverContextView.requestLayout();
        return mLayerOverContextView;
    }

    public void hideOverContextView() {
        if (mLayerOverContextView != null) {
            mLayerOverContextView.setVisibility(View.INVISIBLE);
            mLayerOverContextView.setClickable(false);
            mLayerOverContextView.removeAllViews();
        }
    }

    public void showLoadingView() {
        if (mLayerLoadingView != null) {
            mLayerLoadingView.setVisibility(View.VISIBLE);
        }
    }

    public void hideLoadingView() {
        if (mLayerLoadingView != null) {
            mLayerLoadingView.postDelayed(new Runnable() {

                @Override
                public void run() {
                    mLayerLoadingView.setVisibility(View.INVISIBLE);
                }
            }, 500);

        }
    }

    public boolean isShowLoadingView() {
        if (mLayerLoadingView != null && mLayerLoadingView.getVisibility() == View.VISIBLE) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isOverContextViewVisible() {
        return (mLayerOverContextView.getVisibility() == View.VISIBLE) ? true : false;
    }

    public Rect getLayerHeaderRect() {
        if (mLayerHeader != null) {
            mLayerHeader.getGlobalVisibleRect(mLayerHeaderRect);
        }
        return mLayerHeaderRect;
    }

    public int getSchemeColorId() {
        return mSchemeColorId;
    }

    public int getSchemeHightColorId() {
        return mSchemeHightColorId;
    }

    public void setupCommonBtnBgColor(View view, int colorId) {
        Drawable tmp;
        tmp = view.getBackground();
        Log.v("shape", "tmp" + tmp);
        if (tmp != null && tmp instanceof GradientDrawable) {
            GradientDrawable gd = (GradientDrawable) tmp;
            gd.setColor(getResources().getColor(colorId));
            tmp = null;
        }
    }

    public void setupCommonBtnSelectorBgColor(View view, int colorId) {
        Drawable tmp;
        tmp = view.getBackground();
        Log.v("shape", "tmp" + tmp);
        if (tmp != null && tmp instanceof StateListDrawable) {
            int color = getResources().getColor(colorId);
            StateListDrawable sld = (StateListDrawable) tmp;
            sld.setState(new int[]{android.R.attr.state_enabled});
            Drawable drawable1 = sld.getCurrent();
            if (drawable1 instanceof GradientDrawable) {
                GradientDrawable gd = (GradientDrawable) drawable1;
                gd.setColor(color);
            }

            sld.setState(new int[]{android.R.attr.state_pressed});
            Drawable drawable2 = sld.getCurrent();
            int reduce = 100;
            if (drawable2 instanceof GradientDrawable) {
                GradientDrawable gd = (GradientDrawable) drawable2;
                int alpha = (color >> 24) & 0x000000FF;
                alpha -= reduce;
                if (alpha < 0) {
                    alpha = 0;
                }
                color = (alpha << 24) | (color & 0x00FFFFFF);
                gd.setColor(color);
            }
        }
    }

    public void setupCommonBtnSelectorBgColor(View view, int normalColorId, int selectedColorId, int pressedColorId) {
        Drawable tmp;
        tmp = view.getBackground();
        Log.v("shape", "tmp" + tmp);
        if (tmp != null && tmp instanceof StateListDrawable) {
            int normalColor = getResources().getColor(normalColorId);
            int selectedColor = getResources().getColor(selectedColorId);
            int pressedColor = getResources().getColor(pressedColorId);
            StateListDrawable sld = (StateListDrawable) tmp;
            sld.setState(new int[]{android.R.attr.state_enabled});
            Drawable drawable1 = sld.getCurrent();
            if (drawable1 instanceof GradientDrawable) {
                GradientDrawable gd = (GradientDrawable) drawable1;
                gd.setColor(normalColor);
            }

            sld.setState(new int[]{android.R.attr.state_pressed});
            Drawable drawable2 = sld.getCurrent();
            if (drawable2 instanceof GradientDrawable) {
                GradientDrawable gd = (GradientDrawable) drawable2;
                gd.setColor(pressedColor);
            }

            sld.setState(new int[]{android.R.attr.state_selected});
            Drawable drawable3 = sld.getCurrent();
            if (drawable3 instanceof GradientDrawable) {
                GradientDrawable gd = (GradientDrawable) drawable3;
                gd.setColor(selectedColor);
            }
        }
    }

    public HeaderType getHeaderType() {
        return mHeaderType;
    }

    public int getTitleId() {
        return mTitleId;
    }

    protected int getWindowSoftInputMode() {
        return WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
    }

    final public void callActivityDetailApi(final String mApiId, final String mApiType) {
        mCallActivityDetailAsyncTask = new ElderlyAsyncTask<Void, Void, Void>(getActivity()) {
            ActivityDetailAO mActivityDetailAO = null;

            @Override
            protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {

                if (mApiId != null && mApiType != null) {
                    try {
                        mActivityDetailAO = ApiManager.getInstance().getActivityDetail(mApiId, mApiType);
                        mActivityDetailAO.setActivityType(mApiType);
                        // Log.v(TAG, "mActivityDetailAO>>" + mActivityDetailAO);
                    } catch (XmlPullParserException e) {
                        e.printStackTrace();
                    }
                }
                return null;
            }

            @Override
            protected void doOnSuccess(Void result) {
                Log.i(TAG, mActivityDetailAO + ".LWXLWX.." + mActivityDetailAO.getId());
                if (mActivityDetailAO != null) {
                    ActivityDetailFragment adf = new ActivityDetailFragment();
                    Bundle bundle = new Bundle();
                    bundle.putAll(getArguments());
                    mActivityDetailAO.setActivityType(mApiType);
                    bundle.putSerializable(ActivityDetailFragment.KEY_STORE_ACTIVITY_DETAIL, mActivityDetailAO);
                    adf.setArguments(bundle);
                    getTabNavigationFragment().push(adf);
                } else {
                    ElderlyUtil.showElderlyDialog(getActivity(), R.string.common_dialog_title, 0, R.string.common_server_busy, R.string.common_confirm, 0, null, null);
                }
            }

            @Override
            protected boolean showCustomLoading() {
                return true;
            }

            @Override
            protected void callCustomLoading() {
                showLoadingView();
            }

            @Override
            protected void cancelCustomLoading() {
                hideLoadingView();
                super.cancelCustomLoading();
            }

            @Override
            public boolean cancelOnFragmentPush() {
                // TODO Auto-generated method stub
                return true;
            }

            @Override
            protected void onCancelled() {
                ApiManager.getInstance().cancelCallActivityDetail();
                super.onCancelled();
            }

        };
        setCurrentAsyncTask(mCallActivityDetailAsyncTask);
        mCallActivityDetailAsyncTask.execute((Void) null);
    }

    @Override
    public void onDestroyView() {
        hideOverContextView();
        super.onDestroyView();
    }

}
