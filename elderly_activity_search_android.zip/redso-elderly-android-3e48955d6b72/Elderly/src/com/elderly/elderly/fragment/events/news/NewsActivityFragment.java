package com.elderly.elderly.fragment.events.news;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.adapter.BannerPagerAdapter;
import com.elderly.elderly.adapter.NewsActivityAdapter;
import com.elderly.elderly.component.ElderlyListBanner;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.component.ElderlyListView.ListOnScrollListener;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.manager.api.ApiManager;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.BannerAO;
import com.elderly.elderly.util.ElderlyAsyncTask;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLInvalidNetworkException;

import org.xmlpull.v1.XmlPullParserException;

import java.util.List;

import lib.gt.ga.v2.GAManager;

public class NewsActivityFragment extends TempleteFragment {
	private static final String TAG = "NewsActivityFragment";
	private ElderlyListView mElderlyListView;
	// private ElderlyViewPager mViewPager;
	// private ElderlyCirclePageIndicator mViewPagerIndicator;
	private FrameLayout mOverView;
	// private View mImgVPhotoArrowLeft;
	// private View mImgVPhotoArrowRight;
	private BannerPagerAdapter mBannerAdapter;
	private ElderlyListBanner mElderlyListBanner;
	private NewsActivityAdapter mActivityAdapter;
	private List<ActivityAO> mActivityData;
	private List<ActivityAO> mLastCallActivityData;
	private List<BannerAO> mBannerData;
	private String mApiType;
	private int mActivityOffset;
	private boolean mNoResult = false;
	private boolean mCallApiing = false;
	private ElderlyAsyncTask<Void, Void, Void> mListDataAsyncTask;

	@Override
	public void setupContextView(LayoutInflater inflater, ViewGroup mLayerContextView) {
		inflater.inflate(R.layout.page_news_activity, mLayerContextView);
		mElderlyListView = (ElderlyListView) mLayerContextView.findViewById(R.id.page_news_activity_mElderlyListView);
		// mImgVPhotoArrowLeft = mLayerContextView.findViewById(R.id.page_news_activity_mImgVPhotoArrowLeft);
		// mImgVPhotoArrowRight = mLayerContextView.findViewById(R.id.page_news_activity_mImgVPhotoArrowRight);
		// mViewPager = (ElderlyViewPager) mLayerContextView.findViewById(R.id.page_news_activity_mViewPager);
		// mViewPagerIndicator = (ElderlyCirclePageIndicator) mLayerContextView
		// .findViewById(R.id.page_news_activity_mViewPagerIndicator);
		if (mActivityAdapter == null) {
			mActivityAdapter = new NewsActivityAdapter(getMainActivity(),mElderlyListView);
		}
		mElderlyListView.getListView().setDividerHeight(
				(int) getResources().getDimensionPixelSize(R.dimen.divider_line_height));
		if (mBannerAdapter == null) {
			mBannerAdapter = new BannerPagerAdapter(getActivity(), this);
		}
		initListBannerView();
		mElderlyListBanner.setBannerAdapter(mBannerAdapter);
		mElderlyListView.setHeaderView(mElderlyListBanner);
		mElderlyListView.setAdapter(mActivityAdapter);
		setTitle(R.string.header_news_activity);

		// mViewPager.setAdapter(mBannerAdapter);
		// mViewPagerIndicator.setSnap(true);
		// mViewPagerIndicator.setViewPager(mViewPager);
		// mImgVPhotoArrowLeft.setVisibility(View.INVISIBLE);
		// mImgVPhotoArrowRight.setVisibility(View.INVISIBLE);

		setupListener();

		if (mApiType == null) {
			showType();
			callBannerApi();
		}

		mElderlyListView.setIsHideEmptyTip(true);
		
		GAManager.getInstance().trackView(Constants.NEWS_ACTIVITY_PG_LATESTACTIVITY);
	}

	private void setupListener() {
		mElderlyListView.setListOnScrollListener(new ListOnScrollListener() {

			@Override
			public void onScrollEnd(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				callActivityApi();
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

			}
		});

		mElderlyListView.getListView().setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.v(TAG,"onItemClick>>"+position);
				if(mElderlyListView.getHeaderView()!=null){
					position-=1;
				}
				ActivityAO ao = mActivityData.get(position);
				callActivityDetailApi(ao.getId(),mApiType);
//				Bundle bundle = new Bundle();
//				bundle.putString(ActivityDetailFragment.KEY_STORE_ID, ao.getId());
//				bundle.putString(ActivityDetailFragment.KEY_STORE_TYPE, mApiType);
//				bundle.putString(HEADER_TYPE, HeaderType.NewsActivity.name());
//				ActivityDetailFragment adf = new ActivityDetailFragment();
//				adf.setArguments(bundle);
//				getTabNavigationFragment().push(adf);
			}
		});

	}

	// 添加guidview的圖片指導圖
	private void showGuidView() {
		mOverView = showOverContextView(0, false);
		mOverView.removeAllViews();
		ImageView sexGuidView = new ImageView(getActivity());
		FrameLayout.LayoutParams parms = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		parms.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
		parms.bottomMargin = (int) ElderlyUtil.dip2px(getActivity(), 60);
		sexGuidView.setImageResource(Constants.getGuide(11));
		sexGuidView.setContentDescription("提示：此页面可上下滑动浏览更多内容");
		mOverView.addView(sexGuidView, parms);
		mOverView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				hideOverContextView();

			}
		});
	}

	private void showType() {
		mOverView = showOverContextView(0, false);
		mOverView.removeAllViews();
		View subView = LayoutInflater.from(getActivity()).inflate(R.layout.view_activity_type, null);
		View lcsd = subView.findViewById(R.id.view_activity_type_mTxtLCSD);
		View nLcsd = subView.findViewById(R.id.view_activity_type_mTxtNotLCSD);
		setupCommonBtnBgColor(lcsd, getSchemeColorId());
		setupCommonBtnBgColor(nLcsd, getSchemeColorId());
		mOverView.addView(subView);

		lcsd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.NEWS_ACTIVITY_LCSDBUTTON, Constants.GA_ACTION_CLICK, "");
				mElderlyListView.setIsHideEmptyTip(false);
				hideOverContextView();
				mApiType = ActivityDetailFragment.TYPE_LCSD;
				mActivityAdapter.setApiType(mApiType);
				callActivityApi();

			}
		});
		nLcsd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GAManager.getInstance().trackEvent(Constants.NEWS_ACTIVITY_ELDERCENTERBUTTON, Constants.GA_ACTION_CLICK, "");
				mElderlyListView.setIsHideEmptyTip(false);
				hideOverContextView();
				mApiType = ActivityDetailFragment.TYPE_ELDERLY;
				mActivityAdapter.setApiType(mApiType);
				callActivityApi();
			}
		});

	}

	private void callActivityApi() {
		if (UserProfileManager.getInstance().isNeedShowNewActivityTip()) {
			showGuidView();
			UserProfileManager.getInstance().alReadlyShowNewActivityTip();
		}
		if (mNoResult) {
			return;
		}
		if (!mCallApiing) {
			mCallApiing = true;
			mListDataAsyncTask=new ElderlyAsyncTask<Void, Void, Void>(getActivity()) {

				@Override
				protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
					try {

						mLastCallActivityData = ApiManager.getInstance().getActivityPageList(mApiType, mActivityOffset);
						// Log.v(TAG, "mActivityData>>" + mActivityData.size());
					} catch (XmlPullParserException e) {
						e.printStackTrace();
					} finally {
						mCallApiing = false;
					}
					return null;
				}

				@Override
				protected void doOnSuccess(Void result) {
					if (mActivityData == null) {
						mActivityData = mLastCallActivityData;
						mActivityAdapter.setData(mActivityData);
					} else {
						mActivityData.addAll(mLastCallActivityData);
						mActivityAdapter.addData(mLastCallActivityData);
					}
					if ((mLastCallActivityData != null && mLastCallActivityData.size() == 0) || mActivityOffset >= 200) {
						mNoResult = true;
					} else {
						mNoResult = false;
					}
					if (mLastCallActivityData != null) {
						mActivityOffset += mLastCallActivityData.size();
					}
					// mActivityOffset += ApiManager.DEFALUT_PAGE_SIZE;
					mLastCallActivityData = null;
				}
				@Override
				protected boolean showCustomLoading() {
					return true;
				}
				@Override
				protected void callCustomLoading() {
					showLoadingView();
				}
				
				@Override
				protected void cancelCustomLoading() {
					hideLoadingView();
					super.cancelCustomLoading();
				}
				
				@Override
				protected void onCancelled() {
					ApiManager.getInstance().cancelCallActivityPageList();
					super.onCancelled();
				}
				

			};
			setCurrentAsyncTask(mListDataAsyncTask);
			mListDataAsyncTask.execute((Void) null);
		}
	}

	private void callBannerApi() {

		new ElderlyAsyncTask<Void, Void, Void>(getActivity(), false) {

			@Override
			protected Void doInBackground(Void params) throws CLInvalidNetworkException, CLConnectionException {
				try {
					mBannerData = ApiManager.getInstance().getBannerList("L");
					Log.v(TAG, "mBanner>>" + mBannerData.size());
				} catch (XmlPullParserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return null;
			}

			@Override
			protected void doOnSuccess(Void result) {
				if (mBannerData != null) {
					if (mBannerData.size() > 0) {
						mBannerAdapter.setData(mBannerData);
						mElderlyListBanner.getViewPager().setCurrentItem(0);
					}
					mElderlyListBanner.showArrow(0);
				}

			}

			@Override
			protected boolean handleException(Exception ex) {
				return true;
			}

		}.execute((Void) null);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		mNoResult = false;
		mElderlyListBanner.destory();
		// if (mBannerAdapter != null) {
		// mBannerAdapter.release();
		// }

	}

	private void initListBannerView() {
		if (mElderlyListBanner == null) {
			mElderlyListBanner = new ElderlyListBanner(getActivity());
		}
	}
	

}
