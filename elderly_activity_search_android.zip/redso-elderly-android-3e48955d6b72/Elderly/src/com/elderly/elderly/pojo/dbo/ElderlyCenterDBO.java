package com.elderly.elderly.pojo.dbo;

import android.database.Cursor;

import com.elderly.elderly.pojo.BasePO;

public class ElderlyCenterDBO extends BasePO {
	private String centerId;
	private String centerNid;
	private String activityCenterName_tc;
	private String activityCenterName_sc;
	private String organization_tc;
	private String organization_sc;
	private String categoriesValue_tc;
	private String categoriesValue_sc;

	public String getCenterId() {
		return centerId;
	}

	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	public String getCenterNid() {
		return centerNid;
	}

	public void setCenterNid(String centerNid) {
		this.centerNid = centerNid;
	}

	public String getActivityCenterName_tc() {
		return activityCenterName_tc;
	}

	public void setActivityCenterName_tc(String activityCenterName_tc) {
		this.activityCenterName_tc = activityCenterName_tc;
	}

	public String getActivityCenterName_sc() {
		return activityCenterName_sc;
	}

	public void setActivityCenterName_sc(String activityCenterName_sc) {
		this.activityCenterName_sc = activityCenterName_sc;
	}

	public String getOrganization_tc() {
		return organization_tc;
	}

	public void setOrganization_tc(String organization_tc) {
		this.organization_tc = organization_tc;
	}

	public String getOrganization_sc() {
		return organization_sc;
	}

	public void setOrganization_sc(String organization_sc) {
		this.organization_sc = organization_sc;
	}

	public String getCategoriesValue_tc() {
		return categoriesValue_tc;
	}

	public void setCategoriesValue_tc(String categoriesValue_tc) {
		this.categoriesValue_tc = categoriesValue_tc;
	}

	public String getCategoriesValue_sc() {
		return categoriesValue_sc;
	}

	public void setCategoriesValue_sc(String categoriesValue_sc) {
		this.categoriesValue_sc = categoriesValue_sc;
	}

	public void initWithCursor(Cursor cursor) {
		this.activityCenterName_sc = getStringByColumnName(cursor, "activityCenterName_sc");
		this.activityCenterName_tc = getStringByColumnName(cursor, "activityCenterName_tc");
		this.categoriesValue_sc = getStringByColumnName(cursor, "categoriesValue_sc");
		this.categoriesValue_tc = getStringByColumnName(cursor, "categoriesValue_tc");
		this.centerId = getStringByColumnName(cursor, "centerId");
		this.centerNid = getStringByColumnName(cursor, "centerNid");
		this.organization_sc = getStringByColumnName(cursor, "organization_sc");
		this.organization_tc = getStringByColumnName(cursor, "organization_tc");
	}
	
	public String getOrganization() {
		return getStringInLanguage(organization_tc, organization_sc);
	}

	public String getCategoriesValue() {
		return getStringInLanguage(categoriesValue_tc, categoriesValue_sc);
	}
	
	public String getActivityCenterName() {
		return getStringInLanguage(activityCenterName_tc, activityCenterName_sc);
	}

}
