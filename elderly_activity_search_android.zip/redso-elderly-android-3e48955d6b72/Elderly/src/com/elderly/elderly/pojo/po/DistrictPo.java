package com.elderly.elderly.pojo.po;

import java.util.ArrayList;

import android.util.Log;

public class DistrictPo extends LocationPo {
	private ArrayList<LocationPo> regions;

	public ArrayList<LocationPo> getRegions() {
		return regions;
	}

	public void setRegions(ArrayList<LocationPo> regions) {
		this.regions = regions;
	}



}
