package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class GetTokenAO extends BasePO {
	public String status;
	private String message;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
