package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class KeyWordAO extends BasePO {
	private String id;
	private String seq;
	private String code_tc;
	private String code_sc;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getCode_tc() {
		return code_tc;
	}
	public void setCode_tc(String code_tc) {
		this.code_tc = code_tc;
	}
	public String getCode_sc() {
		return code_sc;
	}
	public void setCode_sc(String code_sc) {
		this.code_sc = code_sc;
	}
	public String getCode(){
		return getStringInLanguage(code_tc, code_sc);
	}
	
	
}
