package com.elderly.elderly.pojo.ao;

import java.util.List;

import com.elderly.elderly.pojo.BasePO;

public class ActivityCenterAO extends BasePO {
	private String id;
	private String nid;
	private String activityCenterName_tc;
	private String activityCenterName_sc;
	private String organization_tc;
	private String organization_sc;
	private String longitude;
	private String latitude;
	private List<ActivityAO> activityList;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}

	public String getActivityCenterName_tc() {
		return activityCenterName_tc;
	}

	public void setActivityCenterName_tc(String activityCenterName_tc) {
		this.activityCenterName_tc = activityCenterName_tc;
	}

	public String getActivityCenterName_sc() {
		return activityCenterName_sc;
	}

	public void setActivityCenterName_sc(String activityCenterName_sc) {
		this.activityCenterName_sc = activityCenterName_sc;
	}

	public String getOrganization_tc() {
		return organization_tc;
	}

	public void setOrganization_tc(String organization_tc) {
		this.organization_tc = organization_tc;
	}

	public String getOrganization_sc() {
		return organization_sc;
	}

	public void setOrganization_sc(String organization_sc) {
		this.organization_sc = organization_sc;
	}

	public String getOrganization() {
		return getStringInLanguage(organization_tc, organization_sc);
	}

	public String getActivityCenterName() {
		return getStringInLanguage(activityCenterName_tc, activityCenterName_sc);
	}

	public void setActivityList(List<ActivityAO> activityList) {
		this.activityList = activityList;
	}
	
	public List<ActivityAO> getActivityList() {
		return activityList;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

}
