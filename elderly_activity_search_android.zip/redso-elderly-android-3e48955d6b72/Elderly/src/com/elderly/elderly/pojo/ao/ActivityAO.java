package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class ActivityAO extends BasePO {
    private String id;
    private String nid;
    private String title_tc;
    private String title_sc;
    private String date;
    private String endDate;
    private String startTime;
    private String endTime;
    private String activeArea_tc;
    private String activeArea_sc;
    private String memberFee_tc;
    private String memberFee_sc;
    private String nonmenberFee_tc;
    private String nonmenberFee_sc;
    private String fee_tc;
    private String fee_sc;
    private String eventType_tc;
    private String eventType_sc;



    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }

    public String getNid() {
        return nid;
    }

    public void setNid(String nid) {
        this.nid = nid;
    }

    public String getTitle_tc() {
        return title_tc;
    }

    public void setTitle_tc(String title_tc) {
        this.title_tc = title_tc;
    }

    public String getTitle_sc() {
        return title_sc;
    }

    public void setTitle_sc(String title_sc) {
        this.title_sc = title_sc;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getActiveArea_tc() {
        return activeArea_tc;
    }

    public void setActiveArea_tc(String activeArea_tc) {
        this.activeArea_tc = activeArea_tc;
    }

    public String getActiveArea_sc() {
        return activeArea_sc;
    }

    public void setActiveArea_sc(String activeArea_sc) {
        this.activeArea_sc = activeArea_sc;
    }

    public String getMemberFee_tc() {
        return memberFee_tc;
    }

    public void setMemberFee_tc(String memberFee_tc) {
        this.memberFee_tc = memberFee_tc;
    }

    public String getMemberFee_sc() {
        return memberFee_sc;
    }

    public void setMemberFee_sc(String memberFee_sc) {
        this.memberFee_sc = memberFee_sc;
    }

    public String getNonmenberFee_tc() {
        return nonmenberFee_tc;
    }

    public void setNonmenberFee_tc(String nonmenberFee_tc) {
        this.nonmenberFee_tc = nonmenberFee_tc;
    }

    public String getNonmenberFee_sc() {
        return nonmenberFee_sc;
    }

    public void setNonmenberFee_sc(String nonmenberFee_sc) {
        this.nonmenberFee_sc = nonmenberFee_sc;
    }

    public String getFee_tc() {
        return fee_tc;
    }

    public void setFee_tc(String fee_tc) {
        this.fee_tc = fee_tc;
    }

    public String getFee_sc() {
        return fee_sc;
    }

    public void setFee_sc(String fee_sc) {
        this.fee_sc = fee_sc;
    }


    public String getEventType_tc() {
        return eventType_tc;
    }

    public void setEventType_tc(String eventType_tc) {
        this.eventType_tc = eventType_tc;
    }


    public String getEventType_sc() {
        return eventType_sc;
    }

    public void setEventType_sc(String eventType_sc) {
        this.eventType_sc = eventType_sc;
    }

    public String getFee() {
        return getStringInLanguage(fee_tc, fee_sc);
    }

    public String getNonmemberFee() {
        return getStringInLanguage(nonmenberFee_tc, nonmenberFee_sc);
    }

    public String getMemberFee() {
        return getStringInLanguage(memberFee_tc, memberFee_sc);
    }

    public String getActiveArea() {
        return getStringInLanguage(activeArea_tc, activeArea_sc);
    }

    public String getEventType() {
        return getStringInLanguage(eventType_tc, eventType_sc);
    }

    public String getTitle() {
        return getStringInLanguage(title_tc, title_sc);
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
