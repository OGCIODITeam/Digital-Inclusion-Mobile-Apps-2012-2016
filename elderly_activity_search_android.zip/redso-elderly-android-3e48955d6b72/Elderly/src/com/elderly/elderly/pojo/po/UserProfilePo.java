package com.elderly.elderly.pojo.po;

import java.util.ArrayList;

import com.elderly.elderly.pojo.BasePO;

public class UserProfilePo extends BasePO{
	private String name;
	private String picture;
	private String sex;
	private String district;
	private String region;
	private ArrayList<String> interests;
	private ArrayList<String> communitys;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public ArrayList<String> getInterests() {
		return interests;
	}
	public void setInterests(ArrayList<String> interests) {
		this.interests = interests;
	}
	public ArrayList<String> getCommunitys() {
		return communitys;
	}
	public void setCommunitys(ArrayList<String> communitys) {
		this.communitys = communitys;
	}
	
	
}
