package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class CommunityCentreAO extends BasePO {
	private String vid="";
	private String nid="";
	private String latitude="";
	private String longitude="";
	private String fieldElderlyLocationValue_tc="";
	private String fieldElderlyLocationValue_sc="";
	private String fieldElderlyOrganizationValue_tc="";
	private String fieldElderlyOrganizationValue_sc="";
	private String fieldElderlyCategoriesValue_tc="";
	private String fieldElderlyCategoriesValue_sc="";
	private String fieldElderlyDistrictValue_tc="";
	private String fieldElderlyDistrictValue_sc="";
	private String fieldElderlyCentreValue_tc="";
	private String fieldElderlyCentreValue_sc="";
	private int index;//use for save local

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}

	public String getFieldElderlyLocationValue() {
		return super.getStringInLanguage(fieldElderlyLocationValue_tc, fieldElderlyLocationValue_sc);
	}

	public void setFieldElderlyLocationValue(String fieldElderlyLocationValue) {
		this.fieldElderlyLocationValue_tc = fieldElderlyLocationValue;
	}

	public void setFieldElderlyLocationValue_sc(String fieldElderlyLocationValue_sc) {
		this.fieldElderlyLocationValue_sc = fieldElderlyLocationValue_sc;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getFieldElderlyOrganizationValue() {
		return super.getStringInLanguage(fieldElderlyOrganizationValue_tc, fieldElderlyOrganizationValue_sc);
	}

	public void setFieldElderlyOrganizationValue_tc(String fieldElderlyOrganizationValue) {
		this.fieldElderlyOrganizationValue_tc = fieldElderlyOrganizationValue;
	}

	public void setFieldElderlyOrganizationValue_sc(String fieldElderlyOrganizationValue_sc) {
		this.fieldElderlyOrganizationValue_sc = fieldElderlyOrganizationValue_sc;
	}

	public String getFieldElderlyCategoriesValue() {
		return super.getStringInLanguage(fieldElderlyCategoriesValue_tc, fieldElderlyCategoriesValue_sc);
	}

	public void setFieldElderlyCategoriesValue_tc(String fieldElderlyCategoriesValue) {
		this.fieldElderlyCategoriesValue_tc = fieldElderlyCategoriesValue;
	}

	public void setFieldElderlyCategoriesValue_sc(String fieldElderlyCategoriesValue_sc) {
		this.fieldElderlyCategoriesValue_sc = fieldElderlyCategoriesValue_sc;
	}

	public String getFieldElderlyDistrictValue() {
		return super.getStringInLanguage(fieldElderlyDistrictValue_tc, fieldElderlyDistrictValue_sc);
	}

	public void setFieldElderlyDistrictValue_tc(String fieldElderlyDistrictValue) {
		this.fieldElderlyDistrictValue_tc = fieldElderlyDistrictValue;
	}

	public void setFieldElderlyDistrictValue_sc(String fieldElderlyDistrictValue_sc) {
		this.fieldElderlyDistrictValue_sc = fieldElderlyDistrictValue_sc;
	}

	public String getFieldElderlyCentreValue() {
		return  super.getStringInLanguage(fieldElderlyCentreValue_tc, fieldElderlyCentreValue_sc);
	}

	public void setFieldElderlyCentreValue_tc(String fieldElderlyCentreValue) {
		this.fieldElderlyCentreValue_tc = fieldElderlyCentreValue;
	}

	public void setFieldElderlyCentreValue_sc(String fieldElderlyCentreValue_sc) {
		this.fieldElderlyCentreValue_sc = fieldElderlyCentreValue_sc;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getFieldElderlyLocationValue_tc() {
		return fieldElderlyLocationValue_tc;
	}

	public String getFieldElderlyOrganizationValue_tc() {
		return fieldElderlyOrganizationValue_tc;
	}

	public String getFieldElderlyCategoriesValue_tc() {
		return fieldElderlyCategoriesValue_tc;
	}

	public String getFieldElderlyDistrictValue_tc() {
		return fieldElderlyDistrictValue_tc;
	}

	public String getFieldElderlyCentreValue_tc() {
		return fieldElderlyCentreValue_tc;
	}
	
	
	
	
	
	

}
