package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class BannerAO extends BasePO {
	private String id;
	private String title_tc;
	private String title_sc;
	private String description_tc;
	private String description_sc;
	private String image;
	private String link;
	private String type;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle_tc() {
		return title_tc;
	}

	public void setTitle_tc(String title_tc) {
		this.title_tc = title_tc;
	}

	public String getTitle_sc() {
		return title_sc;
	}

	public void setTitle_sc(String title_sc) {
		this.title_sc = title_sc;
	}

	public String getDescription_tc() {
		return description_tc;
	}

	public void setDescription_tc(String description_tc) {
		this.description_tc = description_tc;
	}

	public String getDescription_sc() {
		return description_sc;
	}

	public void setDescription_sc(String description_sc) {
		this.description_sc = description_sc;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return getStringInLanguage(title_tc, title_sc);
	}

	public String getDescription() {
		return getStringInLanguage(description_tc, description_sc);
	}

}
