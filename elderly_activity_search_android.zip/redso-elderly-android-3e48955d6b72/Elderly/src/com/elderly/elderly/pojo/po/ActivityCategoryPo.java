package com.elderly.elderly.pojo.po;

import com.elderly.elderly.pojo.BasePO;

public class ActivityCategoryPo extends BasePO {
	private static final long serialVersionUID = 1L;
	private String key;
	private String nameTc;
	private String nameSc;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getNameTc() {
		return nameTc;
	}

	public void setNameTc(String nameTc) {
		this.nameTc = nameTc;
	}

	public String getNameSc() {
		return nameSc;
	}

	public void setNameSc(String nameSc) {
		this.nameSc = nameSc;
	}
	
	public String getName(){
		return super.getStringInLanguage(nameTc, nameSc);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj != null && obj instanceof String) {
			String tmp = (String) obj;
			if (tmp.equals(key)) {
				return true;
			}
		}
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ActivityCategoryPo other = (ActivityCategoryPo) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return key;
	}
	
	

}
