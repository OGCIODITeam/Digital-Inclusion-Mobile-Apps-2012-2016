package com.elderly.elderly.pojo.ao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.elderly.elderly.pojo.BasePO;

public class WeatherAO extends BasePO {

	private String date;
	private String code;
	private String name;
	private String name_sc;
	private String type;
	private String temperature;
	private String maxTemperature;
	private String minTemperature;
	private String warning;
	private String uvRadiation;
	private String humidity;
	private List<ForecastWeather> weatherList = new ArrayList<WeatherAO.ForecastWeather>();

	public static class ForecastWeather extends BasePO {
		private String date;
		private String code;
		private String name;
		private String name_sc;
		private String type;
		private String maxTemperature;
		private String minTemperature;

		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getName() {
			return getStringInLanguage(name, name_sc);
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getName_sc() {
			return name_sc;
		}

		public void setName_sc(String name_sc) {
			this.name_sc = name_sc;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getMaxTemperature() {
			return maxTemperature;
		}

		public void setMaxTemperature(String maxTemperature) {
			this.maxTemperature = maxTemperature;
		}

		public String getMinTemperature() {
			return minTemperature;
		}

		public void setMinTemperature(String minTemperature) {
			this.minTemperature = minTemperature;
		}

	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return super.getStringInLanguage(name, name_sc);
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName_sc() {
		return name_sc;
	}

	public void setName_sc(String name_sc) {
		this.name_sc = name_sc;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getMaxTemperature() {
		return maxTemperature;
	}

	public void setMaxTemperature(String maxTemperature) {
		this.maxTemperature = maxTemperature;
	}

	public String getMinTemperature() {
		return minTemperature;
	}

	public void setMinTemperature(String minTemperature) {
		this.minTemperature = minTemperature;
	}

	public String getWarning() {
//		 warning="1,2,4,5,21,9,6,11,16";
		// warning="1,2,4,5";
		return warning;
	}

	public void setWarning(String warning) {
		this.warning = warning;
	}

	public String getUvRadiation() {
		return uvRadiation;
	}

	public void setUvRadiation(String uvRadiation) {
		this.uvRadiation = uvRadiation;
	}

	public String getHumidity() {
		return humidity;
	}

	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}

	public List<ForecastWeather> getWeatherList() {
		return weatherList;
	}

	public void setWeatherList(List<ForecastWeather> weatherList) {
		this.weatherList = weatherList;
	}

}
