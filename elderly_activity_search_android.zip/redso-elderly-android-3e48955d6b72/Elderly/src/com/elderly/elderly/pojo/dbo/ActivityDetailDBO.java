package com.elderly.elderly.pojo.dbo;

import android.database.Cursor;

import com.elderly.elderly.pojo.BasePO;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;

public class ActivityDetailDBO extends ActivityDetailAO {

	public void initWithCursor(Cursor cursor) {
		this.id = getStringByColumnName(cursor, "id");
		this.nid = getStringByColumnName(cursor, "nid");
		this.activityType = getStringByColumnName(cursor, "activity_type");
		this.date = getStringByColumnName(cursor, "activity_date");
		this.endDate = getStringByColumnName(cursor, "activity_endDate");
		this.title_sc = getStringByColumnName(cursor, "title_sc");
		this.title_tc = getStringByColumnName(cursor, "title_tc");
		this.activeArea_sc = getStringByColumnName(cursor, "activeArea_sc");
		this.activeArea_tc = getStringByColumnName(cursor, "activeArea_tc");
		this.activityCenterName_sc = getStringByColumnName(cursor, "activityCenterName_sc");
		this.activityCenterName_tc = getStringByColumnName(cursor, "activityCenterName_tc");
		this.activityDetail_sc = getStringByColumnName(cursor, "activityDetail_sc");
		this.activityDetail_tc = getStringByColumnName(cursor, "activityDetail_tc");
		this.activityTarget_sc = getStringByColumnName(cursor, "activityTarget_sc");
		this.activityTarget_tc = getStringByColumnName(cursor, "activityTarget_tc");
		this.ageLowerLimint_sc = getStringByColumnName(cursor, "ageLowerLimint_sc");
		this.ageLowerLimint_tc = getStringByColumnName(cursor, "ageLowerLimint_tc");
		this.applicationMethod_sc = getStringByColumnName(cursor, "applicationMethod_sc");
		this.applicationMethod_tc = getStringByColumnName(cursor, "applicationMethod_tc");
		this.categoriesValue_sc = getStringByColumnName(cursor, "categoriesValue_sc");
		this.categoriesValue_tc = getStringByColumnName(cursor, "categoriesValue_tc");
		this.centerId = getStringByColumnName(cursor, "centerId");
		this.centerNid = getStringByColumnName(cursor, "centerNid");
		this.endTime = getStringByColumnName(cursor, "endTime");
		this.eventType_sc = getStringByColumnName(cursor, "eventType_sc");
		this.eventType_tc = getStringByColumnName(cursor, "eventType_tc");
		this.fee_sc = getStringByColumnName(cursor, "fee_sc");
		this.fee_tc = getStringByColumnName(cursor, "fee_tc");
		this.latitude = getStringByColumnName(cursor, "latitude");
		this.link = getStringByColumnName(cursor, "link");
		this.location_sc = getStringByColumnName(cursor, "location_sc");
		this.location_tc = getStringByColumnName(cursor, "location_tc");
		this.longitude = getStringByColumnName(cursor, "longitude");
		this.memberFee_sc = getStringByColumnName(cursor, "memberFee_sc");
		this.memberFee_tc = getStringByColumnName(cursor, "memberFee_tc");
		this.nonmenberFee_sc = getStringByColumnName(cursor, "nonmenberFee_sc");
		this.nonmenberFee_tc = getStringByColumnName(cursor, "nonmenberFee_tc");
		this.organization_sc = getStringByColumnName(cursor, "organization_sc");
		this.organization_tc = getStringByColumnName(cursor, "organization_tc");
		this.remark_sc = getStringByColumnName(cursor, "remark_sc");
		this.remark_tc = getStringByColumnName(cursor, "remark_tc");
		this.startTime = getStringByColumnName(cursor, "startTime");
	}

}
