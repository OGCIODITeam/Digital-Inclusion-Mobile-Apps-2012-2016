package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class VersionAO extends BasePO {
	private String id;
	private String link;
	private String type;
	private String versionNum;
	private String iphoneMsg;
	private String status;
	private String msg;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(String versionNum) {
		this.versionNum = versionNum;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getIphoneMsg() {
		return iphoneMsg;
	}

	public void setIphoneMsg(String iphoneMsg) {
		this.iphoneMsg = iphoneMsg;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
