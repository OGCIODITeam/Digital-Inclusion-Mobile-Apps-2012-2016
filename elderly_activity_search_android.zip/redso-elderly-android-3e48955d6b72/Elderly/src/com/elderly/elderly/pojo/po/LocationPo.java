package com.elderly.elderly.pojo.po;

import android.util.Log;

import com.elderly.elderly.pojo.BasePO;

public class LocationPo extends BasePO {
	private String key;
	private String nameTc;
	private String nameSc;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getNameTc() {
		return nameTc;
	}

	public void setNameTc(String nameTc) {
		this.nameTc = nameTc;
	}

	public String getNameSc() {
		return nameSc;
	}

	public void setNameSc(String nameSc) {
		this.nameSc = nameSc;
	}

	@Override
	public boolean equals(Object o) {
		Log.v("BasePO", "o>>" + o + " key>>" + getKey());
		if (o != null && o instanceof String) {
			String tmp = (String) o;
			if (tmp.equals(getKey())) {
				return true;
			}
		}else if(o!=null && o instanceof LocationPo){
			LocationPo tmp=(LocationPo) o;
			if(tmp.getKey().equals(getKey())){
				return true;
			}
		}
		return super.equals(o);
	}

	public boolean equals(String key) {
		return key != null && key.equals(getKey()) ? true : false;
	}

	public String getName() {
		return super.getStringInLanguage(nameTc, nameSc);
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
