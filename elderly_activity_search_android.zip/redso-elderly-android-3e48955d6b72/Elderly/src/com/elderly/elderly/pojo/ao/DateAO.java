package com.elderly.elderly.pojo.ao;

import java.util.Date;

import com.elderly.elderly.Constants;
import com.elderly.elderly.pojo.BasePO;
import com.gt.cl.util.CLDateUtil;

public class DateAO extends BasePO {
	private String dateStr;
	private Date date;

	public String getDateStr() {
		return dateStr;
	}

	public void setDateStr(String date) {
		this.dateStr = date;
		if(dateStr!=null){
			this.date=CLDateUtil.formatDate(dateStr, Constants.DATE_FORMAT_PATTERN_API);
		}
	}

	public Date getDate() {
		return date;
	}
	
	
	
	
}
