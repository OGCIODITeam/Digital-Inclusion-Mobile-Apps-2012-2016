package com.elderly.elderly.pojo.ao;

import com.elderly.elderly.pojo.BasePO;

public class ActivityDetailAO extends BasePO {
	protected String id;
	protected String nid;
	protected String title_tc;
	protected String title_sc;
	protected String date;
	protected String startTime;
	protected String endTime;
	protected String activeArea_tc;
	protected String activeArea_sc;
	protected String memberFee_tc;
	protected String memberFee_sc;
	protected String nonmenberFee_tc;
	protected String nonmenberFee_sc;
	protected String fee_tc;
	protected String fee_sc;
	protected String eventType_tc;
	protected String eventType_sc;
	protected String centerId;
	protected String centerNid;
	protected String activityCenterName_tc;
	protected String activityCenterName_sc;
	protected String activityDetail_tc;
	protected String activityDetail_sc;
	protected String organization_tc;
	protected String organization_sc;
	protected String categoriesValue_tc;
	protected String categoriesValue_sc;
	protected String applicationMethod_tc;
	protected String applicationMethod_sc;
	protected String activityTarget_tc;
	protected String activityTarget_sc;
	protected String ageLowerLimint_tc;
	protected String ageLowerLimint_sc;
	protected String remark_tc;
	protected String remark_sc;
	protected String longitude;
	protected String latitude;
	protected String link;
	protected String location_tc;
	protected String location_sc;
	protected String activityType;// E 长者活动中心 L 康文处
	protected String endDate;

	@Override
	public String toString() {
		return "ActivityDetailAO [id=" + id + ", nid=" + nid + ", title_tc=" + title_tc + ", title_sc=" + title_sc + ", date=" + date + ", startTime=" + startTime + ", endTime=" + endTime + ", activeArea_tc=" + activeArea_tc + ", activeArea_sc=" + activeArea_sc + ", memberFee_tc=" + memberFee_tc + ", memberFee_sc=" + memberFee_sc + ", nonmenberFee_tc=" + nonmenberFee_tc + ", nonmenberFee_sc=" + nonmenberFee_sc + ", fee_tc=" + fee_tc + ", fee_sc=" + fee_sc + ", eventType_tc=" + eventType_tc + ", eventType_sc=" + eventType_sc + ", centerId=" + centerId + ", centerNid=" + centerNid + ", activityCenterName_tc=" + activityCenterName_tc + ", activityCenterName_sc=" + activityCenterName_sc + ", activityDetail_tc=" + activityDetail_tc + ", activityDetail_sc=" + activityDetail_sc + ", organization_tc=" + organization_tc + ", organization_sc=" + organization_sc + ", categoriesValue_tc=" + categoriesValue_tc + ", categoriesValue_sc=" + categoriesValue_sc + ", applicationMethod_tc=" + applicationMethod_tc + ", applicationMethod_sc=" + applicationMethod_sc + ", activityTarget_tc=" + activityTarget_tc + ", activityTarget_sc=" + activityTarget_sc + ", ageLowerLimint_tc=" + ageLowerLimint_tc + ", ageLowerLimint_sc=" + ageLowerLimint_sc + ", remark_tc=" + remark_tc + ", remark_sc=" + remark_sc + ", longitude=" + longitude + ", latitude=" + latitude + ", link=" + link + ", location_tc=" + location_tc + ", location_sc=" + location_sc + ", activityType=" + activityType + ", endDate=" + endDate + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}

	public String getTitle_tc() {
		return title_tc;
	}

	public void setTitle_tc(String title_tc) {
		this.title_tc = title_tc;
	}

	public String getTitle_sc() {
		return title_sc;
	}

	public void setTitle_sc(String title_sc) {
		this.title_sc = title_sc;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getActiveArea_tc() {
		return activeArea_tc;
	}

	public void setActiveArea_tc(String activeArea_tc) {
		this.activeArea_tc = activeArea_tc;
	}

	public String getActiveArea_sc() {
		return activeArea_sc;
	}

	public void setActiveArea_sc(String activeArea_sc) {
		this.activeArea_sc = activeArea_sc;
	}

	public String getMemberFee_tc() {
		return memberFee_tc;
	}

	public void setMemberFee_tc(String memberFee_tc) {
		this.memberFee_tc = memberFee_tc;
	}

	public String getMemberFee_sc() {
		return memberFee_sc;
	}

	public void setMemberFee_sc(String memberFee_sc) {
		this.memberFee_sc = memberFee_sc;
	}

	public String getNonmenberFee_tc() {
		return nonmenberFee_tc;
	}

	public void setNonmenberFee_tc(String nonmenberFee_tc) {
		this.nonmenberFee_tc = nonmenberFee_tc;
	}

	public String getNonmenberFee_sc() {
		return nonmenberFee_sc;
	}

	public void setNonmenberFee_sc(String nonmenberFee_sc) {
		this.nonmenberFee_sc = nonmenberFee_sc;
	}

	public String getFee_tc() {
		return fee_tc;
	}

	public void setFee_tc(String fee_tc) {
		this.fee_tc = fee_tc;
	}

	public String getFee_sc() {
		return fee_sc;
	}

	public void setFee_sc(String fee_sc) {
		this.fee_sc = fee_sc;
	}

	public String getEventType_tc() {
		return eventType_tc;
	}

	public void setEventType_tc(String eventType_tc) {
		this.eventType_tc = eventType_tc;
	}

	public String getEventType_sc() {
		return eventType_sc;
	}

	public void setEventType_sc(String eventType_sc) {
		this.eventType_sc = eventType_sc;
	}

	public String getCenterId() {
		return centerId;
	}

	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	public String getCenterNid() {
		return centerNid;
	}

	public void setCenterNid(String centerNid) {
		this.centerNid = centerNid;
	}

	public String getActivityCenterName_tc() {
		return activityCenterName_tc;
	}

	public void setActivityCenterName_tc(String activityCenterName_tc) {
		this.activityCenterName_tc = activityCenterName_tc;
	}

	public String getActivityCenterName_sc() {
		return activityCenterName_sc;
	}

	public void setActivityCenterName_sc(String activityCenterName_sc) {
		this.activityCenterName_sc = activityCenterName_sc;
	}

	public String getActivityDetail_tc() {
		return activityDetail_tc;
	}

	public void setActivityDetail_tc(String activityDetail_tc) {
		this.activityDetail_tc = activityDetail_tc;
	}

	public String getActivityDetail_sc() {
		return activityDetail_sc;
	}

	public void setActivityDetail_sc(String activityDetail_sc) {
		this.activityDetail_sc = activityDetail_sc;
	}

	public String getOrganization_tc() {
		return organization_tc;
	}

	public void setOrganization_tc(String organization_tc) {
		this.organization_tc = organization_tc;
	}

	public String getOrganization_sc() {
		return organization_sc;
	}

	public void setOrganization_sc(String organization_sc) {
		this.organization_sc = organization_sc;
	}

	public String getCategoriesValue_tc() {
		return categoriesValue_tc;
	}

	public void setCategoriesValue_tc(String categoriesValue_tc) {
		this.categoriesValue_tc = categoriesValue_tc;
	}

	public String getCategoriesValue_sc() {
		return categoriesValue_sc;
	}

	public void setCategoriesValue_sc(String categoriesValue_sc) {
		this.categoriesValue_sc = categoriesValue_sc;
	}

	public String getApplicationMethod_tc() {
		return applicationMethod_tc;
	}

	public void setApplicationMethod_tc(String applicationMethod_tc) {
		this.applicationMethod_tc = applicationMethod_tc;
	}

	public String getApplicationMethod_sc() {
		return applicationMethod_sc;
	}

	public void setApplicationMethod_sc(String applicationMethod_sc) {
		this.applicationMethod_sc = applicationMethod_sc;
	}

	public String getActivityTarget_tc() {
		return activityTarget_tc;
	}

	public void setActivityTarget_tc(String activityTarget_tc) {
		this.activityTarget_tc = activityTarget_tc;
	}

	public String getActivityTarget_sc() {
		return activityTarget_sc;
	}

	public void setActivityTarget_sc(String activityTarget_sc) {
		this.activityTarget_sc = activityTarget_sc;
	}

	public String getAgeLowerLimint_tc() {
		return ageLowerLimint_tc;
	}

	public void setAgeLowerLimint_tc(String ageLowerLimint_tc) {
		this.ageLowerLimint_tc = ageLowerLimint_tc;
	}

	public String getAgeLowerLimint_sc() {
		return ageLowerLimint_sc;
	}

	public void setAgeLowerLimint_sc(String ageLowerLimint_sc) {
		this.ageLowerLimint_sc = ageLowerLimint_sc;
	}

	public String getRemark_tc() {
		return remark_tc;
	}

	public void setRemark_tc(String remark_tc) {
		this.remark_tc = remark_tc;
	}

	public String getRemark_sc() {
		return remark_sc;
	}

	public void setRemark_sc(String remark_sc) {
		this.remark_sc = remark_sc;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getLocation_tc() {
		return location_tc;
	}

	public void setLocation_tc(String location_tc) {
		this.location_tc = location_tc;
	}

	public String getLocation_sc() {
		return location_sc;
	}

	public void setLocation_sc(String location_sc) {
		this.location_sc = location_sc;
	}

	public String getFee() {
		return getStringInLanguage(fee_tc, fee_sc);
	}

	public String getNonmemberFee() {
		return getStringInLanguage(nonmenberFee_tc, nonmenberFee_sc);
	}

	public String getMemberFee() {
		return getStringInLanguage(memberFee_tc, memberFee_sc);
	}

	public String getActiveArea() {
		return getStringInLanguage(activeArea_tc, activeArea_sc);
	}

	public String getEventType() {
		return getStringInLanguage(eventType_tc, eventType_sc);
	}

	public String getTitle() {
		return getStringInLanguage(title_tc, title_sc);
	}

	public String getActivityCenterName() {
		return getStringInLanguage(activityCenterName_tc, activityCenterName_sc);
	}

	public String getActivityDetail() {
		return getStringInLanguage(activityDetail_tc, activityDetail_sc);
	}

	public String getOrganization() {
		return getStringInLanguage(organization_tc, organization_sc);
	}

	public String getCategoriesValue() {
		return getStringInLanguage(categoriesValue_tc, categoriesValue_sc);
	}

	public String getApplicationMethod() {
		return getStringInLanguage(applicationMethod_tc, applicationMethod_sc);
	}

	public String getActivityTarget() {
		return getStringInLanguage(activityTarget_tc, activityTarget_sc);
	}

	public String getAgeLowerLimit() {
		return getStringInLanguage(ageLowerLimint_tc, ageLowerLimint_sc);
	}

	public String getRemark() {
		return getStringInLanguage(remark_tc, remark_sc);
	}

	public String getLocation() {
		return getStringInLanguage(location_tc, location_sc);
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	// public void initWithCursor(Cursor cursor) {
	// this.id = getStringByColumnName(cursor, "id");
	// this.nid = getStringByColumnName(cursor, "nid");
	// this.activityType = getStringByColumnName(cursor, "activity_type");
	// this.date = getStringByColumnName(cursor, "activity_date");
	// this.title_sc = getStringByColumnName(cursor, "title_sc");
	// this.title_tc = getStringByColumnName(cursor, "title_tc");
	// this.activeArea_sc = getStringByColumnName(cursor, "activeArea_sc");
	// this.activeArea_tc = getStringByColumnName(cursor, "activeArea_tc");
	// this.activityCenterName_sc = getStringByColumnName(cursor,
	// "activityCenterName_sc");
	// this.activityCenterName_tc = getStringByColumnName(cursor,
	// "activityCenterName_tc");
	// this.activityDetail_sc =
	// getStringByColumnName(cursor,"activityDetail_sc");
	// this.activityDetail_tc =
	// getStringByColumnName(cursor,"activityDetail_tc");
	// this.activityTarget_sc = getStringByColumnName(cursor,
	// "activityTarget_sc");
	// this.activityTarget_tc = getStringByColumnName(cursor,
	// "activityTarget_tc");
	// this.ageLowerLimint_sc = getStringByColumnName(cursor,
	// "ageLowerLimint_sc");
	// this.ageLowerLimint_tc = getStringByColumnName(cursor,
	// "ageLowerLimint_tc");
	// this.applicationMethod_sc = getStringByColumnName(cursor,
	// "applicationMethod_sc");
	// this.applicationMethod_tc = getStringByColumnName(cursor,
	// "applicationMethod_tc");
	// this.categoriesValue_sc = getStringByColumnName(cursor,
	// "categoriesValue_sc");
	// this.categoriesValue_tc = getStringByColumnName(cursor,
	// "categoriesValue_tc");
	// this.centerId = getStringByColumnName(cursor, "centerId");
	// this.centerNid = getStringByColumnName(cursor, "centerNid");
	// this.endTime = getStringByColumnName(cursor, "endTime");
	// this.eventType_sc = getStringByColumnName(cursor, "eventType_sc");
	// this.eventType_tc = getStringByColumnName(cursor, "eventType_tc");
	// this.fee_sc = getStringByColumnName(cursor, "fee_sc");
	// this.fee_tc = getStringByColumnName(cursor, "fee_tc");
	// this.latitude = getStringByColumnName(cursor, "latitude");
	// this.link = getStringByColumnName(cursor, "link");
	// this.location_sc = getStringByColumnName(cursor, "location_sc");
	// this.location_tc = getStringByColumnName(cursor, "location_tc");
	// this.longitude = getStringByColumnName(cursor, "longitude");
	// this.memberFee_sc = getStringByColumnName(cursor, "memberFee_sc");
	// this.memberFee_tc = getStringByColumnName(cursor, "memberFee_tc");
	// this.nonmenberFee_sc = getStringByColumnName(cursor, "nonmenberFee_sc");
	// this.nonmenberFee_tc = getStringByColumnName(cursor, "nonmenberFee_tc");
	// this.organization_sc = getStringByColumnName(cursor, "organization_sc");
	// this.organization_tc = getStringByColumnName(cursor, "organization_tc");
	// this.remark_sc = getStringByColumnName(cursor, "remark_sc");
	// this.remark_tc = getStringByColumnName(cursor, "remark_tc");
	// this.startTime = getStringByColumnName(cursor, "startTime");
	// }

}
