package com.elderly.elderly.manager;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources.NotFoundException;
import android.util.Log;
import android.util.Xml;

import com.elderly.elderly.R;
import com.elderly.elderly.parser.ActivityCategoryParser;
import com.elderly.elderly.parser.CommunityCentreAOParser;
import com.elderly.elderly.parser.DistrictPoParser;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;
import com.elderly.elderly.pojo.po.DistrictPo;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.pojo.po.UserProfilePo;
import com.gt.cl.util.CLFileUtil;

import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 管理UserFile信息
 * 
 * @author jianfeng.lao
 * @version 1.0
 * @CreateDate 2013-8-15
 */
public class UserProfileManager {
	public static final String TAG = "UserProfileManager";
	private static final String USER_PROFILE_SP = "user_profile.sp";
	private static final String SP_KEYS_USER_NAME = "user_name";
	private static final String SP_KEYS_USER_PICTURE = "user_picture";
	private static final String SP_KEYS_USER_SEX = "user_sex";
	private static final String SP_KEYS_USER_DISTRICT = "user_area";
	private static final String SP_KEYS_USER_REGION = "user_region";
	private static final String SP_KEYS_USER_INTEREST = "user_interest";

	private static final String SP_KEYS_HELP_USER_NAME = "sp_keys_help_user_name";
	private static final String SP_KEYS_HELP_USER_SEX = "sp_keys_help_user_sex";
	private static final String SP_KEYS_HELP_USER_DISTRICT = "sp_keys_help_user_area";
	private static final String SP_KEYS_HELP_USER_REGION = "sp_keys_help_user_region";
	private static final String SP_KEYS_HELP_USER_INTEREST = "sp_keys_help_user_interest";
	private static final String SP_KEYS_HELP_USER_INTEREST_DETAIL = "sp_keys_help_user_interest_detail";
	private static final String SP_KEYS_HELP_USER_COMMUNITY = "sp_keys_help_user_community";
	private static final String SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART1 = "sp_keys_help_user_community_detail_part1";
	private static final String SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART2 = "sp_keys_help_user_community_detail_part2";
	private static final String SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART3 = "sp_keys_help_user_community_detail_part3";
	private static final String SP_KEYS_HELP_USER_DELETE_PHOTO = "sp_keys_help_user_delete_photo";

	private static final String SP_KEYS_HELP_NEW_ACTIVITY = "sp_keys_help_new_activity";
	private static final String SP_KEYS_HELP_SELECT_INTEREST = "sp_keys_help_select_interest";

	private static UserProfileManager mInstance;
	private SharedPreferences mUserInfoSp;
	private SharedPreferences mMyInterestSp;
	private Context mContext;

	private List<DistrictPo> mDistrictData;
	private List<ActivityCategoryPo> mActivityCategoryData;

	private UserProfileManager(Context context) {
		this.mContext = context;
		mUserInfoSp = mContext.getSharedPreferences(USER_PROFILE_SP, 0);
		DistrictPoParser districtPoParser = new DistrictPoParser();
		ActivityCategoryParser activityCategoryParser = new ActivityCategoryParser();
		try {
			districtPoParser.parser(mContext.getResources().openRawResource(R.raw.location));
			activityCategoryParser.parser(mContext.getResources().openRawResource(R.raw.activity_category));
		} catch (NotFoundException e) {
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}
		mDistrictData = districtPoParser.getData();
		mActivityCategoryData = activityCategoryParser.getData();
		// Log.v(TAG, "mDistrictData>>" + mDistrictData.toString());
		// setMyInterestList(mActivityCategoryData);
		// Log.v(TAG, "mActivityCategoryData>>" + Arrays.toString(getMyInterestList().toArray()));
	}

	public static void init(Context context) {
		if (mInstance == null) {
			mInstance = new UserProfileManager(context);
		}
	}

	public static UserProfileManager getInstance() {
		return mInstance;
	}

	public UserProfilePo getUserProfile() {
		UserProfilePo po = new UserProfilePo();
		po.setName(mUserInfoSp.getString(SP_KEYS_USER_NAME, null));
		po.setPicture(mUserInfoSp.getString(SP_KEYS_USER_PICTURE, null));
		po.setSex(mUserInfoSp.getString(SP_KEYS_USER_SEX, null));
		po.setDistrict(mUserInfoSp.getString(SP_KEYS_USER_DISTRICT, null));
		po.setRegion(mUserInfoSp.getString(SP_KEYS_USER_REGION, null));
		return po;
	}

	public void updateUserName(String name) {
		mUserInfoSp.edit().putString(SP_KEYS_USER_NAME, name).commit();
	}

	public void updateUserPicture(String pic) {
		mUserInfoSp.edit().putString(SP_KEYS_USER_PICTURE, pic).commit();
	}
	
	public boolean isSetPhoto(){
		if(mUserInfoSp.getString(SP_KEYS_USER_PICTURE, null)==null){
			return false;
		}else{
			return true;
		}
	}

	public void updateUserSex(String sex) {
		mUserInfoSp.edit().putString(SP_KEYS_USER_SEX, sex).commit();
	}

	public void updateUserDistrict(String district) {
		mUserInfoSp.edit().putString(SP_KEYS_USER_DISTRICT, district).commit();
	}

	public void updateUserRegion(String location) {
		mUserInfoSp.edit().putString(SP_KEYS_USER_REGION, location).commit();
	}

	public boolean isNeedShowUserNameTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_NAME, true);
	}

	public boolean isNeedShowUserSexTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_SEX, true);
	}

	public boolean isNeedShowUserDistrictTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_DISTRICT, true);
	}

	public boolean isNeedShowUserRegionTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_REGION, true);
	}

	public boolean isNeedShowUserInterestTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_INTEREST, true);
	}

	public boolean isNeedShowUserInterestDetailTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_INTEREST_DETAIL, true);
	}

	public boolean isNeedShowUserCommunityTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_COMMUNITY, true);
	}

	public boolean isNeedShowUserCommunityDetailPart1Tip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART1, true);
	}

	public boolean isNeedShowUserCommunityDetailPart2Tip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART2, true);
	}

	public boolean isNeedShowUserCommunityDetailPart3Tip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART3, true);
	}

	public boolean isNeedShowUserDeletePhoto(){
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_USER_DELETE_PHOTO, true);
	}
	
	public boolean isNeedShowSelectInterestTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_SELECT_INTEREST, true);
	}

	public boolean isNeedShowNewActivityTip() {
		return mUserInfoSp.getBoolean(SP_KEYS_HELP_NEW_ACTIVITY, true);
	}

	public void alReadlyShowNewActivityTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_NEW_ACTIVITY, false).commit();
	}

	public void alReadlyShowUserNameTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_NAME, false).commit();
	}

	public void alReadlyShowUserSexTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_SEX, false).commit();
	}

	public void alReadlyShowUserDirstrictTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_DISTRICT, false).commit();
	}

	public void alReadlyShowUserRegionTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_REGION, false).commit();
	}

	public void alReadlyShowUserInterestTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_INTEREST, false).commit();
	}

	public void alReadlyShowUserInteresDetailtTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_INTEREST_DETAIL, false).commit();
	}

	public void alReadlyShowUserCommunityTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_COMMUNITY, false).commit();
	}

	public void alReadlyShowUserCommunityDetailPart1Tip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART1, false).commit();
	}

	public void alReadlyShowUserCommunityDetailPart2Tip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART2, false).commit();
	}

	public void alReadlyShowUserCommunityDetailPart3Tip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_COMMUNITY_DETAIL_PART3, false).commit();
	}

	public void alReadlyShowUserDeletePhoto(){
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_USER_DELETE_PHOTO, false).commit();
	}
	
	public void alReadlyShowSelectInterestTip() {
		mUserInfoSp.edit().putBoolean(SP_KEYS_HELP_SELECT_INTEREST, false).commit();
	}

	public DistrictPo getDistrictPoByKey(String key) {
		for (int i = 0; i < mDistrictData.size(); i++) {
			DistrictPo po = mDistrictData.get(i);
			if (po.equals(key)) {
				// Log.v(TAG, "find po>>" + po.getName());
				return po;
			}
		}
		return null;
	}

	public LocationPo getRegionByKey(String districtKey, String regionKey) {
		List<LocationPo> list = getRegionList(districtKey);
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				LocationPo po = list.get(i);
				if (po.equals(regionKey)) {
					return po;
				}
			}
			return null;
		} else {
			return null;
		}
	}

	public List<LocationPo> getRegionList(String districtKey) {
		DistrictPo po = getDistrictPoByKey(districtKey);
		if (po != null) {
			return po.getRegions();
		} else {
			return null;
		}
	}

	public List<DistrictPo> getDistrictPoList() {
		return mDistrictData;
	}

	public void setMyInterestList(List<ActivityCategoryPo> list) {
		if (list == null || list.size() == 0) {
			mUserInfoSp.edit().putString(SP_KEYS_USER_INTEREST, null).commit();
		} else {
			StringBuilder sb = new StringBuilder(list.size());
			sb.append(list.get(0).toString());
			int i = 1;
			int size = list.size();
			for (; i < size; i++) {
				sb.append(",");
				sb.append(list.get(i).toString());
			}
			String array = sb.toString();
			mUserInfoSp.edit().putString(SP_KEYS_USER_INTEREST, array).commit();
			// Log.v(TAG,"array>>"+array+",tmp>>"+Arrays.toString(tmp));

		}
	}

	public List<ActivityCategoryPo> getMyInterestList() {
		List<ActivityCategoryPo> result = new ArrayList<ActivityCategoryPo>();
		String history = mUserInfoSp.getString(SP_KEYS_USER_INTEREST, null);
		if (history != null && !history.equals("")) {
			String tmp[] = history.split(",");
			int size = mActivityCategoryData.size();
			int i = 0;
			for (; i < size; i++) {
				ActivityCategoryPo po = mActivityCategoryData.get(i);
				int y = 0;
				int length = tmp.length;
				for (; y < length; y++) {
					String key = tmp[y];
					if (po.equals(key)) {
						result.add(po);
						break;
					}
				}
			}
		}
		return result;
	}

	public List<ActivityCategoryPo> getAllInterestList() {
		return mActivityCategoryData;
	}

	public List<CommunityCentreAO> readMyCommunityCentre() {
		CommunityCentreAOParser parser = new CommunityCentreAOParser();
		List<CommunityCentreAO> result = null;
		String filePath = CLFileUtil.createCacheFile("user/my_community.xml", mContext);
		try {
			parser.parser(filePath);
			result = parser.getData();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}
		return result;
	}

	public void saveMyCommunityCentre(CommunityCentreAO tmp) {
		if (tmp == null) {
			return;
		}
		List<CommunityCentreAO> originalData = readMyCommunityCentre();
		if (originalData == null) {
			originalData = new ArrayList<CommunityCentreAO>();
		}
//		Log.v(TAG, "originalData>>" + originalData.size() + ",index>>" + tmp.getIndex());
		for (int i = 0; i < originalData.size(); i++) {
//			Log.v(TAG, "loop>>" + originalData.get(i).getIndex());
			if (originalData.get(i).getIndex() == tmp.getIndex()) {
				originalData.remove(i);
			}
		}
		originalData.add(tmp);
		Log.v(TAG, "after originalData>>" + originalData.size());
		String filePath = CLFileUtil.createCacheFile("user/my_community.xml", mContext);
		FileOutputStream os;
		try {
			os = new FileOutputStream(filePath);
			XmlSerializer serializer = Xml.newSerializer();
			serializer.setOutput(os, "UTF-8");
			serializer.startDocument("UTF-8", true);
			serializer.startTag(null, "contentTypeServiceUnitList");
			for (int i = 0; i < originalData.size(); i++) {
				CommunityCentreAO ao=originalData.get(i);
				serializer.startTag(null, CommunityCentreAOParser.NODE_CONTENTTYPESERVICEUNIT);
				serializer.startTag(null, CommunityCentreAOParser.NODE_INDEX);
				serializer.text(String.valueOf(ao.getIndex()));
				serializer.endTag(null, CommunityCentreAOParser.NODE_INDEX);

				serializer.startTag(null, CommunityCentreAOParser.NODE_NID);
				serializer.text(ao.getNid());
				serializer.endTag(null, CommunityCentreAOParser.NODE_NID);

				serializer.startTag(null, CommunityCentreAOParser.NODE_VID);
				serializer.text(ao.getVid());
				serializer.endTag(null, CommunityCentreAOParser.NODE_VID);

				serializer.startTag(null, CommunityCentreAOParser.NODE_LATITUDE);
				serializer.text(ao.getLatitude());
				serializer.endTag(null, CommunityCentreAOParser.NODE_LATITUDE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_LONGITUDE);
				serializer.text(ao.getLongitude());
				serializer.endTag(null, CommunityCentreAOParser.NODE_LONGITUDE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCATEGORIESVALUE);
				serializer.text(ao.getFieldElderlyCategoriesValue());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCATEGORIESVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCENTREVALUE);
				serializer.text(ao.getFieldElderlyCentreValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCENTREVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYDISTRICTVALUE);
				serializer.text(ao.getFieldElderlyDistrictValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYDISTRICTVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYLOCATIONVALUE);
				serializer.text(ao.getFieldElderlyLocationValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYLOCATIONVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYORGANIZATIONVALUE);
				serializer.text(ao.getFieldElderlyOrganizationValue_tc() == null ? "" : ao
						.getFieldElderlyOrganizationValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYORGANIZATIONVALUE);

				serializer.endTag(null, CommunityCentreAOParser.NODE_CONTENTTYPESERVICEUNIT);
			}
			serializer.endTag(null, "contentTypeServiceUnitList");
			serializer.endDocument();
			os.flush();
			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void removeOneCommunity(CommunityCentreAO tmp){
		if (tmp == null) {
			return;
		}
		List<CommunityCentreAO> originalData = readMyCommunityCentre();
		if (originalData == null) {
			originalData = new ArrayList<CommunityCentreAO>();
		}
		for (int i = 0; i < originalData.size(); i++) {
			if (originalData.get(i).getIndex() == tmp.getIndex()) {
				originalData.remove(i);
			}
		}
		
		String filePath = CLFileUtil.createCacheFile("user/my_community.xml", mContext);
		FileOutputStream os;
		try {
			os = new FileOutputStream(filePath);
			XmlSerializer serializer = Xml.newSerializer();
			serializer.setOutput(os, "UTF-8");
			serializer.startDocument("UTF-8", true);
			serializer.startTag(null, "contentTypeServiceUnitList");
			for (int i = 0; i < originalData.size(); i++) {
				CommunityCentreAO ao=originalData.get(i);
				serializer.startTag(null, CommunityCentreAOParser.NODE_CONTENTTYPESERVICEUNIT);
				serializer.startTag(null, CommunityCentreAOParser.NODE_INDEX);
				serializer.text(String.valueOf(ao.getIndex()));
				serializer.endTag(null, CommunityCentreAOParser.NODE_INDEX);

				serializer.startTag(null, CommunityCentreAOParser.NODE_NID);
				serializer.text(ao.getNid());
				serializer.endTag(null, CommunityCentreAOParser.NODE_NID);

				serializer.startTag(null, CommunityCentreAOParser.NODE_VID);
				serializer.text(ao.getVid());
				serializer.endTag(null, CommunityCentreAOParser.NODE_VID);

				serializer.startTag(null, CommunityCentreAOParser.NODE_LATITUDE);
				serializer.text(ao.getLatitude());
				serializer.endTag(null, CommunityCentreAOParser.NODE_LATITUDE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_LONGITUDE);
				serializer.text(ao.getLongitude());
				serializer.endTag(null, CommunityCentreAOParser.NODE_LONGITUDE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCATEGORIESVALUE);
				serializer.text(ao.getFieldElderlyCategoriesValue());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCATEGORIESVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCENTREVALUE);
				serializer.text(ao.getFieldElderlyCentreValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYCENTREVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYDISTRICTVALUE);
				serializer.text(ao.getFieldElderlyDistrictValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYDISTRICTVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYLOCATIONVALUE);
				serializer.text(ao.getFieldElderlyLocationValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYLOCATIONVALUE);

				serializer.startTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYORGANIZATIONVALUE);
				serializer.text(ao.getFieldElderlyOrganizationValue_tc() == null ? "" : ao
						.getFieldElderlyOrganizationValue_tc());
				serializer.endTag(null, CommunityCentreAOParser.NODE_FIELDELDERLYORGANIZATIONVALUE);

				serializer.endTag(null, CommunityCentreAOParser.NODE_CONTENTTYPESERVICEUNIT);
			}
			serializer.endTag(null, "contentTypeServiceUnitList");
			serializer.endDocument();
			os.flush();
			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
