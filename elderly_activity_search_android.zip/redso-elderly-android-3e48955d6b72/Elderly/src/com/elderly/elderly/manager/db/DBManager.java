package com.elderly.elderly.manager.db;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import android.R.integer;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.elderly.elderly.pojo.dbo.ActivityDetailDBO;
import com.elderly.elderly.pojo.dbo.ElderlyCenterDBO;
import com.elderly.elderly.util.SQLiteUtil;
import com.gt.cl.util.CLDateUtil;
import com.gt.cl.util.CLLog;

public final class DBManager {

	private static final String TAG = "DBManager";

	private static DBManager instance = null;

	private SQLiteUtil mSQLiteUtil;
	private Context mContext;

	private DBManager(Context context) {
		this.mContext = context;
		mSQLiteUtil = new SQLiteUtil(context);
		if (!mSQLiteUtil.checkDatabaseExist()) {
			mSQLiteUtil.createLocalDatabase();
		}
	}

	public static void init(Context context) {
		if (instance == null) {
			instance = new DBManager(context);
		}
	}

	public synchronized static DBManager getInstance() {
		return instance;
	}

	public static void destroy() {
		if (instance != null) {
			instance.release();
		}
		instance = null;
	}

	private void release() {
		mSQLiteUtil.destroy();
		mSQLiteUtil = null;

	}
	
	private Cursor readDataFromDB(String sql, String[] selectionArgs) {
		CLLog.d(TAG, "SQL: " + sql);
		return mSQLiteUtil.getDatabase()
				.rawQuery(sql, selectionArgs);
	}

	private Cursor readDataFromDB(String sql) {
		return readDataFromDB(sql, null);
	}

	private String getStringByColumnName(Cursor cursor, String columnName) {
		return cursor.getString(cursor.getColumnIndex(columnName));
	}

	private <T> List<T> fetchDataFromCursor(Class<T> clazz, Cursor cursor) {
		List<T> dataList = new ArrayList<T>();
		if (cursor != null) {
			try {
				Method initWithCursorMethod = clazz.getMethod("initWithCursor",
						Cursor.class);
				while (cursor.moveToNext()) {
					T obj = clazz.newInstance();
					initWithCursorMethod.invoke(obj, cursor);
					dataList.add(obj);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				cursor.close();
			}
		}
		return dataList;
	}

	public void inseartActivityDetail(ActivityDetailAO data) {
		if (data == null && data.getId() == null) {
			return;
		}
		if (!isContainActivityDetail(data)) {
			String value = getString(data.getActivityType()) + ","
					+ getString(data.getId()) + ","
					+ getString(data.getNid()) + ","
					+ getString(data.getTitle_tc()) + ","
					+ getString(data.getTitle_sc()) + ","
					+ getString(data.getStartTime()) + ","
					+ getString(data.getEndTime()) + ","
					+ getString(data.getActiveArea_tc()) + ","
					+ getString(data.getActiveArea_sc()) + ","
					+ getString(data.getMemberFee_tc()) + ","
					+ getString(data.getMemberFee_sc()) + ","
					+ getString(data.getNonmenberFee_tc()) + ","
					+ getString(data.getNonmenberFee_sc()) + ","
					+ getString(data.getFee_tc()) + ","
					+ getString(data.getFee_sc()) + ","
					+ getString(data.getEventType_tc()) + ","
					+ getString(data.getEventType_sc()) + ","
					+ getString(data.getCenterId()) + ","
					+ getString(data.getCenterNid()) + ","
					+ getString(data.getActivityCenterName_tc()) + ","
					+ getString(data.getActivityCenterName_sc()) + ","
					+ getString(data.getActivityDetail_tc()) + ","
					+ getString(data.getActivityDetail_sc()) + ","
					+ getString(data.getOrganization_tc()) + ","
					+ getString(data.getOrganization_sc()) + ","
					+ getString(data.getCategoriesValue_tc()) + ","
					+ getString(data.getCategoriesValue_sc()) + ","
					+ getString(data.getApplicationMethod_tc()) + ","
					+ getString(data.getApplicationMethod_sc()) + ","
					+ getString(data.getActivityTarget_tc()) + ","
					+ getString(data.getActivityTarget_sc()) + ","
					+ getString(data.getAgeLowerLimint_tc()) + ","
					+ getString(data.getAgeLowerLimint_sc()) + ","
					+ getString(data.getRemark_tc()) + ","
					+ getString(data.getRemark_sc()) + ","
					+ getString(data.getLongitude()) + ","
					+ getString(data.getLatitude()) + ","
					+ getString(data.getLink()) + ","
					+ getString(data.getLocation_tc()) + ","
					+ getString(data.getLocation_sc()) + ","
					+ getString(data.getDate()) + ","
					+ getString(data.getEndDate());
			String sql = SQL.INSERT_INTO_ACTIVITY_DETAIL.replace("@value", value);
			Log.v(TAG, "sql>>" + sql);
			mSQLiteUtil.getDatabase().execSQL(sql);
		}
	}

	public String getString(String data) {
		if (data != null) {
			return "\"" + data + "\"";
		} else {
			return "null";
		}
	}

	public boolean isContainActivityDetail(ActivityDetailAO data) {
		Cursor cursor = null;
		boolean result = false;
		if (data != null) {
			cursor = readDataFromDB(SQL.CONTAIN_ACTIVITY_DETAIL, new String[] { data.getId(), data.getActivityType() });
			// Log.v(TAG, "cursor>>"+Arrays.toString(cursor.getColumnNames()));
			if (cursor != null) {
				cursor.moveToNext();
				String c = cursor.getString(cursor.getColumnIndex("c"));
				cursor.close();
				int count = Integer.parseInt(c);
				if (count == 0) {
					result = false;
				} else {
					result = true;
				}
			}
		}
		return result;
	}

	public boolean isContainActivityDetail(String id, String type) {
		Cursor cursor = null;
		boolean result = false;
		if (type != null && id != null) {
			cursor = readDataFromDB(SQL.CONTAIN_ACTIVITY_DETAIL, new String[] { id, type });
			// Log.v(TAG, "cursor>>"+Arrays.toString(cursor.getColumnNames()));
			if (cursor != null) {
				cursor.moveToNext();
				String c = cursor.getString(cursor.getColumnIndex("c"));
				cursor.close();
				int count = Integer.parseInt(c);
				if (count == 0) {
					result = false;
				} else {
					result = true;
				}
			}
		}
		return result;
	}

	public List<ActivityDetailDBO> getLCSDData(Date date) {
		List<ActivityDetailDBO> result = null;
		if (date != null) {
			String arg = CLDateUtil.formatDate(date, "yyyy-MM-dd");//按月查询,sql 会format yyyyMM
			String sql = SQL.SELECT_LCSD_BY_DATE.replace("?", arg);
			Cursor cursor = readDataFromDB(sql, null);
			if (cursor != null) {
				result = fetchDataFromCursor(ActivityDetailDBO.class, cursor);
			}
		}
		return result;
	}

	public List<ElderlyCenterDBO> getElderlyGroupList(Date date) {
		List<ElderlyCenterDBO> result = null;
		if (date != null) {
//			String arg = CLDateUtil.formatDate(date, "yyyy-MM-dd");
			String arg = CLDateUtil.formatDate(date, "yyyy-MM");//按月查询
			String sql = SQL.SELECT_ELDERLY_CENTRE_BY_DATE.replace("?", arg);
			Cursor cursor = readDataFromDB(sql, null);
			if (cursor != null) {
				result = fetchDataFromCursor(ElderlyCenterDBO.class, cursor);
			}
		}
		return result;
	}
	
	public int delete(String id){
//		String sql = SQL.DELETE.replace("?", id);
//		mSQLiteUtil.getDatabase().execSQL(sql);
		System.out.println(new String[]{"\""+id+"\""});
		return mSQLiteUtil.getDatabase().delete("activity_detail", "id=?", new String[]{id});
	}

	public HashMap<String, List<ActivityDetailDBO>> getElderlyActvitys(Date date, List<ElderlyCenterDBO> centreDBO) {
		HashMap<String, List<ActivityDetailDBO>> result = new HashMap<String, List<ActivityDetailDBO>>();
		if (date != null && centreDBO != null) {
//			String arg = CLDateUtil.formatDate(date, "yyyy-MM-dd");
			String arg = CLDateUtil.formatDate(date, "yyyy-MM");//按月查询
			String sql = SQL.SELECT_ELDERLY_CENTRE_ACTIVITY_BY_DATE.replace("?2", arg);
			List<ActivityDetailDBO> subData = null;
			for (int i = 0; i < centreDBO.size(); i++) {
				ElderlyCenterDBO centre = centreDBO.get(i);
				if (centre != null) {
					Cursor cursor = readDataFromDB(sql.replace("?1", centre.getCenterId()), null);
					if (cursor != null) {
						subData = fetchDataFromCursor(ActivityDetailDBO.class, cursor);
					}
					if (subData != null && subData.size() > 0) {
						result.put(centre.getCenterId(), subData);
					}
				}
			}

		}
		return result;
	}

}
