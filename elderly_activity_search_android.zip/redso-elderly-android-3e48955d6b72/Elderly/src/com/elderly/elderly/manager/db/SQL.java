package com.elderly.elderly.manager.db;

public class SQL {
	public static final String CONTAIN_ACTIVITY_DETAIL="select count(*) as c from activity_detail where id=? and activity_type=?";
	
	public static final String INSERT_INTO_ACTIVITY_DETAIL="insert into activity_detail(activity_type,id,nid,title_tc,title_sc,startTime,endTime," +
			"activeArea_tc,activeArea_sc,memberFee_tc,memberFee_sc," +
			"nonmenberFee_tc,nonmenberFee_sc,fee_tc,fee_sc," +
			"eventType_tc,eventType_sc,centerId,centerNid,activityCenterName_tc,activityCenterName_sc,activityDetail_tc,activityDetail_sc,organization_tc,organization_sc," +
			"categoriesValue_tc,categoriesValue_sc,applicationMethod_tc,applicationMethod_sc,activityTarget_tc,activityTarget_sc,ageLowerLimint_tc,ageLowerLimint_sc," +
			"remark_tc,remark_sc,longitude,latitude,link,location_tc,location_sc,activity_date,activity_endDate) values(@value)";
	
//	public static final String SELECT_LCSD_BY_DATE="select * from activity_detail where activity_type=\"L\" and strftime('%s','?') between strftime('%s',activity_date) and strftime('%s',activity_endDate)";
	public static final String SELECT_LCSD_BY_DATE="select * from activity_detail where activity_type=\"L\" and strftime('%Y%m','?') between strftime('%Y%m',activity_date) and strftime('%Y%m',activity_endDate)";//按月查询
	
	public static final String SELECT_ELDERLY_CENTRE_ACTIVITY_BY_DATE="select * from activity_detail where activity_type=\"E\" and centerId=\"?1\" and activity_date like '%?2%' order by centerId";
	
	public static final String SELECT_ELDERLY_CENTRE_BY_DATE="select * from activity_detail where activity_type=\"E\" and activity_date like '%?%' group by centerId order by centerId";
	
	public static final String SELECT_ALL_TABLE_COUNT = "select count(*) as c from Sqlite_master where type = 'table'";

	public static final String DELETE = "delete from activity_detail where id=\"?\"";

}
