package com.elderly.elderly.manager;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.Constants.FontSize;
import com.elderly.elderly.Constants.Language;
import com.elderly.elderly.ElderlyApplication;

public class SettingsManager {
	private static final String TAG = "SettingsManager";
	private ElderlyApplication mApplication;
	private static SettingsManager instance = null;

	private SettingsManager(ElderlyApplication application) {
		mApplication = application;
	}

	public synchronized static void init(ElderlyApplication application) {
		if (instance == null) {
			instance = new SettingsManager(application);
		}
	}

	public static SettingsManager getInstance() {
		return instance;
	}

	public String getLanguageFromSettings() {
		return mApplication.getDefaultSharedPreferences().getString(Constants.SP_KEYS_LANGUAGE, null);
	}

	public void saveLanguageToSettings(Language language) {
		mApplication.getDefaultSharedPreferences().edit().putString(Constants.SP_KEYS_LANGUAGE, language.name())
				.commit();
	}

	public String getFontSizeFromSettings() {
		return mApplication.getDefaultSharedPreferences().getString(Constants.SP_KEYS_FONT_SIZE, null);
	}



	public void saveFontSizeToSettings(FontSize fontSize) {
		mApplication.getDefaultSharedPreferences().edit().putString(Constants.SP_KEYS_FONT_SIZE, fontSize.name())
				.commit();
	}

	public String getColorThemeFromSettings() {
		return mApplication.getDefaultSharedPreferences().getString(Constants.SP_KEYS_COLOR_THEME, null);
	}

	public void saveColorThemeToSettings(ColorTheme colorTheme) {
		mApplication.getDefaultSharedPreferences().edit().putString(Constants.SP_KEYS_COLOR_THEME, colorTheme.name())
				.commit();
	}



    public String getSearchModeSettings() {
        return mApplication.getDefaultSharedPreferences().getString(Constants.SP_KEYS_SEARCH, "horizontal");
    }

    public void saveSearchModeSettings(Constants.SearchMode searchMode) {

        mApplication.getDefaultSharedPreferences().edit().putString(Constants.SP_KEYS_SEARCH,searchMode
                .name())
                .commit();
    }

	public String getPropertyForGCMRegisterToken() {
		return mApplication.getDefaultSharedPreferences().getString(Constants.SP_KEYS_GCM_TOKEN, null);
	}

	public void setPropertyForGCMRegisterToken(String token) {
		mApplication.getDefaultSharedPreferences().edit().putString(Constants.SP_KEYS_GCM_TOKEN, token)
				.commit();
	}

}
