package com.elderly.elderly.manager.api;

import android.content.Context;
import android.util.Log;

import com.elderly.elderly.Constants;
import com.elderly.elderly.parser.ActivityAOParser;
import com.elderly.elderly.parser.ActivityCenterAOParser;
import com.elderly.elderly.parser.ActivityDetailAOParser;
import com.elderly.elderly.parser.BannerAOParser;
import com.elderly.elderly.parser.CommunityCentreAOParser;
import com.elderly.elderly.parser.DateAOParser;
import com.elderly.elderly.parser.GetTokenParser;
import com.elderly.elderly.parser.KeyWordAOParser;
import com.elderly.elderly.parser.VersionAOParser;
import com.elderly.elderly.parser.WeatherAOParser;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.ActivityCenterAO;
import com.elderly.elderly.pojo.ao.ActivityDetailAO;
import com.elderly.elderly.pojo.ao.BannerAO;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.elderly.elderly.pojo.ao.DateAO;
import com.elderly.elderly.pojo.ao.GetTokenAO;
import com.elderly.elderly.pojo.ao.KeyWordAO;
import com.elderly.elderly.pojo.ao.VersionAO;
import com.elderly.elderly.pojo.ao.WeatherAO;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLHttpClient;
import com.gt.cl.http.CLInvalidNetworkException;
import com.gt.cl.util.CLFileUtil;

import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.util.List;
import java.util.TreeMap;

public class ApiManager {
	private static final String TAG = "ApiManager";
	private static ApiManager instance;
	private Context mContext;
	private CLHttpClient mWeatherHttpClient;
	private CLHttpClient mNewActivityHttpClient;
	private CLHttpClient mActivityDetailHttpClient;
	private CLHttpClient mMyFavouriteCenterHttpClient;
	private CLHttpClient mSearchNearByListHttpClient;
	private CLHttpClient mSearchElderlyListHttpClient;
	private CLHttpClient mDateListHttpClient;
	private CLHttpClient mDateListByCoordinateHttpClient;
	private CLHttpClient mKeyWorkHttpClient;
	private CLHttpClient mSearchLcsdHttpClient;
	private CLHttpClient mCommunityCentreListHttpClient;
	private CLHttpClient mLCSDEasySearchListHttpClient;
	private CLHttpClient mElderlyEasySearchListHttpClient;
	private CLHttpClient mSearchLcsdListByKeywordHttpClient;
	public static final int DEFALUT_PAGE_SIZE = 20;

	private ApiManager(Context context) {
		this.mContext = context;
	}

	public static void init(Context context) {
		if (instance == null) {
			instance = new ApiManager(context);
		}
	}

	public static ApiManager getInstance() {
		return instance;
	}

	public WeatherAO checkWeather() throws CLConnectionException, CLInvalidNetworkException, XmlPullParserException {
		String url = Constants.API_CHECK_WEACHER;
		mWeatherHttpClient = new CLHttpClient(url, mContext);
		CLFileUtil.deleteCacheFile("xml/weather.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/weather.xml", mContext);
		mWeatherHttpClient.get(filePath);
		WeatherAOParser parser = new WeatherAOParser();
		parser.parser(filePath);
		WeatherAO ao = parser.getWeatherAO();
		String saveFile = CLFileUtil.createCacheFile("store/weather.xml", mContext);
		CLFileUtil.copyFile(new File(filePath), new File(saveFile));
		return ao;
	}

	/**
	 * 获取之前保存天汽
	 * 
	 * @return
	 * @author jianfeng.lao
	 * @CreateDate 2013-10-10
	 */
	public WeatherAO getWeatherFormHistory() {
		File cacheDir = mContext.getCacheDir();
		String path = cacheDir.getPath() + "/" + "store/weather.xml";
		File file = new File(path);
		if (!file.exists()) {
			return null;
		}
		WeatherAO ao = null;
		WeatherAOParser parser = new WeatherAOParser();
		try {
			parser.parser(file.getAbsolutePath());
			ao = parser.getWeatherAO();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}

		return ao;

	}

	public void cancelCheckWeather() {
		if (mWeatherHttpClient != null) {
			mWeatherHttpClient.closeHttpClient();
			mWeatherHttpClient = null;
		}
	}

	public List<CommunityCentreAO> getCommunityCentreList(String district, int offset, int pageSize)
			throws CLConnectionException,
			CLInvalidNetworkException, XmlPullParserException {
		String url = Constants.API_MY_COMMUNITY_CENTRE_LIST;
		mCommunityCentreListHttpClient = new CLHttpClient(url, mContext);
		mCommunityCentreListHttpClient.addParam("district", district);
		mCommunityCentreListHttpClient.addParam("offset", offset);
		mCommunityCentreListHttpClient.addParam("pageSize", pageSize);
		CLFileUtil.deleteCacheFile("xml/my_communityCentre.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/my_communityCentre.xml", mContext);
		mCommunityCentreListHttpClient.post(filePath);
		CommunityCentreAOParser parser = new CommunityCentreAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallCommunityCentreList() {
		if (mCommunityCentreListHttpClient != null) {
			mCommunityCentreListHttpClient.closeHttpClient();
			mCommunityCentreListHttpClient = null;
		}
	}

	/**
	 * 
	 * @param type
	 *            参数:offset, pageSize, activityType[L:康文署/ E:長者活動中心]
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 * @author jianfeng.lao
	 * @CreateDate 2013-9-10
	 */
	public List<ActivityAO> getActivityPageList(String type, int offset) throws CLConnectionException,
			CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_NEW_ACTIVITY;
		CLFileUtil.deleteCacheFile("xml/page_activity.xml", mContext);
		mNewActivityHttpClient = new CLHttpClient(url, mContext);

		mNewActivityHttpClient.addParam("activityType", type);
        Log.v(TAG, "activityType>>"+type);
		mNewActivityHttpClient.addParam("offset", offset);
        Log.v(TAG, "offset>>"+offset);
		mNewActivityHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		String filePath = CLFileUtil.createCacheFile("xml/page_activity.xml", mContext);
		mNewActivityHttpClient.post(filePath);
		ActivityAOParser parser = new ActivityAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallActivityPageList() {
		if (mNewActivityHttpClient != null) {
			mNewActivityHttpClient.closeHttpClient();
			mNewActivityHttpClient = null;
		}
	}

	/**
	 * Type:M代表Main page，A代表Activity detail , L 代表 Latest activities
	 * 
	 * @return
	 * @author jianfeng.lao
	 * @throws CLInvalidNetworkException
	 * @throws CLConnectionException
	 * @throws XmlPullParserException
	 * @CreateDate 2013-9-10
	 */
	public List<BannerAO> getBannerList(String type) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_BANNAR;
		CLHttpClient client = new CLHttpClient(url, mContext);
		client.addParam("type", type);
		CLFileUtil.deleteCacheFile("xml/banner.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/banner.xml", mContext);
		client.post(filePath);
		BannerAOParser parser = new BannerAOParser();
		parser.parser(filePath);
		String saveFile = CLFileUtil.createCacheFile("store/" + type + "_banner.xml", mContext);
		CLFileUtil.copyFile(new File(filePath), new File(saveFile));
		return parser.getData();
	}

	/**
	 * 获得历史的Banner数据
	 * 
	 * @param type
	 * @return
	 * @author jianfeng.lao
	 * @CreateDate 2013-10-10
	 */
	public List<BannerAO> getBannerListFormHistory(String type) {
		Log.v(TAG, "getBannerListFormHistory>>type>>" + type);
		File cacheDir = mContext.getCacheDir();
		String path = cacheDir.getPath() + "/" + "store/" + type + "_banner.xml";
		File file = new File(path);
		if (!file.exists()) {
			return null;
		}
		List<BannerAO> datas = null;
		BannerAOParser parser = new BannerAOParser();
		try {
			parser.parser(path);
			datas = parser.getData();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return datas;
	}

	/**
	 * 
	 * @param id
	 * @param type
	 *            [L:康文署/ E:長者活動中心]
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 * @author jianfeng.lao
	 * @CreateDate 2013-9-10
	 */
	public ActivityDetailAO getActivityDetail(String id, String type) throws CLConnectionException,
			CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_ACTIVITY_DETAIL;
		mActivityDetailHttpClient = new CLHttpClient(url, mContext);
		mActivityDetailHttpClient.addParam("id", id);
		mActivityDetailHttpClient.addParam("activityType", type);
		CLFileUtil.deleteCacheFile("xml/activity_detail.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/activity_detail.xml", mContext);
		mActivityDetailHttpClient.post(filePath);
		ActivityDetailAOParser parser = new ActivityDetailAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallActivityDetail() {
		if (mActivityDetailHttpClient != null) {
			mActivityDetailHttpClient.closeHttpClient();
			mActivityDetailHttpClient = null;
		}
	}

	/**
	 * 获取最爱中心 活动
	 * 
	 * @param date 日期
	 * @param centreIds 社区中心Id
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 */
	public TreeMap<String, List<ActivityAO>> getMyFavouriteCentreActivity(String date, List<String> centreIds)
			throws CLConnectionException, CLInvalidNetworkException, XmlPullParserException {
        TreeMap<String, List<ActivityAO>> data = new TreeMap<String, List<ActivityAO>>();
		String url = Constants.API_MY_FAVOURITE_CENTRE;
		if (date != null && centreIds != null) {
			for (int i = 0; i < centreIds.size(); i++) {
				CLFileUtil.deleteCacheFile("xml/my_favourite_centre_activity.xml", mContext);
				mMyFavouriteCenterHttpClient = new CLHttpClient(url, mContext);
				mMyFavouriteCenterHttpClient.addParam("activityType", "E");
				mMyFavouriteCenterHttpClient.addParam("activityCenterId", centreIds.get(i));
                Log.v(TAG, "activityCenterId>>"+centreIds.get(i));
				mMyFavouriteCenterHttpClient.addParam("date", date);
                Log.v(TAG, "date>>"+date);
				CLFileUtil.deleteCacheFile("xml/my_favourite_centre_activity.xml", mContext);
				String filePath = CLFileUtil.createCacheFile("xml/my_favourite_centre_activity.xml", mContext);
				mMyFavouriteCenterHttpClient.post(filePath);
				ActivityAOParser parser = new ActivityAOParser();
				parser.parser(filePath);
				List<ActivityAO> datas = parser.getData();
				if (datas != null && datas.size() > 0) {
					data.put(centreIds.get(i), datas);
				}

			}
		}
		return data;
	}

	public void cancelCallMyFavouriteCentre() {
		if (mMyFavouriteCenterHttpClient != null) {
			mMyFavouriteCenterHttpClient.closeHttpClient();
			mMyFavouriteCenterHttpClient = null;
		}
	}

	/**
	 * 获取附近的活动中心
	 * 
	 * @param searchDistance 搜索范围
	 * @param latitude
	 * @param longitude
	 * @param date 日期
	 * @param activeArea 活动范围
	 * 
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 */
	public List<ActivityCenterAO> getSearchNearbyList(String searchDistance, String latitude, String longitude,
			String date,
			String activeArea, int offset) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_SEARCH_NEARBY_LIST;
		mSearchNearByListHttpClient = new CLHttpClient(url, mContext);
		mSearchNearByListHttpClient.addParam("activityType", "E");
		mSearchNearByListHttpClient.addParam("offset", offset);
		mSearchNearByListHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		mSearchNearByListHttpClient.addParam("searchDistance", searchDistance);
		mSearchNearByListHttpClient.addParam("latitude", latitude);
		mSearchNearByListHttpClient.addParam("longitude", longitude);
		mSearchNearByListHttpClient.addParam("date", date);
		mSearchNearByListHttpClient.addParam("activeArea", activeArea);
		CLFileUtil.deleteCacheFile("xml/search_nearby_list.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/search_nearby_list.xml", mContext);
		mSearchNearByListHttpClient.post(filePath);
		ActivityCenterAOParser parser = new ActivityCenterAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallSearchNearbyList() {
		if (mSearchNearByListHttpClient != null) {
			mSearchNearByListHttpClient.closeHttpClient();
			mSearchNearByListHttpClient = null;
		}
	}

	/**
	 * 获取elderly列表
	 * 
	 * @param date 日期
	 * @param eventType
	 * @param activeArea 活动范围
	 * @param age 年龄
	 * @param fee
	 * @param organization 组织
	 * @param keyword 关键字
	 * 
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 */
	public List<ActivityCenterAO> getSearchElderlyList(String date, String eventType, String activeArea, String age,
			String fee,
			String organization, String keyword, int offset) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_SEARCH_ELDERLY_LIST;
		mSearchElderlyListHttpClient = new CLHttpClient(url, mContext);
		mSearchElderlyListHttpClient.addParam("offset", offset);
		mSearchElderlyListHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		mSearchElderlyListHttpClient.addParam("date", date);
		mSearchElderlyListHttpClient.addParam("eventType", eventType);
		mSearchElderlyListHttpClient.addParam("activeArea", activeArea);
		mSearchElderlyListHttpClient.addParam("age", age);
		mSearchElderlyListHttpClient.addParam("fee", fee);
		mSearchElderlyListHttpClient.addParam("organization", organization);
		mSearchElderlyListHttpClient.addParam("keyword", keyword);
		CLFileUtil.deleteCacheFile("xml/search_elderly_list.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/search_elderly_list.xml", mContext);
		mSearchElderlyListHttpClient.post(filePath);
		ActivityCenterAOParser parser = new ActivityCenterAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallSearchElderlyList() {
		if (mSearchElderlyListHttpClient != null) {
			mSearchElderlyListHttpClient.closeHttpClient();
			mSearchElderlyListHttpClient = null;
		}
	}

	/**
	 * 获取date列表
	 * 
	 * @param date 日期
	 * @param eventType
	 * @param activeArea 活动范围
	 * @param age 年龄
	 * @param fee
	 * @param organization 组织
	 * @param keyword 关键字
	 * @param activityType 活动类型
	 * 
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 */
	public List<DateAO> getDateList(String date, String eventType, String activeArea, String age, String fee,
			String organization,
			String keyword, String activityType) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_DATE_LIST;
		mDateListHttpClient = new CLHttpClient(url, mContext);
		mDateListHttpClient.addParam("date", date);
		mDateListHttpClient.addParam("eventType", eventType);
		mDateListHttpClient.addParam("activeArea", activeArea);
		mDateListHttpClient.addParam("age", age);
		mDateListHttpClient.addParam("fee", fee);
		mDateListHttpClient.addParam("organization", organization);
		mDateListHttpClient.addParam("keyword", keyword);
		mDateListHttpClient.addParam("activityType", activityType);
		CLFileUtil.deleteCacheFile("xml/date_list.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/date_list.xml", mContext);
		mDateListHttpClient.post(filePath);
		DateAOParser parser = new DateAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallDateList() {
		if (mDateListHttpClient != null) {
			mDateListHttpClient.closeHttpClient();
			mDateListHttpClient = null;
		}
	}

	/**
	 * 获取search nearly date列表
	 * 
	 * @param date 日期
	 * 
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 */
	public List<DateAO> getDateListByCoordinate(String date, String searchDistance, String latitude, String longitude)
			throws CLConnectionException, CLInvalidNetworkException, XmlPullParserException {
		String url = Constants.API_DATE_LIST_BYCOORDINATE;
		mDateListByCoordinateHttpClient = new CLHttpClient(url, mContext);
		mDateListByCoordinateHttpClient.addParam("date", date);
		mDateListByCoordinateHttpClient.addParam("activityType", "E");
		mDateListByCoordinateHttpClient.addParam("searchDistance", searchDistance);
		mDateListByCoordinateHttpClient.addParam("latitude", latitude);
		mDateListByCoordinateHttpClient.addParam("longitude", longitude);
		CLFileUtil.deleteCacheFile("xml/date_list_by_Coordinate.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/date_list_by_Coordinate.xml", mContext);
		mDateListByCoordinateHttpClient.post(filePath);
		DateAOParser parser = new DateAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallDateListByCoordinate() {
		if (mDateListByCoordinateHttpClient != null) {
			mDateListByCoordinateHttpClient.closeHttpClient();
			mDateListByCoordinateHttpClient = null;
		}
	}

	public List<KeyWordAO> getKeyWordList() throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_KEYWORD_LIST;
		mKeyWorkHttpClient = new CLHttpClient(url, mContext);
		CLFileUtil.deleteCacheFile("xml/key_word.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/key_word.xml", mContext);
		mKeyWorkHttpClient.post(filePath);
		KeyWordAOParser parser = new KeyWordAOParser();
		parser.parser(filePath);
		return parser.getData();

	}

	public void cancelCallKeyWordList() {
		if (mKeyWorkHttpClient != null) {
			mKeyWorkHttpClient.closeHttpClient();
			mKeyWorkHttpClient = null;
		}
	}
	/**
	 * 按日查询LCSD活动
	 * @param date
	 * @param eventType
	 * @param activeArea
	 * @param age
	 * @param fee
	 * @param organization
	 * @param keyword
	 * @param offset
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 * @author jianfeng.lao
	 * @CreateDate 2013-10-18
	 */
	public List<ActivityAO> getSearchLcsdList(String date, String eventType, String activeArea, String age, String fee,
			String organization, String keyword, int offset) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_SEARCH_LCSD_LIST;
		mSearchLcsdHttpClient = new CLHttpClient(url, mContext);
		mSearchLcsdHttpClient.addParam("offset", offset);
		mSearchLcsdHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		mSearchLcsdHttpClient.addParam("date", date);
		mSearchLcsdHttpClient.addParam("eventType", eventType);
		mSearchLcsdHttpClient.addParam("activeArea", activeArea);
		mSearchLcsdHttpClient.addParam("age", age);
		mSearchLcsdHttpClient.addParam("fee", fee);
		mSearchLcsdHttpClient.addParam("organization", organization);
		mSearchLcsdHttpClient.addParam("keyword", keyword);
		CLFileUtil.deleteCacheFile("xml/search_lcsd_list.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/search_lcsd_list.xml", mContext);
		mSearchLcsdHttpClient.post(filePath);
		ActivityAOParser parser = new ActivityAOParser();
		parser.parser(filePath);
		return parser.getData();
	}
	
	public void cancelCallSearchLcsdList() {
		if (mSearchLcsdHttpClient != null) {
			mSearchLcsdHttpClient.closeHttpClient();
			mSearchLcsdHttpClient = null;
		}
	}

	/**
	 * 按月查询康文处活动
	 * 
	 * @param date 格式(yyyy-MM)
	 * @param offset
	 * @param eventType
	 * @param activeArea
	 * @return
	 * @author jianfeng.lao
	 * @throws CLInvalidNetworkException
	 * @throws CLConnectionException
	 * @throws XmlPullParserException
	 * @CreateDate 2013-10-18
	 */
	public List<ActivityAO> getLCSDEasySearchList(String date, int offset, String eventType, String activeArea)
			throws CLConnectionException, CLInvalidNetworkException, XmlPullParserException {
		String url = Constants.API_EASY_SEARCH_LIST;
		mLCSDEasySearchListHttpClient = new CLHttpClient(url, mContext);
		mLCSDEasySearchListHttpClient.addParam("offset", offset);
		mLCSDEasySearchListHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		mLCSDEasySearchListHttpClient.addParam("date", date);
		mLCSDEasySearchListHttpClient.addParam("eventType", eventType);
		mLCSDEasySearchListHttpClient.addParam("activeArea", activeArea);
		mLCSDEasySearchListHttpClient.addParam("activityType", "L");
		CLFileUtil.deleteCacheFile("xml/lcsd_easy_search_list.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/lcsd_easy_search_list.xml", mContext);
		mLCSDEasySearchListHttpClient.post(filePath);
		ActivityAOParser parser = new ActivityAOParser();
		parser.parser(filePath);
		return parser.getData();
	}
	
	
	public void cancelCallLCSDEasySearchList() {
		if (mLCSDEasySearchListHttpClient != null) {
			mLCSDEasySearchListHttpClient.closeHttpClient();
			mLCSDEasySearchListHttpClient = null;
		}
	}
	
	/**
	 * 按月查询长者活动中心活动
	 * @param date 格式(yyyy-MM)
	 * @param offset
	 * @param eventType
	 * @param activeArea
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 * @author jianfeng.lao
	 * @CreateDate 2013-10-18
	 */
	public List<ActivityCenterAO> getElderlyEasySearchList(String date, int offset, String eventType, String activeArea) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_EASY_SEARCH_LIST;
		mElderlyEasySearchListHttpClient = new CLHttpClient(url, mContext);
		mElderlyEasySearchListHttpClient.addParam("offset", offset);
		mElderlyEasySearchListHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		mElderlyEasySearchListHttpClient.addParam("date", date);
		mElderlyEasySearchListHttpClient.addParam("eventType", eventType);
		mElderlyEasySearchListHttpClient.addParam("activeArea", activeArea);
		mElderlyEasySearchListHttpClient.addParam("activityType", "E");
		CLFileUtil.deleteCacheFile("xml/elderly_easy_search_list.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/elderly_easy_search_list.xml", mContext);
		mElderlyEasySearchListHttpClient.post(filePath);
		ActivityCenterAOParser parser = new ActivityCenterAOParser();
		parser.parser(filePath);
		return parser.getData();
	}

	public void cancelCallElderlyEasySearchList() {
		if (mSearchElderlyListHttpClient != null) {
			mSearchElderlyListHttpClient.closeHttpClient();
			mSearchElderlyListHttpClient = null;
		}
	}
	
	/**
	 * 按月
	 * @param date
	 * @param keyword
	 * @param offset
	 * @return
	 * @throws CLConnectionException
	 * @throws CLInvalidNetworkException
	 * @throws XmlPullParserException
	 * @author jianfeng.lao
	 * @CreateDate 2013-10-18
	 */
	public List<ActivityAO> getSearchLcsdListByKeyword(String date,String keyword, int offset) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_SEARCH_LCSD_LIST_BY_KEY_WORD;
		mSearchLcsdListByKeywordHttpClient = new CLHttpClient(url, mContext);
		mSearchLcsdListByKeywordHttpClient.addParam("offset", offset);
		mSearchLcsdListByKeywordHttpClient.addParam("pageSize", DEFALUT_PAGE_SIZE);
		mSearchLcsdListByKeywordHttpClient.addParam("date", date);
		mSearchLcsdListByKeywordHttpClient.addParam("keyword", keyword);
		CLFileUtil.deleteCacheFile("xml/Search_Lcsd_List_By_Keyword.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/Search_Lcsd_List_By_Keyword.xml", mContext);
		mSearchLcsdListByKeywordHttpClient.post(filePath);
		ActivityAOParser parser = new ActivityAOParser();
		parser.parser(filePath);
		return parser.getData();
	}
	
	public void cancelCallSearchLcsdListByKeyword() {
		if (mSearchLcsdListByKeywordHttpClient != null) {
			mSearchLcsdListByKeywordHttpClient.closeHttpClient();
			mSearchLcsdListByKeywordHttpClient = null;
		}
	}

	

	public GetTokenAO sendTokenToService(String token) throws CLConnectionException, CLInvalidNetworkException,
			XmlPullParserException {
		String url = Constants.API_GET_TOKEN;
		CLHttpClient client = new CLHttpClient(url, mContext);
		client.addParam("platform", "android");
		client.addParam("token", token);
		CLFileUtil.deleteCacheFile("xml/send_token.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/send_token.xml", mContext);
		client.post(filePath);
		GetTokenParser parser = new GetTokenParser();
		parser.parser(filePath);
		return parser.getGetTokenAO();
	}

	public VersionAO getVersion() throws CLConnectionException, CLInvalidNetworkException, XmlPullParserException {
		String url = Constants.API_GET_VERSION;
		CLHttpClient client = new CLHttpClient(url, mContext);
		client.addParam("Type", "A");
		CLFileUtil.deleteCacheFile("xml/version.xml", mContext);
		String filePath = CLFileUtil.createCacheFile("xml/version.xml", mContext);
		client.post(filePath);
		VersionAOParser parser = new VersionAOParser();
		parser.parser(filePath);
		return parser.getData();
	}
}
