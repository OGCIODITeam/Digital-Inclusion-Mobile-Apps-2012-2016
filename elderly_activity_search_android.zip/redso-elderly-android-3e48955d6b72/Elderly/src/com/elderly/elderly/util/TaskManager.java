package com.elderly.elderly.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.format.Time;

public class TaskManager extends HandlerThread {
	private Context mUIContext;
	private TaskHandler mTaskHandler;
	private ThreadPoolExecutor mThreadPoolExecutor;
	private BlockingQueue<Runnable> mThreadList=null;

	public TaskManager(Context mUIContext, String managerName) {
		super(managerName);
		start();
		this.mUIContext = mUIContext;
		this.mThreadList = new ArrayBlockingQueue<Runnable>(20);
		if (mTaskHandler == null) {
			mTaskHandler = new TaskHandler(getLooper());
		}
		if(mThreadPoolExecutor==null){
			mThreadPoolExecutor=new ThreadPoolExecutor(2, 10, 30*1000, TimeUnit.MILLISECONDS, mThreadList,new AbortPolicy());
		}
	}

	public void destory() {
		if (mTaskHandler != null) {
			mTaskHandler.getLooper().quit();
			mTaskHandler = null;
		}
		if(mThreadPoolExecutor!=null){
			mThreadPoolExecutor.shutdownNow();
			mThreadPoolExecutor.shutdown();
		}
	}

	private class TaskHandler extends Handler {

		public TaskHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			}
			super.handleMessage(msg);
		}
	}

	public abstract class Task<Params, Progress, Result> extends Thread{
		

		public void onPrepare() {
		};

		public void onProgressUpdate(Progress progress) {
		};

		public abstract Result doInBackGround(Params... params);

		public abstract void doOnSuccess(Result result);

		public boolean handlerException() {
			return false;
		}

	}

}
