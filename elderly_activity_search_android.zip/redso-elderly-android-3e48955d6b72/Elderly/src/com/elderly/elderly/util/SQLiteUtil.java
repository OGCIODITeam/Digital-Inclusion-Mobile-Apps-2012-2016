package com.elderly.elderly.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.elderly.elderly.R;
import com.gt.cl.http.CLConnectionException;
import com.gt.cl.http.CLHttpClient;
import com.gt.cl.util.CLFileUtil;

public class SQLiteUtil {

	private static final String TAG = "SQLiteUtil";

	public String DB_NAME = "elderly.sqlite";

	public static final String DATABASE_PATH = "/data/data/" + R.class.getPackage().getName() + "/databases/";

	private Context mContext;
	private SQLiteDatabase database;

	private boolean updateSuccess = false;

	public SQLiteUtil(Context context) {
		this.mContext = context;
	}

	public boolean checkDatabaseExist() {
		// Log.v(TAG, "checkDatabaseExist>>" + mDBType);
		final File sqlFile = new File(DATABASE_PATH + DB_NAME);
		return sqlFile.exists();
	}

	/**
	 * Create local database, call this method each time on application launch.
	 */
	public void createLocalDatabase() {
		// Log.v(TAG, "createLocalDatabase>>"+mDBType);
		final File databasePath = new File(DATABASE_PATH);
		if (!databasePath.exists()) {
			databasePath.mkdirs();
		}
		InputStream inputStream = null;
		inputStream = mContext.getResources().openRawResource(R.raw.elderly);
		try {
			CLFileUtil.saveInputStreamAsFile(inputStream, new File(DATABASE_PATH + DB_NAME));
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			CLFileUtil.closeIOStream(inputStream);
		}
	}

	public synchronized SQLiteDatabase getDatabase() {
		if (database == null) {
			database = mContext.openOrCreateDatabase(DB_NAME, Context.MODE_WORLD_READABLE, null);
		}
		return database;
	}

	private void release() {
		if (database != null) {
			database.close();
			database = null;
		}
	}

	public void destroy() {
		release();
	}

	// ---------------Utils--------------

	private boolean isZipFile(String fileHeaderCode) {
		final String fileHeader = fileHeaderCode.trim();
		return "504B03".equals(fileHeader);
	}

	private boolean isSqliteFile(String fileHeaderCode) {
		final String fileHeader = fileHeaderCode.trim();
		return "53514C".equals(fileHeader);
	}

	// 获取文件头信息
	private String getFileHeader(String filePath) {
		FileInputStream is = null;
		String value = "";
		try {
			is = new FileInputStream(filePath);
			byte[] b = new byte[3];
			is.read(b, 0, b.length);
			value = bytesToHexString(b);
		} catch (Exception e) {} finally {
			if (null != is) {
				try {
					is.close();
				} catch (IOException e) {}
			}
		}
		return value;
	}

	private String bytesToHexString(byte[] src) {
		StringBuilder builder = new StringBuilder();
		if (src == null || src.length <= 0) {
			return null;
		}
		String hv;
		for (int i = 0; i < src.length; i++) {
			hv = Integer.toHexString(src[i] & 0xFF).toUpperCase();
			if (hv.length() < 2) {
				builder.append(0);
			}
			builder.append(hv);
		}
		return builder.toString();
	}

	/**
	 * 解压缩功能.
	 * 将zipFile文件解压到folderPath目录下.
	 * 
	 * @throws Exception
	 */
	public int unZipFile(File zipFile, String folderPath) throws ZipException, IOException {
		ZipFile zfile = new ZipFile(zipFile);
		Enumeration<? extends ZipEntry> zList = zfile.entries();
		ZipEntry ze = null;
		byte[] buf = new byte[1024];
		while (zList.hasMoreElements()) {
			ze = (ZipEntry) zList.nextElement();
			if (ze.isDirectory()) {
				// Log.d("unZipFile", "ze.getName() = "+ze.getName());
				String dirstr = folderPath + ze.getName();
				// dirstr.trim();
				dirstr = new String(dirstr.getBytes("8859_1"), "UTF-8");
				// Log.d("unZipFile", "str = "+dirstr);
				File f = new File(dirstr);
				f.mkdir();
				continue;
			}
			// Log.d("unZipFile", "ze.getName() = "+ze.getName());
			OutputStream os = new BufferedOutputStream(new FileOutputStream(getRealFileName(folderPath, ze.getName())));
			InputStream is = new BufferedInputStream(zfile.getInputStream(ze));
			int readLen = 0;
			while ((readLen = is.read(buf, 0, 1024)) != -1) {
				os.write(buf, 0, readLen);
			}
			is.close();
			os.close();
		}
		zfile.close();
		Log.d("unZipFile", "unZip successful.");
		return 0;
	}

	/**
	 * 给定根目录，返回一个相对路径所对应的实际文件名.
	 * 
	 * @param baseDir 指定根目录
	 * @param absFileName 相对路径名，来自于ZipEntry中的name
	 * @return java.io.File 实际的文件
	 */
	public File getRealFileName(String baseDir, String absFileName) {
		String[] dirs = absFileName.split("/");
		File ret = new File(baseDir);
		String substr = null;
		if (dirs.length > 1) {
			for (int i = 0; i < dirs.length - 1; i++) {
				substr = dirs[i];
				try {
					// substr.trim();
					substr = new String(substr.getBytes("8859_1"), "GB2312");

				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ret = new File(ret, substr);

			}
			Log.d("unZipFile", "1ret = " + ret);
			if (!ret.exists())
				ret.mkdirs();
			substr = dirs[dirs.length - 1];
			try {
				// substr.trim();
				substr = new String(substr.getBytes("8859_1"), "GB2312");
				Log.d("unZipFile", "substr = " + substr);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ret = new File(ret, substr);
			Log.d("unZipFile", "2ret = " + ret);
			return ret;
		}
		return ret;
	}
}
