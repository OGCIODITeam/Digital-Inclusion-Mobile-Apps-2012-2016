package com.elderly.elderly;

import android.os.Environment;

import java.util.Calendar;

public class Constants {

	

	public static final String FACEBOOK_ID = "534016993338196";

	public static final String WEIBO_ID = "2302179089";

	public static final String TWITTER_CONSUMER_KEY = "JDSsZ1U8mpsm5upec06Hg";

	public static final String TWITTER_CONSUMER_SECRET = "Z25vpMHyZfBzd32bXKiQG9wOBV9Y5Z6q1f9d9cXYE";

	public static final String PUSH_NOTIFICATION_SEND_ID = "1085540347262";

	// public static final String GOOGLE_ANALYTICS_TRACKING_ID_TEST = "UA-43684574-1";
	public static final String GOOGLE_ANALYTICS_TRACKING_ID_PROCUTION = "UA-43684574-1";
	public static final String GOOGLE_ANALYTICS_TRACKING_ID = GOOGLE_ANALYTICS_TRACKING_ID_PROCUTION;

	public static final boolean ENABLE_DEBUG = true;

	public static final boolean ENABLE_UPDATE_DB = true;

	public static final String PATH_LOCAL_IMAGE_LIBRARY = Environment.getExternalStorageDirectory().getAbsolutePath()
			+ "/Elederly/images/";

	// public static final String API_DOMAIN = "http://192.168.1.97:8080/elderly/";

	public static final String UAT_API_DOMAIN = "http://cn.gtomato.com:10080/elderly/";// UAT
	public static final String PRODUTION_API_DOMAIN = "http://www.e123.hk/elderly/";// production

	public static final String API_DOMAIN = BuildSettings.IS_PRODUCTION ? PRODUTION_API_DOMAIN : UAT_API_DOMAIN;
	/**
	 * Type:M代表Main page，A代表Activity detail , L 代表 Latest activities
	 */
	public static final String API_BANNAR = API_DOMAIN + "api/bannerList.do";
	/**
	 * 参数 path,width
	 */
	public static final String API_IMAGE = API_DOMAIN + "api/image.do";
	/**
	 * 参数 district, eg: 香港島, offset, pageSize
	 */
	public static final String API_MY_COMMUNITY_CENTRE_LIST = API_DOMAIN + "api/myCommunityCentreList.do";

	public static final String API_CHECK_WEACHER = API_DOMAIN + "api/weatherList.do";
	/**
	 * 参数:offset, pageSize, activityType[L:康文署/ E:長者活動中心]
	 */
	public static final String API_NEW_ACTIVITY = API_DOMAIN + "api/activityPageList.do";
	/**
	 * 参数:id, activityType[L:康文署/ E:長者活動中心]
	 */
	public static final String API_ACTIVITY_DETAIL = API_DOMAIN + "api/activityDetail.do";
	/**
	 * ctivityType[L:康文署/ E:長者活動中心], activityCenterId, date
	 */
	public static final String API_MY_FAVOURITE_CENTRE = API_DOMAIN + "api/myFavouriteCentre.do";
	/**
	 * offset,pageSize ,activityType[E:長者活動中心], searchDistance, latitude, longitude，date, activeArea,
	 * choose[C:现在的坐标，A：现在的居住 区域]
	 */
	public static final String API_SEARCH_NEARBY_LIST = API_DOMAIN + "api/searchNearbyList.do";
	/**
	 * offset,pageSize ,date, eventType, activeArea, age, fee, organization, keyword
	 */
	public static final String API_SEARCH_ELDERLY_LIST = API_DOMAIN + "api/searchElderlyList.do";
	/**
	 * offset,pageSize, date, eventType, activeArea, age, fee, organization, keyword
	 */
	public static final String API_SEARCH_LCSD_LIST = API_DOMAIN + "api/searchLcsdList.do";
	/**
	 * date, eventType, activeArea, age, fee, organization, keyword, activityType[L:康文署/ E:長者活動中心]
	 */
	public static final String API_SEARCH_DATE = API_DOMAIN + "api/dateList.do";

	public static final String API_KEYWORD_LIST = API_DOMAIN + "api/keywordList.do";
	/**
	 * date, eventType, activeArea, age, fee, organization, keyword, activityType[L:康文署/ E:長者活動中心]
	 */
	public static final String API_DATE_LIST = API_DOMAIN + "api/dateList.do";
	/**
	 * offset,pageSize ,activityType[E:長者活動中心], searchDistance, latitude, longitude，date
	 */
	public static final String API_DATE_LIST_BYCOORDINATE = API_DOMAIN + "api/dateListByCoordinate.do";

	/**
	 * platform:ios/android, token
	 */
	public static final String API_GET_TOKEN = API_DOMAIN + "api/getToken.do";
	/**
	 * Type:A
	 */
	public static final String API_GET_VERSION = API_DOMAIN + "api/checkVersion.do";

	/**
	 * offset,pageSize ,date(yyyy-MM), eventType, activeArea, activityType[L:康文署/ E:長者活動中心]
	 */
	public static final String API_EASY_SEARCH_LIST = API_DOMAIN + "api/easySearchList.do";
	/**
	 * offset,pageSize, date(yyyy-MM), keyword
	 */
	public static final String API_SEARCH_LCSD_LIST_BY_KEY_WORD = API_DOMAIN + "api/searchLcsdListByKeword.do";

	/**
	 * 关于我们 url
	 */
	public static final String LINK_ABOUT_US_TC = API_DOMAIN + "about/about_tc.html";
	public static final String LINK_ABOUT_US_SC = API_DOMAIN + "about/about_sc.html";

	/*-- SP Keys --*/
	public static final String SP_KEYS_LANGUAGE = "Language";
	public static final String SP_KEYS_FONT_SIZE = "font_size";
	public static final String SP_KEYS_COLOR_THEME = "color_theme";
    public static final String SP_KEYS_SEARCH = "Search";
	public static final String SP_KEYS_GCM_TOKEN = "gcm_token";

	/**
	 * other
	 * 
	 */

	public static final String DATE_FORMAT_PATTERN_SHOW = "yyyy年MM月dd日";
	public static final String DATE_FORMAT_PATTERN_SHOW2 = "yyyy年MM月";
	public static final String DATE_FORMAT_PATTERN_SHOW3 = "yyyy年";
	public static final String DATE_FORMAT_PATTERN_SHOW_SPECIAL = "yyyy-MM-dd";
	public static final String DATE_FORMAT_PATTERN_API = "yyyy-MM-dd";
	public static final String DATE_FORMAT_PATTERN_API2 = "yyyy-MM";

	public static enum Language {
		Chinese, TranditionalChinese;
		public static Language CurrentLanguage;

		public static String getCurrentLanguageStr() {
			if (CurrentLanguage == Chinese) {
				return "sc";
			} else {
				return "cn";
			}
		}
	}

	public static enum FontSize {
		Small, Normal, Large;
		public static FontSize CurrentFontSize;

		public static String getCurrentLanguageStr() {
			if (CurrentFontSize == Normal) {
				return "normal";
			} else if (CurrentFontSize == Large) {
				return "large";
			} else {
				return "small";
			}
		}
	}

	public static enum ColorTheme {
		ColorTheme1, ColorTheme2;
		public static ColorTheme CurrentColorTheme;

		public static String getCurrentLanguageStr() {
			if (CurrentColorTheme == ColorTheme1) {
				return "ColorTheme1";
			} else {
				return "ColorTheme2";
			}
		}

	}


    public static enum SearchMode{

        Vertical, Horizontal;
        public static SearchMode CurrentsearchMode;

        public static String getCurrentSearchMode() {
            if (CurrentsearchMode == Vertical) {
                return "Vertical";
            } else {
                return "Horizontal";
            }
        }

    }


	public static enum HeaderType {
		NewsActivity, FavoriteCenter, MyActivity, SearchNear, SearchEasy, SearchAdvance, ProfileSetting, Other, MainActivityToWebView, Setting
	}

	public static int getSchemeColorIdByHeaderType(HeaderType type) {
		if (type != null && ColorTheme.CurrentColorTheme != null) {
			if (type.equals(HeaderType.NewsActivity)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_NewActivity;
				} else {
					return R.color.header_scheme2_NewActivity;
				}
			} else if (type.equals(HeaderType.FavoriteCenter)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_FavoriteCenter;
				} else {
					return R.color.header_scheme2_FavoriteCenter;
				}
			} else if (type.equals(HeaderType.MyActivity)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_MyActivity;
				} else {
					return R.color.header_scheme2_MyActivity;
				}
			} else if (type.equals(HeaderType.SearchNear)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_SearchNear;
				} else {
					return R.color.header_scheme2_SearchNear;
				}
			} else if (type.equals(HeaderType.SearchEasy)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_SearchSimply;
				} else {
					return R.color.header_scheme2_SearchSimply;
				}
			} else if (type.equals(HeaderType.SearchAdvance)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_SearchAdvanced;
				} else {
					return R.color.header_scheme2_SearchAdvanced;
				}
			} else if (type.equals(HeaderType.ProfileSetting)) {
				return R.color.header_ProfileSetting;
			} else if (type.equals(HeaderType.MainActivityToWebView)) {
				return R.color.blue;
			} else if (type.equals(HeaderType.Setting)) {
				return R.color.header_Setting;
			}
			return R.color.header_trasparent;
		} else {
			return R.color.header_trasparent;
		}
	}

	public static int getSchemeHightLightColorIdByHeaderType(HeaderType type) {
		if (type != null && ColorTheme.CurrentColorTheme != null) {
			if (type.equals(HeaderType.NewsActivity)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_NewActivity_heightLight;
				} else {
					return R.color.header_scheme2_NewActivity_heightLight;
				}
			} else if (type.equals(HeaderType.FavoriteCenter)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_FavoriteCenter_heightLight;
				} else {
					return R.color.header_scheme2_FavoriteCenter_heightLight;
				}
			} else if (type.equals(HeaderType.MyActivity)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_MyActivity_hightLight;
				} else {
					return R.color.header_scheme2_MyActivity_hightLight;
				}
			} else if (type.equals(HeaderType.SearchNear)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_SearchNear_hightLight;
				} else {
					return R.color.header_scheme2_SearchNear_hightLight;
				}
			} else if (type.equals(HeaderType.SearchEasy)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_SearchSimply_hightLight;
				} else {
					return R.color.header_scheme2_SearchSimply_hightLight;
				}
			} else if (type.equals(HeaderType.SearchAdvance)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.color.header_scheme1_SearchAdvanced_hightLight;
				} else {
					return R.color.header_scheme2_SearchAdvanced_hightLight;
				}
			} else if (type.equals(HeaderType.ProfileSetting)) {
				return R.color.header_ProfileSetting;
			}
			return R.color.header_trasparent;
		} else {
			return R.color.header_trasparent;
		}
	}

	public static String getStringInLanguage(String tc, String sc) {
		String string = null;
		if (Language.CurrentLanguage == Language.TranditionalChinese) {
			string = tc;
		} else {
			string = sc;
		}
		return string;
	}

	public static String getWeekTxtByInt(int id) {
		switch (id) {
		case Calendar.SUNDAY:
			return "星期日";
		case Calendar.MONDAY:
			return "星期一";
		case Calendar.TUESDAY:
			return "星期二";
		case Calendar.WEDNESDAY:
			return "星期三";
		case Calendar.THURSDAY:
			return "星期四";
		case Calendar.FRIDAY:
			return "星期五";
		case Calendar.SATURDAY:
			return "星期六";
		}
		return null;
	}

	public static int getWeatherIcon(int code) {
		int id = R.drawable.weather_icons_50;
		switch (code) {
		case 50:
			id = R.drawable.weather_icons_50;
			break;
		case 51:
			id = R.drawable.weather_icons_51;
			break;
		case 52:
			id = R.drawable.weather_icons_52;
			break;
		case 53:
			id = R.drawable.weather_icons_53;
			break;
		case 54:
			id = R.drawable.weather_icons_54;
			break;
		case 60:
			id = R.drawable.weather_icons_60;
			break;
		case 61:
			id = R.drawable.weather_icons_61;
			break;
		case 62:
			id = R.drawable.weather_icons_62;
			break;
		case 63:
			id = R.drawable.weather_icons_63;
			break;
		case 64:
			id = R.drawable.weather_icons_64;
			break;
		case 65:
			id = R.drawable.weather_icons_65;
			break;
		case 76:
			id = R.drawable.weather_icons_76;
			break;
		case 77:
			id = R.drawable.weather_icons_77;
			break;
		case 80:
			id = R.drawable.weather_icons_80;
			break;
		case 81:
			id = R.drawable.weather_icons_81;
			break;
		case 82:
			id = R.drawable.weather_icons_82;
			break;
		case 83:
			id = R.drawable.weather_icons_83;
			break;
		case 84:
			id = R.drawable.weather_icons_84;
			break;
		case 85:
			id = R.drawable.weather_icons_85;
			break;
		case 90:
			id = R.drawable.weather_icons_90;
			break;
		case 91:
			id = R.drawable.weather_icons_91;
			break;
		case 92:
			id = R.drawable.weather_icons_92;
			break;
		case 93:
			id = R.drawable.weather_icons_93;
			break;
		}
		return id;
	}

	public static int getWeatherForecastIcon(int code) {
		int id = R.drawable.weather_forecast_50;
		switch (code) {
		case 50:
			id = R.drawable.weather_forecast_50;
			break;
		case 51:
			id = R.drawable.weather_forecast_51;
			break;
		case 52:
			id = R.drawable.weather_forecast_52;
			break;
		case 53:
			id = R.drawable.weather_forecast_53;
			break;
		case 54:
			id = R.drawable.weather_forecast_54;
			break;
		case 60:
			id = R.drawable.weather_forecast_60;
			break;
		case 61:
			id = R.drawable.weather_forecast_61;
			break;
		case 62:
			id = R.drawable.weather_forecast_62;
			break;
		case 63:
			id = R.drawable.weather_forecast_63;
			break;
		case 64:
			id = R.drawable.weather_forecast_64;
			break;
		case 65:
			id = R.drawable.weather_forecast_65;
			break;
		case 76:
			id = R.drawable.weather_forecast_76;
			break;
		case 77:
			id = R.drawable.weather_forecast_77;
			break;
		case 80:
			id = R.drawable.weather_forecast_80;
			break;
		case 81:
			id = R.drawable.weather_forecast_81;
			break;
		case 82:
			id = R.drawable.weather_forecast_82;
			break;
		case 83:
			id = R.drawable.weather_forecast_83;
			break;
		case 84:
			id = R.drawable.weather_forecast_84;
			break;
		case 85:
			id = R.drawable.weather_forecast_85;
			break;
		case 90:
			id = R.drawable.weather_forecast_90;
			break;
		case 91:
			id = R.drawable.weather_forecast_91;
			break;
		case 92:
			id = R.drawable.weather_forecast_92;
			break;
		case 93:
			id = R.drawable.weather_forecast_93;
			break;
		}
		return id;
	}

	public static int getWarningIcon(int code) {
		int id = R.drawable.weather_icons_1;
		switch (code) {
		case 1:
			id = R.drawable.weather_icons_1;
			break;
		case 2:
			id = R.drawable.weather_icons_2;
			break;
		case 3:
			id = R.drawable.weather_icons_3;
			break;
		case 4:
			id = R.drawable.weather_icons_4;
			break;
		case 5:
			id = R.drawable.weather_icons_5;
			break;
		case 6:
			id = R.drawable.weather_icons_6;
			break;
		case 7:
			id = R.drawable.weather_icons_7;
			break;
		case 8:
			id = R.drawable.weather_icons_8;
			break;
		case 9:
			id = R.drawable.weather_icons_9;
			break;
		case 10:
			id = R.drawable.weather_icons_10;
			break;
		case 11:
			id = R.drawable.weather_icons_11;
			break;
		case 12:
			id = R.drawable.weather_icons_12;
		case 13:
			id = R.drawable.weather_icons_13;
			break;
		case 14:
			id = R.drawable.weather_icons_14;
			break;
		case 15:
			id = R.drawable.weather_icons_15;
			break;
		case 16:
			id = R.drawable.weather_icons_16;
			break;
		case 17:
			id = R.drawable.weather_icons_17;
			break;
		case 18:
			id = R.drawable.weather_icons_18;
			break;
		case 19:
			id = R.drawable.weather_icons_19;
			break;
		case 20:
			id = R.drawable.weather_icons_20;
			break;
		case 21:
			id = R.drawable.weather_icons_21;
			break;
		}
		return id;
	}

	public static int getGuide(int index) {
		int id = 0;
		switch (index) {
		case 1:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide01_sc;
			} else {
				id = R.drawable.guide01_tc;
			}
			break;
		case 2:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide02_sc;
			} else {
				id = R.drawable.guide02_tc;
			}
			break;
		case 3:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide03_sc;
			} else {
				id = R.drawable.guide03_tc;
			}
			break;
		case 4:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide04_sc;
			} else {
				id = R.drawable.guide04_tc;
			}
			break;
		case 5:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide05_sc;
			} else {
				id = R.drawable.guide05_tc;
			}
			break;
		case 6:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide06_sc;
			} else {
				id = R.drawable.guide06_tc;
			}
			break;
		case 7:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide07_sc;
			} else {
				id = R.drawable.guide07_tc;
			}
			break;
		case 8:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide08_sc;
			} else {
				id = R.drawable.guide08_tc;
			}
			break;
		case 9:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide09_sc;
			} else {
				id = R.drawable.guide09_tc;
			}
			break;
		case 10:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide10_sc;
			} else {
				id = R.drawable.guide10_tc;
			}
			break;
		case 11:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide11_sc;
			} else {
				id = R.drawable.guide11_tc;
			}
			break;
		case 13:
			if (Language.CurrentLanguage == Language.Chinese) {
				id = R.drawable.guide13_sc;
			} else {
				id = R.drawable.guide13_tc;
			}
			break;
		}
		return id;
	}

	/**
	 * 获得group indicator drawable
	 * 
	 * @param type
	 * @param isUp
	 * @return
	 * @author jianfeng.lao
	 * @CreateDate 2013-9-13
	 */
	public static int getGroupIndicatorByHeaderType(HeaderType type, boolean isUp) {
		int id = 0;
		if (type.equals(HeaderType.FavoriteCenter)) {
			if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
				if (isUp) {
					id = R.drawable.btn_blue_down;
				} else {
					id = R.drawable.btn_blue_up;
				}
			} else {

				if (isUp) {
					id = R.drawable.btn_heavy_green_down;
				} else {
					id = R.drawable.btn_heavy_green_up;
				}

			}
		} else if (type.equals(HeaderType.MyActivity)) {
			if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
				if (isUp) {
					id = R.drawable.btn_green_down;
				} else {
					id = R.drawable.btn_green_up;
				}
			} else {
				if (isUp) {
					id = R.drawable.btn_heavy_blue_down;
				} else {
					id = R.drawable.btn_heavy_blue_up;
				}
			}
		} else if (type.equals(HeaderType.SearchNear)) {
			if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
				if (isUp) {
					id = R.drawable.btn_yellow_down;
				} else {
					id = R.drawable.btn_yellow_up;
				}
			} else {
				if (isUp) {
					id = R.drawable.btn_heavy_yellow_down;
				} else {
					id = R.drawable.btn_heavy_yellow_up;
				}
			}
		} else if (type.equals(HeaderType.SearchEasy)) {
			if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
				if (isUp) {
					id = R.drawable.btn_orange_down;
				} else {
					id = R.drawable.btn_orange_up;
				}
			} else {
				if (isUp) {
					id = R.drawable.btn_heavy_orange_down;
				} else {
					id = R.drawable.btn_heavy_orange_up;
				}
			}
		} else if (type.equals(HeaderType.SearchAdvance)) {
			if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
				if (isUp) {
					id = R.drawable.btn_purple_down;
				} else {
					id = R.drawable.btn_purple_up;
				}
			} else {
				if (isUp) {
					id = R.drawable.btn_heavy_purple_down;
				} else {
					id = R.drawable.btn_heavy_purple_up;
				}
			}
		}
		return id;
	}

	public static int getArBackGound(HeaderType type) {
		if (type != null && ColorTheme.CurrentColorTheme != null) {
			if (type.equals(HeaderType.NewsActivity)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.drawable.txt_box02_red;
				} else {
					return R.drawable.txt_box02_heavy_red;
				}
			} else if (type.equals(HeaderType.FavoriteCenter)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.drawable.txt_box02_blue;
				} else {
					return R.drawable.txt_box02_heavy_green;
				}
			} else if (type.equals(HeaderType.MyActivity)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.drawable.txt_box02_green;
				} else {
					return R.drawable.txt_box02_heavy_blue;
				}
			} else if (type.equals(HeaderType.SearchNear)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.drawable.txt_box02_yellow;
				} else {
					return R.drawable.txt_box02_heavy_yellow;
				}
			} else if (type.equals(HeaderType.SearchEasy)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.drawable.txt_box02_orange;
				} else {
					return R.drawable.txt_box02_heavy_orange;
				}
			} else if (type.equals(HeaderType.SearchAdvance)) {
				if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
					return R.drawable.txt_box02_purple;
				} else {
					return R.drawable.txt_box02_heavy_purple;
				}
			} else if (type.equals(HeaderType.ProfileSetting)) {
				return R.color.header_ProfileSetting;
			}
			return R.drawable.txt_box02_red;
		} else {
			return R.drawable.txt_box02_red;
		}
	}

	// ////////////////GA CONSTANT
	public static final String SPLASH_SCREEN = "pg_SplashScreen";

	public static final String MAIN_PAGE_PG_MAINPAGE = "pg_MainPage";
	public static final String MAIN_PAGE_PHOTOBUTTON = "PhotoButton";
	public static final String MAIN_PAGE_WEATHERFORECASTBUTTON = "WeatherForecastButton";
	public static final String MAIN_PAGE_BANNER = "Banner";
	public static final String MAIN_PAGE_LATESTACTIVITYBUTTON = "LatestActivityButton";
	public static final String MAIN_PAGE_FAVOURITECENTERBUTTON = "FavouriteCenterButton";
	public static final String MAIN_PAGE_MYACTIVITYBUTTON = "MyActivityButton";
	public static final String MAIN_PAGE_SEARCHNEARBYBUTTON = "SearchNearbyButton";
	public static final String MAIN_PAGE_EASYSEARCHBUTTON = "EasySearchButton";
	public static final String MAIN_PAGE_ADVANCEDSEARCHBUTTON = "AdvancedSearchButton";
	public static final String MAIN_PAGE_SETTINGBUTTON = "SettingButton";

	public static final String NEWS_ACTIVITY_PG_LATESTACTIVITY = "pg_LatestActivity";
	public static final String NEWS_ACTIVITY_LCSDBUTTON = "LCSDButton";
	public static final String NEWS_ACTIVITY_ELDERCENTERBUTTON = "ElderCenterButton";
	public static final String NEWS_ACTIVITY_BANNER = "Banner";

	public static final String DETAIL_PG_ACTIVITYDETAIL_ACTIVITYNUMBER_ACTIVITYTITLE = "pg_ActivityDetail_ActivityNumber_ActivityTitle";
	public static final String DETAIL_BANNER = "Banner";
	public static final String DETAIL_ADDBUTTON = "AddButton";
	public static final String DETAIL_SHAREBUTTON = "ShareButton";
	public static final String SHARE_ACTIVITYDETAILSHARE = "ActivityDetailShare";
	public static final String DETAIL_MAPBUTTON = "MapButton";
	public static final String MAP_ARBUTTON = "ARButton";
	public static final String MAP_PIN = "Pin";
	public static final String MAP_CURRENTLOCATIONBUTTON = "CurrentLocationButton";
	public static final String MAP_ACTIVITYDETAILBUTTON = "ActivityDetailButton";

	public static final String FAV_PG_FAVOURITECENTER = "pg_FavouriteCenter";
	public static final String FAV_DATE = "Date";

	public static final String MY_PG_MYACTIVITY = "pg_MyActivity";
	public static final String MY_DATE = "Date";

	public static final String NEAR_PG_SEARCHNEARBY = "pg_SearchNearby";
	public static final String NEAR_CURRENTLOCATIONBUTTON = "CurrentLocationButton";
	public static final String NEAR_LIVINGLOCATIONBUTTON = "LivingLocationButton";
	public static final String NEAR_SELECTDISTANCEBUTTON = "SelectDistanceButton";

	public static final String EASY_PG_EASYSEARCH = "pg_EasySearch";
	public static final String EASY_SEARCHBUTTON = "SearchButton";

	public static final String ADV_PG_ADVANCEDSEARCH = "pg_AdvancedSearch";
	public static final String ADV_ACTIVITYTYPE = "ActivityType";
	public static final String ADV_ACTIVITYLOCATION = "ActivityLocation";
	public static final String ADV_ORGANIZATION = "Organization";
	public static final String ADV_DATE = "Date";
	public static final String ADV_AGE = "Age";
	public static final String ADV_PRICE = "Price";
	public static final String ADV_KEYWORD = "Keyword";
	public static final String ADV_SEARCHBUTTON = "SearchButton";
	public static final String ADV_HOTKEY = "Hotkey";

	public static final String SETTING_PG_SETTING = "pg_Setting";
	public static final String SETTING_SMALLFONTSIZE = "SmallFontSize";
	public static final String SETTING_MEDIUMFONTSIZE = "MediumFontSize";
	public static final String SETTING_LARGEFONTSIZE = "LargeFontSize";
	public static final String SETTING_TRADITIONALCHINESE = "TraditionalChinese";
	public static final String SETTING_SIMPLIFIEDCHINESE = "SimplifiedChinese";
	public static final String SETTING_COLOUR1 = "Colour1";
	public static final String SETTING_COLOUR2 = "Colour2";

	public static final String GA_ACTION_CLICK = "click";
	public static final String GA_ACTION_FACEBOOK = "facebook";
	public static final String GA_ACTION_WEIBO = "weibo";
	public static final String GA_ACTION_TWITTER = "twitter";
	public static final String GA_ACTION_WHATSAPP = "whatsapp";
	public static final String GA_ACTION_SMS = "sms";
	public static final String GA_ACTION_EMAIL = "email";
	// ////////////////GA CONSTANT

}
