package com.elderly.elderly.adapter;

import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;

import com.elderly.elderly.Constants;
import com.elderly.elderly.component.ElderlyWeatherForecastCell;
import com.elderly.elderly.pojo.ao.WeatherAO;
import com.elderly.elderly.pojo.ao.WeatherAO.ForecastWeather;
import com.gt.cl.util.CLDateUtil;

public class WeatherForecastAdapter extends BaseAdapter {
	private static final String TAG = "WeatherForecastAdapter";
	private Context mContext;
	private WeatherAO mWeatherAO;
	private Calendar mCalendar;

	public WeatherForecastAdapter(Context mContext) {
		super();
		this.mContext = mContext;
		mCalendar = Calendar.getInstance();
	}

	public void setWeatherAO(WeatherAO mWeatherAO) {
		this.mWeatherAO = mWeatherAO;
		Log.v(TAG, "size>>" + mWeatherAO.getWeatherList().size());
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return mWeatherAO != null && mWeatherAO.getWeatherList() != null ? mWeatherAO.getWeatherList().size() : 0;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ElderlyWeatherForecastCell cell = null;
		if (convertView == null) {
			cell = new ElderlyWeatherForecastCell(mContext);
			AbsListView.LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			cell.setLayoutParams(lp);
		} else {
			cell = (ElderlyWeatherForecastCell) convertView;
		}
		ForecastWeather ao = mWeatherAO.getWeatherList().get(position);
		int iconId = Constants.getWeatherForecastIcon(Integer.parseInt(ao.getCode()));
		cell.getImgVWeatherIcon().setImageResource(iconId);
		String date="";
		Date dateTime=CLDateUtil.formatDate(ao.getDate(), "yyyy-MM-dd");
		mCalendar.setTime(dateTime);
		date=CLDateUtil.formatDate(dateTime, "MM月dd日");
		date+=" ("+Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK))+")";
		cell.getTxtDate().setText(date);
		String status=ao.getMinTemperature()+" - "+ao.getMaxTemperature()+"° "+ao.getName();
		cell.getTxtWeatherStatus().setText(status);
		return cell;
	}

}
