package com.elderly.elderly.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.elderly.elderly.component.ElderlyMyInterestCell;

import java.util.List;

public class SearchOptionAdapter extends BaseAdapter {
    private Context mContext;
    private List<String> keys;

    int selected;

    public SearchOptionAdapter(Context mContext) {
        super();
        this.mContext = mContext;

    }


    public void seData(List<String> keys, int selected) {
        this.keys = keys;
        this.selected = selected;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return keys != null ? keys.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
       ElderlyMyInterestCell cell = null;
        if (convertView == null) {
            cell = new ElderlyMyInterestCell(mContext);
        } else {
            cell = (ElderlyMyInterestCell) convertView;
        }


        String key = keys.get(position);
        cell.getTxtTitle().setText(key);
        cell.setTag(key);

            if(position==selected){
                cell.getIcon().setSelected(true);
            }else{
                cell.getIcon().setSelected(false);
            }




        cell.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                if(position!=selected) {
                    selected = position;
                }
                notifyDataSetChanged();

            }
        });

        return cell;
    }

	public int getSelected() {
		return selected;
	}

}
