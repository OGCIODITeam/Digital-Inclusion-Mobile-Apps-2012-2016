package com.elderly.elderly.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.R;
import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.component.ElderlyActivityCell;
import com.elderly.elderly.component.ElderlyGroupCell;
import com.elderly.elderly.fragment.search.SearchResultFragment;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.ActivityCenterAO;
import com.gt.cl.util.CLDateUtil;

import java.util.Date;
import java.util.List;

public class SearchResultAdapter extends BaseExpandableListAdapter {

	private Context mContext;
	private HeaderType mHeaderType;
	private List<ActivityCenterAO> mActivityCenterAOs;
	private Date mCurrentApiDate;
	private ExpandableListView mListView;

	public SearchResultAdapter(Context mContext, HeaderType mHeaderType,ExpandableListView listView) {
		super();
		this.mContext = mContext;
		this.mHeaderType = mHeaderType;
		this.mListView = listView;
	}

	public void setData(List<ActivityCenterAO> mActivityCenterAOs, Date mCurrentApiDate) {
		this.mActivityCenterAOs = mActivityCenterAOs;
		this.mCurrentApiDate = mCurrentApiDate;
		notifyDataSetChanged();
	}

	public void addData(List<ActivityCenterAO> mActivityCenterAOs) {
		if (mActivityCenterAOs != null) {
			this.mActivityCenterAOs.addAll(mActivityCenterAOs);
		}
		notifyDataSetChanged();
	}

	@Override
	public int getGroupCount() {
		return mActivityCenterAOs != null ? mActivityCenterAOs.size() : 0;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		int count = 0;
		if (mActivityCenterAOs != null) {
			if (mActivityCenterAOs.get(groupPosition).getActivityList() != null) {
				return mActivityCenterAOs.get(groupPosition).getActivityList().size();
			}
		}
		return count;
	}

	@Override
	public Object getGroup(int groupPosition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		ActivityAO ao = null;
		if (mActivityCenterAOs != null) {
			if (mActivityCenterAOs.get(groupPosition).getActivityList() != null) {
				mActivityCenterAOs.get(groupPosition).getActivityList().get(childPosition);
			}
		}
		return ao;
	}

	@Override
	public long getGroupId(int groupPosition) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		Log.i("test", "nimei adapter");
		ElderlyGroupCell cell = null;
		if (convertView == null) {
			cell = new ElderlyGroupCell(mContext);
		} else {
			cell = (ElderlyGroupCell) convertView;
		}
		ActivityCenterAO ao = mActivityCenterAOs.get(groupPosition);
		String temp = "";
		if (ao.getOrganization() == null || "".equals(ao.getOrganization())) {
			temp = ao.getActivityCenterName();
		} else if (ao.getActivityCenterName() == null || "".equals(ao.getActivityCenterName())) {
			temp = ao.getOrganization();
		} else {
			temp = ao.getOrganization() + "\n" + ao.getActivityCenterName();
		}
		cell.getTxtTitle().setText(temp);
		cell.setBackgroundColor(mContext.getResources().getColor(Constants.getSchemeColorIdByHeaderType(mHeaderType)));
		cell.getImgVArrow().setImageResource(Constants.getGroupIndicatorByHeaderType(mHeaderType, !isExpanded));
		cell.setClickable(false);
		if (isExpanded) {
			cell.getImgVArrow().setContentDescription("收起");
//			cell.getImgVArrow().setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View v) {
//					mListView.collapseGroup(groupPosition);
//				}
//			});
		} else {
			cell.getImgVArrow().setContentDescription("展开");
//			cell.getImgVArrow().setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View v) {
//					mListView.expandGroup(groupPosition);
//				}
//			});
		}
		return cell;
	}

	@Override
	public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, final View convertView, ViewGroup parent) {
		List<ActivityAO> data = mActivityCenterAOs.get(groupPosition).getActivityList();
		ActivityAO ao = null;
		if (data != null) {
			ao = data.get(childPosition);
		}
		final ElderlyActivityCell cell;
		if (convertView == null) {
			cell = new ElderlyActivityCell(mContext);
		} else {
			cell = (ElderlyActivityCell) convertView;
		}
		cell.getTxtTitle().setText(ao.getTitle());
		cell.setBtnMoreContentDescription(mContext.getString(R.string.voice_page_btn_more, ao.getTitle()),new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ActivityAO ao = mActivityCenterAOs.get(groupPosition).getActivityList().get(childPosition);
				((SearchResultFragment)((MainActivity)mContext).getNavigationFragment().getCurrentFragment()).callActivityDetailApi(ao.getId());
			}
		});
		if (ao.getEventType() != null) {
			cell.getTxtActivityType().setText(mContext.getString(R.string.page_activity_type, ao.getEventType()));
		} else {
			cell.getTxtActivityType().setText(mContext.getString(R.string.page_activity_type, mContext.getString(R.string.page_search_adv_activity_other)));
		}

		String[] tempDate = null;
		String date = null;
		String endDate = null;
		if (ao.getDate() != null) {
			tempDate = ao.getDate().split(",");
		}
		if (tempDate != null && tempDate.length > 0) {
			date = tempDate[0];
			endDate = tempDate[tempDate.length - 1];
		}

		if (date != null) {
			date = CLDateUtil.formatDate(date, Constants.DATE_FORMAT_PATTERN_API, Constants.DATE_FORMAT_PATTERN_SHOW);
		}
		if (endDate != null) {
			endDate = CLDateUtil.formatDate(endDate, Constants.DATE_FORMAT_PATTERN_API, Constants.DATE_FORMAT_PATTERN_SHOW);
		}
		if (date != null && !"".equals(date)) {
			if (endDate != null && !"".equals(endDate)) {
				date += "-";
				date += endDate;
			}
		} else {
			if (endDate != null && !"".equals(endDate)) {
				date = endDate;
			} else {
				date = "";
			}
		}

		cell.getTxtDate().setText(mContext.getString(R.string.page_activity_date, date));

		cell.getTxtCost().setVisibility(View.GONE);
		if (ao.getFee() != null) {
			try {
				if (Double.valueOf(ao.getFee()) == 0) {
					cell.getTxtCost().setText(mContext.getResources().getString(R.string.page_activity_fee_no));
				} else {
					cell.getTxtCost().setText(mContext.getResources().getString(R.string.page_activity_fee, ao.getFee()));
				}
			} catch (Exception e) {
				cell.getTxtCost().setText(mContext.getResources().getString(R.string.page_activity_fee_nomark, ao.getFee()));
			}
		}
		// else{
		// cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee, ""));
		// }

        String voiceLabel="";
        if (ao.getStartTime() != null && ao.getEndTime() != null) {
            voiceLabel=
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime()));
            cell.getTxtTime().setText(
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime())));
        } else {
            if (ao.getStartTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime()));
            } else if (ao.getEndTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime()));
            }
        }
        cell.getTxtTime().setContentDescription(voiceLabel+"按钮");
		return cell;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	public void release() {
		if (mActivityCenterAOs != null) {
			mActivityCenterAOs.clear();
			mActivityCenterAOs = null;
		}
	}

}
