package com.elderly.elderly.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.elderly.elderly.Constants;
import com.elderly.elderly.fragment.BrowseFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.ao.BannerAO;
import com.elderly.elderly.util.ElderlyUtil;
import com.gt.cl.component.imageview.bitmapview.CLBitmapView;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo;

import java.util.List;

import lib.gt.ga.v2.GAManager;

public class BannerPagerAdapter extends PagerAdapter {
	private static final String TAG = "BannerPagerAdapter";
	private Context mContext;
	private List<BannerAO> mData;
	private TempleteFragment mTempleteFragment;
	private boolean isClick;

	public BannerPagerAdapter(Context mContext, TempleteFragment tf) {
		super();
		this.mContext = mContext;
		mTempleteFragment = tf;
	}

	@Override
	public int getCount() {
		return mData != null ? mData.size() : 0;
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {
		return view == object;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		container.removeView((View) object);
		if (object instanceof CLBitmapView) {
			((CLBitmapView) (object)).unRegisterBitmapInfoListener();
		}
	}

	@Override
	public Object instantiateItem(ViewGroup container, final int position) {
		CLBitmapView view = new CLBitmapView(mContext);
		String url = Constants.API_IMAGE + "?path=" + mData.get(position).getImage() + "&width="
				+ mContext.getResources().getDisplayMetrics().widthPixels;
		Log.v(TAG, "url>>" + url);
		String filePath = Constants.PATH_LOCAL_IMAGE_LIBRARY + ElderlyUtil.toMd5(url.getBytes());
		CLBitmapInfo.Options options = new CLBitmapInfo.Options();
		options.getMothedDownload = true;
		view.setBitmapInfo(url, url, filePath, options);
		container.addView(view);
		view.loadImageOneByOne();
        Log.d("bannerstring",mData.get(position).getTitle());
		view.setContentDescription(mData.get(position).getTitle());
		view.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mData.get(position).getLink() != null && !isClick) {
					GAManager.getInstance().trackEvent(Constants.NEWS_ACTIVITY_BANNER, Constants.GA_ACTION_CLICK, mData.get(position).getId());
					if (onMyItemClick != null) {
						onMyItemClick.onMyItemClick();
					}
					BrowseFragment bf = new BrowseFragment();
					Bundle bundle = new Bundle();
					bundle.putString(TempleteFragment.HEADER_TYPE,
							mTempleteFragment.getHeaderType() != null ? mTempleteFragment
									.getHeaderType().name() : null);
					bundle.putString(BrowseFragment.KEY_STORE_URL, mData.get(position).getLink());
					bf.setArguments(bundle);
					mTempleteFragment.getTabNavigationFragment().push(bf);
				}

			}
		});
		return view;
	}

	public void setData(List<BannerAO> mData) {
		this.mData = mData;
		notifyDataSetChanged();
	}

	public void release() {
		if (mData != null) {
			mData.clear();
			mData = null;
		}
		mContext = null;
	}

	public interface OnMyItemClickListener {
		public void onMyItemClick();
	}

	OnMyItemClickListener onMyItemClick;

	public void setOnMyItemClickListener(OnMyItemClickListener onMyItemClick) {
		this.onMyItemClick = onMyItemClick;
	}

	public void setIsClick(boolean isClick) {
		this.isClick = isClick;
	}
}
