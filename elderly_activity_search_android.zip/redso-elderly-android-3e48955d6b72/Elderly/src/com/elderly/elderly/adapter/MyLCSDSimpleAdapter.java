package com.elderly.elderly.adapter;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.component.ElderlyActivityCell;
import com.elderly.elderly.fragment.search.SearchResultFragment;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.gt.cl.util.CLDateUtil;

import java.util.Date;
import java.util.List;

// import com.elderly.elderly.Constants;

public class MyLCSDSimpleAdapter extends BaseAdapter {

	private Context mContext;
	private List<ActivityAO> mData;
	private Date mCurrentApiDate;

	public MyLCSDSimpleAdapter(Context mContext) {
		super();
		this.mContext = mContext;
	}

	public void setData(List<ActivityAO> mData, Date date) {
		this.mCurrentApiDate = date;
		this.mData = mData;
		notifyDataSetChanged();
	}

	public void addData(List<ActivityAO> mData) {
		if (mData != null) {
			this.mData.addAll(mData);
		}
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData != null ? mData.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ElderlyActivityCell cell = null;
		if (convertView == null) {
			cell = new ElderlyActivityCell(mContext);
		} else {
			cell = (ElderlyActivityCell) convertView;
		}
		ActivityAO ao = mData.get(position);
		cell.getTxtActivityArea().setVisibility(View.VISIBLE);
		cell.getTxtTitle().setText(ao.getTitle());
		cell.setBtnMoreContentDescription(mContext.getString(R.string.voice_page_btn_more, ao.getTitle()),new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ActivityAO ao = mData.get(position);
				((SearchResultFragment)((MainActivity)mContext).getNavigationFragment().getCurrentFragment()).callActivityDetailApi(ao.getId());
			}
		});
		cell.getTxtActivityType().setVisibility(View.GONE);

		String date = null;
		String endDate = null;
		if (ao.getDate() != null) {
			date = CLDateUtil.formatDate(ao.getDate(), Constants.DATE_FORMAT_PATTERN_API, Constants.DATE_FORMAT_PATTERN_SHOW);
		}
		if (ao.getEndDate() != null) {
			endDate = CLDateUtil.formatDate(ao.getEndDate(), Constants.DATE_FORMAT_PATTERN_API, Constants.DATE_FORMAT_PATTERN_SHOW);
		}
		if (date != null && !"".equals(date)) {
			if (endDate != null && !"".equals(endDate)) {
				date += "-";
				date += endDate;
			}
		} else {
			if (endDate != null && !"".equals(endDate)) {
				date = endDate;
			} else {
				date = "";
			}
		}

		cell.getTxtDate().setText(mContext.getString(R.string.page_activity_date, date));

		setCostText(cell.getTxtCost(), ao);


		if (ao.getActiveArea() != null) {
			cell.getTxtActivityArea().setText(mContext.getResources().getString(R.string.page_activity_area, ao.getActiveArea()));
		} else {
			cell.getTxtActivityArea().setText(mContext.getResources().getString(R.string.page_activity_area, ""));
		}

        String voiceLabel="";
        if (ao.getStartTime() != null && ao.getEndTime() != null) {
            voiceLabel=
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime()));
            cell.getTxtTime().setText(
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime())));
        } else {
            if (ao.getStartTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime()));
            } else if (ao.getEndTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime()));
            }
        }
        cell.getTxtTime().setContentDescription(voiceLabel+"按钮");
		return cell;
	}

	private void setCostText(TextView txtCost, ActivityAO ao) {
		if (ao.getFee() != null) {
			try {
				if (Double.valueOf(ao.getFee()) == 0) {
					txtCost.setText(mContext.getString(R.string.page_activity_fee_no));
				} else {
					txtCost.setText(mContext.getString(R.string.page_activity_fee, ao.getFee()));
				}
			} catch (Exception e) {
				txtCost.setText(mContext.getString(R.string.page_activity_fee_nomark, ao.getFee()));
			}
			return;
		}
		if (ao.getMemberFee() != null) {
			try {
				if (Double.valueOf(ao.getMemberFee()) == 0) {
					txtCost.setText(mContext.getString(R.string.page_activity_memfee_no));
				} else {
					txtCost.setText(mContext.getString(R.string.page_activity_memfee, ao.getMemberFee()));
				}
			} catch (Exception e) {
				txtCost.setText(mContext.getString(R.string.page_activity_memfee_nomark, ao.getMemberFee()));
			}
			return;
		}
		if (ao.getNonmemberFee() != null) {
			try {
				if (Double.valueOf(ao.getNonmemberFee()) == 0) {
					txtCost.setText(mContext.getString(R.string.page_activity_no_memfee_no));
				} else {
					txtCost.setText(mContext.getString(R.string.page_activity_no_memfee, ao.getNonmemberFee()));
				}
			} catch (Exception e) {
				txtCost.setText(mContext.getString(R.string.page_activity_no_memfee_nomark, ao.getNonmemberFee()));
			}
			return;
		}
	}

}
