package com.elderly.elderly.adapter;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.elderly.elderly.component.ElderlyMyInterestCell;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;

import java.util.List;

public class MyInterestAdapter extends BaseAdapter {
	private Context mContext;
	private List<ActivityCategoryPo> mDatas;
	private List<ActivityCategoryPo> mHightLightDatas;
    int selected;
	public MyInterestAdapter(Context mContext) {
		super();
		this.mContext = mContext;
		mDatas = UserProfileManager.getInstance().getAllInterestList();
		mHightLightDatas = UserProfileManager.getInstance().getMyInterestList();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDatas != null ? mDatas.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ElderlyMyInterestCell cell = null;
		if (convertView == null) {
			cell = new ElderlyMyInterestCell(mContext);
		} else {
			cell = (ElderlyMyInterestCell) convertView;
		}
		ActivityCategoryPo po = mDatas.get(position);
		cell.getTxtTitle().setText(po.getName());
		cell.setTag(po);

		cell.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (v.getTag() != null && v.getTag() instanceof ActivityCategoryPo) {
					if (mHightLightDatas.contains(v.getTag())) {
						mHightLightDatas.remove(v.getTag());
					} else if (!mHightLightDatas.contains(v.getTag())) {
						mHightLightDatas.add((ActivityCategoryPo) v.getTag());
                        selected = position;
                    }
					notifyDataSetChanged();
				}
			}
		});
		if (mHightLightDatas.contains(po)) {
			cell.getIcon().setSelected(true);
            selected = position;
		} else {
			cell.getIcon().setSelected(false);
		}
		return cell;
	}

	public List<ActivityCategoryPo> getHightLightDatas() {
		return mHightLightDatas;
	}

    public int getSelected() {
        return selected;
    }

}
