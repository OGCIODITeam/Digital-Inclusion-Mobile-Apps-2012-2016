package com.elderly.elderly.adapter;

import java.util.List;

import kankan.wheel.widget.adapters.AbstractWheelTextAdapter;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;

import com.elderly.elderly.R;
import com.elderly.elderly.pojo.po.LocationPo;
import com.elderly.elderly.util.ElderlyUtil;

public class WheelTextAdapter extends AbstractWheelTextAdapter {

	private Object[] mData;
	private Object[] mDataContentDescription;

	protected int mSelectedIndex;

	public WheelTextAdapter(Context context) {
		super(context);
	}

	public void setData(List<?> data) {
		mData = data.toArray();
	}

	public void setData(Object[] data) {
		mData = data;
	}

	public void setDataContentDescription(Object[] mDataContentDescription) {
		this.mDataContentDescription = mDataContentDescription;
	}

	@Override
	public int getItemsCount() {
		return mData == null ? 0 : mData.length;
	}

	@Override
	public View getItem(int index, View convertView, ViewGroup parent) {
		TextView textView = null;
		if (convertView == null) {
			textView = new TextView(context);
			textView.setGravity(Gravity.CENTER);
			int padding = (int) ElderlyUtil.dip2px(context, 8);
			int height = (int) context.getResources().getDimension(R.dimen.view_simple_wheel_item_height);
			textView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, height));
			textView.setPadding(0, padding, 0, padding);
		}
		else {
			textView = (TextView) convertView;
		}
		textView.setTextAppearance(context, mSelectedIndex == index ? R.style.simple_wheel_item_select
				: R.style.simple_wheel_item_unSelect);
		textView.setText(getItemText(index));
		textView.setTextColor(mSelectedIndex == index ? Color.BLACK : 0xff959595);
		textView.setTag(mData[index]);
		textView.setClickable(true);
		textView.setContentDescription(getItemContentDescription(index));
		return textView;
	}

	@Override
	public CharSequence getItemText(int index) {
		if (index >= 0 && index < getItemsCount()) {
			Object item = mData[index];
			if (item instanceof CharSequence) {
				return (CharSequence) item;
			} else if (item instanceof LocationPo) {
				return ((LocationPo) item).getName();
			}
		}
		return null;
	}

	public CharSequence getItemContentDescription(int index) {
		if (mDataContentDescription == null) {
			return getItemText(index);
		}
		if (index >= 0 && index < getItemsCount()) {
			Object item = mDataContentDescription[index];
			if (item instanceof CharSequence) {
				return (CharSequence) item;
			} else if (item instanceof LocationPo) {
				return ((LocationPo) item).getName();
			}
		}
		return null;
	}

	public Object getData(int index) {
		if (index >= 0 && index < getItemsCount()) {
			return mData[index];
		} else {
			return null;
		}
	}

	public void setSelectedIndex(int index) {
		mSelectedIndex = index;
		notifyDataChangedEvent();
	}

	public void release() {
		if (mData != null) {
			mData = null;
		}
		context = null;
	}

}
