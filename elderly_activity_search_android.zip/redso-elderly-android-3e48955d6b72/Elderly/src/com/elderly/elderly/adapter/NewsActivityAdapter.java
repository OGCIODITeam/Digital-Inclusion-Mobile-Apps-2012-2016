package com.elderly.elderly.adapter;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.component.ElderlyLastActivityCell;
import com.elderly.elderly.component.ElderlyListView;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.gt.cl.util.CLDateUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class NewsActivityAdapter extends BaseAdapter {
	private Context mContext;
	private List<ActivityAO> mData;
	private Calendar mCalendar;
	private ElderlyListView mListView;
	private String mApiType;

	public NewsActivityAdapter(Context mContext,ElderlyListView listView) {
		super();
		this.mContext = mContext;
		mCalendar = Calendar.getInstance();
		this.mListView = listView;
	}
	
	public void setApiType(String apiType){
		this.mApiType = apiType;
	}

	@Override
	public int getCount() {
		return mData != null && mData.size() > 0 ? mData.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ElderlyLastActivityCell cell = null;
		if (convertView == null || !(convertView instanceof ElderlyLastActivityCell)) {
			cell = new ElderlyLastActivityCell(mContext);
			AbsListView.LayoutParams lp = new AbsListView.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			cell.setLayoutParams(lp);
		} else {
			cell = (ElderlyLastActivityCell) convertView;
		}
		ActivityAO ao = mData.get(position);
		cell.getTxtTitle().setText(ao.getTitle());
		cell.getBtnMore().setContentDescription(mContext.getString(R.string.voice_page_btn_more, ao.getTitle()));
		cell.getBtnMore().setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ActivityAO ao = mData.get(position);
				((TempleteFragment)((MainActivity)mContext).getNavigationFragment().getCurrentFragment()).callActivityDetailApi(ao.getId(),mApiType);
			}
		});
		if (ao.getDate() != null) {
			String dates[] = ao.getDate().split(",");
			if (dates.length > 0) {
				Date date = CLDateUtil.formatDate(dates[0], Constants.DATE_FORMAT_PATTERN_API);
				mCalendar.setTime(date);
				String day = CLDateUtil.formatDate(date, Constants.DATE_FORMAT_PATTERN_SHOW);
				String week = Constants.getWeekTxtByInt(mCalendar.get(Calendar.DAY_OF_WEEK));
				cell.getTxtDate().setText(day + " (" + week + ")");
			}
		}
		cell.getTxtLocation().setText(ao.getActiveArea());
		setCostText(cell.getTxtCost(), ao);
		return cell;
	}

	public void setData(List<ActivityAO> mData) {
		this.mData = mData;
		notifyDataSetChanged();
	}

	public void addData(List<ActivityAO> mData) {
		this.mData.addAll(mData);
		notifyDataSetChanged();
	}

	public void release() {
		if (mData != null) {
			mData.clear();
			mData = null;
		}
		mContext = null;
	}

	private void setCostText(TextView txtCost, ActivityAO ao) {
        String voiceLabel="";
		if (ao.getFee() != null) {
			try {
				if (Double.valueOf(ao.getFee()) == 0) {
                    voiceLabel=mContext.getString(R.string.page_activity_fee_no);
					txtCost.setText(mContext.getString(R.string.page_activity_fee_no));
				} else {
                    voiceLabel=mContext.getString(R.string.page_activity_fee, ao.getFee());
					txtCost.setText(mContext.getString(R.string.page_activity_fee, ao.getFee()));
				}
			} catch (NumberFormatException e) {
                voiceLabel=mContext.getString(R.string.page_activity_fee_nomark, ao.getFee());
				txtCost.setText(mContext.getString(R.string.page_activity_fee_nomark, ao.getFee()));
			}
            txtCost.setContentDescription(voiceLabel+"按钮");
			return;
		}
		if (ao.getMemberFee() != null) {
			try {
				if (Double.valueOf(ao.getMemberFee()) == 0) {
                    voiceLabel=mContext.getString(R.string.page_activity_memfee_no);

                    txtCost.setText(mContext.getString(R.string.page_activity_memfee_no));
				} else {
                    voiceLabel=mContext.getString(R.string.page_activity_memfee, ao.getMemberFee());

                    txtCost.setText(mContext.getString(R.string.page_activity_memfee, ao.getMemberFee()));
				}
			} catch (NumberFormatException e) {
                voiceLabel=mContext.getString(R.string.page_activity_memfee_nomark, ao.getMemberFee());

                txtCost.setText(mContext.getString(R.string.page_activity_memfee_nomark, ao.getMemberFee()));
			}
            txtCost.setContentDescription(voiceLabel+"按钮");


            return;
		}
		if (ao.getNonmemberFee() != null) {
			try {
				if (Double.valueOf(ao.getNonmemberFee()) == 0) {
                    voiceLabel=mContext.getString(R.string.page_activity_no_memfee_no);

                    txtCost.setText(mContext.getString(R.string.page_activity_no_memfee_no));
				} else {
                    voiceLabel=mContext.getString(R.string.page_activity_no_memfee, ao.getNonmemberFee());

                    txtCost.setText(mContext.getString(R.string.page_activity_no_memfee, ao.getNonmemberFee()));
				}
			} catch (NumberFormatException e) {
                voiceLabel=mContext.getString(R.string.page_activity_no_memfee_nomark, ao.getNonmemberFee());

                txtCost.setText(mContext.getString(R.string.page_activity_no_memfee_nomark, ao.getNonmemberFee()));
			}
            txtCost.setContentDescription(voiceLabel+"按钮");

            return;
		}
		txtCost.setText(" ");
        txtCost.setContentDescription(" " +"按钮");
	}
}
