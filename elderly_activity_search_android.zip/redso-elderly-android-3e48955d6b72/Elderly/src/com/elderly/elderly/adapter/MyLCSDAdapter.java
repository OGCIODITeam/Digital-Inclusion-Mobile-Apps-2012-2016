package com.elderly.elderly.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.elderly.elderly.Constants;
import com.elderly.elderly.R;
import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.component.ElderlyActivityCell;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.events.my.MyActivityFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.dbo.ActivityDetailDBO;
import com.gt.cl.util.CLDateUtil;

import java.util.Date;
import java.util.List;

public class MyLCSDAdapter extends BaseAdapter {
	private Context mContext;
	private List<ActivityDetailDBO> mData;
	private Date mCurrentApiDate;

	public MyLCSDAdapter(Context mContext) {
		super();
		this.mContext = mContext;
	}

	public void setData(List<ActivityDetailDBO> mData, Date date) {
		this.mCurrentApiDate = date;
		this.mData = mData;
		notifyDataSetInvalidated();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData != null ? mData.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ElderlyActivityCell cell = null;
		if (convertView == null) {
			cell = new ElderlyActivityCell(mContext);
		} else {
			cell = (ElderlyActivityCell) convertView;
		}
		// Log.v("ao", "ao>>" + ao.toString());
		ActivityDetailDBO ao = mData.get(position);
		cell.getTxtTitle().setText(ao.getTitle());
		cell.setBtnMoreContentDescription(mContext.getString(R.string.voice_page_btn_more, ao.getTitle()),new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ActivityDetailDBO ao = mData.get(position);
				Bundle bundle = new Bundle();
				bundle.putSerializable(
						ActivityDetailFragment.KEY_STORE_ACTIVITY_DETAIL,
						ao);
				bundle.putString(TempleteFragment.HEADER_TYPE, ((MyActivityFragment)((MainActivity)mContext).getNavigationFragment().getCurrentFragment()).getHeaderType().name());
				ActivityDetailFragment adf = new ActivityDetailFragment();
				adf.setArguments(bundle);
				((MainActivity)mContext).getNavigationFragment().push(adf);
			}
		});
		if (ao.getEventType() != null) {
			cell.getTxtActivityType().setText(mContext.getString(R.string.page_activity_type, ao.getEventType()));
		} else {
			cell.getTxtActivityType().setText(
					mContext.getString(R.string.page_activity_type, mContext.getString(R.string.page_search_adv_activity_other)));
		}
		cell.getTxtActivityType().setVisibility(View.GONE);
		String date = null;
		String endDate = null;
		if (ao.getDate() != null) {
			date = CLDateUtil.formatDate(ao.getDate(), Constants.DATE_FORMAT_PATTERN_API, Constants.DATE_FORMAT_PATTERN_SHOW);
		}
		if (ao.getEndDate() != null) {
			endDate = CLDateUtil.formatDate(ao.getEndDate(), Constants.DATE_FORMAT_PATTERN_API, Constants.DATE_FORMAT_PATTERN_SHOW);
		}
		if (date != null && !"".equals(date)) {
			if (endDate != null && !"".equals(endDate)) {
				date += "-";
				date += endDate;
			}
		} else {
			if (endDate != null && !"".equals(endDate)) {
				date = endDate;
			} else {
				date = "";
			}
		}
//		String date = CLDateUtil.formatDate(mCurrentApiDate, Constants.DATE_FORMAT_PATTERN_SHOW);
		// Log.v("ao", "date>>" + date);
		cell.getTxtDate().setText(mContext.getString(R.string.page_activity_date, date));
		if (ao.getFee() != null) {
			try {
				if (Double.valueOf(ao.getFee()) == 0) {
					cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee_no));
				} else {
					cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee, ao.getFee()));
				}
			} catch (Exception e) {
				cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee_nomark, ao.getFee()));
			}
		}
		// else {
		// cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee_no));
		// }


        String voiceLabel="";
        if (ao.getStartTime() != null && ao.getEndTime() != null) {
            voiceLabel=
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime()));
            cell.getTxtTime().setText(
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime())));
        } else {
            if (ao.getStartTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime()));
            } else if (ao.getEndTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime()));
            }
        }
        cell.getTxtTime().setContentDescription(voiceLabel+"按钮");
		return cell;
	}

}
