package com.elderly.elderly.adapter;

import java.util.List;

import android.content.Context;
import android.location.Location;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;
import com.elderly.elderly.pojo.po.LocationPo;

public class SearchEasyRegionAdapter extends BaseAdapter {
	private Context mContext;
	private List<LocationPo> mData=null;
	String mWhichDistrict = "hk_district";

	public SearchEasyRegionAdapter(Context mContext) {
		super();
		this.mContext = mContext;
	}
	
	public void setupData(List<LocationPo> mData){
		this.mData=mData;
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return mData != null ? mData.size() : 0;
	}

	@Override
	public LocationPo getItem(int position) {
		// TODO Auto-generated method stub
		return mData != null ? mData.get(position) : null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LinearLayout ll = null;
		TextView txt = null;
		if (convertView == null) {
			ll = new LinearLayout(mContext);
			ll.setGravity(Gravity.CENTER);
			txt = new TextView(mContext);
			int screenWidth = mContext.getResources().getDisplayMetrics().widthPixels;
			Gallery.LayoutParams lp = new Gallery.LayoutParams(screenWidth / 2, LayoutParams.WRAP_CONTENT);
			LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
					LayoutParams.WRAP_CONTENT);
			txt.setTextAppearance(mContext, R.style.page_search_easy_txt);
			txt.setLayoutParams(llp);
			txt.setGravity(Gravity.CENTER);
			if(mWhichDistrict.equals("hk_district")){
				txt.setBackgroundResource(R.drawable.area_purple);
			}else if(mWhichDistrict.equals("kl_district")){
				txt.setBackgroundResource(R.drawable.area_red);
			}else{
				txt.setBackgroundResource(R.drawable.area_green);
			}
			
			txt.setId(123456);
			ll.addView(txt);
			ll.setLayoutParams(lp);
		} else {
			ll = (LinearLayout) convertView;
			txt = (TextView) ll.findViewById(123456);
		}
		
		txt.setText(mData.get(position).getName());
		return ll;
	}

	public void setColor(String whichDistrict){
		this.mWhichDistrict = whichDistrict;
	}
}
