package com.elderly.elderly.adapter;

import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.elderly.elderly.R;

public class TestAdapter extends BaseAdapter {
	private String TAG="TestAdapter";
	private Context mContext;

	public TestAdapter(Context mContext) {
		super();
		this.mContext = mContext;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Log.v(TAG,"getView>>"+position);
		LinearLayout ll = null;
		ImageView view = null;
		if (convertView == null) {
			ll=new LinearLayout(mContext);
			ll.setGravity(Gravity.CENTER);
			ll.setOrientation(LinearLayout.VERTICAL);
			TextView tv=new TextView(mContext);
			tv.setGravity(Gravity.CENTER);
			tv.setText("太极");
			view = new ImageView(mContext);
			view.setImageResource(R.drawable.search_example);
			int screenWidth=mContext.getResources().getDisplayMetrics().widthPixels;
			Gallery.LayoutParams lp=new Gallery.LayoutParams(screenWidth/2,LayoutParams.WRAP_CONTENT);
//			view.setBackgroundColor(0x88006688);
			LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			ll.addView(view, llp);
			ll.addView(tv,llp);
			ll.setLayoutParams(lp);
		}else{
			view=(ImageView) convertView;
		}
		return ll;
	}

}
