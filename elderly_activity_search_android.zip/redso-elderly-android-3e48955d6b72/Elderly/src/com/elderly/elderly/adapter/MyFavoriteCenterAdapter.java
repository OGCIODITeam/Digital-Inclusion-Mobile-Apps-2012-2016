package com.elderly.elderly.adapter;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;

import com.elderly.elderly.Constants;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.R;
import com.elderly.elderly.activity.MainActivity;
import com.elderly.elderly.component.ElderlyActivityCell;
import com.elderly.elderly.component.ElderlyGroupCell;
import com.elderly.elderly.fragment.events.ActivityDetailFragment;
import com.elderly.elderly.fragment.templete.TempleteFragment;
import com.elderly.elderly.pojo.ao.ActivityAO;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;
import com.gt.cl.util.CLDateUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class MyFavoriteCenterAdapter extends BaseExpandableListAdapter {
    private Context mContext;
    private List<CommunityCentreAO> mGroupData;
    private TreeMap<String, List<ActivityAO>> mChildData;
    private HeaderType mHeaderType;
    private Date mCurrentApiDate;
    private ExpandableListView mListView;


    public MyFavoriteCenterAdapter(Context mContext, HeaderType mHeaderType, ExpandableListView listView) {
        super();
        this.mContext = mContext;
        this.mHeaderType = mHeaderType;
        this.mListView = listView;
    }

    public void setGroupData(List<CommunityCentreAO> mGroupData) {
        this.mGroupData = mGroupData;
        notifyDataSetChanged();
    }

    public void setChildData(TreeMap<String, List<ActivityAO>> mChildData, Date date) {
        this.mChildData = mChildData;
        this.mCurrentApiDate = date;

        Iterator iter = mChildData.entrySet().iterator();
        while (iter.hasNext()) {

            Map.Entry entry = (Map.Entry) iter.next();

            Collections.sort(((List<ActivityAO>) entry.getValue()), new Comparator<ActivityAO>() {

                @Override
                public int compare(ActivityAO fruite1, ActivityAO fruite2) {

                    Long valueA = getLatestDateTime(fruite1.getDate());
                    Long valueB = getLatestDateTime(fruite2.getDate());

                    int retval = valueB.compareTo(valueA);

                    if (retval > 0) {
                        return 1;
                    } else if (retval < 0) {
                        return -1;
                    } else {
                        return 0;
                    }
                }
            });
        }


        notifyDataSetChanged();
    }

    @Override
    public int getGroupCount() {
        // TODO Auto-generated method stub
        return mGroupData != null ? mGroupData.size() : 0;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        int count = 0;
        if (mGroupData != null && mChildData != null) {
            String key = mGroupData.get(groupPosition).getNid();
            if (key != null) {
                List<ActivityAO> data = mChildData.get(key);
                if (data != null) {
                    count = data.size();
                }
            }
        }
        return count;
    }

    @Override
    public Object getGroup(int groupPosition) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ActivityAO getChild(int groupPosition, int childPosition) {
        ActivityAO ao = null;
        if (mGroupData != null && mChildData != null) {
            String key = mGroupData.get(groupPosition).getNid();
            if (key != null) {
                List<ActivityAO> data = mChildData.get(key);

                if (data != null) {
                    ao = data.get(childPosition);
                }
            }
        }
        return ao;
    }

    @Override
    public long getGroupId(int groupPosition) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        ElderlyGroupCell cell = null;
        if (convertView == null) {
            cell = new ElderlyGroupCell(mContext);
        } else {
            cell = (ElderlyGroupCell) convertView;
        }
        CommunityCentreAO ao = mGroupData.get(groupPosition);
        cell.getTxtTitle().setText(ao.getFieldElderlyOrganizationValue() + "\n" + ao.getFieldElderlyCentreValue());
        cell.setBackgroundColor(mContext.getResources().getColor(Constants.getSchemeColorIdByHeaderType(mHeaderType)));
        cell.getImgVArrow().setImageResource(Constants.getGroupIndicatorByHeaderType(mHeaderType, !isExpanded));
        cell.getImgVArrow().setClickable(false);
        if (isExpanded) {
            cell.getImgVArrow().setContentDescription("收起");
//			cell.getImgVArrow().setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View v) {
//					mListView.collapseGroup(groupPosition);
//				}
//			});
        } else {
            cell.getImgVArrow().setContentDescription("展开");
//			cell.getImgVArrow().setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View v) {
//					mListView.expandGroup(groupPosition);
//				}
//			});
        }
        return cell;
    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        String key = mGroupData.get(groupPosition).getNid();
        List<ActivityAO> data = mChildData.get(key);
        ActivityAO ao = null;
        if (data != null) {
            ao = data.get(childPosition);
        }
        ElderlyActivityCell cell = null;
        if (convertView == null) {
            cell = new ElderlyActivityCell(mContext);
        } else {
            cell = (ElderlyActivityCell) convertView;
        }
        // Log.v("ao", "ao>>" + ao.toString());
        cell.getTxtTitle().setText(ao.getTitle());
        cell.setBtnMoreContentDescription(mContext.getString(R.string.voice_page_btn_more, ao.getTitle()), new OnClickListener() {

            @Override
            public void onClick(View v) {
                ActivityAO ao = getChild(groupPosition, childPosition);
                if (ao != null && ao.getId() != null) {
                    ((TempleteFragment) ((MainActivity) mContext).getNavigationFragment().getCurrentFragment()).callActivityDetailApi(ao.getId(), ActivityDetailFragment.TYPE_ELDERLY);
                }
            }
        });
        if (ao.getEventType() != null) {
            cell.getTxtActivityType().setText(mContext.getString(R.string.page_activity_type, ao.getEventType()));
        } else {
            cell.getTxtActivityType().setText(
                    mContext.getString(R.string.page_activity_type, mContext.getString(R.string.page_search_adv_activity_other)));
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Date dated = null;
        //get latest day of event
        try {
            dated = sdf.parse(getLatestDate(ao.getDate()).toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String date = CLDateUtil.formatDate(dated, Constants.DATE_FORMAT_PATTERN_SHOW);
        // Log.v("ao", "date>>" + date);
        cell.getTxtDate().setText(mContext.getString(R.string.page_activity_date, date));
        if (ao.getFee() != null) {
            try {
                if (Double.valueOf(ao.getFee()) == 0) {
                    cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee_no));
                } else {
                    cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee, ao.getFee()));
                }
            } catch (Exception e) {
                cell.getTxtCost().setText(mContext.getString(R.string.page_activity_fee_nomark, ao.getFee()));
            }
        }
        String voiceLabel="";
        if (ao.getStartTime() != null && ao.getEndTime() != null) {
            voiceLabel=
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime()));
            cell.getTxtTime().setText(
                    mContext.getResources().getString(R.string.page_activity_time,
                            (ao.getStartTime() + " - " + ao.getEndTime())));
        } else {
            if (ao.getStartTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getStartTime()));
            } else if (ao.getEndTime() != null) {
                voiceLabel=mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime());

                cell.getTxtTime().setText(
                        mContext.getResources().getString(R.string.page_activity_time, ao.getEndTime()));
            }
        }
        cell.getTxtTime().setContentDescription(voiceLabel+"按钮");
        return cell;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    public void release() {
        if (mGroupData != null) {
            mGroupData.clear();
            mGroupData = null;
        }
        if (mChildData != null) {
            mChildData.clear();
            mChildData = null;
        }
    }


    public Long getLatestDateTime(String dateString) {
        List<String> items = Arrays.asList(dateString.split("\\s*,\\s*"));
        List<String> filtedItems = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date latestdate = null;
        //init month filter

        Calendar monthCal = Calendar.getInstance();
        monthCal.setTime(targetMonth);

        for (int i = 0; i < items.size(); i++) {
            try {
                Date date = sdf.parse(items.get(i));
                Calendar dateCal = Calendar.getInstance();

                dateCal.setTime(date);
                if (monthCal.get(Calendar.MONTH) == dateCal.get(Calendar.MONTH)) {
                    filtedItems.add(items.get(i));
                }

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        try {
            latestdate = sdf.parse(filtedItems.get(filtedItems.size() - 1));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date todayDate = new Date();
        for (int i = 0; i < filtedItems.size(); i++) {
            try {
                Date date = sdf.parse(filtedItems.get(i));
                if (date.after(todayDate)) {
                    latestdate = sdf.parse(filtedItems.get(i));
                    break;

                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        android.util.Log.d("latestdate.getTime() ", latestdate.getTime() + "");
        return latestdate.getTime();
    }

    public String getLatestDate(String dateString) {
        List<String> items = Arrays.asList(dateString.split("\\s*,\\s*"));
        List<String> filtedItems = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //init month filter
        Calendar monthCal = Calendar.getInstance();
        monthCal.setTime(targetMonth);

        for (int i = 0; i < items.size(); i++) {
            try {
                Date date = sdf.parse(items.get(i));
                Calendar dateCal = Calendar.getInstance();
                dateCal.setTime(date);
                if (monthCal.get(Calendar.MONTH) == dateCal.get(Calendar.MONTH)) {
                    filtedItems.add(items.get(i));
                }

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        String latestdate = filtedItems.get(filtedItems.size() - 1);

        Date todayDate = new Date();
        for (int i = 0; i < filtedItems.size(); i++) {

            try {
                Date date = sdf.parse(filtedItems.get(i));
                    if (date.after(todayDate)) {
                        latestdate = filtedItems.get(i);
                        break;
                    }

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return latestdate;
    }

    Date targetMonth;

    public void setTargetMonth(Date month) {
        targetMonth = month;
    }

}
