package com.elderly.elderly.adapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.elderly.elderly.R;
import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.component.ElderlyMyInterestCell;
import com.elderly.elderly.manager.UserProfileManager;
import com.elderly.elderly.pojo.po.ActivityCategoryPo;

public class SelectInterestAdapter extends BaseAdapter {
	private Context mContext;
	private List<ActivityCategoryPo> mDatas;
	private List<ActivityCategoryPo> mHightLightDatas;
	private ActivityCategoryPo mAllCategory;

	public SelectInterestAdapter(Context mContext) {
		super();
		this.mContext = mContext;
		mAllCategory = new ActivityCategoryPo();
		mAllCategory.setKey("all");
		mAllCategory.setNameSc("全部");
		mAllCategory.setNameTc("全部");
		mDatas = new ArrayList<ActivityCategoryPo>();
		mHightLightDatas = new ArrayList<ActivityCategoryPo>();
		mDatas.add(mAllCategory);
		mDatas.addAll(UserProfileManager.getInstance().getAllInterestList());
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDatas != null ? mDatas.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ElderlyMyInterestCell cell = null;
		if (convertView == null) {
			cell = new ElderlyMyInterestCell(mContext);
			int drawableId=R.drawable.sl_bg_choose_search_adv;
			if(ColorTheme.CurrentColorTheme==ColorTheme.ColorTheme2){
				drawableId=R.drawable.sl_bg_choose_search_adv1;
			}
			cell.getIcon().setBackgroundResource(drawableId);
		} else {
			cell = (ElderlyMyInterestCell) convertView;
		}
		ActivityCategoryPo po = mDatas.get(position);
		cell.getTxtTitle().setText(po.getName());
		cell.setTag(po);
		cell.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (v.getTag() != null && v.getTag() instanceof ActivityCategoryPo) {
					if (position == 0) {
						if (mHightLightDatas.contains(mAllCategory)) {
							mHightLightDatas.clear();
						}else{
							mHightLightDatas.clear();
							mHightLightDatas.addAll(mDatas);
						}
					}else{
						ActivityCategoryPo po = (ActivityCategoryPo) v.getTag();
						if (mHightLightDatas.contains(po)){
							mHightLightDatas.remove(mAllCategory);
							mHightLightDatas.remove(po);
						}else{
							mHightLightDatas.add(po);
						}
					}
					notifyDataSetChanged();
				}
			}
		});
		
		if (mHightLightDatas.contains(po)) {
			cell.getIcon().setSelected(true);
		}else{
			cell.getIcon().setSelected(false);
		}
		return cell;
	}

	public List<ActivityCategoryPo> getHightLightDatas() {
		Log.i("testcc", mHightLightDatas.size()+"get..."+mHightLightDatas.size()+"..."+mDatas.size());
		return mHightLightDatas.contains(mAllCategory) ? UserProfileManager.getInstance().getAllInterestList()
				: mHightLightDatas;
	}

	public void setHightLightDatas(List<ActivityCategoryPo> hightLightDatas) {
		if (hightLightDatas!=null&&hightLightDatas.size()>0) {
			Log.i("testcc", hightLightDatas.size()+"set..."+hightLightDatas.size()+"..."+mDatas.size());
			this.mHightLightDatas.addAll(hightLightDatas);
			if (hightLightDatas.size() == (mDatas.size()-1)) {
				this.mHightLightDatas.add(0, mAllCategory);
			}
			notifyDataSetChanged();
		}
	}
}
