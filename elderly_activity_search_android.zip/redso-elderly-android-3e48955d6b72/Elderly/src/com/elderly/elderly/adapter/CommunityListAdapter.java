package com.elderly.elderly.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.elderly.elderly.Constants.ColorTheme;
import com.elderly.elderly.Constants.HeaderType;
import com.elderly.elderly.R;
import com.elderly.elderly.component.ElderlyCommunityCentreCell;
import com.elderly.elderly.pojo.ao.CommunityCentreAO;

public class CommunityListAdapter extends BaseAdapter {
	private Context mContext;
	private List<CommunityCentreAO> mData;
	private int selectIndex = -1;
	private HeaderType mHeaderType;

	public CommunityListAdapter(Context mContext, HeaderType mHeaderType) {
		super();
		this.mContext = mContext;
		this.mHeaderType = mHeaderType;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData != null ? mData.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	/*
	 * (non-Javadoc)
	 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ElderlyCommunityCentreCell cell = null;
		if (convertView == null) {
			cell = new ElderlyCommunityCentreCell(mContext);
		} else {
			cell = (ElderlyCommunityCentreCell) convertView;
		}
		if (mHeaderType == HeaderType.ProfileSetting) {
			cell.getIcon().setBackgroundResource(R.drawable.sl_bg_choose_profile);
		} else {
			if (ColorTheme.CurrentColorTheme == ColorTheme.ColorTheme1) {
				cell.getIcon().setBackgroundResource(R.drawable.sl_bg_choose_search_adv);
			} else {
				cell.getIcon().setBackgroundResource(R.drawable.sl_bg_choose_search_adv1);
			}

		}
		CommunityCentreAO ao = mData.get(position);
		
		String temp = "";
		if ("".equals(ao.getFieldElderlyOrganizationValue())) {
			temp = ao.getFieldElderlyCentreValue();
		}else if ("".equals(ao.getFieldElderlyCentreValue())) {
			temp = ao.getFieldElderlyOrganizationValue();
		}else{
			temp = ao.getFieldElderlyOrganizationValue()+"\n"+ao.getFieldElderlyCentreValue();
		}
		cell.getTxtTitle1().setText(temp);
		cell.setTag(position + "");
		cell.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				selectIndex = Integer.parseInt((String) v.getTag());
				notifyDataSetChanged();
			}
		});
		if (position == selectIndex) {
			cell.getIcon().setSelected(true);
		} else {
			cell.getIcon().setSelected(false);
		}
		return cell;
	}

	public void addData(List<CommunityCentreAO> data) {
		if (data != null) {
			if (mData == null) {
				mData = data;
			} else {
				mData.addAll(data);
			}
			notifyDataSetChanged();
		}
	}

	public void setData(List<CommunityCentreAO> data) {
		mData = data;
		notifyDataSetChanged();
	}

	public CommunityCentreAO getSelectData() {
		return mData != null && mData.size() > 0 && selectIndex!=-1? mData.get(selectIndex) : null;
	}

	public void release() {
		if (mData != null) {
			mData.clear();
			mData = null;
		}
		mContext = null;
	}
}
