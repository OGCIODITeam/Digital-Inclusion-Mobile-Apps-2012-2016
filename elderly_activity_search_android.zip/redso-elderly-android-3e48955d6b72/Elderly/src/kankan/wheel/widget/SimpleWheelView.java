package kankan.wheel.widget;

import kankan.wheel.widget.adapters.WheelViewAdapter;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.elderly.elderly.R;

public class SimpleWheelView extends WheelView {

	private static final String TAG = "SimpleWheelView";

	private static Bitmap sArrowUpBitmapOff;
	private static Bitmap sArrowUpBitmapOn;
	private static Bitmap sArrowDownBitmapOff;
	private static Bitmap sArrowDownBitmapOn;
	private static BitmapDrawable sTopShadow;
	private static BitmapDrawable sBottomShadow;
	private Bitmap sSelectBitmap;

	private Paint mLinePaint = new Paint();
	private int mLineStartX;
	private int mLineEndX;
	private boolean mCanDown;
	private boolean mCanUp;
	private int mArrowX;
	private int mArrowHeight;

	private boolean mFirstInvalidate;

	/**
	 * Constructor
	 */
	public SimpleWheelView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		mFirstInvalidate = true;
		mLinePaint.setColor(0xffcf2134);
		mLinePaint.setStrokeWidth(3);

		final int arrowWidth = (int) getResources().getDimension(R.dimen.wheelview_arrow_width);
		final int arrowHeight = (int) getResources().getDimension(R.dimen.wheelview_arrow_height);
		Log.v(TAG, "arrowWidth>>" + arrowWidth);
		// if(sArrowUpBitmapOff == null) {
		// Bitmap arrowUpBitmapOff = BitmapFactory.decodeResource(getResources(), R.drawable.wheel_arrow_up_off);
		// sArrowUpBitmapOff = Bitmap.createScaledBitmap(arrowUpBitmapOff, arrowWidth, arrowHeight, false);
		// arrowUpBitmapOff.recycle();
		// }
		// if(sArrowUpBitmapOn == null) {
		// Bitmap arrowUpBitmapOn = BitmapFactory.decodeResource(getResources(), R.drawable.wheel_arrow_up_on);
		// sArrowUpBitmapOn = Bitmap.createScaledBitmap(arrowUpBitmapOn, arrowWidth, arrowHeight, false);
		// arrowUpBitmapOn.recycle();
		// }
		// if(sArrowDownBitmapOff == null) {
		// Bitmap arrowDownBitmapOff = BitmapFactory.decodeResource(getResources(), R.drawable.wheel_arrow_down_off);
		// sArrowDownBitmapOff = Bitmap.createScaledBitmap(arrowDownBitmapOff, arrowWidth, arrowHeight, false);
		// arrowDownBitmapOff.recycle();
		// }
		// if(sArrowDownBitmapOn == null) {
		// Bitmap arrowDownBitmapOn = BitmapFactory.decodeResource(getResources(), R.drawable.wheel_arrow_down_on);
		// sArrowDownBitmapOn = Bitmap.createScaledBitmap(arrowDownBitmapOn, arrowWidth, arrowHeight, false);
		// arrowDownBitmapOn.recycle();
		// }
		if (sTopShadow == null) {
			// sTopShadow = (BitmapDrawable) getResources().getDrawable(R.drawable.simple_wheel_bg);
		}
		if (sBottomShadow == null) {
			// sBottomShadow = (BitmapDrawable) getResources().getDrawable(R.drawable.simple_wheel_bg);
		}
		// if (sSelectBitmap == null) {
		// sSelectBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.setting_area_on);
		// }

		mArrowHeight = arrowHeight + 10;
		// setPadding(0, arrowHeight, 0, arrowHeight);
	}

	/**
	 * Constructor
	 */
	public SimpleWheelView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	/**
	 * Constructor
	 */
	public SimpleWheelView(Context context) {
		this(context, null);
	}

	/**
	 * Initializes resources
	 */
	@Override
	protected void initResourcesIfNecessary() {
		if (centerDrawable == null) {
			// centerDrawable = getContext().getResources().getDrawable(R.drawable.simple_wheel_val);
		}

		if (topShadow == null) {
			// topShadow = new GradientDrawable(Orientation.TOP_BOTTOM, SHADOWS_COLORS);
		}

		if (bottomShadow == null) {
			// bottomShadow = new GradientDrawable(Orientation.BOTTOM_TOP, SHADOWS_COLORS);
		}

		// setBackgroundResource(R.drawable.simple_wheel_bg);
		setBackgroundColor(Color.WHITE);
	}

	public void setSelectBitmap(int id) {
		if (sSelectBitmap == null && id != 0) {
			sSelectBitmap = BitmapFactory.decodeResource(getResources(), id);
		}
	}

	/**
	 * Draws rect for current value
	 * 
	 * @param canvas the canvas for drawing
	 */
	protected void drawCenterRect(Canvas canvas) {
		int center = getHeight() / 2;
		int offset = (int) (getItemHeight() / 2);
		// centerDrawable.setBounds(0, center - offset, getWidth(), center + offset);
		// centerDrawable.draw(canvas);

		if (mLineStartX == 0 || mLineEndX == 0) {
			final int viewWidth = getWidth();
			final int percentWidth = viewWidth * 60 / 100;
			mLineStartX = (viewWidth - percentWidth) / 2;
			mLineEndX = mLineStartX + percentWidth;
		}
		if (sSelectBitmap != null) {
			canvas.drawBitmap(sSelectBitmap, (getWidth() / 2 - sSelectBitmap.getWidth() / 2), center - sSelectBitmap.getHeight() / 2, new Paint());
		}
		// canvas.drawLine(mLineStartX, center - offset, mLineEndX, center - offset, mLinePaint);
		// canvas.drawLine(mLineStartX, center + offset, mLineEndX, center + offset, mLinePaint);
	}

	@Override
	public void setViewAdapter(WheelViewAdapter viewAdapter) {
		if (viewAdapter != null) {
			mCanDown = viewAdapter.getItemsCount() > 1;
		}
		super.setViewAdapter(viewAdapter);
	}

	@Override
	protected void notifyChangingListeners(int oldValue, int newValue) {
		final int itemCount = getViewAdapter().getItemsCount();
		if (newValue == 0) {
			mCanUp = false;
			mCanDown = true;
		} else if (newValue == itemCount - 1) {
			mCanUp = true;
			mCanDown = false;
		} else {
			mCanUp = true;
			mCanDown = true;
		}
		super.notifyChangingListeners(oldValue, newValue);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		View view = getItemView(getCurrentItem());
		if (view instanceof TextView) {
			TextView tv = (TextView) view;
			String string = tv.getContentDescription().toString();
			if (string == null) {
				string = tv.getText().toString();
			}
			setContentDescription(string);
		}
		// if(mArrowX == 0) {
		// mArrowX = getWidth() / 2 - (sArrowDownBitmapOff.getWidth() / 2);
		// }
		// canvas.save();
		// super.onDraw(canvas);
		// canvas.drawBitmap(mCanUp ? sArrowUpBitmapOn : sArrowUpBitmapOff, mArrowX, 0, null);
		// canvas.drawBitmap(mCanDown ? sArrowDownBitmapOn : sArrowDownBitmapOff, mArrowX, getHeight() -
		// sArrowDownBitmapOff.getHeight(), null);
		// canvas.restore();
		// if(mFirstInvalidate) {
		// mFirstInvalidate = false;
		// postInvalidate();
		// }
	}

	protected void drawShadows(Canvas canvas) {
		// int height = (int)(1.5 * getItemHeight());
		// canvas.drawRect(0, 0, getWidth(), mArrowHeight, mShadowPaint);
		// canvas.drawRect(0, getHeight() - mArrowHeight, getWidth(), getHeight(), mShadowPaint);

		canvas.save();
		if (sTopShadow != null) {
			sTopShadow.setBounds(0, 0, getWidth(), mArrowHeight);
			sTopShadow.draw(canvas);
		}
		if (sBottomShadow != null) {
			sBottomShadow.setBounds(0, getHeight() - mArrowHeight, getWidth(), getHeight());
			sBottomShadow.draw(canvas);
		}
		canvas.restore();
	}

	public void release() {
		if (sSelectBitmap != null && !sSelectBitmap.isRecycled()) {
			sSelectBitmap.recycle();
		}
	}

	protected void notifyScrollingListenersAboutEnd() {
		View view = getItemView(getCurrentItem());
		if (view instanceof TextView) {
			TextView tv = (TextView) view;
			String string = tv.getContentDescription().toString();
			if (string == null) {
				string = tv.getText().toString();
			}
			setContentDescription(string);
		}
		setFocusableInTouchMode(true);
		setFocusable(true);
		requestFocus();
		super.notifyScrollingListenersAboutEnd();
	}

	@Override
	protected void notifyScrollingListenersAboutStart() {
		super.notifyScrollingListenersAboutStart();
		clearFocus();
	}
	// --------------------------------------------------

}
