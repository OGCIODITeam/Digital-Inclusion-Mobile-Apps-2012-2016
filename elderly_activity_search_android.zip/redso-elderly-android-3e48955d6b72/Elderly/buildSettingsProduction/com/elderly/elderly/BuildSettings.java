package com.elderly.elderly;

public class BuildSettings {
	public static final boolean IS_PRODUCTION = true;
}
