package lib.gt.ga.v2;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Collection;

import android.app.Activity;
import android.content.Context;

import com.google.analytics.tracking.android.EasyTracker;
import com.google.analytics.tracking.android.ExceptionReporter;
import com.google.analytics.tracking.android.GAServiceManager;
import com.google.analytics.tracking.android.GoogleAnalytics;
import com.google.analytics.tracking.android.Tracker;

public class GAManager {
	
	private final String TAG = "GAManager";

/* -------------------- Constructor -------------------- */
	
	private static GAManager instance = null;
	private static String sGoogleAnalyticsTrackingId;
	
	private GoogleAnalytics mGoogleAnalytics;
	private Tracker mTracker;
	
	public synchronized static void init(Context context, String GoogleAnalyticsTrackingId) {
		if(instance == null) {
			sGoogleAnalyticsTrackingId = new String(GoogleAnalyticsTrackingId);
			instance = new GAManager(context);
		}
	}
	
	public synchronized static void destory() {
		if(instance != null) {
			instance.release();
			sGoogleAnalyticsTrackingId = null;
			instance = null;
		}
	}
	
	public static GAManager getInstance() {
		return instance;
	}
	
	private GAManager(Context context) {
		mGoogleAnalytics = GoogleAnalytics.getInstance(context);
		EasyTracker.getInstance().setContext(context);
		mTracker = mGoogleAnalytics.getTracker(sGoogleAnalyticsTrackingId);
	}
	
/* -------------------- Public methods -------------------- */	
	
	public static void onStart(Activity activity) {
		EasyTracker.getInstance().activityStart(activity);
	}
	
	public static void onStop(Activity activity) {
		EasyTracker.getInstance().activityStop(activity);
	}
	
	public void sendView(String viewName) {
		trackView(viewName);
	}
	
	public void trackView(String viewName) {
		if(mTracker == null) {
			return ;
		}
		if(isNull(viewName)) {
			return ;
		}
		Log.i(TAG, "onTrackView -> " + viewName);
		mTracker.sendView(viewName);
	}
	
	public void sendEvent(String category, String action, String label) {
		sendEvent(category, action, label, Long.MIN_VALUE);
	}
	
	public void sendEvent(String category, String action, String label, long value) {
		trackEvent(category, action, label, value);
	}
	
	public void trackEvent(String category, String action, String label) {
		trackEvent(category, action, label, Long.MIN_VALUE);
	}
	
	public void trackEvent(String category, String action, String label, long value) {
		if(mTracker == null) {
			return ;
		}
		if(isNull(category, action, label)) {
			return ;
		}
		mTracker.sendEvent(category, action, label, value == Long.MIN_VALUE ? null : value);
	}
	
	public void enableReportUncaughtException() {
		if(mTracker == null) {
			return ;
		}
		UncaughtExceptionHandler exceptionHanlder = new ExceptionReporter(
				mTracker, 
				GAServiceManager.getInstance(), 
				Thread.getDefaultUncaughtExceptionHandler());
		Thread.setDefaultUncaughtExceptionHandler(exceptionHanlder);
	}
	
	public void setDebugable(boolean debugable) {
		if(mGoogleAnalytics != null) {
			mGoogleAnalytics.setDebug(debugable);
		}
		Log.loggagble(debugable);
	}
	
	private void release() {
		if(mGoogleAnalytics != null) {
			mGoogleAnalytics.closeTracker(mTracker);
			mGoogleAnalytics = null;
		}
		if(mTracker != null) {
			mTracker.close();
			mTracker = null;
		}
	}

/* -------------------- Private methods -------------------- */
	
	private boolean isNull(Object... objects) {
		return isNull(false, objects);
	}

	private boolean isNull(Boolean checkChildCollections, Object... objects) {
		boolean flag = true;
		if (objects != null) {
			for (Object o : objects) {
				if (o != null) {
					if (checkChildCollections && (o instanceof Collection<?> || o instanceof Object[])) {
						return isNull(true, o);
					} else {
						flag = "".equals(o.toString().trim());
						if (flag) {
							break;
						}
					}
				} else {
					flag = true;
					break;
				}
			}
		}
		return flag;
	}
	
}
