package com.gt.cl.json;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.gt.cl.util.CLClassUtil;
import com.gt.cl.util.CLStringUtil;

public class CLJsonParser {
	
	
	public void parseJsonToBean(String json, Object obj){
		try {
			JSONObject jsonObject = new JSONObject(json);
			
			parseJsonObjectToBean(jsonObject, obj);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	
	public void parseJsonObjectToBean(JSONObject jsonObject, Object obj){
		Class<?> cs = obj.getClass();
		Field[] fields = CLClassUtil.getFields(cs);
		for(Field field : fields){
			field.setAccessible(true);
			CLJsonMapping jsonInfo = null;
			jsonInfo = field.getAnnotation(CLJsonMapping.class);
			if(jsonInfo==null){
				Method getter = CLClassUtil.getGetterMethod(cs, field.getName());
				if(getter!=null){
					jsonInfo = getter.getAnnotation(CLJsonMapping.class);
				}
			}
			
			if(jsonInfo!=null){
				
				
				
				String tagPath = jsonInfo.tagPath();
				
				
				
				if(jsonInfo.type() == CLJsonMapping.TYPE_COLLECTION){
					String genericType = jsonInfo.genericType();
					
					try {
						List<Object> list = new ArrayList<Object>();
						Class<?> genCs = Class.forName(genericType);
						this.parseJsonToList(jsonObject, list, genCs, tagPath);
						CLClassUtil.setValue(obj, field, list);
					} catch (Exception e) {
						//e.printStackTrace();
					}
				}else{
					
					Object value = getValueByPath(jsonObject, tagPath);
					Class<?> fieldClass = field.getType();
					if(fieldClass.isAssignableFrom(String.class)){
						if(value instanceof String){
							String strValue = (String)value;
							CLClassUtil.setValue(obj, field, strValue);
						}
					}else if(fieldClass.isAssignableFrom(Integer.class) ||  fieldClass.isAssignableFrom(int.class)){
						try {
							Integer intValue = Integer.parseInt(value.toString());
							CLClassUtil.setValue(obj, field, intValue);
						} catch (Exception e) {
							
						}
						
						
					}else if(fieldClass.isAssignableFrom(Float.class) ||  fieldClass.isAssignableFrom(float.class)){
						try {
							Float floatValue = Float.parseFloat(value.toString());
							CLClassUtil.setValue(obj, field, floatValue);
						} catch (Exception e) {
							
						}
					}else if(fieldClass.isAssignableFrom(Long.class) ||  fieldClass.isAssignableFrom(long.class)){
						try {
							Long longValue = Long.parseLong(value.toString());
							CLClassUtil.setValue(obj, field, longValue);
						} catch (Exception e) {
							
						}
					}else if(fieldClass.isAssignableFrom(Boolean.class) ||  fieldClass.isAssignableFrom(boolean.class)){
						try {
							String strValue = value.toString();
							String trueValue = jsonInfo.trueValue();
							if(strValue!=null && strValue.equals(trueValue)){
								CLClassUtil.setValue(obj, field, true);
							}else{
								CLClassUtil.setValue(obj, field, false);
							}
							
						} catch (Exception e) {
							
						}
					}else if(fieldClass.isAssignableFrom(Date.class)){
						try {
							String strValue = value.toString();
							String dateFormat = jsonInfo.dateFormat();
							SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
							Date date = sdf.parse(strValue);
							CLClassUtil.setValue(obj, field, date);
							
						} catch (Exception e) {
							
						}
					}else{
						try {
							Object objValue = null;
							if(jsonInfo.genericType()!=null && !"".equals(jsonInfo.genericType())){
								Class<?> genericClass = Class.forName(jsonInfo.genericType());
								objValue = genericClass.newInstance();
							}else{
								objValue = field.getType().newInstance();
							}
							
							
							String regEx = ".*\\[([0-9]*?)\\]";
							Pattern pat = Pattern.compile(regEx);
							Matcher mat = pat.matcher(tagPath);
							boolean rs = mat.find();
							if(rs){
								String newSubPath = tagPath.replaceAll("\\[.*?\\]", "");
								
								JSONArray jsonArray = jsonObject.optJSONArray(newSubPath);
								String arrayIndexStr = mat.group(1);
								Log.i("", "arrayIndexStr   >>>>  " + arrayIndexStr);
								int arrayIndex = Integer.parseInt(arrayIndexStr);
								if(arrayIndex < jsonArray.length()){
									JSONObject subJsonObj = jsonArray.optJSONObject(arrayIndex);
									parseJsonObjectToBean(subJsonObj, objValue);
									CLClassUtil.setValue(obj, field, objValue);
								}
								
							}else{
								parseJsonObjectToBean((JSONObject)value, objValue);
								CLClassUtil.setValue(obj, field, objValue);
							}
							
						} catch (Exception e) {
							//e.printStackTrace();
						}
					}
					
					
				}
				
			}
			
		}
	}
	
	
	protected void parseJsonToList(JSONObject jsonObj, List<Object> list, Class<?> genCs, String tagPath){
		Object objValue = getValueByPath(jsonObj, tagPath);
		if(objValue!=null){
			if(objValue instanceof JSONArray){
				JSONArray jsonArray = (JSONArray)objValue;
				for(int i=0;i<jsonArray.length();i++){
					Object subValue = jsonArray.opt(i);
					if(genCs.isAssignableFrom(String.class)){
						if(subValue instanceof String){
							list.add(subValue);
						}
					}else if(genCs.isAssignableFrom(Integer.class) || genCs.isAssignableFrom(int.class)){
						try {
							Integer intValue = Integer.parseInt(subValue.toString());
							list.add(intValue);
						} catch (Exception e) {
							
						}
					}else{
						try {
							Object genObj = genCs.newInstance();
							if(subValue instanceof JSONObject){
								JSONObject subJsonObj = (JSONObject)subValue;
								this.parseJsonObjectToBean(subJsonObj, genObj);
								list.add(genObj);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}else if(objValue instanceof List){
				List vList = (List)objValue;
				list.addAll(vList);
			}
			
		}
		
		
	}
	
	protected Object getValueByPath(JSONObject jsonObj, String path){
		Object value = null;
		if(path.contains(".")){
			String[] paths = path.split("\\.");
			List<String> pathList = Arrays.asList(paths);;
			value = getValueByPaths(jsonObj, pathList);
//			JSONObject tmpJsonObj = jsonObj;
//			for(int i=0;i<paths.length;i++){
//				String subPath = paths[i];
//				if(i!=paths.length-1){
//					if(subPath.contains("[]")){
//						String newSubPath = subPath.replaceAll("\\[\\]", "");
//						JSONArray jsonArray = tmpJsonObj.optJSONArray(newSubPath);
//					}else{
//						tmpJsonObj = tmpJsonObj.optJSONObject(subPath);
//					}
//					
//				}else{
//					value = tmpJsonObj.opt(subPath);
//				}
//			}
		}else{
			List<String> pathList = new ArrayList<String>();
			pathList.add(path);
			value = getValueByPaths(jsonObj, pathList);
//			value = jsonObj.opt(path);
		}
		return value;
	}
	
	protected Object getValueByPaths(JSONObject jsonObj, List<String> paths){
		Object value = null;
		JSONObject tmpJsonObj = jsonObj;
		for(int i=0;i<paths.size();i++){
			String subPath = paths.get(i);
			if(i!=paths.size() - 1){
				if(subPath.indexOf("[")>0){
					String newSubPath = subPath.replaceAll("\\[.*?\\]", "");
					JSONArray jsonArray = tmpJsonObj.optJSONArray(newSubPath);
					List<String> subPaths = new ArrayList<String>();
					for(int j=i+1; j<paths.size();j++){
						subPaths.add(paths.get(j));
					}
					
					
					String regEx = ".*\\[([0-9]+?)\\]";
					Pattern pat = Pattern.compile(regEx);
					Matcher mat = pat.matcher(subPath);
					boolean rs = mat.find();
					Log.i("", "rs   >>>>  " + rs);
					if(rs){
						try {
							String arrayIndexStr = mat.group(1);
							Log.i("", "arrayIndexStr   >>>>  " + arrayIndexStr);
							int arrayIndex = Integer.parseInt(arrayIndexStr);
							
							if(arrayIndex < jsonArray.length()){
								JSONObject subJsonObj = jsonArray.optJSONObject(arrayIndex);
								Object subValue = getValueByPaths(subJsonObj, subPaths);
								Log.i("", "subValue   >>>>  " + subValue);
								value = subValue;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
					}else{
						List valueList = new ArrayList();
						for(int j=0;j<jsonArray.length();j++){
							JSONObject subJsonObj = jsonArray.optJSONObject(j);
							Object subValue = getValueByPaths(subJsonObj, subPaths);
							valueList.add(subValue);
						}
						value = valueList;
					}
					
					
					
					break;
				}else if(subPath.startsWith("#")){
					String newSubPath = subPath.replaceAll("[^0-9]", "");
					try {
						int index = Integer.parseInt(newSubPath);
						Iterator<String> keys = tmpJsonObj.keys();
						int itIndex = 0;
						while(keys.hasNext()){
							String key = keys.next();
							if(itIndex==index){
								value = key;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}else if(subPath.startsWith("@#")){
					String newSubPath = subPath.replaceAll("[^0-9]", "");
					try {
						int index = Integer.parseInt(newSubPath);
						Iterator<String> keys = tmpJsonObj.keys();
						int itIndex = 0;
						while(keys.hasNext()){
							String key = keys.next();
							if(itIndex==index){
								value = tmpJsonObj.opt(key);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}else{
					tmpJsonObj = tmpJsonObj.optJSONObject(subPath);
				}
				
			}else{
				String regEx = ".*\\[([0-9]*?)\\]";
				Pattern pat = Pattern.compile(regEx);
				Matcher mat = pat.matcher(subPath);
				boolean rs = mat.find();
				if(rs){
					String newSubPath = subPath.replaceAll("\\[.*?\\]", "");
					
					JSONArray jsonArray = tmpJsonObj.optJSONArray(newSubPath);
					String arrayIndexStr = mat.group(1);
					Log.i("", "arrayIndexStr   >>>>  " + arrayIndexStr);
					int arrayIndex = Integer.parseInt(arrayIndexStr);
//					JSONObject subJsonObj = jsonArray.optJSONObject(arrayIndex);
					value = jsonArray.opt(arrayIndex);
				}else if(subPath.startsWith("#")){
					String newSubPath = subPath.replaceAll("[^0-9]", "");
					try {
						int index = Integer.parseInt(newSubPath);
						Iterator<String> keys = tmpJsonObj.keys();
						int itIndex = 0;
						while(keys.hasNext()){
							String key = keys.next();
							if(itIndex==index){
								value = key;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}else if(subPath.startsWith("@#")){
					String newSubPath = subPath.replaceAll("[^0-9]", "");
					try {
						int index = Integer.parseInt(newSubPath);
						Iterator<String> keys = tmpJsonObj.keys();
						int itIndex = 0;
						while(keys.hasNext()){
							String key = keys.next();
							if(itIndex==index){
								value = tmpJsonObj.opt(key);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
				}else{
					value = tmpJsonObj.opt(subPath);
				}
				
			}
		}
		
		return value;
	}
}
