package com.gt.cl.component.imageview.bitmapview.info;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Vector;

import android.graphics.Bitmap;
import android.media.ExifInterface;
import android.util.Log;

/**
 * 
 * Bitmap Info pojo
 * 
 * @author jianfeng.lao
 * @version 1.0
 * @CreateDate 2013-3-10
 */
public class CLBitmapInfo {
	private static final String TAG = "BitmapInfo";
	/**
	 * opt param
	 */
	private Options options;
	/**
	 * image path is store
	 */
	private String filePath;// 全路径
	/**
	 * download image url
	 */
	private String downLoadUrl;
	/**
	 */
	private LinkedList<BitmapInfoListener> listeners;
	/**
	 * 加载Bitmap的UI标志符
	 */
	private String UIFlag;
	/**
	 * 一定要set并且是要每一张Bitmap只有一个唯一key
	 */
	private String cacheKey;
	

	public CLBitmapInfo(String cacheKey, String downLoadUrl, String filePath, Options options) {
		super();
		this.cacheKey = cacheKey;
		this.downLoadUrl = downLoadUrl;
		this.filePath = filePath;
		this.options = options;
		listeners = new LinkedList<CLBitmapInfo.BitmapInfoListener>();
	}

	public interface BitmapInfoListener {
		public void onDownLoad(CLBitmapInfo info, boolean isSuccess);

		public void onBitmapLoad(CLBitmapInfo info, Bitmap bitmap);

		public void beforeRecyle(CLBitmapInfo info);
	}

	/**
	 * 
	 * 加载Image选项
	 * 
	 * @author jianfeng.lao
	 * @version 1.0
	 * @CreateDate 2013-3-10
	 */
	public static class Options {
		/**
		 * unit pixel 如果>0,在加载图片时会用android的压缩方法加载
		 */
		public float width = -1;
		/**
		 * unit pixel 如果>0,在加载图片时会用android的压缩方法加载
		 */
		public float height = -1;
		/**
		 * will recycle bitmap after BitmapCache full
		 */
		public boolean notPullSoftCache = false;
		
		public boolean autoOrientation=false;
		
		public boolean getMothedDownload=true;

		public Options() {
			super();
		}

		public Options(boolean notPullSoftCache) {
			super();
			this.notPullSoftCache = notPullSoftCache;
		}

		public Options(float width, float height) {
			super();
			this.width = width;
			this.height = height;
		}

		@Override
		public String toString() {
			return "Options --> witdh:" + width + " height:" + height;
		}

	}

	public Options getOptions() {
		return options;
	}

	public String getFilePath() {
		return filePath;
	}

	public String getDownLoadUrl() {
		return downLoadUrl;
	}

	public void setDownLoadUrl(String downLoadUrl) {
		this.downLoadUrl = downLoadUrl;
	}

	public void removeBitmapListener(BitmapInfoListener listener) {
		if (listeners == null) {
			return;
		}
		synchronized (listeners) {

			if (listeners.contains(listener)) {
				// Log.v(TAG, "size>>" + listeners.size() + ",removeBitmapListener>>" + listener + ",key>>"
				// + cacheKey);
				listeners.remove(listener);
			}
		}
	}

	public void removeAllBitmapListener() {
		if (listeners == null) {
			return;
		}
		listeners.clear();
	}

	public void setOptions(Options options) {
		this.options = options;
	}

	public void addBitmapInfoListener(BitmapInfoListener listener) {
		if (listeners == null) {
			return;
		}
		synchronized (listeners) {
			if (!listeners.contains(listener)) {
				// Log.v(TAG, "size>>" + listeners.size() + ",addBitmapInfoListener>>" + listener + ",key>>"
				// + cacheKey);
				listeners.add(listener);
			}
		}

	}

	public String getUiFlag() {
		return UIFlag;
	}

	public void setUiFlag(String uiFlag) {
		this.UIFlag = uiFlag;
	}

	public String getCacheKey() {
		return cacheKey;
	}

	public void setCacheKey(String cacheKey) {
		this.cacheKey = cacheKey;
	}

	public void setPath(String path) {
		this.filePath = path;
	}

	public boolean equals(String cacheKey) {
		if (getCacheKey().equals(cacheKey)) {
			return true;
		} else {
			return false;
		}
	}

	public void callBackOnLoad(Bitmap bitmap, CLBitmapInfo info) {

		if (listeners != null) {
			synchronized (listeners) {
				// Log.v("CLBitmapView", "size>>" + listeners.size() + ",callBackOnLoad>>" + info.getCacheKey());
				for (BitmapInfoListener listener : listeners) {
					listener.onBitmapLoad(info, bitmap);
				}
			}
		}
	}

	public void callBackDownload(CLBitmapInfo info, boolean isSuccess) {
		if (listeners != null) {
			synchronized (listeners) {
				// Log.v(TAG, "size>>" + listeners.size() + ",callBackDownload>>");
				for (BitmapInfoListener listener : listeners) {
					listener.onDownLoad(info, isSuccess);
				}
			}
		}
	}

	public void callBackBeforeRecycle(CLBitmapInfo info) {
		if (listeners != null) {
			synchronized (listeners) {
				for (BitmapInfoListener listener : listeners) {
					listener.beforeRecyle(info);
				}
			}

		}
	}

	@Override
	public String toString() {
		return "BitmapInfo [cacheKey=" + cacheKey + "]";
	}

	@Override
	public boolean equals(Object o) {
		if (o != null && o instanceof CLBitmapInfo) {
			CLBitmapInfo bi = (CLBitmapInfo) o;
			if (bi.getCacheKey().equals(getCacheKey())) {
				return true;
			}
		}
		return super.equals(o);
	}
	
	public static int readPictureDegree(String path) {
		int degree = 0;
		try {
			ExifInterface exifInterface = new ExifInterface(path);
			int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION,
					ExifInterface.ORIENTATION_NORMAL);
			switch (orientation) {
			case ExifInterface.ORIENTATION_ROTATE_90:
				degree = 90;
				break;
			case ExifInterface.ORIENTATION_ROTATE_180:
				degree = 180;
				break;
			case ExifInterface.ORIENTATION_ROTATE_270:
				degree = 270;
				break;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return degree;
	}

	
	
}
