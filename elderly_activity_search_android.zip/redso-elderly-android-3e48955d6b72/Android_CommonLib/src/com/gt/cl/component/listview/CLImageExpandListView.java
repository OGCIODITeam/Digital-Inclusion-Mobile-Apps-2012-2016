package com.gt.cl.component.listview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.ExpandableListView;

import com.gt.cl.component.imageview.bitmapview.CLBitmapView.CLItemBitmapViewInterface;

public class CLImageExpandListView extends ExpandableListView implements OnScrollListener {
	private static final String TAG = "CLImageExpandListView";

	private static final int MSG_CHECK_SCROLL_STATE = 0x00000001;
	private static final int CHECK_SCROLL_STATE_DELAY = 350;// 滚动时每隔50毫秒设置一次
	private int mFirstVisibleItem = -1;// 滚动时每隔50毫秒设置一次
	private int mVisibleItemCount = -1;
	private int mLastFirstVisibleItem = -1;
	private int mLastVisibleItemCount = -1;
	private boolean mIsScrolling = false;
	private boolean mEnableShowHeaderView = false;
	private OnListViewScrollListener mScrollListener;
	private View mCurrentHeaderView;
	private CLImageExpandListViewHeaderListener mHeaderListener;
	private int mCurrentHeaderPosition = -1;
	private Rect mHeaderRect;
	private int mHeaderHeightOffset = 0;

	/**
	 * true 如果childView是实现CLItemBitmapViewInterface会自动loadImage
	 */
	private boolean mIsAutoLoadImage = false;

	public CLImageExpandListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		setupListener();
	}

	public CLImageExpandListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupListener();
	}

	public CLImageExpandListView(Context context) {
		super(context);
		setupListener();
	}

	private void setupListener() {
		super.setOnScrollListener(this);
	}

	public void sendScrollStatusMsg(int firstVisibleIndex, int visibleCount) {
		mLastFirstVisibleItem = firstVisibleIndex;
		mLastVisibleItemCount = visibleCount;
		if (mLastFirstVisibleItem == mFirstVisibleItem && mLastVisibleItemCount == mVisibleItemCount) {
			return;
		}
		if (!mIsScrolling && !handler.hasMessages(MSG_CHECK_SCROLL_STATE)) {
			// Log.i(TAG, "sendScrollStatusMsg>>" + firstVisibleIndex + "," + visibleCount);
			handler.sendEmptyMessage(MSG_CHECK_SCROLL_STATE);
		}

	}

	public void removeScrollStatusMsg() {
		if (handler != null) {
			handler.removeMessages(MSG_CHECK_SCROLL_STATE);
		}
	}

	private Handler handler = new Handler() {

		@Override
		public void dispatchMessage(Message msg) {
			switch (msg.what) {
			case MSG_CHECK_SCROLL_STATE:
				// Log.i(TAG,lastFirstVisibleItem+","+lastVisibleItemCount+"  "+firstVisibleItem+","+visibleItemCount);
				if (mLastFirstVisibleItem != mFirstVisibleItem || mLastVisibleItemCount != mVisibleItemCount) {
					mFirstVisibleItem = mLastFirstVisibleItem;
					mVisibleItemCount = mLastVisibleItemCount;
					mIsScrolling = true;
					sendEmptyMessageDelayed(MSG_CHECK_SCROLL_STATE, CHECK_SCROLL_STATE_DELAY);
				} else {
					if (mIsAutoLoadImage) {
						int i = 0, size = getChildCount();
						// Log.v(TAG, "AutoLoadImage size>>"+size);
						for (; i < size; i++) {
							View child = getChildAt(i);
							if (child instanceof CLItemBitmapViewInterface) {
								CLItemBitmapViewInterface clbvi = (CLItemBitmapViewInterface) child;
								if (clbvi.getItemBitmapView() != null) {
									// Log.v(TAG,
									// "load image >>"+clbvi.getItemBitmapView().getBitmapInfo().getCacheKey());
									clbvi.getItemBitmapView().loadImageOneByOne();
								}
							}
						}
					}
					if (mScrollListener != null) {
						mScrollListener.onScrollWidthDelay(mFirstVisibleItem, mVisibleItemCount);
					}
					mIsScrolling = false;
				}
				// Log.i(TAG, "isScrolling ==" + mIsScrolling);
				break;
			}

			super.dispatchMessage(msg);
		}
	};

	public interface OnListViewScrollListener {
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount);

		public void onScrollStateChanged(AbsListView view, int scrollState);

		public void onScrollWidthDelay(int firstVisibleItem, int visibleItemCount);
	}

	public void setOnListViewScrollListener(OnListViewScrollListener scrollListener) {
		this.mScrollListener = scrollListener;
	}

	public void resetScrollAttribute() {
		mFirstVisibleItem = -1;
		mVisibleItemCount = -1;
		mLastFirstVisibleItem = -1;
		mLastVisibleItemCount = -1;
		mIsScrolling = false;
	}

	/**
	 * 
	 * @param mIsAutoLoadImage true 如果childView是实现CLItemBitmapViewInterface会自动loadImage
	 * @author jianfeng.lao
	 * @CreateDate 2013-5-2
	 */
	public void setIsAutoLoadImage(boolean mIsAutoLoadImage) {
		this.mIsAutoLoadImage = mIsAutoLoadImage;
	}

	public boolean isIsAutoLoadImage() {
		return mIsAutoLoadImage;
	}

	@Override
	protected void dispatchDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.dispatchDraw(canvas);
		if (mCurrentHeaderView != null) {
			int saveCount = canvas.save();
			canvas.translate(0, -mHeaderHeightOffset);
			// needed for < HONEYCOMB
			canvas.clipRect(0, 0, mCurrentHeaderView.getWidth(), mCurrentHeaderView.getHeight());
			mCurrentHeaderView.draw(canvas);
			canvas.restoreToCount(saveCount);
		}
	}

	private View getCurrentHeaderView(int groupPosition, View convertView, Rect rect) {
		View view = convertView;
		if (mHeaderListener != null && groupPosition != mCurrentHeaderPosition) {
			// Log.v(TAG, "rect>>" + rect);
			mCurrentHeaderPosition = groupPosition;
			view = mHeaderListener.getHeader(groupPosition, convertView);
			if (view.isLayoutRequested()) {
				view.setLayoutParams(new LayoutParams(rect.width(), rect.height()));
				int widthSpec = MeasureSpec.makeMeasureSpec(rect.width(), MeasureSpec.EXACTLY);
				int heightSpec = MeasureSpec.makeMeasureSpec(rect.height(), MeasureSpec.EXACTLY);
				view.measure(widthSpec, heightSpec);
				view.layout(0, 0, rect.width(), rect.height());
			}
		}
		return view;
	}

	public interface CLImageExpandListViewHeaderListener {
		public View getHeader(int groupPos, View convertView);
	}

	/**
	 * 设置这个listener就可以实现有浮动header效果
	 * 
	 * @param mHeaderListener
	 * @author jianfeng.lao
	 * @CreateDate 2013-7-12
	 */
	public void setHeaderListener(CLImageExpandListViewHeaderListener mHeaderListener) {
		this.mHeaderListener = mHeaderListener;
		if (mHeaderListener != null) {
			mEnableShowHeaderView = true;
		} else {
			mEnableShowHeaderView = false;
		}
	}

	/**
	 * 重新设置浮动header效果
	 * 
	 * @author jianfeng.lao
	 * @CreateDate 2013-7-12
	 */
	public void resetHeaderState() {
		mCurrentHeaderView = null;
		mCurrentHeaderPosition = -1;
		onScroll(this, getFirstVisiblePosition(), getChildCount(), getCount());
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
		if (mScrollListener != null || mIsAutoLoadImage) {
			if (mScrollListener != null) {
				mScrollListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
			}

			int ptp = view.pointToPosition(0, 0);
			// Log.i(TAG, "firstVisibleItem:" + firstVisibleItem + " visibleItemCount:" + visibleItemCount +
			// " totalItemCount:" + totalItemCount);

			if (ptp != AdapterView.INVALID_POSITION) {
				if (mEnableShowHeaderView && getExpandableListAdapter() != null
						&& getExpandableListAdapter().getGroupCount() > 0) {
					long pos = getExpandableListPosition(ptp);
					int groupPos = ExpandableListView.getPackedPositionGroup(pos);
					int childPos = ExpandableListView.getPackedPositionChild(pos);
					int childSize = getExpandableListAdapter().getChildrenCount(groupPos);
					// Log.v(TAG, "mCurrentHeaderPosition>>" + mCurrentHeaderPosition + ",groupPos>>" + groupPos
					// + ",childPos>>" + childPos + ",childSize>>" + childSize);
					Rect r = new Rect();
					View topChildview = view.getChildAt(0);
					topChildview.getHitRect(r);
					if (childPos == -1 || groupPos != mCurrentHeaderPosition) {
						if (childPos == -1 && mHeaderRect == null) {
							mHeaderRect = new Rect(r);
						}
						mCurrentHeaderView = getCurrentHeaderView(groupPos, mCurrentHeaderView, mHeaderRect);
					}
					if (childPos == (childSize - 1)) {
						/*
						 * 这里有一个好怪的bug,如果listview 设置dividerHeight为0,会出现顶部刚刚到最后一个childview,但
						 * childView.bottom==0
						 */
						if (r.bottom <= mHeaderRect.height() && r.bottom >= 0) {
							mHeaderHeightOffset = mHeaderRect.height() - r.bottom;
						} else {
							mHeaderHeightOffset = 0;
						}
					} else if (childPos == 0 || childPos == (childSize - 2) || (childPos == -1)) {
						mHeaderHeightOffset = 0;
					}

				}
				sendScrollStatusMsg(firstVisibleItem, visibleItemCount);
			}
		}
	}

	public void removeCheckScrollMsg() {
		handler.removeMessages(MSG_CHECK_SCROLL_STATE);
	}

	@Deprecated
	public void setOnScrollListener(OnScrollListener l) {
		// TODO Auto-generated method stub
	}
}
