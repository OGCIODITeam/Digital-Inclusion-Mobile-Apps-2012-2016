package com.gt.cl.component.imageview.bitmapview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.FloatMath;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.ImageView;

import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo.BitmapInfoListener;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfo.Options;
import com.gt.cl.component.imageview.bitmapview.info.CLBitmapInfoManager;
import com.gt.cl.component.imageview.bitmapview.loader.CLBitmapLoader;

/**
 * CLItemBitmapView是一个拥有异步下载,缓存,异步加载,销毁图片功能的ImageView
 * 
 * @author jianfeng.lao
 * @version 1.0
 * @CreateDate 2013-5-6
 */
public class CLBitmapView extends ImageView implements BitmapInfoListener {
	private final static String TAG = "CLBitmapView";

	private ScaleType mLoadSuccessScaleType;
	private ScaleType mDefaultIconScaleType;
	/**
	 * 加载Bitmap的UI标志符
	 */
	private String mUIFlag;
	private CLBitmapInfo mBitmapInfo;
	private SetBitmapRunnable mSetBitmapRunnable;
	private boolean mHasUserDefalutBitmap = false;
	private Bitmap mUserDefalutBitmap = null;
	private int mUserDefalutImageResource = -1;
	private boolean mEnableScaleAndZoom = false;
	private boolean mIsLoadBitmapSuccess = false;

	private Matrix currentMatrix = new Matrix();// 当前matrix
	private Matrix savedMatrix = new Matrix();// 保存前一个matrix
	private PointF mPrePoint = new PointF();// 前一个点
	private PointF mMidPoint = new PointF();// 两指中点

	private int mBitmapHeight = 0;
	private int mBitmapWidth = 0;
	private Matrix mFitScreenSizeMatrix = null;

	private float minScaleR = 1.0f;// 初始最小缩放
	private float dist = 1f;// 两指距离

	private static float MAX_SCALE = 3f;
	private static final int NONE = 0;
	private static final int DRAG = 1;
	private static final int ZOOM = 2;

	public static final int ZOOM_FIT = 0x0001000;
	public static final int ZOOM_IN = 0x0002000;
	public static final int ZOOM_OUT = 0x0003000;

	public static final int DRAG_ACTION_NONE = 0x00000000;
	public static final int DRAG_ACTION_OVER_LEFT = 0x00000001;
	public static final int DRAG_ACTION_OVER_RIGHT = 0x00000010;
	public static final int DRAG_ACTION_OVER_TOP = 0x00000100;
	public static final int DRAG_ACTION_OVER_BOTTOM = 0x00001000;

	private int mDragAction = DRAG_ACTION_NONE;
	private int mZoomAction = ZOOM_FIT;

	private int mode = NONE;

	public CLBitmapView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	public CLBitmapView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public CLBitmapView(Context context) {
		super(context);
		init();
	}

	private void initScaleAndZoomAttribute(Bitmap bitmap) {
		if (bitmap == null) {
			return;
		}
		if (mEnableScaleAndZoom) {
			if (mFitScreenSizeMatrix == null) {
				mFitScreenSizeMatrix = new Matrix();
			}
			mFitScreenSizeMatrix.reset();
			if (bitmap != null) {
				mBitmapHeight = bitmap.getHeight();
				mBitmapWidth = bitmap.getWidth();
				setImageBitmap(bitmap);
			}
			float wScale = (float) getWidth() / (float) mBitmapWidth;
			float hScale = (float) getHeight() / (float) mBitmapHeight;
			float fitSrceenScale = wScale > hScale ? hScale : wScale;
			minScaleR = fitSrceenScale;
			mFitScreenSizeMatrix.setScale(fitSrceenScale, fitSrceenScale);
			mFitScreenSizeMatrix.postTranslate((getWidth() - mBitmapWidth * fitSrceenScale) / 2,
					(getHeight() - mBitmapHeight * fitSrceenScale) / 2);
			setImageMatrix(mFitScreenSizeMatrix);
			currentMatrix.set(mFitScreenSizeMatrix);
		}
	}

	public void setFitScreenSize() {
		if (mEnableScaleAndZoom && mFitScreenSizeMatrix != null) {
			mode = NONE;
			mDragAction = DRAG_ACTION_NONE;
			mZoomAction = ZOOM_FIT;
			currentMatrix.set(mFitScreenSizeMatrix);
			savedMatrix.set(mFitScreenSizeMatrix);
			setImageMatrix(mFitScreenSizeMatrix);
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		Log.v(TAG, "onTouchEvent>>" + event.getY());
		if (mEnableScaleAndZoom && mIsLoadBitmapSuccess) {
			switch (event.getAction() & MotionEvent.ACTION_MASK) {
			case MotionEvent.ACTION_DOWN:
				// Log.v(TAG, "ACTION_DOWN>>");
				savedMatrix.set(currentMatrix);
				mPrePoint.set(event.getX(), event.getY());
				mode = DRAG;
				break;
			case MotionEvent.ACTION_POINTER_DOWN:
				// Log.v(TAG, "ACTION_POINTER_DOWN>>");
				dist = spacing(event);
				if (spacing(event) > 10f) {
					savedMatrix.set(currentMatrix);
					midPoint(mMidPoint, event);
					mode = ZOOM;
				}
				break;
			case MotionEvent.ACTION_UP: {
				mDragAction = DRAG_ACTION_NONE;
				mode = NONE;
				break;
			}
			case MotionEvent.ACTION_POINTER_UP:
				mDragAction = DRAG_ACTION_NONE;
				mode = NONE;
				break;
			case MotionEvent.ACTION_MOVE:
				// Log.v(TAG, "ACTION_MOVE>>");
				if (mode == DRAG) {
					currentMatrix.set(savedMatrix);
					currentMatrix.postTranslate(event.getX() - mPrePoint.x, event.getY()
							- mPrePoint.y);
				} else if (mode == ZOOM) {
					float newDist = spacing(event);
					if (newDist > 10f) {
						currentMatrix.set(savedMatrix);
						float tScale = newDist / dist;
						float[] martix = new float[9];
						float[] p = new float[9];
						currentMatrix.getValues(martix);
						getImageMatrix().getValues(p);
						// Log.e(TAG, "currentMatrix>>" + currentMatrix.toShortString());
						// Log.e(TAG, "tScale>>" + tScale + ",mid point>>(" + mMidPoint.x + "," + mMidPoint.y
						// + ")");
						if (p[Matrix.MSCALE_X] <= MAX_SCALE || martix[Matrix.MSCALE_X] * tScale <= MAX_SCALE) {
							currentMatrix.postScale(tScale, tScale, mMidPoint.x, mMidPoint.y);
						} else {
							currentMatrix.set(getImageMatrix());
						}

					}
				}
				break;
			}
			checkView();
			setImageMatrix(currentMatrix);

			Matrix m = new Matrix();
			m.set(currentMatrix);
			RectF rect = new RectF(0, 0, mBitmapWidth, mBitmapHeight);
			m.mapRect(rect);

			mDragAction = DRAG_ACTION_NONE;
			if (Math.rint(rect.bottom) == getHeight()) {
				Log.v(TAG, "to bottom>>");
				mDragAction |= DRAG_ACTION_OVER_BOTTOM;
			}
			if (Math.rint(rect.top) == 0) {
				mDragAction |= DRAG_ACTION_OVER_TOP;
			}
			if (Math.rint(rect.left) == 0) {
				mDragAction |= DRAG_ACTION_OVER_LEFT;
			}
			if (Math.rint(rect.right) == getWidth()) {
				mDragAction |= DRAG_ACTION_OVER_RIGHT;
			}
			// Log.v(TAG, "bottom>>"+Math.rint(rect.bottom));
			// Log.v(TAG, "currentMatrix rect>>" + rect + ",height>>" + getHeight()+",mDragAction>>"+mDragAction);
			float[] fitMatrixValue = new float[9];
			mFitScreenSizeMatrix.getValues(fitMatrixValue);
			float[] curMatrixValue = new float[9];
			currentMatrix.getValues(curMatrixValue);
			if (curMatrixValue[Matrix.MSCALE_X] == fitMatrixValue[Matrix.MSCALE_X]) {
				mZoomAction = ZOOM_FIT;
			} else if (curMatrixValue[Matrix.MSCALE_X] > fitMatrixValue[Matrix.MSCALE_X]) {
				mZoomAction = ZOOM_IN;
			} else {
				mZoomAction = ZOOM_OUT;
			}
			return true;
		} else {
			return super.onTouchEvent(event);
		}
	}

	private void init() {
		mSetBitmapRunnable = new SetBitmapRunnable();
	}

	/**
	 * 设置UI flag
	 * 
	 * @param uiFlag 加载Bitmap的UI标志符
	 * @author jianfeng.lao
	 * @CreateDate 2013-4-27
	 */
	public void setUiFlag(String uiFlag) {
		this.mUIFlag = uiFlag;
	}

	/**
	 * 设置BitmapInfo并且从cache中获取bitmap
	 * 
	 * @param cacheKey 每个BitmapInfo只有唯一key
	 * @param url 下载image url
	 * @param filePath 保存路径
	 * @param options bitmap可选参数
	 * @author jianfeng.lao
	 * @CreateDate 2013-4-27
	 */
	public void setBitmapInfo(String cacheKey, String url, String filePath, Options options) {
		// Log.i(TAG, "setBitmapInfo>>" + cacheKey);
		CLBitmapInfo biCache = CLBitmapInfoManager.getInstance().getBitmapInfo(cacheKey);
		if (mBitmapInfo != null) {
			CLBitmapInfo tmp = CLBitmapInfoManager.getInstance().getBitmapInfo(mBitmapInfo.getCacheKey());
			if (tmp != null) {
				tmp.removeBitmapListener(this);
			}
		}
		if (mBitmapInfo != null && mBitmapInfo.equals(biCache)) {
			// Log.v(TAG, "mBitmapInfo!=null && biCache==mBitmapInfo");
			biCache.removeBitmapListener(this);
			this.mBitmapInfo = biCache;
		} else if (biCache != null) {
			// Log.v(TAG, "biCache != null");
			biCache.removeBitmapListener(this);
			this.mBitmapInfo = biCache;
		} else if(cacheKey!=null&&filePath!=null){
			// Log.v(TAG, "new mBitmapInfo");
			mBitmapInfo = new CLBitmapInfo(cacheKey, url, filePath, options);
			CLBitmapInfoManager.getInstance().addBitmapInfo(mBitmapInfo);
		}else{
			mBitmapInfo=null;
		}
		if (mBitmapInfo != null) {
			mBitmapInfo.addBitmapInfoListener(this);
			mBitmapInfo.setUiFlag(mUIFlag);
		}

		loadImageFromCache();
	}

	/**
	 * load image form cache
	 * 
	 * @author jianfeng.lao
	 * @CreateDate 2013-4-27
	 */
	public void loadImageFromCache() {
		if (mBitmapInfo != null) {
			boolean success = CLBitmapLoader.getInstance().loadBitmapFromCache(mBitmapInfo);
			if (!success) {
				setDefalutBitmap();
			}
		}else{
			setDefalutBitmap();
		}
	}

	public void setDefalutBitmap() {
		// Log.d(TAG, "setDefalutBitmap info" + mBitmapInfo);
		// if (mBitmapInfo != null && mIsLoadBitmapSuccess) {
		// CLBitmapInfoManager.getInstance().getBitmapInfo(mBitmapInfo.getCacheKey()).removeBitmapListener(this);
		// }
		mIsLoadBitmapSuccess = false;
		setDefalutIconScaleType();
		if (!mHasUserDefalutBitmap) {
			setImageBitmap(CLBitmapLoader.getInstance().getDefaultBitmap());
		} else {
			if (mUserDefalutImageResource > 0) {
				setImageResource(mUserDefalutImageResource);
			} else {
				setImageBitmap(mUserDefalutBitmap);
			}
		}
	}

	/**
	 * recycle bitmap from cache
	 * 
	 * @author jianfeng.lao
	 * @CreateDate 2013-5-2
	 */
	public void destory() {
		if (mBitmapInfo != null) {
			CLBitmapLoader.getInstance().recycleBitmapInfo(mBitmapInfo);
		}
	}

	public interface CLItemBitmapViewInterface {
		public CLBitmapView getItemBitmapView();
	}

	public void setScaleType(ScaleType defaultIconScaleType, ScaleType loadSuccessScaleType) {
		this.mLoadSuccessScaleType = loadSuccessScaleType;
		this.mDefaultIconScaleType = defaultIconScaleType;
	}

	public void setViewPagerScaleType() {
		setScaleType(ScaleType.CENTER_INSIDE, ScaleType.FIT_CENTER);
	}

	private void setDefalutIconScaleType() {
		if (mDefaultIconScaleType != null) {
			super.setScaleType(mDefaultIconScaleType);
		}
	}

	private void setLoadImageSuccessScaleType() {
		if (mLoadSuccessScaleType != null) {
			super.setScaleType(mLoadSuccessScaleType);
		}
	}

	/**
	 * 
	 * 使用BitmapLoader加载图片
	 * 
	 * @author jianfeng.lao
	 * @CreateDate 2013-4-27
	 */
	public void loadImageOneByOne() {
		if (mBitmapInfo == null) {
			return;
		}
		if (!CLBitmapLoader.getInstance().loadBitmapFromCache(mBitmapInfo)) {
			// Log.v(TAG, "loadImageOneByOne>>" + mBitmapInfo.getCacheKey());
			mSetBitmapRunnable.setBitmap(null);
			post(mSetBitmapRunnable);
			CLBitmapLoader.getInstance().addLoaderTask(mBitmapInfo);
		}

	}

	@Override
	public void onDownLoad(CLBitmapInfo info, boolean isSuccess) {
		Log.v(TAG, "onDownLoad info url>>" + info.getDownLoadUrl());
		Log.v(TAG, "onDownLoad view url>>" + mBitmapInfo.getDownLoadUrl());
		if (isSuccess) {
			loadImageOneByOne();
		}
	}

	@Override
	public void onBitmapLoad(CLBitmapInfo info, final Bitmap bitmap) {
		Log.i(TAG, "onBitmapLoad>>" + info);
		if (mBitmapInfo != null && mBitmapInfo.equals(info)) {
			mSetBitmapRunnable.setBitmap(bitmap);
			post(mSetBitmapRunnable);
		} else {
			Log.i(TAG, "onBitmapLoad>>key not campare");
		}
	}

	@Override
	public void beforeRecyle(CLBitmapInfo info) {
		// Log.d(TAG, "beforeRecyle>>" + info);
		if (mBitmapInfo != null && mBitmapInfo.equals(info)) {
			mSetBitmapRunnable.setBitmap(null);
			post(mSetBitmapRunnable);
		} else {
			Log.d(TAG, "cache key not available,do not set defalut icon");
		}
	}

	private class SetBitmapRunnable implements Runnable {
		private Bitmap bitmap;

		public void run() {
			setImage(bitmap);
		}

		public void setBitmap(Bitmap bitmap) {
			this.bitmap = bitmap;
		}

	}

	public void setImage(Bitmap bitmap) {
		if (bitmap == null) {
			setDefalutBitmap();
		} else {
			if (!mEnableScaleAndZoom) {
				setLoadImageSuccessScaleType();
				setImageBitmap(bitmap);
			} else {
				setScaleType(ScaleType.MATRIX);
				initScaleAndZoomAttribute(bitmap);
			}
			mIsLoadBitmapSuccess = true;

		}
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
	}

	public CLBitmapInfo getBitmapInfo() {
		return mBitmapInfo;
	}

	/**
	 * 设置自定defalut image
	 * 
	 * @param bitmap
	 * @param useUserDefalutImage 如果true,用自定义image作为缩略图,否则用CLBitmapLoader提供的defalut thumbnail
	 * @author jianfeng.lao
	 * @CreateDate 2013-5-27
	 */
	public void setUserDefalutBitmap(Bitmap bitmap, boolean useUserDefalutImage) {
		this.mHasUserDefalutBitmap = useUserDefalutImage;
		this.mUserDefalutBitmap = bitmap;
	}

	/**
	 * 设置自定defalut image
	 * 
	 * @param resourceId
	 * @param useUserDefalutImage 如果true,用自定义image作为缩略图,否则用CLBitmapLoader提供的defalut thumbnail
	 * @author jianfeng.lao
	 * @CreateDate 2013-5-27
	 */
	public void setUserDefalutBitmap(int resourceId, boolean useUserDefalutImage) {
		this.mHasUserDefalutBitmap = useUserDefalutImage;
		this.mUserDefalutImageResource = resourceId;
	}

	public Bitmap getUserDefalutBitmap() {
		return mUserDefalutBitmap;
	}

	public void setEnableScaleAndZoom(boolean mEnableScale) {
		this.mEnableScaleAndZoom = mEnableScale;
	}

	protected void center(boolean horizontal, boolean vertical) {
		// 图片居中
		Matrix m = new Matrix();
		m.set(currentMatrix);
		RectF rect = new RectF(0, 0, mBitmapWidth, mBitmapHeight);
		m.mapRect(rect);

		float height = rect.height();
		float width = rect.width();
		// Log.v(TAG, "currentMatrix>>" + currentMatrix.toShortString());
		Log.d(TAG, "rect>>" + rect);
		// Log.i(TAG, "getWidth>>" + getWidth() + ",getHeight>>" + getHeight() + ",width>>" + width + ",height>>" +
		// height);
		float deltaX = 0, deltaY = 0;
		if (vertical) {
			if (height < getHeight()) {
				deltaY = (getHeight() - height) / 2 - rect.top;
				Log.i(TAG, deltaY + "..." + height + "..." + mBitmapHeight);
			} else if (rect.top > 0) {
				deltaY = -rect.top;
			} else if (rect.bottom < getHeight()) {
				deltaY = this.getHeight() - rect.bottom;
			}
		}

		if (horizontal) {
			if (width < getWidth()) {
				deltaX = (getWidth() - width) / 2 - rect.left;
				// Log.i(TAG, deltaX + "..." + width + "..." + mBitmapWidth);
			} else if (rect.left > 0) {
				deltaX = -rect.left;
			} else if (rect.right < getWidth()) {
				deltaX = getWidth() - rect.right;
			}
		}
		currentMatrix.postTranslate(deltaX, deltaY);
	}

	// 检查缩放范围并且居中
	private void checkView() {
		float p[] = new float[9];
		currentMatrix.getValues(p);
		// Log.v(TAG, "scaleX>>" + p[Matrix.MSCALE_X] + ",translateX>>" + p[Matrix.MTRANS_X] + ",translateY"
		// + p[Matrix.MTRANS_Y]);
		if (mode == ZOOM) {
			if (p[Matrix.MSCALE_X] < minScaleR) {
				currentMatrix.setScale(minScaleR, minScaleR);
				mZoomAction = ZOOM_FIT;
			} else {

			}
		}
		center(true, true);
	}

	// 计算两指距离
	private float spacing(MotionEvent event) {
		float x = 0;
		float y = 0;
		try {
			x = event.getX(0) - event.getX(1);
			y = event.getY(0) - event.getY(1);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return FloatMath.sqrt(x * x + y * y);
	}

	// 计算两指中点
	private void midPoint(PointF point, MotionEvent event) {
		float x = 0;
		float y = 0;
		try {
			x = event.getX(0) + event.getX(1);
			y = event.getY(0) + event.getY(1);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		point.set(x / 2, y / 2);
	}

	public void unRegisterBitmapInfoListener() {
		if (mBitmapInfo != null) {
			CLBitmapInfoManager.getInstance().getBitmapInfo(mBitmapInfo.getCacheKey()).removeBitmapListener(this);
		}
	}

	public static void setMaxScale(float maxScale) {
		MAX_SCALE = maxScale;
	}

	public boolean isDraging() {
		return mode == DRAG;
	}

	public int getDragAction() {
		return mDragAction;
	}

	public int getZoomAction() {
		return mZoomAction;
	}

}
