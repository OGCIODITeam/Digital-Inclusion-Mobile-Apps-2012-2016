package com.gt.cl.component.listview;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.gt.cl.component.imageview.bitmapview.CLBitmapView.CLItemBitmapViewInterface;

public class CLImageListView extends ListView {
	private static final String TAG = "CLImageListView";

	private static final int MSG_CHECK_SCROLL_STATE = 0x00000001;
	private static final int CHECK_SCROLL_STATE_DELAY = 350;// 滚动时每隔50毫秒设置一次
	private int mFirstVisibleItem = -1;// 滚动时每隔50毫秒设置一次
	private int mVisibleItemCount = -1;
	private int mLastFirstVisibleItem = -1;
	private int mLastVisibleItemCount = -1;
	private boolean mIsScrolling = false;
	private OnListViewScrollListener mScrollListener;
	/**
	 * true 如果childView是实现CLItemBitmapViewInterface会自动loadImage
	 */
	private boolean mIsAutoLoadImage = false;
	
	// 滑动距离及坐标  
    private float xDistance;
    private float yDistance;
    private float xLast;
    private float yLast; 

	public CLImageListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		setupListener();
	}

	public CLImageListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setupListener();
	}

	public CLImageListView(Context context) {
		super(context);
		setupListener();
	}

	private void setupListener() {
		super.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (mScrollListener != null) {
					mScrollListener.onScrollStateChanged(view, scrollState);
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				if (mScrollListener != null || mIsAutoLoadImage) {
					if (mScrollListener != null) {
						mScrollListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
					}

					int ptp = view.pointToPosition(0, 0);
					// Log.i(TAG, "firstVisibleItem:" + firstVisibleItem + " visibleItemCount:" + visibleItemCount +
					// " totalItemCount:" + totalItemCount);
					if (ptp != AdapterView.INVALID_POSITION) {
						// if (obtainDataListener != null && obtainDataThread.isInitServerContext()) {
						sendScrollStatusMsg(firstVisibleItem, visibleItemCount);

						// }
					}
				}

			}
		});
	}

	public void sendScrollStatusMsg(int firstVisibleIndex, int visibleCount) {
		mLastFirstVisibleItem = firstVisibleIndex;
		mLastVisibleItemCount = visibleCount;
		if (mLastFirstVisibleItem == mFirstVisibleItem && mLastVisibleItemCount == mVisibleItemCount) {
			return;
		}
		if (!mIsScrolling && !handler.hasMessages(MSG_CHECK_SCROLL_STATE)) {
			Log.i(TAG, "sendScrollStatusMsg>>" + firstVisibleIndex + "," + visibleCount);
			handler.sendEmptyMessage(MSG_CHECK_SCROLL_STATE);
		}

	}

	private Handler handler = new Handler() {

		@Override
		public void dispatchMessage(Message msg) {
			switch (msg.what) {
			case MSG_CHECK_SCROLL_STATE:
				// Log.i(TAG,lastFirstVisibleItem+","+lastVisibleItemCount+"  "+firstVisibleItem+","+visibleItemCount);
				if (mLastFirstVisibleItem != mFirstVisibleItem || mLastVisibleItemCount != mVisibleItemCount) {
					mFirstVisibleItem = mLastFirstVisibleItem;
					mVisibleItemCount = mLastVisibleItemCount;
					mIsScrolling = true;
					sendEmptyMessageDelayed(MSG_CHECK_SCROLL_STATE, CHECK_SCROLL_STATE_DELAY);
				} else {
					if (mIsAutoLoadImage) {
						int i = 0, size = getChildCount();
//						Log.v(TAG, "AutoLoadImage size>>"+size);
						for (; i < size&&getVisibility()==View.VISIBLE; i++) {
							View child = getChildAt(i);
							if (child instanceof CLItemBitmapViewInterface) {
								CLItemBitmapViewInterface clbvi = (CLItemBitmapViewInterface) child;
								if (clbvi.getItemBitmapView() != null) {
//									Log.v(TAG, "load image >>"+clbvi.getItemBitmapView().getBitmapInfo().getCacheKey());
									clbvi.getItemBitmapView().loadImageOneByOne();
								}
							}
						}
					}
					if (mScrollListener != null) {
						mScrollListener.onScrollWidthDelay(mFirstVisibleItem, mVisibleItemCount);
					}
					mIsScrolling = false;
				}
				Log.i(TAG, "isScrolling ==" + mIsScrolling);
				break;
			}

			super.dispatchMessage(msg);
		}
	};

	public interface OnListViewScrollListener {
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount);
		public void onScrollStateChanged(AbsListView view, int scrollState);
		public void onScrollWidthDelay(int firstVisibleItem, int visibleItemCount);
	}

	public void setOnListViewScrollListener(OnListViewScrollListener scrollListener) {
		this.mScrollListener = scrollListener;
	}

	public void resetScrollAttribute() {
		mFirstVisibleItem = -1;
		mVisibleItemCount = -1;
		mLastFirstVisibleItem = -1;
		mLastVisibleItemCount = -1;
		mIsScrolling = false;
	}
	
	public void removeCheckScrollMsg(){
		handler.removeMessages(MSG_CHECK_SCROLL_STATE);
	}

	/**
	 * 
	 * @param mIsAutoLoadImage true 如果childView是实现CLItemBitmapViewInterface会自动loadImage
	 * @author jianfeng.lao
	 * @CreateDate 2013-5-2
	 */
	public void setIsAutoLoadImage(boolean mIsAutoLoadImage) {
		this.mIsAutoLoadImage = mIsAutoLoadImage;
	}

	public boolean isIsAutoLoadImage() {
		return mIsAutoLoadImage;
	}
	
	
	@Deprecated
	public void setOnScrollListener(OnScrollListener l) {
		// TODO Auto-generated method stub
	}
	
	
	/**
	 * 解决ListView 和 ViewPager 结合触摸不灵活的问题。
	 */
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {  
        case MotionEvent.ACTION_DOWN:  
            xDistance = yDistance = 0f;  
            xLast = ev.getX();  
            yLast = ev.getY();  
            break;
            
        case MotionEvent.ACTION_MOVE:  
            final float curX = ev.getX();  
            final float curY = ev.getY();  
              
            xDistance += Math.abs(curX - xLast);  
            yDistance += Math.abs(curY - yLast);  
            xLast = curX;  
            yLast = curY;  
              
            if(xDistance > yDistance){  
                return false;  
            }
    }
    return super.onInterceptTouchEvent(ev);
	}

}
