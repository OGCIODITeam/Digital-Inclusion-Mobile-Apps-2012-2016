package com.gt.cl.http;

public interface CLHttpProcessListener {
	public void onProcessChange(int process, long max);
}
