package com.gt.cl.http;

public class CLInvalidNetworkException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6544198128840094181L;

	
}
