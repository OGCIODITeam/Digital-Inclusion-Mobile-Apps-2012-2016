package com.gt.cl.xml;

import java.io.Serializable;

public interface CLXMLPojo extends Serializable {
	
	public void set(String key, Object value);
	
}
