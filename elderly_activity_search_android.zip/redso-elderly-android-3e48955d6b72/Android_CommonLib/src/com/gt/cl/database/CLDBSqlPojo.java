package com.gt.cl.database;

import java.io.Serializable;

public interface CLDBSqlPojo extends Serializable {
	
	public void set(String key, Object value);
	
}
