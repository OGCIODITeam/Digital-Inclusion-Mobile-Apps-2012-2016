package com.facebook.gt.widget;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.android.AsyncFacebookRunner;
import com.facebook.android.AsyncFacebookRunner.RequestListener;
import com.facebook.android.FacebookError;
import com.facebook.android.R;
import com.facebook.gt.facebook.FacebookManager;
import com.facebook.gt.facebook.ForceCloseIOException;

public class ShareDialog extends Dialog {
	private final int WORD_MAX = 140;
	private int mWordCount = WORD_MAX;
	private EditText editText;
	private TextView countText;
	private ImageView imageView;
	private Button button_send;
	private Button button_cancel;
	private ImageView button_close;
	private OnshareCompleteListener onshareCompleteListener;
	private Bitmap bitmap;
	private RelativeLayout relativeLayout;
	private LinearLayout linearLayout;
	private FrameLayout frameLayout;
	private int FacebookManagerCODE = FacebookManager.MSG_SHARE_PHOTO_FB_ERROR;
	AsyncFacebookRunner mAsyncRunner;

	public ShareDialog(Context context, Bitmap bitmap, AsyncFacebookRunner mAsyncRunner) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		// TODO Auto-generated constructor stub
		this.bitmap = bitmap;
		this.mAsyncRunner = mAsyncRunner;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gt_facebook_share_dialog);
		frameLayout = (FrameLayout) findViewById(R.id.share_dialog_ly);
		relativeLayout = (RelativeLayout) findViewById(R.id.share_loading);
		linearLayout = (LinearLayout) findViewById(R.id.share_content_ly);
		DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
		frameLayout.setPadding((int) (metrics.widthPixels / 1000.0 * 20), (int) (metrics.heightPixels / 1000.0 * 25), (int) (metrics.widthPixels / 1000.0 * 20), (int) (metrics.heightPixels / 1000.0 * 25));
		editText = (EditText) findViewById(R.id.share_text);
		countText = (TextView) findViewById(R.id.share_counttext);
		imageView = (ImageView) findViewById(R.id.share_image);
		button_send = (Button) findViewById(R.id.share_send);
		button_cancel = (Button) findViewById(R.id.share_cancle);
		button_close = (ImageView) findViewById(R.id.share_dialog_close_button);

		imageView.setImageBitmap(bitmap);

		button_send.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// 隐藏键盘
				InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
				getShareDialog().showLoading();
				Log.i("adc", "facebook upload>>>shareContent>>" + editText.getText().toString());
				Bundle params = new Bundle();
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				byte[] data = null;
				bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
				data = baos.toByteArray();
				// put进去
				params.putByteArray("photo", data);
				// title
				params.putString("caption", editText.getText().toString());
				// 开始上传
				mAsyncRunner.request("me/photos", params, "POST", new PhotoUploadListener(), null);
				Log.i("adc", "facebook posted");

			}
		});

		button_cancel.setOnClickListener(new OnCloseClickListener());
		button_close.setOnClickListener(new OnCloseClickListener());
		
		editText.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void afterTextChanged(Editable text) {
				if(mWordCount - text.length() < 0) {
					CharSequence finalText = text.subSequence(0, mWordCount);
					int selection = editText.getSelectionStart();
					selection = Math.min(selection, finalText.length());
					selection = Math.max(0, selection);
					editText.setText(finalText);
					editText.setSelection(selection);
				}
				else {
					countText.setText(String.valueOf(mWordCount - text.length()));
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				
			}
		});
	}

	class OnCloseClickListener implements View.OnClickListener {
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			// 隐藏键盘
			InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
			getShareDialog().dismiss();
		}
	}

	public interface OnshareCompleteListener {
		public void onShareComplete(int FacebookManagerCODE);
	}

	private ShareDialog getShareDialog() {
		return this;
	}

	public void setOnshareCompleteListener(OnshareCompleteListener onshareCompleteListener) {
		this.onshareCompleteListener = onshareCompleteListener;
	}

	@Override
	public void dismiss() {
		// TODO Auto-generated method stub
		clear();
		super.dismiss();
	}

	public void clear() {
		imageView.setImageBitmap(null);
		bitmap.recycle();
		bitmap = null;
	}

	public void showLoading() {
		frameLayout.setPadding(0, 0, 0, 0);
		button_close.setVisibility(View.GONE);
		linearLayout.setVisibility(View.GONE);
		relativeLayout.setVisibility(View.VISIBLE);
	}

	public void hideLoading() {
		relativeLayout.setVisibility(View.GONE);
	}

	/*
	 * callback for the photo upload
	 */
	public class PhotoUploadListener extends BaseRequestListener {

		@Override
		public void onComplete(final String response, final Object state) {
			Log.i("adc", "facebook onComplete>>" + response);
			FacebookManagerCODE = FacebookManager.MSG_SHARE_PHOTO_END;
			onshareCompleteListener.onShareComplete(FacebookManagerCODE);
//			hideLoading();
//			getShareDialog().dismiss();
		}

		public void onFacebookError(FacebookError error) {
			Log.i("adc", "facebook FacebookError>>" + error.toString());
			FacebookManagerCODE = FacebookManager.MSG_SHARE_PHOTO_FB_ERROR;
			onshareCompleteListener.onShareComplete(FacebookManagerCODE);
//			hideLoading();
//			getShareDialog().dismiss();
		}
	}

	// 内部类
	private abstract class BaseRequestListener implements RequestListener {

		@Override
		public void onFacebookError(FacebookError e, final Object state) {

			e.printStackTrace();
		}

		@Override
		public void onFileNotFoundException(FileNotFoundException e, final Object state) {

			e.printStackTrace();
		}

		@Override
		public void onIOException(IOException e, final Object state) {

			e.printStackTrace();
		}

		@Override
		public void onMalformedURLException(MalformedURLException e, final Object state) {

			e.printStackTrace();
		}

		@Override
		public void onForceCloseIOException(ForceCloseIOException e) {

		}
	}
}
