package com.facebook.gt.facebook;


import java.io.InputStream;

import android.content.Context;
import android.graphics.drawable.Drawable;

public class ResourceUtil {

//	public static String getResourceSubFolder(){
//		//TODO
//		return "/"
//	}
	
	public static Drawable getDrawableFromResourceFolder___(String imageName){
		String path="/"+imageName+".png";
//		Class.forName(ResourceUtil.class.getName()).getResourceAsStream(path);
		InputStream is=null;
		try{
			is=Class.forName(ResourceUtil.class.getName()).getResourceAsStream(path);
			return Drawable.createFromStream(is, imageName);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(is!=null){
				try{
					is.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return null;
	}
}
