package com.facebook.gt.facebook;

public class ForceCloseIOException extends Exception {

	public ForceCloseIOException(){
		super("ForceCloseIOException");
	}
}
