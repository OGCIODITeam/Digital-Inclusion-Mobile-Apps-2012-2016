package com.facebook.gt.facebook;

public final class ResourceManager {
	private ResourceManager() {}
	
	public static int drawable_close;
	public static int drawable_dialogBackground;
	
	public static int layout_progressDialog;
	
	public static int anim_progressLoading;
	
	public static int id_dialogIcon;
	public static int id_dialogMessage;
	
	/**
	 * 此方法仅供本库调用
	 * @param outerRes
	 * @param innerRes
	 * @return
	 */
	public static int getResource(int outerRes, int innerRes) {
		int res = outerRes == 0 ? innerRes : outerRes;
		return res;
	}
	
//	public static int getLayoutProgressDialog() {
//		return layout_progressDialog;
//	}
//	
//	public static void setLayoutProgressDialog(int layout) {
//		layout_progressDialog = layout;
//	}
//	
//	public static int getDrawableClose() {
//		return drawable_close;
//	}
//	
//	public static void setDrawableClose(int drawable) {
//		drawable_close = drawable;
//	}
//	
//	public static int getAnimProgressLoading() {
//		return anim_progressLoading;
//	}
//	
//	public static void setAnimProgressLoading(int anim) {
//		anim_progressLoading = anim;
//	}
}
