package com.facebook.gt.common.view;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.android.R;
import com.facebook.gt.facebook.ResourceManager;

public class OhProgressDialog extends Dialog {

	private ImageView imageView=null;
	private TextView textView=null;
	private Animation loadingAnim=null;
	
	public OhProgressDialog(Context context) {
		super(context);
		
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.setCanceledOnTouchOutside(false);
//		View view=super.getLayoutInflater().inflate(R.layout.dialog_progress, null);
//		super.setView(view);
		
		int dialogLayout = ResourceManager.getResource(ResourceManager.layout_progressDialog, R.layout.dialog_progress);
		if(dialogLayout < 0) {
			return ;
		}
		
		super.setContentView(dialogLayout);
		
		int iconId = ResourceManager.getResource(ResourceManager.id_dialogIcon, R.id.icon);
		int messageId = ResourceManager.getResource(ResourceManager.id_dialogMessage, R.id.message);
		if(iconId > 0) {
			imageView=(ImageView)super.findViewById(iconId);
		}
		if(messageId > 0) {
			textView=(TextView)super.findViewById(messageId);
		}
		
		if(imageView == null || textView == null) {
			return ;
		}

		int anim = ResourceManager.getResource(ResourceManager.anim_progressLoading, R.anim.dialog_progress_loading);
		if(anim > 0) {
			loadingAnim=AnimationUtils.loadAnimation(context, anim);
		}
	}
	
	public void setMessage(int resIdMessage){
		textView.setText(super.getContext().getResources().getString(resIdMessage));
	}
	public void setMessage(CharSequence message){
		textView.setText(message);
	}
	
	public void show(){
		super.show();
		if(loadingAnim != null) {
			imageView.startAnimation(loadingAnim);
		}
	}
	
	public void dismiss(){
		imageView.clearAnimation();
		super.dismiss();
		
	}
	
	public void setTypeface(Typeface tf) {
		if(textView != null) {
			textView.setTypeface(tf);
		}
	}
}
