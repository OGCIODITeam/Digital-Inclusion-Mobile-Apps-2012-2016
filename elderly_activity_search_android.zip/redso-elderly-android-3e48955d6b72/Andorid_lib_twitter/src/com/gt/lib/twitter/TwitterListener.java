package com.gt.lib.twitter;

public interface TwitterListener {

	void onAuthorizeSuccess();
	void onAuthorizeFail();
}
