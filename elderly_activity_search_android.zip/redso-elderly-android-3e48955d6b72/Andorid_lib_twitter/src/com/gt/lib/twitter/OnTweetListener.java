package com.gt.lib.twitter;

import twitter4j.Status;

public interface OnTweetListener {

	void onTweetSuccess(Status status);
	void onTweetFail(Status status);
	
}
