package com.gt.lib.twitter;

public interface OnTimeoutListener {
	void onTimeout();
}
