package com.gt.lib.twitter;

interface OnAuthorizeSuccessListener {
	void onAuthorizeSuccess(String authorizationUrl);
}
