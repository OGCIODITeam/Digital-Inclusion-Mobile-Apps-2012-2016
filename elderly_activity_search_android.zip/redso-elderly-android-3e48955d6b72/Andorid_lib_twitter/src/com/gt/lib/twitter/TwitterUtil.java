package com.gt.lib.twitter;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.util.Log;

public class TwitterUtil {
	
	private static final String TAG = "TwitterUtil";

	protected static final String SHORTEN_URL_API = "http://tinyurl.com/api-create.php?url=";
	
	private TwitterUtil() {
		
	}
	
	public static String translateShortenUrl(String link) throws IOException {
		String retUrl = null;
		String preShortenUrl = SHORTEN_URL_API + link;
		URL url = new URL(preShortenUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setConnectTimeout(20000);
		conn.setReadTimeout(20000);
		conn.connect();
		InputStream inStream = conn.getInputStream();
		byte[] data = new byte[1024];
		int length = inStream.read(data);
		retUrl = new String(data, 0, length);
		inStream.close();
		conn.disconnect();
		Log.d(TAG, "Translate shorten url: " + retUrl);
		return retUrl;
	}
	
}
