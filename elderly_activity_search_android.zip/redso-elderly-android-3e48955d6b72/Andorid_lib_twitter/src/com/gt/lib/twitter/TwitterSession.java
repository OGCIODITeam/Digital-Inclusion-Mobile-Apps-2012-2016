package com.gt.lib.twitter;

import twitter4j.auth.AccessToken;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class TwitterSession {

	private final String TW_SP_NAME = "twitter.sp";
	private final String TW_SP_KEY_AUTH_TOKEN = "AuthToken";
	private final String TW_SP_KEY_AUTH_SECRET = "AuthSecret";
	private final String TW_SP_KEY_USER_NAME = "UserName";
	
	private SharedPreferences mSharedPreferences;
	
	public TwitterSession(Context context) {
		mSharedPreferences = context.getSharedPreferences(TW_SP_NAME, Context.MODE_WORLD_WRITEABLE);
	}
	
	public void StoreAccessToken(AccessToken accessToken, String userName) {
		Editor editor = mSharedPreferences.edit();
		editor.putString(TW_SP_KEY_AUTH_TOKEN, accessToken.getToken());
		editor.putString(TW_SP_KEY_AUTH_SECRET, accessToken.getTokenSecret());
		editor.putString(TW_SP_KEY_USER_NAME, userName);
		editor.commit();
	}
	
	public void resetAccessToken() {
		Editor editor = mSharedPreferences.edit();
		editor.putString(TW_SP_KEY_AUTH_TOKEN, null);
		editor.putString(TW_SP_KEY_AUTH_SECRET, null);
		editor.putString(TW_SP_KEY_USER_NAME, null);
		editor.commit();
	}
	
	public String getUserName() {
		return mSharedPreferences.getString(TW_SP_KEY_USER_NAME, "");
	}
	
	public AccessToken getAccessToken() {
		AccessToken retValue = null;
		String token = mSharedPreferences.getString(TW_SP_KEY_AUTH_TOKEN, null);
		String secret = mSharedPreferences.getString(TW_SP_KEY_AUTH_SECRET, null);
		
		if(token != null && secret != null) {
			retValue = new AccessToken(token, secret);
		}
		return retValue;
	}
	
}
