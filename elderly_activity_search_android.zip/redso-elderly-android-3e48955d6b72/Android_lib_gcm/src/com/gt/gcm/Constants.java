package com.gt.gcm;

public class Constants {

	public static enum Languages {
		Traditional_Chinese {
			public String toString() {
				return "zh";
			}
		},
		Simplified_Chinese {
			public String toString() {
				return "sc";
			}
		},
		English {
			public String toString() {
				return "en";
			}
		};
		public static Languages getByString(String value) {
			if ("zh".equals(value)) {
				return Traditional_Chinese;
			} else if ("sc".equals(value)) {
				return Simplified_Chinese;
			} else if ("en".equals(value)) {
				return English;
			} else {
				return null;
			}
		}
	}
}
