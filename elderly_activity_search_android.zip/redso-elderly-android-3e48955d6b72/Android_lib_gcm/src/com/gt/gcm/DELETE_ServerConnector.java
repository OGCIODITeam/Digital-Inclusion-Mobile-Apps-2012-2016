package com.gt.gcm;

import android.content.Context;

public interface DELETE_ServerConnector {

	public boolean register(final Context context, final String regId); 
	public void unregister(final Context context, final String regId);
}
