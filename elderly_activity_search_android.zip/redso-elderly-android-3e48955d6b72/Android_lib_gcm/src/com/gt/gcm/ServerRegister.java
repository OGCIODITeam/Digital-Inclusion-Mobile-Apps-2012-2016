package com.gt.gcm;

import android.content.Context;

public interface ServerRegister {

	public boolean registerToServer(Context context,String regId,String language);
}
