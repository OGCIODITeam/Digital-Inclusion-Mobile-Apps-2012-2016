package com.gt.gcm;

public interface ResultChecker {

	/**
	 * 
	 * @param content
	 * @return True if the content is right. Otherwise false. Return false cause retry.
	 */
	public boolean checkResult(String content);
}
