package com.gt.gcm;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gcm.GCMBaseIntentService;
import com.google.android.gcm.GCMRegistrar;

public class GCMIntentService extends GCMBaseIntentService {

	private static final String TAG="GCMIntentService";
	private static String extraNameMessage="message";
	
	static Class<?> classForIntent=null;
	static int resIcon=0;
	
	public GCMIntentService() {
//        super(GCMManager.getSenderID());
		Log.i(TAG, "GCMIntentService>>>");
    }

	
	
    @Override
	protected String[] getSenderIds(Context context) {
//		return super.getSenderIds(context);
    	Log.i(TAG, "getSenderIds>>>");
    	return new String[]{GCMManager.getSenderID()};
	}



	@Override
	public void onCreate() {
    	Log.i(TAG, "onCreate>>>");
		super.onCreate();
	}

	@Override
	public void onDestroy() {
		Log.d(TAG, "GCM >> onDestroy");
		super.onDestroy();
	}



	@Override
    protected void onRegistered(Context context, String registrationId) {
        Log.i(TAG, "onRegistered>>>registrationId = " + registrationId);
        ServerUtilities.register(context, registrationId);
    }

    @Override
    protected void onUnregistered(Context context, String registrationId) {
        Log.i(TAG, "onUnregistered>>>registrationId="+registrationId);
        if (GCMRegistrar.isRegisteredOnServer(context)) {
            ServerUtilities.unregister(context, registrationId);
        } else {
            // This callback results from the call to unregister made on
            // ServerUtilities when the registration to the server failed.
            Log.i(TAG, "onUnregistered>>>Ignoring unregister callback");
        }
    }

    @Override
    protected void onMessage(Context context, Intent intent) {
        Log.i(TAG, "onMessage>>>");
//        Bundle bundle=intent.getExtras();
//        Set<String> keySet=bundle.keySet();
//        for(String key:keySet){
//        	Log.i(TAG, "onMessage>>>key="+key);
//        }
        String message=intent.getStringExtra(extraNameMessage);
        if(message==null){
        	Log.e(TAG, "onMessage>>>message is null.");
        	message="";
        	sendBroadcastMessage(context,message);
        }
        else{
        	handleWhenPushMessage(context,message);
        	sendBroadcastMessage(context,message);
        }
//        Log.i(TAG, "onMessage>>>end");
//        String message = getString(R.string.gcm_message);
//        displayMessage(context, message);
        // notifies user
//        generateNotification(context, message);
    }

//    @Override
//    protected void onDeletedMessages(Context context, int total) {
//        Log.i(TAG, "Received deleted messages notification");
//        String message = getString(R.string.gcm_deleted, total);
//        displayMessage(context, message);
//        // notifies user
//        generateNotification(context, message);
//    }

    @Override
    public void onError(Context context, String errorId) {
        Log.i(TAG, "onError>>>errorId=" + errorId);
    }

    @Override
    protected boolean onRecoverableError(Context context, String errorId) {
        Log.i(TAG, "onRecoverableError>>>errorId=" + errorId);
        return super.onRecoverableError(context, errorId);
    }
    
    private static void sendBroadcastMessage(Context context, String message) {
        Intent intent = new Intent(GCMManager.BROADCAST_ACTION_MESSAGE);
        intent.putExtra(GCMManager.EXTRA_NAME_MESSAGE, message);
        context.sendBroadcast(intent);
    }

    static void setExtraNameMessage(String name){
    	extraNameMessage=name;
    }
    
    private static void handleWhenPushMessage(Context context,String message){
    	Log.d(TAG, "GCM >> handleWhenPushMessage");
    	int behavior=GCMManager.getBehaviorWhenPushMessage();
    	switch(behavior){
    	case GCMManager.WHEN_PUSH_MESSAGE_NONE:
    		break;
    	case GCMManager.WHEN_PUSH_MESSAGE_SHOW_NOTIFICATION:
    		if(classForIntent==null){
    			Log.e(TAG, "handleWhenPushMessage WHEN_PUSH_MESSAGE_SHOW_NOTIFICATION>>>classForIntent is null");
    		}
    		else{
    			GCMManager.showNotification(context, classForIntent, resIcon, message);
    		}
    		break;
    	case GCMManager.WHEN_PUSH_MESSAGE_SHOW_DIALOG:
    		if(classForIntent==null){
    			Log.e(TAG, "handleWhenPushMessage WHEN_PUSH_MESSAGE_SHOW_DIALOG>>>classForIntent is null");
    		}
    		else{
    			GCMManager.showDialog(context, classForIntent, message);
    		}
    		break;
    	}
    }
}
