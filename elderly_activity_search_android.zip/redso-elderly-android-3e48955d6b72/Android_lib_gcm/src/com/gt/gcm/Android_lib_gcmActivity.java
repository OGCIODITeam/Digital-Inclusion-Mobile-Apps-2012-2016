package com.gt.gcm;


import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;

public class Android_lib_gcmActivity extends Activity {
	
	private static final String TAG="Android_lib_gcmActivity";
	
	private static final String senderID="720891220648";
	private static final String SERVER_URL = "http://sit.membership.fortress.com.hk/fortress/api/addNUpdateUser.do";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        registerReceiver(mHandleMessageReceiver,
                new IntentFilter(GCMManager.BROADCAST_ACTION_MESSAGE));
        
      //Push message
      		GCMManager.onCreate(this, senderID);
      		GCMManager.setServerUrlRegister(SERVER_URL);
      		GCMManager.startByGtHKType("en");
      		
      		
//        GCMManager.onCreate(this, senderID);
//        GCMManager.setServerUrlRegister(SERVER_URL+"/register");
//        
//        GCMManager.start();
        
    }
    
    @Override
    protected void onDestroy() {
    	unregisterReceiver(mHandleMessageReceiver);
    	GCMManager.onDestroy();
    	super.onDestroy();
    }
    
    private final BroadcastReceiver mHandleMessageReceiver =
            new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String newMessage = intent.getExtras().getString(GCMManager.EXTRA_NAME_MESSAGE);
            Log.i(TAG, "Android lib gcmActivity >> onReceive>>>newMessage="+newMessage);
            GCMManager.showNotification(context, Android_lib_gcmActivity.class,0, newMessage);
        }
    };
}