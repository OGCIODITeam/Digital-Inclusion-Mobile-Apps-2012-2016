Main file description : 

app  		: signchat code
main 		: the library for coach marks
main_crop  	: the library for image cropping 

gradle 		: the build setting of signchat
