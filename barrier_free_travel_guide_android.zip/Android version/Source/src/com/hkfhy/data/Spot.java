package com.hkfhy.data;

public class Spot {
	int id;
	int record_id;
	int district_id;
	int type_id;
	String title;
	String content;
	String transport;
	String info;
	float rate;
	int total_rated;
	float map_lat;
	float map_lng;
	float center_lat;
	float center_lng;
	float baidu_map_x;
	float baidu_map_y;
	float baidu_center_x;
	float baidu_center_y;
	int zoom;
	String create_time;
	String update_time;
	int seq;
	int lang;

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	Photo photos;

	public int getId() {
		return id;
	}

	public int getRecord_id() {
		return record_id;
	}

	public int getDistrict_id() {
		return district_id;
	}

	public int getType_id() {
		return type_id;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}

	public String getTransport() {
		return transport;
	}

	public String getInfo() {
		return info;
	}

	public float getRate() {
		return rate;
	}

	public int getTotal_rated() {
		return total_rated;
	}

	public float getMap_lat() {
		return map_lat;
	}

	public float getMap_lng() {
		return map_lng;
	}

	public float getCenter_lat() {
		return center_lat;
	}

	public float getCenter_lng() {
		return center_lng;
	}

	public int getZoom() {
		return zoom;
	}

	public String getCreate_time() {
		return create_time;
	}

	public String getUpdate_time() {
		return update_time;
	}

	public int getSeq() {
		return seq;
	}

	public Photo getPhotos() {
		return photos;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setRecord_id(int record_id) {
		this.record_id = record_id;
	}

	public void setDistrict_id(int district_id) {
		this.district_id = district_id;
	}

	public void setType_id(int type_id) {
		this.type_id = type_id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setTransport(String transport) {
		this.transport = transport;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public void setTotal_rated(int total_rated) {
		this.total_rated = total_rated;
	}

	public void setMap_lat(float map_lat) {
		this.map_lat = map_lat;
	}

	public void setMap_lng(float map_lng) {
		this.map_lng = map_lng;
	}

	public void setCenter_lat(float center_lat) {
		this.center_lat = center_lat;
	}

	public void setCenter_lng(float center_lng) {
		this.center_lng = center_lng;
	}

	public void setZoom(int zoom) {
		this.zoom = zoom;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public void setPhotos(Photo photos) {
		this.photos = photos;
	}

	public float getBaidu_map_x() {
		return baidu_map_x;
	}

	public void setBaidu_map_x(float baidu_map_x) {
		this.baidu_map_x = baidu_map_x;
	}

	public float getBaidu_map_y() {
		return baidu_map_y;
	}

	public void setBaidu_map_y(float baidu_map_y) {
		this.baidu_map_y = baidu_map_y;
	}

	public float getBaidu_center_x() {
		return baidu_center_x;
	}

	public void setBaidu_center_x(float baidu_center_x) {
		this.baidu_center_x = baidu_center_x;
	}

	public float getBaidu_center_y() {
		return baidu_center_y;
	}

	public void setBaidu_center_y(float baidu_center_y) {
		this.baidu_center_y = baidu_center_y;
	}
}
