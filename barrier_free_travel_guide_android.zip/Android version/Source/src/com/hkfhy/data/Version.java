package com.hkfhy.data;

public class Version {
	int db_version;
	int data_version;
	String update_time;
	int total_location;

	public int getTotal_location() {
		return total_location;
	}

	public void setTotal_location(int total_location) {
		this.total_location = total_location;
	}

	public int getDb_version() {
		return db_version;
	}

	public int getData_version() {
		return data_version;
	}

	public String getUpdate_time() {
		return update_time;
	}

	public void setDb_version(int db_version) {
		this.db_version = db_version;
	}

	public void setData_version(int data_version) {
		this.data_version = data_version;
	}

	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}
}
