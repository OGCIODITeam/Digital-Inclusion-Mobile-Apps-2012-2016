package com.hkfhy.data;

import java.util.List;

public class Data {
	private List<Spot> spot;
	private List<District> district;
	private List<SpotType> spot_type;
	private List<Location> location;
	private List<LocationType> location_type;
	private List<Page> page;

	public int getTotal() {
		int total = 0;
		if (null != spot) {
			total += spot.size();
		}
		if (null != district) {
			total += district.size();
		}
		if (null != spot_type) {
			total += spot_type.size();
		}
		if (null != location) {
			total += location.size();
		}
		if (null != location_type) {
			total += location_type.size();
		}
		if (null != page) {
			total += page.size();
		}
		return total;
	}

	public List<Spot> getSpot() {
		return spot;
	}

	public List<District> getDistrict() {
		return district;
	}

	public List<SpotType> getSpot_type() {
		return spot_type;
	}

	public List<Location> getLocation() {
		return location;
	}

	public List<LocationType> getLocation_type() {
		return location_type;
	}

	public List<Page> getPage() {
		return page;
	}

	public void setPage(List<Page> page) {
		this.page = page;
	}

	public void setSpot(List<Spot> spot) {
		this.spot = spot;
	}

	public void setDistrict(List<District> district) {
		this.district = district;
	}

	public void setSpot_type(List<SpotType> spot_type) {
		this.spot_type = spot_type;
	}

	public void setLocation(List<Location> location) {
		this.location = location;
	}

	public void setLocation_type(List<LocationType> location_type) {
		this.location_type = location_type;
	}
}
