package com.hkfhy.data;

public class Location {
	int id;
	int record_id;
	int type_id;
	String title;
	String open_time;
	String content;
	float map_lat;
	float map_lng;
	float baidu_map_x;
	float baidu_map_y;
	String create_time;
	String update_time;
	int seq;
	int lang;

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setRecord_id(int record_id) {
		this.record_id = record_id;
	}

	public void setType_id(int type_id) {
		this.type_id = type_id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setOpen_time(String open_time) {
		this.open_time = open_time;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setMap_lat(float map_lat) {
		this.map_lat = map_lat;
	}

	public void setMap_lng(float map_lng) {
		this.map_lng = map_lng;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public int getId() {
		return id;
	}

	public int getRecord_id() {
		return record_id;
	}

	public int getType_id() {
		return type_id;
	}

	public String getTitle() {
		return title;
	}

	public String getOpen_time() {
		return open_time;
	}

	public String getContent() {
		return content;
	}

	public float getMap_lat() {
		return map_lat;
	}

	public float getMap_lng() {
		return map_lng;
	}

	public String getCreate_time() {
		return create_time;
	}

	public String getUpdate_time() {
		return update_time;
	}

	public int getSeq() {
		return seq;
	}

	public float getBaidu_map_x() {
		return baidu_map_x;
	}

	public void setBaidu_map_x(float baidu_map_x) {
		this.baidu_map_x = baidu_map_x;
	}

	public float getBaidu_map_y() {
		return baidu_map_y;
	}

	public void setBaidu_map_y(float baidu_map_y) {
		this.baidu_map_y = baidu_map_y;
	}

}
