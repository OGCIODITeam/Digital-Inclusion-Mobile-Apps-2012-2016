package com.hkfhy.data;

import java.util.List;

public class Photo {
	private List<Thumbnail> thumbnail;

	public List<Thumbnail> getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(List<Thumbnail> thumbnail) {
		this.thumbnail = thumbnail;
	}
}
