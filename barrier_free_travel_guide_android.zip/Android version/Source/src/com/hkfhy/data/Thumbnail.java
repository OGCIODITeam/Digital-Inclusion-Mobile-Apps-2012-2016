package com.hkfhy.data;

public class Thumbnail {
	int id;
	String path;
	String path_small;
	String alt_text;
	int parent_id;
	int seq;
	int lang;

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public void setAlt_text(String alt_text) {
		this.alt_text = alt_text;
	}

	public String getPath() {
		return path;
	}

	public String getAlt_text() {
		return alt_text;
	}

	public String getPath_small() {
		return path_small;
	}

	public void setPath_small(String path_small) {
		this.path_small = path_small;
	}

}
