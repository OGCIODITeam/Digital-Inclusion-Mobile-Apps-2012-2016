package com.hkfhy.data;

public class LocationType {
	int id;
	int record_id;
	String title;
	String create_time;
	String update_time;
	int seq;
	int lang;

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setRecord_id(int record_id) {
		this.record_id = record_id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public int getId() {
		return id;
	}

	public int getRecord_id() {
		return record_id;
	}

	public String getTitle() {
		return title;
	}

	public String getCreate_time() {
		return create_time;
	}

	public String getUpdate_time() {
		return update_time;
	}

	public int getSeq() {
		return seq;
	}
}
