package com.hkfhy.server;

public class RatingResponse {
	float rate;
	int total_rated;

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public int getTotal_rated() {
		return total_rated;
	}

	public void setTotal_rated(int total_rated) {
		this.total_rated = total_rated;
	}

}
