package com.hkfhy.guide;

import android.content.Context;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageButton;

import com.hkfhy.data.Page;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.PageDataSource;

public class Instrction extends MyActivity {

	private DataSource dataSource;
	private PageDataSource pageDataSource;

	ImageButton BtnHome;
	WebView webView;

	int imageNumber = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.instrction);

		context = this;

		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		webView = (WebView) findViewById(R.id.content_text);
		setUpPageTheme(this);

		setUpPage(context);

		homeButton = (ImageButton) findViewById(R.id.home_btn);
		homeButton.setOnClickListener(homeButtonClicked);

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		pageDataSource = new PageDataSource(context);

		Page page = pageDataSource.getById(3, LANGUAGE_ID);
		if (null != page) {
			String content = page.getContent();
			String decodedHtml = Html.fromHtml(content).toString();
			decodedHtml = replaceHtmlImageLink(decodedHtml);
			webView.setBackgroundColor(0x00000000);
			webView.loadDataWithBaseURL(null, decodedHtml, "text/html",
					"utf-8", null);

			// ContentText.setMovementMethod(new ScrollingMovementMethod());
			// Spanned spanned = Html.fromHtml(decodedHtml, this, null);
			// ContentText.setText(spanned);
		}

		dataSource.close();
	}

	public void setUpPageTheme(Context context) {
		prefs = PreferenceManager.getDefaultSharedPreferences(context);

		String prefTextSize = prefs.getString("text_size", TEXT_NORMAL);
		WebSettings webSettings = webView.getSettings();

		if (prefTextSize.equals(TEXT_NORMAL)) {
			context.setTheme(R.style.largeFont);
			webSettings.setTextZoom(120);
		} else if (prefTextSize.equals(TEXT_LARGE)) {
			context.setTheme(R.style.XlargeFont);
			webSettings.setTextZoom(150);
		} else {
			context.setTheme(R.style.NoActionBar);
			webSettings.setTextZoom(100);
		}
	}

}
