package com.hkfhy.guide;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.text.Html;
import android.text.Layout;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.devsmart.android.ui.HorizontalListView;
import com.hkfhy.adapter.ThumbnailListAdapter;
import com.hkfhy.asynctask.SpotRatingTask;
import com.hkfhy.data.Spot;
import com.hkfhy.data.Thumbnail;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.SpotDataSource;
import com.hkfhy.datasource.ThumbnailDataSource;

public class SpotDetail extends MyActivity {

	private static final String RATING_URL = DOMAIN + "submit_rate.php";
	private final int SCROLL_AMOUNT = 150;

	private DataSource dataSource;
	private SpotDataSource spotDataSource;
	private ThumbnailDataSource thumbnailDataSource;

	private Spot spot;

	TextView spotTitleTextView;
	TextView contentTextView;
	TextView totalRatedTextView;
	LinearLayout thumbnailListLayout;

	ImageButton contentTextPrev;
	ImageButton contentTextNext;

	ImageButton spotContentButton;
	ImageButton spotTransportButton;
	ImageButton spotInfoButton;
	ImageButton spotMapButton;
	ImageButton spotFacebookButton;
	ImageButton spotCommentButton;
	HorizontalListView thumbnailListView;

	List<Thumbnail> thumbnails;

	RatingBar ratingBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.spot_detail);

		context = this;
		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		setUpPage(context);

		homeButton = (ImageButton) findViewById(R.id.home_btn);
		homeButton.setOnClickListener(homeButtonClicked);

		spotTitleTextView = (TextView) findViewById(R.id.spot_title);
		contentTextView = (TextView) findViewById(R.id.content_text_view);
		totalRatedTextView = (TextView) findViewById(R.id.total_rated);

		spotContentButton = (ImageButton) findViewById(R.id.spot_content);
		spotTransportButton = (ImageButton) findViewById(R.id.spot_transport);
		spotInfoButton = (ImageButton) findViewById(R.id.spot_info);
		spotMapButton = (ImageButton) findViewById(R.id.spot_map);
		spotFacebookButton = (ImageButton) findViewById(R.id.spot_facebook);
		spotCommentButton = (ImageButton) findViewById(R.id.spot_comment);

		ratingBar = (RatingBar) findViewById(R.id.rating_bar);

		ratingBar.setOnRatingBarChangeListener(ratingBarChanged);
		ratingBar.setOnTouchListener(ratingBarTouched);

		spotContentButton.setOnClickListener(spotContentButtonClicked);
		spotTransportButton.setOnClickListener(spotTransportButtonClicked);
		spotInfoButton.setOnClickListener(spotInfoButtonClicked);
		spotMapButton.setOnClickListener(spotMapButtonClicked);
		spotCommentButton.setOnClickListener(spotCommentClicked);
		spotFacebookButton.setOnClickListener(spotFacebookButtonClicked);

		contentTextPrev = (ImageButton) findViewById(R.id.content_text_prev);
		contentTextNext = (ImageButton) findViewById(R.id.content_text_next);
		contentTextPrev.setOnTouchListener(contentTextPrevClicked);
		contentTextNext.setOnTouchListener(contentTextNextClicked);

		contentTextView.setMovementMethod(new ScrollingMovementMethod());

		thumbnailListView = (HorizontalListView) findViewById(R.id.thumbnail_list);
		thumbnailListView.setOnItemClickListener(thumbnailListItemClicked);

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		spotDataSource = new SpotDataSource(context);
		thumbnailDataSource = new ThumbnailDataSource(context);

		// Get spot record id
		Bundle extras = getIntent().getExtras();
		int spotRecordId = 0;
		if (extras != null) {
			spotRecordId = extras.getInt("EXTRA_SELECTED_SPOT");
		}

		spot = spotDataSource.getById(spotRecordId, LANGUAGE_ID);

		// Set header text
		spotTitleTextView.setText(spot.getTitle());

		// Set content
		String content = spot.getContent();
		setContentText(content);

		ratingBar.setRating(spot.getRate());
		totalRatedTextView.setText(getResources().getString(
				R.string.no_barrier_rate_prefix)
				+ spot.getTotal_rated()
				+ getResources().getString(R.string.no_barrier_rate_subfix));

		// Set thumbnails
		// thumbnailListView
		thumbnails = thumbnailDataSource.getByParentId(spot.getRecord_id(),
				LANGUAGE_ID);
		File fileWithinMyDir = getApplicationContext().getFilesDir();
		if (null != thumbnails) {
			ThumbnailListAdapter thumbnailListAdapter = new ThumbnailListAdapter(
					context, R.id.thumbnail_list, thumbnails, fileWithinMyDir,
					R.layout.viewitem_spot_detail);
			thumbnailListView.setAdapter(thumbnailListAdapter);
		}

		dataSource.close();
	}

	// Set content
	public void setContentText(String content) {
		String decodedHtml = Html.fromHtml(content).toString();
		contentTextView.setText(Html.fromHtml(decodedHtml));
	}

	HorizontalListView.OnItemClickListener thumbnailListItemClicked = new HorizontalListView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			Thumbnail thumb = thumbnails.get(position);
		}
	};

	// Content buttons clicked
	View.OnClickListener spotContentButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			String content = spot.getContent();
			setContentText(content);
			contentTextView.scrollTo(0, 0);
		}
	};
	View.OnClickListener spotTransportButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			String content = spot.getTransport();
			setContentText(content);
			contentTextView.scrollTo(0, 0);
		}
	};
	View.OnClickListener spotInfoButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			String content = spot.getInfo();
			setContentText(content);
			contentTextView.scrollTo(0, 0);
		}
	};

	// Facebook button
	/*
	 * Facebook only accept link in Intent.EXTRA_TEXT
	 * https://developers.facebook.com/bugs/332619626816423
	 */
	View.OnClickListener spotFacebookButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			String webLink = DOMAIN + "spot-detail?id=" + spot.getRecord_id();
			// String facebookFeedUrl = FACEBOOK_SHARER_URL
			// + Html.escapeHtml(webLink);
			// Intent browse = new Intent(Intent.ACTION_VIEW,
			// Uri.parse(facebookFeedUrl));
			// startActivity(browse);

			// String content = removeHtmlTags(Html.fromHtml(
			// Html.fromHtml(spot.getContent()).toString()).toString());

			Intent sendIntent = new Intent();
			sendIntent.setAction(Intent.ACTION_SEND);
			sendIntent.putExtra(Intent.EXTRA_SUBJECT, spot.getTitle());
			// sendIntent.putExtra(Intent.EXTRA_TEXT, content);
			sendIntent.putExtra(Intent.EXTRA_TEXT, webLink);
			sendIntent.setType("text/plain");
			startActivity(sendIntent);
		}
	};

	// Go to map
	View.OnClickListener spotMapButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent;
			if (USE_MAP_SERVICE.equals(MAP_GOOGLE)) {
				intent = new Intent(getBaseContext(), Map.class);
			} else {
				intent = new Intent(getBaseContext(), MapBaidu.class);
			}
			intent.putExtra("EXTRA_SELECTED_SPOT", spot.getRecord_id());
			startActivity(intent);
		}
	};

	// Go to comment
	View.OnClickListener spotCommentClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(getBaseContext(), SpotComment.class);
			intent.putExtra("EXTRA_SELECTED_SPOT", spot.getRecord_id());
			startActivity(intent);
		}
	};

	// Rate
	RatingBar.OnRatingBarChangeListener ratingBarChanged = new OnRatingBarChangeListener() {
		@Override
		public void onRatingChanged(RatingBar ratingBar, float rating,
				boolean fromUser) {
			// Log.d("guide", "Rate: " + rating);
		}
	};
	View.OnTouchListener ratingBarTouched = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if (event.getActionMasked() == MotionEvent.ACTION_POINTER_UP
					|| event.getActionMasked() == MotionEvent.ACTION_UP) {
				float rating = ratingBar.getRating();
				Log.d("guide", "clicked Rate: " + rating);
				sendRating(rating);
			}
			return false;
		}
	};

	public void sendRating(final float rating) {
		new AlertDialog.Builder(this)
				.setTitle(getResources().getString(R.string.rating))
				.setMessage(getResources().getString(R.string.rating_confirm))
				.setIcon(android.R.drawable.ic_dialog_alert)
				.setPositiveButton(R.string.yes,
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int whichButton) {
								Toast.makeText(
										getBaseContext(),
										getResources().getString(
												R.string.rating_sending),
										Toast.LENGTH_SHORT).show();

								List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
										2);
								String deviceId = Secure.getString(
										context.getContentResolver(),
										Secure.ANDROID_ID);

								nameValuePairs.add(nameValue("id",
										spot.getRecord_id() + ""));
								nameValuePairs.add(nameValue("rate", rating
										+ ""));
								nameValuePairs.add(nameValue("device_os",
										OS_NAME));
								nameValuePairs.add(nameValue("device_id",
										deviceId));
								new SpotRatingTask(nameValuePairs, context,
										spot.getRecord_id(), DOMAIN, ratingBar,
										totalRatedTextView).execute(RATING_URL);
							}
						}).setNegativeButton(R.string.cancel, null).show();
	}

	// Content arrow clicked
	View.OnTouchListener contentTextPrevClicked = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent arg1) {
			int scrollY = contentTextView.getScrollY();
			int scrolled = scrollY - SCROLL_AMOUNT;
			if (scrolled < 0) {
				scrolled = 0;
			}
			contentTextView.scrollTo(0, scrolled);
			return false;
		}
	};
	View.OnTouchListener contentTextNextClicked = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent arg1) {
			Layout layout = contentTextView.getLayout();

			int scrollY = contentTextView.getScrollY();
			int contentHeight = layout.getHeight();
			int viewHeight = contentTextView.getHeight();

			int scrolled = scrollY + SCROLL_AMOUNT;
			if (scrolled > contentHeight - viewHeight) {
				scrolled = contentHeight - viewHeight;
			}
			contentTextView.scrollTo(0, scrolled);
			return false;
		}
	};
}
