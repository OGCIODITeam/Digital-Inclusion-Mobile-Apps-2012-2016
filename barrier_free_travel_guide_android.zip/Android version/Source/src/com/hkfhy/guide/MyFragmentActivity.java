package com.hkfhy.guide;

import java.util.Locale;

import org.apache.http.message.BasicNameValuePair;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.hkfhy.datasource.DataSource;

public class MyFragmentActivity extends FragmentActivity {

	// Preferences
	protected static final String TAG = "guide";
	protected String APP_PACKAGE_NAME = "com.hkfhy.guide";
	protected SharedPreferences prefs;

	// DB
	protected DataSource dataSource;

	// Some general setting
	protected static final String DOMAIN = "http://app.e-cgo.org.hk/";

	protected static final boolean DEVELOPER_MODE = false;
	protected static final boolean SKIP_OPENING = false;
	protected static final String OS_NAME = "android";

	// Facebook setting
	protected static final String FACEBOOK_FEED_URL = "http://www.facebook.com/dialog/feed?";
	protected static final String FACEBOOK_SHARER_URL = "https://www.facebook.com/sharer/sharer.php?u=";
	protected static final String FACEBOOK_APP_ID = "322838561153388";

	// Common elements
	protected ImageButton homeButton;
	protected ImageButton changeLanguageButton;
	protected ImageButton changeTextSizeButton;
	protected Context context;

	// Map
	protected static final String MAP_GOOGLE = "google";
	protected static final String MAP_BAIDU = "baidu";
	protected static String USE_MAP_SERVICE = MAP_GOOGLE;

	protected static final String BAIDU_API_KEY = "64cccc4d601da3cc800d873288479de1";

	protected static final int TOILET_ID = 31;
	protected static final int ACCESSIBLE_TOILET_ID = 32;
	protected static final int CAR_PARK_ID = 33;
	protected static final int DISABLED_PARKING_ID = 34;
	protected static final int BUS_STOP_ID = 35;
	protected static final int SCENIC_SPOT_ID = 36;

	// Languages
	protected static final String ZH_HK = "zh_HK";
	protected static final String EN_US = "en_US";
	protected static final int LANGUAGE_ID_ZH_HK = 2;
	protected static final int LANGUAGE_ID_EN_US = 1;
	protected static final String LANGUAGE_CODE_ZH = "zh-hant";
	protected static final String LANGUAGE_CODE_EN = "en";
	protected int LANGUAGE_ID = LANGUAGE_ID_ZH_HK;
	protected String LANGUAGE_CODE = LANGUAGE_CODE_ZH;

	// Text size;
	protected static final String TEXT_NORMAL = "normal";
	protected static final String TEXT_LARGE = "large";
	protected static final String TEXT_XLARGE = "xlarge";
	protected String TEXT_SIZE = TEXT_NORMAL;

	public void setUpPage(Context context) {
		// prefs = getSharedPreferences(APP_PACKAGE_NAME, Context.MODE_PRIVATE);
		prefs = PreferenceManager.getDefaultSharedPreferences(context);
		USE_MAP_SERVICE = prefs.getString("map_type", MAP_GOOGLE);

		String prefLang = prefs.getString("lang", ZH_HK);
		if (prefLang.equals(ZH_HK)) {
			LANGUAGE_ID = LANGUAGE_ID_ZH_HK;
		} else {
			LANGUAGE_ID = LANGUAGE_ID_EN_US;
		}
	}

	public void setUpTheme(Context context) {
		prefs = PreferenceManager.getDefaultSharedPreferences(context);

		String prefTextSize = prefs.getString("text_size", TEXT_NORMAL);

		if (prefTextSize.equals(TEXT_NORMAL)) {
			context.setTheme(R.style.largeFont);
		} else if (prefTextSize.equals(TEXT_LARGE)) {
			context.setTheme(R.style.XlargeFont);
		} else {
			context.setTheme(R.style.NoActionBar);
		}
	}

	// Go home
	protected View.OnClickListener homeButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			startActivity(new Intent(v.getContext(), Home.class));
		}
	};

	// change_language
	protected View.OnClickListener changeLanguageClicked = new View.OnClickListener() {
		@SuppressLint("DefaultLocale")
		public void onClick(View v) {
			// String key = APP_PACKAGE_NAME + "." + "lang";
			String key = "lang";
			String prefLang = prefs.getString(key, ZH_HK);
			Log.d("guide", "Language change from: " + prefLang);

			String changedLang;

			if (prefLang.equals(ZH_HK)) {
				changedLang = EN_US;
				LANGUAGE_ID = LANGUAGE_ID_EN_US;
			} else {
				changedLang = ZH_HK;
				LANGUAGE_ID = LANGUAGE_ID_ZH_HK;
			}

			prefs.edit().putString(key, changedLang).commit();

			Resources res = context.getResources();
			// Change locale settings in the app.
			DisplayMetrics dm = res.getDisplayMetrics();
			android.content.res.Configuration conf = res.getConfiguration();
			conf.locale = new Locale(changedLang.toLowerCase());
			res.updateConfiguration(conf, dm);

			// Restart activity
			Toast.makeText(context, R.string.changing_language,
					Toast.LENGTH_LONG).show();
			Intent intent = getIntent();
			finish();
			startActivity(intent);
		}
	};

	// change text size
	protected View.OnClickListener changeTextSizeClicked = new View.OnClickListener() {
		public void onClick(View v) {
			String key = "text_size";
			String prefTextSize = prefs.getString(key, TEXT_NORMAL);

			String changedSize;

			if (prefTextSize.equals(TEXT_NORMAL)) {
				changedSize = TEXT_LARGE;
			} else if (prefTextSize.equals(TEXT_LARGE)) {
				changedSize = TEXT_XLARGE;
			} else {
				changedSize = TEXT_NORMAL;
			}

			Log.d("guide", "Text size change from: " + prefTextSize + " to "
					+ changedSize);

			prefs.edit().putString(key, changedSize).commit();

			// Restart activity
			Intent intent = getIntent();
			finish();
			startActivity(intent);
		}
	};

	public void onCreateContextMenu(ContextMenu contextMenu, View view,
			ContextMenu.ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(contextMenu, view, menuInfo);

		int groupId = 1;
		int itemId = 1;
		int order = 1;

		contextMenu.add(groupId++, itemId++, order++, "test1");
		contextMenu.add(groupId++, itemId++, order++, "test2");
		contextMenu.add(groupId++, itemId++, order++, "test3");

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.common_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (R.id.action_settings == item.getItemId()) {
			Log.d("guide", "Go settings");

			Intent intent = new Intent(getBaseContext(), Preference.class);
			startActivity(intent);
		}
		return true;

	}

	// Common method
	public BasicNameValuePair nameValue(String name, String value) {
		return new BasicNameValuePair(name, value);
	}

	public String convertHtml(String html) {
		html = Html.fromHtml(html).toString();
		html = Html.fromHtml(html).toString();
		html = replaceHtmlImageLink(html);
		return html;
	}

	public String removeHtmlTags(String html) {
		// Removes all items in brackets
		html = html.replaceAll("<(.*?)\\>", " ");
		// Must be undeneath
		html = html.replaceAll("<(.*?)\\\n", " ");
		// Removes any connected item to the last bracket
		html = html.replaceFirst("(.*?)\\>", " ");
		html = html.replaceAll("&nbsp;", " ");
		html = html.replaceAll("&amp;", " ");
		return html;
	}

	public String replaceHtmlImageLink(String html) {
		/*
		 * <img src="upload/ to <img src="DOMAIN/upload/
		 */
		html = html.replaceAll("<img src=\"upload/", "<img src=\"" + DOMAIN
				+ "upload/");
		html = html.replaceAll("width=\"150\" height=\"94\"", "width=\"100%\"");
		return html;
	}

	public CharSequence stripHtml(String s) {
		return Html.fromHtml(s).toString().replace('\n', (char) 32)
				.replace((char) 160, (char) 32)
				.replace((char) 65532, (char) 32).trim();
	}
}
