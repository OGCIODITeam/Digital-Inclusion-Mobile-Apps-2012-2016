package com.hkfhy.guide;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hkfhy.asynctask.RequestTask;
import com.hkfhy.server.ServerResponse;

public class Comment extends MyActivity {

	private static final String POST_DATA_URL = DOMAIN + "submit_comment.php";

	private String commentCategory = "comment";
	Button commentButton;
	Button complainButton;
	Button inquiryButton;

	Button submitButton;
	Button cancelButton;

	EditText inputName;
	EditText inputTel;
	EditText inputEmail;
	EditText inputContent;

	LinearLayout contentContainer;
	RelativeLayout loadingOverlay;
	RelativeLayout submitResult;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.comment);

		context = this;
		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		setUpPage(context);

		homeButton = (ImageButton) findViewById(R.id.home_btn);
		homeButton.setOnClickListener(homeButtonClicked);

		if (DEVELOPER_MODE) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		contentContainer = (LinearLayout) findViewById(R.id.content_container);
		loadingOverlay = (RelativeLayout) findViewById(R.id.loading_overlay);
		submitResult = (RelativeLayout) findViewById(R.id.submit_result);

		submitButton = (Button) findViewById(R.id.submit_button);
		submitButton.setOnClickListener(submitButtonClicked);

		cancelButton = (Button) findViewById(R.id.cancel_button);
		cancelButton.setOnClickListener(cancelButtonClicked);

		inputName = (EditText) findViewById(R.id.input_name);
		inputTel = (EditText) findViewById(R.id.input_tel);
		inputEmail = (EditText) findViewById(R.id.input_email);
		inputContent = (EditText) findViewById(R.id.input_content);

		commentButton = (Button) findViewById(R.id.category_comment);
		complainButton = (Button) findViewById(R.id.category_complain);
		inquiryButton = (Button) findViewById(R.id.category_inquiry);

		commentButton.setOnClickListener(commentButtonClicked);
		complainButton.setOnClickListener(complainButtonClicked);
		inquiryButton.setOnClickListener(inquiryButtonClicked);

		commentButton.setSelected(true);
	}

	// Category
	View.OnClickListener commentButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			commentButton.setSelected(false);
			complainButton.setSelected(false);
			inquiryButton.setSelected(false);

			commentCategory = "comment";
			commentButton.setSelected(true);
		}
	};
	View.OnClickListener complainButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			commentButton.setSelected(false);
			complainButton.setSelected(false);
			inquiryButton.setSelected(false);

			commentCategory = "complain";
			complainButton.setSelected(true);
		}
	};
	View.OnClickListener inquiryButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			commentButton.setSelected(false);
			complainButton.setSelected(false);
			inquiryButton.setSelected(false);

			commentCategory = "inquiry";
			inquiryButton.setSelected(true);
		}
	};

	// Form
	public ServerResponse httpResponseToServerResponse(HttpResponse response) {
		ServerResponse serverResponse = null;
		try {
			InputStream inputStream = response.getEntity().getContent();
			InputStreamReader inputStreamReader = new InputStreamReader(
					inputStream);
			BufferedReader bufferedReader = new BufferedReader(
					inputStreamReader);
			StringBuilder stringBuilder = new StringBuilder();
			String bufferedStrChunk = null;

			while ((bufferedStrChunk = bufferedReader.readLine()) != null) {
				stringBuilder.append(bufferedStrChunk);
			}
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			JsonObject json = parser.parse(stringBuilder.toString())
					.getAsJsonObject();

			serverResponse = gson.fromJson(json, ServerResponse.class);

		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		return serverResponse;
	}

	View.OnClickListener submitButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			/*
			 * submit_comment.php (post method) category* =
			 * comment|complain|inquiry name* = text tel = text email = text
			 * content* = text
			 */
			if (inputName.getText().toString().isEmpty()
					&& inputContent.getText().toString().isEmpty()) {

				Toast.makeText(context, R.string.spot_form_required,
						Toast.LENGTH_LONG).show();
			} else {
				submitButton.setEnabled(false);
				Toast.makeText(context, R.string.form_sent, Toast.LENGTH_LONG)
						.show();

				Log.d("guide", "Post data to: " + POST_DATA_URL);

				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
						2);
				nameValuePairs.add(nameValue("category", commentCategory));
				nameValuePairs.add(nameValue("name", inputName.getText()
						.toString()));
				nameValuePairs.add(nameValue("tel", inputTel.getText()
						.toString()));
				nameValuePairs.add(nameValue("email", inputEmail.getText()
						.toString()));
				nameValuePairs.add(nameValue("content", inputContent.getText()
						.toString()));
				new RequestTask(nameValuePairs).execute(POST_DATA_URL);

				// Reset form
				submitButton.setEnabled(true);
				resetForm();
			}

		}
	};

	private void resetForm() {
		inputName.setText("");
		inputTel.setText("");
		inputEmail.setText("");
		inputContent.setText("");
	}

	// Reset form
	View.OnClickListener cancelButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			// resetForm();
			Intent intent = new Intent(getBaseContext(), Home.class);
			startActivity(intent);
		}
	};
}
