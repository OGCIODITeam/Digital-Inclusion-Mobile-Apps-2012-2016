package com.hkfhy.guide;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.hkfhy.adapter.SearchResultAdapter;
import com.hkfhy.data.Spot;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.SpotDataSource;

public class Search extends MyActivity {

	private final int SCROLL_AMOUNT = 150;

	EditText searchInput;
	ImageButton searchSubmit;

	private DataSource dataSource;
	private SpotDataSource spotDataSource;

	private List<String> keywords;

	TextView searchResultMessage;
	ListView searchResultList;

	ImageButton searchResultListPrev;
	ImageButton searchResultListNext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.search);

		context = this;
		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		setUpPage(context);

		homeButton = (ImageButton) findViewById(R.id.home_btn);
		homeButton.setOnClickListener(homeButtonClicked);

		searchInput = (EditText) findViewById(R.id.search_input);
		searchSubmit = (ImageButton) findViewById(R.id.search_submit);
		searchSubmit.setOnClickListener(searchSubmitClicked);

		searchResultMessage = (TextView) findViewById(R.id.search_result_message);
		searchResultList = (ListView) findViewById(R.id.search_result_list);

		searchResultListPrev = (ImageButton) findViewById(R.id.search_result_list_prev);
		searchResultListNext = (ImageButton) findViewById(R.id.search_result_list_next);
		searchResultListPrev.setOnTouchListener(searchResultListPrevClicked);
		searchResultListNext.setOnTouchListener(searchResultListNextClicked);

		// Get selected category if enter from home grids
		Bundle extras = getIntent().getExtras();
		String searchKeywords = "";
		if (extras != null) {
			searchKeywords = extras.getString("EXTRA_SEARCH_KEYWORDS");
		}
		searchInput.setText(searchKeywords);

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		spotDataSource = new SpotDataSource(context);

		goSearch();

		searchResultList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View view,
					int position, long id) {

				Spot selectedSpot = (Spot) searchResultList.getAdapter()
						.getItem(position);

				if (null == selectedSpot) {
					Log.d("guide", "Selecting spot in search �S�r�d");
				} else {
					// Go spot detail page
					Intent intent = new Intent(getBaseContext(),
							SpotDetail.class);
					intent.putExtra("EXTRA_SELECTED_SPOT",
							selectedSpot.getRecord_id());
					startActivity(intent);
				}
			}
		});

		dataSource.close();
	}

	public void goSearch() {
		String searchKeywords = searchInput.getText().toString();
		if (!searchKeywords.isEmpty()) {
			keywords = Arrays.asList(searchKeywords.split("\\s* \\s*"));

			List<Spot> spots = spotDataSource.getAllByKeywords(keywords,
					LANGUAGE_ID);

			File fileWithinMyDir = getApplicationContext().getFilesDir();
			SearchResultAdapter<Spot> searchResultAdapter = new SearchResultAdapter<Spot>(
					context, R.id.search_result_list, spots, fileWithinMyDir,
					LANGUAGE_ID);
			if (!searchResultAdapter.isEmpty()) {
				searchResultList.setAdapter(searchResultAdapter);
			} else {
				Toast.makeText(context, R.string.no_result, Toast.LENGTH_LONG)
						.show();
			}

		}
	}

	View.OnClickListener searchSubmitClicked = new View.OnClickListener() {
		public void onClick(View v) {
			goSearch();
		}
	};

	// Content arrow clicked
	View.OnTouchListener searchResultListPrevClicked = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent arg1) {
			searchResultList.smoothScrollBy(-SCROLL_AMOUNT, 200);
			return false;
		}
	};
	View.OnTouchListener searchResultListNextClicked = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent arg1) {
			searchResultList.smoothScrollBy(SCROLL_AMOUNT, 200);
			return false;
		}
	};

}
