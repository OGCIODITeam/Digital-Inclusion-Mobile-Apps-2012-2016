package com.hkfhy.guide;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.map.MapController;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.OverlayItem;
import com.baidu.platform.comapi.basestruct.GeoPoint;
import com.google.android.gms.maps.model.LatLng;
import com.hkfhy.data.Location;
import com.hkfhy.data.Spot;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.LocationDataSource;
import com.hkfhy.datasource.SpotDataSource;

public class MapBaidu extends MyActivity implements LocationListener {
	private DataSource dataSource;
	private SpotDataSource spotDataSource;
	private LocationDataSource locationDataSource;

	private int spotRecordId = 0;

	private Spot spot = null;

	// Buttons
	Button mapToolToilet;
	Button mapToolParking;
	Button mapToolBusStop;
	Button mapToolScenicSpot;
	ImageButton mapToolHome;
	ImageButton mapToolGps;
	ImageButton mapToolZoomIn;
	ImageButton mapToolZoomOut;

	LocationManager locationManager;

	// Map
	BMapManager mBMapMan = null;
	MapView mMapView = null;
	MapController mMapController;

	private final double BAIDU_MAP_COORD_MOD = 1E6;

	private boolean hasMap = false;
	private float lat = (float) 22.3;
	private float lng = (float) 114.17;
	private int zoom = 16;

	private boolean firstRun = true;

	// Show location type
	private boolean showToilet = false;
	private boolean showParking = false;
	private boolean showSpot = false;
	private boolean showBusStop = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mBMapMan = new BMapManager(getApplication());
		mBMapMan.init(BAIDU_API_KEY, null);

		// 注意：请在试用setContentView前初始化BMapManager对象，否则会报错
		setContentView(R.layout.map_baidu);

		context = this;

		mapToolToilet = (Button) findViewById(R.id.map_tool_toilet);
		mapToolParking = (Button) findViewById(R.id.map_tool_parking);
		mapToolBusStop = (Button) findViewById(R.id.map_tool_bus_stop);
		mapToolScenicSpot = (Button) findViewById(R.id.map_tool_scenic_spot);
		mapToolHome = (ImageButton) findViewById(R.id.map_tools_home);
		mapToolGps = (ImageButton) findViewById(R.id.map_tool_gps);
		mapToolZoomIn = (ImageButton) findViewById(R.id.map_tool_zoom_in);
		mapToolZoomOut = (ImageButton) findViewById(R.id.map_tool_zoom_out);

		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,
				0, (LocationListener) context);

		mapToolToilet.setOnClickListener(mapToolToiletClicked);
		mapToolParking.setOnClickListener(mapToolParkingClicked);
		mapToolBusStop.setOnClickListener(mapToolBusStopClicked);
		mapToolScenicSpot.setOnClickListener(mapToolScenicSpotClicked);
		mapToolHome.setOnClickListener(homeButtonClicked);
		mapToolGps.setOnClickListener(mapToolGpsClicked);
		mapToolZoomIn.setOnClickListener(mapToolZoomInClicked);
		mapToolZoomOut.setOnClickListener(mapToolZoomOutClicked);

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		spotDataSource = new SpotDataSource(context);
		locationDataSource = new LocationDataSource(context);

		mMapView = (MapView) findViewById(R.id.bmapsView);
		// mMapView.setBuiltInZoomControls(true);
		if (null != mMapView) {
			hasMap = true;
		}

		// 设置启用内置的缩放控件
		mMapController = mMapView.getController();

		// Get spot record id
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			spotRecordId = extras.getInt("EXTRA_SELECTED_SPOT");
			if (spotRecordId > 0) {
				spot = spotDataSource.getById(spotRecordId, LANGUAGE_ID);
				if (null != spot) {
					lat = spot.getBaidu_map_y();
					lng = spot.getBaidu_map_x();
					zoom = spot.getZoom();
					showSpot = true;
					mapToolScenicSpot.setSelected(true);
				}
			} else {
				LatLng gpsPosition = getGpsPosition();
				lat = (float) gpsPosition.latitude;
				lng = (float) gpsPosition.longitude;
			}

			String showLocationTypeName = extras
					.getString("EXTRA_LOCATION_TYPE_NAME");
			if (null != showLocationTypeName) {
				if (showLocationTypeName.equals("toilet")) {
					showToilet = true;
					mapToolToilet.setSelected(true);
				} else if (showLocationTypeName.equals("parking")) {
					showParking = true;
					mapToolParking.setSelected(true);
				}
			}
		} else {
			LatLng gpsPosition = getGpsPosition();
			lat = (float) gpsPosition.latitude;
			lng = (float) gpsPosition.longitude;
		}

		// Set map
		setUpMap();

		dataSource.close();
	}

	private GeoPoint toGeoPoint(double lat, double lng) {
		GeoPoint geoPoint = new GeoPoint((int) (lat * BAIDU_MAP_COORD_MOD),
				(int) (lng * BAIDU_MAP_COORD_MOD));
		return geoPoint;
	}

	private void setUpMap() {
		if (hasMap) {

			mMapView.getOverlays().clear();

			if (firstRun) {
				mMapController.setCenter(toGeoPoint(lat, lng));// 设置地图中心点
				mMapController.setZoom(zoom);// 设置地图zoom级别
				firstRun = false;
			}

			// Get locations
			List<Location> locations = locationDataSource
					.getAllByLang(LANGUAGE_ID);
			List<Spot> spots = spotDataSource.getAllByLang(LANGUAGE_ID);

			if (null != locations) {
				// Set Locations
				for (Location location : locations) {
					// If show**** is on, show the icon
					if (isThisLocationOn(location)) {
						double lat = location.getBaidu_map_y();
						double lng = location.getBaidu_map_x();
						String title = location.getTitle();
						String snippet = location.getOpen_time()
								+ location.getContent();
						int iconResourceId = getIconResourceId(location
								.getType_id());

						Drawable mark = getResources().getDrawable(
								iconResourceId);
						GeoPoint geoPoint = toGeoPoint(lat, lng);
						OverlayItem overlayItem = new OverlayItem(geoPoint,
								title, snippet);

						BaiduItemizedOverlay itemOverlay = new BaiduItemizedOverlay(
								mark, mMapView, context);
						mMapView.getOverlays().add(itemOverlay);
						itemOverlay.addItem(overlayItem);
						// TODO
						// Get icon ID
						// Add marker
						// mMap.addMarker(new MarkerOptions()
						// .position(new LatLng(lat, lng))
						// .title(title)
						// .snippet(snippet)
						// .icon(BitmapDescriptorFactory
						// .fromResource(iconResourceId)));
					}
				}

				// Set spot
				if (showSpot) {
					for (Spot spot : spots) {
						double lat = spot.getBaidu_map_y();
						double lng = spot.getBaidu_map_x();
						String title = spot.getTitle();
						int iconResourceId = R.drawable.map_icon_scenic_spot;

						Drawable mark = getResources().getDrawable(
								iconResourceId);
						GeoPoint geoPoint = toGeoPoint(lat, lng);
						OverlayItem overlayItem = new OverlayItem(geoPoint,
								title, "");

						BaiduItemizedOverlay itemOverlay = new BaiduItemizedOverlay(
								mark, mMapView, context);
						mMapView.getOverlays().add(itemOverlay);
						itemOverlay.addItem(overlayItem);
						// Log.d("guide", "show spot" + title);

						// TODO
						// Marker marker = mMap.addMarker(new MarkerOptions()
						// .position(new LatLng(lat, lng))
						// .title(title)
						// .icon(BitmapDescriptorFactory
						// .fromResource(iconResourceId)));

						if (null != this.spot
								&& this.spot.getRecord_id() == spot
										.getRecord_id()) {
							// TODO
							// marker.showInfoWindow();
						}

					}
				}
				mMapView.refresh();

			}
		}
	}

	// Locations on/off
	View.OnClickListener mapToolToiletClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showToilet = showToilet ? false : true;
			mapToolToilet.setSelected(showToilet);
			setUpMap();
		}
	};
	View.OnClickListener mapToolParkingClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showParking = showParking ? false : true;
			mapToolParking.setSelected(showParking);
			setUpMap();
		}
	};
	View.OnClickListener mapToolBusStopClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showBusStop = showBusStop ? false : true;
			mapToolBusStop.setSelected(showBusStop);
			setUpMap();
		}
	};
	View.OnClickListener mapToolScenicSpotClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showSpot = showSpot ? false : true;
			mapToolScenicSpot.setSelected(showSpot);
			setUpMap();
		}
	};

	// Set to GPS position
	View.OnClickListener mapToolGpsClicked = new View.OnClickListener() {
		public void onClick(View v) {
			setToGpsPosition();
		}
	};

	// Zoom in/out
	View.OnClickListener mapToolZoomInClicked = new View.OnClickListener() {
		public void onClick(View v) {
			if (hasMap) {
				mMapController.zoomIn();
			}
		}
	};
	View.OnClickListener mapToolZoomOutClicked = new View.OnClickListener() {
		public void onClick(View v) {
			if (hasMap) {
				mMapController.zoomOut();
			}
		}
	};

	private LatLng getGpsPosition() {
		LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
		boolean enabled = service
				.isProviderEnabled(LocationManager.GPS_PROVIDER);

		LatLng newTarget;
		if (!enabled) {
			newTarget = new LatLng(this.lat, this.lng);
		} else {
			locationManager.requestLocationUpdates(
					LocationManager.GPS_PROVIDER, 0, 0,
					(LocationListener) context);
			List<String> providers = locationManager.getProviders(true);

			android.location.Location location = null;
			for (int i = 0; i < providers.size(); i++) {
				location = locationManager.getLastKnownLocation(providers
						.get(i));
				if (location != null)
					break;
			}

			double lat = location.getLatitude();
			double lng = location.getLongitude();

			newTarget = new LatLng(lat, lng);
		}

		return newTarget;
	}

	// Set to GPS position
	private void setToGpsPosition() {
		if (hasMap) {
			LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
			boolean enabled = service
					.isProviderEnabled(LocationManager.GPS_PROVIDER);

			// Check if enabled and if not send user to the GSP settings
			// Better solution would be to display a dialog and suggesting
			// to go to the settings
			if (!enabled) {
				Log.d("guide", "not enabled");
				Intent intent = new Intent(
						Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				startActivity(intent);
			} else {
				LatLng newTarget = getGpsPosition();
				mMapController.animateTo(toGeoPoint(newTarget.latitude,
						newTarget.longitude));
			}
		}
	}

	// Resource ID
	private int getIconResourceId(int typeId) {
		int iconResourceId = R.drawable.ic_launcher;
		switch (typeId) {
		case TOILET_ID:
			iconResourceId = R.drawable.map_icon_toilet;
			break;
		case ACCESSIBLE_TOILET_ID:
			iconResourceId = R.drawable.map_icon_accessible_toilet;
			break;
		case CAR_PARK_ID:
			iconResourceId = R.drawable.map_icon_carpark;
			break;
		case DISABLED_PARKING_ID:
			iconResourceId = R.drawable.map_icon_disabled_parking;
			break;
		case BUS_STOP_ID:
			iconResourceId = R.drawable.map_icon_bus_stop;
			break;
		case SCENIC_SPOT_ID:
			iconResourceId = R.drawable.map_icon_scenic_spot;
			break;
		}

		return iconResourceId;
	}

	private boolean isThisLocationOn(Location location) {
		boolean isOn = false;
		int typeId = location.getType_id();
		if (showToilet
				&& (typeId == TOILET_ID || typeId == ACCESSIBLE_TOILET_ID)) {
			isOn = true;
		} else if (showParking
				&& (typeId == CAR_PARK_ID || typeId == DISABLED_PARKING_ID)) {
			isOn = true;
		} else if (showBusStop && typeId == BUS_STOP_ID) {
			isOn = true;
		}
		return isOn;
	}

	@Override
	protected void onDestroy() {
		mMapView.destroy();
		if (mBMapMan != null) {
			mBMapMan.destroy();
			mBMapMan = null;
		}
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		mMapView.onPause();
		if (mBMapMan != null) {
			mBMapMan.stop();
		}
		super.onPause();
	}

	@Override
	protected void onResume() {
		mMapView.onResume();
		if (mBMapMan != null) {
			mBMapMan.start();
		}
		super.onResume();
	}

	@Override
	public void onLocationChanged(android.location.Location arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		// TODO Auto-generated method stub

	}
}
