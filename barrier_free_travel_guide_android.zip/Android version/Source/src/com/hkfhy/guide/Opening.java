package com.hkfhy.guide;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Environment;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;

import com.anglia.library.AlertDialogManager;
import com.anglia.library.ConnectionDetector;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hkfhy.asynctask.UpdateLocationTask;
import com.hkfhy.asynctask.UpdateThumbnailFromSpotsTask;
import com.hkfhy.data.Data;
import com.hkfhy.data.District;
import com.hkfhy.data.Location;
import com.hkfhy.data.LocationType;
import com.hkfhy.data.Page;
import com.hkfhy.data.Spot;
import com.hkfhy.data.SpotType;
import com.hkfhy.data.Thumbnail;
import com.hkfhy.data.Version;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.DistrictDataSource;
import com.hkfhy.datasource.LocationDataSource;
import com.hkfhy.datasource.LocationTypeDataSource;
import com.hkfhy.datasource.PageDataSource;
import com.hkfhy.datasource.SpotDataSource;
import com.hkfhy.datasource.SpotTypeDataSource;
import com.hkfhy.datasource.ThumbnailDataSource;
import com.hkfhy.datasource.VersionDataSource;

public class Opening extends MyActivity {
	protected boolean _active = true;
	protected int _splashTime = 5000;
	private boolean connected = false;

	private static final String DATA_JSON_URL = DOMAIN
			+ "data.json?without=location";
	// private static final String DATA_JSON_URL = DOMAIN + "data.json";
	private static final String VERSION_JSON_URL = DOMAIN + "version.json";

	public static int OPENING_MIN_SHOW_TIME = 2000;

	public Context context;
	protected SharedPreferences prefs;

	ProgressDialog progressDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.opening);

		Log.d("guide", "start app");

		context = this;

		prefs = PreferenceManager.getDefaultSharedPreferences(context);

		// Set up the language
		String key = "lang";
		String prefLang = prefs.getString(key, ZH_HK);
		String currentLang;

		if (prefLang.equals(ZH_HK)) {
			currentLang = ZH_HK;
			LANGUAGE_ID = LANGUAGE_ID_ZH_HK;
		} else {
			currentLang = EN_US;
			LANGUAGE_ID = LANGUAGE_ID_EN_US;
		}

		prefs.edit().putString(key, currentLang).commit();

		Resources res = context.getResources();
		// Change locale settings in the app.
		DisplayMetrics dm = res.getDisplayMetrics();
		android.content.res.Configuration conf = res.getConfiguration();
		conf.locale = new Locale(currentLang.toLowerCase());
		res.updateConfiguration(conf, dm);

		// Check network status
		ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
		connected = cd.isConnectingToInternet();
		AlertDialogManager alert = new AlertDialogManager();
		if (!connected) {
			if (!this.isFinishing()) {
				alert.showAlertDialog(this, null,
						getString(R.string.connection_error));
			}
		}

		if (!this.isFinishing()) {
			progressDialog = new ProgressDialog(this);
			progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			progressDialog.setMessage(getResources()
					.getString(R.string.loading));
			progressDialog.setIndeterminate(false);
			progressDialog.setCancelable(false);
			progressDialog.setMax(0);
			progressDialog.setProgress(0);
			progressDialog.show();
		}

		// If connected, update the app data
		Thread updateDataThread = new Thread() {
			@Override
			public void run() {
				Looper.prepare();

				boolean needUpdate = false;
				try {
					Log.d("guide", "version data requesting");

					// Create a new HTTP Client
					DefaultHttpClient defaultClient = new DefaultHttpClient();
					HttpGet httpGetRequest;
					HttpResponse httpResponse;
					BufferedReader reader;

					// Request version JSON
					httpGetRequest = new HttpGet(VERSION_JSON_URL);
					httpResponse = defaultClient.execute(httpGetRequest);
					reader = new BufferedReader(new InputStreamReader(
							httpResponse.getEntity().getContent(), "UTF-8"));
					String versionJSON = reader.readLine();

					// Convert JSON
					Gson gson = new Gson();
					JsonParser parser = new JsonParser();

					// Convert version JSON to object
					JsonObject versionJsonObj = parser.parse(versionJSON)
							.getAsJsonObject();
					Version version = gson.fromJson(versionJsonObj,
							Version.class);

					versionJSON = null;

					Log.d("guide", "version data ready");

					/*
					 * Update data spots districts spot_type locations
					 * location_type
					 */

					// Update data if data version in JSON is greater
					// Data source
					dataSource = new DataSource(context);
					dataSource.open();

					VersionDataSource versionDataSource = new VersionDataSource(
							context);

					int currentDataVersion = versionDataSource
							.getCurrentDataVersion();
					Log.d("database", "Current data version: "
							+ currentDataVersion);
					Log.d("database",
							"New data version: " + version.getData_version());

					int total_location = version.getTotal_location();
					prefs.edit().putInt("total_location", total_location)
							.commit();
					prefs.edit().putInt("updated_location", total_location)
							.commit();

					LocationDataSource locationDataSource = new LocationDataSource(
							context);
					int downloadedTotalLocation = locationDataSource.getTotal();

					Bundle extras = getIntent().getExtras();
					// if (extras != null) {
					// needUpdate = extras.getBoolean("EXTRA_NEED_UPDATE",
					// false);
					// }
					if (downloadedTotalLocation != total_location) {
						Log.d(TAG,
								"downloadedTotalLocation != total_location: "
										+ downloadedTotalLocation + "/"
										+ total_location);
						prefs.edit().putInt("updated_location", 0).commit();
						needUpdate = true;
					}

					if (currentDataVersion < version.getData_version()) {
						Log.d("database", "update version");

						Log.d("guide", "data requesting");

						// Request data JSON
						httpGetRequest = new HttpGet(DATA_JSON_URL);
						httpResponse = defaultClient.execute(httpGetRequest);
						reader = new BufferedReader(new InputStreamReader(
								httpResponse.getEntity().getContent(), "UTF-8"));
						String dataJSON = reader.readLine();

						JsonObject dataJsonObj = parser.parse(dataJSON)
								.getAsJsonObject();

						dataJSON = null;

						// Convert data JSON to object
						JsonObject zhJsonObj = dataJsonObj.get("zh-hant")
								.getAsJsonObject();
						JsonObject enJsonObj = dataJsonObj.get("en")
								.getAsJsonObject();

						Log.d("guide", "data ready");

						Data zhData = gson.fromJson(zhJsonObj, Data.class);
						Data enData = gson.fromJson(enJsonObj, Data.class);

						int zhTotal = zhData.getTotal();
						int enTotal = enData.getTotal();
						int dataTotal = enTotal + zhTotal;

						Log.d(TAG, "data total: " + dataTotal);

						progressDialog.setMax(dataTotal);

						dataSource.cleanUpAllData();

						prefs.edit().putInt("updated_location", 0).commit();
						needUpdate = true;

						updateData(zhData, version);
						updateData(enData, version);

						if (null != version) {
							versionDataSource.update(version);
						}

						if (DEVELOPER_MODE) {
							copyDatabaseToCard();
						}
					} else {
						Log.d("database", "no data update");
					}

					dataSource.close();

					progressDialog.dismiss();

					sleep(1000);
				} catch (InterruptedException e) {
					Log.e("guide", "InterruptedException: " + e.getMessage());
				} catch (ClientProtocolException e) {
					Log.e("guide", "ClientProtocolException: " + e.getMessage());
				} catch (IOException e) {
					Log.e("guide", "IOException: " + e.getMessage());
				} finally {
					Log.d("guide", "opening home activity");

					finish();

					Intent intent = new Intent(getBaseContext(), Home.class);
					intent.putExtra("EXTRA_NEED_UPDATE", needUpdate);
					startActivity(intent);
					// startActivity(new Intent(Opening.this, Home.class));
				}

				Looper.loop();
			}
		};

		// If not connected, sleep a few seconds to show the opening
		Thread justShowOpening = new Thread() {
			@Override
			public void run() {
				try {
					progressDialog.dismiss();
					Log.d("guide", "no connection / skip data update");
					sleep(OPENING_MIN_SHOW_TIME);
					startActivity(new Intent(Opening.this, Home.class));
				} catch (InterruptedException e) {
					Log.e("guide", "InterruptedException: " + e.getMessage());
				}
			}
		};

		// Handle the opening mode

		if (SKIP_OPENING) {
			// For developing
			OPENING_MIN_SHOW_TIME = 0;
			justShowOpening.start();
		} else {
			if (connected) {
				updateDataThread.start();
			} else {
				justShowOpening.start();
			}
		}
	}

	private void addProgress() {
		int newProgress = progressDialog.getProgress() + 1;
		progressDialog.setProgress(newProgress);
	}

	private void updateData(Data data, Version version) {

		List<Spot> spots = (List<Spot>) data.getSpot();
		List<Location> locations = (List<Location>) data.getLocation();
		List<District> districts = (List<District>) data.getDistrict();
		List<SpotType> spotTypes = (List<SpotType>) data.getSpot_type();
		List<LocationType> locationTypes = (List<LocationType>) data
				.getLocation_type();
		List<Page> pages = (List<Page>) data.getPage();

		SpotDataSource spotDataSource = new SpotDataSource(context);
		ThumbnailDataSource thumbnailDataSource = new ThumbnailDataSource(
				context);
		DistrictDataSource districtDataSource = new DistrictDataSource(context);
		LocationDataSource locationDataSource = new LocationDataSource(context);
		SpotTypeDataSource spotTypeDataSource = new SpotTypeDataSource(context);
		LocationTypeDataSource locationTypeDataSource = new LocationTypeDataSource(
				context);
		PageDataSource pageDataSource = new PageDataSource(context);

		if (null != spots) {
			for (Spot record : spots) {
				addProgress();
				spotDataSource.update(record);
				Log.d("database",
						"Spot (" + record.getId() + "): " + record.getTitle());

				// Download thumbnails
				List<Thumbnail> thumbnailList = record.getPhotos()
						.getThumbnail();
				if (null != thumbnailList) {
					int seq = 0;
					for (Thumbnail thumb : thumbnailList) {
						// Log.d("database", "Thumb (" + record.getRecord_id()
						// + "): " + thumb.getPath());

						File fileWithinMyDir = getApplicationContext()
								.getFilesDir();

						// new UpdateThumbnailTask(thumbnailDataSource, thumb,
						// record, DOMAIN, fileWithinMyDir).execute("");
					}
				}
			}

			File fileWithinMyDir = getApplicationContext().getFilesDir();
			new UpdateThumbnailFromSpotsTask(thumbnailDataSource, spots,
					DOMAIN, fileWithinMyDir).execute("");
		}

		if (null != locations) {
			Log.d(TAG, "Update total " + locations.size()
					+ " locations in background");
			for (Location record : locations) {
				// locationDataSource.update(record);

				new UpdateLocationTask(locationDataSource, record).execute("");
				// Log.d("database", "Location (" + record.getId() + "): "
				// + record.getTitle());
			}
		}

		if (null != districts) {
			for (District record : districts) {
				addProgress();
				districtDataSource.update(record);
				Log.d("database", "District (" + record.getId() + "): "
						+ record.getTitle());
			}
		}

		if (null != spotTypes) {
			for (SpotType record : spotTypes) {
				addProgress();
				spotTypeDataSource.update(record);
				Log.d("database", "Spot type (" + record.getId() + "): "
						+ record.getTitle());
			}
		}

		if (null != locationTypes) {
			for (LocationType record : locationTypes) {
				addProgress();
				locationTypeDataSource.update(record);
				Log.d("database", "Location type (" + record.getId() + "): "
						+ record.getTitle());
			}
		}

		if (null != pages) {
			for (Page record : pages) {
				addProgress();
				pageDataSource.update(record);
				Log.d("database",
						"Page (" + record.getId() + "): " + record.getTitle());
			}
		}
	}

	public void copyDatabaseToCard() {
		try {
			Log.d("database", "start backup copy");
			File sdcard = Environment.getExternalStorageDirectory();
			File outputFile = new File(sdcard, "guide.db");
			if (!outputFile.exists())
				outputFile.createNewFile();

			File data = Environment.getDataDirectory();
			File inputFile = new File(data, "data/" + getPackageName()
					+ "/databases/" + "guide.db");
			InputStream input = new FileInputStream(inputFile);
			OutputStream output = new FileOutputStream(outputFile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = input.read(buffer)) > 0) {
				output.write(buffer, 0, length);
			}
			output.flush();
			output.close();
			input.close();
			Log.d("database", "end backup copy");
		} catch (IOException e) {
			Log.d("database", "fail backup copy");
			e.printStackTrace();
			throw new Error("Copying Failed");
		}
	}

}
