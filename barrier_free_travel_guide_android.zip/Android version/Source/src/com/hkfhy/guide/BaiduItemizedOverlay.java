package com.hkfhy.guide;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.Toast;

import com.baidu.mapapi.map.ItemizedOverlay;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.OverlayItem;
import com.baidu.platform.comapi.basestruct.GeoPoint;

public class BaiduItemizedOverlay extends ItemizedOverlay<OverlayItem> {

	Context context;

	// 用MapView构造ItemizedOverlay
	public BaiduItemizedOverlay(Drawable mark, MapView mapView) {
		super(mark, mapView);
	}

	public BaiduItemizedOverlay(Drawable mark, MapView mapView, Context context) {
		super(mark, mapView);
		this.context = context;
	}

	protected boolean onTap(int index) {
		// 在此处理item点击事件
		String title = this.getItem(index).getTitle();
		String snippet = this.getItem(index).getSnippet();
		String showText = title;
		if (snippet != "") {
			showText += ": " + snippet;
		}

		Toast.makeText(context, showText, Toast.LENGTH_LONG).show();
		return true;
	}

	public boolean onTap(GeoPoint pt, MapView mapView) {
		// 在此处理MapView的点击事件，当返回 true时
		super.onTap(pt, mapView);
		return false;
	}
}