package com.hkfhy.guide;

import java.util.HashMap;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.hkfhy.data.Location;
import com.hkfhy.data.Spot;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.LocationDataSource;
import com.hkfhy.datasource.SpotDataSource;

public class Map extends MyFragmentActivity implements LocationListener {
	private static final int ZOOM_CAMERA_DURATION = 300;
	// private static final int DEFAULT_ZOOM_LEVEL = 15;

	private DataSource dataSource;
	private SpotDataSource spotDataSource;
	private LocationDataSource locationDataSource;

	private int spotRecordId = 0;

	private Spot spot = null;

	ProgressDialog progressDialog;

	// Buttons
	Button mapToolToilet;
	Button mapToolParking;
	Button mapToolBusStop;
	Button mapToolScenicSpot;
	ImageButton mapToolHome;
	ImageButton mapToolGps;
	ImageButton mapToolZoomIn;
	ImageButton mapToolZoomOut;

	LocationManager locationManager;

	// Map
	private HashMap<Marker, Location> locationMap = new HashMap<Marker, Location>();
	private HashMap<Marker, Spot> spotMap = new HashMap<Marker, Spot>();

	private GoogleMap mMap;
	private boolean hasMap = false;
	private float lat = (float) 22.3;
	private float lng = (float) 114.17;
	private int zoom = 16;

	private boolean positionFound = false;
	private boolean positionShown = false;

	private boolean firstRun = true;

	// Show location type
	private boolean showToilet = false;
	private boolean showParking = false;
	private boolean showSpot = false;
	private boolean showBusStop = false;

	int updated_location = 0;
	int total_location = 0;

	// Lightbox
	RelativeLayout mapInfoFrame;
	TextView mapInfoTitle;
	TextView mapInfoOpenTime;
	WebView mapInfoContent;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);

		context = this;

		// prefs = getSharedPreferences(APP_PACKAGE_NAME, Context.MODE_PRIVATE);
		prefs = PreferenceManager.getDefaultSharedPreferences(context);
		prefs.registerOnSharedPreferenceChangeListener(spChanged);
		USE_MAP_SERVICE = prefs.getString("map_type", MAP_GOOGLE);

		String prefLang = prefs.getString("lang", ZH_HK);
		if (prefLang.equals(ZH_HK)) {
			LANGUAGE_ID = LANGUAGE_ID_ZH_HK;
		} else {
			LANGUAGE_ID = LANGUAGE_ID_EN_US;
		}

		mapToolToilet = (Button) findViewById(R.id.map_tool_toilet);
		mapToolParking = (Button) findViewById(R.id.map_tool_parking);
		mapToolBusStop = (Button) findViewById(R.id.map_tool_bus_stop);
		mapToolScenicSpot = (Button) findViewById(R.id.map_tool_scenic_spot);
		mapToolHome = (ImageButton) findViewById(R.id.map_tools_home);
		mapToolGps = (ImageButton) findViewById(R.id.map_tool_gps);
		mapToolZoomIn = (ImageButton) findViewById(R.id.map_tool_zoom_in);
		mapToolZoomOut = (ImageButton) findViewById(R.id.map_tool_zoom_out);

		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,
				0, (LocationListener) context);

		mapToolToilet.setOnClickListener(mapToolToiletClicked);
		mapToolParking.setOnClickListener(mapToolParkingClicked);
		mapToolBusStop.setOnClickListener(mapToolBusStopClicked);
		mapToolScenicSpot.setOnClickListener(mapToolScenicSpotClicked);
		mapToolHome.setOnClickListener(homeButtonClicked);
		mapToolGps.setOnClickListener(mapToolGpsClicked);
		mapToolZoomIn.setOnClickListener(mapToolZoomInClicked);
		mapToolZoomOut.setOnClickListener(mapToolZoomOutClicked);

		mapInfoFrame = (RelativeLayout) findViewById(R.id.map_info_frame);
		mapInfoTitle = (TextView) findViewById(R.id.map_info_title);
		mapInfoOpenTime = (TextView) findViewById(R.id.map_info_open_time);
		mapInfoContent = (WebView) findViewById(R.id.map_info_content);

		mapInfoFrame.setOnClickListener(mapInfoFrameClicked);

		updated_location = prefs.getInt("updated_location", 0);
		total_location = prefs.getInt("total_location", 0);

		if (!this.isFinishing() && total_location > 0
				&& total_location > updated_location) {
			progressDialog = new ProgressDialog(this);
			progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			progressDialog.setMessage(getResources()
					.getString(R.string.loading));
			progressDialog.setIndeterminate(false);
			progressDialog.setCancelable(false);
			progressDialog.setMax(total_location);
			progressDialog.setProgress(updated_location);
			progressDialog.show();
		}

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		spotDataSource = new SpotDataSource(context);
		locationDataSource = new LocationDataSource(context);

		// Get spot record id
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			spotRecordId = extras.getInt("EXTRA_SELECTED_SPOT");
			if (spotRecordId > 0) {
				spot = spotDataSource.getById(spotRecordId, LANGUAGE_ID);
				if (null != spot) {
					lat = spot.getCenter_lat();
					lng = spot.getCenter_lng();
					zoom = spot.getZoom();
					showSpot = true;
					mapToolScenicSpot.setSelected(true);
				}
			} else {
				LatLng gpsPosition = getGpsPosition();
				lat = (float) gpsPosition.latitude;
				lng = (float) gpsPosition.longitude;
			}

			String showLocationTypeName = extras
					.getString("EXTRA_LOCATION_TYPE_NAME");
			if (null != showLocationTypeName) {
				if (showLocationTypeName.equals("toilet")) {
					showToilet = true;
					mapToolToilet.setSelected(true);
				} else if (showLocationTypeName.equals("parking")) {
					showParking = true;
					mapToolParking.setSelected(true);
				}
			}
		} else {
			LatLng gpsPosition = getGpsPosition();
			lat = (float) gpsPosition.latitude;
			lng = (float) gpsPosition.longitude;
		}

		// Set googlemap
		android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
		SupportMapFragment mapFragment = (SupportMapFragment) fragmentManager
				.findFragmentById(R.id.map);
		mMap = mapFragment.getMap();
		if (null != mMap) {
			mMap.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
				@Override
				public void onInfoWindowClick(Marker marker) {
					Location location = locationMap.get(marker);
					if (null != location) {
						Log.d(TAG,
								marker.getId() + " location: "
										+ location.getTitle());

						mapInfoFrame.setVisibility(View.VISIBLE);
						mapInfoTitle.setText(location.getTitle());

						String openTime = location.getOpen_time();
						if (!openTime.isEmpty()) {
							mapInfoOpenTime.setText(openTime);
						}

						// String content = convertHtml(location.getContent());
						// mapInfoContent.setText(content);

						// String content = location.getContent();
						// String decodedHtml =
						// Html.fromHtml(content).toString();
						// decodedHtml = replaceHtmlImageLink(decodedHtml);
						String content = location.getContent();
						content = Html.fromHtml(content).toString();
						content = replaceHtmlImageLink(content);

						mapInfoContent.setBackgroundColor(0x00000000);
						mapInfoContent.loadDataWithBaseURL(null, content,
								"text/html", "utf-8", null);
					} else {
						Spot spot = spotMap.get(marker);
						if (null != spot) {
							// Go spot detail page
							Intent intent = new Intent(getBaseContext(),
									SpotDetail.class);
							intent.putExtra("EXTRA_SELECTED_SPOT",
									spot.getRecord_id());
							startActivity(intent);
						}
					}

				}
			});
		}

		if (total_location <= 0 || total_location <= updated_location) {
			setUpMap();
		}

		dataSource.close();
	}

	SharedPreferences.OnSharedPreferenceChangeListener spChanged = new SharedPreferences.OnSharedPreferenceChangeListener() {
		@Override
		public void onSharedPreferenceChanged(SharedPreferences arg0,
				String arg1) {

			updated_location = prefs.getInt("updated_location", 0);
			total_location = prefs.getInt("total_location", 0);
			// Log.d(TAG, "progress change: " + updated_location + "/"
			// + total_location);

			if (progressDialog != null) {
				progressDialog.setMax(total_location);
				progressDialog.setProgress(updated_location);
			}

			if (updated_location >= total_location) {
				Log.d(TAG, "map locations all loaded: " + updated_location
						+ "/" + total_location);
				if (progressDialog != null) {
					progressDialog.dismiss();
				}
				setUpMap();
			}
		}
	};

	public void updateAdapter(Marker marker, Location location) {
		locationMap.put(marker, location);
	}

	@SuppressLint("NewApi")
	private void setUpMap() {
		// Do a null check to confirm that we have not already instantiated the
		// map.
		if (mMap == null) {
			android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
			SupportMapFragment mapFragment = (SupportMapFragment) fragmentManager
					.findFragmentById(R.id.map);
			mMap = mapFragment.getMap();
			// Check if we were successful in obtaining the map.
			if (mMap != null) {
				// The Map is verified. It is now safe to manipulate the map.
				hasMap = true;
			}
		} else {
			hasMap = true;
		}

		if (hasMap) {

			LatLng centerLatLng = new LatLng(lat, lng);

			UiSettings uiSettings = mMap.getUiSettings();
			uiSettings.setZoomControlsEnabled(false);

			mMap.clear();

			if (firstRun) {
				mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(centerLatLng,
						zoom));
				firstRun = false;
			}

			// progressDialog = ProgressDialog.show(this, "", getResources()
			// .getString(R.string.loading), true);
			// progressDialog.setCancelable(true);

			// Get locations
			final List<Location> locations = locationDataSource
					.getAllByLang(LANGUAGE_ID);
			final List<Spot> spots = spotDataSource.getAllByLang(LANGUAGE_ID);

			Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
				public void run() {
					if (!locations.isEmpty()) {
						// Set Locations
						for (final Location location : locations) {
							// If show**** is on, show the icon
							if (isThisLocationOn(location)) {

								// AddMarkerTask addMarkerTask = new
								// AddMarkerTask(this,
								// context, location, mMap);
								// addMarkerTask.execute();

								double lat = location.getMap_lat();
								double lng = location.getMap_lng();
								String title = location.getTitle();
								String snippet = location.getOpen_time()
										+ stripHtml(Html.fromHtml(
												location.getContent())
												.toString());
								int iconResourceId = getIconResourceId(location
										.getType_id());

								// Get icon ID
								// Add marker
								Marker marker = mMap.addMarker(new MarkerOptions()
										.position(new LatLng(lat, lng))
										.title(title)
										.snippet(snippet)
										.icon(BitmapDescriptorFactory
												.fromResource(iconResourceId)));

								locationMap.put(marker, location);

							}
						}

						// Set spot
						if (showSpot) {
							for (Spot spot : spots) {
								double lat = spot.getMap_lat();
								double lng = spot.getMap_lng();
								String title = spot.getTitle();
								int iconResourceId = R.drawable.map_icon_scenic_spot;

								// Log.d("guide", "show spot" + title);

								Marker marker = mMap
										.addMarker(new MarkerOptions()
												.position(new LatLng(lat, lng))
												.title(title)
												.icon(BitmapDescriptorFactory
														.fromResource(iconResourceId)));

								spotMap.put(marker, spot);
								// if (null != this.spot
								// && this.spot.getRecord_id() == spot
								// .getRecord_id()) {
								// marker.showInfoWindow();
								// }

							}
						}

					}
					// progressDialog.dismiss();
				}
			}, 500);

			positionShown = false;
			setToGpsPosition(false);

			// progressDialog.dismiss();

		}
	}

	private LatLng getGpsPosition() {
		LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
		boolean isEnableGPS = service
				.isProviderEnabled(LocationManager.GPS_PROVIDER);
		boolean isEnableNTW = service
				.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

		isEnableNTW = true;

		android.location.Location gpsLocation = null;
		android.location.Location ntwLocation = null;
		LatLng newTarget = null;

		Log.d(TAG, "ProviderEnabled: GPS " + isEnableGPS + ", NTW "
				+ isEnableNTW);

		if (isEnableGPS) {
			locationManager.requestLocationUpdates(
					LocationManager.GPS_PROVIDER, 0, 0,
					(LocationListener) context);

			gpsLocation = locationManager
					.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		}
		if (isEnableNTW) {
			locationManager.requestLocationUpdates(
					LocationManager.NETWORK_PROVIDER, 0, 0,
					(LocationListener) context);

			long ntwLocationTime = 0;
			android.location.Location newNtwLocation = null;
			List<String> providers = locationManager.getProviders(true);
			for (int i = 0; i < providers.size(); i++) {
				newNtwLocation = locationManager.getLastKnownLocation(providers
						.get(i));
				if (null != newNtwLocation) {
					if (ntwLocationTime < newNtwLocation.getTime()) {
						ntwLocationTime = newNtwLocation.getTime();
						ntwLocation = newNtwLocation;
					}
				}
			}
		}

		if (null != gpsLocation && null != ntwLocation) {
			// Log.d(TAG, "GPS accuracy: " + gpsLocation.getAccuracy());
			// Log.d(TAG, "GPS time: " + gpsLocation.getTime());
			// Log.d(TAG, "NTW accuracy: " + ntwLocation.getAccuracy());
			// Log.d(TAG, "NTW time: " + ntwLocation.getTime());

			if (gpsLocation.getTime() > ntwLocation.getTime()) {
				double lat = gpsLocation.getLatitude();
				double lng = gpsLocation.getLongitude();

				Log.d(TAG, "GPS location: " + lat + ", " + lng);
				newTarget = new LatLng(lat, lng);
			} else {
				double lat = ntwLocation.getLatitude();
				double lng = ntwLocation.getLongitude();

				Log.d(TAG, "NTW location: " + lat + ", " + lng);
				newTarget = new LatLng(lat, lng);
			}
		} else if (null != gpsLocation) {
			double lat = gpsLocation.getLatitude();
			double lng = gpsLocation.getLongitude();

			Log.d(TAG, "GPS location: " + lat + ", " + lng);
			newTarget = new LatLng(lat, lng);
		} else if (null != ntwLocation) {
			double lat = ntwLocation.getLatitude();
			double lng = ntwLocation.getLongitude();

			Log.d(TAG, "NTW location: " + lat + ", " + lng);
			newTarget = new LatLng(lat, lng);
		}

		if (null == newTarget) {
			Log.d("guide", "isProviderEnabled: not enabled");

			newTarget = new LatLng(this.lat, this.lng);
		}

		positionFound = true;

		return newTarget;
	}

	// Set to GPS position
	private void setToGpsPosition() {
		setToGpsPosition(true);
	}

	private void setToGpsPosition(boolean moveCamera) {
		if (hasMap) {
			LatLng newTarget = getGpsPosition();
			CameraPosition cameraPosition = mMap.getCameraPosition();
			float zoom = cameraPosition.zoom;

			if (moveCamera) {
				mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(newTarget,
						zoom));
			}

			double lat = newTarget.latitude;
			double lng = newTarget.longitude;
			LatLng latlng = new LatLng(lat, lng);

			positionShown = false;
			addPositionPointer(latlng);
		}
	}

	private void addPositionPointer(LatLng latlng) {
		if (hasMap && positionFound && !positionShown) {
			int iconResourceId = R.drawable.google_maps_pin;

			mMap.addCircle(new CircleOptions().center(latlng).radius(100)
					.strokeColor(Color.parseColor("#800000ff"))
					.fillColor(Color.parseColor("#800000ee")));

			mMap.addMarker(new MarkerOptions().position(latlng).icon(
					BitmapDescriptorFactory.fromResource(iconResourceId)));

			positionShown = true;
		}
	}

	// Locations on/off
	View.OnClickListener mapToolToiletClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showToilet = showToilet ? false : true;
			mapToolToilet.setSelected(showToilet);
			setUpMap();
		}
	};
	View.OnClickListener mapToolParkingClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showParking = showParking ? false : true;
			mapToolParking.setSelected(showParking);
			setUpMap();
		}
	};
	View.OnClickListener mapToolBusStopClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showBusStop = showBusStop ? false : true;
			mapToolBusStop.setSelected(showBusStop);
			setUpMap();
		}
	};
	View.OnClickListener mapToolScenicSpotClicked = new View.OnClickListener() {
		public void onClick(View v) {
			showSpot = showSpot ? false : true;
			mapToolScenicSpot.setSelected(showSpot);
			setUpMap();
		}
	};

	// Set to GPS position
	View.OnClickListener mapToolGpsClicked = new View.OnClickListener() {
		public void onClick(View v) {
			positionShown = false;
			setToGpsPosition();
			setUpMap();
		}
	};

	// Zoom in/out
	View.OnClickListener mapToolZoomInClicked = new View.OnClickListener() {
		public void onClick(View v) {
			if (hasMap) {
				CameraPosition cameraPosition = mMap.getCameraPosition();
				LatLng currentTarget = cameraPosition.target;
				float zoom = cameraPosition.zoom + 1;

				mMap.animateCamera(
						CameraUpdateFactory.newLatLngZoom(currentTarget, zoom),
						ZOOM_CAMERA_DURATION, null);
			}
		}
	};
	View.OnClickListener mapToolZoomOutClicked = new View.OnClickListener() {
		public void onClick(View v) {
			if (hasMap) {
				CameraPosition cameraPosition = mMap.getCameraPosition();
				LatLng currentTarget = cameraPosition.target;
				float zoom = cameraPosition.zoom - 1;

				mMap.animateCamera(
						CameraUpdateFactory.newLatLngZoom(currentTarget, zoom),
						ZOOM_CAMERA_DURATION, null);
			}
		}
	};

	// Resource ID
	private int getIconResourceId(int typeId) {
		int iconResourceId = R.drawable.ic_launcher;
		switch (typeId) {
		case TOILET_ID:
			iconResourceId = R.drawable.map_icon_toilet;
			break;
		case ACCESSIBLE_TOILET_ID:
			iconResourceId = R.drawable.map_icon_accessible_toilet;
			break;
		case CAR_PARK_ID:
			iconResourceId = R.drawable.map_icon_carpark;
			break;
		case DISABLED_PARKING_ID:
			iconResourceId = R.drawable.map_icon_disabled_parking;
			break;
		case BUS_STOP_ID:
			iconResourceId = R.drawable.map_icon_bus_stop;
			break;
		case SCENIC_SPOT_ID:
			iconResourceId = R.drawable.map_icon_scenic_spot;
			break;
		}

		return iconResourceId;
	}

	private boolean isThisLocationOn(Location location) {
		boolean isOn = false;
		int typeId = location.getType_id();
		if (showToilet
				&& (typeId == TOILET_ID || typeId == ACCESSIBLE_TOILET_ID)) {
			isOn = true;
		} else if (showParking
				&& (typeId == CAR_PARK_ID || typeId == DISABLED_PARKING_ID)) {
			isOn = true;
		} else if (showBusStop && typeId == BUS_STOP_ID) {
			isOn = true;
		}
		return isOn;
	}

	@Override
	public void onLocationChanged(android.location.Location location) {
		// float accuracy = location.getAccuracy();
		// Log.d(TAG, "onLocationChanged: " + accuracy);
		// setUpMap();
		// setToGpsPosition();
	}

	@Override
	public void onProviderDisabled(String arg0) {
		Log.d(TAG, "onProviderDisabled: " + arg0);

	}

	@Override
	public void onProviderEnabled(String arg0) {
		Log.d(TAG, "onProviderEnabled: " + arg0);

	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		Log.d(TAG, "onStatusChanged: " + arg0);

	}

	View.OnClickListener mapInfoFrameClicked = new View.OnClickListener() {
		public void onClick(View v) {
			mapInfoFrame.setVisibility(View.GONE);
		}
	};
}
