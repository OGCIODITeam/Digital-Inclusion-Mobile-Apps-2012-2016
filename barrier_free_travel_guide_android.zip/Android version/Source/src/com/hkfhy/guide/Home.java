package com.hkfhy.guide;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.hkfhy.asynctask.UpdateLocationsTask;
import com.hkfhy.datasource.LocationDataSource;

public class Home extends MyActivity {

	private final String HKFHY_WEBSITE = "http://www.hkfhy.org.hk";
	private final String OGCIO_WEBSITE = "http://www.ogcio.gov.hk";
	// private static final String LOCATION_DATA_JSON_URL = DOMAIN
	// + "data.json?without=spot,location_type,district,page,spot_type";
	private static final String LOCATION_DATA_JSON_URL = DOMAIN
			+ "location_data.json";

	ImageButton BtnHK;
	ImageButton BtnKLN;
	ImageButton BtnNT;
	ImageButton BtnIsland;
	ImageButton BtnToilet;
	ImageButton BtnParking;
	ImageButton BtnSearch;
	ImageButton BtnComment;
	ImageButton BtnInstrction;

	ImageView footerLogo1;
	ImageView footerLogo2;

	EditText searchInput;
	ImageButton searchSubmit;

	boolean needUpdate = false;
	int totalLocations = 0;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);

		context = this;
		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		setUpPage(context);

		BtnHK = (ImageButton) findViewById(R.id.home_grid_hk);
		BtnKLN = (ImageButton) findViewById(R.id.home_grid_kln);
		BtnNT = (ImageButton) findViewById(R.id.home_grid_nt);
		BtnIsland = (ImageButton) findViewById(R.id.home_grid_island);
		BtnToilet = (ImageButton) findViewById(R.id.home_grid_toilet);
		BtnParking = (ImageButton) findViewById(R.id.home_grid_parking);
		BtnSearch = (ImageButton) findViewById(R.id.home_grid_search);
		BtnComment = (ImageButton) findViewById(R.id.home_grid_comment);
		BtnInstrction = (ImageButton) findViewById(R.id.home_grid_instrction);

		footerLogo1 = (ImageView) findViewById(R.id.footer_logo1);
		footerLogo2 = (ImageView) findViewById(R.id.footer_logo2);

		BtnHK.setOnClickListener(BtnHKClicked);
		BtnKLN.setOnClickListener(BtnKLNClicked);
		BtnNT.setOnClickListener(BtnNTClicked);
		BtnIsland.setOnClickListener(BtnIslandClicked);
		BtnToilet.setOnClickListener(BtnToiletClicked);
		BtnParking.setOnClickListener(BtnParkingClicked);
		BtnSearch.setOnClickListener(BtnSearchClicked);
		BtnComment.setOnClickListener(BtnCommentClicked);
		BtnInstrction.setOnClickListener(BtnInstrctionClicked);

		footerLogo1.setOnClickListener(footerLogo1Clicked);
		footerLogo2.setOnClickListener(footerLogo2Clicked);

		searchInput = (EditText) findViewById(R.id.home_search_input);
		searchInput.setText("");

		searchSubmit = (ImageButton) findViewById(R.id.home_search_submit);
		searchSubmit.setOnClickListener(searchSubmitClicked);

		LocationDataSource locationDataSource = new LocationDataSource(context);
		int downloadedTotalLocation = locationDataSource.getTotal();
		totalLocations = prefs.getInt("total_location", 0);
		
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			needUpdate = extras.getBoolean("EXTRA_NEED_UPDATE", false);
		}

		// needUpdate = true;
		if (needUpdate) {

			Thread updateDataThread = new Thread() {
				@Override
				public void run() {
					Looper.prepare();

					updateData("zh-hant");
					updateData("en");

					Looper.loop();
				}
			};

			updateDataThread.start();

		}
	}

	public void updateData(String lang) {
		LocationDataSource locationDataSource = new LocationDataSource(context);
		new UpdateLocationsTask(locationDataSource, prefs,
				LOCATION_DATA_JSON_URL, lang).execute("");
	}

	// Districts
	View.OnClickListener BtnHKClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(getBaseContext(),
					com.hkfhy.guide.District.class);
			intent.putExtra("EXTRA_HOME_SELECTED_DISTRICT", 0);
			startActivity(intent);
		}
	};
	View.OnClickListener BtnKLNClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(getBaseContext(),
					com.hkfhy.guide.District.class);
			intent.putExtra("EXTRA_HOME_SELECTED_DISTRICT", 1);
			startActivity(intent);
		}
	};
	View.OnClickListener BtnNTClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(getBaseContext(),
					com.hkfhy.guide.District.class);
			intent.putExtra("EXTRA_HOME_SELECTED_DISTRICT", 2);
			startActivity(intent);
		}
	};
	View.OnClickListener BtnIslandClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(getBaseContext(),
					com.hkfhy.guide.District.class);
			intent.putExtra("EXTRA_HOME_SELECTED_DISTRICT", 3);
			startActivity(intent);
		}
	};

	// Locations
	View.OnClickListener BtnToiletClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent;
			if (USE_MAP_SERVICE.equals(MAP_GOOGLE)) {
				intent = new Intent(getBaseContext(), com.hkfhy.guide.Map.class);
			} else {
				intent = new Intent(getBaseContext(),
						com.hkfhy.guide.MapBaidu.class);
			}
			intent.putExtra("EXTRA_LOCATION_TYPE_NAME", "toilet");
			startActivity(intent);
		}
	};
	View.OnClickListener BtnParkingClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent;
			if (USE_MAP_SERVICE.equals(MAP_GOOGLE)) {
				intent = new Intent(getBaseContext(), com.hkfhy.guide.Map.class);
			} else {
				intent = new Intent(getBaseContext(),
						com.hkfhy.guide.MapBaidu.class);
			}
			intent.putExtra("EXTRA_LOCATION_TYPE_NAME", "parking");
			startActivity(intent);
		}
	};

	// Search
	public void goSearch() {
		Intent intent = new Intent(getBaseContext(),
				com.hkfhy.guide.Search.class);
		intent.putExtra("EXTRA_SEARCH_KEYWORDS", searchInput.getText()
				.toString());
		startActivity(intent);
	}

	View.OnClickListener BtnSearchClicked = new View.OnClickListener() {
		public void onClick(View v) {
			goSearch();
		}
	};
	View.OnClickListener searchSubmitClicked = new View.OnClickListener() {
		public void onClick(View v) {
			goSearch();
		}
	};

	// Comment
	View.OnClickListener BtnCommentClicked = new View.OnClickListener() {
		public void onClick(View v) {
			startActivity(new Intent(v.getContext(),
					com.hkfhy.guide.Comment.class));
		}
	};

	// Instruction
	View.OnClickListener BtnInstrctionClicked = new View.OnClickListener() {
		public void onClick(View v) {
			startActivity(new Intent(v.getContext(),
					com.hkfhy.guide.Instrction.class));
		}
	};

	// Footer logos
	View.OnClickListener footerLogo1Clicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent browse = new Intent(Intent.ACTION_VIEW,
					Uri.parse(HKFHY_WEBSITE));
			startActivity(browse);
		}
	};
	View.OnClickListener footerLogo2Clicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent browse = new Intent(Intent.ACTION_VIEW,
					Uri.parse(OGCIO_WEBSITE));
			startActivity(browse);
		}
	};
}
