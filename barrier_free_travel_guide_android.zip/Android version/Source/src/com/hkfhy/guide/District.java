package com.hkfhy.guide;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import com.devsmart.android.ui.HorizontalListView;
import com.hkfhy.adapter.DistrictSpinAdapter;
import com.hkfhy.adapter.SpotAdapter;
import com.hkfhy.adapter.SpotTypeSpinAdapter;
import com.hkfhy.adapter.ThumbnailListAdapter;
import com.hkfhy.data.Spot;
import com.hkfhy.data.SpotType;
import com.hkfhy.data.Thumbnail;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.DistrictDataSource;
import com.hkfhy.datasource.SpotDataSource;
import com.hkfhy.datasource.SpotTypeDataSource;
import com.hkfhy.datasource.ThumbnailDataSource;

public class District extends MyActivity {

	private int selectedCategory = 0;
	private final int THUMBNAIL_LIST_SCROLL_AMOUNT = 150;
	private final int SCROLL_AMOUNT = 150;
	List<Button> categoryButtons = new ArrayList<Button>();

	private String districtsInSelectedCategory = "";

	Spinner districtSpinner;
	Spinner spotTypeSpinner;
	ListView spotListView;

	ImageButton spotListPrev;
	ImageButton spotListNext;
	ImageButton thumbnailListPrev;
	ImageButton thumbnailListNext;

	HorizontalListView thumbnailListView;
	RelativeLayout spotListContainer;
	List<Thumbnail> thumbnails;
	// LinearLayout thumbnailListLayout;

	private DataSource dataSource;
	private DistrictDataSource districtDataSource;
	private ThumbnailDataSource thumbnailDataSource;
	private SpotDataSource spotDataSource;
	private SpotTypeDataSource spotTypeDataSource;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.district);

		context = this;
		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		setUpPage(context);

		homeButton = (ImageButton) findViewById(R.id.home_btn);
		homeButton.setOnClickListener(homeButtonClicked);

		categoryButtons.add((Button) findViewById(R.id.category1));
		categoryButtons.add((Button) findViewById(R.id.category2));
		categoryButtons.add((Button) findViewById(R.id.category3));
		categoryButtons.add((Button) findViewById(R.id.category4));

		districtSpinner = (Spinner) findViewById(R.id.input_district);
		spotTypeSpinner = (Spinner) findViewById(R.id.input_spot_type);
		districtSpinner.setOnItemSelectedListener(onItemSelected);
		spotTypeSpinner.setOnItemSelectedListener(onItemSelected);
		spotListView = (ListView) findViewById(R.id.spot_list);

		// List arrows
		spotListPrev = (ImageButton) findViewById(R.id.spot_list_prev);
		spotListNext = (ImageButton) findViewById(R.id.spot_list_next);
		thumbnailListPrev = (ImageButton) findViewById(R.id.thumbnail_list_prev);
		thumbnailListNext = (ImageButton) findViewById(R.id.thumbnail_list_next);
		thumbnailListPrev.setOnTouchListener(thumbnailListPrevClicked);
		thumbnailListNext.setOnTouchListener(thumbnailListNextClicked);
		spotListPrev.setOnTouchListener(spotListPrevClicked);
		spotListNext.setOnTouchListener(spotListNextClicked);
		spotListContainer = (RelativeLayout) findViewById(R.id.spot_list_container);

		thumbnailListView = (HorizontalListView) findViewById(R.id.thumbnail_list);
		thumbnailListView.setOnItemClickListener(thumbnailListItemClicked);

		spotListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View view,
					int position, long id) {

				Spot selectedSpot = (Spot) spotListView.getAdapter().getItem(
						position);

				if (null == selectedSpot) {
					Log.d("guide", "Selecting spot in district �S�r�d");
				} else {
					// Go spot detail page
					Intent intent = new Intent(getBaseContext(),
							SpotDetail.class);
					intent.putExtra("EXTRA_SELECTED_SPOT",
							selectedSpot.getRecord_id());
					startActivity(intent);
				}
			}
		});

		// Get selected category if enter from home grids
		Bundle extras = getIntent().getExtras();
		int selectedDistrictIndex = selectedCategory;
		if (extras != null) {
			selectedDistrictIndex = extras
					.getInt("EXTRA_HOME_SELECTED_DISTRICT");
		}

		Button selectButton = categoryButtons.get(selectedDistrictIndex);
		if (null != selectButton) {
			selectButton.setSelected(true);
			selectedCategory = selectedDistrictIndex;
		}
		categoryButtons.get(selectedCategory).setSelected(true);

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		districtDataSource = new DistrictDataSource(context);
		thumbnailDataSource = new ThumbnailDataSource(context);
		spotDataSource = new SpotDataSource(context);
		spotTypeDataSource = new SpotTypeDataSource(context);

		// Set the main district names
		List<com.hkfhy.data.District> mainDistricts = districtDataSource
				.getByParentId(0, LANGUAGE_ID);
		updateDistrictsInSelectedCategory();

		if (null != mainDistricts) {
			int index = 0;
			for (com.hkfhy.data.District mainDistrict : mainDistricts) {
				Button categoryButton = categoryButtons.get(index++);

				if (!mainDistrict.getShort_title().isEmpty()) {
					categoryButton.setText(mainDistrict.getShort_title());
				} else {
					categoryButton.setText(mainDistrict.getTitle());
				}

				categoryButton.setOnClickListener(categoryButtonClicked);
			}
		}

		// Set the spinners
		refreshDistrictSpinner();
		refreshSpotTypeSpinner();
		updateSpotList();

		// Set thumbnails
		thumbnails = thumbnailDataSource.getByMainDistrictId(
				selectedCategory + 1, 10, LANGUAGE_ID);
		File fileWithinMyDir = getApplicationContext().getFilesDir();
		if (null != thumbnails) {
			ThumbnailListAdapter thumbnailListAdapter = new ThumbnailListAdapter(
					context, R.id.thumbnail_list, thumbnails, fileWithinMyDir);
			thumbnailListView.setAdapter(thumbnailListAdapter);

		}
		// thumbnailListView.add

		dataSource.close();
	}

	// Update spot list
	@SuppressWarnings("unchecked")
	private void updateSpotList() {
		// Update search result
		com.hkfhy.data.District selectedDistrict = (com.hkfhy.data.District) districtSpinner
				.getAdapter()
				.getItem(districtSpinner.getSelectedItemPosition());

		SpotType selectedSpot = (SpotType) spotTypeSpinner.getAdapter()
				.getItem(spotTypeSpinner.getSelectedItemPosition());

		int parentId = selectedDistrict.getRecord_id();
		int spotTypeId = selectedSpot.getRecord_id();

		List<Spot> spots;
		if (parentId == -1) {
			spots = spotDataSource.getByMainDistrictIdAndSpotTypeId(
					districtsInSelectedCategory, spotTypeId, LANGUAGE_ID);
		} else {
			spots = spotDataSource.getByDistrictIdAndSpotTypeId(parentId,
					spotTypeId, LANGUAGE_ID);
		}
		if (!spots.isEmpty()) {
			spotListContainer.setVisibility(View.VISIBLE);

			@SuppressWarnings("rawtypes")
			SpotAdapter<Spot> spotAdapter = new SpotAdapter(context,
					R.id.spot_result_item, spots);
			spotListView.setAdapter(spotAdapter);
		} else {
			spotListContainer.setVisibility(View.GONE);
		}
	}

	@SuppressWarnings("unchecked")
	private void refreshDistrictSpinner() {
		List<com.hkfhy.data.District> districts = districtDataSource
				.getByParentId(selectedCategory + 1, LANGUAGE_ID);
		com.hkfhy.data.District allDistrictOption = new com.hkfhy.data.District();
		allDistrictOption.setId(-1);
		allDistrictOption.setRecord_id(-1);
		allDistrictOption.setParent_id(-1);
		allDistrictOption.setTitle(getResources().getString(R.string.location));
		districts.add(0, allDistrictOption);

		@SuppressWarnings("rawtypes")
		DistrictSpinAdapter<District> districtSpinAdapter = new DistrictSpinAdapter(
				context, R.id.spinner_view, districts);
		districtSpinAdapter.setDropDownViewResource(R.layout.spinner_view);
		districtSpinner.setAdapter(districtSpinAdapter);

		// updateSpotList();
	}

	@SuppressWarnings("unchecked")
	private void refreshSpotTypeSpinner() {
		List<SpotType> spotTypes = spotTypeDataSource.getAllByLang(LANGUAGE_ID);
		com.hkfhy.data.SpotType allSpotTypeOption = new com.hkfhy.data.SpotType();
		allSpotTypeOption.setId(-1);
		allSpotTypeOption.setRecord_id(-1);
		allSpotTypeOption.setTitle(getResources().getString(
				R.string.attraction_type));
		spotTypes.add(0, allSpotTypeOption);

		@SuppressWarnings("rawtypes")
		SpotTypeSpinAdapter<SpotType> spotTypeSpinAdapter = new SpotTypeSpinAdapter(
				context, R.id.spinner_view, spotTypes);
		spotTypeSpinAdapter.setDropDownViewResource(R.layout.spinner_view);
		spotTypeSpinner.setAdapter(spotTypeSpinAdapter);

	}

	Spinner.OnItemSelectedListener onItemSelected = new Spinner.OnItemSelectedListener() {
		@Override
		public void onItemSelected(AdapterView<?> parentView,
				View selectedItemView, int position, long id) {
			updateSpotList();
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			updateSpotList();
		}
	};

	// Change category
	View.OnClickListener categoryButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			// Find selected category
			for (int index = 0; index <= 3; index++) {
				Button categoryButton = categoryButtons.get(index);
				if (categoryButton.getId() == v.getId()) {
					categoryButtons.get(selectedCategory).setSelected(false);
					selectedCategory = index;
					categoryButton.setSelected(true);
					updateDistrictsInSelectedCategory();
					continue;
				}
			}
			refreshDistrictSpinner();

			thumbnails = thumbnailDataSource.getByMainDistrictId(
					selectedCategory + 1, 10, LANGUAGE_ID);
			File fileWithinMyDir = getApplicationContext().getFilesDir();
			if (null != thumbnails) {
				ThumbnailListAdapter thumbnailListAdapter = new ThumbnailListAdapter(
						context, R.id.thumbnail_list, thumbnails,
						fileWithinMyDir);
				thumbnailListView.setAdapter(thumbnailListAdapter);

			}
		}
	};

	public void updateDistrictsInSelectedCategory() {
		List<com.hkfhy.data.District> districts = districtDataSource
				.getByParentId(selectedCategory + 1, LANGUAGE_ID);
		boolean isFirstRun = true;
		districtsInSelectedCategory = "";
		if (!districts.isEmpty()) {
			for (com.hkfhy.data.District district : districts) {
				if (!isFirstRun) {
					districtsInSelectedCategory += ", ";
				}
				districtsInSelectedCategory += district.getRecord_id();
				isFirstRun = false;
			}
		}
	}

	// Thumbnail arrow clicked
	View.OnTouchListener thumbnailListPrevClicked = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent arg1) {
			int scrollX = thumbnailListView.getmCurrentX();
			thumbnailListView.scrollTo(scrollX - THUMBNAIL_LIST_SCROLL_AMOUNT);
			return false;
		}
	};
	View.OnTouchListener thumbnailListNextClicked = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent arg1) {
			int scrollX = thumbnailListView.getmCurrentX();
			thumbnailListView.scrollTo(scrollX + THUMBNAIL_LIST_SCROLL_AMOUNT);
			return false;
		}
	};

	HorizontalListView.OnItemClickListener thumbnailListItemClicked = new HorizontalListView.OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			Thumbnail thumb = thumbnails.get(position);
			if (null != thumb) {
				int spotRecordId = thumb.getParent_id();
				boolean isExistedId = spotDataSource.isExistedId(spotRecordId);

				if (!isExistedId) {
					Log.d("guide", "Selecting spot in district �S�r�d");
				} else {
					// Go spot detail page
					Intent intent = new Intent(getBaseContext(),
							SpotDetail.class);
					intent.putExtra("EXTRA_SELECTED_SPOT", spotRecordId);
					startActivity(intent);
				}
			}
		}
	};

	// Content arrow clicked
	View.OnTouchListener spotListPrevClicked = new View.OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent arg1) {
			spotListView.smoothScrollBy(-SCROLL_AMOUNT, 200);
			return false;
		}
	};
	View.OnTouchListener spotListNextClicked = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent arg1) {
			spotListView.smoothScrollBy(SCROLL_AMOUNT, 200);
			return false;
		}
	};

}
