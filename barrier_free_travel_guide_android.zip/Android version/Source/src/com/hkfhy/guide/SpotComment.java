package com.hkfhy.guide;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.hkfhy.asynctask.SpotCommentRequestTask;
import com.hkfhy.data.Spot;
import com.hkfhy.datasource.DataSource;
import com.hkfhy.datasource.SpotDataSource;

public class SpotComment extends MyActivity {

	private static final String POST_DATA_URL = DOMAIN
			+ "submit_spot_comment.php";

	private DataSource dataSource;
	private SpotDataSource spotDataSource;

	private Spot spot;

	TextView headerTextView;

	Button submitButton;
	Button cancelButton;

	EditText inputName;
	EditText inputTel;
	EditText inputEmail;
	EditText inputContent;
	Button inputFile;

	ImageView inputFilePreview;

	private Uri fileUri = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setUpTheme(this);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.spot_comment);

		context = this;
		changeLanguageButton = (ImageButton) findViewById(R.id.change_language);
		changeLanguageButton.setOnClickListener(changeLanguageClicked);
		changeTextSizeButton = (ImageButton) findViewById(R.id.change_text_size_btn);
		changeTextSizeButton.setOnClickListener(changeTextSizeClicked);

		setUpPage(context);

		homeButton = (ImageButton) findViewById(R.id.home_btn);
		homeButton.setOnClickListener(homeButtonClicked);

		headerTextView = (TextView) findViewById(R.id.spot_comment_header_text);

		submitButton = (Button) findViewById(R.id.submit_button);
		submitButton.setOnClickListener(submitButtonClicked);

		cancelButton = (Button) findViewById(R.id.cancel_button);
		cancelButton.setOnClickListener(cancelButtonClicked);

		inputFile = (Button) findViewById(R.id.input_file);
		inputFile.setOnClickListener(inputFileClicked);

		inputName = (EditText) findViewById(R.id.input_name);
		inputTel = (EditText) findViewById(R.id.input_tel);
		inputEmail = (EditText) findViewById(R.id.input_email);
		inputContent = (EditText) findViewById(R.id.input_content);

		inputFilePreview = (ImageView) findViewById(R.id.input_file_preview);

		// Open database
		dataSource = new DataSource(context);
		dataSource.open();

		spotDataSource = new SpotDataSource(context);

		// Get spot record id
		Bundle extras = getIntent().getExtras();
		int spotRecordId = 0;
		if (extras != null) {
			spotRecordId = extras.getInt("EXTRA_SELECTED_SPOT");
		}
		spot = spotDataSource.getById(spotRecordId, LANGUAGE_ID);

		// Set header
		String headerPrefix = getResources().getString(
				R.string.spot_comment_header_prefix);
		String headerSubfix = getResources().getString(
				R.string.spot_comment_header_subfix);
		int highlightColor = getResources().getColor(R.color.highlight_color);
		int startPos = headerPrefix.length();
		int endPos = startPos + spot.getTitle().length();

		SpannableString spannableString = new SpannableString(headerPrefix
				+ spot.getTitle() + headerSubfix);
		spannableString.setSpan(new ForegroundColorSpan(highlightColor),
				startPos, endPos, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		headerTextView.setText(spannableString);

		dataSource.close();
	}

	View.OnClickListener submitButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {

			if (inputName.getText().toString().isEmpty()
					&& inputContent.getText().toString().isEmpty()) {

				Toast.makeText(context, R.string.spot_form_required,
						Toast.LENGTH_LONG).show();
			} else {
				submitButton.setEnabled(false);
				Toast.makeText(context, R.string.form_sent, Toast.LENGTH_LONG)
						.show();

				Log.d("guide", "Post data to: " + POST_DATA_URL);

				MultipartEntity multipartEntity = new MultipartEntity(
						HttpMultipartMode.BROWSER_COMPATIBLE);
				Charset chars = Charset.forName("UTF-8");

				try {
					multipartEntity.addPart("id",
							new StringBody(spot.getRecord_id() + ""));
					multipartEntity.addPart("name", new StringBody(inputName
							.getText().toString(), chars));
					multipartEntity.addPart("tel", new StringBody(inputTel
							.getText().toString()));
					multipartEntity.addPart("email", new StringBody(inputEmail
							.getText().toString()));
					multipartEntity.addPart("content", new StringBody(
							inputContent.getText().toString(), chars));

					if (null != fileUri) {
						File imageFile;

						imageFile = new File(fileUri.getPath());
						if (!imageFile.exists()) {
							String realPath = getRealPathFromURI(fileUri);
							if (null != realPath) {
								imageFile = new File(realPath);
							} else {
								Log.d("guide", "no this file: " + realPath);
							}
						}

						if (imageFile.exists()) {
							multipartEntity.addPart("attachment[1]",
									new FileBody(imageFile));
						} else {
							Log.d("guide", "no this file");
						}
					}

				} catch (UnsupportedEncodingException e) {
					Log.e("guide",
							"UnsupportedEncodingException: " + e.getMessage());
				}

				new SpotCommentRequestTask(multipartEntity)
						.execute(POST_DATA_URL);

				// Reset form
				submitButton.setEnabled(true);
				resetForm();
			}

		}
	};

	public String getRealPathFromURI(Uri contentUri) {
		String[] proj = { MediaStore.Images.Media.DATA };
		Cursor cursor = context.getContentResolver().query(contentUri, proj,
				null, null, null);
		int column_index = cursor
				.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
		cursor.moveToFirst();
		return cursor.getString(column_index);
	}

	private void resetForm() {
		inputName.setText("");
		inputTel.setText("");
		inputEmail.setText("");
		inputContent.setText("");
		fileUri = null;
		inputFilePreview.setImageURI(null);
	}

	// Reset form
	View.OnClickListener cancelButtonClicked = new View.OnClickListener() {
		public void onClick(View v) {
			// resetForm();
			Intent intent = new Intent(getBaseContext(), Home.class);
			startActivity(intent);
		}
	};

	// Choose file
	View.OnClickListener inputFileClicked = new View.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(Intent.ACTION_PICK);
			intent.setType("image/*");
			Intent destIntent = Intent.createChooser(intent, getResources()
					.getString(R.string.choose_file));
			startActivityForResult(destIntent, 0);
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			Uri uri = data.getData();
			fileUri = uri;
			if (uri != null) {
				inputFilePreview.setImageURI(uri);

				setTitle(uri.toString());
			} else {
				setTitle("Invalid path");
			}
		} else {
			setTitle("Cancelled");
		}
	}

}
