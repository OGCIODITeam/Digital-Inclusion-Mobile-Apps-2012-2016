package com.hkfhy.datasource;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class SQLiteHelper extends SQLiteOpenHelper {
	protected static SQLiteDatabase db = null;

	private static final String DATABASE_NAME = "guide.db";
	private static final int DATABASE_VERSION = 3;

	// version table
	private static final String CREATE_TABLE_VERSION = ""
			+ "CREATE TABLE IF NOT EXISTS version" + "("
			+ "	id				int PRIMARY KEY," + "	name			varchar(200),"
			+ "	value			varchar(200)" + ")";

	// spot table
	private static final String CREATE_TABLE_SPOT = ""
			+ "CREATE TABLE IF NOT EXISTS spot" + "("
			+ "	id				int PRIMARY KEY," + "	record_id		int KEY,"
			+ "	district_id		int KEY," + "	type_id			int KEY,"
			+ "	title			varchar(200)," + "	content			text,"
			+ "	transport		text," + "	info			text," + "	rate			double,"
			+ "	total_rated		int," + "	map_lat			double,"
			+ "	map_lng			double," + "	center_lat		double,"
			+ "	center_lng		double," + "	zoom			int," + "	baidu_map_x		double,"
			+ "	baidu_map_y		double," + "	baidu_center_x		double,"
			+ "	baidu_center_y		double," + "	create_time		timestamp,"
			+ "	update_time		timestamp," + "	seq				int," + "	lang			int,"
			+ "	thumbnail_path	varchar(200),"
			+ "	thumbnail_alt_text	varchar(200)" + ")";

	// district table
	private static final String CREATE_TABLE_DISTRICT = ""
			+ "CREATE TABLE IF NOT EXISTS district" + "("
			+ "	id				int PRIMARY KEY," + "	record_id		int KEY,"
			+ "	parent_id		int KEY," + "	title			varchar(200),"
			+ "	short_title			varchar(32)," + "	create_time		timestamp,"
			+ "	update_time		timestamp," + "	seq				int," + "	lang			int" + ")";

	// location table
	private static final String CREATE_TABLE_LOCATION = ""
			+ "CREATE TABLE IF NOT EXISTS location" + "("
			+ "	id				int PRIMARY KEY," + "	record_id		int KEY,"
			+ "	type_id			int KEY," + "	title			varchar(200),"
			+ "	open_time		varchar(200)," + "	content			varchar(200),"
			+ "	map_lat			double," + "	map_lng			double,"
			+ "	baidu_map_x		double," + "	baidu_map_y		double,"
			+ "	create_time		timestamp," + "	update_time		timestamp,"
			+ "	seq				int," + "	lang			int" + ")";

	// spot type table
	private static final String CREATE_TABLE_SPOT_TYPE = ""
			+ "CREATE TABLE IF NOT EXISTS spot_type" + "("
			+ "	id				int PRIMARY KEY," + "	record_id		int KEY,"
			+ "	parent_id		int KEY," + "	title			varchar(200),"
			+ "	create_time		timestamp," + "	update_time		timestamp,"
			+ "	seq				int," + "	lang			int" + ")";

	// location type table
	private static final String CREATE_TABLE_LOCATION_TYPE = ""
			+ "CREATE TABLE IF NOT EXISTS location_type" + "("
			+ "	id				int PRIMARY KEY," + "	record_id		int KEY,"
			+ "	title			varchar(200)," + "	create_time		timestamp,"
			+ "	update_time		timestamp," + "	seq				int," + "	lang			int" + ")";

	// thumbnail type table
	private static final String CREATE_TABLE_THUMBNAIL = ""
			+ "CREATE TABLE IF NOT EXISTS thumbnail" + "("
			+ "	id				INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
			+ "	parent_id		int KEY," + "	path			varchar(512),"
			+ "	path_small		varchar(512)," + "	alt_text		varchar(512),"
			+ "	seq				int," + "	lang			int" + ")";

	// page table
	private static final String CREATE_TABLE_PAGE = ""
			+ "CREATE TABLE IF NOT EXISTS page" + "("
			+ "	id				int PRIMARY KEY," + "	record_id		int KEY,"
			+ "	parent_id		int KEY," + "	title			varchar(200),"
			+ "	content			varchar(200)," + "	create_time		timestamp,"
			+ "	update_time		timestamp," + "	seq				int," + "	lang			int" + ")";

	public SQLiteHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		if (db == null) {
			try {
				db = this.getWritableDatabase();
			} finally {
				if (db != null) {
					db = this.getReadableDatabase();
				}
			}
		}
	}

	public SQLiteHelper(Context context, int dataVersion) {
		super(context, DATABASE_NAME, null, dataVersion);
		db = this.getWritableDatabase();
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		Log.d("database", "ready create");

		db.execSQL(CREATE_TABLE_VERSION);
		db.execSQL(CREATE_TABLE_SPOT);
		db.execSQL(CREATE_TABLE_DISTRICT);
		db.execSQL(CREATE_TABLE_LOCATION);
		db.execSQL(CREATE_TABLE_SPOT_TYPE);
		db.execSQL(CREATE_TABLE_LOCATION_TYPE);
		db.execSQL(CREATE_TABLE_THUMBNAIL);
		db.execSQL(CREATE_TABLE_PAGE);

		Log.d("database", "table created");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.d("database", "ready upgrade");

		// Log for drop table
		Log.w(SQLiteHelper.class.getName(), "Upgrading database from version "
				+ oldVersion + " to " + newVersion
				+ ", which will destroy all old data");
		// Drop tables
		db.execSQL("DROP TABLE IF EXISTS spot");
		db.execSQL("DROP TABLE IF EXISTS spot_type");
		db.execSQL("DROP TABLE IF EXISTS location");
		db.execSQL("DROP TABLE IF EXISTS location_type");
		db.execSQL("DROP TABLE IF EXISTS district");
		db.execSQL("DROP TABLE IF EXISTS version");
		db.execSQL("DROP TABLE IF EXISTS thumbnail");
		db.execSQL("DROP TABLE IF EXISTS page");
		// db.execSQL("DROP TABLE IF EXISTS setting");
		// Recreate tables
		onCreate(db);

		Log.d("database", "table upgraded");
	}

	public SQLiteDatabase getDb() {
		return db;
	}

	// Do nothing
	public void close() {
		// if (db != null) {
		// db.close();
		// }
	}

}