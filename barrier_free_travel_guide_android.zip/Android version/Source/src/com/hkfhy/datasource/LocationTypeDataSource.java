package com.hkfhy.datasource;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.hkfhy.data.LocationType;

public class LocationTypeDataSource extends DataSource {

	// Database fields
	private static final String TABLE_NAME = "location_type";

	private String[] allColumns = { "id", "record_id", "title", "create_time",
			"update_time", "seq", "lang" };

	public LocationTypeDataSource(Context context) {
		super(context);
	}

	public LocationTypeDataSource(Context context, int dataVersion) {
		super(context, dataVersion);
	}

	public long update(LocationType record) {
		ContentValues values = new ContentValues();

		values.put("id", record.getId());
		values.put("record_id", record.getRecord_id());
		values.put("title", record.getTitle());
		values.put("create_time", record.getCreate_time());
		values.put("update_time", record.getUpdate_time());
		values.put("seq", record.getSeq());
		values.put("lang", record.getLang());

		long queryId = 0;
		if (isExistedRecord(record)) {
			String whereClause = "id = " + record.getId();
			String[] whereArgs = null;
			queryId = database.update(TABLE_NAME, values, whereClause,
					whereArgs);
		} else {
			String nullColumnHack = null;
			queryId = database.insert(TABLE_NAME, nullColumnHack, values);
		}

		return queryId;
	}

	public void delete(LocationType record) {
		long id = record.getId();
		System.out.println("locationType deleted with id: " + id);
		database.delete(TABLE_NAME, "id = " + id, null);
	}

	public Boolean isExistedRecord(LocationType record) {
		Boolean isExist = true;
		long id = record.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = { "id" };
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			isExist = false;
		}
		cursor.close();

		return isExist;
	}

	public LocationType getById(LocationType record) {
		long id = record.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		LocationType newRecord = cursorToRecord(cursor);
		cursor.close();
		return newRecord;
	}

	public List<LocationType> getAll() {
		List<LocationType> records = new ArrayList<LocationType>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			LocationType record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	private LocationType cursorToRecord(Cursor cursor) {
		LocationType record = new LocationType();

		record.setId(cursor.getInt(cursor.getColumnIndex("id")));
		record.setRecord_id(cursor.getInt(cursor.getColumnIndex("record_id")));
		record.setTitle(cursor.getString(cursor.getColumnIndex("title")));
		record.setCreate_time(cursor.getString(cursor
				.getColumnIndex("create_time")));
		record.setUpdate_time(cursor.getString(cursor
				.getColumnIndex("update_time")));
		record.setSeq(cursor.getInt(cursor.getColumnIndex("seq")));
		record.setLang(cursor.getInt(cursor.getColumnIndex("lang")));

		return record;
	}
}