package com.hkfhy.datasource;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.hkfhy.data.Version;

public class VersionDataSource extends DataSource {

	// Database fields
	private static final String TABLE_NAME = "version";

	private String[] allColumns = { "id", "name", "value" };

	public VersionDataSource(Context context) {
		super(context);
	}
	
	public VersionDataSource(Context context, int dataVersion) {
		super(context, dataVersion);
	}

	public int getCurrentDataVersion() {
		int currentDataVersion = 0;

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "name = 'data_version'";
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			currentDataVersion = 0;
		} else {
			currentDataVersion = Integer.valueOf(cursor.getString(cursor
					.getColumnIndex("value")));
		}
		cursor.close();

		return currentDataVersion;
	}

	public void update(Version version) {
		String nullColumnHack = null;

		database.execSQL("DELETE FROM " + TABLE_NAME);
		database.execSQL("VACUUM");

		ContentValues values = new ContentValues();

		values.put("name", "update_time");
		values.put("value", version.getUpdate_time());
		database.insert(TABLE_NAME, nullColumnHack, values);
		values.clear();

		values.put("name", "data_version");
		values.put("value", version.getData_version());
		database.insert(TABLE_NAME, nullColumnHack, values);
		values.clear();

		values.put("name", "db_version");
		values.put("value", version.getDb_version());
		database.insert(TABLE_NAME, nullColumnHack, values);
		values.clear();
	}

	// private Version cursorToRecord(Cursor cursor) {
	// Version record = new Version();
	//
	// record.setData_version(cursor.getInt(cursor.getColumnIndex("value")));
	// record.setDb_version(cursor.getInt(cursor.getColumnIndex("value")));
	// record.setUpdate_time(cursor.getString(cursor.getColumnIndex("value")));
	//
	// return record;
	// }
}
