package com.hkfhy.datasource;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.hkfhy.data.Location;

public class LocationDataSource extends DataSource {

	// Database fields
	private static final String TABLE_NAME = "location";

	private String[] allColumns = { "id", "record_id", "type_id", "title",
			"open_time", "content", "map_lat", "map_lng", "baidu_map_x",
			"baidu_map_y", "create_time", "update_time", "seq", "lang" };

	public LocationDataSource(Context context) {
		super(context);
	}

	public LocationDataSource(Context context, int dataVersion) {
		super(context, dataVersion);
	}

	public long update(Location location) {
		ContentValues values = new ContentValues();

		values.put("id", location.getId());
		values.put("record_id", location.getRecord_id());
		values.put("type_id", location.getType_id());
		values.put("title", location.getTitle());
		values.put("open_time", location.getOpen_time());
		values.put("content", location.getContent());

		values.put("map_lat", location.getMap_lat());
		values.put("map_lng", location.getMap_lng());

		values.put("baidu_map_x", location.getBaidu_map_x());
		values.put("baidu_map_y", location.getBaidu_map_y());

		values.put("create_time", location.getCreate_time());
		values.put("update_time", location.getUpdate_time());
		values.put("seq", location.getSeq());
		values.put("lang", location.getLang());

		long queryId = 0;
		if (isExistedRecord(location)) {
			String whereClause = "id = " + location.getId();
			String[] whereArgs = null;
			queryId = database.update(TABLE_NAME, values, whereClause,
					whereArgs);
		} else {
			String nullColumnHack = null;
			queryId = database.insert(TABLE_NAME, nullColumnHack, values);
		}

		return queryId;
	}

	public void delete(Location location) {
		long id = location.getId();
		System.out.println("Location deleted with id: " + id);
		database.delete(TABLE_NAME, "id = " + id, null);
	}

	public Boolean isExistedRecord(Location location) {
		Boolean isExist = true;
		long id = location.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = { "id" };
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			isExist = false;
		}
		cursor.close();

		return isExist;
	}

	public Location getById(Location location) {
		long id = location.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		Location record = cursorToRecord(cursor);
		cursor.close();
		return record;
	}

	public List<Location> getAll() {
		List<Location> records = new ArrayList<Location>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Location record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public int getTotal() {
		int total = 0;
		List<Location> records = new ArrayList<Location>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Location record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		total = records.size();
		return total;
	}

	public List<Location> getAllByLang(int lang) {
		List<Location> records = new ArrayList<Location>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		// String orderBy = "seq DESC";
		String orderBy = "type_id ASC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Location record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	private Location cursorToRecord(Cursor cursor) {
		Location record = new Location();

		record.setId(cursor.getInt(cursor.getColumnIndex("id")));
		record.setRecord_id(cursor.getInt(cursor.getColumnIndex("record_id")));
		record.setType_id(cursor.getInt(cursor.getColumnIndex("type_id")));
		record.setTitle(cursor.getString(cursor.getColumnIndex("title")));
		record.setOpen_time(cursor.getString(cursor.getColumnIndex("open_time")));
		record.setContent(cursor.getString(cursor.getColumnIndex("content")));

		record.setMap_lat(cursor.getFloat(cursor.getColumnIndex("map_lat")));
		record.setMap_lng(cursor.getFloat(cursor.getColumnIndex("map_lng")));

		record.setBaidu_map_x(cursor.getFloat(cursor
				.getColumnIndex("baidu_map_x")));
		record.setBaidu_map_y(cursor.getFloat(cursor
				.getColumnIndex("baidu_map_y")));

		record.setCreate_time(cursor.getString(cursor
				.getColumnIndex("create_time")));
		record.setUpdate_time(cursor.getString(cursor
				.getColumnIndex("update_time")));
		record.setSeq(cursor.getInt(cursor.getColumnIndex("seq")));
		record.setLang(cursor.getInt(cursor.getColumnIndex("lang")));

		return record;
	}
}