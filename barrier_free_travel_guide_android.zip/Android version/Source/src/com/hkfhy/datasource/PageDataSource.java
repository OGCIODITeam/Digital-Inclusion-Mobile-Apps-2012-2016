package com.hkfhy.datasource;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.hkfhy.data.Page;

public class PageDataSource extends DataSource {

	// Database fields
	private static final String TABLE_NAME = "page";

	private String[] allColumns = { "id", "record_id", "parent_id", "title",
			"content", "create_time", "update_time", "seq", "lang" };

	public PageDataSource(Context context) {
		super(context);
	}

	public PageDataSource(Context context, int dataVersion) {
		super(context, dataVersion);
	}

	public long update(Page page) {
		ContentValues values = new ContentValues();

		values.put("id", page.getId());
		values.put("record_id", page.getRecord_id());
		values.put("parent_id", page.getParent_id());
		values.put("title", page.getTitle());
		values.put("content", page.getContent());

		values.put("create_time", page.getCreate_time());
		values.put("update_time", page.getUpdate_time());
		values.put("seq", page.getSeq());
		values.put("lang", page.getLang());

		long queryId = 0;
		if (isExistedRecord(page)) {
			String whereClause = "id = " + page.getId();
			String[] whereArgs = null;
			queryId = database.update(TABLE_NAME, values, whereClause,
					whereArgs);
		} else {
			String nullColumnHack = null;
			queryId = database.insert(TABLE_NAME, nullColumnHack, values);
		}

		return queryId;
	}

	public void delete(Page page) {
		long id = page.getId();
		System.out.println("page deleted with id: " + id);
		database.delete(TABLE_NAME, "id = " + id, null);
	}

	public Boolean isExistedRecord(Page page) {
		Boolean isExist = true;
		long id = page.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = { "id" };
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			isExist = false;
		}
		cursor.close();

		return isExist;
	}

	public Page getById(Page page) {
		long id = page.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		Page record = cursorToRecord(cursor);
		cursor.close();
		return record;
	}

	public Page getById(int id, int lang) {

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "record_id = " + id + " AND lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		Page record = cursorToRecord(cursor);
		cursor.close();
		return record;
	}

	public List<Page> getAll() {
		List<Page> records = new ArrayList<Page>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Page record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Page> getAllByLang(int lang) {
		List<Page> records = new ArrayList<Page>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Page record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	private Page cursorToRecord(Cursor cursor) {
		Page record = new Page();

		record.setId(cursor.getInt(cursor.getColumnIndex("id")));
		record.setRecord_id(cursor.getInt(cursor.getColumnIndex("record_id")));
		record.setParent_id(cursor.getInt(cursor.getColumnIndex("parent_id")));
		record.setTitle(cursor.getString(cursor.getColumnIndex("title")));
		record.setContent(cursor.getString(cursor.getColumnIndex("content")));

		record.setCreate_time(cursor.getString(cursor
				.getColumnIndex("create_time")));
		record.setUpdate_time(cursor.getString(cursor
				.getColumnIndex("update_time")));
		record.setSeq(cursor.getInt(cursor.getColumnIndex("seq")));
		record.setLang(cursor.getInt(cursor.getColumnIndex("lang")));

		return record;
	}
}