package com.hkfhy.datasource;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.hkfhy.data.District;
import com.hkfhy.data.Spot;

public class SpotDataSource extends DataSource {

	// Database fields
	private static final String TABLE_NAME = "spot";
	private Context context;

	private String[] allColumns = { "id", "record_id", "district_id",
			"type_id", "title", "content", "transport", "info", "rate",
			"total_rated", "map_lat", "map_lng", "center_lat", "center_lng",
			"zoom", "baidu_map_x", "baidu_map_y", "baidu_center_x",
			"baidu_center_y", "create_time", "update_time", "seq", "lang",
			"thumbnail_path", "thumbnail_alt_text" };

	public SpotDataSource(Context context) {
		super(context);
		this.context = context;
	}

	public SpotDataSource(Context context, int dataVersion) {
		super(context, dataVersion);
	}

	public long update(Spot spot) {
		ContentValues values = new ContentValues();

		values.put("id", spot.getId());
		values.put("record_id", spot.getRecord_id());
		values.put("district_id", spot.getDistrict_id());
		values.put("type_id", spot.getType_id());
		values.put("title", spot.getTitle());
		values.put("content", spot.getContent());
		values.put("transport", spot.getTransport());
		values.put("info", spot.getInfo());
		values.put("rate", spot.getRate());
		values.put("total_rated", spot.getTotal_rated());
		values.put("map_lat", spot.getMap_lat());
		values.put("map_lng", spot.getMap_lng());
		values.put("center_lat", spot.getCenter_lat());
		values.put("center_lng", spot.getCenter_lng());
		values.put("zoom", spot.getZoom());

		values.put("baidu_map_x", spot.getBaidu_map_x());
		values.put("baidu_map_y", spot.getBaidu_map_y());
		values.put("baidu_center_x", spot.getBaidu_center_x());
		values.put("baidu_center_y", spot.getBaidu_center_y());

		values.put("create_time", spot.getCreate_time());
		values.put("update_time", spot.getUpdate_time());
		values.put("seq", spot.getSeq());
		values.put("lang", spot.getLang());
		// values.put("thumbnail_path", spot.getThumbnail_path());
		// values.put("thumbnail_alt_text" spot.getThumbnail_alt_text());

		long queryId = 0;
		if (isExistedRecord(spot)) {
			String whereClause = "id = " + spot.getId();
			String[] whereArgs = null;
			queryId = database.update(TABLE_NAME, values, whereClause,
					whereArgs);
		} else {
			String nullColumnHack = null;
			queryId = database.insert(TABLE_NAME, nullColumnHack, values);
		}

		return queryId;
	}

	public void delete(Spot spot) {
		long id = spot.getId();
		System.out.println("Spot deleted with id: " + id);
		database.delete(TABLE_NAME, "id = " + id, null);
	}

	public Boolean isExistedRecord(Spot spot) {
		Boolean isExist = true;
		long id = spot.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = { "id" };
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			isExist = false;
		}
		cursor.close();

		return isExist;
	}

	public Boolean isExistedId(int id) {
		Boolean isExist = true;

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = { "id" };
		String selection = "record_id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			isExist = false;
		}
		cursor.close();

		return isExist;
	}

	public Spot getById(Spot spot) {
		long id = spot.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		Spot record = cursorToRecord(cursor);
		cursor.close();
		return record;
	}

	public Spot getById(int spotRecordId, int lang) {

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "record_id = " + spotRecordId + " AND lang = "
				+ lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		Spot record = cursorToRecord(cursor);
		cursor.close();
		return record;
	}

	public List<Spot> getAll() {
		List<Spot> records = new ArrayList<Spot>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Spot record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Spot> getAllByLang(int lang) {
		List<Spot> records = new ArrayList<Spot>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Spot record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Spot> getByDistrictId(int districtId, int lang) {
		List<Spot> records = new ArrayList<Spot>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "district_id = " + districtId + " AND lang=" + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Spot record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Spot> getAllByKeywords(List<String> keywords, int lang) {
		List<Spot> records = new ArrayList<Spot>();

		// Search district first
		DistrictDataSource districtDataSource;
		districtDataSource = new DistrictDataSource(context);
		List<District> districts = districtDataSource.getAllByKeywords(
				keywords, lang);

		// Generate district list SQL
		String districtListSql = "";
		if (!districts.isEmpty()) {
			boolean firstRun = true;
			for (District district : districts) {
				if (!firstRun) {
					districtListSql += ", ";
				}
				districtListSql += district.getRecord_id();
				firstRun = false;
			}
			districtListSql = " OR district_id IN (" + districtListSql + ")";
		}

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		selection += " AND (";
		boolean firstKeyword = true;
		for (String keyword : keywords) {
			if (!firstKeyword) {
				selection += " OR ";
			}
			selection += "title LIKE '%" + keyword + "%'"
					+ " OR content LIKE '%" + keyword + "%'"
					+ " OR transport LIKE '%" + keyword + "%'"
					+ " OR info LIKE '%" + keyword + "%'";
			firstKeyword = false;
		}
		selection += districtListSql;
		selection += ")";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Spot record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Spot> getByDistrictIdAndSpotTypeId(int districtId,
			int spotTypeId, int lang) {
		List<Spot> records = new ArrayList<Spot>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		selection = "lang = " + lang;
		if (districtId >= 0 && spotTypeId >= 0) {
			selection += " AND district_id = " + districtId + " AND type_id = "
					+ spotTypeId;
		} else if (districtId >= 0) {
			selection += " AND district_id = " + districtId;
		} else if (spotTypeId >= 0) {
			selection += " AND type_id = " + spotTypeId;
		}

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Spot record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Spot> getByMainDistrictIdAndSpotTypeId(
			String districtsInSelectedCategory, int spotTypeId, int lang) {
		List<Spot> records = new ArrayList<Spot>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		selection = "lang = " + lang;
		if (!districtsInSelectedCategory.isEmpty() && spotTypeId >= 0) {
			selection += " AND district_id IN (" + districtsInSelectedCategory
					+ ") AND type_id = " + spotTypeId;
		} else if (!districtsInSelectedCategory.isEmpty()) {
			selection += " AND district_id IN (" + districtsInSelectedCategory
					+ ")";
		} else if (spotTypeId >= 0) {
			selection += " AND type_id = " + spotTypeId;
		}

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Spot record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	private Spot cursorToRecord(Cursor cursor) {
		Spot record = new Spot();

		if (null != cursor) {
			record.setId(cursor.getInt(cursor.getColumnIndex("id")));
			record.setRecord_id(cursor.getInt(cursor
					.getColumnIndex("record_id")));
			record.setDistrict_id(cursor.getInt(cursor
					.getColumnIndex("district_id")));
			record.setType_id(cursor.getInt(cursor.getColumnIndex("type_id")));
			record.setTitle(cursor.getString(cursor.getColumnIndex("title")));
			record.setContent(cursor.getString(cursor.getColumnIndex("content")));
			record.setTransport(cursor.getString(cursor
					.getColumnIndex("transport")));
			record.setInfo(cursor.getString(cursor.getColumnIndex("info")));
			record.setRate(cursor.getFloat(cursor.getColumnIndex("rate")));
			record.setTotal_rated(cursor.getInt(cursor
					.getColumnIndex("total_rated")));
			record.setMap_lat(cursor.getFloat(cursor.getColumnIndex("map_lat")));
			record.setMap_lng(cursor.getFloat(cursor.getColumnIndex("map_lng")));
			record.setCenter_lat(cursor.getFloat(cursor
					.getColumnIndex("center_lat")));
			record.setCenter_lng(cursor.getFloat(cursor
					.getColumnIndex("center_lng")));
			record.setZoom(cursor.getInt(cursor.getColumnIndex("zoom")));

			record.setBaidu_map_x(cursor.getFloat(cursor
					.getColumnIndex("baidu_map_x")));
			record.setBaidu_map_y(cursor.getFloat(cursor
					.getColumnIndex("baidu_map_y")));
			record.setBaidu_center_x(cursor.getFloat(cursor
					.getColumnIndex("baidu_center_x")));
			record.setBaidu_center_y(cursor.getFloat(cursor
					.getColumnIndex("baidu_center_y")));

			record.setCreate_time(cursor.getString(cursor
					.getColumnIndex("create_time")));
			record.setUpdate_time(cursor.getString(cursor
					.getColumnIndex("update_time")));
			record.setSeq(cursor.getInt(cursor.getColumnIndex("seq")));
			record.setLang(cursor.getInt(cursor.getColumnIndex("lang")));
			// thumbnail_path
			// thumbnail_alt_text
			// Photo photos;
		}

		return record;
	}
}