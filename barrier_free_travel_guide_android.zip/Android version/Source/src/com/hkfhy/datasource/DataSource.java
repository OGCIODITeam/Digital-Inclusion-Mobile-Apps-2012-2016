package com.hkfhy.datasource;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DataSource {

	protected static SQLiteDatabase database;
	protected static SQLiteHelper dbHelper;
	protected int dataVersion;

	public DataSource(Context context) {
		dbHelper = new SQLiteHelper(context);
	}

	public DataSource(Context context, int dataVersion) {
		this.dataVersion = dataVersion;
		dbHelper = new SQLiteHelper(context, dataVersion);
	}

	public void cleanUpAllData() {
		SQLiteDatabase db = dbHelper.getDb();
		db.execSQL("DELETE from spot");
		db.execSQL("DELETE from spot_type");
		db.execSQL("DELETE from location");
		db.execSQL("DELETE from location_type");
		db.execSQL("DELETE from district");
		db.execSQL("DELETE from thumbnail");
		// db.execSQL("DELETE from version");
	}

	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}

	public void close() {
		dbHelper.close();
	}
}
