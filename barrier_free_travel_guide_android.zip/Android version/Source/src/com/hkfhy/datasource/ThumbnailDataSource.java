package com.hkfhy.datasource;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.hkfhy.data.District;
import com.hkfhy.data.Spot;
import com.hkfhy.data.Thumbnail;

public class ThumbnailDataSource extends DataSource {

	// Database fields
	private static final String TABLE_NAME = "thumbnail";
	private Context context;

	private String[] allColumns = { "id", "path", "path_small", "alt_text",
			"parent_id", "seq", "lang" };

	public ThumbnailDataSource(Context context) {
		super(context);
		this.context = context;
	}

	public ThumbnailDataSource(Context context, int dataVersion) {
		super(context, dataVersion);
		this.context = context;
	}

	public long update(Thumbnail record) {
		ContentValues values = new ContentValues();

		if (record.getId() != 0) {
			values.put("id", record.getId());
		}
		values.put("path", record.getPath());
		values.put("path_small", record.getPath_small());
		values.put("alt_text", record.getAlt_text());
		values.put("parent_id", record.getParent_id());
		values.put("seq", record.getSeq());
		values.put("lang", record.getLang());

		long queryId = 0;
		if (isExistedRecord(record)) {
			String whereClause = "path = '" + record.getPath()
					+ "' AND parent_id = " + record.getParent_id()
					+ " AND lang = " + record.getLang();
			String[] whereArgs = null;
			queryId = database.update(TABLE_NAME, values, whereClause,
					whereArgs);
		} else {
			String nullColumnHack = null;
			queryId = database.insert(TABLE_NAME, nullColumnHack, values);
		}

		return queryId;
	}

	public void delete(Thumbnail record) {
		long id = record.getId();
		System.out.println("Thumbnail deleted with id: " + id);
		database.delete(TABLE_NAME, "id = " + id, null);
	}

	public Boolean isExistedRecord(Thumbnail record) {
		Boolean isExist = true;
		String path = record.getPath();
		int parent_id = record.getParent_id();
		int lang = record.getLang();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = { "id" };
		String selection = "path = '" + path + "' AND parent_id = " + parent_id
				+ " AND lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = null;
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();

		if (!(cursor.moveToFirst()) || cursor.getCount() == 0) {
			isExist = false;
		}
		cursor.close();

		return isExist;
	}

	public Thumbnail getById(Thumbnail record) {
		long id = record.getId();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "id = " + id;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = "0,1";

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);
		cursor.moveToFirst();
		Thumbnail newRecord = cursorToRecord(cursor);
		cursor.close();
		return newRecord;
	}

	public List<Thumbnail> getAll() {
		List<Thumbnail> records = new ArrayList<Thumbnail>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = null;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Thumbnail record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Thumbnail> getByParentId(int parentId, int lang) {
		List<Thumbnail> records = new ArrayList<Thumbnail>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "parent_id = " + parentId + " AND lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = null;
		String having = null;
		String orderBy = "seq DESC";
		String limit = null;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Thumbnail record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Thumbnail> getOneEachFromAll(int maxLimit, int lang) {
		List<Thumbnail> records = new ArrayList<Thumbnail>();

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = "parent_id";
		String having = null;
		String orderBy = "RANDOM()";
		String limit = "0," + maxLimit;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Thumbnail record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	public List<Thumbnail> getByMainDistrictId(int mainDistrictId,
			int maxLimit, int lang) {
		List<Thumbnail> records = new ArrayList<Thumbnail>();

		// Search district first
		DistrictDataSource districtDataSource = new DistrictDataSource(context);
		SpotDataSource spotDataSource = new SpotDataSource(context);
		List<District> districts = districtDataSource.getByParentId(
				mainDistrictId, lang);

		// Generate district list SQL
		String parentListSql = "";
		if (!districts.isEmpty()) {
			boolean firstRun = true;
			for (District district : districts) {
				List<Spot> spots = spotDataSource.getByDistrictId(
						district.getRecord_id(), lang);

				if (!spots.isEmpty()) {
					for (Spot spot : spots) {
						if (!firstRun) {
							parentListSql += ", ";
						}
						parentListSql += spot.getRecord_id();
						firstRun = false;
					}
				}
			}
			
			parentListSql = " AND parent_id IN (" + parentListSql + ")";
		}

		// Query parameters
		String table = TABLE_NAME;
		String[] columns = allColumns;
		String selection = "lang = " + lang;
		String[] selectionArgs = null;
		String groupBy = "parent_id";
		String having = null;
		String orderBy = "RANDOM()";
		String limit = "0," + maxLimit;

		selection += parentListSql;

		// Execute query
		Cursor cursor = database.query(table, columns, selection,
				selectionArgs, groupBy, having, orderBy, limit);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Thumbnail record = cursorToRecord(cursor);
			records.add(record);
			cursor.moveToNext();
		}

		cursor.close();
		return records;
	}

	private Thumbnail cursorToRecord(Cursor cursor) {
		Thumbnail record = new Thumbnail();

		record.setId(cursor.getInt(cursor.getColumnIndex("id")));
		record.setPath(cursor.getString(cursor.getColumnIndex("path")));
		record.setPath_small(cursor.getString(cursor
				.getColumnIndex("path_small")));
		record.setAlt_text(cursor.getString(cursor.getColumnIndex("alt_text")));
		record.setParent_id(cursor.getInt(cursor.getColumnIndex("parent_id")));
		record.setSeq(cursor.getInt(cursor.getColumnIndex("seq")));
		record.setLang(cursor.getInt(cursor.getColumnIndex("lang")));

		return record;
	}
}