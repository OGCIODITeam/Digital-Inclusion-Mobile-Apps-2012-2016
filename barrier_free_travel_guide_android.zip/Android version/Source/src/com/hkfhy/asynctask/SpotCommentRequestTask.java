package com.hkfhy.asynctask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpParams;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hkfhy.server.ServerResponse;

public class SpotCommentRequestTask extends AsyncTask<String, String, String> {

	private MultipartEntity multipartEntity;
	private DefaultHttpClient httpclient;

	public SpotCommentRequestTask(MultipartEntity multipartEntity) {
		super();
		this.multipartEntity = multipartEntity;
	}

	@Override
	protected String doInBackground(String... uri) {

		HttpParams params = new BasicHttpParams();
		params.setParameter(CoreProtocolPNames.PROTOCOL_VERSION,
				HttpVersion.HTTP_1_1);
		httpclient = new DefaultHttpClient(params);

		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(uri[0]);
		try {
			httppost.setEntity(multipartEntity);

		} catch (Exception e) {
			Log.e("guide", e.getMessage(), e);
		}

		// Execute HTTP Post Request
		HttpResponse response = null;
		try {
			response = httpclient.execute(httppost);
		} catch (ClientProtocolException e) {
			Log.e("guide", "ClientProtocolException: " + e.getMessage());
		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		// ServerResponse serverResponse =
		// httpResponseToServerResponse(response);
		//
		// String responseString = "";
		// if (serverResponse.getSuccess()) {
		// responseString = "success";
		// } else {
		// responseString = "error";
		// }
		String responseString = "success";
		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		// Do anything with response..
	}

	public ServerResponse httpResponseToServerResponse(HttpResponse response) {
		ServerResponse serverResponse = null;
		try {
			InputStream inputStream = response.getEntity().getContent();
			InputStreamReader inputStreamReader = new InputStreamReader(
					inputStream);
			BufferedReader bufferedReader = new BufferedReader(
					inputStreamReader);
			StringBuilder stringBuilder = new StringBuilder();
			String bufferedStrChunk = null;

			while ((bufferedStrChunk = bufferedReader.readLine()) != null) {
				stringBuilder.append(bufferedStrChunk);
			}
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			JsonObject json = parser.parse(stringBuilder.toString())
					.getAsJsonObject();

			serverResponse = gson.fromJson(json, ServerResponse.class);

		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		return serverResponse;
	}
}