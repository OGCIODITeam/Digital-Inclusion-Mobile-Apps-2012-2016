package com.hkfhy.asynctask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hkfhy.guide.R;
import com.hkfhy.server.RatingResponse;
import com.hkfhy.server.ServerResponse;

public class SpotRatingTask extends AsyncTask<String, Integer, String> {

	private final String GET_RATE_JSON_FILE = "get_rate.json";

	private List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
	private Context context;
	private int recordId;
	private String DOMAIN;
	private RatingBar ratingBar;
	private TextView totalRatedTextView;

	RatingResponse ratingResponse;

	public SpotRatingTask(List<NameValuePair> nameValuePairs) {
		super();
		this.nameValuePairs = nameValuePairs;
	}

	public SpotRatingTask(List<NameValuePair> nameValuePairs, Context context,
			int recordId, String DOMAIN, RatingBar ratingBar,
			TextView totalRatedTextView) {
		super();
		this.nameValuePairs = nameValuePairs;
		this.context = context;
		this.recordId = recordId;
		this.DOMAIN = DOMAIN;
		this.ratingBar = ratingBar;
		this.totalRatedTextView = totalRatedTextView;
	}

	@Override
	protected String doInBackground(String... uri) {
		Log.d("guide", "doInBackground:�@spot rating");

		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(uri[0]);
		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			Log.e("guide", "UnsupportedEncodingException: " + e.getMessage());
		}

		// Execute HTTP Post Request
		HttpResponse response = null;
		try {
			response = httpclient.execute(httppost);
		} catch (ClientProtocolException e) {
			Log.e("guide", "ClientProtocolException: " + e.getMessage());
		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		ServerResponse serverResponse = httpResponseToServerResponse(response);

		String responseString = "";
		if (serverResponse.getSuccess()) {
			responseString = "success";

			// Create a new HTTP Client
			DefaultHttpClient defaultClient = new DefaultHttpClient();
			HttpGet httpGetRequest;
			HttpResponse httpResponse;
			BufferedReader reader;

			// Request version JSON
			httpGetRequest = new HttpGet(DOMAIN + GET_RATE_JSON_FILE + "?id="
					+ recordId);
			try {
				httpResponse = defaultClient.execute(httpGetRequest);
				reader = new BufferedReader(new InputStreamReader(httpResponse
						.getEntity().getContent(), "UTF-8"));
				String responseJSON = reader.readLine();

				// Convert JSON
				Gson gson = new Gson();
				JsonParser parser = new JsonParser();

				// Convert version JSON to object
				JsonObject responseJsonObj = parser.parse(responseJSON)
						.getAsJsonObject();
				ratingResponse = gson.fromJson(responseJsonObj,
						RatingResponse.class);
				publishProgress(100);
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			responseString = "error";
		}
		return responseString;
	}

	protected void onProgressUpdate(Integer... values) {
		float rate = ratingResponse.getRate();
		int totalRated = ratingResponse.getTotal_rated();

		ratingBar.setRating(rate);
		totalRatedTextView.setText(context.getResources().getString(
				R.string.no_barrier_rate_prefix)
				+ totalRated
				+ context.getResources().getString(
						R.string.no_barrier_rate_subfix));

		Toast.makeText(context,
				context.getResources().getString(R.string.rating_sent),
				Toast.LENGTH_SHORT).show();

	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		// Do anything with response..
	}

	public ServerResponse httpResponseToServerResponse(HttpResponse response) {
		ServerResponse serverResponse = null;
		try {
			InputStream inputStream = response.getEntity().getContent();
			InputStreamReader inputStreamReader = new InputStreamReader(
					inputStream);
			BufferedReader bufferedReader = new BufferedReader(
					inputStreamReader);
			StringBuilder stringBuilder = new StringBuilder();
			String bufferedStrChunk = null;

			while ((bufferedStrChunk = bufferedReader.readLine()) != null) {
				stringBuilder.append(bufferedStrChunk);
			}
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			JsonObject json = parser.parse(stringBuilder.toString())
					.getAsJsonObject();

			serverResponse = gson.fromJson(json, ServerResponse.class);

		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		return serverResponse;
	}
}
