package com.hkfhy.asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.text.Html;
import android.util.Log;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.hkfhy.data.Location;
import com.hkfhy.guide.Map;
import com.hkfhy.guide.MyActivity;
import com.hkfhy.guide.R;

public class AddMarkerTask extends AsyncTask<String, Integer, String> {

	Map activity;
	Context context;
	Location location;
	GoogleMap mMap;
	Marker marker;

	protected static final int TOILET_ID = 31;
	protected static final int ACCESSIBLE_TOILET_ID = 32;
	protected static final int CAR_PARK_ID = 33;
	protected static final int DISABLED_PARKING_ID = 34;
	protected static final int BUS_STOP_ID = 35;
	protected static final int SCENIC_SPOT_ID = 36;

	protected static final String DOMAIN = "http://app.e-cgo.org.hk/";

	public AddMarkerTask(MyActivity myActivity, Context context,
			Location location, GoogleMap mMap) {
		super();
		this.context = context;
		this.location = location;
		this.mMap = mMap;
	}

	@Override
	protected String doInBackground(String... params) {
		double lat = location.getMap_lat();
		double lng = location.getMap_lng();
		String title = location.getTitle();
		String snippet = location.getOpen_time()
				+ convertHtml(location.getContent());
		int iconResourceId = getIconResourceId(location.getType_id());

		marker = mMap.addMarker(new MarkerOptions()
				.position(new LatLng(lat, lng)).title(title).snippet(snippet)
				.icon(BitmapDescriptorFactory.fromResource(iconResourceId)));
		return null;
	}

	@Override
	protected void onPostExecute(String result) {
		Log.d("guide", "exe: " + location.getTitle());
		activity.updateAdapter(marker, location);
	}

	// Resource ID
	private int getIconResourceId(int typeId) {
		int iconResourceId = R.drawable.ic_launcher;
		switch (typeId) {
		case TOILET_ID:
			iconResourceId = R.drawable.map_icon_toilet;
			break;
		case ACCESSIBLE_TOILET_ID:
			iconResourceId = R.drawable.map_icon_accessible_toilet;
			break;
		case CAR_PARK_ID:
			iconResourceId = R.drawable.map_icon_carpark;
			break;
		case DISABLED_PARKING_ID:
			iconResourceId = R.drawable.map_icon_disabled_parking;
			break;
		case BUS_STOP_ID:
			iconResourceId = R.drawable.map_icon_bus_stop;
			break;
		case SCENIC_SPOT_ID:
			iconResourceId = R.drawable.map_icon_scenic_spot;
			break;
		}

		return iconResourceId;
	}

	public String convertHtml(String html) {
		html = Html.fromHtml(html).toString();
		html = Html.fromHtml(html).toString();
		html = replaceHtmlImageLink(html);
		return html;
	}

	public String removeHtmlTags(String html) {
		// Removes all items in brackets
		html = html.replaceAll("<(.*?)\\>", " ");
		// Must be undeneath
		html = html.replaceAll("<(.*?)\\\n", " ");
		// Removes any connected item to the last bracket
		html = html.replaceFirst("(.*?)\\>", " ");
		html = html.replaceAll("&nbsp;", " ");
		html = html.replaceAll("&amp;", " ");
		return html;
	}

	public String replaceHtmlImageLink(String html) {
		/*
		 * <img src="upload/ to <img src="DOMAIN/upload/
		 */
		html = html.replaceAll("<img src=\"upload/", "<img src=\"" + DOMAIN
				+ "upload/");
		return html;
	}
}
