package com.hkfhy.asynctask;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.http.util.ByteArrayBuffer;

import android.os.AsyncTask;
import android.util.Log;

import com.hkfhy.data.Spot;
import com.hkfhy.data.Thumbnail;
import com.hkfhy.datasource.ThumbnailDataSource;

//AsyncTask<InputType, UpdateType, ResultType>
public class UpdateThumbnailFromSpotsTask extends
		AsyncTask<String, String, String> {

	private ThumbnailDataSource thumbnailDataSource;
	private List<Spot> spots;
	private String DOMAIN;
	private File fileWithinMyDir;

	public UpdateThumbnailFromSpotsTask(
			ThumbnailDataSource thumbnailDataSource, List<Spot> spots,
			String DOMAIN, File fileWithinMyDir) {
		super();
		this.thumbnailDataSource = thumbnailDataSource;
		this.spots = spots;
		this.DOMAIN = DOMAIN;
		this.fileWithinMyDir = fileWithinMyDir;
	}

	@Override
	protected String doInBackground(String... uri) {
		String responseString = "";

		Log.d("database", "running update");

		if (null != spots) {
			Log.d("database", "has spots");
			for (Spot spot : spots) {
				// Download thumbnails
				List<Thumbnail> thumbnailList = spot.getPhotos().getThumbnail();
				if (null != thumbnailList) {
					int seq = 0;
					for (Thumbnail thumb : thumbnailList) {
						// Get smaller photo by img.php
						URL url;
						try {
							url = new URL(DOMAIN + thumb.getPath_small());
							File file = new File(
									fileWithinMyDir.getAbsolutePath() + "/"
											+ thumb.getPath());

							if (file.exists() && file.isDirectory()) {
								file.delete();
								Log.d("database",
										"Thumb (" + spot.getRecord_id()
												+ ") delete dir");
							}

							if (false == file.exists()) {
								File dir = new File(file.getParentFile()
										.getAbsolutePath());
								if (false == dir.exists()) {
									dir.mkdirs();
								}

								URLConnection ucon = url.openConnection();
								InputStream is = ucon.getInputStream();
								BufferedInputStream bis = new BufferedInputStream(
										is);
								ByteArrayBuffer baf = new ByteArrayBuffer(50);
								int current = 0;
								while ((current = bis.read()) != -1) {
									baf.append((byte) current);
								}

								FileOutputStream fos = new FileOutputStream(
										file);
								fos.write(baf.toByteArray());
								fos.close();

								Log.d("database",
										"Thumb (" + spot.getRecord_id()
												+ ") downloaded: "
												+ thumb.getPath());

							} else {
								Log.d("database",
										"Thumb (" + spot.getRecord_id()
												+ ") exists: "
												+ thumb.getPath());
							}
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						// Update to database
						thumb.setLang(spot.getLang());
						thumb.setParent_id(spot.getRecord_id());
						// thumb.setSeq(++seq);
						thumbnailDataSource.update(thumb);

					}
				}
			}
		}
		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		Log.d("guide", "Do anything with response..");
	}

	public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
		throw new RejectedExecutionException("Task " + r.toString()
				+ " rejected from " + e.toString());
	}
}
