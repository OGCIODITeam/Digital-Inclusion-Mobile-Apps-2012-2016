package com.hkfhy.asynctask;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import com.hkfhy.data.Location;
import com.hkfhy.datasource.LocationDataSource;

public class UpdateLocationTask extends AsyncTask<String, String, String> {

	private LocationDataSource locationDataSource;
	private Location record;
	private SharedPreferences prefs;

	public UpdateLocationTask(LocationDataSource locationDataSource,
			Location record) {
		super();
		this.locationDataSource = locationDataSource;
		this.record = record;
	}

	public UpdateLocationTask(LocationDataSource locationDataSource,
			Location record, SharedPreferences prefs) {
		super();
		this.locationDataSource = locationDataSource;
		this.record = record;
		this.prefs = prefs;
	}

	@Override
	protected String doInBackground(String... uri) {
		String responseString = "";
		// Log.d("database", "do in background Location (" + record.getId()
		// + "): " + record.getTitle());
		locationDataSource.update(record);

		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		int updated_location = prefs.getInt("updated_location", 0);
		updated_location++;
		prefs.edit().putInt("updated_location", updated_location).commit();
	}
}
