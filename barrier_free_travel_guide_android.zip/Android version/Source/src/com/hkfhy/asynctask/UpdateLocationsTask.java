package com.hkfhy.asynctask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hkfhy.data.Data;
import com.hkfhy.data.Location;
import com.hkfhy.datasource.LocationDataSource;

public class UpdateLocationsTask extends AsyncTask<String, String, String> {

	private LocationDataSource locationDataSource;
	private SharedPreferences prefs;
	private String url;
	private String lang;

	public UpdateLocationsTask(LocationDataSource locationDataSource,
			SharedPreferences prefs, String url, String lang) {
		super();
		this.locationDataSource = locationDataSource;
		this.prefs = prefs;
		this.url = url;
		this.lang = lang;
	}

	@Override
	protected String doInBackground(String... uri) {
		String responseString = "";
		// Log.d("database", "do in background Location (" + record.getId()
		// + "): " + record.getTitle());

		try {
			int start = 1;

			Log.d("guide", "location data requesting");

			// Create a new HTTP Client
			DefaultHttpClient defaultClient = new DefaultHttpClient();
			HttpGet httpGetRequest;
			HttpResponse httpResponse;
			BufferedReader reader;

			boolean noMoreData = false;

			do {
				// Request version JSON
				String dataUrl = url + "?locale=" + lang + "&start=" + start;

				Log.d("guide", "dataUrl: " + dataUrl);
				httpGetRequest = new HttpGet(dataUrl);
				String locationJSON = "";
				httpResponse = defaultClient.execute(httpGetRequest);
				reader = new BufferedReader(new InputStreamReader(httpResponse
						.getEntity().getContent(), "UTF-8"));
				locationJSON = reader.readLine();

				if (null != locationJSON) {
					// Convert JSON
					Gson gson = new Gson();
					JsonParser parser = new JsonParser();

					// Convert version JSON to object
					JsonObject dataJsonObj = parser.parse(locationJSON)
							.getAsJsonObject();

					locationJSON = null;

					// Convert data JSON to object
					JsonObject jsonObj = dataJsonObj.get(lang)
							.getAsJsonObject();

					Log.d("guide", "location data ready: " + start);

					Data data = gson.fromJson(jsonObj, Data.class);

					List<Location> locations = (List<Location>) data
							.getLocation();

					if (null != locations) {
						Log.d("guide", "Update total " + locations.size()
								+ " locations in background");
						for (Location record : locations) {
							locationDataSource.update(record);

							int updated_location = prefs.getInt(
									"updated_location", 0);
							updated_location++;
							prefs.edit()
									.putInt("updated_location",
											updated_location).commit();

							// Log.d("database", "Location (" +
							// record.getId() + "): "
							// + record.getTitle());
						}
						start += 1;
					} else {
						noMoreData = true;
						Log.d("guide", "nullpo location data");
					}
				} else {
					noMoreData = true;
					Log.d("guide", "empty location json");
				}

			} while (!noMoreData);

		} catch (ClientProtocolException e) {
			Log.e("guide", "ClientProtocolException: " + e.getMessage());
		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
	}
}
