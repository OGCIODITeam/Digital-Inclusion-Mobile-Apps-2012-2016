package com.hkfhy.asynctask;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

public class GetImagesInTextView extends AsyncTask<String, String, String> {

	private TextView textView;

	public GetImagesInTextView(TextView textView) {
		super();
		this.textView = textView;
	}

	@Override
	protected String doInBackground(String... arg0) {
		try {
			/* Open a new URL and get the InputStream to load data from it. */
			URL aURL = new URL("ur Image URL");
			URLConnection conn = aURL.openConnection();
			conn.connect();
			InputStream is = conn.getInputStream();
			/* Buffered is always good for a performance plus. */
			BufferedInputStream bis = new BufferedInputStream(is);
			/* Decode url-data to a bitmap. */
			Bitmap bm = BitmapFactory.decodeStream(bis);
			bis.close();
			is.close();

			@SuppressWarnings("deprecation")
			Drawable d = new BitmapDrawable(bm);
			// d.setId("1");
			// wherever u want the image relative to textview
			textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 1, 0);
		} catch (IOException e) {
			Log.e("error", "Remote Image Exception", e);
		}
		return null;
	}

}
