package com.hkfhy.asynctask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hkfhy.server.ServerResponse;

public class RequestTask extends AsyncTask<String, String, String> {

	private List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

	public RequestTask(List<NameValuePair> nameValuePairs) {
		super();
		this.nameValuePairs = nameValuePairs;
	}

	@Override
	protected String doInBackground(String... uri) {

		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(uri[0]);
		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			Log.e("guide", "UnsupportedEncodingException: " + e.getMessage());
		}

		// Execute HTTP Post Request
		HttpResponse response = null;
		try {
			response = httpclient.execute(httppost);
		} catch (ClientProtocolException e) {
			Log.e("guide", "ClientProtocolException: " + e.getMessage());
		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		ServerResponse serverResponse = httpResponseToServerResponse(response);

		String responseString = "";
		if (serverResponse.getSuccess()) {
			responseString = "success";
		} else {
			responseString = "error";
		}
		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		// Do anything with response..
	}

	public ServerResponse httpResponseToServerResponse(HttpResponse response) {
		ServerResponse serverResponse = null;
		try {
			InputStream inputStream = response.getEntity().getContent();
			InputStreamReader inputStreamReader = new InputStreamReader(
					inputStream);
			BufferedReader bufferedReader = new BufferedReader(
					inputStreamReader);
			StringBuilder stringBuilder = new StringBuilder();
			String bufferedStrChunk = null;

			while ((bufferedStrChunk = bufferedReader.readLine()) != null) {
				stringBuilder.append(bufferedStrChunk);
			}
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			JsonObject json = parser.parse(stringBuilder.toString())
					.getAsJsonObject();

			serverResponse = gson.fromJson(json, ServerResponse.class);

		} catch (IOException e) {
			Log.e("guide", "IOException: " + e.getMessage());
		}

		return serverResponse;
	}
}