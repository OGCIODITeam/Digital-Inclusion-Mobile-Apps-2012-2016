package com.hkfhy.asynctask;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.http.util.ByteArrayBuffer;

import android.os.AsyncTask;
import android.util.Log;

import com.hkfhy.data.Spot;
import com.hkfhy.data.Thumbnail;
import com.hkfhy.datasource.ThumbnailDataSource;

public class UpdateThumbnailTask extends AsyncTask<String, String, String> {

	private ThumbnailDataSource thumbnailDataSource;
	private Thumbnail thumb;
	private Spot spot;
	private File fileWithinMyDir;
	private String DOMAIN;

	public UpdateThumbnailTask(ThumbnailDataSource thumbnailDataSource,
			Thumbnail thumb, Spot spot, String DOMAIN, File fileWithinMyDir) {
		super();
		this.thumbnailDataSource = thumbnailDataSource;
		this.thumb = thumb;
		this.spot = spot;
		this.fileWithinMyDir = fileWithinMyDir;
		this.DOMAIN = DOMAIN;
	}

	@Override
	protected String doInBackground(String... uri) {
		String responseString = "";
		// Log.d("database", "do in background Thumb (" + thumb.getPath() +
		// ")");

		// StrictMode.ThreadPolicy policy = new
		// StrictMode.ThreadPolicy.Builder()
		// .permitAll().build();
		// StrictMode.setThreadPolicy(policy);

		// Get smaller photo by img.php
		URL url;
		try {
			url = new URL(DOMAIN + thumb.getPath_small());
			File file = new File(fileWithinMyDir.getAbsolutePath() + "/"
					+ thumb.getPath());

			if (file.exists() && file.isDirectory()) {
				file.delete();
				Log.d("database", "Thumb (" + spot.getRecord_id()
						+ ") delete dir");
			}

			if (false == file.exists()) {
				File dir = new File(file.getParentFile().getAbsolutePath());
				if (false == dir.exists()) {
					dir.mkdirs();
				}

				URLConnection ucon = url.openConnection();
				InputStream is = ucon.getInputStream();
				BufferedInputStream bis = new BufferedInputStream(is);
				ByteArrayBuffer baf = new ByteArrayBuffer(50);
				int current = 0;
				while ((current = bis.read()) != -1) {
					baf.append((byte) current);
				}

				FileOutputStream fos = new FileOutputStream(file);
				fos.write(baf.toByteArray());
				fos.close();

				Log.d("database", "Thumb (" + spot.getRecord_id()
						+ ") downloaded: " + thumb.getPath());

			} else {
				Log.d("database", "Thumb (" + spot.getRecord_id()
						+ ") exists: " + thumb.getPath());
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Update to database
		thumb.setLang(spot.getLang());
		thumb.setParent_id(spot.getRecord_id());
		// thumb.setSeq(++seq);
		thumbnailDataSource.update(thumb);

		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		// Do anything with response..
	}

    public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
        throw new RejectedExecutionException("Task " + r.toString() +
                                             " rejected from " +
                                             e.toString());
    }
}
