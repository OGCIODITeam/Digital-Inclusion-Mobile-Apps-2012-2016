package com.hkfhy.adapter;

import java.io.File;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.hkfhy.data.Thumbnail;
import com.hkfhy.guide.R;

public class ThumbnailListAdapter extends ArrayAdapter<Thumbnail> {
	private Context context;
	private List<Thumbnail> values;
	private File fileWithinMyDir;
	private int viewItemLayoutId;

	public ThumbnailListAdapter(Context context, int resourceId,
			List<Thumbnail> values) {
		super(context, resourceId, values);
		this.context = context;
		this.values = values;
		viewItemLayoutId = R.layout.viewitem;
	}

	public ThumbnailListAdapter(Context context, int resourceId,
			List<Thumbnail> values, File fileWithinMyDir) {
		super(context, resourceId, values);
		this.context = context;
		this.values = values;
		this.fileWithinMyDir = fileWithinMyDir;
		viewItemLayoutId = R.layout.viewitem;
	}

	public ThumbnailListAdapter(Context context, int resourceId,
			List<Thumbnail> values, File fileWithinMyDir, int viewItemLayoutId) {
		super(context, resourceId, values);
		this.context = context;
		this.values = values;
		this.fileWithinMyDir = fileWithinMyDir;
		this.viewItemLayoutId = viewItemLayoutId;
	}

	@Override
	public int getCount() {
		return values.size();
	}

	@Override
	public Thumbnail getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View retval = LayoutInflater.from(parent.getContext()).inflate(
				viewItemLayoutId, null);
		Thumbnail thumb = values.get(position);
		ImageView imageView = (ImageView) retval
				.findViewById(R.id.thumbnail_list_image);

		File file = new File(fileWithinMyDir.getAbsolutePath() + "/"
				+ thumb.getPath());

		if (file.exists() && file.isFile()) {
			Bitmap thumbBitmap = BitmapFactory.decodeFile(file
					.getAbsolutePath());

			imageView.setImageBitmap(thumbBitmap);
			// imageView.setAdjustViewBounds(true);
			imageView.setContentDescription(thumb.getAlt_text());
		}

		return imageView;
	}

}