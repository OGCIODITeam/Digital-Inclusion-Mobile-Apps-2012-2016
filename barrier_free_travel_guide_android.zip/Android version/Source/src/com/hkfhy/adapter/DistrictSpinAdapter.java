package com.hkfhy.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.hkfhy.data.District;
import com.hkfhy.guide.R;

@SuppressWarnings("hiding")
public class DistrictSpinAdapter<District> extends ArrayAdapter<District> {
	private Context context;
	private List<District> values;
	LayoutInflater inflator;

	public DistrictSpinAdapter(Context context, int textViewResourceId,
			List<District> values) {
		super(context, textViewResourceId, values);
		this.context = context;
		this.values = values;
		inflator = LayoutInflater.from(context);
	}

	public int getCount() {
		return values.size();
	}

	public District getItem(int position) {
		return values.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView label = new TextView(context);
		label.setTextColor(Color.parseColor("#3a3a3a"));
		List<District> districts = (List<District>) values;
		label.setText(((com.hkfhy.data.District) districts.get(position)).getTitle());

		return label;
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		convertView = inflator.inflate(R.layout.spinner_view, null);
		TextView label = (TextView) convertView.findViewById(R.id.spinner_view);
		label.setTextColor(Color.parseColor("#3a3a3a"));
		List<District> districts = (List<District>) values;
		label.setText(((com.hkfhy.data.District) districts.get(position))
				.getTitle());

		return convertView;
	}
}