package com.hkfhy.adapter;

import java.util.List;

import com.hkfhy.guide.R;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class SpotTypeSpinAdapter<spotType> extends ArrayAdapter<spotType> {
	private Context context;
	private List<spotType> values;
	LayoutInflater inflator;

	public SpotTypeSpinAdapter(Context context, int textViewResourceId,
			List<spotType> values) {
		super(context, textViewResourceId, values);
		this.context = context;
		this.values = values;
		inflator = LayoutInflater.from(context);
	}

	public int getCount() {
		return values.size();
	}

	public spotType getItem(int position) {
		return values.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView label = new TextView(context);
		label.setTextColor(Color.parseColor("#3a3a3a"));
		List<spotType> records = (List<spotType>) values;
		label.setText(((com.hkfhy.data.SpotType) records.get(position))
				.getTitle());

		return label;
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		convertView = inflator.inflate(R.layout.spinner_view, null);
		TextView label = (TextView) convertView.findViewById(R.id.spinner_view);
		label.setTextColor(Color.parseColor("#3a3a3a"));
		List<spotType> records = (List<spotType>) values;
		label.setText(((com.hkfhy.data.SpotType) records.get(position))
				.getTitle());

		return convertView;
	}
}