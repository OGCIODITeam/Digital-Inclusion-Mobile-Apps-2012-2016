package com.hkfhy.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hkfhy.adapter.SearchResultAdapter.ViewHolder;
import com.hkfhy.guide.R;

public class SpotAdapter<Spot> extends ArrayAdapter<Spot> {
	private Context context;
	private List<Spot> values;
	LayoutInflater inflator;

	public SpotAdapter(Context context, int textViewResourceId,
			List<Spot> values) {
		super(context, textViewResourceId, values);
		this.context = context;
		this.values = values;
		inflator = LayoutInflater.from(context);
	}

	public int getCount() {
		return values.size();
	}

	public Spot getItem(int position) {
		return values.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// Set ViewHolder at first see the item
		if (convertView == null) {

			// convertView = inflator.inflate(R.layout.search_result_item,
			// null);
			convertView = LayoutInflater.from(parent.getContext()).inflate(
					R.layout.spot_result_item, null);

			ViewHolder viewHolder = new ViewHolder();

			viewHolder.label = (TextView) convertView
					.findViewById(R.id.spot_result_item);

			convertView.setTag(viewHolder);
		}

		// Get the ViewHolder
		ViewHolder viewHolder = (ViewHolder) convertView.getTag();

		// convertView = inflator.inflate(R.layout.spot_result_item, null);
		viewHolder.label.setTextColor(Color.parseColor("#3a3a3a"));
		// label.setBackgroundColor(Color.parseColor("#e05b00"));
		List<Spot> records = (List<Spot>) values;
		viewHolder.label.setText(((com.hkfhy.data.Spot) records.get(position))
				.getTitle());

		convertView.setTag(viewHolder);

		return convertView;
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		convertView = inflator.inflate(R.layout.spot_result_item, null);
		TextView label = (TextView) convertView
				.findViewById(R.id.spot_result_item);
		label.setTextColor(Color.parseColor("#3a3a3a"));
		// label.setBackgroundColor(Color.parseColor("#e05b00"));
		List<Spot> records = (List<Spot>) values;
		label.setText(((com.hkfhy.data.Spot) records.get(position)).getTitle());

		return convertView;
	}

	static class ViewHolder {
		public TextView label;
	}
}