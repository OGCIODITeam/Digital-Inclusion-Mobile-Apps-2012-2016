package com.hkfhy.adapter;

public interface KeyValueItem {
	public long getOptionValue();
	public String getOptionLabel();
}