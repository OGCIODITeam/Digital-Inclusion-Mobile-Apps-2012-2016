package com.sahk.sahkp.form;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.androidquery.AQuery;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;

/**
 * Created by casum on 13-9-25.
 */
public class FormFragment extends _AbstractMainFragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        this.inflater = inflater;
        View v = inflater.inflate(R.layout.form, container, false);
        aq = new AQuery(v);

        return v;
    }

}

