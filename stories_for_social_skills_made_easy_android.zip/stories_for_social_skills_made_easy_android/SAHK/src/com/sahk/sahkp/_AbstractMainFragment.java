package com.sahk.sahkp;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import com.androidquery.AQuery;

import java.lang.ref.WeakReference;

/**
 * Created by linlinet on 13-9-22.
 */
public class _AbstractMainFragment extends Fragment implements View.OnClickListener {

    private final String TAG = "_AbstractMainFragment";

    public _AbstractMainFragment() {
    }

    protected FragmentActivity context;
    protected OnListListener mCallback;
    protected AQuery aq;
    protected LayoutInflater inflater;
    public static final int[] strids = new int[]{R.array.story1, R.array.story2, R.array.story3,
            R.array.story4, R.array.story5, R.array.story6, R.array.story7, R.array.story8, R.array.story9, R.array.story10, R.array.story11, R.array.story12, R.array.story13, R.array.story14, R.array.story15, R.array.story16, R.array.story17,
            R.array.story18, R.array.story19, R.array.story20, R.array.story21, R.array.story22, R.array.story23, R.array.story24, R.array.story25, R.array.story26, R.array.story27, R.array.story28, R.array.story29, R.array.story30, R.array.story31,
            R.array.story32, R.array.story33, R.array.story34, R.array.story35, R.array.story36, R.array.story37, R.array.story38, R.array.story39, R.array.story40, R.array.story41, R.array.story42, R.array.story43, R.array.story44, R.array.story45,
            R.array.story46, R.array.story47, R.array.story48, R.array.story49, R.array.story50, R.array.story51, R.array.story52, R.array.story53, R.array.story54, R.array.story55, R.array.story56, R.array.story57, R.array.story58, R.array.story59,
            R.array.story60, R.array.story61, R.array.story62, R.array.story63, R.array.story64, R.array.story65, R.array.story66, R.array.story67, R.array.story68, R.array.story69, R.array.story70, R.array.story71, R.array.story72, R.array.story73,
            R.array.story74, R.array.story75, R.array.story76, R.array.story77, R.array.story78, R.array.story79, R.array.story80, R.array.story81, R.array.story82, R.array.story83, R.array.story84, R.array.story85, R.array.story86, R.array.story87,
            R.array.story88, R.array.story89, R.array.story90, R.array.story91, R.array.story92, R.array.story93, R.array.story94, R.array.story95, R.array.story96, R.array.story97, R.array.story98, R.array.story99, R.array.story100
    };

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallback = (OnListListener) (context = (FragmentActivity) activity);
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement OnHeadlineSelectedListener");
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_menu:
                Log.i(TAG, "---------->btnMenu");
                mCallback.showSlidingMenu();
                break;
            case R.id.btnBack:
                Log.i(TAG, "---------->btnBack");
                mCallback.onBack();
                break;
        }
    }

    public void toBack() {

    }

    public void onBack() {

    }

    public void clear() {

    }

    public void set() {

    }

    protected Bitmap doInBack(int data) {
        return null;
    }

    // Container Activity must implement this interface
    public interface OnListListener {
        public void onLoading(String msg);

        public void finishLoading();

        public void switchContent(Fragment fragment);

        public void addContent(Fragment fragment);

        public void onBack();

        public void reloadActivity();

        public void showSlidingMenu();
    }
}
