package com.sahk.sahkp;

import android.app.Activity;
import android.bluetooth.BluetoothSocket;
import com.sahk.sahkp.data.CustomerStory;
import com.sahk.sahkp.data.CustomerStoryInfo;

import java.io.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExchangeThread extends Thread {
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;
    private final Activity context;
    private Integer mStoryId, pindex;
    private String preValue, content;
    private String imgPath, audioPath;
    private FileOutputStream bos;
    private Integer length;
    private Integer bookid;

    public ExchangeThread(Activity context, BluetoothSocket socket) {
        this.context = context;
        mmSocket = socket;
        InputStream tmpIn = null;
        OutputStream tmpOut = null;
        try {
            tmpIn = socket.getInputStream();
            tmpOut = socket.getOutputStream();
        } catch (IOException e) {
        }
        mmInStream = tmpIn;
        mmOutStream = tmpOut;
    }

    public void run() {
        byte[] buffer = new byte[1024];
        int bytes;
        while (true) {
            try {
                bytes = mmInStream.read(buffer);
                if (!"I".equals(preValue) && !"A".equals(preValue)) {
                    String data = new String(buffer, 0, bytes - 1);
                    setString(data);
                } else {
                    try {
                        bos.write(buffer, 0, bytes);
                        length -= bytes;
                        if (length <= 1) {
                            bos.close();
                            preValue = null;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                break;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void setString(String data) {
        try {
            if (data.startsWith("S")) {
                mStoryId = Integer.valueOf(data.substring(1));
                createCustomerStory(mStoryId);
                preValue = null;
            } else if (data.startsWith("C")) {
                content = data.substring(1);
                preValue = null;
            } else if (data.startsWith("P")) {
                preValue = null;
                pindex = Integer.valueOf(data.substring(1));
            } else if (data.startsWith("I")) {
                length = Integer.valueOf(data.substring(1));
                preValue = "I";
                File dir = new File(CommonUtility.photoFolderPath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".jpg";
                imgPath = CommonUtility.photoFolderPath + File.separator + timeStamp;
                bos = new FileOutputStream(imgPath);
            } else if (data.startsWith("A")) {
                length = Integer.valueOf(data.substring(1));
                preValue = "A";
                String name = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".amr";
                File dir = new File(CommonUtility.audioFolderPath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                audioPath = CommonUtility.audioFolderPath + File.separator + name;
                bos = new FileOutputStream(audioPath);
            } else if (data.startsWith("B")) {
                createCustomerStoryInfo();
            } else if (data.startsWith("D")) {
                context.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (context instanceof MainActivity) {
                            ((MainActivity) context).onLoading("");
                        }
                    }
                });
            } else if (data.startsWith("E")) {
                context.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (context instanceof MainActivity) {
                            ((MainActivity) context).finishLoading();
                        }
                    }
                });
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createCustomerStoryInfo() {
        CustomerStoryInfo customerStoryInfo = new CustomerStoryInfo();
        customerStoryInfo.bookindex = bookid;
        customerStoryInfo.audio = audioPath;
        customerStoryInfo.content = content;
        customerStoryInfo.pindex = pindex;
        customerStoryInfo.sindex = mStoryId;
        customerStoryInfo.image = imgPath;
        try {
            CustomerStoryInfo.saveData(context, CustomerStoryInfo.class, customerStoryInfo);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createCustomerStory(Integer mStoryId) {
        CustomerStory customerStory = new CustomerStory();
        customerStory.bookindex = mStoryId;
        try {
            CustomerStory.saveData(context, CustomerStory.class, customerStory);
            bookid = customerStory.id;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void write(final byte[] bytes) {
        try {
            mmOutStream.write(bytes);
        } catch (IOException e) {
        }
    }

    public void write(int data) {
        try {
            mmOutStream.write(data);
        } catch (IOException e) {
        }
    }

    public void writeString(String str) {
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(mmOutStream)), true);
        out.println(str);
    }

    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) {
        }
    }


    public interface FinishLinstener {
        public void onFinish();
    }
}
