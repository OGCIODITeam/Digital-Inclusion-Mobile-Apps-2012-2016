package com.sahk.sahkp.setting;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.CustomerStory;
import com.sahk.sahkp.data.CustomerStoryInfo;
import com.sahk.sahkp.data.Database;

import java.sql.SQLException;

/**
 * Created by Winkey on 19/8/13.
 */
public class SettingFragment extends _AbstractMainFragment implements CompoundButton.OnCheckedChangeListener {

    private ToggleButton btn_lang, btn_sound, btn_notice;
    private SharedPreferences settings;
    private SharedPreferences.Editor PE;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        View v = inflater.inflate(R.layout.setting, container, false);
        aq = new AQuery(v);
        init();

        // Inflate the layout for this fragment
        return v;
    }

    private void init() {
        settings = context.getSharedPreferences(CommonUtility.APP_NAME, context.MODE_PRIVATE);
        PE = settings.edit();

        btn_lang = (ToggleButton) aq.id(R.id.btn_lang).getView();
        btn_lang.setChecked(CommonUtility.LOCALLANG_CN.equals(CommonUtility.lang));
        if (CommonUtility.lang.equals(CommonUtility.LOCALLANG_CN)) {
            btn_lang.setContentDescription(getResources().getString(R.string.btn_big5gb2312_cn));
        } else {
            btn_lang.setContentDescription(getResources().getString(R.string.btn_big5gb2312_tw));
        }


        btn_lang.setOnCheckedChangeListener(this);
        btn_sound = (ToggleButton) aq.id(R.id.btn_sound).getView();
        btn_notice = (ToggleButton) aq.id(R.id.btn_notice).getView();
        if (settings.getString("sound", "") == CommonUtility.sound) {
            btn_sound.setChecked(CommonUtility.LOCALSOUND_CN.equals(CommonUtility.sound));
            btn_sound.setContentDescription(getResources().getString(R.string.btn_cantonchinese_cn));
        } else {
            btn_sound.setContentDescription(getResources().getString(R.string.btn_cantonchinese_tw));
        }
//        btn_sound.setChecked(CommonUtility.LOCALSOUND_HK.equals(CommonUtility.sound));
        if (settings.getString("notice", "") == CommonUtility.notice) {
            btn_notice.setChecked(CommonUtility.LOCALNOTICE_ON.equals(CommonUtility.notice));
            btn_notice.setContentDescription(getResources().getString(R.string.btn_switchonoff_off));
        } else {
            btn_notice.setContentDescription(getResources().getString(R.string.btn_switchonoff_on));
        }
        btn_sound.setOnCheckedChangeListener(this);
        btn_notice.setOnCheckedChangeListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.img_delete: {
                try {
                    Database.deleteDatas(context, CustomerStory.class);
                    Database.deleteDatas(context, CustomerStoryInfo.class);
                    Toast.makeText(context, context.getString(R.string.bookmark_null_1), Toast.LENGTH_LONG).show();
                } catch (SQLException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.btn_lang:
                String lang = b ? CommonUtility.LOCALLANG_CN : CommonUtility.LOCALLANG_TW;
                PE.putString("lang", lang);
                CommonUtility.lang = lang;
                PE.commit();
                System.gc();
                mCallback.reloadActivity();
                break;
            case R.id.btn_sound:
                String sound = b ? CommonUtility.LOCALSOUND_CN : CommonUtility.LOCALSOUND_HK;
                PE.putString("sound", sound);
                PE.commit();
                CommonUtility.sound = sound;
                if (sound.equals(CommonUtility.LOCALSOUND_CN))
                    btn_sound.setContentDescription(getResources().getString(R.string.btn_cantonchinese_cn));
                else
                    btn_sound.setContentDescription(getResources().getString(R.string.btn_cantonchinese_tw));
                break;
            case R.id.btn_notice:
                String notice = b ? CommonUtility.LOCALNOTICE_ON : CommonUtility.LOCALNOTICE_OFF;
                PE.putString("notice", notice);
                PE.commit();
                CommonUtility.notice = notice;
                if (notice.equals(CommonUtility.LOCALNOTICE_ON))
                    btn_notice.setContentDescription(getResources().getString(R.string.btn_switchonoff_off));
                else
                    btn_notice.setContentDescription(getResources().getString(R.string.btn_switchonoff_on));
                break;
        }
    }
}
