package com.sahk.sahkp.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import com.androidquery.AQuery;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.about.AboutFragment;
import com.sahk.sahkp.bookmark.BookMarkFragment;
import com.sahk.sahkp.form.FormFragment;
import com.sahk.sahkp.profile.ProfileFragment;
import com.sahk.sahkp.setting.SettingFragment;
import com.sahk.sahkp.story.MainFragment;
import com.sahk.sahkp.story.StorymadeFragment;
import com.sahk.sahkp.usage.UsageFragment;
import com.sahk.sahkp.webaccessibility.WebAccessibilityFragment;

/**
 * Created by Winkey on 16/8/13.
 */
public class MenuFragment extends Fragment implements RadioGroup.OnCheckedChangeListener {

    public int curRadioId = R.id.btn_menu_stories;
    private AQuery aq;

    private OnListListener mCallback;
    private RadioGroup radioGroup;
    private Fragment stories, about, setting, bookmark, usage, form, storemade, webaccessibility;
    private Fragment preFragment;


    public MenuFragment() {
    }

    public MenuFragment(int radioId) {
        if (radioId > 0)
            curRadioId = radioId;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
        try {
            mCallback = (OnListListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement Fragment Interface");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.menu_content, container, false);
        aq = new AQuery(v);
        init();
        return v;
    }

    private void init() {
        mCallback.switchContent(getFragmentItem(curRadioId));

        radioGroup = (RadioGroup) aq.id(R.id.radio_menu).getView();
        radioGroup.check(curRadioId);
        radioGroup.setOnCheckedChangeListener(this);

        aq.id(R.id.btn_menu_profile).clicked(this, "menuClick");
    }

    private Fragment getFragmentItem(int radioId) {
        Fragment fragment = null;
        switch (radioId) {
            case R.id.btn_menu_stories:
                if (stories == null) {
                    stories = new MainFragment();
                    preFragment = stories;
                }
                fragment = stories;
                break;
            case R.id.btn_menu_custom_stories:
                if (storemade == null)
                    storemade = new StorymadeFragment();
                fragment = storemade;
                break;
            case R.id.btn_menu_bookmark:
                if (bookmark == null)
                    bookmark = new BookMarkFragment();
                fragment = bookmark;
                break;
            case R.id.btn_menu_about:
                if (about == null)
                    about = new AboutFragment();
                fragment = about;
                break;
            case R.id.btn_menu_usage:
                if (usage == null)
                    usage = new UsageFragment();
                fragment = usage;
                break;
            case R.id.btn_menu_form:
                if (form == null)
                    form = new FormFragment();
                fragment = form;
                break;
            case R.id.btn_menu_webaccessibility:
                if (webaccessibility == null)
                    webaccessibility = new WebAccessibilityFragment();
                fragment = webaccessibility;
                break;
            case R.id.btn_menu_setting:
                if (setting == null)
                    setting = new SettingFragment();
                fragment = setting;
                break;
            case R.id.btn_menu_profile:
                mCallback.switchContent(new ProfileFragment());
                break;
        }
        return fragment;
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        curRadioId = i;
        if (preFragment != null)
            ((_AbstractMainFragment) preFragment).toBack();
        Fragment fragment = getFragmentItem(i);
        if (fragment == null)
            return;
        mCallback.switchContent(fragment);
        preFragment = fragment;
    }

    // Container Activity must implement this interface
    public interface OnListListener {

        public void switchContent(Fragment fragment);

        public void addContent(Fragment fragment);
    }
}
