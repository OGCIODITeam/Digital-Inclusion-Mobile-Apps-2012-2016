package com.sahk.sahkp;

import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.*;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.androidquery.callback.AbstractAjaxCallback;
import com.google.android.vending.expansion.downloader.*;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.ReadingList;
import com.sahk.sahkp.data.ResourceTaker;
import com.sahk.sahkp.fragments.MenuFragment;
import com.sahk.sahkp.setting.SettingFragment;
import com.sahk.sahkp.story.MainFragment;
import com.sahk.sahkp.story.StorymadeFragment;
import com.sahk.sahkp.tools.net.MySSLSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;

import java.io.*;
import java.security.KeyStore;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends SlidingFragmentActivity implements MainFragment.OnListListener, MenuFragment.OnListListener, View.OnClickListener, IDownloaderClient {

    private static final String TAG = "MainActivity";
    MenuFragment menuFragment;
    private BluetoothServerSocket mmServerSocket;
    private Fragment mContent;
    private ProgressDialog loadingDailog;
    private SharedPreferences settings;
    private boolean isReload;
    private BluetoothAdapter mBluetoothAdapter;
    private boolean isPause;
    private Dialog dialog;
    private IDownloaderService mRemoteService;
    private IStub mDownloaderClientStub;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    finishLoading();
                    break;
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.e(TAG, "--------->onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        settings = getSharedPreferences(CommonUtility.APP_NAME, MODE_PRIVATE);
        init();
    }

    @Override
    protected void onResume() {
        Log.e(TAG, "--------->onResume");
        super.onResume();
        isPause = false;
        openBlueTooth();

        // Removed to stop dismissing dialog right after it points to an EasyDialog or Advertisement Dialog
        //dimissD();
        //

    }

    private void init() {
        downloadOrZip();
        setZipPath();
        setLocalSetting();
        mDownloaderClientStub = DownloaderClientMarshaller.CreateStub(this, MyDownLoadService.class);

        getIntentContent();
        getUUID();
        setssh();
        ResourceTaker.initialData(this);

        // set the behind view
        menuFragment = new MenuFragment(0);
        setBehindContentView(R.layout.menu);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.menu_frame, menuFragment)
                .commit();
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        CommonUtility.screenWidth = dm.widthPixels;
        CommonUtility.screenHeight = dm.heightPixels;
        int bookWidth = getResources().getDimensionPixelSize(R.dimen.book_cover_width);
        CommonUtility.bookNum = (CommonUtility.screenWidth - bookWidth / 2) / bookWidth;
        int _width = getResources().getDimensionPixelSize(R.dimen.menu_offset);
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(getResources(), R.drawable.sahk_manu_bu1_down, option);
        int menuW = option.outWidth;
        CommonUtility.screenDesity = dm.density;
        _width = dm.widthPixels - (int) (menuW);
        if (_width < 100) {
            _width = 100;
        }
        // customize the SlidingMenu
        SlidingMenu sm = getSlidingMenu();
        sm.setBehindOffset(_width);
        sm.setFadeDegree(0.35f);
        sm.setShadowWidth(50);
        sm.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
        sm.setShadowDrawable(R.drawable.shadow);
        // ------end

        setReport();
        openBlueTooth();

    }

    //设置 zip 文件夹路径
    private String setZipPath() {
        String sdcardPath = Environment.getExternalStorageDirectory().getPath();
        String zipFile = sdcardPath + "/SAHK/.sahkpfiles";
        CommonUtility.LOCAL_FILE_PATH = zipFile;
        return zipFile;
    }

    //设置保存 zip 文件的路径
    private String setZipFilePath() {
        String sdcardPath = Environment.getExternalStorageDirectory().getPath();
        String packageName = MainActivity.this.getPackageName();

        // Rewritten to use the zip file path in the 20140325 version
        return sdcardPath + "/Android/obb/" + packageName + "/main.3.com.sahk.sahkp.obb";
        //return sdcardPath + "/Android/obb/" + packageName + "/main.5.com.sahk.sahkp.obb";
        //

    }

    private void openBlueTooth() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            return;
        }
        if (!mBluetoothAdapter.isEnabled()) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isPause)
                        openBlueTooth();
                }
            }, 60000);
            return;
        }
        if (mmServerSocket == null)
            new AcceptThread().start();
    }

    private class AcceptThread extends Thread {
        public AcceptThread() {
            BluetoothServerSocket tmp = null;
            try {
                tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(CommonUtility.NAME, CommonUtility.MY_UUID);
            } catch (IOException e) {
            }
            mmServerSocket = tmp;
        }

        public void run() {
            BluetoothSocket socket = null;
            while (true) {
                if (mmServerSocket == null)
                    return;
                try {
                    try {
                        socket = mmServerSocket.accept();
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    }
                } catch (final IOException e) {
                }
                if (socket != null) {
                    manageConnectedSocket(socket);
                }
            }
        }

        public void cancel() {
            try {
                mmServerSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void manageConnectedSocket(BluetoothSocket socket) {
        ExchangeThread exchangeThread = new ExchangeThread(this, socket);
        exchangeThread.start();
    }

    private void setLocalSetting() {

        setLang();
        setSound();
        setNotice();
    }

    private void setLang() {
        Resources res = getApplicationContext().getResources();
        Configuration conf = res.getConfiguration();
        String lang = settings.getString("lang", "");
        if (CommonUtility.LOCALLANG_CN.equals(lang)) {
            conf.locale = Locale.SIMPLIFIED_CHINESE;
            CommonUtility.lang = CommonUtility.LOCALLANG_CN;
        } else {
            CommonUtility.lang = CommonUtility.LOCALLANG_TW;
            conf.locale = Locale.TRADITIONAL_CHINESE;
        }
        res.updateConfiguration(conf, null);
    }

    private void setSound() {
        String lang = settings.getString("sound", "");
        if (CommonUtility.LOCALSOUND_CN.equals(lang)) {
            CommonUtility.sound = CommonUtility.LOCALSOUND_CN;
        } else {
            CommonUtility.sound = CommonUtility.LOCALSOUND_HK;
        }
    }

    private void setNotice() {
        String lang = settings.getString("notice", "");
        if (CommonUtility.LOCALNOTICE_ON.equals(lang)) {
            CommonUtility.notice = CommonUtility.LOCALNOTICE_ON;
        } else {
            CommonUtility.notice = CommonUtility.LOCALNOTICE_OFF;
        }

    }

    private void getIntentContent() {
        Intent intent = getIntent();
        if (intent != null) {
            String tel = intent.getDataString();
            if (tel != null) {
                List<ReadingList> list = getReadingListByStudentId(1);

                int ReadingListSize = 0;
                if (list != null) {
                    ReadingListSize = list.size();
                }
                if (ReadingListSize != 0) {
                    tel = tel.replace("tel:", "");
                    ReadingList readingList = new ReadingList();
                    readingList.studentid = 1;
                    readingList.readinglistname = (ReadingListSize + 1) + "";
                    readingList.books = tel;
                    try {
                        Database.saveData(this, ReadingList.class, readingList);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private List getReadingListByStudentId(int student_id) {
        List<Database> list = null;
        try {
            list = Database.getDatas(this, ReadingList.class, "studentid", student_id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    private void getUUID() {
        CommonUtility.MY_UUID = UUID.fromString("00001106-0000-1000-8000-00805F9B34FB");
//        TelephonyManager tm = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
//        String tmDevice = "" + tm.getDeviceId();
//        String tmSerial = "" + tm.getSimSerialNumber();
//        String androidId = "" + android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
//        CommonUtility.MY_UUID = new UUID(androidId.hashCode(), ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
    }

    private void setssh() {
        try {
            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            trustStore.load(null, null);

            SSLSocketFactory sf = new MySSLSocketFactory(trustStore);
            sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            AbstractAjaxCallback.setSSF(sf);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setReport() {
        long report = settings.getLong("report", 0);
        Date d = new Date();
        if (report == 0) {
            SharedPreferences.Editor editor = settings.edit();
            editor.putLong("report", d.getTime());
            editor.commit();
            return;
        }
        long subTime = d.getTime() - report;
        if (subTime > 30 * 24 * 60 * 60 * 1000l) {
            SharedPreferences.Editor editor = settings.edit();
            editor.putLong("report", d.getTime());
            editor.commit();
            startActivity(new Intent(this, ReportActivity.class));
        }
    }

    private void downloadOrZip() {
        try {
            if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                Toast.makeText(this, getString(R.string.no_sdkcard), Toast.LENGTH_LONG).show();
                this.finish();
            }
            File file = new File(setZipPath());
            File obbfile = new File(setZipFilePath());

            // Rewritten to use the code in 20140325 version
            //if (file.exists()) {
                //if (obbfile.exists()) {
                    //File fileCN = new File(setZipPath() + "/cn");
                    //File fileCNTW = new File(setZipPath() + "/cntw");
                    //if (!fileCN.exists() || !fileCNTW.exists()) {
                        //showMyDialog(R.string.dialog3_prompt);
                    //}
                //} else {
                    //showMyDialog(R.string.dialog4_prompt);
                //}
            //} else {
                //showMyDialog(R.string.dialog4_prompt);
            //}
            if (!file.exists()) {
                if (obbfile.exists()) {
                    showMyDialog(R.string.dialog3_prompt);
                } else {
                    showMyDialog(R.string.dialog4_prompt);
                }
            }
            else {
                dialog = new AdvertisementDialog();
            }
            //

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showMyDialog(int msg) {
        dialog = new EasyDialog(this, R.style.dialog, R.layout.mydialog1, msg, R.id.dialog1_confirm, R.id.dialog1_cancel);
    }

    public class EasyDialog extends Dialog {
        public EasyDialog(Context context, int style, int layout, int msg, int confirm, int cancel) {
            super(context, style);
            Window window = getWindow();
            window.setContentView(layout);
            TextView t = (TextView) window.findViewById(R.id.dialog_txt_title);
            t.setText(msg);
            Button btConfirm = (Button) window.findViewById(confirm);
            Button btCancel = (Button) window.findViewById(cancel);
            btConfirm.setTag(msg);
            btCancel.setTag(msg);
            btConfirm.setOnClickListener(MainActivity.this);
            btCancel.setOnClickListener(MainActivity.this);
            show();
        }

        @Override
        public void dismiss() {
            super.dismiss();
        }
    }

    // Added to setup and show the advertisement popup
    public class AdvertisementDialog extends Dialog {
        public AdvertisementDialog() {
            super(MainActivity.this, R.style.dialog);
            Window window = getWindow();
            window.setContentView(R.layout.advertisementdialog);
            ((ImageButton) window.findViewById(R.id.advertisement_link)).setOnClickListener(MainActivity.this);
            ((Button) window.findViewById(R.id.advertisement_close)).setOnClickListener(MainActivity.this);
            show();
        }
    }
    //

    private void dimissD() {
        if (dialog != null) {
            dialog.dismiss();
            dialog = null;
        }
    }

    private void downloadFile() {
        try {
            Intent launchIntent = this.getIntent();
            Intent intentToLaunchThisActivityFromNotification = new Intent(this, MainActivity.class);
            intentToLaunchThisActivityFromNotification.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intentToLaunchThisActivityFromNotification.setAction(launchIntent.getAction());

            if (launchIntent.getCategories() != null) {
                for (String category : launchIntent.getCategories()) {
                    intentToLaunchThisActivityFromNotification.addCategory(category);
                }
            }

            PendingIntent pendingIntent = PendingIntent.getActivity(
                    this,
                    0, intentToLaunchThisActivityFromNotification,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            int startResult = DownloaderClientMarshaller.startDownloadServiceIfRequired(this,
                    pendingIntent, MyDownLoadService.class);

            if (startResult != DownloaderClientMarshaller.NO_DOWNLOAD_REQUIRED) {
                mDownloaderClientStub = DownloaderClientMarshaller.CreateStub(this,
                        MyDownLoadService.class);
                dimissD();
                return;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void depressFile() {
        onLoading(getString(R.string.unziping));
        new Thread() {
            @Override
            public void run() {
                String zipFile = setZipFilePath();
                String unZipFile = setZipPath();
                unzip(zipFile, unZipFile);
            }

            private void save(File file1, File file2) {
                try {
                    FileInputStream fis = new FileInputStream(file2);
                    FileOutputStream fos = new FileOutputStream(file1);
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = fis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fis.close();
                    fos.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            private void unzip(String zipFile, String unZipFile) {
                try {
                    FileInputStream fin = new FileInputStream(zipFile);
                    ZipInputStream zin = new ZipInputStream(fin);
                    File pFile = new File(unZipFile);
                    pFile.mkdirs();
                    ZipEntry ze = null;
                    while ((ze = zin.getNextEntry()) != null) {
                        if (ze.isDirectory()) {
                            File file = new File(pFile, ze.getName());
                            file.mkdirs();
                        } else {
                            FileOutputStream fos = new FileOutputStream(unZipFile + "/" + ze.getName());
                            byte buffer[] = new byte[1024];
                            int len;
                            while ((len = zin.read(buffer)) > 0) {
                                fos.write(buffer, 0, len);
                            }
                            fos.close();
                        }
                        zin.closeEntry();
                    }
                    zin.close();
                    handler.sendEmptyMessage(0);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(0);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    public void onClick(View v) {
        if (mContent instanceof _AbstractMainFragment) {
            ((_AbstractMainFragment) mContent).onClick(v);
        }
        switch (v.getId()) {
            case R.id.dialog1_confirm:
                if ((Integer) v.getTag() == R.string.dialog3_prompt) {
                    depressFile();
                } else if ((Integer) v.getTag() == R.string.dialog4_prompt) {
                    if (CommonUtility.isNetAvailable(MainActivity.this)) {
                        downloadFile();
                    } else {
                        Toast.makeText(MainActivity.this, getString(R.string.net_invaliable), Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case R.id.dialog1_cancel:
                if ((Integer) v.getTag() == R.string.dialog3_prompt) {
                } else if ((Integer) v.getTag() == R.string.dialog4_prompt) {
                }
                break;

            // Added to surf the advertisement website when users click the advertisement graphics
            case R.id.advertisement_link:
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(this.getResources().getString(R.string.advertisement_link)));
                startActivity(i);
            //

        }
        dimissD();
    }

    @Override
    public void onLoading(String msg) {
        if (loadingDailog != null)
            loadingDailog.dismiss();
        loadingDailog = ProgressDialog.show(this, null, msg != null ? msg : this.getResources().getString(R.string.loading));
    }

    @Override
    public void finishLoading() {
        if (loadingDailog != null)
            loadingDailog.dismiss();
    }

    public void switchContent(Fragment fragment) {
        if (fragment == null && mContent == fragment)
            return;
        mContent = fragment;
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.content_frame, fragment)
//                .addToBackStack(null)
                .commit();
        getSlidingMenu().showContent();
        if (isReload && menuFragment.curRadioId != R.id.btn_menu_setting) {
            addContent(new SettingFragment());
        }
        isReload = false;
    }

    @Override
    public void addContent(Fragment fragment) {
        if (fragment == null && mContent == fragment)
            return;
        mContent = fragment;
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.content_frame, fragment)
                .addToBackStack(null)
                .commit();
        getSlidingMenu().showContent();
    }

    @Override
    public void onBack() {
        onBackPressed();
    }

    @Override
    public void reloadActivity() {
        isReload = true;
        getSupportFragmentManager().popBackStack();
        setLang();
        menuFragment = new MenuFragment(menuFragment.curRadioId);
        addMenuFragment();
    }

    @Override
    public void showSlidingMenu() {
        getSlidingMenu().toggle();
    }

    private void addMenuFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.menu_frame, menuFragment)
                .commit();
    }

    public void onBackPressed() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (count > 0) {
            if (mContent instanceof _AbstractMainFragment) {
                ((_AbstractMainFragment) mContent).onBack();
            }
            getSupportFragmentManager().popBackStack();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mContent = getSupportFragmentManager().findFragmentById(R.id.content_frame);
                    if (mContent instanceof StorymadeFragment)
                        switchContent(new StorymadeFragment());
                }
            }, 350);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onServiceConnected(Messenger m) {
        mRemoteService = DownloaderServiceMarshaller.CreateProxy(m);
        mRemoteService.onClientUpdated(mDownloaderClientStub.getMessenger());
    }

    @Override
    public void onDownloadStateChanged(int newState) {
    }

    @Override
    public void onDownloadProgress(DownloadProgressInfo progress) {
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mContent.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        isPause = true;
    }

    @Override
    protected void onStart() {
        if (null != mDownloaderClientStub) {
            mDownloaderClientStub.connect(this);
        }
        super.onStart();
    }

    @Override
    protected void onStop() {
        if (null != mDownloaderClientStub) {
            mDownloaderClientStub.disconnect(this);
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.e(TAG, "---------->onDestroy");
        dimissD();
        if (null != mDownloaderClientStub) {
            mDownloaderClientStub.disconnect(this);
        }
        super.onDestroy();
    }

}
