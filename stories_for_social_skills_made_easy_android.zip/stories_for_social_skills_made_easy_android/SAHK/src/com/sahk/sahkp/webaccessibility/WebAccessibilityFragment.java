package com.sahk.sahkp.webaccessibility;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidquery.AQuery;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
/**
 * Created by Kit on 21/1/2015.
 */
public class WebAccessibilityFragment extends _AbstractMainFragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        this.inflater = inflater;
        View v = inflater.inflate(R.layout.web_accessibility, container, false);
        aq = new AQuery(v);
        init();

        // Inflate the layout for this fragment
        return v;
    }

    private void init() {

    }
}

