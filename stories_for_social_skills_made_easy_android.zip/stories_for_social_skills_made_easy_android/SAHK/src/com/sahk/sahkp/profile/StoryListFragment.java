package com.sahk.sahkp.profile;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.ToggleButton;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.about.AboutFragment;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.ReadingList;
import it.sephiroth.android.library.widget.HListView;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by casum on 13-9-26.
 */
public class StoryListFragment extends _AbstractMainFragment {

    private ProfileFragment profileFragment;
    private View currentMenu;
    private BookAdapter adapter1, adapter2, adapter3, adapter4, adapter5;
    private int studentID;
    private List<ReadingList> list;
    private String books2 = "";
    private String booksStr;
    private boolean isOnclick;

    public StoryListFragment() {

    }

    public StoryListFragment(ProfileFragment profileFragment, int studentID) {
        this.profileFragment = profileFragment;
        this.studentID = studentID;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.storylist, container, false);
        aq = new AQuery(v);
        init();

        // Inflate the layout for this fragment
        return v;
    }

    private void init() {
        adapter1 = new BookAdapter(0);
        adapter2 = new BookAdapter(1);
        adapter3 = new BookAdapter(2);
        adapter4 = new BookAdapter(3);
        adapter5 = new BookAdapter(4);

        ((HListView) aq.id(R.id.lv_1).getView()).setAdapter(adapter1);
        ((HListView) aq.id(R.id.lv_2).getView()).setAdapter(adapter2);
        ((HListView) aq.id(R.id.lv_3).getView()).setAdapter(adapter3);
        ((HListView) aq.id(R.id.lv_4).getView()).setAdapter(adapter4);
        ((HListView) aq.id(R.id.lv_5).getView()).setAdapter(adapter5);

        list = getReadingListByStudentId(studentID);

        aq.id(R.id.btn_ok).clicked(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isOnclick)
                    return;
                isOnclick = true;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int ReadingListSize = 0;
                        if (list != null) {
                            ReadingListSize = list.size();
                        }

                        ReadingList readingList = new ReadingList();
                        readingList.studentid = studentID;
                        readingList.readinglistname = (ReadingListSize + 1) + "";
                        readingList.books = booksStr;
                        try {
                            Database.saveData(context, ReadingList.class, readingList);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        context.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mCallback.finishLoading();
                                profileFragment.refreshReadingList();
                                mCallback.onBack();
                            }
                        });
                    }
                }).start();
            }
        });
    }

    @Override
    public void onBack() {
        super.onBack();
        profileFragment.refreshReadingList(true);
    }

    private List getReadingListByStudentId(int student_id) {
        List<Database> list = null;
        try {
            list = Database.getDatas(context, ReadingList.class, "studentid", student_id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void menuClick(View v) {
        currentMenu.setSelected(false);
        currentMenu = v;
        v.setSelected(true);

        switch (v.getId()) {
            case R.id.btn_menu_about:
                mCallback.switchContent(new AboutFragment());
                break;
        }
    }

    private String addBooks(int index) {
        if (index >= 0) {
            List<Integer> list = getReadingList();
            if (!list.contains(index)) {
                list.add(index);
                StringBuilder stringBuilder = new StringBuilder();
                boolean isFirst = true;
                for (Integer intid : list) {
                    if (!isFirst) {
                        stringBuilder.append(",");
                    } else {
                        isFirst = false;
                    }
                    stringBuilder.append(intid);
                }
                books2 = stringBuilder.toString();
            }
        }
        return books2;
    }

    public List<Integer> getReadingList() {
        List<Integer> list = new ArrayList<Integer>();
        if (books2 != null && books2.length() > 0) {
            String[] strid = books2.split(",");
            for (String sid : strid) {
                if (sid != null && sid.length() > 0)
                    list.add(Integer.parseInt(sid));
            }
        }
        return list;
    }

    public String delBooks(int index) {
        if (index >= 0) {
            List<Integer> list = getReadingList();
            if (list.contains(index)) {
                list.remove((Integer) index);
                StringBuilder stringBuilder = new StringBuilder();
                boolean isFirst = true;
                for (Integer intid : list) {
                    if (!isFirst) {
                        stringBuilder.append(",");
                    } else {
                        isFirst = false;
                    }
                    stringBuilder.append(intid);
                }
                books2 = stringBuilder.toString();
            }
        }
        return books2;
    }

    class BookAdapter extends BaseAdapter {

        private int[] mCount = {32, 27, 14, 17, 10};
        private int mIndex = 0;

        BookAdapter(int index) {
            mIndex = index;
        }

        @Override
        public int getCount() {
            return mCount[mIndex];
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public View getView(final int pos, View view, ViewGroup viewGroup) {
            int index = pos + 1;
            for (int i = 0; i < mIndex; i++) {
                index += mCount[i];
            }

            if (view == null) {
                LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.book_item_2, null);
            }

            AQuery aq_view = new AQuery(view);
            aq_view.id(R.id.layout_rating).visibility(View.INVISIBLE);
            aq_view.id(R.id.toggle_add).visibility(View.VISIBLE);
            final ToggleButton toggle = (ToggleButton) aq_view.id(R.id.toggle_add).getView();
            final int finalIndex = index;
            toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (toggle.isChecked()) {
                        books2 = addBooks(finalIndex);
                    } else {
                        books2 = delBooks(finalIndex);
                    }
                    booksStr = books2;
                }
            });


            try {
                InputStream imgStream = getActivity().getAssets().open(CommonUtility.getFirstImage(index));
                Drawable drawable = new WeakReference<Drawable>(Drawable.createFromStream(imgStream, null)).get();
                aq_view.id(R.id.img_book).image(drawable);
                aq_view.id(R.id.img_book).getView().setContentDescription(context.getResources().getStringArray(strids[index - 1])[0]);

            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }

            aq_view.id(R.id.img_book).clicked(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!toggle.isChecked()) {
                        toggle.setChecked(true);
                    } else {
                        toggle.setChecked(false);
                    }
                    if (toggle.isChecked()) {
                        books2 = addBooks(finalIndex);
                    } else {
                        books2 = delBooks(finalIndex);
                    }
                    booksStr = books2;
                }
            });


            return view;
        }
    }

}
