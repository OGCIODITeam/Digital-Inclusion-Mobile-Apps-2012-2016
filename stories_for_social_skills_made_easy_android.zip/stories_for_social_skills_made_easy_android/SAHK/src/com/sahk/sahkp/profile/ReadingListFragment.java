package com.sahk.sahkp.profile;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.ToggleButton;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.about.AboutFragment;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.ReadingList;
import it.sephiroth.android.library.widget.HListView;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by casum on 13-9-22.
 */
public class ReadingListFragment extends _AbstractMainFragment {

    private View currentMenu;
    private BookAdapter adapter1, adapter2, adapter3, adapter4, adapter5;
    private int readinglistID;
    private List<Integer> readinglists;
    private ReadingList readings;
    private String books2 = "";
    private String booksStr;
    public static final int[] strids = new int[]{R.array.story1, R.array.story2, R.array.story3,
            R.array.story4, R.array.story5, R.array.story6, R.array.story7, R.array.story8, R.array.story9, R.array.story10, R.array.story11, R.array.story12, R.array.story13, R.array.story14, R.array.story15, R.array.story16, R.array.story17,
            R.array.story18, R.array.story19, R.array.story20, R.array.story21, R.array.story22, R.array.story23, R.array.story24, R.array.story25, R.array.story26, R.array.story27, R.array.story28, R.array.story29, R.array.story30, R.array.story31,
            R.array.story32, R.array.story33, R.array.story34, R.array.story35, R.array.story36, R.array.story37, R.array.story38, R.array.story39, R.array.story40, R.array.story41, R.array.story42, R.array.story43, R.array.story44, R.array.story45,
            R.array.story46, R.array.story47, R.array.story48, R.array.story49, R.array.story50, R.array.story51, R.array.story52, R.array.story53, R.array.story54, R.array.story55, R.array.story56, R.array.story57, R.array.story58, R.array.story59,
            R.array.story60, R.array.story61, R.array.story62, R.array.story63, R.array.story64, R.array.story65, R.array.story66, R.array.story67, R.array.story68, R.array.story69, R.array.story70, R.array.story71, R.array.story72, R.array.story73,
            R.array.story74, R.array.story75, R.array.story76, R.array.story77, R.array.story78, R.array.story79, R.array.story80, R.array.story81, R.array.story82, R.array.story83, R.array.story84, R.array.story85, R.array.story86, R.array.story87,
            R.array.story88, R.array.story89, R.array.story90, R.array.story91, R.array.story92, R.array.story93, R.array.story94, R.array.story95, R.array.story96, R.array.story97, R.array.story98, R.array.story99, R.array.story100
    };

    public ReadingListFragment() {
    }

    public ReadingListFragment(int readinglistID) {
        this.readinglistID = readinglistID;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        View v = inflater.inflate(R.layout.readinglist, container, false);
        aq = new AQuery(v);
        init();

        // Inflate the layout for this fragment
        return v;
    }

    private void init() {

        try {
            readings = (ReadingList) Database.getDatasForId(context, ReadingList.class, readinglistID);
            if (readings != null) {
                readinglists = getReadingBookList(readings.books);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        adapter1 = new BookAdapter(0);
        adapter2 = new BookAdapter(1);
        adapter3 = new BookAdapter(2);
        adapter4 = new BookAdapter(3);
        adapter5 = new BookAdapter(4);
        ((HListView) aq.id(R.id.lv_1).getView()).setAdapter(adapter1);
        ((HListView) aq.id(R.id.lv_2).getView()).setAdapter(adapter2);
        ((HListView) aq.id(R.id.lv_3).getView()).setAdapter(adapter3);
        ((HListView) aq.id(R.id.lv_4).getView()).setAdapter(adapter4);
        ((HListView) aq.id(R.id.lv_5).getView()).setAdapter(adapter5);
        //update Reading list
        aq.id(R.id.btn_ok).clicked(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    ReadingList rbooks = (ReadingList) Database.getDatasForId(context, ReadingList.class, readinglistID);
                    rbooks.books = booksStr;
                    try {
                        Database.saveData(context, ReadingList.class, rbooks);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    mCallback.switchContent(new ProfileFragment());
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private List<Integer> getReadingBookList(String books) {
        List<Integer> list = new ArrayList<Integer>();
        if (books != null && books.length() > 0) {
            String[] strid = books.split(",");
            for (String sid : strid) {
                if (sid != null && sid.length() > 0)
                    list.add(Integer.parseInt(sid));
            }
        }
        return list;
    }

    public void menuClick(View v) {
        currentMenu.setSelected(false);
        currentMenu = v;
        v.setSelected(true);

        switch (v.getId()) {
            case R.id.btn_menu_about:
                mCallback.switchContent(new AboutFragment());
                break;
        }
    }

    private String addBooks(int index) {
        if (index >= 0) {
            List<Integer> list = getReadingList();
            if (!list.contains(index)) {
                list.add(index);
                StringBuilder stringBuilder = new StringBuilder();
                boolean isFirst = true;
                for (Integer intid : list) {
                    if (!isFirst) {
                        stringBuilder.append(",");
                    } else {
                        isFirst = false;
                    }
                    stringBuilder.append(intid);
                }
                books2 = stringBuilder.toString();
            }
        }
        return books2;
    }

    public List<Integer> getReadingList() {
        List<Integer> list = new ArrayList<Integer>();
        if (books2 != null && books2.length() > 0) {
            String[] strid = books2.split(",");
            for (String sid : strid) {
                if (sid != null && sid.length() > 0)
                    list.add(Integer.parseInt(sid));
            }
        }
        return list;
    }

    public String delBooks(int index) {
        if (index >= 0) {
            List<Integer> list = getReadingList();
            if (list.contains(index)) {
                list.remove((Integer) index);
                StringBuilder stringBuilder = new StringBuilder();
                boolean isFirst = true;
                for (Integer intid : list) {
                    if (!isFirst) {
                        stringBuilder.append(",");
                    } else {
                        isFirst = false;
                    }
                    stringBuilder.append(intid);
                }
                books2 = stringBuilder.toString();
            }
        }
        return books2;
    }

    class BookAdapter extends BaseAdapter {

        private int[] mCount = {32, 27, 14, 17, 10};
        private int mIndex = 0;

        BookAdapter(int index) {
            mIndex = index;
        }

        @Override
        public int getCount() {
            return mCount[mIndex];
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public View getView(final int pos, View view, ViewGroup viewGroup) {
            int index = pos + 1;
            for (int i = 0; i < mIndex; i++) {
                index += mCount[i];
            }

            if (view == null) {
                view = inflater.inflate(R.layout.book_item_2, null);
            }

            AQuery aq_view = new AQuery(view);
            aq_view.id(R.id.toggle_add).checked(false);
            aq_view.id(R.id.layout_rating).invisible();
            aq_view.id(R.id.toggle_add).visible();
            aq_view.getView().setContentDescription(context.getResources().getStringArray(strids[index - 1])[0]);
            final ToggleButton toggle = (ToggleButton) aq_view.id(R.id.toggle_add).getView();

            final int finalIndex = index;
            toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if (toggle.isChecked()) {
                        books2 = addBooks(finalIndex);
                    } else {
                        books2 = delBooks(finalIndex);
                    }
                    booksStr = books2;
                }
            });

            try {
                InputStream imgStream = getActivity().getAssets().open(CommonUtility.getFirstImage(index));
                Drawable drawable = new WeakReference<Drawable>(Drawable.createFromStream(imgStream, null)).get();
                aq_view.id(R.id.img_book).image(drawable);
                aq_view.id(R.id.img_book).getView().setContentDescription(context.getResources().getStringArray(strids[index - 1])[0]);

            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
            if (readinglists != null) {
                if (readinglists.contains(index)) {
                    aq_view.id(R.id.toggle_add).checked(true);
                }
            }

            aq_view.id(R.id.img_book).clicked(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!toggle.isChecked()) {
                        toggle.setChecked(true);
                    } else {
                        toggle.setChecked(false);
                    }
                    if (toggle.isChecked()) {
                        books2 = addBooks(finalIndex);
                    } else {
                        books2 = delBooks(finalIndex);
                    }
                    booksStr = books2;
                }
            });

            if (toggle.isChecked()) {
                books2 = addBooks(index);
            } else {
                books2 = delBooks(index);
            }
            booksStr = books2;

            return view;
        }
    }

}

