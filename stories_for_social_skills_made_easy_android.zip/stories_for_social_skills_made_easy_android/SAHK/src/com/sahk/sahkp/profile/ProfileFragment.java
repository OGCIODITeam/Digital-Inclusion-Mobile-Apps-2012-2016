package com.sahk.sahkp.profile;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.androidquery.AQuery;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.about.AboutFragment;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.ReadingList;
import com.sahk.sahkp.data.Student;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by casum on 13-9-22.
 */
public class ProfileFragment extends _AbstractMainFragment {

    private View currentMenu;
    private LinearLayout reading_layout;
    private ViewPager viewpager;
    private List<Database> students;
    private List<Database> readinglist;
    private int cstudentID = -1;
    private boolean isOnclick;
    //    private LinearLayout dot_layout;
    private int currentIndex = -1;

    //private List<>
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.profile, container, false);

        aq = new AQuery(v);
        init();

        // Inflate the layout for this fragment
        return v;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.btn_add:
                mCallback.addContent(new ProfileDetailFragment());
                break;
            case R.id.btn_edit:
                if (cstudentID == -1)
                    return;
                mCallback.addContent(new ProfileDetailFragment(this, cstudentID));
                break;
            case R.id.btn_add_reading_list:
                if (isOnclick)
                    return;
                isOnclick = true;

                mCallback.addContent(new StoryListFragment(this, cstudentID));
                break;
        }
    }

    private void init() {
        viewpager = (ViewPager) aq.id(R.id.viewpager).getView();
//        dot_layout = (LinearLayout) aq.id(R.id.dot_layout).getView();
        reading_layout = (LinearLayout) aq.id(R.id.reading_layout).getView();

        refreshStudent();

        refreshReadingList();
    }

    public void refreshReadingList() {
        refreshReadingList(false);
    }

    public void refreshReadingList(boolean isOnBack) {
        isOnclick = false;
        if (isOnBack) {
            return;
        }
        if (cstudentID == -1)
            return;

        reading_layout.removeAllViews();
        if (readinglist != null) {
            readinglist.clear();
        }
        readinglist = getReadingListByStudentId(cstudentID);
        if (readinglist != null) {


            for (int i = 0; i < readinglist.size(); i++) {
                final ReadingList readlist = (ReadingList) readinglist.get(i);
                final Integer rid = readlist.id;
                LayoutInflater inflater = LayoutInflater.from(context);
                final View view = inflater.inflate(R.layout.reading_list_title, null);

                TextView title = (TextView) view.findViewById(R.id.title);
                title.setText(context.getResources().getString(R.string.readList) + (i + 1));

                Button btn_share = (Button) view.findViewById(R.id.btn_share);
                Button btn_delete = (Button) view.findViewById(R.id.btn_delete);
                btn_share.setTag(readlist.books);
                btn_share.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String books_id = (String) v.getTag();
                        shareWithEmail(books_id);
                    }
                });
                Button btn_go = (Button) view.findViewById(R.id.button_go);
                btn_go.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mCallback.addContent(new ReadingListFragment(rid));
                    }
                });
                reading_layout.addView(view);
                btn_delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        reading_layout.removeView(view);
                        readinglist.remove(readlist);
                        readlist.studentid = -1;
                        deleteByName(readlist);
                        refreshReadingList();
                    }
                });
                reading_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mCallback.addContent(new ReadingListFragment(rid));
                    }
                });
            }
        }
    }

    private void deleteByName(String name) {
        List<Database> list = null;
        try {
            Database.deleteData(context, ReadingList.class, "readinglistname", name);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteByName(Database database) {
        List<Database> list = null;
        try {
            Database.saveData(context, ReadingList.class, database);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void refreshStudent() {
        if (students != null) {
            students.clear();
        }
        students = getProfiles();
        if (students != null && students.size() > 0) {
            if (currentIndex < students.size() - 1)
                currentIndex++;
            Student student = (Student) students.get(currentIndex);
            if (student != null) {
                cstudentID = student.id;
            }
            MyViewPagerAdapter pagerAdapter = new MyViewPagerAdapter(students);
            viewpager.setOnPageChangeListener(pagerAdapter);
            viewpager.setAdapter(pagerAdapter);
            viewpager.setCurrentItem(currentIndex);
        }
    }

    public String checktextlength(String value) {
        if (value.length() > 14)
            return value.substring(0, 13) + "...";
        else
            return value;
    }

    private void setDot(int arg1) {
        if (students.size() == 1) {
            aq.id(R.id.btn_before).gone();
            aq.id(R.id.btn_next).gone();
        } else {
            if (arg1 == 0) {
                aq.id(R.id.btn_before).background(R.drawable.l_arrow_01).visibility(View.GONE);
                aq.id(R.id.btn_next).background(R.drawable.r_arrow_02).visibility(View.VISIBLE);
            } else if (arg1 == (students.size() - 1)) {
                aq.id(R.id.btn_before).background(R.drawable.l_arrow_02).visibility(View.VISIBLE);
                aq.id(R.id.btn_next).background(R.drawable.r_arrow_01).visibility(View.GONE);
            } else {
                aq.id(R.id.btn_before).background(R.drawable.l_arrow_02).visibility(View.VISIBLE);
                aq.id(R.id.btn_next).background(R.drawable.r_arrow_02).visibility(View.VISIBLE);
            }
        }
    }

    private void sharemessagebox() {

        final CharSequence[] items = {context.getResources().getString(R.string.email), context.getResources().getString(R.string.bluetooth)};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(context.getResources().getString(R.string.share));
        builder.setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {
                switch (item) {
                    case 0:
                        shareWithEmail("");
                        break;
                    case 1:
                        shareWithBluetooth();
                        break;
                }
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void shareWithBluetooth() {

    }

    private void shareWithEmail(String str) {
        String[] bookids = str.split(",");
        StringBuffer sb = new StringBuffer();
        int id = 0;
        String s = "";
        for (int i = 0; i < bookids.length; i++) {
            id = Integer.parseInt(bookids[i]);
            s = context.getResources().getStringArray(strids[id - 1])[0];
            sb.append(s + "<br>");
        }
//        sb.append("<br><br>govsahk://");
        String temp = context.getResources().getString(R.string.content3) + "APP:<p><a href=\"tel:" + str + "\">SAHK</a></p>";
        String down = context.getResources().getString(R.string.content1) + "&lt;Google play&gt;" + context.getResources().getString(R.string.content2) + "<br>" + context.getResources().getString(R.string.content4);
        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        String parentEmail = ((Student) students.get(currentIndex)).parentsemail;
        intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{parentEmail});
        intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
        String body = "<html> <head> <meta http-equiv=\"Content-Style-Type\" content=\"text/css\"></head>" +
                "<body>" + sb + temp + down + "</body></html>";
        intent.putExtra(android.content.Intent.EXTRA_TEXT, Html.fromHtml(body));
        intent.setType("text/html");
        startActivity(Intent.createChooser(intent, "邮件"));
    }

    private boolean addReadingList(int studentid, String name) {
        ReadingList readingList = new ReadingList();
        readingList.studentid = studentid;
        readingList.readinglistname = name;
        try {
            Database.saveData(context, ReadingList.class, readingList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }

    private List<Database> getProfiles() {
        List<Database> list = null;
        try {
            list = Database.getDatas(context, Student.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    private List getReadingListByStudentId(int student_id) {
        List<Database> list = null;
        try {
            list = Database.getDatas(context, ReadingList.class, "studentid", student_id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void menuClick(View v) {
        currentMenu.setSelected(false);
        currentMenu = v;
        v.setSelected(true);

        switch (v.getId()) {
            case R.id.btn_menu_about:
                mCallback.switchContent(new AboutFragment());
                break;
        }
    }

    private class MyViewPagerAdapter extends PagerAdapter implements ViewPager.OnPageChangeListener {

        private final List list;
        private View[] views;


        public MyViewPagerAdapter(List list) {
            this.list = list;
            views = new View[list.size()];
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {

        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            if (views[position] == null) {
                LayoutInflater inflater = context.getLayoutInflater();
                View view = inflater.inflate(R.layout.profile_item, null);

                final Student student = (Student) list.get(position);
                TextView nameText = (TextView) view.findViewById(R.id.name);

                nameText.setText(checktextlength(student.familyname + "" + student.lastname));

                TextView schoolText = (TextView) view.findViewById(R.id.school);
                schoolText.setText(checktextlength(student.school));

                TextView classText = (TextView) view.findViewById(R.id.class_txt);
                classText.setText(checktextlength(student.classname_s));

                TextView parents = (TextView) view.findViewById(R.id.parent);
                parents.setText(checktextlength(student.parents));

                TextView parentsemail = (TextView) view.findViewById(R.id.parentemail);
                parentsemail.setText(checktextlength(student.parentsemail));
                parentsemail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (list.size() > 0) {
                            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                            intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{student.parentsemail});
                            intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                            String body = "";
                            intent.putExtra(android.content.Intent.EXTRA_TEXT, Html.fromHtml(body));
                            intent.setType("text/html");
                            startActivity(Intent.createChooser(intent, "邮件"));
                        }
                    }
                });
                TextView teacher = (TextView) view.findViewById(R.id.teacher);
                teacher.setText(checktextlength(student.teacher));

                TextView teacheremail = (TextView) view.findViewById(R.id.teacheremail);
                teacheremail.setText(checktextlength(student.teacheremail));
                teacheremail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (list.size() > 0) {
                            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                            intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{student.teacheremail});
                            intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                            String body = "";
                            intent.putExtra(android.content.Intent.EXTRA_TEXT, Html.fromHtml(body));
                            intent.setType("text/html");
                            startActivity(Intent.createChooser(intent, "邮件"));
                        }
                    }
                });
                container.addView(view);
                views[position] = view;
            }
            if (list.size() > 1 && position == 0) {
                aq.id(R.id.btn_next).background(R.drawable.r_arrow_02).visibility(View.VISIBLE);
            }
            return views[position];
        }

        @Override
        public void onPageScrollStateChanged(int arg0) {
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageSelected(int arg0) {

            cstudentID = ((Student) students.get(arg0)).id;
            currentIndex = arg0;

            refreshReadingList();

            setDot(arg0);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == (arg1);
        }

        @Override
        public int getCount() {
            if (students == null)
                return 0;
            return students.size();
        }

    }

}
