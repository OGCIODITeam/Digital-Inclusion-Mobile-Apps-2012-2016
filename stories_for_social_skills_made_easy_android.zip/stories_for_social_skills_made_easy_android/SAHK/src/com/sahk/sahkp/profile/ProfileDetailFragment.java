package com.sahk.sahkp.profile;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.ReadingList;
import com.sahk.sahkp.data.Student;

import java.sql.SQLException;

/**
 * Created by casum on 13-9-18.
 */
public class ProfileDetailFragment extends _AbstractMainFragment {

    private ProfileFragment profileFragment;
    private View currentMenu;
    private String family_name;
    private String last_name;
    private String school;
    private String class_name;
    private String parents;
    private String parents_email;
    private String teacher;
    private String teacher_email;
    private int studentID = -1;
    private Student student;

    public ProfileDetailFragment() {

    }

    public ProfileDetailFragment(ProfileFragment profileFragment, int studentID) {
        this.profileFragment = profileFragment;
        this.studentID = studentID;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.profile_detail, container, false);
        aq = new AQuery(v);

        if (studentID == -1)    //save
        {
            aq.id(R.id.btn_save).clicked(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    init();
                }
            });
        } else {                 //update
            showStudent();

            aq.id(R.id.btn_save).clicked(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updateStudent();
                }
            });
        }
        // Inflate the layout for this fragment
        return v;
    }

    private void showStudent() {
        try {
            student = (Student) Database.getDatasForId(context, Student.class, studentID);
            aq.id(R.id.rl_delete).visibility(View.VISIBLE).id(R.id.bt_delete_student).clicked(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Database.deleteDataById(context, Student.class, studentID);
                        Database.deleteData(context, ReadingList.class, "studentid", studentID);
                        mCallback.switchContent(new ProfileFragment());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            });
            aq.id(R.id.family_name).text(student.familyname);
            aq.id(R.id.last_name).text(student.lastname);
            aq.id(R.id.school).text(student.school);
            aq.id(R.id.class_name).text(student.classname_s);
            aq.id(R.id.parent).text(student.parents);
            aq.id(R.id.parent_email).text(student.parentsemail);
            aq.id(R.id.teacher).text(student.teacher);
            aq.id(R.id.teacher_email).text(student.teacheremail);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateStudent() {
        family_name = String.valueOf(aq.id(R.id.family_name).getEditText().getText());
        last_name = String.valueOf(aq.id(R.id.last_name).getEditText().getText());
        school = String.valueOf(aq.id(R.id.school).getEditText().getText());
        class_name = String.valueOf(aq.id(R.id.class_name).getEditText().getText());
        parents = String.valueOf(aq.id(R.id.parent).getEditText().getText());
        parents_email = String.valueOf(aq.id(R.id.parent_email).getEditText().getText());
        teacher = String.valueOf(aq.id(R.id.teacher).getEditText().getText());
        teacher_email = String.valueOf(aq.id(R.id.teacher_email).getEditText().getText());

        if (isNot_Null(family_name, last_name, parents, parents_email, teacher, teacher_email)) {
            if (!CommonUtility.isEmail(parents_email)) {
                CommonUtility.showDialog_ok(context, context.getResources().getString(R.string.email_format_error));
                return;
            }
            if (!CommonUtility.isEmail(teacher_email)) {
                CommonUtility.showDialog_ok(context, context.getResources().getString(R.string.email_format_error));
                return;
            }

            if (!updateProfile()) {
                return;
            } else {
                new AlertDialog.Builder(context)
                        .setMessage(R.string.save_success)
                        .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
                                profileFragment.refreshStudent();
                                mCallback.onBack();
                            }
                        })
                        .show();
            }

        } else {
            CommonUtility.showDialog_ok(context, context.getResources().getString(R.string.input_not_null));
            return;
        }
    }

    private boolean updateProfile() {
        student.familyname = family_name;
        student.lastname = last_name;
        student.school = school;
        student.classname_s = class_name;
        student.parents = parents;
        student.parentsemail = parents_email;
        student.teacher = teacher;
        student.teacheremail = teacher_email;
        try {
            Student.saveData(context, Student.class, student);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }

    private void init() {
        family_name = String.valueOf(aq.id(R.id.family_name).getEditText().getText());
        last_name = String.valueOf(aq.id(R.id.last_name).getEditText().getText());
        school = String.valueOf(aq.id(R.id.school).getEditText().getText());
        class_name = String.valueOf(aq.id(R.id.class_name).getEditText().getText());
        parents = String.valueOf(aq.id(R.id.parent).getEditText().getText());
        parents_email = String.valueOf(aq.id(R.id.parent_email).getEditText().getText());
        teacher = String.valueOf(aq.id(R.id.teacher).getEditText().getText());
        teacher_email = String.valueOf(aq.id(R.id.teacher_email).getEditText().getText());

        if (isNot_Null(family_name, last_name, parents, parents_email, teacher, teacher_email)) {
            if (!CommonUtility.isEmail(parents_email)) {
                CommonUtility.showDialog_ok(context, context.getResources().getString(R.string.email_format_error));
                return;
            }
            if (!CommonUtility.isEmail(teacher_email)) {
                CommonUtility.showDialog_ok(context, context.getResources().getString(R.string.email_format_error));
                return;
            }

            if (!saveProfile()) {
                return;
            } else {
                new AlertDialog.Builder(context)
                        .setMessage(R.string.save_success)
                        .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
                                mCallback.switchContent(new ProfileFragment());
                            }
                        })
                        .show();
            }

        } else {
            CommonUtility.showDialog_ok(context, context.getResources().getString(R.string.input_not_null));
            return;
        }
    }

    private boolean saveProfile() {
        Student student1 = new Student();
        student1.familyname = family_name;
        student1.lastname = last_name;
        student1.school = school;
        student1.classname_s = class_name;
        student1.parents = parents;
        student1.parentsemail = parents_email;
        student1.teacher = teacher;
        student1.teacheremail = teacher_email;
        try {
            Student.saveData(context, Student.class, student1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }

    private boolean isNot_Null(String family_name, String last_name, String parents, String parents_email, String teacher, String teacher_email) {

        if (family_name.length() > 0 && last_name.length() > 0 && parents.length() > 0 && parents_email.length() > 0 && teacher.length() > 0 && teacher_email.length() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public void menuClick(View v) {
        currentMenu.setSelected(false);
        currentMenu = v;
        v.setSelected(true);

        switch (v.getId()) {
            case R.id.btn_menu_profile:
                mCallback.switchContent(new ProfileFragment());
                break;
        }
    }

}
