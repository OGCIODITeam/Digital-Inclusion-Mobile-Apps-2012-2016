package com.sahk.sahkp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by linlinet on 13-9-22.
 */
public class CommonUtility {
    public static final String APP_NAME = "SAHK";
    public static final String TAG = "CommonUtility";
    public static final String LOCALLANG_CN = "cn";
    public static final String LOCALLANG_TW = "cntw";
    public static final int CHOOSE_IMAGE_ACTIVITY_REQUEST_CODE = 100;
    public static final int REQUEST_ENABLE_BT = 11;
    public static UUID MY_UUID;
    public static final String NAME = "SAHK_bluetooth";
    public static String lang = LOCALLANG_TW;


    public static final String LOCALSOUND_CN = "cn";
    public static final String LOCALSOUND_HK = "hk";
    public static String sound = LOCALSOUND_HK;

    public static final String LOCALNOTICE_ON = "on";
    public static final String LOCALNOTICE_OFF = "off";
    public static String notice = LOCALNOTICE_ON;
    public static final boolean isDebug = false;

    public static String LOCAL_FILE_PATH;
    public static int sWidth = 0;
    public static int sHeight = 0;
    public static int screenWidth = 0;
    public static int screenHeight = 0;
    public static float screenDesity = 0;
    public static int bookNum = 3;

    public static Bitmap cropbitmap;
    public static String appFolderPath = Environment.getExternalStorageDirectory() + File.separator + "SAHK" + File.separator;
    public static String photoFolderPath = appFolderPath + "img";
    public static String audioFolderPath = appFolderPath + "audio";

    public static void showDialog_ok(Context context, String msg) {
        new AlertDialog.Builder(context)
                .setMessage(msg)
                .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        dialog.cancel();
                    }
                })
                .show();
    }

    public static int getImageId(Activity context, int sindex, int pindex) {
        String drawable = "drawable";
        if (lang == null || lang.length() == 0)
            lang = LOCALLANG_TW;
        if (lang.equals(LOCALLANG_CN))
            drawable = "drawable";
        return context.getResources().getIdentifier(getImageName(sindex, pindex), drawable, "com.sahk.sahk");
    }

    public static String getImageName(int sindex, int pindex) {
        boolean isC = pindex <= 0;
        String c = isC ? "c" : ("p" + pindex);
        String end = "t";
        if (lang == null || lang.length() == 0)
            lang = LOCALLANG_TW;
        if (lang.equals(LOCALLANG_CN))
            end = "s";
        String name = String.format("story%d_%s_%s", sindex, c, end);
        return name;
    }

    public static String getAudioName(int sindex, int pindex) {
        boolean isC = pindex <= 0;
        String end = "c";
        if (sound == null || sound.length() == 0)
            sound = LOCALSOUND_HK;
        if (sound.equals(LOCALSOUND_CN)) {
            end = "m";
        }
        String c = isC ? "c" : ("p" + pindex);
        String name = String.format("story%d_%s_%s.mp3", sindex, c, end);
        return name;
    }

    public static InputStream getFileImageStream(int sindex, int pindex) {
        try {
            FileInputStream fis = new FileInputStream(CommonUtility.LOCAL_FILE_PATH + "/" + CommonUtility.lang + "/images/" + getImageName(sindex, pindex) + ".png");
            return fis;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getFileAudioPath(int sindex, int pindex) {
        if (sound.equals("cn")) {
            return CommonUtility.LOCAL_FILE_PATH + "/cn/audios/" + getAudioName(sindex, pindex);
        }
        return CommonUtility.LOCAL_FILE_PATH + "/cntw/audios/" + getAudioName(sindex, pindex);
    }

    public static String getFirstImage(int index) {
        String end = "t_ct";
        String sf = "tc";
        if (lang == null || lang.length() == 0)
            lang = LOCALLANG_TW;
        if (lang.equals(LOCALLANG_CN)) {
            end = "s_sc";
            sf = "sc";
        }
        String name = String.format("%s/images/story%d_c_%s.png", sf, index, end);
        return name;
    }

    public static boolean isEmail(final String strEmail) {
        String strPattern = "^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?";

        Pattern p = Pattern.compile(strPattern);
        Matcher m = p.matcher(strEmail);
        return m.matches();
    }

    public static Boolean isNetAvailable(Context con) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager)
                    con.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo wifiInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            NetworkInfo mobileInfo =
                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            if (wifiInfo.isConnected() || mobileInfo.isConnected()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

}

