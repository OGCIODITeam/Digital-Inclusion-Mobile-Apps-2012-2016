package com.sahk.sahkp.data;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "customerstories")
public class CustomerStory extends Database {

    //	@DatabaseField(generatedId = true)
//	public Integer id;
    @DatabaseField
    public Integer bookindex;
    @DatabaseField
    public Integer pages;
    @DatabaseField
    public Integer category;
    @DatabaseField
    public String name;
}
