package com.sahk.sahkp.data;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.util.ArrayList;
import java.util.List;

@DatabaseTable(tableName = "bookmarks")
public class BookMark extends Database {

//	@DatabaseField(generatedId = true)
//	public Integer id;

    @DatabaseField
    public Integer storyid;
    @DatabaseField
    public Integer madeid;
    @DatabaseField
    public String customname;
    @DatabaseField
    public Integer custombookid;
    @DatabaseField
    public Integer category;
    @DatabaseField
    public String indexs = "";   // 1,2,3,5,

    public void addBookMark(int index) {
        if (index < 0)
            return;
        List<Integer> list = getBookMarks();
        if (!list.contains(index)) {
            list.add(index);
            StringBuilder stringBuilder = new StringBuilder();
            boolean isFirst = true;
            for (Integer intid : list) {
                if (!isFirst) {
                    stringBuilder.append(",");
                } else {
                    isFirst = false;
                }
                stringBuilder.append(intid);
            }
            indexs = stringBuilder.toString();
        }
    }

    public List<Integer> getBookMarks() {
        List<Integer> list = new ArrayList<Integer>();
        if (indexs != null && indexs.length() > 0) {
            String[] strid = indexs.split(",");
            for (String sid : strid) {
                if (sid != null && sid.length() > 0)
                    list.add(Integer.getInteger(sid));
            }
        }
        return list;
    }
}
