package com.sahk.sahkp.data;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.util.ArrayList;
import java.util.List;

@DatabaseTable(tableName = "stories")
public class Story extends Database {

//	@DatabaseField(generatedId = true)
//	public Integer id;

    @DatabaseField
    public String ratings;

    @DatabaseField
    public Integer rating;

    @DatabaseField
    public Integer count;

    @DatabaseField
    public Integer pages;

    @DatabaseField
    public Integer category;

    public void addBookMark(int index) {
        if (index <= 0)
            return;
        List<Integer> list = getBookMarks();
        list.add(index);
        StringBuilder stringBuilder = new StringBuilder();
        boolean isFirst = true;
        int r = 0;
        for (Integer intid : list) {
            r += intid;
            if (!isFirst) {
                stringBuilder.append(",");
            } else {
                isFirst = false;
            }
            stringBuilder.append(intid);
        }
        ratings = stringBuilder.toString();
        rating = r / list.size();
    }

    public List<Integer> getBookMarks() {
        List<Integer> list = new ArrayList<Integer>();
        if (ratings != null && ratings.length() > 0) {
            String[] strid = ratings.split(",");
            for (String sid : strid) {
                if (sid != null && sid.length() > 0)
                    list.add(Integer.valueOf(sid));
            }
        }
        return list;
    }
}
