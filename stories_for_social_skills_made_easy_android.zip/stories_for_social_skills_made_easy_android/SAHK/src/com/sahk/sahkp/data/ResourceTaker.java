package com.sahk.sahkp.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.DeleteBuilder;

/**
 * Created by Winkey on 23/8/13.
 */
public class ResourceTaker {

    public static final String SHARED_PREFERENCE_NAME = "SAHK";
    public static final String TEXT_LANG_PREF_NAME = "textlang";
    public static final String VOICE_LANG_PREF_NAME = "voicelang";
    public static final String FIRST_LAUNCH_PREF_NAME = "firstlaunch";

    public static final int[] pages = {8, 4, 8, 11, 4, 4, 5, 7, 6, 6,
            6, 9, 6, 7, 5, 8, 5, 4, 5, 5,
            4, 6, 5, 8, 4, 8, 5, 6, 6, 5,
            6, 5, 4, 5, 4, 7, 6, 9, 5, 5,
            6, 6, 5, 8, 5, 4, 7, 5, 7, 4,
            8, 5, 6, 5, 5, 4, 6, 9, 5, 6,
            5, 8, 5, 5, 6, 4, 5, 8, 9, 5,
            9, 4, 6, 5, 6, 5, 6, 6, 5, 5,
            6, 6, 7, 8, 6, 7, 5, 7, 6, 4,
            4, 6, 9, 7, 5, 9, 9, 8, 5, 9};

    private static final int[] category = {32, 27, 14, 17, 10};

    public static void initialData(Context mContext) {
        SharedPreferences sp = mContext.getSharedPreferences(SHARED_PREFERENCE_NAME, Context.MODE_PRIVATE);
        if (sp.getBoolean(FIRST_LAUNCH_PREF_NAME, true)) {
            try {
                DatabaseHelper helper = OpenHelperManager.getHelper(mContext, DatabaseHelper.class);
                Dao<Story, Object> dao = helper.getStoryDataDao();
                DeleteBuilder<Story, Object> delete = dao.deleteBuilder();

                int index = 0;
                int j = 0;
                for (int count : category) {
                    for (int i = 0; i < count; i++) {
                        try {
                            Story storyData = new Story();
                            storyData.count = 0;
                            storyData.category = j;
                            storyData.pages = pages[index];
                            storyData.rating = 0;
                            dao.create(storyData);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        index++;
                    }
                    j++;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            SharedPreferences.Editor edit = sp.edit();
            edit.putBoolean(FIRST_LAUNCH_PREF_NAME, false);
            edit.commit();
        }
    }
}
