package com.sahk.sahkp.data;

import android.content.Context;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.Where;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * Created by linlinet on 13-9-23.
 */
public class Database implements Serializable {

    @DatabaseField(generatedId = true)
    public Integer id;

    public static Dao<Database, Object> getDataDao(Context mContext, Class tClass) throws SQLException {
        DatabaseHelper helper = OpenHelperManager.getHelper(mContext, DatabaseHelper.class);
        return DaoManager.createDao(helper.getConnectionSource(), tClass);
    }

    public static List<Database> getDatas(Context mContext, Class tClass) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        return dao.queryForAll();
    }

    public static Database getDatasForId(Context mContext, Class tClass, Object value) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
//        dao.mapSelectStarRow()
        return dao.queryForId(value);
    }

    public static List<Database> getDatas(Context mContext, Class tClass, String key, Object value) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        return dao.queryForEq(key, value);
    }

    public static List<Database> getDatas(Context mContext, Class tClass, Map<String, Object> keyvaluse) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        return dao.queryForFieldValues(keyvaluse);
    }

    public static Database getDatasAtFirst(Context mContext, Class tClass, String key, Object value) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        QueryBuilder<Database, Object> query = dao.queryBuilder();
        Where<Database, Object> where_q = query.where();
        where_q.eq(key, value);
        return dao.queryForFirst(query.prepare());
    }

    public static void deleteData(Context mContext, Class tClass, Database database) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        dao.delete(database);
    }

    public static void deleteDatas(Context mContext, Class tClass, List<Database> database) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        dao.delete(database);
    }

    public static void deleteDatas(Context mContext, Class tClass) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        dao.delete(getDatas(mContext, tClass));
    }

    public static void deleteData(Context mContext, Class tClass, String key, Object value) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        DeleteBuilder<Database, Object> delete = dao.deleteBuilder();
        Where<Database, Object> where_d = delete.where();
        where_d.eq(key, value);
        dao.delete(delete.prepare());
    }



    public static void deleteDataById(Context mContext, Class tClass, Object value) throws SQLException{
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        dao.deleteById(value);
    }

    public static void deleteDataByIds(Context mContext, Class tClass, List<Object> value) throws SQLException{
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        dao.deleteIds(value);
    }

    public static void saveDatas(Context mContext, Class tClass, List<Database> datas) throws SQLException {
        for (Database data : datas) {
            saveData(mContext, tClass, data);
        }
    }

    public static void saveData(Context mContext, Class tClass, Database data) throws SQLException {
        Dao<Database, Object> dao = getDataDao(mContext, tClass);
        dao.createOrUpdate(data);
//        DeleteBuilder<Database, Object> delete = dao.deleteBuilder();
//        if (data.id != null && data.id > 0) {
//            QueryBuilder<Database, Object> query = dao.queryBuilder();
//            Where<Database, Object> where_q = query.where();
//            where_q.eq("id", data.id);
//            List<Database> datas = dao.query(query.prepare());
//            if (datas.size() > 0) {
//                DeleteBuilder<Database, Object> delete = dao.deleteBuilder();
//                Where<Database, Object> where_d = delete.where();
//                where_d.eq("id", data.id);
//                dao.delete(delete.prepare());
//            }
//        }
//        dao.create(data);
    }

}
