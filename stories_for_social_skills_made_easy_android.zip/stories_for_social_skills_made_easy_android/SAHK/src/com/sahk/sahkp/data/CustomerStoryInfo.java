package com.sahk.sahkp.data;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "customerstoryinfos")
public class CustomerStoryInfo extends Database {

//	@DatabaseField(generatedId = true)
//	public Integer id;

    @DatabaseField
    public Integer sindex;

    @DatabaseField
    public Integer bookindex;

    @DatabaseField
    public Integer pindex;

    @DatabaseField
    public String audio = "";

    @DatabaseField
    public String image = "";

    @DatabaseField
    public String content = "";


}
