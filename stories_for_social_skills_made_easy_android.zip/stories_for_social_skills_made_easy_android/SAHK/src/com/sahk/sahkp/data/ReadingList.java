package com.sahk.sahkp.data;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by casum on 13-9-26.
 */
@DatabaseTable(tableName = "readinglist")
public class ReadingList extends Database {

//	@DatabaseField(generatedId = true)
//	public Integer id;

    @DatabaseField
    public Integer studentid;

    @DatabaseField
    public String readinglistname;

    @DatabaseField
    public String books = "";   // 1,2,3,5,

    public void addReadingList(int index) {
        if (index < 0)
            return;
        List<Integer> list = getReadingList();
        if (!list.contains(index)) {
            list.add(index);
            StringBuilder stringBuilder = new StringBuilder();
            boolean isFirst = true;
            for (Integer intid : list) {
                if (!isFirst) {
                    stringBuilder.append(",");
                } else {
                    isFirst = false;
                }
                stringBuilder.append(intid);
            }
            books = stringBuilder.toString();
        }
    }

    public List<Integer> getReadingList() {
        List<Integer> list = new ArrayList<Integer>();
        if (books != null && books.length() > 0) {
            String[] strid = books.split(",");
            for (String sid : strid) {
                if (sid != null && sid.length() > 0)
                    list.add(Integer.getInteger(sid));
            }
        }
        return list;
    }
}
