package com.sahk.sahkp.data;

import java.sql.SQLException;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

public class DatabaseHelper extends OrmLiteSqliteOpenHelper {
	
	private static final String DATABASE_NAME = "sahk.db";
	private static final int DATABASE_VERSION = 3;

    private Dao<Story, Object> storyDao = null;
    private Dao<BookMark, Object> bookmarkDao;
    private Dao<Student, Object> studentsDao;
    private Dao<ReadingList, Object> readingListDao;

    public DatabaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	public boolean ClearAll(){
		ConnectionSource cs = getConnectionSource();
		try {
			TableUtils.clearTable(cs, Story.class);
            TableUtils.clearTable(cs, BookMark.class);
            TableUtils.clearTable(cs, CustomerStory.class);
            TableUtils.clearTable(cs, CustomerStoryInfo.class);
            TableUtils.clearTable(cs, Student.class);
            TableUtils.clearTable(cs, ReadingList.class);

            return true;
		} catch (SQLException e) {
			return false;
		}
	}

	@Override
	public void onCreate(SQLiteDatabase db, ConnectionSource cs) {
		try{
			TableUtils.createTable(cs, Story.class);
            TableUtils.createTable(cs, BookMark.class);
            TableUtils.createTable(cs, CustomerStory.class);
            TableUtils.createTable(cs, CustomerStoryInfo.class);
            TableUtils.createTable(cs, Student.class);
            TableUtils.createTable(cs, ReadingList.class);
        } catch (SQLException e) {
		}
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, ConnectionSource cs, int oldVersion, int newVersion) {
		try {
			TableUtils.dropTable(cs, Story.class, true);
            TableUtils.dropTable(cs, BookMark.class, true);
            TableUtils.dropTable(cs, CustomerStory.class, true);
            TableUtils.dropTable(cs, CustomerStoryInfo.class, true);
            TableUtils.dropTable(cs, Student.class, true);
            TableUtils.dropTable(cs, ReadingList.class, true);
			onCreate(db);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Dao<Story, Object> getStoryDataDao() throws SQLException {
		if (storyDao == null) {
            storyDao = DaoManager.createDao(getConnectionSource(), Story.class);
		}
		return storyDao;
	}

    public Dao<BookMark, Object> getBookMarkDataDao() throws SQLException {
        if (bookmarkDao == null) {
            bookmarkDao = DaoManager.createDao(getConnectionSource(), BookMark.class);
        }
        return bookmarkDao;
    }

    public Dao<Student, Object> getStudentDataDao() throws SQLException {
        if (studentsDao == null) {
            studentsDao = DaoManager.createDao(getConnectionSource(), Student.class);
        }
        return studentsDao;
    }

    public Dao<ReadingList, Object> getReadingListDataDao() throws SQLException {
        if (readingListDao == null) {
            readingListDao = DaoManager.createDao(getConnectionSource(), ReadingList.class);
        }
        return readingListDao;
    }

}
