package com.sahk.sahkp.data;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by casum on 13-9-23.
 */
@DatabaseTable(tableName = "students")
public class Student extends Database {

//    @DatabaseField(generatedId = true)
//    public Integer id;

    @DatabaseField
    public String familyname;

    @DatabaseField
    public String lastname;

    @DatabaseField
    public String school;

    @DatabaseField
    public String classname_s;

    @DatabaseField
    public String parents;

    @DatabaseField
    public String parentsemail;

    @DatabaseField
    public String teacher;

    @DatabaseField
    public String teacheremail;


}
