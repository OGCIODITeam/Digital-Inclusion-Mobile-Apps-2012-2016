package com.sahk.sahkp.story;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.androidquery.AQuery;
import com.m2.dragdrop.DragController;
import com.m2.dragdrop.DragLayer;
import com.m2.dragdrop.MyAbsoluteLayout;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.CustomViewPager;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.CustomerStory;
import com.sahk.sahkp.data.CustomerStoryInfo;
import com.sahk.sahkp.data.Database;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Winkey on 19/8/13.
 */
public class StoryEditFragment extends _AbstractMainFragment implements View.OnTouchListener {
    private static final int CROPIMAGE_CODE = 200;
    private String booktitle;
    private String[] contents;
    private View[] views;
    private DragController[] mDragControllers;
    private String[] Stroydetail;
    private String[] Stroycheckvalue;
    private int mStoryId;
    private int mBookid;
    private int mPageindex;
    private StoryFragment storyfragmen;
    private ImageView[] ivs;
    private Bitmap[] ivss;
    private Dialog dialog;
    private boolean isRecode;
    private CheckBox check;
    private boolean isFinish;
    private TextView txt_time;
    private MediaRecorder mRecorder;
    private MediaPlayer mPlayer;
    private String aduoivalue, aduoivalueloca;
    private boolean isStart;
    private TextView txt_msg;
    private boolean isRun;
    private int stime;
    private int etime;
    private Thread thread;
    private boolean isEdit;
    private LinearLayout layout_button;
    private CustomViewPager viewpager;
    private List<Database> infolist;
    private Map<Integer, CustomerStoryInfo> map = new HashMap<Integer, CustomerStoryInfo>();
    private int curIndex;
    private Map<Integer, Bitmap> bitmapMap = new HashMap<Integer, Bitmap>();
    private boolean flag1[];
    private boolean flag2 = false;


    public StoryEditFragment(StoryFragment storfragm, int storyId, int bookid, int pageindex, String bookTitle) {
        storyfragmen = storfragm;
        mStoryId = storyId;
        mBookid = bookid;
        curIndex = mPageindex = pageindex;
        this.booktitle = bookTitle;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        View v = inflater.inflate(R.layout.story_content_edit, container, false);
        aq = new AQuery(v);

        Stroydetail = getResources().getStringArray(strids[mStoryId - 1]);
        Stroycheckvalue = new String[Stroydetail.length];

        try {
            if (mBookid > -1)
                infolist = (CustomerStoryInfo.getDatas(context, CustomerStoryInfo.class, "bookindex", mBookid));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        viewpager = (CustomViewPager) aq.id(R.id.viewpager).getView();
        MyPager pageviewAdapter = new MyPager();
        viewpager.setAdapter(pageviewAdapter);
        viewpager.setOnPageChangeListener(pageviewAdapter);
        viewpager.setCurrentItem(mPageindex);
        CommonUtility.cropbitmap = null;
        return v;
    }

    public void toBack() {
        super.toBack();
        try {
            for (View v : views) {
                AQuery Aq = new AQuery(v);
                ImageView iv = Aq.id(R.id.stroyiamge).getImageView();
                if (iv != null) {
                    iv.setImageBitmap(null);
                }
            }
            Set<Map.Entry<Integer, Bitmap>> set = bitmapMap.entrySet();
            for (Map.Entry<Integer, Bitmap> entry : set) {
                entry.getValue().recycle();
            }
            bitmapMap.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setView(AQuery ap, int id, int pos) {
        try {
            Bitmap bmpCache = bitmapMap.get(pos);
            if (bmpCache != null && !flag1[pos]) {
                ap.id(R.id.image).image(bmpCache);
                return;
            }
            Bitmap bmp = BitmapFactory.decodeStream(CommonUtility.getFileImageStream(mStoryId, pos));
            if (bmp == null) {
                Toast.makeText(context, getString(R.string.accessory_bag), Toast.LENGTH_LONG).show();
                return;
            }
            int picW = (int) (CommonUtility.screenDesity * bmp.getWidth() + 0.5);
            int picH = (int) (CommonUtility.screenDesity * bmp.getHeight() + 0.5);
            Bitmap bmp1 = Bitmap.createScaledBitmap(bmp, picW, picH, true);
            int w = bmp1.getWidth();
            int h = bmp1.getHeight();
            if (w >= CommonUtility.screenWidth) {
                int offset = (w - CommonUtility.screenWidth);
                Bitmap newBmp = Bitmap.createBitmap(bmp1, offset, 0, CommonUtility.screenWidth, h);
                ap.id(R.id.image).image(newBmp);
                bitmapMap.put(pos, newBmp);
                if (bmp != null)
                    bmp.recycle();
            } else {
                ap.id(R.id.image).image(bmp1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBack() {
        super.onBack();
        if (storyfragmen != null) {
            storyfragmen.Setviewpageindex(curIndex, mBookid);
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.btn_bottom_menu:
                if (aq.id(R.id.layout_bottom_menu).getView().getVisibility() == View.VISIBLE)
                    aq.id(R.id.layout_bottom_menu).visibility(View.GONE);
                else
                    aq.id(R.id.layout_bottom_menu).visibility(View.VISIBLE);
                break;
            case R.id.btn_edit:
                mCallback.onBack();
                break;
            case R.id.btn_camera:
                ivs[curIndex] = null;
                choseImage();
                break;
            case R.id.btn_begin_record:
                showDialogSimple();
                break;
            case R.id.btn_save:
                save();
                break;
            case R.id.btn_close:
                getCurrentInfo(curIndex).audio = null;
            case R.id.btn_ok:
                dialog.cancel();
            case R.id.btn_redo:
                stime = etime = 0;
                check.setChecked(false);
                isStart = isFinish = isRecode = false;
                if (mPlayer != null) {
                    mPlayer.release();
                    mPlayer = null;
                }
                check.setBackgroundResource(R.drawable.record);
                txt_msg.setText(R.string.story_beginrecord);
                break;
            case R.id.btn_cancel: {
                if (flag1[curIndex]) {
                    new EasyDialog(context, R.style.CustomDialog, R.layout.mydialog1, R.id.dialog1_confirm, R.id.dialog1_cancel);
                }
            }
            break;
            case R.id.btn_okcover:
                if (flag2) {
                    new EasyDialog(context, R.style.CustomDialog, R.layout.mydialog2, R.id.dialog2_confirm, R.id.dialog2_cancel);
                }
                break;
        }
    }

    private void showDialogSimple() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            stopPlaying();
        }
        if (dialog == null) {
            View view = inflater.inflate(R.layout.begin_record, null);
            dialog = new Dialog(context, R.style.dialog);
            dialog.setContentView(view);
            AQuery aq = new AQuery(view);
            aq.id(R.id.btn_ok).clicked(this);
            aq.id(R.id.btn_close).clicked(this);
            aq.id(R.id.btn_redo).clicked(this);
            txt_msg = aq.id(R.id.txt_msg).getTextView();
            txt_time = aq.id(R.id.txt_time).getTextView();
            check = aq.id(R.id.btn_recode).getCheckBox();
            layout_button = (LinearLayout) aq.id(R.id.layout_button).getView();
            check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if (!isRecode) {
                        if (b) {
                            isRecode = true;
                            check.setBackgroundResource(R.drawable.pause);
                            startRecording();
                        }
                    } else {
                        check.setBackgroundResource(!b ? R.drawable.play : R.drawable.pause);
                        if (!isFinish) {
                            isFinish = true;
                            stopRecording();
                            layout_button.setVisibility(View.VISIBLE);
                        } else {
                            if (b)
                                startPlaying();
                            else
                                stopPlaying();
                        }
                    }
                }
            });
        }
        layout_button.setVisibility(View.INVISIBLE);
        txt_time.setText("");
        dialog.show();
    }

    private void startRecording() {
        try {
            String name = "/audiorecord_story_" + mStoryId + "_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".amr";
            File dir = new File(CommonUtility.audioFolderPath);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            CustomerStoryInfo info = getCurrentInfo(curIndex);
            info.audio = CommonUtility.audioFolderPath + name;
            if (mRecorder == null) {
                mRecorder = new MediaRecorder();
                mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                mRecorder.setOutputFormat(MediaRecorder.OutputFormat.RAW_AMR);
                mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            }
            mRecorder.setOutputFile(info.audio);

            mRecorder.prepare();
            mRecorder.start();
            isRun = true;
            setTimeHanlder(true);
            txt_msg.setText(R.string.story_record);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private CustomerStoryInfo getCurrentInfo(int index) {
        CustomerStoryInfo info = null;
        try {
            if (!map.containsKey(index)) {
                if (infolist != null)
                    for (Database cinfo : infolist) {
                        CustomerStoryInfo storyInfo = (CustomerStoryInfo) cinfo;
                        if (storyInfo.pindex == index)
                            info = storyInfo;
                    }
                if (info == null)
                    info = new CustomerStoryInfo();
                map.put(index, info);
            } else {
                info = map.get(index);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }

    private void setTimeHanlder(final boolean isRecord) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isRun)
                    return;
                setTimeText();
                stime++;
                if (!isRecord) {
                    if (stime > etime) {
                        stime = 0;
                        isRun = false;
                        check.setChecked(false);
                        return;
                    }
                }
                setTimeHanlder(isRecord);
            }
        }, 1000);
    }

    private void setTimeText() {
        int h = stime / 3600;
        int m = (stime % 3600) / 60;
        int s = stime % 60;
        String time = String.format("%02d", m) + ":" + String.format("%02d", s);
        if (h > 0)
            time = String.format("%02d", h) + ":" + time;
        txt_time.setText(time);
    }

    private void stopRecording() {
        try {
            if (thread != null) {
                thread = null;
            }
            isRun = false;
            etime = stime;
            if (mRecorder != null) {
                mRecorder.stop();
                mRecorder.release();
                mRecorder = null;
            }
            txt_msg.setText(R.string.story_play);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startPlaying() {
        try {
            if (mPlayer == null)
                mPlayer = new MediaPlayer();

            if (!isStart) {
                mPlayer.setDataSource(getCurrentInfo(curIndex).audio);
                mPlayer.prepare();
                isStart = true;
                stime = 0;
            }
            isRun = true;
            setTimeHanlder(false);
            mPlayer.start();
            txt_msg.setText(R.string.story_playing);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startplayDefult() {
        try {
            mPlayer = new MediaPlayer();

            if (aduoivalue != null) {
                mPlayer.setDataSource(aduoivalue);
                mPlayer.prepare();
                mPlayer.start();
            } else {
                mPlayer.reset();
                AssetFileDescriptor afd = getActivity().getAssets().openFd(aduoivalueloca);
                mPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                mPlayer.prepare();
                mPlayer.start();
                mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        if (null != mp) {
                            mp.stop();
                            mp.release();
                        }
                        mPlayer = null;
                    }
                });
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //停止播放
    private void stopPlaying() {
        if (thread != null) {
            thread = null;
        }
        isRun = false;
        if (mPlayer != null) {
            mPlayer.pause();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isRun = false;
        if (mRecorder != null) {
            mRecorder.release();
            mRecorder = null;
        }
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    private void save() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        save1();
                    }
                });

            }
        }).start();
    }

    private void save1() {
        try {
            isEdit = makeImage();
            if (!isEdit) {
                for (CustomerStoryInfo info : map.values()) {
                    if (info.audio != null && info.audio.length() > 0) {
                        isEdit = true;
                        break;
                    }
                }
            }
            boolean ischange = getcontent();
            if (!isEdit) {
                isEdit = ischange;
            }

            if (isEdit) {
                try {
                    if (mBookid == -1) {
                        CustomerStory customerStory = new CustomerStory();
                        customerStory.bookindex = mStoryId;
                        if (curIndex == 0)
                            customerStory.name = booktitle;
                        CustomerStory.saveData(context, CustomerStory.class, customerStory);
                        mBookid = customerStory.id;
                    } else {
                        CustomerStory customerStory = (CustomerStory) CustomerStory.getDatasForId(context, CustomerStory.class, mBookid);
                        if (curIndex == 0)
                            customerStory.name = booktitle;
                        CustomerStory.saveData(context, CustomerStory.class, customerStory);
                    }
                    for (Integer index : map.keySet()) {
                        CustomerStoryInfo info = map.get(index);
                        info.pindex = index;
                        info.bookindex = mBookid;
                        info.sindex = mStoryId;
                        try {
                            CustomerStoryInfo.saveData(context, CustomerStoryInfo.class, info);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    mCallback.onBack();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean getcontent() {
        boolean isEdit = false;
        try {
            for (int i = 0; i < Stroydetail.length; i++) {
                View view = views[i];
                if (view == null)
                    continue;
                AQuery Aq = new AQuery(view);
                String changevalue = Aq.id(R.id.edit_content).getEditText().getText().toString();
                String changevaluetitle = Aq.id(R.id.edit_title).getEditText().getText().toString();

                if (i == 0 && !changevaluetitle.equals(booktitle)) {
                    booktitle = changevaluetitle;
                    isEdit = true;
                }

                String checkvalue = Stroycheckvalue[i].toString();
                if (0 != i && !changevalue.equals(checkvalue)) {
                    getCurrentInfo(i).content = changevalue;
                    isEdit = true;
                } else {
                    getCurrentInfo(i).content = checkvalue;
                }
                Aq.recycle(view);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isEdit;
    }

    private boolean makeImage() {
        boolean isEdit = false;
        try {
            for (int i = 0; i < Stroydetail.length; i++) {
                if (ivss[i] == null)
                    continue;
                View view = views[i];
                AQuery Aq = new AQuery(view);
                ImageView imgview = Aq.id(R.id.image).getImageView();
                BitmapDrawable drawable = (BitmapDrawable) imgview.getDrawable();
                Bitmap firstBitmap = new WeakReference<Bitmap>(drawable.getBitmap()).get();
                int lengthflag = (imgview.getHeight() - firstBitmap.getHeight()) / 2;
                Bitmap bitmap = Bitmap.createBitmap(firstBitmap.getWidth(), firstBitmap.getHeight(), firstBitmap.getConfig());
                Canvas canvas = new Canvas(bitmap);
                canvas.drawBitmap(firstBitmap, new Matrix(), null);
//                canvas.drawBitmap(ivss[i], ivs[i].getLeft(), ivs[i].getTop() - lengthflag - imgview.getTop(), null);
                canvas.drawBitmap(ivss[i], ivs[i].getLeft(), ivs[i].getTop(), null);

                File dir = new File(CommonUtility.photoFolderPath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + i + ".jpg";
                String imgPath = CommonUtility.photoFolderPath + File.separator + timeStamp;
                FileOutputStream out = null;
                try {
                    out = new FileOutputStream(imgPath);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                    getCurrentInfo(i).image = imgPath;
                    isEdit = true;
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (out != null) {
                        out.close();
                        out = null;
                    }
                }
                Aq.recycle(view);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isEdit;
    }

    private void choseImage() {
        Intent innerIntent = new Intent(Intent.ACTION_GET_CONTENT);
        String IMAGE_UNSPECIFIED = "image/*";
        innerIntent.setType(IMAGE_UNSPECIFIED);
        Intent wrapperIntent = Intent.createChooser(innerIntent, null);
        context.startActivityForResult(wrapperIntent, CommonUtility.CHOOSE_IMAGE_ACTIVITY_REQUEST_CODE);
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CommonUtility.CHOOSE_IMAGE_ACTIVITY_REQUEST_CODE:
                if (resultCode == context.RESULT_OK) {
                    if (data != null) {
                        try {
                            Uri fileUri = data.getData();
                            String imagePath = getImagePath2(fileUri);
                            if (imagePath != null && imagePath.length() > 0 && !imagePath.startsWith("http")) {
                                Intent intent = new Intent(context, AddImageActivity.class);
                                intent.putExtra("imagePath", imagePath);
                                context.startActivityForResult(intent, CROPIMAGE_CODE);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;
            case CROPIMAGE_CODE:
                if (resultCode == context.RESULT_OK) {
                    if (CommonUtility.cropbitmap != null) {
                        viewpager.setPagingEnabled(false);

                        final View view = views[curIndex];
                        AQuery Aq = new AQuery(view);
                        final DragLayer mDragLayer = (DragLayer) Aq.id(R.id.drag_layer2).visible().getView();
                        if (ivs[curIndex] == null) {
                            int width = CommonUtility.cropbitmap.getWidth();
                            int height = CommonUtility.cropbitmap.getHeight();

                            ivs[curIndex] = new ImageView(context);
                            ivs[curIndex].setLayoutParams(
                                    new MyAbsoluteLayout.LayoutParams(
                                            width, height, CommonUtility.screenWidth / 2 - width / 2, CommonUtility.sHeight / 2 - height / 2)
                            );
                            mDragLayer.removeAllViews();
                            mDragLayer.addView(ivs[curIndex]);
                        }
                        ivs[curIndex].setOnTouchListener(this);
                        ivss[curIndex] = CommonUtility.cropbitmap;
                        ivs[curIndex].setImageBitmap(ivss[curIndex]);
                        flag1[curIndex] = true;
                        flag2 = true;
                    }
                }
                break;
        }
    }

    private String getImagePath2(Uri uri) {
        String filePath = "";
        String[] projection = {MediaStore.MediaColumns.DATA};
        Cursor cursor1 = context.managedQuery(uri, projection, null, null, null);
        if (cursor1 != null) {
            int columnIndex = cursor1.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            cursor1.moveToFirst();
            filePath = cursor1.getString(columnIndex);
            try {
                if (Integer.parseInt(Build.VERSION.SDK) < 14) {
                    cursor1.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return filePath;
    }

    @Override
    public boolean onTouch(View v, MotionEvent ev) {
        boolean handledHere = false;
        final int action = ev.getAction();
        if (action == MotionEvent.ACTION_DOWN) {
            handledHere = startDrag(v);
        }
        return handledHere;
    }

    public boolean startDrag(View v) {
        Object dragInfo = v;
        View view = views[curIndex];
        AQuery Aq = new AQuery(view);
        DragLayer mDragLayer = (DragLayer) Aq.id(R.id.drag_layer2).visible().getView();
        mDragControllers[curIndex].startDrag(v, mDragLayer, dragInfo, DragController.DRAG_ACTION_MOVE);
        Aq.recycle(v);
        return true;
    }

    private class MyPager extends PagerAdapter implements ViewPager.OnPageChangeListener {
        private String imagevalue, conetvalue;
        private CustomerStoryInfo custinfo;
        private AQuery Aq;
        private boolean flag = false;

        public MyPager() {
            views = new View[Stroydetail.length];
            mDragControllers = new DragController[Stroydetail.length];
            ivs = new ImageView[Stroydetail.length];
            ivss = new Bitmap[Stroydetail.length];
            contents = new String[Stroydetail.length];
            flag1 = new boolean[Stroydetail.length];
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            ((ViewPager) container).removeView((View) object);
        }

        @Override
        public int getCount() {
            return Stroydetail.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object o) {
            return view == o;
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int pos) {
            View view = null;
            try {
                if (views[pos] == null) {
                    getvalueforpageid(pos);
                    view = inflater.inflate(R.layout.story_content_edit_item, null);
                    Aq = new AQuery(view);
                    DragLayer mDragLayer = (DragLayer) Aq.id(R.id.drag_layer2).getView();
                    DragController mDragController = new DragController(context);
                    mDragControllers[pos] = mDragController;
                    mDragLayer.setDragController(mDragController);
                    mDragController.addDropTarget(mDragLayer);
                    if (mBookid > -1) {
                        if (imagevalue != null) {
                            flag1[pos] = true;
                            File file = aq.getCachedFile(imagevalue);
                            Aq.id(R.id.image).image(file, 800);
                        }
                    }
                    if (imagevalue == null) {
                        try {
                            flag1[pos] = false;
                            setView(Aq, CommonUtility.getImageId(context, mStoryId, pos), pos);
                        } catch (OutOfMemoryError e) {
                            e.printStackTrace();
                        }
                    }

                    EditText edit_content = Aq.id(R.id.edit_content).getEditText();
                    if (pos == 0) {
                        Aq.id(R.id.textviewvalue).text(conetvalue).textSize(30);
                        if (!"".equals(booktitle)) {
                            Aq.id(R.id.edit_title).text(booktitle);
                        }
                    } else {
                        Aq.id(R.id.ll_edit_title).visibility(View.GONE);
                        edit_content.setText(conetvalue);
                    }
                    contents[pos] = conetvalue;
                    Stroycheckvalue[pos] = conetvalue;
                    container.addView(view);
                    views[pos] = view;
                    return view;
                } else {
                    container.addView(views[pos]);
                    return views[pos];
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return view;
        }

        @Override
        public void onPageScrolled(int i, float v, int i2) {

        }

        @Override
        public void onPageSelected(int i) {
            if (mPlayer != null && mPlayer.isPlaying()) {
                stopPlaying();
            }

            curIndex = i;
            CommonUtility.cropbitmap = null;
            getvalueforpageid(curIndex);
            if (flag)
                startplayDefult();
            flag = true;
        }

        @Override
        public void onPageScrollStateChanged(int i) {

        }

        private void getvalueforpageid(int post) {
            imagevalue = null;
            conetvalue = null;
            aduoivalue = null;
            custinfo = null;
            if (infolist != null) {
                for (Database info : infolist) {
                    custinfo = (CustomerStoryInfo) info;
                    if (custinfo.pindex == post) {
                        imagevalue = custinfo.image;
                        conetvalue = custinfo.content;
                        aduoivalue = custinfo.audio;
                        break;
                    }
                }
            }
            if (imagevalue == null || imagevalue.equals("")) {
                imagevalue = null;
            }
            if (conetvalue == null)
                conetvalue = Stroydetail[post];

            if (aduoivalue == null || aduoivalue.equals("")) {
                aduoivalue = getCurrentInfo(post).audio;
                if (aduoivalue == null || aduoivalue.equals("")) {
                    aduoivalue = null;
                    aduoivalueloca = CommonUtility.getAudioName(mStoryId, post);
                }
            }
        }
    }

    public class EasyDialog extends Dialog implements android.view.View.OnClickListener {
        public EasyDialog(Context context, int style, int layout, int confirm, int cancel) {
            super(context, style);
            Window window = getWindow();
            window.setContentView(layout);
            Button confirm1 = (Button) window.findViewById(confirm);
            Button cancel1 = (Button) window.findViewById(cancel);
            confirm1.setOnClickListener(this);
            cancel1.setOnClickListener(this);
            show();
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.dialog1_confirm:
                    dismiss();
                    if (ivs[curIndex] != null) {
                        ivs[curIndex].setImageBitmap(null);
                    }
                    View view = views[curIndex];
                    AQuery Aqq = new AQuery(view);
                    setView(Aqq, CommonUtility.getImageId(context, mStoryId, curIndex), curIndex);
                    File file = new File(getCurrentInfo(curIndex).image);
                    file.delete();
                    flag1[curIndex] = false;
                    flag2 = false;
                    try {
                        CustomerStoryInfo.deleteData(context, CustomerStoryInfo.class, "image", getCurrentInfo(curIndex).image);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.dialog1_cancel:
                    dismiss();
                    break;
                case R.id.dialog2_confirm:
                    flag2 = false;
                    dismiss();
                    if (ivs[curIndex] != null) {
                        ivs[curIndex].setOnTouchListener(null);
                        viewpager.setPagingEnabled(true);
                    }
                    break;
                case R.id.dialog2_cancel:
                    dismiss();
                    break;
            }
        }
    }
}
