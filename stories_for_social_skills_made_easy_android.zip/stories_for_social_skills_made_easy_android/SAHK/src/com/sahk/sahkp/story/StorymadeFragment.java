package com.sahk.sahkp.story;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.CustomerStory;
import com.sahk.sahkp.data.Database;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.util.List;

/**
 * User: user
 * Date: 13-9-27
 * Time: 上午11:57
 * To change this template use File | Settings | File Templates.
 */
public class StorymadeFragment extends _AbstractMainFragment {

    List<Database> cuslist = null;
    private RelateslistAdapter pelatesadp;
    private GridView gridview;

    public void StorymadeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        View v = inflater.inflate(R.layout.story_made, container, false);
        aq = new AQuery(v);
        init();
        return v;
    }

    private void init() {
        cuslist = getCustomerList();
        pelatesadp = new RelateslistAdapter();
        gridview = (GridView) aq.id(R.id.gvcostumer).getView();
        gridview.setAdapter(pelatesadp);
        gridview.setOnItemClickListener(pelatesadp);
    }

    private List<Database> getCustomerList() {
        List<Database> list = null;
        try {
            list = Database.getDatas(context, CustomerStory.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    class RelateslistAdapter extends BaseAdapter implements AdapterView.OnItemClickListener {

        @Override
        public int getCount() {
            int size = cuslist.size();
            if (size == 0)
                return 0;
            int row = size / 3;
            if (size % 3 != 0)
                row++;
            int count = row * 3;
            return count;
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = inflater.inflate(R.layout.customer_bookitem, null);
            }
            AQuery Aq = new AQuery(view);
            if (i >= cuslist.size()) {
                Aq.id(R.id.ll_custom_title).invisible();
                Aq.id(R.id.img_book).invisible();
                return view;
            } else {
                Aq.id(R.id.img_book).visible();
                Aq.id(R.id.ll_custom_title).visible();
            }
            CustomerStory cust = (CustomerStory) cuslist.get(i);
            String name = cust.name;
            Aq.id(R.id.tv_custom_name).text(name);
            String imgname = CommonUtility.getFirstImage(cust.bookindex);
            try {
                InputStream imgStream = getActivity().getAssets().open(imgname);
                Drawable drawable = new WeakReference<Drawable>(Drawable.createFromStream(imgStream, null)).get();
                Aq.id(R.id.img_book).image(drawable);
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return view;
        }

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            if (i >= cuslist.size()) {
                return;
            }
            CustomerStory cust = (CustomerStory) cuslist.get(i);
            mCallback.addContent(new StoryFragment(cust.bookindex, 0, cust.id, 1, cust.name));
        }
    }
}
