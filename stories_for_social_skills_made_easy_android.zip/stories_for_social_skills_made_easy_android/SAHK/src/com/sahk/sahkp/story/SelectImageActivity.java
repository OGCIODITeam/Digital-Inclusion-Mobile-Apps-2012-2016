package com.sahk.sahkp.story;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.sahk.sahkp.CommonUtility;

/**
 * Created by linlinet on 13-10-8.
 */
public class SelectImageActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        choseImage();
    }

    private void choseImage() {
        Intent innerIntent = new Intent(Intent.ACTION_GET_CONTENT);
        String IMAGE_UNSPECIFIED = "image/*";
        innerIntent.setType(IMAGE_UNSPECIFIED);
        Intent wrapperIntent = Intent.createChooser(innerIntent, null);
        startActivityForResult(wrapperIntent, CommonUtility.CHOOSE_IMAGE_ACTIVITY_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CommonUtility.CHOOSE_IMAGE_ACTIVITY_REQUEST_CODE:
                setResult(RESULT_OK, data);
                finish();
                break;
        }
    }
}
