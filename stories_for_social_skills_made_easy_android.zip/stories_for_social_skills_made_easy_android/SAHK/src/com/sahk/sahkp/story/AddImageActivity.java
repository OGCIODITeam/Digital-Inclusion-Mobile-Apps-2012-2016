package com.sahk.sahkp.story;

import android.content.Context;
import android.content.Intent;
import android.gesture.GestureOverlayView;
import android.gesture.GestureStroke;
import android.graphics.*;
import android.media.ExifInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import com.actionbarsherlock.app.SherlockActivity;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

/**
 * Created by linlinet on 13-9-24.
 */
public class AddImageActivity extends SherlockActivity implements View.OnClickListener {

    private AQuery aq;
    private String imagePath;

    DrawingView dv;

    private Bitmap bitmap;
    private Bitmap bitmap2;
    private ImageView imageView;
    private GestureOverlayView gestureOverlayView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.story_add_image);
        aq = new AQuery(this);
        imagePath = getIntent().getStringExtra("imagePath");
        imageView = aq.id(R.id.image).getImageView();
        CommonUtility.cropbitmap = null;

        FileInputStream in = null;
        try {
            in = new FileInputStream(imagePath);

            ExifInterface exif = new ExifInterface(imagePath);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            int angle = 0;
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) {
                angle = 90;
            } else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) {
                angle = 180;
            } else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                angle = 270;
            }
            Matrix mat = new Matrix();
            mat.postRotate(angle);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            options.inSampleSize = 1;
            BitmapFactory.decodeStream(in, null, options);
            int size = getSampleSize(options.outWidth, options.outHeight);
            options.inSampleSize = size;
            in = new FileInputStream(imagePath);
            BitmapFactory.decodeStream(in, null, options);
            int w = options.outWidth;
            int h = options.outHeight;
            Bitmap bmp;
            if (w > CommonUtility.screenWidth || h > CommonUtility.screenHeight) {
                options.inSampleSize = 2 * size;
                options.inJustDecodeBounds = false;
                in = new FileInputStream(imagePath);
                bmp = BitmapFactory.decodeStream(in, null, options);
                w = bmp.getWidth();
                h = bmp.getHeight();
            } else {
                options.inJustDecodeBounds = false;
                in = new FileInputStream(imagePath);
                bmp = BitmapFactory.decodeStream(in, null, options);
            }
            bitmap = Bitmap.createBitmap(bmp, 0, 0, w, h, mat, true);
            imageView.setImageBitmap(bitmap);

            gestureOverlayView = (GestureOverlayView) findViewById(R.id.gestures_overlay03);
            gestureOverlayView.addOnGestureListener(new GesturesProcessor());
            dv = new DrawingView(this);
        } catch (Exception e) {
            e.printStackTrace();
        } catch (OutOfMemoryError oom) {
            oom.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int getSampleSize(int outWidth, int outHeight) {
        int size = 10;
        if (CommonUtility.sWidth != 0 && CommonUtility.sHeight != 0) {
            size = outWidth / CommonUtility.sWidth >
                    outHeight / CommonUtility.sHeight ?
                    outWidth / CommonUtility.sWidth :
                    outHeight / CommonUtility.sHeight;
        }
        return size;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_redo:
                gestureOverlayView.clear(false);
                gPath = null;
                bitmap2 = null;
                break;
            case R.id.btn_back:
                this.finish();
                break;
            case R.id.btn_ok:
                if (bitmap2 == null)
                    return;
                Intent intent = new Intent();
                CommonUtility.cropbitmap = bitmap2;
                setResult(RESULT_OK, intent);
                finish();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        imageView.setImageBitmap(null);
        if (bitmap != null)
            bitmap.recycle();
    }

    private class DrawingView extends View {

        String TAG = "DrawingView";

        public DrawingView(Context context) {
            super(context);
        }

        @Override
        public void onDraw(Canvas canvas) {
            Paint paint = new Paint();
            if (AddImageActivity.gPath != null) {
                bitmap2 = getclip();
                canvas.drawBitmap(getclip(), 0, 0, paint);// originally x and y is o
            } else {
            }
        }

        public Bitmap getclip() {
            Bitmap bmp = null;
            try {
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();

                Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(output);

                final Paint paint = new Paint();
                final Rect rect = new Rect(0, 0, width, height);

                paint.setColor(Color.BLUE);
                paint.setStyle(Paint.Style.FILL);
                paint.setAntiAlias(true);

                canvas.drawPath(AddImageActivity.gPath, paint);// 绘制路径
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                canvas.drawBitmap(bitmap, rect, rect, paint);
                int x = (int) getMinX();
                int y = (int) getMinY();
                int xM = (int) (getMaxX());
                int yM = (int) (getMaxY());
                if (xM > width)
                    xM = width;
                if (yM > height)
                    yM = height;
                if (x <= 0)
                    x = 0;
                if (y <= 0)
                    y = 0;
                int w1 = xM - x;
                int h1 = yM - y;
                if (w1 <= 0)
                    return null;
                if (h1 <= 0)
                    return null;
                bmp = Bitmap.createBitmap(output, x, y, w1, h1);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bmp;
        }
    }

    private float getMinX() {
        float k = points[0];
        for (int i = 0; i < points.length; i += 2) {
            if (k > points[i])
                k = points[i];
        }
        return k;
    }

    private float getMinY() {
        float k = points[1];
        for (int i = 1; i < points.length; i += 2) {
            if (k > points[i])
                k = points[i];
        }
        return k;
    }

    private float getMaxX() {
        float k = points[0];
        for (int i = 0; i < points.length; i += 2) {
            if (k < points[i])
                k = points[i];
        }
        return k;
    }

    private float getMaxY() {
        float k = points[1];
        for (int i = 1; i < points.length; i += 2) {
            if (k < points[i])
                k = points[i];
        }
        return k;
    }

    static float[] points;
    static Path gPath;

    private class GesturesProcessor implements GestureOverlayView.OnGestureListener {

        public void onGestureStarted(GestureOverlayView overlay, MotionEvent event) {
        }

        public void onGesture(GestureOverlayView overlay, MotionEvent event) {
        }

        public void onGestureEnded(GestureOverlayView overlay, MotionEvent event) {
            gPath = overlay.getGesture().toPath();
            List<GestureStroke> list = overlay.getGesture().getStrokes();
            points = list.get(0).points;
            dv.setBackgroundColor(Color.TRANSPARENT);
            bitmap2 = dv.getclip();
        }

        public void onGestureCancelled(GestureOverlayView overlay, MotionEvent event) {
        }
    }

}
