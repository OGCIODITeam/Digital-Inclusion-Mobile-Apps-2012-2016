package com.sahk.sahkp.story;

import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.*;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.ExchangeThread;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.BookMark;
import com.sahk.sahkp.data.CustomerStoryInfo;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.Story;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by Winkey on 19/8/13.
 */
public class StoryFragment extends _AbstractMainFragment {

    private static int category = 0;
    private static int mStoryId;
    private static int mBookindex;
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                deviceList.add(device);
                listadpent.notifyDataSetChanged();
            }
        }
    };
    public int madeid;
    Boolean pauseflag = false;
    List<Database> infolist = null;
    ViewPager vpContent;
    String[] Stroydetail;
    int count = 0;
    int lastValue = 0;
    private View[] views;
    private CustomerStoryInfo custinfo;
    private ListAdapter listadpent;
    private int choiceindex = -1;
    private String imagevalue, aduoivalue, conetvalue;
    private boolean isstopaudio = false;
    private MediaPlayer mPlayer;
    private BluetoothAdapter mBluetoothAdapter;
    private List<BluetoothDevice> deviceList = new ArrayList<BluetoothDevice>();
    private Dialog dialog;
    private ExchangeThread exchangeThread;
    private ConnectThread connectThread;
    private Story story;
    private String aduoivalueloca;
    private PageviewAdapter pageadpet;
    private Map<Integer, Bitmap> bitmapMap = new HashMap<Integer, Bitmap>();
    private boolean isMenuOn = false;
    private String bookTitle = "";

    public StoryFragment(int storyId, int category, int bookindex, int madeid, String bookTitle) {
        mStoryId = storyId;
        this.category = category;
        this.mBookindex = bookindex;
        this.madeid = madeid;
        this.bookTitle = bookTitle;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        View view = inflater.inflate(R.layout.story_content, container, false);
        aq = new AQuery(view);
        init();
        return view;
    }

    private void init() {
        if (Stroydetail == null) {
            try {
                Stroydetail = context.getResources().getStringArray(strids[mStoryId - 1]);
            } catch (ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            }
        } else {
            if (isMenuOn) {
                aq.id(R.id.textpage).text(1 + "/" + Stroydetail.length);
            }
        }
        showView(madeid);
        if (madeid != 1) {
            try {
                story = (Story) Story.getDatasAtFirst(context, Story.class, "id", mStoryId);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (isMenuOn) {
                aq.id(R.id.texteye).text(story.count + "");
                aq.id(R.id.eyeimage).getView().setContentDescription(getResources().getString(R.string.btn_readcount) + (count) + "");
            }
            count = story.count;
            story.count++;
            try {
                Story.saveData(context, Story.class, story);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            aq.id(R.id.texteye).text((count + 1) + "");
            aq.id(R.id.eyeimage).getView().setContentDescription(getResources().getString(R.string.btn_readcount) + (count + 1) + "");
        } else {
            try {
                infolist = (CustomerStoryInfo.getDatas(context, CustomerStoryInfo.class, "bookindex", mBookindex));
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        getvalueforpageid(0);
        startPlaying();

        if (vpContent == null) {
            vpContent = (ViewPager) aq.id(R.id.detialviewpage).getView();
            pageadpet = new PageviewAdapter();
            vpContent.setAdapter(pageadpet);
            vpContent.setOnPageChangeListener(pageadpet);
        }
        vpContent.setCurrentItem(0);
    }

    private void showView(int madeid) {
        if (madeid == 1) {
            aq.id(R.id.btn_edit1).visible();
            aq.id(R.id.eyeimage).invisible();
            aq.id(R.id.texteye).invisible();
        }
    }

    public void getvalueforpageid(int post) {
        imagevalue = null;
        aduoivalue = null;
        conetvalue = null;
        custinfo = null;
        if (infolist != null) {
            for (Database info : infolist) {
                custinfo = (CustomerStoryInfo) info;
                if (custinfo.pindex == post) {
                    imagevalue = custinfo.image;
                    aduoivalue = custinfo.audio;
                    conetvalue = custinfo.content;
                    break;
                }
            }
        }
        if (imagevalue == null || imagevalue.equals("")) {
            imagevalue = null;
        }

        if (aduoivalue == null || aduoivalue.equals("")) {
            aduoivalue = null;
            aduoivalueloca = CommonUtility.getFileAudioPath(mStoryId, post);
        }

        if (conetvalue == null)
            conetvalue = Stroydetail[post];

    }

    private void startPlaying() {
        if (mPlayer != null) {
            if (pauseflag) {
                pauseflag = false;
                mPlayer.start();
            }
        } else {
            pauseflag = false;
            mPlayer = new MediaPlayer();
            if (!isstopaudio) {
                try {
                    if (aduoivalue != null) {
                        mPlayer.setDataSource(aduoivalue);
                        mPlayer.prepare();
                        mPlayer.start();
                    } else {
                        mPlayer.reset();
                        mPlayer.setDataSource(aduoivalueloca);
                        mPlayer.prepare();
                        mPlayer.start();
                        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                if (null != mp) {
                                    mp.stop();
                                    mp.release();
                                }
                                mPlayer = null;
                            }
                        });
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                isstopaudio = false;
            }
        }
    }

    private void pausePlaying() {
        if (mPlayer != null) {
            mPlayer.pause();
            pauseflag = true;
        }
    }

    private void stopPlaying() {
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    public void Setviewpageindex(int pageindex, int bookid) {
        madeid = 1;
        isstopaudio = false;
        mBookindex = bookid;

        try {
            infolist = (CustomerStoryInfo.getDatas(context, CustomerStoryInfo.class, "bookindex", mBookindex));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < views.length; i++) {
            setView(views[i], i);
        }

        if (lastValue != pageindex) {
            isstopaudio = true;
        }
        pageadpet.notifyDataSetChanged();
        vpContent.setCurrentItem(pageindex);
    }

    private void setView(View view, int pos) {
        AQuery Aq = new AQuery(view);
        getvalueforpageid(pos);
        if (pos == 0) {
            Aq.id(R.id.textviewvalue).text(conetvalue).textSize(30);
        } else {
            Aq.id(R.id.textviewvalue_buttom).text(conetvalue);
        }
        if (madeid == 1) {
            if (imagevalue != null) {
                File file = aq.getCachedFile(imagevalue);
                Aq.id(R.id.stroyiamge).image(file, 800);
            }
        }
        if (imagevalue == null) {
            try {
                Bitmap bmpCache = bitmapMap.get(pos);
                if (bmpCache != null) {
                    Aq.id(R.id.stroyiamge).image(bmpCache);
                    return;
                }
                Bitmap bmp = BitmapFactory.decodeStream(CommonUtility.getFileImageStream(mStoryId, pos));
                if (bmp == null) {
                    Toast.makeText(context, getString(R.string.accessory_bag), Toast.LENGTH_LONG).show();
                    return;
                }
                int picW = (int) (CommonUtility.screenDesity * bmp.getWidth() + 0.5);
                int picH = (int) (CommonUtility.screenDesity * bmp.getHeight() + 0.5);
                Bitmap bmp1 = Bitmap.createScaledBitmap(bmp, picW, picH, true);
                int w = bmp1.getWidth();
                int h = bmp1.getHeight();
                if (w >= CommonUtility.screenWidth) {
                    int offset = (w - CommonUtility.screenWidth);
                    Bitmap newBmp = Bitmap.createBitmap(bmp1, offset, 0, CommonUtility.screenWidth, h);
                    Aq.id(R.id.stroyiamge).image(newBmp);
                    CommonUtility.sWidth = CommonUtility.screenWidth;
                    if (bmp != null)
                        bmp.recycle();
                    bitmapMap.put(pos, newBmp);
                } else {
                    Aq.id(R.id.stroyiamge).image(bmp1);
                    CommonUtility.sWidth = w;
                    bitmapMap.put(pos, bmp1);
                }
                CommonUtility.sHeight = h;
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void showshareDialog() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            stopPlaying();
        }
        if (dialog == null) {
            View view = inflater.inflate(R.layout.sharedialog, null);
            dialog = new Dialog(context, R.style.CustomDialog);
            dialog.setContentView(view);
            Window dialogWindow = dialog.getWindow();
            WindowManager.LayoutParams lp = dialogWindow.getAttributes();
            lp.width = 480;
            lp.height = 320;
            dialogWindow.setAttributes(lp);
            AQuery aq = new AQuery(view);
            aq.id(R.id.btn_share_ok).clicked(this);
        }
        dialog.show();
    }

    private void addBookMark() {
        new AlertDialog.Builder(context)
                .setMessage(context.getResources().getString(R.string.add_bookmark))
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        dialog.cancel();
                    }
                })
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        BookMark bookMark = null;
                        if (madeid == 0) {
                            try {
                                bookMark = (BookMark) BookMark.getDatasAtFirst(context, BookMark.class, "storyid", mStoryId);
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                            if (bookMark == null) {
                                bookMark = new BookMark();
                                bookMark.storyid = mStoryId;
                                bookMark.category = category;
                                bookMark.madeid = 0;
                            }
                        } else if (madeid == 1) {
                            try {
                                bookMark = (BookMark) BookMark.getDatasAtFirst(context, BookMark.class, "custombookid", mBookindex);
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                            if (bookMark == null) {
                                bookMark = new BookMark();
                                bookMark.storyid = mStoryId;
                                bookMark.category = category;
                                bookMark.custombookid = mBookindex;
                                bookMark.madeid = 1;
                                bookMark.customname = bookTitle;
                            }
                        }
                        try {
                            BookMark.saveData(context, BookMark.class, bookMark);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(context, context.getString(R.string.addbookmark_success), Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    public void showshareDialogSimple() {
        choiceindex = -1;
        if (dialog == null) {
            View view = inflater.inflate(R.layout.dialog_share, null);
            dialog = new Dialog(context, R.style.dialog);
            dialog.setContentView(view);
            AQuery aq = new AQuery(view);
            aq.id(R.id.btn_ok).clicked(this);
            aq.id(R.id.button_pass).clicked(this);
            aq.id(R.id.btn_close).clicked(this);
            listadpent = new ListAdapter();
            aq.id(R.id.phonelistviwe).getListView().setAdapter(listadpent);
        }
        dialog.show();
    }

    private void createBlueTooth() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            return;
        }
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, CommonUtility.REQUEST_ENABLE_BT);
            return;
        }
        deviceList.clear();
        findDevices(mBluetoothAdapter);
        showshareDialogSimple();
    }

    private void findDevices(BluetoothAdapter mBluetoothAdapter) {
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        context.registerReceiver(mReceiver, filter);
        mBluetoothAdapter.startDiscovery();
    }

    private void sendByBlueTooth() {
        if (choiceindex >= deviceList.size())
            return;

        mCallback.onLoading("");
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }

        BluetoothDevice device = deviceList.get(choiceindex);
        if (connectThread == null || !device.equals(connectThread.mmDevice)) {
            if (connectThread != null) {
                connectThread.cancel();
                connectThread = null;
            }
            connectThread = new ConnectThread(device);
            connectThread.start();
        } else if (exchangeThread != null) {
            sendMessage(exchangeThread);
        }
    }

    private class ConnectThread extends Thread {
        public final BluetoothDevice mmDevice;
        public final BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            mmDevice = device;
            try {
                tmp = device.createRfcommSocketToServiceRecord(CommonUtility.MY_UUID);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            mmSocket = tmp;
        }

        public void run() {
            mBluetoothAdapter.cancelDiscovery();
            try {
                mmSocket.connect();
            } catch (final IOException connectException) {
                connectException.printStackTrace();
                try {
                    mmSocket.close();
                } catch (IOException closeException) {
                    closeException.printStackTrace();
                    mCallback.finishLoading();
                }
                return;
            }
            manageConnectedSocket(mmSocket);
        }

        public void cancel() {
            mCallback.finishLoading();
            try {
                mmSocket.close();
            } catch (IOException e) {
            }
        }
    }

    private void manageConnectedSocket(BluetoothSocket mmSocket) {
        exchangeThread = new ExchangeThread(context, mmSocket);
        sendMessage(exchangeThread);
    }

    private void sendMessage(ExchangeThread exchangeThread) {
        if (infolist == null || infolist.size() == 0)
            return;

        exchangeThread.writeString("D");
        sleep();
        exchangeThread.writeString("S" + mStoryId);
        sleep();
        for (Database in : infolist) {
            CustomerStoryInfo info = (CustomerStoryInfo) in;
            exchangeThread.writeString("P" + info.pindex);
            sleep();
            exchangeThread.writeString("C" + info.content);
            sleep();
            String path = info.image;
            byte[] bytes = readBytes(path);
            if (bytes != null) {
                int length = bytes.length;
                exchangeThread.writeString("I" + length);
                sleep();
                exchangeThread.write(bytes);
                sleep();
                sleep();
                sleep();
                sleep();
                sleep();
            }
            path = info.audio;
            bytes = readBytes(path);
            if (bytes != null) {
                int length = bytes.length;
                exchangeThread.writeString("A" + length);
                sleep();
                exchangeThread.write(bytes);
                sleep();
            }
            sleep();
            sleep();
            exchangeThread.writeString("B");
            sleep();
            sleep();
            sleep();
            sleep();
        }

        exchangeThread.writeString("E");
        sleep();
        context.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mCallback.finishLoading();
                if (connectThread != null) {
                    connectThread.cancel();
                    connectThread = null;
                }
            }
        });
    }

    private void sleep() {
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private byte[] readBytes(String path) {
        File file = new File(path);
        int size = (int) file.length();
        FileInputStream fileInputStream = null;
        byte[] bytes = new byte[size];
        try {
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytes);
            return bytes;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.ridaoButton:
                if (pauseflag) {
                    aq.id(R.id.ridaoButton).getButton().setBackgroundResource(R.drawable.s_pause_1);
                    startPlaying();
                } else {
                    aq.id(R.id.ridaoButton).getButton().setBackgroundResource(R.drawable.s_pause_2);
                    pausePlaying();
                }
                break;
            case R.id.btn_edit1:
                showshareDialog();
                break;
            case R.id.btn_share_ok:
                if (dialog != null)
                    dialog.dismiss();
                dialog = null;
                createBlueTooth();
                break;
            case R.id.btn_edit: {
                stopPlaying();
                if (madeid == 1) {
                    mCallback.addContent(new StoryEditFragment(this, mStoryId, mBookindex, lastValue, bookTitle));
                } else {
                    mCallback.addContent(new StoryEditFragment(this, mStoryId, -1, lastValue, bookTitle));
                }
                pauseflag = false;
            }
            break;
            case R.id.btn_bottom_menu:
                if (isMenuOn) {
                    aq.id(R.id.layout_bottom_menu).visibility(View.GONE);
                    aq.id(R.id.btn_bottom_menu).getView().setContentDescription(getResources().getString(R.string.btn_open));
                    isMenuOn = false;
                } else {
                    aq.id(R.id.layout_bottom_menu).visibility(View.VISIBLE);
                    aq.id(R.id.btn_bottom_menu).getView().setContentDescription(getResources().getString(R.string.btn_c));
                    isMenuOn = true;
                }
                break;
            case R.id.btn_bookmark:
                addBookMark();
                break;
            case R.id.btn_ok:
                if (choiceindex != -1) {
                    sendByBlueTooth();
                    dialog.cancel();
                }
                break;
            case R.id.btn_close:
                if (mBluetoothAdapter != null)
                    mBluetoothAdapter.cancelDiscovery();
                dialog.cancel();
                break;
        }
    }

    @Override
    public void toBack() {
        super.toBack();
        try {
            for (View v : views) {
                AQuery Aq = new AQuery(v);
                ImageView iv = Aq.id(R.id.stroyiamge).getImageView();
                if (iv != null) {
                    iv.setImageBitmap(null);
                }
            }
            Set<Map.Entry<Integer, Bitmap>> set = bitmapMap.entrySet();
            for (Map.Entry<Integer, Bitmap> entry : set) {
                entry.getValue().recycle();
            }
            bitmapMap.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        //Activity暂停时释放录音和播放对象
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CommonUtility.REQUEST_ENABLE_BT:
                if (resultCode == context.RESULT_OK) {
                    createBlueTooth();
                }
                break;
        }
    }

    class ListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return deviceList.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.share_item, null);
            }
            AQuery Aq = aq.recycle(view);
            Aq.id(R.id.layout_shareitem).clicked(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    choiceindex = i;
                    listadpent.notifyDataSetChanged();
                }
            });

            Aq.id(R.id.nametextview).text(deviceList.get(i).getName());

            if (choiceindex == i) {
                Aq.id(R.id.iamgechoice).image(R.drawable.click_bu_2);
            } else
                Aq.id(R.id.iamgechoice).image(R.drawable.click_bu_1);

            return view;
        }
    }

    private class PageviewAdapter extends PagerAdapter implements ViewPager.OnPageChangeListener {

        public PageviewAdapter() {
            views = new View[Stroydetail.length];
        }

        @Override
        public int getCount() {
            return Stroydetail.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object o) {
            return view == o;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int pos) {
            if (views[pos] == null) {
                View view = inflater.inflate(R.layout.story_detial, null);
                setView(view, pos);
                container.addView(view);
                views[pos] = view;
                return view;
            } else {
                container.addView(views[pos]);
                return views[pos];
            }
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            ((ViewPager) container).removeView((View) object);
        }

        @Override
        public void onPageScrolled(int i, float v, int i2) {

        }

        @Override
        public void onPageSelected(int i) {
            stopPlaying();
            aq.id(R.id.textpage).text((i + 1) + "/" + Stroydetail.length);
            lastValue = i;
            getvalueforpageid(i);
            startPlaying();
        }

        @Override
        public void onPageScrollStateChanged(int i) {

        }
    }

}
