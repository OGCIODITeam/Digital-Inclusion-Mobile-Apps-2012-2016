package com.sahk.sahkp.story;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

/**
 * User: user
 * Date: 13-9-24
 * Time: 下午4:21
 * To change this template use File | Settings | File Templates.
 */
public class Myviewpage extends ViewPager {

    private boolean left = false;
    private boolean right = false;
    private boolean isScrolling = false;
    private int lastValue = -1;
    private ChangeViewCallback changeViewCallback = null;

    public Myviewpage(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public Myviewpage(Context context) {
        super(context);
        init();
    }

    private void init() {
        setOnPageChangeListener(listener);
    }

    public OnPageChangeListener listener = new OnPageChangeListener() {
        @Override
        public void onPageScrollStateChanged(int arg0) {
            if (arg0 == 1) {
                isScrolling = true;
            } else {
                isScrolling = false;
            }
            if (arg0 == 2) {
                if (changeViewCallback != null) {
                    changeViewCallback.changeView(left, right);
                }
                right = left = false;
            }
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
            if (isScrolling) {
                if (lastValue > arg2) {
                    // 递减，向右侧滑动
                    right = true;
                    left = false;
                } else if (lastValue < arg2) {
                    // 递减，向右侧滑动
                    right = false;
                    left = true;
                } else if (lastValue == arg2) {
                    right = left = false;
                }
            }
            lastValue = arg2;
        }

        @Override
        public void onPageSelected(int arg0) {
            if (changeViewCallback != null) {
                changeViewCallback.getCurrentPageIndex(arg0);
            }
        }
    };


    public interface ChangeViewCallback {

        public void changeView(boolean left, boolean right);

        public void getCurrentPageIndex(int index);
    }

}
