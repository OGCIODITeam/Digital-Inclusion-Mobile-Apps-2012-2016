package com.sahk.sahkp.story;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.Story;
import it.sephiroth.android.library.widget.HListView;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by Winkey on 16/8/13.
 */
public class MainFragment extends _AbstractMainFragment {

    private final String TAG = "MainFragment";
    public static final int[] strids = new int[]{R.array.story1, R.array.story2, R.array.story3,
            R.array.story4, R.array.story5, R.array.story6, R.array.story7, R.array.story8, R.array.story9, R.array.story10, R.array.story11, R.array.story12, R.array.story13, R.array.story14, R.array.story15, R.array.story16, R.array.story17,
            R.array.story18, R.array.story19, R.array.story20, R.array.story21, R.array.story22, R.array.story23, R.array.story24, R.array.story25, R.array.story26, R.array.story27, R.array.story28, R.array.story29, R.array.story30, R.array.story31,
            R.array.story32, R.array.story33, R.array.story34, R.array.story35, R.array.story36, R.array.story37, R.array.story38, R.array.story39, R.array.story40, R.array.story41, R.array.story42, R.array.story43, R.array.story44, R.array.story45,
            R.array.story46, R.array.story47, R.array.story48, R.array.story49, R.array.story50, R.array.story51, R.array.story52, R.array.story53, R.array.story54, R.array.story55, R.array.story56, R.array.story57, R.array.story58, R.array.story59,
            R.array.story60, R.array.story61, R.array.story62, R.array.story63, R.array.story64, R.array.story65, R.array.story66, R.array.story67, R.array.story68, R.array.story69, R.array.story70, R.array.story71, R.array.story72, R.array.story73,
            R.array.story74, R.array.story75, R.array.story76, R.array.story77, R.array.story78, R.array.story79, R.array.story80, R.array.story81, R.array.story82, R.array.story83, R.array.story84, R.array.story85, R.array.story86, R.array.story87,
            R.array.story88, R.array.story89, R.array.story90, R.array.story91, R.array.story92, R.array.story93, R.array.story94, R.array.story95, R.array.story96, R.array.story97, R.array.story98, R.array.story99, R.array.story100
    };
    static int range = 0;
    private static int mStoryId;
    public String[] raginlist;
    public int starvalue = 0;
    private boolean isRatingVisible = false;
    private BookAdapter adapter1, adapter2, adapter3, adapter4, adapter5;
    private Dialog starDialog;
    private AQuery aqDialog;
    private Map<Integer, Bitmap> bitmapMap = new HashMap<Integer, Bitmap>();
    private List<ImageView> list = new LinkedList<ImageView>();

    public void MainFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.e(TAG, "--------->onCreateView");
        this.inflater = inflater;
        View v = inflater.inflate(R.layout.main_content, container, false);
        aq = new AQuery(v);
        init();
        return v;
    }

    private void init() {
        adapter1 = new BookAdapter(0);
        adapter2 = new BookAdapter(1);
        adapter3 = new BookAdapter(2);
        adapter4 = new BookAdapter(3);
        adapter5 = new BookAdapter(4);

        ((HListView) aq.id(R.id.lv_1).getView()).setAdapter(adapter1);
        ((HListView) aq.id(R.id.lv_2).getView()).setAdapter(adapter2);
        ((HListView) aq.id(R.id.lv_3).getView()).setAdapter(adapter3);
        ((HListView) aq.id(R.id.lv_4).getView()).setAdapter(adapter4);
        ((HListView) aq.id(R.id.lv_5).getView()).setAdapter(adapter5);

        aq.id(R.id.btn_eye).clicked(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isRatingVisible) {
                    view.setSelected(true);
                    isRatingVisible = true;
                } else {
                    view.setSelected(false);
                    isRatingVisible = false;
                }
                adapter1.notifyDataSetChanged();
                adapter2.notifyDataSetChanged();
                adapter3.notifyDataSetChanged();
                adapter4.notifyDataSetChanged();
                adapter5.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void toBack() {
        for (ImageView iv : list) {
            iv.setImageBitmap(null);
        }
        Set<Map.Entry<Integer, Bitmap>> set = bitmapMap.entrySet();
        for (Map.Entry<Integer, Bitmap> entry : set) {
            entry.getValue().recycle();
        }
        set.clear();
    }

    @Override
    protected Bitmap doInBack(int data) {
        try {
            InputStream imgStream = getActivity().getAssets().open(CommonUtility.getFirstImage(data));
            Bitmap bmpp = new WeakReference<Bitmap>(BitmapFactory.decodeStream(imgStream)).get();
            bitmapMap.put(data, bmpp);
            return bmpp;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    class BookAdapter extends BaseAdapter {
        private int[] mCount = {32, 27, 14, 17, 10};
        private int mIndex = 0;
        private View.OnClickListener dialogClick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.staer1:
                        range = 1;
                        setStarStatus(aqDialog, range);
                        break;
                    case R.id.staer2:
                        range = 2;
                        setStarStatus(aqDialog, range);
                        break;
                    case R.id.staer3:
                        range = 3;
                        setStarStatus(aqDialog, range);
                        break;
                    case R.id.staer4:
                        range = 4;
                        setStarStatus(aqDialog, range);
                        break;
                    case R.id.staer5:
                        range = 5;
                        setStarStatus(aqDialog, range);
                        break;
                    case R.id.button_ok: {
                        if (range != 0) {
                            saveStar();
                            starDialog.dismiss();
                            starDialog.cancel();
                            starDialog = null;
                            range = 0;
                        }
                    }
                    break;
                    case R.id.btn_close: {
                        starDialog.dismiss();
                        starDialog.cancel();
                        starDialog = null;
                        range = 0;
                    }
                    break;
                    case R.id.button_pass: {
                        adapter1.notifyDataSetChanged();
                        adapter2.notifyDataSetChanged();
                        adapter3.notifyDataSetChanged();
                        adapter4.notifyDataSetChanged();
                        adapter5.notifyDataSetChanged();

                        mCallback.addContent(new StoryFragment(mStoryId, mIndex, -1, 0, ""));

                        starDialog.dismiss();
                        starDialog.cancel();
                        starDialog = null;
                        range = 0;
                    }
                    break;
                }
            }
        };

        BookAdapter(int index) {
            mIndex = index;
        }

        @Override
        public int getCount() {
            return mCount[mIndex];
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public View getView(final int pos, View cview, ViewGroup viewGroup) {
            View view = null;
            int index = pos + 1;
            if (mIndex == 1) {

            }
            for (int i = 0; i < mIndex; i++) {
                index += mCount[i];
            }
            if (view == null)
                view = inflater.inflate(R.layout.book_item, null);

            try {
                final AQuery aq_view = new AQuery(view);
                if (isRatingVisible) {
                    aq_view.id(R.id.layout_rating).visible();
                    try {
                        Story story = (Story) Story.getDatasAtFirst(context, Story.class, "id", index);
                        aq_view.id(R.id.tv_rating).text(story.count + "");
                        aq_view.id(R.id.star1).gone();
                        aq_view.id(R.id.star2).gone();
                        aq_view.id(R.id.star3).gone();
                        aq_view.id(R.id.star4).gone();
                        aq_view.id(R.id.star5).gone();
                        starvalue = story.rating;
                        for (int i = 0; i < starvalue; i++) {
                            switch (i) {
                                case 0:
                                    aq_view.id(R.id.star1).visible();
                                    break;
                                case 1:
                                    aq_view.id(R.id.star2).visible();
                                    break;
                                case 2:
                                    aq_view.id(R.id.star3).visible();
                                    break;
                                case 3:
                                    aq_view.id(R.id.star4).visible();
                                    break;
                                case 4:
                                    aq_view.id(R.id.star5).visible();
                                    break;
                            }
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else
                    aq_view.id(R.id.layout_rating).invisible();
                try {
                    InputStream imgStream = getActivity().getAssets().open(CommonUtility.getFirstImage(index));
                    Drawable drawable = new WeakReference<Drawable>(Drawable.createFromStream(imgStream, null)).get();
                    aq_view.id(R.id.img_book).image(drawable);
                    aq_view.id(R.id.img_book).getView().setContentDescription(context.getResources().getStringArray(strids[index - 1])[0]);

                } catch (OutOfMemoryError e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                final int finalIndex = index;
                aq_view.id(R.id.img_book).clicked(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            Story story = (Story) Story.getDatasAtFirst(context, Story.class, "id", finalIndex);
                            if (story.count >= 1) {
                                mStoryId = finalIndex;
                                showStarDialog();
                            } else {
                                mCallback.addContent(new StoryFragment(finalIndex, mIndex, -1, 0, ""));
                            }
                            aq.id(R.id.btn_eye).getView().setSelected(false);
                            isRatingVisible = false;
                            adapter1.notifyDataSetChanged();
                            adapter2.notifyDataSetChanged();
                            adapter3.notifyDataSetChanged();
                            adapter4.notifyDataSetChanged();
                            adapter5.notifyDataSetChanged();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
            return view;
        }

        public void showStarDialog() {
            if (starDialog == null) {
                View view = inflater.inflate(R.layout.dialog_stare, null);
                starDialog = new Dialog(context, R.style.dialog);
                starDialog.setContentView(view);
                aqDialog = new AQuery(view);
                aqDialog.id(R.id.staer1).clicked(dialogClick);
                aqDialog.id(R.id.staer2).clicked(dialogClick);
                aqDialog.id(R.id.staer3).clicked(dialogClick);
                aqDialog.id(R.id.staer4).clicked(dialogClick);
                aqDialog.id(R.id.staer5).clicked(dialogClick);
                aqDialog.id(R.id.btn_close).clicked(dialogClick);
                aqDialog.id(R.id.button_pass).clicked(dialogClick);
                aqDialog.id(R.id.button_ok).clicked(dialogClick);
            }
            starDialog.show();
        }

        private void saveStar() {
            Story story = null;
            try {
                story = (Story) Story.getDatasAtFirst(context, Story.class, "id", mStoryId);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (story == null) {
                story = new Story();
            }
            story.addBookMark(range);
            try {
                Story.saveData(context, Story.class, story);
                Toast.makeText(context, getString(R.string.givepoint), Toast.LENGTH_LONG).show();
                adapter1.notifyDataSetChanged();
                adapter2.notifyDataSetChanged();
                adapter3.notifyDataSetChanged();
                adapter4.notifyDataSetChanged();
                adapter5.notifyDataSetChanged();
                mCallback.addContent(new StoryFragment(mStoryId, mIndex, -1, 0, ""));
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        private void setStarStatus(AQuery aq, int range) {
            aq.id(R.id.staer1).image(R.drawable.star_1);
            aq.id(R.id.staer2).image(R.drawable.star_1);
            aq.id(R.id.staer3).image(R.drawable.star_1);
            aq.id(R.id.staer4).image(R.drawable.star_1);
            aq.id(R.id.staer5).image(R.drawable.star_1);
            for (int i = 0; i < range; i++) {
                switch (i) {
                    case 0:
                        aq.id(R.id.staer1).image(R.drawable.star_2);
                        break;
                    case 1:
                        aq.id(R.id.staer2).image(R.drawable.star_2);
                        break;
                    case 2:
                        aq.id(R.id.staer3).image(R.drawable.star_2);
                        break;
                    case 3:
                        aq.id(R.id.staer4).image(R.drawable.star_2);
                        break;
                    case 4:
                        aq.id(R.id.staer5).image(R.drawable.star_2);
                        break;
                }
            }
        }
    }
}
