package com.sahk.sahkp;

import com.google.android.vending.expansion.downloader.impl.DownloaderService;

/**
 * Created by Administrator on 13-11-13.
 */
public class MyDownLoadService extends DownloaderService {
    public static final String BASE64_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAttpSfOlIz12p5BY2WNHJkTqUQr83R7ZxpdIW/0I+FmSaPDh2rI8Y0lyiWAiPR5ptbu3zgP0y3IvEK7Vt/Y5otHvKXaN3LYBBZa12ow7M4c+fkWzSnGPESFf75+1TB8OfA7XGkC5vXfC+TXsGHi0/pWGsghESqgl3tXgay11GKh5NAFigeGFsbqXzyZnuzIecgWGyyrsiUBUWis+enzaRMAnQ9Ma4snJ4RpUVouMDgl0VCgDabRR7dxcrjkTEtHvbjb971iDoLHh15DoJ1JBNbcwUvNHE0GAqRy7IXgJa0lVjE6Nr39WTliZeuXRx0G6hzXQmy79P6QxRKZSDBy+1xwIDAQAB";
    public static final byte[] SALT = new byte[]{1, 42, -12, -1, 54, 98,
            -100, -12, 43, 2, -8, -4, 9, 5, -106, -107, -33, 45, -1, 84
    };

    @Override
    public String getPublicKey() {
        return BASE64_PUBLIC_KEY.trim();
    }

    @Override
    public byte[] getSALT() {
        return SALT;
    }

    @Override
    public String getAlarmReceiverClassName() {
        return MyDownLoadService.class.getName();
    }

}
