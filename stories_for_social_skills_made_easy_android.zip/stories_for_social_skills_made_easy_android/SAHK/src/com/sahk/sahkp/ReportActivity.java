package com.sahk.sahkp;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.androidquery.AQuery;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.data.Story;

import java.io.*;
import java.lang.ref.WeakReference;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by linlinet on 13-9-28.
 */
public class ReportActivity extends Activity implements View.OnClickListener {
    @Override
    public void onClick(View view) {
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    private int[] mCount = {32, 27, 14, 17, 10};
    private AQuery aq;
    private int index = 0;
    private ProgressDialog loadingDailog;
    LinearLayout l_1, l_2, l_3, l_4, l_5;
    private TextView txt_time;
    private LinkedList<Bitmap> list = new LinkedList<Bitmap>();
    private List<Database> reportStory;
    private LinkedList<Integer> ralist;
    private Dialog dialog;
    private Bitmap bmp;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (ralist.size() > 0) {
                reccle();
                init1();
            } else {
                loadingDailog.cancel();
                loadingDailog.dismiss();
                View view = View.inflate(ReportActivity.this, R.layout.sharedialog, null);
                dialog = new Dialog(ReportActivity.this, R.style.CustomDialog) {
                    @Override
                    public void dismiss() {
                        super.dismiss();
                        finish();
                    }
                };
                TextView tv_title = (TextView) view.findViewById(R.id.tv_dialog_title);
                tv_title.setText(getResources().getString(R.string.dialog_title));
                dialog.setContentView(view);
                Window dialogWindow = dialog.getWindow();
                WindowManager.LayoutParams lp = dialogWindow.getAttributes();
                lp.width = 480;
                lp.height = 320;
                dialogWindow.setAttributes(lp);
                AQuery aq = new AQuery(view);
                aq.id(R.id.btn_share_ok).clicked(ReportActivity.this);
                dialog.show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report_content);
        aq = new AQuery(this);

        String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date());
        txt_time = aq.id(R.id.txt_time).text(timeStamp).getTextView();
        ralist = new LinkedList<Integer>();
        for (int i = 1; i <= 100; i++) {
            ralist.add(i);
        }
        try {
            reportStory = Story.getDatas(this, Story.class, "rating", 0);
            for (int i = 0; i < reportStory.size(); i++) {
                ralist.remove(reportStory.get(i).id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        init1();
    }

    private void init1() {
        loadingDailog = ProgressDialog.show(this, null, getString(R.string.loading));
        l_1 = (LinearLayout) aq.id(R.id.l_1).getView();
        l_2 = (LinearLayout) aq.id(R.id.l_2).getView();
        l_3 = (LinearLayout) aq.id(R.id.l_3).getView();
        l_4 = (LinearLayout) aq.id(R.id.l_4).getView();
        l_5 = (LinearLayout) aq.id(R.id.l_5).getView();
        for (int i = 0; i < 5; i++) {
            addItem(i);
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                saveImage();
            }
        }, 350);
    }

    private int width;
    private int height;

    private synchronized void saveImage() {
        View u = findViewById(R.id.layout_report);
        final ScrollView scrollView = (ScrollView) findViewById(R.id.layout_report);
        height = scrollView.getChildAt(0).getHeight();
        width = scrollView.getChildAt(0).getWidth();
        bmp = getBitmapFromView(scrollView, width, height);
        saveReport(bmp);
    }

    private void addItem(int index) {
        int[] arr = {32, 59, 86, 90, 100};
        LinearLayout linearLayout = l_1;
        switch (index) {
            case 1:
                linearLayout = l_2;
                break;
            case 2:
                linearLayout = l_3;
                break;
            case 3:
                linearLayout = l_4;
                break;
            case 4:
                linearLayout = l_5;
                break;
        }
        int tem = 0;
        int arrtem[] = new int[CommonUtility.bookNum];
        int size = ralist.size();
        for (int i = 0; i < size; i++) {
            int bookIndex = ralist.get(i);
            if (index == 0 && bookIndex <= arr[index]) {
                linearLayout.addView(getView(bookIndex, index));
                arrtem[tem] = bookIndex;
                tem++;
            } else if (index == 1 && bookIndex > arr[index - 1] && bookIndex <= arr[index]) {
                linearLayout.addView(getView(bookIndex, index));
                arrtem[tem] = bookIndex;
                tem++;
            } else if (index == 2 && bookIndex > arr[index - 1] && bookIndex <= arr[index]) {
                linearLayout.addView(getView(bookIndex, index));
                arrtem[tem] = bookIndex;
                tem++;
            } else if (index == 3 && bookIndex > arr[index - 1] && bookIndex <= arr[index]) {
                linearLayout.addView(getView(bookIndex, index));
                arrtem[tem] = bookIndex;
                tem++;
            } else if (index == 4 && bookIndex > arr[index - 1] && bookIndex <= arr[index]) {
                linearLayout.addView(getView(bookIndex, index));
                arrtem[tem] = bookIndex;
                tem++;
            }
            if (tem == CommonUtility.bookNum) {
                break;
            }
        }
        for (int j = 0; j < arrtem.length; j++) {
            ralist.remove(new Integer(arrtem[j]));
        }
    }

    public View getView(int bookId, int mIndex) {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.book_item, null);
        view.setPadding(0, 20, 0, 0);
        AQuery aq_view = new AQuery(view);
        aq_view.id(R.id.layout_rating).visibility(View.VISIBLE);
        aq_view.id(R.id.star1).gone();
        aq_view.id(R.id.star2).gone();
        aq_view.id(R.id.star3).gone();
        aq_view.id(R.id.star4).gone();
        aq_view.id(R.id.star5).gone();
        try {
            for (int i = 0; i < mIndex; i++) {
                index += mCount[i];
            }
            Story story = (Story) Story.getDatasAtFirst(ReportActivity.this, Story.class, "id", bookId);
            if (story != null) {
                aq_view.id(R.id.tv_rating).text(story.count + "");
                for (int i = 0; i < story.rating; i++) {
                    switch (i) {
                        case 0:
                            aq_view.id(R.id.star1).visible();
                            break;
                        case 1:
                            aq_view.id(R.id.star2).visible();
                            break;
                        case 2:
                            aq_view.id(R.id.star3).visible();
                            break;
                        case 3:
                            aq_view.id(R.id.star4).visible();
                            break;
                        case 4:
                            aq_view.id(R.id.star5).visible();
                            break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            InputStream imgStream = getAssets().open(CommonUtility.getFirstImage(bookId));
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1; //Downsample 10x
            Bitmap bmp = BitmapFactory.decodeStream(imgStream, null, options);
            list.add(bmp);
            aq_view.id(R.id.img_book).image(bmp);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
        return view;
    }

    private synchronized void saveReport(Bitmap bitmap) {
        if (bitmap == null)
            return;
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".jpg";
        try {
            File file = new File(CommonUtility.photoFolderPath);
            if (!file.exists())
                file.mkdirs();
            FileOutputStream out = new FileOutputStream(file + "/" + timeStamp);
            bmp.compress(Bitmap.CompressFormat.JPEG, 95, out);
            handler.sendEmptyMessage(0);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }


    private synchronized Bitmap getBitmapFromView(View view, int width, int height) {
        int widthSpec = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
        int heightSpec = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);
        view.measure(widthSpec, heightSpec);
        view.layout(0, 0, width, height);
        Bitmap bitmap = null;
        try {
            bitmap = new WeakReference<Bitmap>(Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)).get();
            list.add(bitmap);
            Canvas canvas = new Canvas(bitmap);
            view.draw(canvas);
            return bitmap;

        } catch (OutOfMemoryError error) {

        } finally {
            return bitmap;
        }

    }

    private void reccle() {
        l_1.removeAllViews();
        l_2.removeAllViews();
        l_3.removeAllViews();
        l_4.removeAllViews();
        l_5.removeAllViews();
        if (list != null) {
            for (Bitmap bitmap : list) {
                if (bitmap != null) {
                    bitmap.recycle();
                }
            }
        }
        list.clear();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        reccle();
    }
}
