package com.sahk.sahkp.bookmark;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import com.androidquery.AQuery;
import com.sahk.sahkp.CommonUtility;
import com.sahk.sahkp.R;
import com.sahk.sahkp._AbstractMainFragment;
import com.sahk.sahkp.data.BookMark;
import com.sahk.sahkp.data.CustomerStory;
import com.sahk.sahkp.data.Database;
import com.sahk.sahkp.story.StoryFragment;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by casum on 13-9-22.
 */
public class BookMarkFragment extends _AbstractMainFragment {

    List<Database> books = null;
    List<Database> books_custom = null;
    private List<Database> list;
    private RelateslistAdapter pelatesadp;
    private GridView gridview;

    public BookMarkFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        View v = inflater.inflate(R.layout.bookmark_layout, container, false);
        aq = new AQuery(v);
        init();
        return v;
    }

    private void init() {
        if (list != null) {
            list.clear();
        }
        list = new ArrayList<Database>();
        books = getBookMarkList();
        if (books != null) {
            for (int i = 0; i < books.size(); i++) {
                list.add((BookMark) books.get(i));
            }
        }

        books_custom = getBookMarkList_custom();
        if (books_custom != null) {
            for (int i = 0; i < books_custom.size(); i++) {
                list.add((BookMark) books_custom.get(i));
            }
        }

        pelatesadp = new RelateslistAdapter();
        gridview = (GridView) aq.id(R.id.gvcostumer).getView();
        pelatesadp.notifyDataSetChanged();
        gridview.setAdapter(pelatesadp);
        gridview.setOnItemClickListener(pelatesadp);
    }

    private List<Database> getBookMarkList() {
        List<Database> list = null;
        try {
            list = Database.getDatas(context, BookMark.class, "madeid", 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    private List<Database> getBookMarkList_custom() {
        List<Database> list = null;
        try {
            list = Database.getDatas(context, BookMark.class, "madeid", 1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    class RelateslistAdapter extends BaseAdapter implements AdapterView.OnItemClickListener {

        @Override
        public int getCount() {
            int size = list.size();
            if (size == 0)
                return 0;
            int row = size / 3;
            if (size % 3 != 0)
                row++;
            int count = row * 3;
            return count;
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = inflater.inflate(R.layout.customer_bookitem, null);
            }
            AQuery Aq = new AQuery(view);
            if (i >= list.size()) {
                Aq.id(R.id.ll_custom_title).invisible();
                Aq.id(R.id.img_book).invisible();
                return view;
            } else {
                Aq.id(R.id.img_book).visible();
                Aq.id(R.id.ll_custom_title).visible();
            }
            if (list != null) {
                BookMark bookMark = (BookMark) list.get(i);
                if (bookMark != null) {
                    if (bookMark.madeid == 0) {
                        String imgname = CommonUtility.getFirstImage(bookMark.storyid);
                        try {
                            InputStream imgStream = getActivity().getAssets().open(imgname);
                            Drawable drawable = Drawable.createFromStream(imgStream, null);
                            Aq.id(R.id.img_book).image(drawable);
                        } catch (OutOfMemoryError e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } else if (bookMark.madeid == 1) {
                        String imgname = CommonUtility.getFirstImage(bookMark.storyid);
                        try {
                            InputStream imgStream = getActivity().getAssets().open(imgname);
                            Drawable drawable = Drawable.createFromStream(imgStream, null);
                            Aq.id(R.id.img_book).image(drawable);
                        } catch (OutOfMemoryError e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            return view;
        }

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            if (i >= list.size()) {
                return;
            }
            BookMark bookMark = (BookMark) list.get(i);
            if (bookMark.madeid == 0) {
                mCallback.addContent(new StoryFragment(bookMark.storyid, bookMark.category, 0, 0, ""));
            } else if (bookMark.madeid == 1) {
                mCallback.addContent(new StoryFragment(bookMark.storyid, bookMark.category, bookMark.custombookid, bookMark.madeid, bookMark.customname));
            }
        }
    }
}
