//
//  AboutSAHKViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月30日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface AboutSAHKViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet LeftMenuButton *leftBtn;

}

@end
