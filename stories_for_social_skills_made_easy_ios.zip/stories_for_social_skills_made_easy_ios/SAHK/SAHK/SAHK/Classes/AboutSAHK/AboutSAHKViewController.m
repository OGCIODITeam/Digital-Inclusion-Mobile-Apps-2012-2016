//
//  AboutSAHKViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月30日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "AboutSAHKViewController.h"

@interface AboutSAHKViewController ()

@property (nonatomic, retain) IBOutlet UIWebView *WV;
@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

@end

@implementation AboutSAHKViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)dealloc
{
    self.WV.delegate = nil;
    self.WV = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    [topNav release];
    [leftBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        self.WV.frame=CGRectMake( self.WV.frame.origin.x,  self.WV.frame.origin.y+20,  self.WV.frame.size.width,  self.WV.frame.size.height-20);
        
    }
    
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"sahk_aboutus"];
    
    if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
        [self.WV loadHTMLString:@"<!DOCTYPEhtmlPUBLIC\"-//W3C//DTDXHTML1.0Transitional//EN\"\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><htmlxmlns=\"http://www.w3.org/1999/xhtml\"><head><metahttp-equiv=\"Content-Type\"content=\"text/html;charset=UTF-8\"/><title>UntitledDocument</title></head><body><p><!DOCTYPEHTMLPUBLIC\"-//W3C//DTDHTML4.0Transitional//EN\"><!--		@page{margin:2cm}		P{margin-bottom:0.21cm}	--><U><strong>香港耀能協會簡介</strong></U></p><p ALIGN=\"JUSTIFY\">本會於1963年創立，名為「香港痙攣兒童會」。其後將服務擴展至成年痙攣人士，並於1967年易名為「香港痙攣協會」，於1976年立案註冊為法定社團。我們一直緊貼香港社會需要，開創多項服務予其他中樞神經系統受損人士。2008年，我們因應服務發展，更改名稱為「香港耀能協會」。</p><p>我們為各種殘障、不同年齡的人士提供服務，包括︰自閉症、中風、柏金遜症、腦退化症和智障人士等。</p><p>香港耀能協會的理念是「耀承所授、卓越展能」，我們相信服務使用者能夠運用天賦的才能及後天的努力，發揮所長，展耀光輝。</p><p>經過多年來的努力，加上各界的支持，我們已發展成為一間有60個服務單位，聘用近1,400名員工的機構，每年服務超過7,000個家庭。服務範圍包括幼兒中心、特殊學校、就業培訓、成人住宿、社區康復、家庭支援及專業服務等。</p></body></html>" baseURL:nil];
    }
    else {
        [self.WV loadHTMLString:@"<!DOCTYPEhtmlPUBLIC\"-//W3C//DTDXHTML1.0Transitional//EN\"\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><htmlxmlns=\"http://www.w3.org/1999/xhtml\"><head><metahttp-equiv=\"Content-Type\"content=\"text/html;charset=UTF-8\"/><title>UntitledDocument</title></head><body><p><!DOCTYPEHTMLPUBLIC\"-//W3C//DTDHTML4.0Transitional//EN\"><!--		@page{margin:2cm}		P{margin-bottom:0.21cm}	--><U><strong>香港耀能协会简介</strong></U></p><p ALIGN=\"JUSTIFY\">本会於1963年创立，名为「香港痉挛儿童会」。其後将服务扩展至成年痉挛人士，并於1967年易名为「香港痉挛协会」，於1976年立案注册为法定社团。我们一直紧贴香港社会需要，开创多项服务予其他中枢神经系统受损人士。2008年，我们因应服务发展，更改名称为「香港耀能协会」。</p><p>我们为各种残障丶不同年龄的人士提供服务，包括∶自闭症丶中风丶柏金逊症丶脑退化症和智障人士等。</p><p>香港耀能协会的理念是「耀承所授丶卓越展能」，我们相信服务使用者能够运用天赋的才能及後天的努力，发挥所长，展耀光辉。</p><p>经过多年来的努力，加上各界的支持，我们已发展成为一间有60个服务单位，聘用近1,400名员工的机构，每年服务超过7,000个家庭。服务范围包括幼儿中心丶特殊学校丶就业培训丶成人住宿丶社区康复丶家庭支援及专业服务等。</p></body></html>" baseURL:nil];
    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [super viewDidUnload];
}
@end
