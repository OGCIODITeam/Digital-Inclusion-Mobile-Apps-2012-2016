//
//  LeftMenuButton.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButtonDelegate.h"

@interface LeftMenuButton : UIButton

@property (nonatomic, assign) id <LeftMenuButtonDelegate> delegateLeftMenuButton;

@end
