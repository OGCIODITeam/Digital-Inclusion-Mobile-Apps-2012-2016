//
//  LeftMenuButtonDelegate.h
//  SAHK
//
//  Created by Jeff Cheung on 13年10月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol LeftMenuButtonDelegate <NSObject>

@optional

- (void)clickLeftMenuButton;

@end

