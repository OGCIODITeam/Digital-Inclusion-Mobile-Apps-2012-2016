//
//  LeftMenuButton.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "LeftMenuButton.h"

@interface LeftMenuButton ()

#pragma mark - Handle Click Button Events

- (void)clickLeftMenuButton:(UIButton *)button;

@end

@implementation LeftMenuButton

@synthesize delegateLeftMenuButton = _delegateLeftMenuButton;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [self removeTarget:self action:@selector(clickLeftMenuButton:) forControlEvents:UIControlEventTouchUpInside];
    [super dealloc];
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    [self addTarget:self action:@selector(clickLeftMenuButton:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark - Handle Click Button Events

- (void)clickLeftMenuButton:(UIButton *)button
{
    if (self.delegateLeftMenuButton && [self.delegateLeftMenuButton respondsToSelector:@selector(clickLeftMenuButton)]) {
        [self.delegateLeftMenuButton clickLeftMenuButton];
    }
    [[CoreData sharedCoreData].VCSideMenuContainer openLeftMenu];
}

@end
