//
//  JNavigationController.m
//
//  Created by Jeff Cheung on 12年10月26日.
//  Copyright (c) 2012年 Jeff Cheung. All rights reserved.
//

#import "JNavigationController.h"
#import <QuartzCore/QuartzCore.h>
#import "RootViewController.h"

@interface JNavigationController ()

@end

@implementation JNavigationController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Core

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    DEBUGMSG(@"pushViewController: %@", viewController.class);
    if (!animated && ![[viewController class] isEqual:[RootViewController class]]) {
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionMoveIn;
        transition.subtype = kCATransitionFromRight;
        [self.view.layer removeAllAnimations];
		[self.view.layer addAnimation:transition forKey:@""];
    }
    [super pushViewController:viewController animated:animated];
}

- (void)OriginalPushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [super pushViewController:viewController animated:animated];
}

- (NSArray *)OriginalPopToRootViewControllerAnimated:(BOOL)animated
{
    return [super popToRootViewControllerAnimated:animated];
}

- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated
{
    DEBUGMSG(@"popToRootViewControllerAnimated");
    if (!animated) {
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromLeft;
        [self.view.layer removeAllAnimations];
		[self.view.layer addAnimation:transition forKey:@""];
    }
    return [super popToRootViewControllerAnimated:animated];
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated
{
    DEBUGMSG(@"popViewControllerAnimated");
    if (!animated) {
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromLeft;
        [self.view.layer removeAllAnimations];
		[self.view.layer addAnimation:transition forKey:@""];
    }
    return [super popViewControllerAnimated:animated];
}

- (NSArray *)popToViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    DEBUGMSG(@"popToViewController: %@", viewController.class);
    if (!animated) {
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromLeft;
        [self.view.layer removeAllAnimations];
		[self.view.layer addAnimation:transition forKey:@""];
    }
    return [super popToViewController:viewController animated:animated];
}

@end
