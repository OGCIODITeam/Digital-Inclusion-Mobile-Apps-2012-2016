//
//  CoreData.m
//
//  Created by Jeff Cheung on 12年10月26日.
//  Copyright (c) 2012年 Jeff Cheung. All rights reserved.
//

#import "CoreData.h"
#import <QuartzCore/QuartzCore.h>

@interface CoreData ()

@end

@implementation CoreData

@synthesize fOSVersion = _fOSVersion;
@synthesize OQCommonQueue = _OQCommonQueue;
@synthesize OQGraphicQueue = _OQGraphicQueue;
@synthesize JNC = _JNC;
@synthesize window = _window;
@synthesize stringDeviceType = _stringDeviceType;
@synthesize VCLeftRoot = _VCLeftRoot;
@synthesize VCSideMenuContainer = _VCSideMenuContainer;
@synthesize stringLanguage = _stringLanguage, stringVoice = _stringVoice, stringNotificationCenter = _stringNotificationCenter;
@synthesize stringServiceUUID = _stringServiceUUID;
@synthesize stringCharacteristicUUID = _stringCharacteristicUUID;
@synthesize stringDeviceID = _stringDeviceID;

static CoreData *_coreData = nil;

#pragma mark - Core

+ (CoreData *)sharedCoreData
{
	if (!_coreData) {
		_coreData = [[CoreData alloc] init];
        _coreData.fOSVersion = [[UIDevice currentDevice].systemVersion floatValue] + 0.000001;
        _coreData.OQCommonQueue = [[NSOperationQueue alloc] init];
		[_coreData.OQCommonQueue setMaxConcurrentOperationCount:2];
        _coreData.OQGraphicQueue = [[NSOperationQueue alloc] init];
        [_coreData.OQGraphicQueue setMaxConcurrentOperationCount:2];
        
        //uuidgen in terminal
        _coreData.stringServiceUUID = @"1F724CA2-783C-46A6-896F-3580E98E7712";
        _coreData.stringCharacteristicUUID = @"C7239A61-A1E5-4592-8834-18C87035EC5C";
        
        
        NSDictionary *dictionaryAppInfo = [NSDictionary dictionaryWithContentsOfFile:PlistPathAppInfo];
        if (dictionaryAppInfo && [dictionaryAppInfo objectForKey:@"deviceID"]) {
            _coreData.stringDeviceID = [dictionaryAppInfo objectForKey:@"deviceID"];
        }
        else {
            if (_coreData.fOSVersion > 6.0) {
                _coreData.stringDeviceID = [[UIDevice currentDevice].identifierForVendor UUIDString];
            }
            else {
                CFUUIDRef UUIDRef = CFUUIDCreate(kCFAllocatorDefault);
                _coreData.stringDeviceID = [(NSString *)CFUUIDCreateString(kCFAllocatorDefault, UUIDRef) autorelease];
                CFRelease(UUIDRef);
            }
            NSMutableDictionary *MDAppInfo = [NSMutableDictionary new];
            //debug on 2013-10-27
            [MDAppInfo setObject:_coreData.stringDeviceID forKey:@"deviceID"];
            [MDAppInfo writeToFile:PlistPathAppInfo atomically:YES];
            [MDAppInfo release];
        }
    }
	return _coreData;
}

- (void)checkAndSaveDeviceType
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        self.stringDeviceType = iPad;
    }
    else {
        float fScreenHeight = [UIScreen mainScreen].bounds.size.height;
        if (fScreenHeight == 568.0) {
            self.stringDeviceType = iPhone4Inch;
        }
        else {
            self.stringDeviceType = iPhone3Dot5Inch;
        }
    }
    NSAssert(self.stringDeviceType, @"StrDeviceType is nil");
    DEBUGMSG(@"Device Type: %@", self.stringDeviceType);
}

- (NSString *)getXibNameBasedOnDeviceType:(NSString *)StrBaseXibName
{
    if ([self.stringDeviceType isEqualToString:iPad]) {
        return [NSString stringWithFormat:@"%@%@", StrBaseXibName, iPadXibSuffix];
    }
    return [NSString stringWithFormat:@"%@%@", StrBaseXibName, iPhoneXibSuffix];
}

- (UIImage *)loadImageFromMainBundle:(NSString *)stringFilename
{
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:stringFilename ofType:nil]];
    return image;
}

- (UIImage *)resizeImage:(UIImage *)imageOri width:(float)fResizedWidth height:(float)fResizedHeight
{
    UIGraphicsBeginImageContext(CGSizeMake(fResizedWidth ,fResizedHeight));
    [imageOri drawInRect:CGRectMake(0, 0, fResizedWidth, fResizedHeight)];
    UIImage *imageResult = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return imageResult;
}

- (CGSize)getImageViewSizeWithImageSize:(CGSize)sizeImage basedOnImageViewSize:(CGSize)sizeImageView
{    
    return CGSizeMake(sizeImage.width * (sizeImageView.height / sizeImage.height), sizeImageView.height);
}

- (UIImage *)getImageByView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 1.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)saveAndReplaceImageToFolder:(NSString *)stringFolderPath image:(UIImage *)image imageName:(NSString *)stringImageName
{
    DEBUGMSG(@"saveAndReplaceImageToFolder: %@", stringFolderPath);
    NSFileManager *FM = [NSFileManager defaultManager];
    if (![FM fileExistsAtPath:stringFolderPath]) {
        BOOL bIsSuccessful = [FM createDirectoryAtPath:stringFolderPath withIntermediateDirectories:YES attributes:nil error:nil];
        if (!bIsSuccessful) {
            return;
        }
    }
    [UIImagePNGRepresentation(image) writeToFile:[NSString stringWithFormat:@"%@/%@", stringFolderPath, stringImageName] atomically:YES];
}


- (UIImage *)loadImageFromFolder:(NSString *)stringFolderPath imageName:(NSString *)stringImageName
{
    DEBUGMSG(@"loadImageFromFolder: %@", stringFolderPath);
    NSData *dataImage = [NSData dataWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", stringFolderPath, stringImageName]];
    if (!dataImage || dataImage.length == 0) {
        return nil;
    }
    else {
        return [UIImage imageWithData:dataImage];
    }
}

- (void)clearAllFileInFolder:(NSString *)stringFolderPath
{
    DEBUGMSG(@"clearAllFileInFolder: %@", stringFolderPath);
    NSFileManager *FM = [NSFileManager defaultManager];
    NSError *Err = nil;
    for (NSString *stringFilePath in [FM contentsOfDirectoryAtPath:stringFolderPath error:&Err]) {
        BOOL bIsSuccessful = [FM removeItemAtPath:[NSString stringWithFormat:@"%@/%@", stringFolderPath, stringFilePath] error:&Err];
        if (!bIsSuccessful) {
            return;
        }
    }
}

- (void)removeFileInFolder:(NSString *)stringFolderPath filename:(NSString *)stringFileName
{
    DEBUGMSG(@"removeFileInFolder: %@", stringFolderPath);
    NSFileManager *FM = [NSFileManager defaultManager];
    NSError *Err = nil;
    BOOL bIsSuccessful = [FM removeItemAtPath:[NSString stringWithFormat:@"%@/%@", stringFolderPath, stringFileName] error:&Err];
    if (!bIsSuccessful) {
        return;
    }
}

- (UIImage *)getImageByLanguage:(NSString *)stringImageName
{
    DEBUGMSG(@"load Image: %@", [NSString stringWithFormat:@"%@_%@.png", stringImageName, self.stringLanguage]);
    return [UIImage imageNamed:[NSString stringWithFormat:@"%@_%@.png", stringImageName, self.stringLanguage]];
}

- (UIImage *)getImageByCombiningBaseView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 1.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
