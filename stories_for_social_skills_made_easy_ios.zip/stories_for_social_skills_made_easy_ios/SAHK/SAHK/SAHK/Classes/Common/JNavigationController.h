//
//  JNavigationController.h
//
//  Created by Jeff Cheung on 12年10月26日.
//  Copyright (c) 2012年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JNavigationController : UINavigationController

#pragma mark - Core

- (void)OriginalPushViewController:(UIViewController *)viewController animated:(BOOL)animated;
- (NSArray *)OriginalPopToRootViewControllerAnimated:(BOOL)animated;

@end
