//
//  CoreData.h
//
//  Created by Jeff Cheung on 12年10月26日.
//  Copyright (c) 2012年 Jeff Cheung. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LeftRootViewController.h"
#import "MFSideMenuContainerViewController.h"

@interface CoreData : NSObject

@property (nonatomic, assign) float fOSVersion;
@property (nonatomic, retain) NSOperationQueue *OQCommonQueue;
@property (nonatomic, retain) NSOperationQueue *OQGraphicQueue;
@property (nonatomic, retain) JNavigationController *JNC;
@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) NSString *stringDeviceType;
@property (nonatomic, retain) LeftRootViewController *VCLeftRoot;
@property (nonatomic, retain) MFSideMenuContainerViewController *VCSideMenuContainer;
@property (nonatomic, retain) NSString *stringLanguage, *stringVoice, *stringNotificationCenter;
@property (nonatomic, retain) NSString *stringServiceUUID;
@property (nonatomic, retain) NSString *stringCharacteristicUUID;
@property (nonatomic, retain) NSString *stringDeviceID;

#pragma mark - Core

+ (CoreData *)sharedCoreData;
- (void)checkAndSaveDeviceType;
- (NSString *)getXibNameBasedOnDeviceType:(NSString *)StrBaseXibName;
- (UIImage *)loadImageFromMainBundle:(NSString *)stringFilename;
- (UIImage *)resizeImage:(UIImage *)imageOri width:(float)fResizedWidth height:(float)fResizedHeight;
- (CGSize)getImageViewSizeWithImageSize:(CGSize)sizeImage basedOnImageViewSize:(CGSize)sizeImageView;
- (UIImage *)getImageByView:(UIView *)view;
- (void)saveAndReplaceImageToFolder:(NSString *)stringFolderPath image:(UIImage *)image imageName:(NSString *)stringImageName;
- (UIImage *)loadImageFromFolder:(NSString *)stringFolderPath imageName:(NSString *)stringImageName;
- (void)clearAllFileInFolder:(NSString *)stringFolderPath;
- (void)removeFileInFolder:(NSString *)stringFolderPath filename:(NSString *)stringFileName;
- (UIImage *)getImageByLanguage:(NSString *)stringImageName;
- (UIImage *)getImageByCombiningBaseView:(UIView *)view;

@end
