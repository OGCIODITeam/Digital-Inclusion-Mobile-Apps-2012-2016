//
//  SettingsViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月19日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface SettingsViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet UIButton *leftBtn;

    IBOutlet UIImageView *bgImg1;

    IBOutlet UIImageView *bgImg11;
    IBOutlet UIImageView *bgImg2;
    
    IBOutlet UIImageView *bgImg3;
    
    
    IBOutlet UIImageView *bgImg4;
    
}

@end
