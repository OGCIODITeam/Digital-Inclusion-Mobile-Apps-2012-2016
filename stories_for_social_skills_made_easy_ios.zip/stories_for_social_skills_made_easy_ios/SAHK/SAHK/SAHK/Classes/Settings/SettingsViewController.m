//
//  SettingsViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月19日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "SettingsViewController.h"

#define DeleteCustomBookAVTag 102

@interface SettingsViewController () <UIAlertViewDelegate>

@property (nonatomic, retain) IBOutlet UILabel *labelAboutUs, *labelLanguage, *labelVoice, *labelDeleteAllCustomBook, *labelNotificationCenter;
@property (nonatomic, retain) IBOutlet UIButton *buttonLanguage, *buttonVoice, *buttonDeleteAllCustomBook, *buttonNotificationCenter;

@property (nonatomic, retain) NSString *stringLangValue, *stringVoiceValue, *stringNotificationCenterValue;

@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

@property (nonatomic, retain) IBOutlet UITextView *TVSettingsWording;

#pragma mark - Core

- (void)setup;
- (void)setupView;

- (void)setLanguage:(NSString *)stringLangValue;
- (void)setVoice:(NSString *)stringVoiceValue;
- (void)setNotificationCenter:(NSString *)stringNotificationCenterValue;

#pragma mark - Handle Click Button Events

- (IBAction)clickOpenLeftMenuButton:(UIButton *)button;
- (IBAction)clickLanguageButton:(UIButton *)button;
- (IBAction)clickVoiceButton:(UIButton *)button;
- (IBAction)clickDeleteAllCustomBookButton:(UIButton *)button;
- (IBAction)clickNotificationCenterButton:(UIButton *)button;

@end

@implementation SettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.labelAboutUs = nil;
    self.labelLanguage = nil;
    self.labelVoice = nil;
    self.labelDeleteAllCustomBook = nil;
    self.labelNotificationCenter = nil;
    
    self.buttonLanguage = nil;
    self.buttonVoice = nil;
    self.buttonDeleteAllCustomBook = nil;
    self.buttonNotificationCenter = nil;
    
    self.IVTitle = nil;
    
    self.TVSettingsWording = nil;
    [topNav release];
    [leftBtn release];
    [bgImg1 release];
    [bgImg2 release];
    [bgImg3 release];
    [bgImg4 release];
    [bgImg11 release];
    [leftBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        bgImg1.frame=CGRectMake(bgImg1.frame.origin.x, bgImg1.frame.origin.y+20, bgImg1.frame.size.width, bgImg1.frame.size.height);
        bgImg11.frame=CGRectMake(bgImg11.frame.origin.x, bgImg11.frame.origin.y+20, bgImg11.frame.size.width, bgImg11.frame.size.height);
        bgImg2.frame=CGRectMake(bgImg2.frame.origin.x, bgImg2.frame.origin.y+20, bgImg2.frame.size.width, bgImg2.frame.size.height);
        bgImg3.frame=CGRectMake(bgImg3.frame.origin.x, bgImg3.frame.origin.y+20, bgImg3.frame.size.width, bgImg3.frame.size.height);
        bgImg4.frame=CGRectMake(bgImg4.frame.origin.x, bgImg4.frame.origin.y+20, bgImg4.frame.size.width, bgImg4.frame.size.height);

        
        self.labelAboutUs.frame=CGRectMake( self.labelAboutUs.frame.origin.x,  self.labelAboutUs.frame.origin.y+20,  self.labelAboutUs.frame.size.width,  self.labelAboutUs.frame.size.height);
        
         self.labelLanguage.frame=CGRectMake( self.labelLanguage.frame.origin.x,  self.labelLanguage.frame.origin.y+20,  self.labelLanguage.frame.size.width,  self.labelLanguage.frame.size.height);
        
        self.labelVoice.frame=CGRectMake( self.labelVoice.frame.origin.x,  self.labelVoice.frame.origin.y+20,  self.labelVoice.frame.size.width,  self.labelVoice.frame.size.height);
        
         self.labelDeleteAllCustomBook.frame=CGRectMake( self.labelDeleteAllCustomBook.frame.origin.x,  self.labelDeleteAllCustomBook.frame.origin.y+20,  self.labelDeleteAllCustomBook.frame.size.width,  self.labelDeleteAllCustomBook.frame.size.height);
        
        self.labelNotificationCenter.frame=CGRectMake( self.labelNotificationCenter.frame.origin.x,  self.labelNotificationCenter.frame.origin.y+20,  self.labelNotificationCenter.frame.size.width,  self.labelNotificationCenter.frame.size.height);
        
        
          self.buttonLanguage.frame=CGRectMake( self.buttonLanguage.frame.origin.x,  self.buttonLanguage.frame.origin.y+20,  self.buttonLanguage.frame.size.width,  self.buttonLanguage.frame.size.height);
          self.buttonVoice.frame=CGRectMake( self.buttonVoice.frame.origin.x,  self.buttonVoice.frame.origin.y+20,  self.buttonVoice.frame.size.width,  self.buttonVoice.frame.size.height);
          self.buttonDeleteAllCustomBook.frame=CGRectMake( self.buttonDeleteAllCustomBook.frame.origin.x,  self.buttonDeleteAllCustomBook.frame.origin.y+20,  self.buttonDeleteAllCustomBook.frame.size.width,  self.buttonDeleteAllCustomBook.frame.size.height);
          self.buttonNotificationCenter.frame=CGRectMake( self.buttonNotificationCenter.frame.origin.x,  self.buttonNotificationCenter.frame.origin.y+20,  self.buttonNotificationCenter.frame.size.width,  self.buttonNotificationCenter.frame.size.height);
        
        self.TVSettingsWording.frame=CGRectMake( self.TVSettingsWording.frame.origin.x,  self.TVSettingsWording.frame.origin.y+20,  self.TVSettingsWording.frame.size.width,  self.TVSettingsWording.frame.size.height-20);

    }
    [self.buttonDeleteAllCustomBook setTitle:@"删除" forState:UIControlStateNormal];
    [self.buttonDeleteAllCustomBook setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonDeleteAllCustomBook setImage:[UIImage imageNamed:@"settings_delete_2.png"] forState:UIControlStateNormal];

    
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [self setup];
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    NSUserDefaults *UD = [NSUserDefaults standardUserDefaults];
    self.stringLangValue = [UD objectForKey:@"language"];
    self.stringVoiceValue = [UD objectForKey:@"voice"];
    self.stringNotificationCenterValue = [UD objectForKey:@"notificationCenter"];
}

- (void)setupView
{
//    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"settings_setting"];
//    self.labelAboutUs.text = LocalizedString(@"about_us");
//    self.labelLanguage.text = LocalizedString(@"language");
//    self.labelVoice.text = LocalizedString(@"voice");
//    self.labelDeleteAllCustomBook.text = LocalizedString(@"delete_all_custom_book");
//    self.labelNotificationCenter.text = LocalizedString(@"notification_center");
    
    [self setLanguage:self.stringLangValue];
    [self setVoice:self.stringVoiceValue];
    [self setNotificationCenter:self.stringNotificationCenterValue];
    self.TVSettingsWording.text = LocalizedString(@"settings_worlding");
}

- (void)setLanguage:(NSString *)stringLangValue
{
    DEBUGMSG(@"setLanguage:%@", stringLangValue);
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"settings_setting"];
    self.labelAboutUs.text = LocalizedString(@"about_us");
    self.labelLanguage.text = LocalizedString(@"language");
    self.labelVoice.text = LocalizedString(@"voice");
    self.labelDeleteAllCustomBook.text = LocalizedString(@"delete_all_custom_book");
    self.labelNotificationCenter.text = LocalizedString(@"notification_center");
    
    if (stringLangValue && [stringLangValue isEqualToString:@"s"]) {
        [self.buttonLanguage setImage:[UIImage imageNamed:@"settings_simp.png"] forState:UIControlStateNormal];
        [self.buttonLanguage setTitle:@"简体" forState:UIControlStateNormal];
        [self.buttonLanguage setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    }
    else {
        [self.buttonLanguage setImage:[UIImage imageNamed:@"settings_trad.png"] forState:UIControlStateNormal];
        [self.buttonLanguage setTitle:@"繁体" forState:UIControlStateNormal];
        [self.buttonLanguage setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    }
    
    [[CoreData sharedCoreData].VCLeftRoot reloadView];
}

- (void)setVoice:(NSString *)stringVoiceValue
{
    if (stringVoiceValue && [stringVoiceValue isEqualToString:@"m"]) {
        [self.buttonVoice setImage:[UIImage imageNamed:@"settings_Mandarin.png"] forState:UIControlStateNormal];
        [self.buttonVoice setTitle:@"普通话朗读" forState:UIControlStateNormal];
        [self.buttonVoice setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    }
    else {
        [self.buttonVoice setImage:[UIImage imageNamed:@"settings_Cantonese.png"] forState:UIControlStateNormal];
        [self.buttonVoice setTitle:@"粤语朗读" forState:UIControlStateNormal];
        [self.buttonVoice setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    }
}

- (void)setNotificationCenter:(NSString *)stringNotificationCenterValue
{
    if (stringNotificationCenterValue && [stringNotificationCenterValue isEqualToString:@"on"]) {
        [self.buttonNotificationCenter setImage:[UIImage imageNamed:@"settings_on.png"] forState:UIControlStateNormal];
        [self.buttonNotificationCenter setTitle:@"通知中心已打开" forState:UIControlStateNormal];
        [self.buttonNotificationCenter setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    }
    else {
        [self.buttonNotificationCenter setImage:[UIImage imageNamed:@"settings_off.png"] forState:UIControlStateNormal];
        [self.buttonNotificationCenter setTitle:@"通知中心已关闭" forState:UIControlStateNormal];
        [self.buttonNotificationCenter setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    }
}

#pragma mark - Handle Click Button Events

- (IBAction)clickOpenLeftMenuButton:(UIButton *)button
{
    [[CoreData sharedCoreData].VCSideMenuContainer openLeftMenu];
}

- (IBAction)clickLanguageButton:(UIButton *)button
{
    if (self.stringLangValue && [self.stringLangValue isEqualToString:@"s"]) {
        self.stringLangValue = @"t";
    }
    else {
        self.stringLangValue = @"s";
    }
    
    NSUserDefaults *UD = [NSUserDefaults standardUserDefaults];
    [UD setObject:self.stringLangValue forKey:@"language"];
    [UD synchronize];
    [CoreData sharedCoreData].stringLanguage = self.stringLangValue;
    [self setLanguage:self.stringLangValue];
}

- (IBAction)clickVoiceButton:(UIButton *)button
{
    if (self.stringVoiceValue && [self.stringVoiceValue isEqualToString:@"m"]) {
        self.stringVoiceValue = @"c";
    }
    else {
        self.stringVoiceValue = @"m";
    }
    
    NSUserDefaults *UD = [NSUserDefaults standardUserDefaults];
    [UD setObject:self.stringVoiceValue forKey:@"voice"];
    [UD synchronize];
    [CoreData sharedCoreData].stringVoice = self.stringVoiceValue;
    [self setVoice:self.stringVoiceValue];
}

- (IBAction)clickDeleteAllCustomBookButton:(UIButton *)button
{
    UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"confirm_deleted_all_custom_book") delegate:self cancelButtonTitle:LocalizedString(@"cm_cancel") otherButtonTitles:LocalizedString(@"cm_ok"), nil];
    AV.tag = DeleteCustomBookAVTag;
    [AV show];
    [AV release];
}

- (IBAction)clickNotificationCenterButton:(UIButton *)button
{
    if (self.stringNotificationCenterValue && [self.stringNotificationCenterValue isEqualToString:@"on"]) {
        self.stringNotificationCenterValue = @"off";
    }
    else {
        self.stringNotificationCenterValue = @"on";
    }
    
    NSUserDefaults *UD = [NSUserDefaults standardUserDefaults];
    [UD setObject:self.stringNotificationCenterValue forKey:@"notificationCenter"];
    [UD synchronize];
    
    [self setNotificationCenter:self.stringNotificationCenterValue];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == DeleteCustomBookAVTag && buttonIndex == 1) {
        DEBUGMSG(@"clear all file in custom folder");
        [[CoreData sharedCoreData] clearAllFileInFolder:PathCustomFolder];
    }
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [bgImg1 release];
    bgImg1 = nil;
    [bgImg2 release];
    bgImg2 = nil;
    [bgImg3 release];
    bgImg3 = nil;
    [bgImg4 release];
    bgImg4 = nil;
    [bgImg11 release];
    bgImg11 = nil;
    [leftBtn release];
    leftBtn = nil;
    [super viewDidUnload];
}
@end
