//
//  CuttingImageView.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月4日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "CuttingImageView.h"
#import <QuartzCore/QuartzCore.h>

@interface CuttingImageView ()

@property (nonatomic, assign) CGPoint pointTouchStart, pointTouchEnd;
@property (nonatomic, assign) BOOL bCanMove;
@property (nonatomic, assign) CGPoint pointCenter;

#pragma mark - Core

- (BOOL)hasColorOfPoint:(CGPoint)point;

@end

@implementation CuttingImageView

@synthesize bIsCuttingMode = _bIsCuttingMode;
@synthesize MATouchPoint = _MATouchPoint;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [self.MATouchPoint removeAllObjects];
    self.MATouchPoint = nil;
    [super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.MATouchPoint = [[NSMutableArray new] autorelease];
    
}

#pragma mark - Core

- (BOOL)hasColorOfPoint:(CGPoint)point
{
    unsigned char pixel[4] = {0};
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pixel, 1, 1, 8, 4, colorSpace, kCGImageAlphaPremultipliedLast);
    CGContextTranslateCTM(context, -point.x, -point.y);
    [self.layer renderInContext:context];
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    
    if (pixel[0] == 0 &&  pixel[1] == 0 && pixel[2] == 0 && pixel[3] == 0) {
        return NO;
    }
    return YES;
}

#pragma mark - UITouch

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if ([touch tapCount] != 1)
        return;
    
    if (self.bIsCuttingMode) {
        self.pointTouchStart = [touch locationInView:self];
        [self.MATouchPoint removeAllObjects];
        [self.MATouchPoint addObject:[NSString stringWithFormat:@"%f,%f", self.pointTouchStart.x, self.pointTouchStart.y]];
        //DEBUGMSG(@"start point: %f, %f", self.pointTouchStart.x, self.pointTouchStart.y);
    }
    else {
        self.pointCenter = self.center;
        self.pointTouchStart = [touch locationInView:self.superview];
        self.bCanMove = [self hasColorOfPoint:[touch locationInView:self]];
        //DEBUGMSG(@"pointTouchStartCenter: %f, %f, pointTouchStart: %f, %f", self.pointCenter.x, self.pointCenter.y, self.pointTouchStart.x, self.pointTouchStart.y);
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesMoved:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if ([touch tapCount] != 1)
        return;
    
    if (self.bIsCuttingMode) {
        self.pointTouchEnd = [touch locationInView:self];
        
        UIGraphicsBeginImageContext(self.frame.size);
        [self.image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        
        CGContextRef contextRef = UIGraphicsGetCurrentContext();
        CGContextSetLineCap(contextRef, kCGLineCapRound);
        CGContextSetLineWidth(contextRef, 4.0);
        CGContextSetRGBStrokeColor(contextRef, 250.0 / 255.0, 51.0/ 255.0, 37.0 / 255.0, 1.0);
        
        CGContextBeginPath(contextRef);
        CGContextMoveToPoint(contextRef, self.pointTouchStart.x, self.pointTouchStart.y);
        CGContextAddLineToPoint(contextRef, self.pointTouchEnd.x, self.pointTouchEnd.y);
        CGContextStrokePath(contextRef);
        self.image = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        DEBUGMSG(@"self:%@\nstart point: %f, %f\nend point: %f, %f", self, self.pointTouchStart.x, self.pointTouchStart.y, self.pointTouchEnd.x, self.pointTouchEnd.y);
        self.pointTouchStart = self.pointTouchEnd;
        [self.MATouchPoint addObject:[NSString stringWithFormat:@"%f,%f", self.pointTouchEnd.x, self.pointTouchEnd.y]];
//        DEBUGMSG(@"self:%@\nend point: %f, %f", self, self.pointTouchEnd.x, self.pointTouchEnd.y);
    }
    else if (self.bCanMove) {
        self.pointTouchEnd = [touch locationInView:self.superview];
        self.center = CGPointMake(self.pointCenter.x + (self.pointTouchEnd.x - self.pointTouchStart.x), self.pointCenter.y + (self.pointTouchEnd.y - self.pointTouchStart.y));
        //DEBUGMSG(@"center: %f, %f", self.center.x, self.center.y);
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesEnded:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    
    if (self.bIsCuttingMode) {
        self.pointTouchEnd = [touch locationInView:self];
        [self.MATouchPoint addObject:[NSString stringWithFormat:@"%f,%f", self.pointTouchEnd.x, self.pointTouchEnd.y]];
        //DEBUGMSG(@"end point: %f, %f", self.pointTouchEnd.x, self.pointTouchEnd.y);
    }
    else if (self.bCanMove){
        self.pointTouchEnd = [touch locationInView:self.superview];
        self.center = CGPointMake(self.pointCenter.x + (self.pointTouchEnd.x - self.pointTouchStart.x), self.pointCenter.y + (self.pointTouchEnd.y - self.pointTouchStart.y));
        //DEBUGMSG(@"center: %f, %f", self.center.x, self.center.y);
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesCancelled:touches withEvent:event];
}


@end
