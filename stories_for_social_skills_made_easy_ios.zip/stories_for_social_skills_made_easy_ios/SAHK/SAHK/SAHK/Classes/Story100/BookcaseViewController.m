//
//  BookcaseViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookcaseViewController.h"
#import "BookcaseTableViewCell.h"
#import "BookcaseHeaderTableViewCell.h"

@interface BookcaseViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, retain) IBOutlet UITableView *TBVBookcase;
@property (nonatomic, assign) BOOL bShowRating;

@end

@implementation BookcaseViewController

@synthesize MABook = _MABook;
@synthesize delegateBookcaseViewController = _delegateBookcaseViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.bShowRating = NO;
    }
    return self;
}

- (void)dealloc
{
    self.TBVBookcase.delegate = nil;
    self.TBVBookcase.dataSource = nil;
    self.TBVBookcase = nil;
    
    [self.MABook removeAllObjects];
    self.MABook = nil;
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)refreshBookcase
{
    [self.TBVBookcase reloadData];
}

- (void)showRating:(BOOL)bShowRating
{
    self.bShowRating = bShowRating;
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.MABook.count + 1;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        if (indexPath.row == 0) {
            return 68.0;
        }
        return (20.0 + 100.0 + 20.0);
    }
    if (indexPath.row == 0) {
        return 38.0;
    }
    return (10.0 + 74.0 + 10.0);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        static NSString *identifier = @"BookcaseHeaderTableViewCell";
        BookcaseHeaderTableViewCell *cell = (BookcaseHeaderTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseHeaderTableViewCell"] owner:nil options:nil];
            for(id currentObject in objectArray) {
                if([currentObject isKindOfClass:[UITableViewCell class]]) {
                    cell = (BookcaseHeaderTableViewCell *)currentObject;
                    cell.backgroundColor=[UIColor clearColor];

                    cell.userInteractionEnabled=NO;
                    cell.titleClearLbl.text=self.clearTitle;
                  

                    break;
                }
            }
        }
        
        return cell;
    }

    static NSString *identifier = @"BookcaseTableViewCell";
    BookcaseTableViewCell *cell = (BookcaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseTableViewCell"] owner:nil options:nil];
        for(id currentObject in objectArray) {
            if([currentObject isKindOfClass:[UITableViewCell class]]) {
                cell = (BookcaseTableViewCell *)currentObject;
                cell.backgroundColor=[UIColor clearColor];
//                if (IOS7_OR_LATER) {
//                    cell.contentView.superview.backgroundColor=[UIColor redColor];
//                    cell.contentView.backgroundColor=[UIColor clearColor];
//                    
//                }
                break;
            }
        }
    }
    
    NSString *stringBookCoverImageName = @"story";
    
    stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:[[self.MABook objectAtIndex:indexPath.row - 1] objectForKey:@"bookID"]];
    
    if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
        stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
    }
    else {
        stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"];
    }
    [cell reset];
    cell.stringBookID = [[self.MABook objectAtIndex:indexPath.row - 1] objectForKey:@"bookID"];
    [cell setupView:[UIImage imageNamed:stringBookCoverImageName]];
    cell.clearLbl.text=[self.titleArray objectAtIndex:indexPath.row - 1];

    [cell showRating:self.bShowRating];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.delegateBookcaseViewController && [self.delegateBookcaseViewController respondsToSelector:@selector(selectedBook:)]) {
        [self.delegateBookcaseViewController selectedBook:[self.MABook objectAtIndex:indexPath.row - 1]];
    }
}

@end
