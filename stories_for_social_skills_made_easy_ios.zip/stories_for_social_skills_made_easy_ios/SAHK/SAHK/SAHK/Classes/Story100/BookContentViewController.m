//
//  BookContentViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookContentViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "NewHeadViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "CuttingImageView.h"
#import "LeftMenuButton.h"

#define RecoverAVTag 200
#define EditModeDoneAVTag 201

@interface BookContentViewController () <UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, AVAudioPlayerDelegate, UIPopoverControllerDelegate, LeftMenuButtonDelegate, UIAlertViewDelegate>

@property (nonatomic, retain) IBOutlet UIView *viewControl, *viewControlNonEdit, *viewControlEdit;
@property (nonatomic, retain) IBOutlet UIImageView *IVStory;
@property (nonatomic, retain) IBOutlet UITextView *TVStory;
@property (nonatomic, retain) IBOutlet UIToolbar *toolbarTVStory;
@property (nonatomic, retain) IBOutlet UIView *viewBase;
@property (nonatomic, retain) AVAudioPlayer *AP, *APRecordMode;
@property (nonatomic, assign) int iBookID;
@property (nonatomic, assign) int iCurrentPageIndex;
@property (nonatomic, retain) NSDictionary *dictionaryStoryText;
@property (nonatomic, retain) IBOutlet UIButton *buttonPause;
@property (nonatomic, retain) IBOutlet UISwipeGestureRecognizer *SGRLeft, *SGRRight;
@property (nonatomic, assign) int iBookNumOfPage;
@property (nonatomic, retain) UIImagePickerController *IPC;
@property (nonatomic, retain) IBOutlet CuttingImageView *CIVStoryAddHead;
@property (nonatomic, retain) IBOutlet UIView *viewStoryImageBase;
@property (nonatomic, retain) IBOutlet UIButton *buttonBookmark, *buttonSave, *buttonControl, *buttonRecover, *buttonEditModeDone;
@property (nonatomic, assign) BOOL bClickedEditButton;
@property (nonatomic, retain) AVAudioRecorder *AR;

@property (nonatomic, retain) IBOutlet UIImageView *IVTitleStory100, *IVTitleCustomStory;

@property (nonatomic, retain) IBOutlet UIView *viewRecordModeBase;
@property (nonatomic, retain) IBOutlet UIButton *buttonRecordModeRecordButton, *buttonRecordModePlayButton;
@property (nonatomic, retain) IBOutlet UILabel *labelRecordModeTimeValue, *labelRecordModeStatusValue;
@property (nonatomic, retain) NSTimer *timerRecordMode;
@property (nonatomic, retain) NSString *stringRecordModeCurrentSoundFilePath;
@property (nonatomic, retain) NSString *stringContentFileName;
@property (nonatomic, retain) NSDateFormatter *DF;
@property (nonatomic, retain) NSString *stringCustomStoryFolderPath;
@property (nonatomic, retain) UIPopoverController *PC;

@property (nonatomic, retain) IBOutlet UIButton *buttonNewHeadImage;

@property (nonatomic, retain) IBOutlet UIButton *buttonRecordModeRedo, *buttonRecordModeDone;

@property (nonatomic, retain) IBOutlet LeftMenuButton *LMB;


#pragma mark - Core

- (void)setup;
- (void)setupView;
- (void)setImageTextPlayAudio;
- (void)saveCustomStoryImageToEditFolder;
- (void)saveCustomStoryTextToEditFolder;
- (void)doRecoverForCurrentPage;
- (void)displayRecorderCurrentTime;

#pragma mark - Handle Click Button Events

- (IBAction)clickEditButton:(UIButton *)button;
- (IBAction)clickControlButton:(UIButton *)button;
- (IBAction)clickTVStoryDoneButton:(UIBarButtonItem *)BBI;
- (IBAction)clickPauseButton:(UIButton *)button;
- (IBAction)clickNewHeadImageButton:(UIButton *)button;
- (IBAction)clickStartToRecordSoundButton:(UIButton *)button;
- (IBAction)clickRecoverButton:(UIButton *)button;
- (IBAction)clickSaveButton:(UIButton *)button;
- (IBAction)clickBookmarkButton:(UIButton *)button;
- (IBAction)clickEditModeDoneButton:(UIButton *)button;
- (IBAction)clickRecordModeRecordButton:(UIButton *)button;
- (IBAction)clickRecordModePlayButton:(UIButton *)button;
- (IBAction)clickRecordModeRedoButton:(UIButton *)button;
- (IBAction)clickRecordModeDoneButton:(UIButton *)button;
- (IBAction)clickRecordModeCloseButton:(UIButton *)button;

#pragma mark - Handle Gesture Recognizer Events

- (IBAction)swipeLeftGestureRecognizer:(UISwipeGestureRecognizer *)SGR;
- (IBAction)swipeRightGestureRecognizer:(UISwipeGestureRecognizer *)SGR;

@end

@implementation BookContentViewController

@synthesize dictionaryBook = _dictionaryBook;
@synthesize imageFromVCNewHead = _imageFromVCNewHead;
@synthesize bIsEditMode = _bIsEditMode;
@synthesize bPushFromBookmarkView = _bPushFromBookmarkView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.bIsEditMode = NO;
        self.bClickedEditButton = NO;
        self.bPushFromBookmarkView = NO;
    }
    return self;
}

- (void)dealloc
{
    self.dictionaryBook = nil;
    self.viewControl = nil;
    self.viewControlNonEdit = nil;
    self.viewControlEdit = nil;
    
    [self.IVStory.layer removeAllAnimations];
    self.IVStory.image = nil;
    self.IVStory = nil;
    
    [self.TVStory.layer removeAllAnimations];
    self.TVStory.delegate = nil;
    self.TVStory.inputAccessoryView = nil;
    self.TVStory = nil;
    
    self.toolbarTVStory = nil;
    
    self.viewBase = nil;
    
    [self.AP stop];
    self.AP = nil;
    
    self.dictionaryStoryText = nil;
    
    self.buttonPause = nil;
    
    [self.SGRLeft removeTarget:self action:@selector(swipeLeftGestureRecognizer:)];
    self.SGRLeft = nil;
    [self.SGRRight removeTarget:self action:@selector(swipeRightGestureRecognizer:)];
    self.SGRRight = nil;
    
    self.IPC.delegate = nil;
    self.IPC = nil;
    
    self.imageFromVCNewHead = nil;
    
    self.CIVStoryAddHead.image = nil;
    self.CIVStoryAddHead = nil;
    
    self.viewStoryImageBase = nil;
    
    self.buttonBookmark = nil;
    self.buttonSave = nil;
    self.buttonControl = nil;
    self.buttonRecover = nil;
    
    [[CoreData sharedCoreData] clearAllFileInFolder:PathEditFolder];
    
    self.IVTitleStory100.image = nil;
    self.IVTitleStory100 = nil;
    self.IVTitleCustomStory.image = nil;
    self.IVTitleCustomStory = nil;
    
    [self.AR stop];
    self.AR = nil;
    
    self.viewRecordModeBase = nil;
    self.buttonRecordModeRecordButton = nil;
    self.buttonRecordModePlayButton = nil;
    self.labelRecordModeTimeValue = nil;
    self.labelRecordModeStatusValue = nil;
    
    [self.timerRecordMode invalidate];
    self.timerRecordMode = nil;
    
    self.stringRecordModeCurrentSoundFilePath = nil;
    
    [self.APRecordMode stop];
    self.APRecordMode.delegate = nil;
    self.APRecordMode = nil;
    
    self.stringContentFileName = nil;
    
    self.DF = nil;
    
    self.stringCustomStoryFolderPath = nil;
    
    self.PC.delegate = nil;
    self.PC = nil;
    
    self.buttonNewHeadImage = nil;
    
    self.buttonRecordModeRedo = nil;
    self.buttonEditModeDone = nil;
    
    self.LMB.delegateLeftMenuButton = nil;
    self.LMB = nil;
    
    DEBUGMSG(@"%@: dealloc", self.class);
    [topNav release];
    [leftBtn release];
    [editBtn release];
    [bookMarkBtn release];
    [saveBtn release];
    [startRecordBtn release];
    [closeRecordBtn release];
    [titleText release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    if (IOS7_OR_LATER) {
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        editBtn.frame=CGRectMake(editBtn.frame.origin.x, editBtn.frame.origin.y+20, editBtn.frame.size.width, editBtn.frame.size.height);
        bookMarkBtn.frame=CGRectMake(bookMarkBtn.frame.origin.x, bookMarkBtn.frame.origin.y+20, bookMarkBtn.frame.size.width, bookMarkBtn.frame.size.height);
        
        saveBtn.frame=CGRectMake(saveBtn.frame.origin.x, saveBtn.frame.origin.y+20, saveBtn.frame.size.width, saveBtn.frame.size.height);
        self.IVTitleStory100.frame=CGRectMake(self.IVTitleStory100.frame.origin.x, self.IVTitleStory100.frame.origin.y+20, self.IVTitleStory100.frame.size.width, self.IVTitleStory100.frame.size.height);
        
        //        self.SVBookBase.frame=CGRectMake( self.SVBookBase.frame.origin.x,  self.SVBookBase.frame.origin.y+20,  self.SVBookBase.frame.size.width,  self.SVBookBase.frame.size.height-20);
        self.IVTitleCustomStory.frame=CGRectMake( self.IVTitleCustomStory.frame.origin.x,  self.IVTitleCustomStory.frame.origin.y+20,  self.IVTitleCustomStory.frame.size.width,  self.IVTitleCustomStory.frame.size.height);
        
        
         self.viewStoryImageBase.frame=CGRectMake( self.viewStoryImageBase.frame.origin.x,  self.viewStoryImageBase.frame.origin.y+20,  self.viewStoryImageBase.frame.size.width,  self.viewStoryImageBase.frame.size.height);
        
         self.buttonRecover.frame=CGRectMake( self.buttonRecover.frame.origin.x,  self.buttonRecover.frame.origin.y+20,  self.buttonRecover.frame.size.width,  self.buttonRecover.frame.size.height);
        
         self.buttonEditModeDone.frame=CGRectMake( self.buttonEditModeDone.frame.origin.x,  self.buttonEditModeDone.frame.origin.y+20,  self.buttonEditModeDone.frame.size.width,  self.buttonEditModeDone.frame.size.height);
        
         self.TVStory.frame=CGRectMake( self.TVStory.frame.origin.x,  self.TVStory.frame.origin.y+20,  self.TVStory.frame.size.width,  self.TVStory.frame.size.height);
        
        
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        
        
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [editBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [editBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [editBtn setImage:[UIImage imageNamed:@"story100_pen_1.png"] forState:UIControlStateNormal];
    [editBtn setImage:[UIImage imageNamed:@"story100_pen_2.png"] forState:UIControlStateSelected];

    [bookMarkBtn setTitle:@"加入书签" forState:UIControlStateNormal];
    [bookMarkBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [bookMarkBtn setImage:[UIImage imageNamed:@"story100_add_1.png"] forState:UIControlStateNormal];

    [saveBtn setTitle:@"保存" forState:UIControlStateNormal];
    [saveBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [saveBtn setImage:[UIImage imageNamed:@"story100_save_1.png"] forState:UIControlStateNormal];

    [self.buttonRecover setTitle:@"确定回复图片" forState:UIControlStateNormal];
    [self.buttonRecover setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
    [self.buttonRecover setImage:[UIImage imageNamed:@"story100_recover_bu_1.png"] forState:UIControlStateNormal];

    [self.buttonEditModeDone setTitle:@"确定合并图片" forState:UIControlStateNormal];
    [self.buttonEditModeDone setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
    [self.buttonEditModeDone setImage:[UIImage imageNamed:@"story100_btn_enter_1.png"] forState:UIControlStateNormal];

    
    [self.buttonControl setTitle:@"展开" forState:UIControlStateNormal];
    [self.buttonControl setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
//    [self.buttonControl setImage:[UIImage imageNamed:@"story100_save_1.png"] forState:UIControlStateNormal];

    
    [ self.buttonPause setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [ self.buttonPause setTitle:@"暂停" forState:UIControlStateNormal];
//    [saveBtn setImage:[UIImage imageNamed:@"story100_save_1.png"] forState:UIControlStateNormal];

    
    [ self.buttonRecordModeRedo setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [ self.buttonRecordModeRedo setTitle:@"重做" forState:UIControlStateNormal];
    [self.buttonRecordModeRedo setImage:[UIImage imageNamed:@"story100_redo_1.png"] forState:UIControlStateNormal];

    
    [ self.buttonRecordModeDone setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [ self.buttonRecordModeDone setTitle:@"确定" forState:UIControlStateNormal];
    [self.buttonRecordModeDone setImage:[UIImage imageNamed:@"story100_ok_1.png"] forState:UIControlStateNormal];

    
    [self.buttonNewHeadImage setTitle:@"新增头像" forState:UIControlStateNormal];
    [self.buttonNewHeadImage setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
    [self.buttonNewHeadImage setImage:[UIImage imageNamed:@"story100_camera_2.png"] forState:UIControlStateNormal];

    
    [startRecordBtn setTitle:@"开始录音" forState:UIControlStateNormal];
    [startRecordBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [startRecordBtn setImage:[UIImage imageNamed:@"story100_begin_record_2.png"] forState:UIControlStateNormal];


    [closeRecordBtn setTitle:@"关闭录音" forState:UIControlStateNormal];
    [closeRecordBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
//    [closeRecordBtn setImage:[UIImage imageNamed:@"cm_x_1.png"] forState:UIControlStateNormal];

    
    [self.buttonRecordModeRecordButton setTitle:@"点击开始录音" forState:UIControlStateNormal];
    [self.buttonRecordModeRecordButton setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
    [self.buttonRecordModeRecordButton setImage:[UIImage imageNamed:@"story100_record_2.png"] forState:UIControlStateNormal];

    
//    [startRecordBtn setTitle:@"开始录音" forState:UIControlStateNormal];
//    [startRecordBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self setup];
    [self setupView];
    titleText.text=@"故事内容";

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (self.bIsEditMode && self.imageFromVCNewHead) {
        self.CIVStoryAddHead.image = self.imageFromVCNewHead;
        self.CIVStoryAddHead.userInteractionEnabled = YES;
        self.CIVStoryAddHead.bIsCuttingMode = NO;
        CGSize size =  [[CoreData sharedCoreData] getImageViewSizeWithImageSize:CGSizeMake(self.imageFromVCNewHead.size.width, self.imageFromVCNewHead.size.height) basedOnImageViewSize:CGSizeMake(self.IVStory.frame.size.width, self.IVStory.frame.size.height)];
        self.CIVStoryAddHead.frame = CGRectMake(0.0, 0.0, size.width, self.CIVStoryAddHead.frame.size.height);
        DEBUGMSG(@"CIVStoryAddHead: %@", self.CIVStoryAddHead);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    NSFileManager *FM = [NSFileManager defaultManager];
    if (![FM fileExistsAtPath:PathEditFolder]) {
        BOOL bIsSuccessful = [FM createDirectoryAtPath:PathEditFolder withIntermediateDirectories:YES attributes:nil error:nil];
        if (!bIsSuccessful) {
            DEBUGMSG(@"create PathEditFolder not successful");
            return;
        }
    }
    [[CoreData sharedCoreData] clearAllFileInFolder:PathEditFolder];
    self.iBookID = [[self.dictionaryBook objectForKey:@"bookID"] intValue];
    self.iCurrentPageIndex = 0;
    self.dictionaryStoryText = [NSDictionary dictionaryWithContentsOfFile:PlistFilename];
    self.iBookNumOfPage = [[[BookPageNum componentsSeparatedByString:@","] objectAtIndex:self.iBookID - 1] intValue];
    self.stringContentFileName = [NSString stringWithFormat:@"storyContent%d.plist", self.iBookID];
    self.DF = [[[NSDateFormatter alloc] init] autorelease];
    [self.DF setDateFormat:@"yyyyMMddHHmmss"];
    self.stringCustomStoryFolderPath = [NSString stringWithFormat:@"%@/%@-%@", PathCustomFolder, [CoreData sharedCoreData].stringDeviceID, [self.DF stringFromDate:[NSDate date]]];
    DEBUGMSG(@"Book ID: %d", self.iBookID);
    DEBUGMSG(@"Number of page: %d", self.iBookNumOfPage);
}

- (void)setupView
{
    self.LMB.delegateLeftMenuButton = self;
    
    if (self.bPushFromBookmarkView) {
        self.buttonBookmark.enabled = NO;
    }
    
    self.IVTitleStory100.image = [[CoreData sharedCoreData] getImageByLanguage:@"story100_story"];
    self.IVTitleCustomStory.image = [[CoreData sharedCoreData] getImageByLanguage:@"sahk_my_story"];
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPhone3Dot5Inch] || [[CoreData sharedCoreData].stringDeviceType isEqualToString:iPhone4Inch]) {
        self.IVStory.frame = self.CIVStoryAddHead.frame = CGRectMake(0.0, 0.0, 320.0, 250.0);
    }
    else {
        self.IVStory.frame = self.CIVStoryAddHead.frame = CGRectMake(0.0, 0.0, 768.0, 600.0);
    }
    
    self.viewControl.frame = CGRectMake(0.0, self.view.frame.size.height - 26.0, self.viewControl.frame.size.width, self.viewControl.frame.size.height);
    self.TVStory.inputAccessoryView = nil;//self.toolbarTVStory;
//    [self setImageTextPlayAudio];
    
    [self performSelector:@selector(setImageTextPlayAudio) withObject:nil afterDelay:2];

}

//call it when swip
- (void)setImageTextPlayAudio
{
    //image
    NSString *stringImageName;
    if (self.iCurrentPageIndex != 0) {
        stringImageName = [NSString stringWithFormat:@"story%d_p%d_%@.png", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringLanguage];
    }
    else {
        stringImageName = [NSString stringWithFormat:@"story%d_c_%@.png", self.iBookID, [CoreData sharedCoreData].stringLanguage];
    }
    
    if (self.bIsEditMode || self.bClickedEditButton) {
        UIImage *imageStoryLoadFromEditFolder = [[CoreData sharedCoreData] loadImageFromFolder:PathEditFolder imageName:stringImageName];
        
        if (imageStoryLoadFromEditFolder) {
            self.IVStory.image = imageStoryLoadFromEditFolder;
        }
        else {
            self.IVStory.image = [[CoreData sharedCoreData] loadImageFromMainBundle:stringImageName];
        }
    }
    else {
        self.IVStory.image = [[CoreData sharedCoreData] loadImageFromMainBundle:stringImageName];
    }
    
    //text
    
    NSString *stringStoryContent;
    NSString *stringStoryContentKey;
    
    if (self.iCurrentPageIndex != 0) {
        stringStoryContentKey = [NSString stringWithFormat:@"story%d_p%d_%@", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringLanguage];
        stringStoryContent = [self.dictionaryStoryText objectForKey:stringStoryContentKey];
    }
    else {
        stringStoryContentKey = [NSString stringWithFormat:@"story%d_c_%@", self.iBookID, [CoreData sharedCoreData].stringLanguage];
        stringStoryContent = @"";
    }
    
    
    if (self.bIsEditMode || self.bClickedEditButton) {
        NSDictionary *dictionaryStoryContent = [NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", PathEditFolder, self.stringContentFileName]];
        if (dictionaryStoryContent && [dictionaryStoryContent objectForKey:stringStoryContentKey]) {
            stringStoryContent = [dictionaryStoryContent objectForKey:stringStoryContentKey];
        }
        
        //201401211641
        if ((!stringStoryContent || ([stringStoryContent stringByReplacingOccurrencesOfString:@" " withString:@""]).length == 0) && self.iCurrentPageIndex == 0) {
            stringStoryContent = LocalizedString(@"s100_custom_name_please");
        }
    }

    DEBUGMSG(@"stringStoryContentKey: %@", stringStoryContentKey);
    DEBUGMSG(@"stringStoryContent: %@", stringStoryContent);
    
    self.TVStory.text = stringStoryContent;
    
    //audio
    NSError *Err = nil;
    if (self.AP) {
        [self.AP stop];
        self.buttonPause.selected = NO;
    }
    
    NSString *stringAudioFileName;
    if (self.iCurrentPageIndex != 0) {
        stringAudioFileName = [NSString stringWithFormat:@"story%d_p%d_%@", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringVoice];
    }
    else {
        stringAudioFileName = [NSString stringWithFormat:@"story%d_c_%@", self.iBookID, [CoreData sharedCoreData].stringVoice];
    }
    
    if (self.bIsEditMode || self.bClickedEditButton) {
        NSData *dataAudio = [NSData dataWithContentsOfFile:[NSString stringWithFormat:@"%@/%@.caf", PathEditFolder, stringAudioFileName]];
        
        DEBUGMSG(@"dataAudio length of %@: %d", [NSString stringWithFormat:@"%@/%@", PathEditFolder, stringAudioFileName], dataAudio.length);
        
        if (!dataAudio || dataAudio.length == 0) {
            self.AP = [[[AVAudioPlayer alloc] initWithContentsOfURL:[[NSBundle mainBundle] URLForResource:stringAudioFileName withExtension:@"mp3"] error:&Err] autorelease];
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
        }
        else {
            self.AP = [[[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@.caf", PathEditFolder, stringAudioFileName]] error:&Err] autorelease];
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
        }
    }
    else {
        self.AP = [[[AVAudioPlayer alloc] initWithContentsOfURL:[[NSBundle mainBundle] URLForResource:stringAudioFileName withExtension:@"mp3"] error:&Err] autorelease];
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    }
    if (self.AP) {
        //please uncomment
        [self.AP play];
    }
    else {
        DEBUGMSG(@"Occurs Error: %@", Err);
    }
}

- (void)saveCustomStoryImageToEditFolder
{
    if (self.CIVStoryAddHead.image && self.bIsEditMode) {
        DEBUGMSG(@"saveCustomStoryImageToEditFolder");
        UIImage *image = [[[CoreData sharedCoreData] getImageByView:self.viewStoryImageBase] retain];
        self.IVStory.image = image;
        
        NSString *stringImageName;
        if (self.iCurrentPageIndex != 0) {
            stringImageName = [NSString stringWithFormat:@"story%d_p%d_%@.png", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringLanguage];
        }
        else {
            stringImageName = [NSString stringWithFormat:@"story%d_c_%@.png", self.iBookID, [CoreData sharedCoreData].stringLanguage];
        }
        
        [[CoreData sharedCoreData] saveAndReplaceImageToFolder:PathEditFolder image:image imageName:stringImageName];
        [image release];
        self.CIVStoryAddHead.image = nil;
        self.imageFromVCNewHead = nil;
    }
}

- (void)saveCustomStoryTextToEditFolder
{
    
}

- (void)doRecoverForCurrentPage
{
    if (self.bIsEditMode) {
        DEBUGMSG(@"doRecoverForCurrentPage");
        
        NSString *stringImageName;
        if (self.iCurrentPageIndex != 0) {
            stringImageName = [NSString stringWithFormat:@"story%d_p%d_%@.png", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringLanguage];
        }
        else {
            stringImageName = [NSString stringWithFormat:@"story%d_c_%@.png", self.iBookID, [CoreData sharedCoreData].stringLanguage];
        }
        
        self.IVStory.image = [[CoreData sharedCoreData] loadImageFromMainBundle:stringImageName];
        self.CIVStoryAddHead.image = nil;
        self.imageFromVCNewHead = nil;
        [[CoreData sharedCoreData] removeFileInFolder:PathEditFolder filename:stringImageName];
    }
}

- (void)displayRecorderCurrentTime
{
    if (self.AR && self.AR.recording) {
        self.labelRecordModeTimeValue.text = [NSString stringWithFormat:@"%02d:%02d", (int)(self.AR.currentTime / 3600.0), (int)(fmodf(self.AR.currentTime, 3600.0))];   
    }
    else if (self.APRecordMode && self.APRecordMode.playing) {
        self.labelRecordModeTimeValue.text = [NSString stringWithFormat:@"%02d:%02d", (int)(self.APRecordMode.currentTime / 3600.0), (int)(fmodf(self.APRecordMode.currentTime, 3600.0))];
    }
}

#pragma mark - Handle Click Button Events

- (IBAction)clickEditButton:(UIButton *)button
{
    button.selected = !button.selected;
    self.bIsEditMode = button.selected;
    
    if (self.bIsEditMode) {
        self.bClickedEditButton = YES;
        
        self.buttonBookmark.hidden = YES;
        self.buttonSave.hidden = NO;
        self.IVTitleStory100.hidden = YES;
        self.IVTitleCustomStory.hidden = NO;
        titleText.text=@"自制小故事";
        self.buttonRecover.hidden = NO;
        self.buttonEditModeDone.hidden = NO;
        
        self.CIVStoryAddHead.userInteractionEnabled = YES;
        self.CIVStoryAddHead.bIsCuttingMode = NO;
        //self.CIVStoryAddHead.frame = CGRectMake(0.0, 0.0, self.imageFromVCNewHead.size.width, self.imageFromVCNewHead.size.height);
        self.TVStory.editable = YES;
        self.TVStory.inputAccessoryView = self.toolbarTVStory;
        
        //        self.SGRLeft.enabled = NO;
        //        self.SGRRight.enabled = NO;
        
        //201401211649
        if (self.iCurrentPageIndex == 0) {
            NSString *stringStoryContentKey = [NSString stringWithFormat:@"story%d_c_%@", self.iBookID, [CoreData sharedCoreData].stringLanguage];
            NSString *stringStoryContent = nil;;
            NSDictionary *dictionaryStoryContent = [NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", PathEditFolder, self.stringContentFileName]];
            if (dictionaryStoryContent && [dictionaryStoryContent objectForKey:stringStoryContentKey]) {
                stringStoryContent = [dictionaryStoryContent objectForKey:stringStoryContentKey];
            }
            
            //201401211641
            if ((!stringStoryContent || ([stringStoryContent stringByReplacingOccurrencesOfString:@" " withString:@""]).length == 0)) {
                stringStoryContent = LocalizedString(@"s100_custom_name_please");
            }
            
            self.TVStory.text = stringStoryContent;
            
            NSString *stringContent = stringStoryContent;
            
            NSString *stringContentKey;
            if (self.iCurrentPageIndex != 0) {
                stringContentKey = [NSString stringWithFormat:@"story%d_p%d_%@", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringLanguage];
            }
            else {
                stringContentKey = [NSString stringWithFormat:@"story%d_c_%@", self.iBookID, [CoreData sharedCoreData].stringLanguage];
            }
            
            NSMutableDictionary *MDEditStoryContentPath = [NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", PathEditFolder, self.stringContentFileName]];
            if (MDEditStoryContentPath) {
                MDEditStoryContentPath = [MDEditStoryContentPath mutableCopy];
            }
            else {
                MDEditStoryContentPath = [NSMutableDictionary new];
            }
            
            [MDEditStoryContentPath setObject:stringContent forKey:stringContentKey];
            [MDEditStoryContentPath writeToFile:[NSString stringWithFormat:@"%@/%@", PathEditFolder, self.stringContentFileName] atomically:YES];
            [MDEditStoryContentPath release];
        }
    }
    else {
        self.SGRLeft.enabled = YES;
        self.SGRRight.enabled = YES;
        self.buttonBookmark.hidden = NO;
        self.buttonSave.hidden = YES;
        self.buttonRecover.hidden = YES;
        self.buttonEditModeDone.hidden = YES;
        titleText.text=@"故事内容";

        self.CIVStoryAddHead.userInteractionEnabled = NO;
        self.TVStory.editable = NO;
        self.TVStory.inputAccessoryView = nil;
        
        //        [[CoreData sharedCoreData] clearAllFileInFolder:PathEditFolder];
        //        [self doRecoverForCurrentPage];
    }
    
    self.viewControlEdit.hidden = !button.selected;
    self.viewControlNonEdit.hidden = button.selected;
    if (!self.buttonControl.selected && button.selected) {
        [self clickControlButton:self.buttonControl];
    }
    else if (!self.buttonBookmark.selected && !button.selected) {
        [self clickControlButton:self.buttonControl];
    }
}

- (IBAction)clickControlButton:(UIButton *)button
{
    button.selected = !button.selected;
    [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        if (button.selected) {
            self.viewControl.frame = CGRectMake(0.0, self.view.frame.size.height - self.viewControl.frame.size.height, self.viewControl.frame.size.width, self.viewControl.frame.size.height);
        }
        else {
            self.viewControl.frame = CGRectMake(0.0, self.view.frame.size.height - 26.0, self.viewControl.frame.size.width, self.viewControl.frame.size.height);
        }
    } completion:^(BOOL finished) {
        
    }];
    
    if (self.viewControl.frame.origin.y==self.view.frame.size.height - self.viewControl.frame.size.height) {
        [self.buttonControl setTitle:@"收起" forState:UIControlStateNormal];
        [self.buttonControl setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
        
    }else{
        [self.buttonControl setTitle:@"展开" forState:UIControlStateNormal];
        [self.buttonControl setTitleColor:[UIColor clearColor]  forState:UIControlStateNormal];
        
        
    }

}

- (IBAction)clickTVStoryDoneButton:(UIBarButtonItem *)BBI
{
    [self.TVStory resignFirstResponder];
}

- (IBAction)clickPauseButton:(UIButton *)button
{
    button.selected = !button.selected;
    if (self.AP) {
        if (button.selected) {
            [self.AP pause];
        }
        else {
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
            [self.AP play];
        }
    }
}

- (IBAction)clickNewHeadImageButton:(UIButton *)button
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        [self.AP stop];
        self.CIVStoryAddHead.image = nil;
        self.imageFromVCNewHead = nil;
        
        self.SGRLeft.enabled = NO;
        self.SGRRight.enabled = NO;
        
        self.IPC = [[[UIImagePickerController alloc] init] autorelease];
        self.IPC.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        self.IPC.delegate = self;
        
        if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
            self.PC = [[[UIPopoverController alloc] initWithContentViewController:self.IPC] autorelease];
            self.PC.delegate = self;
            [self.PC presentPopoverFromRect:self.viewControl.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }
        else {
            [[CoreData sharedCoreData].JNC presentModalViewController:self.IPC animated:YES];
        }
    }
}

- (IBAction)clickStartToRecordSoundButton:(UIButton *)button
{
    self.buttonRecordModeRedo.hidden = YES;
    self.buttonRecordModeDone.hidden = YES;
    
    self.labelRecordModeStatusValue.text = LocalizedString(@"s100_click_record");
    self.labelRecordModeTimeValue.text = [NSString stringWithFormat:@"%02d:%02d", 0, 0];
    self.viewRecordModeBase.hidden = NO;
}

- (IBAction)clickRecoverButton:(UIButton *)button
{
    //[self doRecoverForCurrentPage];
    UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_confirm_recover_pic") delegate:self cancelButtonTitle:LocalizedString(@"cm_cancel") otherButtonTitles:LocalizedString(@"cm_ok"), nil];
    AV.tag = RecoverAVTag;
    [AV show];
    [AV release];
}

- (IBAction)clickSaveButton:(UIButton *)button
{
    BOOL bSucessful = NO;
    
    NSError *Err;
    NSFileManager *FM = [NSFileManager defaultManager];
    if (![FM fileExistsAtPath:self.stringCustomStoryFolderPath]) {
        bSucessful = [FM createDirectoryAtPath:self.stringCustomStoryFolderPath withIntermediateDirectories:YES attributes:nil error:&Err];
        if (!bSucessful) {
            UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_save_fail") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
            [AV show];
            [AV release];
            DEBUGMSG(@"Err: %@", Err.description);
            return;
        }
    }
    
    if ([FM fileExistsAtPath:PathEditFolder]) {
        NSError *Err = nil;
        for (NSString *stringFileName in [FM contentsOfDirectoryAtPath:PathEditFolder error:&Err]) {
            
            if ([FM fileExistsAtPath:[NSString stringWithFormat:@"%@/%@", self.stringCustomStoryFolderPath, stringFileName]]) {
                bSucessful = [FM removeItemAtPath:[NSString stringWithFormat:@"%@/%@", self.stringCustomStoryFolderPath, stringFileName] error:&Err];
                if (!bSucessful) {
                    UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_save_fail") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
                    [AV show];
                    [AV release];
                    DEBUGMSG(@"Err: %@", Err.description);
                    return;
                }
            }
            
            bSucessful = [FM copyItemAtPath:[NSString stringWithFormat:@"%@/%@", PathEditFolder, stringFileName] toPath:[NSString stringWithFormat:@"%@/%@", self.stringCustomStoryFolderPath, stringFileName] error:&Err];
            if (!bSucessful) {
                UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_save_fail") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
                [AV show];
                [AV release];
                DEBUGMSG(@"Err: %@", Err.description);
                return;
            }
        }
    }
    
    NSMutableDictionary *MDDestStoryContent = [NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", self.stringCustomStoryFolderPath, self.stringContentFileName]];
    if (MDDestStoryContent) {
        MDDestStoryContent = [MDDestStoryContent mutableCopy];
    }
    else {
        MDDestStoryContent = [NSMutableDictionary new];
    }
    
    [MDDestStoryContent setObject:[NSString stringWithFormat:@"%d", self.iBookID] forKey:@"originalStoryID"];
    [MDDestStoryContent writeToFile:[NSString stringWithFormat:@"%@/%@", self.stringCustomStoryFolderPath, self.stringContentFileName] atomically:YES];
    [MDDestStoryContent release];
    
    UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_save_successful") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
    [AV show];
    [AV release];
}

- (IBAction)clickBookmarkButton:(UIButton *)button
{
    NSMutableArray *MABookmark = [NSArray arrayWithContentsOfFile:PlistPathBookmark];
    if (MABookmark) {
        MABookmark = [MABookmark mutableCopy];
    }
    else {
        MABookmark = [NSMutableArray new];
    }
    
    
    for (int x = 0; MABookmark && x < MABookmark.count; x++) {
        if (self.bClickedEditButton && [[[MABookmark objectAtIndex:x] objectForKey:@"isCustomStory"] isEqualToString:@"YES"] && [[[MABookmark objectAtIndex:x] objectForKey:@"customStoryFolderPath"] isEqualToString:self.stringCustomStoryFolderPath]) {
            [MABookmark release];
            UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_bookmarked") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
            [AV show];
            [AV release];
            return;
        }
        else if (!self.bClickedEditButton && [[[MABookmark objectAtIndex:x] objectForKey:@"isCustomStory"] isEqualToString:@"NO"] && [[[MABookmark objectAtIndex:x] objectForKey:@"bookID"] intValue] == self.iBookID) {
            UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_bookmarked") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
            [AV show];
            [AV release];
            return;
        }
    }
    
    NSMutableDictionary *MDBook = [self.dictionaryBook mutableCopy];
    
    //custom story
    if (self.bClickedEditButton) {
        [MDBook setObject:self.stringCustomStoryFolderPath forKey:@"customStoryFolderPath"];
        [MDBook setObject:@"YES" forKey:@"isCustomStory"];
    }
    //non-custom story
    else {
        [MDBook setObject:@"NO" forKey:@"isCustomStory"];
    }
    
    [MABookmark addObject:MDBook];
    [MABookmark writeToFile:PlistPathBookmark atomically:YES];
    
    [MDBook release];
    
    [MABookmark release];
    
    
    UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_bookmarked") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
    [AV show];
    [AV release];
    
}

- (IBAction)clickEditModeDoneButton:(UIButton *)button
{
//    [self saveCustomStoryImageToEditFolder];
//    self.SGRLeft.enabled = YES;
//    self.SGRRight.enabled = YES;
    UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_confirm_integrate_pic") delegate:self cancelButtonTitle:LocalizedString(@"cm_cancel") otherButtonTitles:LocalizedString(@"cm_ok"), nil];
    AV.tag = EditModeDoneAVTag;
    [AV show];
    [AV release];
}

- (IBAction)clickRecordModeRecordButton:(UIButton *)button
{
    if (!button.selected) {
        [self.AP stop];
        [self.AR stop];
        [self.APRecordMode stop];
        
        if (self.iCurrentPageIndex != 0) {
            self.stringRecordModeCurrentSoundFilePath = [NSString stringWithFormat:@"%@/%@", PathEditFolder, [NSString stringWithFormat:@"story%d_p%d_%@.caf", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringVoice]];
        }
        else {
            self.stringRecordModeCurrentSoundFilePath = [NSString stringWithFormat:@"%@/%@", PathEditFolder, [NSString stringWithFormat:@"story%d_c_%@.caf", self.iBookID, [CoreData sharedCoreData].stringVoice]];
        }
        NSURL *URLSoundFile = [NSURL fileURLWithPath:self.stringRecordModeCurrentSoundFilePath];
        
        NSDictionary *dictionaryRecordSettings = [NSDictionary dictionaryWithObjectsAndKeys:
                                                  [NSNumber numberWithInt:AVAudioQualityMin],
                                                  AVEncoderAudioQualityKey,
                                                  [NSNumber numberWithInt:16],
                                                  AVEncoderBitRateKey,
                                                  [NSNumber numberWithInt:2],
                                                  AVNumberOfChannelsKey,
                                                  [NSNumber numberWithFloat:44100.0],
                                                  AVSampleRateKey,
                                                  nil];
        
        NSError *Err1;
        self.AR = [[[AVAudioRecorder alloc] initWithURL:URLSoundFile settings:dictionaryRecordSettings error:&Err1] autorelease];
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryRecord error:nil];
        if (!Err1) {
            [self.AR record];
            [self displayRecorderCurrentTime];
            self.timerRecordMode = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(displayRecorderCurrentTime) userInfo:nil repeats:YES];
            self.labelRecordModeStatusValue.text = LocalizedString(@"s100_recording");
            DEBUGMSG(@"Audio recorder start to record: %@", self.stringRecordModeCurrentSoundFilePath);
        }
        else {
            DEBUGMSG(@"Error: %@", Err1.description);
        }
    }
    else {
        [self.AP stop];
        [self.AR stop];
        [self.APRecordMode stop];
        [self.timerRecordMode invalidate];
        self.timerRecordMode = nil;
        DEBUGMSG(@"Audio recorder stop");
        self.buttonRecordModeRecordButton.selected = NO;
        self.buttonRecordModeRecordButton.hidden = YES;
        self.buttonRecordModePlayButton.selected = NO;
        self.buttonRecordModePlayButton.hidden = NO;
        [self.buttonRecordModePlayButton setBackgroundImage:[UIImage imageNamed:@"story100_play_2.png"] forState:UIControlStateNormal];
        self.labelRecordModeStatusValue.text = LocalizedString(@"s100_click_play_record");
        self.buttonRecordModeRedo.hidden = NO;
        self.buttonRecordModeDone.hidden = NO;
    }
    button.selected = !button.selected;
}

- (IBAction)clickRecordModePlayButton:(UIButton *)button
{
    if (!button.selected) {
        DEBUGMSG(@"click play button");
        if (self.APRecordMode) {
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
            [self.APRecordMode play];
            [self displayRecorderCurrentTime];
            self.timerRecordMode = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(displayRecorderCurrentTime) userInfo:nil repeats:YES];
            [self.buttonRecordModePlayButton setBackgroundImage:[UIImage imageNamed:@"story100_Pause_2.png"] forState:UIControlStateNormal];
            self.labelRecordModeStatusValue.text = LocalizedString(@"s100_playing");
        }
        else {
            [self.AP stop];
            [self.AR stop];
            [self.APRecordMode stop];
            NSError *Err;
            self.APRecordMode = [[[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:self.stringRecordModeCurrentSoundFilePath] error:&Err] autorelease];
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
            self.APRecordMode.delegate = self;
            if (self.APRecordMode && !Err) {
                [self.APRecordMode play];
                DEBUGMSG(@"APRecordMode is playing: %@", self.stringRecordModeCurrentSoundFilePath);
                [self displayRecorderCurrentTime];
                self.timerRecordMode = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(displayRecorderCurrentTime) userInfo:nil repeats:YES];
                [self.buttonRecordModePlayButton setBackgroundImage:[UIImage imageNamed:@"story100_Pause_2.png"] forState:UIControlStateNormal];
                self.labelRecordModeStatusValue.text = LocalizedString(@"s100_playing");
            }
        }
    }
    else {
        DEBUGMSG(@"click pause button");
        [self.AP stop];
        [self.AR stop];
        [self.APRecordMode pause];
        [self.timerRecordMode invalidate];
        self.timerRecordMode = nil;
        [self.buttonRecordModePlayButton setBackgroundImage:[UIImage imageNamed:@"story100_play_2.png"] forState:UIControlStateNormal];
        self.labelRecordModeStatusValue.text = LocalizedString(@"s100_pause");
    }
    button.selected = !button.selected;
}

- (IBAction)clickRecordModeRedoButton:(UIButton *)button
{
    DEBUGMSG(@"clickRecordModeRedoButton");
    [self.AP stop];
    [self.AR stop];
    [self.APRecordMode stop];
    self.AP = nil;
    self.AR = nil;
    self.APRecordMode = nil;
    self.buttonRecordModeRecordButton.selected = NO;
    self.buttonRecordModeRecordButton.hidden = NO;
    self.buttonRecordModePlayButton.selected = NO;
    self.buttonRecordModePlayButton.hidden = YES;
    self.labelRecordModeTimeValue.text = @"00:00";
    self.labelRecordModeStatusValue.text = LocalizedString(@"s100_click_record");
    [[NSFileManager defaultManager] removeItemAtPath:self.stringRecordModeCurrentSoundFilePath error:nil];
    self.buttonRecordModeRedo.hidden = YES;
    self.buttonRecordModeDone.hidden = YES;
}

- (IBAction)clickRecordModeDoneButton:(UIButton *)button
{
    DEBUGMSG(@"clickRecordModeDoneButton");
    [self.AP stop];
    [self.AR stop];
    [self.APRecordMode stop];
    self.AP = nil;
    self.AR = nil;
    self.APRecordMode = nil;
    self.buttonRecordModeRecordButton.selected = NO;
    self.buttonRecordModeRecordButton.hidden = NO;
    self.buttonRecordModePlayButton.selected = NO;
    self.buttonRecordModePlayButton.hidden = YES;
    self.viewRecordModeBase.hidden = YES;
    self.labelRecordModeTimeValue.text = @"00:00";
    self.labelRecordModeStatusValue.text = LocalizedString(@"s100_click_record");
}

- (IBAction)clickRecordModeCloseButton:(UIButton *)button
{
    self.viewRecordModeBase.hidden = YES;
    [self clickRecordModeRedoButton:button];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == RecoverAVTag && buttonIndex == 1) {
        [self doRecoverForCurrentPage];
    }
    else if (alertView.tag == EditModeDoneAVTag && buttonIndex == 1) {
        [self saveCustomStoryImageToEditFolder];
        self.SGRLeft.enabled = YES;
        self.SGRRight.enabled = YES;
    }
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    if (picker.sourceType == UIImagePickerControllerSourceTypePhotoLibrary) {
        if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
            [self.PC dismissPopoverAnimated:NO];
        }
        else {
            [self.IPC dismissModalViewControllerAnimated:NO];
        }
        NewHeadViewController *VCNewHead = [[NewHeadViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"NewHeadViewController"] bundle:nil];
        VCNewHead.VCBookContent = self;
        if ([[info objectForKey:UIImagePickerControllerMediaType] isEqualToString:@"public.image"]) {
            UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
            VCNewHead.dataPhotoImage = UIImagePNGRepresentation([[CoreData sharedCoreData] resizeImage:image width:1536.0 height:((1536.0 * image.size.height) / image.size.width)]);
        }
        [[CoreData sharedCoreData].JNC pushViewController:VCNewHead animated:NO];
        [VCNewHead release];
        
    }
}

#pragma mark - UIPopoverControllerDelegate

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController
{
    if (self.PC && self.PC == popoverController) {
        self.SGRLeft.enabled = YES;
        self.SGRRight.enabled = YES;
    }
    return YES;
}

#pragma mark - Handle Gesture Recognizer Events

- (IBAction)swipeLeftGestureRecognizer:(UISwipeGestureRecognizer *)SGR
{
    //DEBUGMSG(@"SwipeLeftGestureRecognizer");
    if (self.iCurrentPageIndex + 1 < self.iBookNumOfPage) {
        self.iCurrentPageIndex++;
        self.CIVStoryAddHead.image = nil;
        self.imageFromVCNewHead = nil;
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionPush;
        transition.subtype = kCATransitionFromRight;
        [self.IVStory.layer removeAllAnimations];
        [self.TVStory.layer removeAllAnimations];
		[self.IVStory.layer addAnimation:transition forKey:@""];
		[self.TVStory.layer addAnimation:transition forKey:@""];
        [self setImageTextPlayAudio];
    }
}

- (IBAction)swipeRightGestureRecognizer:(UISwipeGestureRecognizer *)SGR
{
    //DEBUGMSG(@"SwipeRightGestureRecognizer");
    if (self.iCurrentPageIndex - 1 >= 0) {
        self.iCurrentPageIndex--;
        self.CIVStoryAddHead.image = nil;
        self.imageFromVCNewHead = nil;
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionPush;
        transition.subtype = kCATransitionFromLeft;
        [self.IVStory.layer removeAllAnimations];
        [self.TVStory.layer removeAllAnimations];
		[self.IVStory.layer addAnimation:transition forKey:@""];
		[self.TVStory.layer addAnimation:transition forKey:@""];
        [self setImageTextPlayAudio];
    }
}

#pragma mark - UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
            self.viewBase.frame = CGRectMake(0.0,  -(610.0 - 26.0), self.viewBase.frame.size.width, self.viewBase.frame.size.height);
        }
        else {
            self.viewBase.frame = CGRectMake(0.0,  -(260.0 - 26.0), self.viewBase.frame.size.width, self.viewBase.frame.size.height);
        }
    } completion:^(BOOL finished) {
    }];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.viewBase.frame = CGRectMake(0.0,  0.0, self.viewBase.frame.size.width, self.viewBase.frame.size.height);
    } completion:^(BOOL finished) {
        NSString *stringContent = textView.text;
        
        NSString *stringContentKey;
        if (self.iCurrentPageIndex != 0) {
            stringContentKey = [NSString stringWithFormat:@"story%d_p%d_%@", self.iBookID, self.iCurrentPageIndex, [CoreData sharedCoreData].stringLanguage];
        }
        else {
            stringContentKey = [NSString stringWithFormat:@"story%d_c_%@", self.iBookID, [CoreData sharedCoreData].stringLanguage];
        }
        
        NSMutableDictionary *MDEditStoryContentPath = [NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", PathEditFolder, self.stringContentFileName]];
        if (MDEditStoryContentPath) {
            MDEditStoryContentPath = [MDEditStoryContentPath mutableCopy];
        }
        else {
            MDEditStoryContentPath = [NSMutableDictionary new];
        }
        
        [MDEditStoryContentPath setObject:stringContent forKey:stringContentKey];
        [MDEditStoryContentPath writeToFile:[NSString stringWithFormat:@"%@/%@", PathEditFolder, self.stringContentFileName] atomically:YES];
        [MDEditStoryContentPath release];
    }];
}

#pragma mark - AVAudioPlayerDelegate

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    if (player == self.APRecordMode) {
        [self.APRecordMode stop];
        self.APRecordMode.delegate = nil;
        self.APRecordMode = nil;
        self.buttonRecordModePlayButton.selected = NO;
        [self.buttonRecordModePlayButton setBackgroundImage:[UIImage imageNamed:@"story100_play_2.png"] forState:UIControlStateNormal];
    }
}

#pragma mark - LeftMenuButtonDelegate

- (void)clickLeftMenuButton
{
    DEBUGMSG(@"clickLeftMenuButton");
    [self.AP stop];
    [self.AR stop];
    [self.APRecordMode stop];
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [editBtn release];
    editBtn = nil;
    [bookMarkBtn release];
    bookMarkBtn = nil;
    [saveBtn release];
    saveBtn = nil;
    [startRecordBtn release];
    startRecordBtn = nil;
    [closeRecordBtn release];
    closeRecordBtn = nil;
    [titleText release];
    titleText = nil;
    [super viewDidUnload];
}
@end
