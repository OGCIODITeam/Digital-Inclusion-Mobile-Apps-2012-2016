//
//  NewHeadViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月3日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookContentViewController.h"
#import "CustomBookContentViewController.h"
#import "LeftMenuButton.h"

@interface NewHeadViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet LeftMenuButton *leftBtn;

    IBOutlet UIButton *redoBtn;
    
    IBOutlet UIButton *doneBtn;
    

}

@property (nonatomic, retain) NSData *dataPhotoImage;
@property (nonatomic, assign) BookContentViewController *VCBookContent;
@property (nonatomic, assign) CustomBookContentViewController *VCCustomBookContent;

@end
