//
//  BookcaseTableViewCell.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookcaseTableViewCell.h"
#import "BookRatingViewController.h"

@interface BookcaseTableViewCell ()

@property (nonatomic, retain) IBOutlet UIImageView *IVBook;
@property (nonatomic, retain) BookRatingViewController *VCBookRating;

@end

@implementation BookcaseTableViewCell

@synthesize stringBookID = _stringBookID;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    self.IVBook.transform = CGAffineTransformIdentity;
    self.IVBook.transform = CGAffineTransformMakeRotation(M_PI_2);
    //self.IVBook.frame = CGRectMake(10.0, 10.0, 101.0, 72.0);
    
    [self.contentView addSubview:self.VCBookRating.view];
    self.VCBookRating.view.transform = CGAffineTransformIdentity;
    self.VCBookRating.view.transform = CGAffineTransformMakeRotation(M_PI_2);
    //self.VCBookRating.view.frame = CGRectMake(10.0, 7.0, 35.0, 78.0);
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        self.IVBook.frame = CGRectMake(15.0, 20.0, 136.0, 100.0);
        self.clearLbl.frame = CGRectMake(15.0, 20.0, 128.0, 100.0);

        self.VCBookRating.view.frame = CGRectMake(13.0, 10.0, 52.0, 120.0);
    }
    else {
        self.IVBook.frame = CGRectMake(10.0, 10.0, 101.0, 72.0);
        self.clearLbl.frame = CGRectMake(10.0, 10.0, 101.0, 72.0);

        self.VCBookRating.view.frame = CGRectMake(10.0, 7.0, 35.0, 78.0);
    }
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.VCBookRating = [[[BookRatingViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookRatingViewController"] bundle:nil] autorelease];
}

- (void)dealloc
{
    self.IVBook.image = nil;
    self.IVBook = nil;
    
    [self.VCBookRating.view removeFromSuperview];
    self.VCBookRating = nil;
    
    self.stringBookID = nil;
    [_clearLbl release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

#pragma mark - Core

- (void)reset
{
    self.stringBookID = nil;
    self.IVBook.image = nil;
    self.VCBookRating.IVStar1.hidden = YES;
    self.VCBookRating.IVStar2.hidden = YES;
    self.VCBookRating.IVStar3.hidden = YES;
    self.VCBookRating.IVStar4.hidden = YES;
    self.VCBookRating.IVStar5.hidden = YES;
}

- (void)setupView:(UIImage *)imageBook
{
    self.IVBook.image = imageBook;
}

- (void)showRating:(BOOL)bShow
{
    NSDictionary *dictionaryBookScore = nil;
    NSArray *arrayBookScore = [NSArray arrayWithContentsOfFile:PlistPathBookScore];
    
    for (int x = 0; arrayBookScore && x < arrayBookScore.count; x++) {
        if (self.stringBookID && [self.stringBookID isEqualToString:[[arrayBookScore objectAtIndex:x] objectForKey:@"bookID"]]) {
            dictionaryBookScore = ((NSDictionary *)[arrayBookScore objectAtIndex:x]);
            break;
        }
    }
    if (dictionaryBookScore) {
        self.VCBookRating.labelViewTimeValue.text = [dictionaryBookScore objectForKey:@"viewTime"];
        int iAvgScore = [[dictionaryBookScore objectForKey:@"avgScore"] intValue];
        if (iAvgScore >= 1) {
            self.VCBookRating.IVStar1.hidden = NO;
        }
        if (iAvgScore >= 2) {
            self.VCBookRating.IVStar2.hidden = NO;
        }
        if (iAvgScore >= 3) {
            self.VCBookRating.IVStar3.hidden = NO;
        }
        if (iAvgScore >= 4) {
            self.VCBookRating.IVStar4.hidden = NO;
        }
        if (iAvgScore == 5) {
            self.VCBookRating.IVStar5.hidden = NO;
        }
    }
    self.VCBookRating.view.hidden = !bShow;
}

@end
