//
//  BookcaseHeaderTableViewCell.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookcaseHeaderTableViewCell.h"

@interface BookcaseHeaderTableViewCell ()


@end

@implementation BookcaseHeaderTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [_titleClearLbl release];
    [super dealloc];
}



@end
