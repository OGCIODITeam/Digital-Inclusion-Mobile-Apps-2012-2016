//
//  BookcaseHeaderTableViewCell.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookcaseHeaderTableViewCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UILabel *titleClearLbl;
@end
