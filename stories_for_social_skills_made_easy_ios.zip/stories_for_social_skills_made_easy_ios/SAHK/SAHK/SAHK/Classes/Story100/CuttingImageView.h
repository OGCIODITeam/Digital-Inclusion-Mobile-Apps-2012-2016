//
//  CuttingImageView.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月4日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CuttingImageView : UIImageView

@property (nonatomic, assign) BOOL bIsCuttingMode;
@property (nonatomic, retain) NSMutableArray *MATouchPoint;


@end
