//
//  BookcaseViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookcaseViewControllerDelegate.h"

@interface BookcaseViewController : UIViewController

@property (nonatomic, retain) NSMutableArray *MABook;
@property (nonatomic, retain) NSArray *titleArray;
@property (nonatomic, retain) NSString *clearTitle;


@property (nonatomic, assign) id <BookcaseViewControllerDelegate> delegateBookcaseViewController;

#pragma mark - Core

- (void)refreshBookcase;
- (void)showRating:(BOOL)bShowRating;

@end
