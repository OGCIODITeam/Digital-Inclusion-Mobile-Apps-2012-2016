//
//  NewHeadViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月3日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "NewHeadViewController.h"
#import "CuttingImageView.h"

@interface NewHeadViewController ()

@property (nonatomic, retain) IBOutlet UIImageView *IVContent;
@property (nonatomic, retain) IBOutlet CuttingImageView *CIV;
@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

#pragma mark - Core

- (void)setup;
- (void)setupView;

#pragma mark - Handle Click Button Events

- (IBAction)clickUndoButton:(UIButton *)button;
- (IBAction)clickDoneButton:(UIButton *)button;

@end

@implementation NewHeadViewController

@synthesize dataPhotoImage = _dataPhotoImage;
@synthesize VCBookContent = _VCBookContent;
@synthesize VCCustomBookContent = _VCCustomBookContent;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.dataPhotoImage = nil;
    self.IVContent.image = nil;
    self.IVContent = nil;
    
    self.CIV = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    [topNav release];
    [leftBtn release];
    [redoBtn release];
    [doneBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    if (IOS7_OR_LATER) {
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);

        self.IVTitle.frame=CGRectMake( self.IVTitle.frame.origin.x,  self.IVTitle.frame.origin.y+20,  self.IVTitle.frame.size.width,  self.IVTitle.frame.size.height);
        self.CIV.frame=CGRectMake( self.CIV.frame.origin.x,  self.CIV.frame.origin.y+60,  self.CIV.frame.size.width,  self.CIV.frame.size.height);
          self.IVContent.frame=CGRectMake( self.IVContent.frame.origin.x,  self.IVContent.frame.origin.y+20,  self.IVContent.frame.size.width,  self.IVContent.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        
        
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [redoBtn setTitle:@"重做" forState:UIControlStateNormal];
    [redoBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [redoBtn setImage:[UIImage imageNamed:@"story100_redo_2.png"] forState:UIControlStateNormal];

    [doneBtn setTitle:@"确定" forState:UIControlStateNormal];
    [doneBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [doneBtn setImage:[UIImage imageNamed:@"story100_ok_1.png"] forState:UIControlStateNormal];

    [self setup];
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    
}

- (void)setupView
{
    
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"story100_add_new_head"];
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPhone3Dot5Inch]) {
        if (IOS7_OR_LATER) {
            self.IVContent.frame = self.CIV.frame = CGRectMake(0.0, 50.0+20, 320.0, 342.0);

        }else{
            self.IVContent.frame = self.CIV.frame = CGRectMake(0.0, 50.0, 320.0, 342.0);
        }
    }
    else {
        
        if (IOS7_OR_LATER) {
            self.IVContent.frame = self.CIV.frame = CGRectMake(0.0, 50.0+20, 320.0, 342.0);
            
        }else{
        self.IVContent.frame = self.CIV.frame = CGRectMake(0.0, 50.0, 320.0, 430.0);
        }
    }
    
    self.IVContent.image = [UIImage imageWithData:self.dataPhotoImage];
    self.CIV.bIsCuttingMode = YES;
    CGSize size =  [[CoreData sharedCoreData] getImageViewSizeWithImageSize:CGSizeMake([UIImage imageWithData:self.dataPhotoImage].size.width, [UIImage imageWithData:self.dataPhotoImage].size.height) basedOnImageViewSize:CGSizeMake(self.IVContent.frame.size.width, self.IVContent.frame.size.height)];
//    self.IVContent.frame = self.CIV.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width - size.width) / 2.0, self.IVContent.frame.origin.y, size.width, self.IVContent.frame.size.height);
    self.IVContent.frame = self.CIV.frame = CGRectMake(roundf(([UIScreen mainScreen].bounds.size.width - size.width) / 2.0), roundf(self.IVContent.frame.origin.y), roundf(size.width), roundf(self.IVContent.frame.size.height));
}

#pragma mark - Handle Click Button Events

- (IBAction)clickUndoButton:(UIButton *)button
{
    self.CIV.image = nil;
    [self.CIV.MATouchPoint removeAllObjects];
}

- (IBAction)clickDoneButton:(UIButton *)button
{
    NSMutableArray *MATouchPoint = self.CIV.MATouchPoint;
    
    if (!MATouchPoint || MATouchPoint.count == 0)
        return;
    
    UIGraphicsBeginImageContext(self.CIV.frame.size);
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineCap(contextRef, kCGLineCapRound);
    CGContextSetLineWidth(contextRef, 1.0);
    CGFloat fillColorFloatArray[] = {0 / 255.0, 0 / 255.0, 0 / 255.0, 1.0};
    CGContextSetFillColor(contextRef, fillColorFloatArray);
    
    NSArray *array = [[MATouchPoint objectAtIndex:0] componentsSeparatedByString:@","];
    CGContextMoveToPoint(contextRef, [[array objectAtIndex:0] floatValue], [[array objectAtIndex:1] floatValue]);
    
    for(int x = 1; x < MATouchPoint.count; x++){
        NSArray *array = [[MATouchPoint objectAtIndex:x] componentsSeparatedByString:@","];
        CGContextAddLineToPoint(contextRef, [[array objectAtIndex:0] floatValue], [[array objectAtIndex:1] floatValue]);
    }
    CGContextClip(contextRef);
    [self.IVContent.image drawInRect:CGRectMake(0, 0, self.CIV.frame.size.width, self.CIV.frame.size.height)];
    if (self.VCBookContent) {
        self.VCBookContent.imageFromVCNewHead = UIGraphicsGetImageFromCurrentImageContext();
    }
    else if (self.VCCustomBookContent) {
        self.VCCustomBookContent.imageFromVCNewHead = UIGraphicsGetImageFromCurrentImageContext();
    }
    UIGraphicsEndImageContext();
    [[CoreData sharedCoreData].JNC popViewControllerAnimated:NO];
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [redoBtn release];
    redoBtn = nil;
    [doneBtn release];
    doneBtn = nil;
    [super viewDidUnload];
}
@end
