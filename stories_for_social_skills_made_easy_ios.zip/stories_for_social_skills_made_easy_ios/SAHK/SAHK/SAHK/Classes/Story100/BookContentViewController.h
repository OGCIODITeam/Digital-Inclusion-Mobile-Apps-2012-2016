//
//  BookContentViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface BookContentViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet LeftMenuButton *leftBtn;
    IBOutlet UIButton *editBtn;

    IBOutlet UIButton *bookMarkBtn;
    
    IBOutlet UIButton *saveBtn;
    
    IBOutlet UIButton *startRecordBtn;
    
    IBOutlet UIButton *closeRecordBtn;
    
    
    IBOutlet UILabel *titleText;
    
    
    
}

@property (nonatomic, retain) NSDictionary *dictionaryBook;
@property (nonatomic, retain) UIImage *imageFromVCNewHead;
@property (nonatomic, assign) BOOL bIsEditMode;
@property (nonatomic, assign) BOOL bPushFromBookmarkView;

@end
