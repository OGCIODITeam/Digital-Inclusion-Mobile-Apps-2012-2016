//
//  Story100ViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月13日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface Story100ViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet UIImageView *topLogo;

    IBOutlet LeftMenuButton *leftBtn;
    IBOutlet UIButton *rightBtn;
    
    IBOutlet UIImageView *grayImg;
    
    IBOutlet UIImageView *story100Logo;
    
    IBOutlet UIButton *skipBtn;
    
    IBOutlet UIButton *lastReadDoneBtn;
    
}


@end
