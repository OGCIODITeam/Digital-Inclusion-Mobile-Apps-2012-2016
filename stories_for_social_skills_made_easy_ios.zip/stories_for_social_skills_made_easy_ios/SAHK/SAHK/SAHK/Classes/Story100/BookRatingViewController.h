//
//  BookRatingViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookRatingViewController : UIViewController

@property (nonatomic, retain) IBOutlet UILabel *labelViewTimeValue;
@property (nonatomic, retain) IBOutlet UIImageView *IVStar1, *IVStar2, *IVStar3, *IVStar4, *IVStar5;

@end
