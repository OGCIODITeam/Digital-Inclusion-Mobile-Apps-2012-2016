//
//  Story100ViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月13日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "Story100ViewController.h"
#import "BookcaseViewController.h"
#import "BookContentViewController.h"

#define TitleWidth 38.0
#define TitleWidthiPad 68.0

@interface Story100ViewController () <BookcaseViewControllerDelegate>

@property (nonatomic, retain) IBOutlet UIScrollView *SVBookBase;
@property (nonatomic, retain) BookcaseViewController *VCBookcase1, *VCBookcase2, *VCBookcase3, *VCBookcase4, *VCBookcase5;

@property (nonatomic, retain) NSDictionary *dictionaryStoryFilename;

@property (nonatomic, retain) NSMutableArray *MABookScore;

@property (nonatomic, retain) IBOutlet UILabel *labelLastRead;
@property (nonatomic, retain) IBOutlet UIView *viewLastReadBase;
@property (nonatomic, retain) IBOutlet UIButton *buttonLastReadStar1, *buttonLastReadStar2, *buttonLastReadStar3, *buttonLastReadStar4, *buttonLastReadStar5;
@property (nonatomic, assign) int iCurrentStarNum;
@property (nonatomic, retain) NSArray *arrayButtonLastReadStar;
@property (nonatomic, retain) NSDictionary *dictionaryCurrentLastReadBook;

@property (nonatomic, retain) IBOutlet UIImageView *IVCat1, *IVCat2, *IVCat3, *IVCat4, *IVCat5;

#pragma mark - Core

- (void)setup;
- (void)setupView;

#pragma mark - Handle Click Button Events

- (IBAction)clickShowRatingButton:(UIButton *)button;
- (IBAction)clickLastReadStarButton:(UIButton *)button;
- (IBAction)clickLastReadSkipButton:(UIButton *)button;
- (IBAction)clickLastReadDoneButton:(UIButton *)button;

@end

@implementation Story100ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.iCurrentStarNum = UndefinedInt;
    }
    return self;
}

- (void)dealloc
{
    self.SVBookBase.delegate = nil;
    self.SVBookBase = nil;
    
    self.VCBookcase1.delegateBookcaseViewController = nil;
    [self.VCBookcase1.view removeFromSuperview];
    self.VCBookcase1 = nil;
    self.VCBookcase2.delegateBookcaseViewController = nil;
    [self.VCBookcase2.view removeFromSuperview];
    self.VCBookcase2 = nil;
    self.VCBookcase3.delegateBookcaseViewController = nil;
    [self.VCBookcase3.view removeFromSuperview];
    self.VCBookcase3 = nil;
    self.VCBookcase4.delegateBookcaseViewController = nil;
    [self.VCBookcase4.view removeFromSuperview];
    self.VCBookcase4 = nil;
    self.VCBookcase5.delegateBookcaseViewController = nil;
    [self.VCBookcase5.view removeFromSuperview];
    self.VCBookcase5 = nil;
    
    self.dictionaryStoryFilename = nil;
    
    [self.MABookScore removeAllObjects];
    self.MABookScore = nil;
    
    self.labelLastRead = nil;
    
    self.viewLastReadBase = nil;
    
    self.buttonLastReadStar1 = nil;
    self.buttonLastReadStar2 = nil;
    self.buttonLastReadStar3 = nil;
    self.buttonLastReadStar4 = nil;
    self.buttonLastReadStar5 = nil;
    
    self.IVCat1.image = nil;
    self.IVCat1 = nil;
    self.IVCat2.image = nil;
    self.IVCat2 = nil;
    self.IVCat3.image = nil;
    self.IVCat3 = nil;
    self.IVCat4.image = nil;
    self.IVCat4 = nil;
    self.IVCat5.image = nil;
    self.IVCat5 = nil;
    
    [topNav release];
    [topLogo release];
    [leftBtn release];
    [rightBtn release];
    [grayImg release];
    [story100Logo release];
    [skipBtn release];
    [lastReadDoneBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        topLogo.frame=CGRectMake(topLogo.frame.origin.x, topLogo.frame.origin.y+20, topLogo.frame.size.width, topLogo.frame.size.height);
        grayImg.frame=CGRectMake(grayImg.frame.origin.x, grayImg.frame.origin.y+20, grayImg.frame.size.width, grayImg.frame.size.height);
        
        story100Logo.frame=CGRectMake(story100Logo.frame.origin.x, story100Logo.frame.origin.y+20, story100Logo.frame.size.width, story100Logo.frame.size.height);
        rightBtn.frame=CGRectMake(rightBtn.frame.origin.x, rightBtn.frame.origin.y+20, rightBtn.frame.size.width, rightBtn.frame.size.height);
        
//        self.SVBookBase.frame=CGRectMake( self.SVBookBase.frame.origin.x,  self.SVBookBase.frame.origin.y+20,  self.SVBookBase.frame.size.width,  self.SVBookBase.frame.size.height-20);
        self.SVBookBase.frame=CGRectMake( self.SVBookBase.frame.origin.x,  self.SVBookBase.frame.origin.y+20,  self.SVBookBase.frame.size.width,  self.SVBookBase.frame.size.height);

        
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        
        
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];
    
    [rightBtn setTitle:@"檢視閱讀評分" forState:UIControlStateNormal];
    [rightBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [rightBtn setImage:[UIImage imageNamed:@"cm_eye_icon_iPhone.png"] forState:UIControlStateNormal];

    
    [self.buttonLastReadStar1 setTitle:@"一星按钮" forState:UIControlStateNormal];
    [self.buttonLastReadStar1 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonLastReadStar1 setImage:[UIImage imageNamed:@"cm_star_1.png"] forState:UIControlStateNormal];
    [self.buttonLastReadStar1 setImage:[UIImage imageNamed:@"cm_star_2.png"] forState:UIControlStateSelected];


    [self.buttonLastReadStar2 setTitle:@"二星按钮" forState:UIControlStateNormal];
    [self.buttonLastReadStar2 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonLastReadStar2 setImage:[UIImage imageNamed:@"cm_star_1.png"] forState:UIControlStateNormal];
    [self.buttonLastReadStar2 setImage:[UIImage imageNamed:@"cm_star_2.png"] forState:UIControlStateSelected];



    [self.buttonLastReadStar3 setTitle:@"三星按钮" forState:UIControlStateNormal];
    [self.buttonLastReadStar3 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonLastReadStar3 setImage:[UIImage imageNamed:@"cm_star_1.png"] forState:UIControlStateNormal];
    [self.buttonLastReadStar3 setImage:[UIImage imageNamed:@"cm_star_2.png"] forState:UIControlStateSelected];


    
    [self.buttonLastReadStar4 setTitle:@"四星按钮" forState:UIControlStateNormal];
    [self.buttonLastReadStar4 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonLastReadStar4 setImage:[UIImage imageNamed:@"cm_star_1.png"] forState:UIControlStateNormal];
    [self.buttonLastReadStar4 setImage:[UIImage imageNamed:@"cm_star_2.png"] forState:UIControlStateSelected];



    [self.buttonLastReadStar5 setTitle:@"五星按钮" forState:UIControlStateNormal];
    [self.buttonLastReadStar5 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonLastReadStar5 setImage:[UIImage imageNamed:@"cm_star_1.png"] forState:UIControlStateNormal];
    [self.buttonLastReadStar5 setImage:[UIImage imageNamed:@"cm_star_2.png"] forState:UIControlStateSelected];


    [skipBtn setTitle:@"跳过評分" forState:UIControlStateNormal];
    [skipBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [skipBtn setImage:[UIImage imageNamed:@"cm_jump_1.png"] forState:UIControlStateNormal];
    
    [lastReadDoneBtn setTitle:@"确定" forState:UIControlStateNormal];
    [lastReadDoneBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [lastReadDoneBtn setImage:[UIImage imageNamed:@"cm_ok_1.png"] forState:UIControlStateNormal];

    
    
    
    [self setup];
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    self.MABookScore = [NSArray arrayWithContentsOfFile:PlistPathBookScore];
    if (self.MABookScore) {
        self.MABookScore = [[self.MABookScore mutableCopy] autorelease];
    }
    else {
        self.MABookScore = [[NSMutableArray new] autorelease];
        for (int x = 1; x <= 100; x++) {
            NSMutableDictionary *MDBookScore = [[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d", x], @"bookID", @"0", @"viewTime", nil] mutableCopy];
            [self.MABookScore addObject:MDBookScore];
            [MDBookScore release];
        }
        [self.MABookScore writeToFile:PlistPathBookScore atomically:YES];
        
    }
    self.dictionaryStoryFilename = [NSDictionary dictionaryWithContentsOfFile:PlistFilename];
}

- (void)setupView
{
    self.viewLastReadBase.hidden = YES;
    self.arrayButtonLastReadStar = [NSArray arrayWithObjects:self.buttonLastReadStar1, self.buttonLastReadStar2, self.buttonLastReadStar3, self.buttonLastReadStar4, self.buttonLastReadStar5, nil];
    
    self.labelLastRead.text = LocalizedString(@"s100_last_read_msg");
    
    if (![[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        //self.SVBookBase.contentSize = CGSizeMake(320.0, 650.0);
        self.SVBookBase.contentSize = CGSizeMake(320.0, 650.0);
    }else{
        self.SVBookBase.contentSize = CGSizeMake(768.0, 925.0);

    
    }
    
    NSArray*titleArray1=[NSArray arrayWithObjects:@"怎样打招呼？",@"什麼時候握手？",@"什麼時候說多謝？",@"什麼時候說唔該？",@"什麼時候說對唔住？",@"我可以怎樣拿到想要的東西？",@"怎樣令人開心？",@"見到喜歡的小朋友，我可以怎樣做？",@"怎樣幫助別人？",@"小朋友還未把事情做好，我可以怎樣做？",@"事情做錯了，應該怎麼辦？",@"不開心時，我可以怎樣做？",@"生氣時，我可以怎樣做？",@"怎樣保持冷靜？",@"想玩玩具時，我可以怎樣做？",@"想玩別人的玩具時，我可以怎樣做？",@"小朋友不想借玩具、借圖書給我，我可以怎樣做？",@"在我家裡，朋友可以玩我的玩具嗎？",@"怎樣才能拿回自己的玩具？",@"怎樣分享玩具？",@"什麼時候輪到我玩玩具？",@"怎樣學習玩遊戲？",@"玩遊戲時，我可以怎樣做？",@"怎樣接受比賽的勝負？",@"別人向我說話時，我可以做什麼？",@"朋友正在談話，我有話要說，我可以怎樣做？",@"為甚麼要等別人把話說完，我才開始說話？",@"當我不知道別人說什麼時，可以怎樣做？",@"別人向我發問時，我可以怎樣做？",@"為甚麼談話要有不同的話題？",@"人人都有機會表達意見",@"保持適當的聲量", nil];
    NSArray*titleArray1_s=[NSArray arrayWithObjects:@"怎样打招呼？",@"什么时候握手？",@"什么时候说［谢谢］（1）？",@"什么时候说［谢谢］（2）？",@"什么时候说［对不起］？",@"我可以怎样拿到想要的东西？",@"怎样令人开心？",@"见到喜欢得小朋友，我可以怎样做？",@"怎样帮助别人？",@"小朋友还未把事情做好，我可以怎样做？",@"事情做错了，应该怎么办？",@"不开心时，我可以怎样做？",@"生气时，我可以怎样做？",@"怎样保持冷静？",@"想玩玩具时，我可以怎样做？",@"想玩别人得玩具时，我可以怎样做？",@"小朋友不想借玩具、借图书给我，我可以怎样做？",@"在我家里，朋友可以玩我的玩具吗？",@"怎样才能拿回自己得玩具？",@"怎样分享玩具？",@"什么时候轮到我玩玩具？",@"怎样学些玩游戏？",@"玩游戏时，我可以怎样做？",@"怎样接受比赛得胜负？",@"别人向我说话时，我可以做什么？",@"朋友正在谈话，我有话要说，我可以怎样做？",@"为什么要等别人把话说完，我才开始说话？",@"当我不知道别人说什么时，可以怎样做？",@"别人向我发问时，我可以怎样做？",@"为什么谈话要有不同得话题？",@"人人都有机会表达意见",@"保持适当得声量", nil];

    NSArray*titleArray2=[NSArray arrayWithObjects:@"學校是什麼地方？",@"為甚麼我要上學？",@"我在學校裡，做些什麼事？",@"小時候做些什麼事？",@"回到學校後，媽媽為甚麼便要走？",@"怎樣乘搭校車？",@"乘坐校車時，我可以怎樣做？",@"為甚麼我要午睡？",@"我在午睡時間可以怎樣做？",@"如果我不想午睡，我可以怎麼辦？",@"為甚麼會有代課老師？",@"什麼是假期？",@"為甚麼要留心上課？",@"上課時，小朋友想做其他事情，他可以怎樣做？",@"當我看到有趣的教材或玩具時，可以怎樣做？",@"老師說話時，為甚麼我要保持安靜？",@"老師在說話，我有話說，我可以怎樣做？",@"老師，你說了些什麼？",@"為甚麼要舉手輪流說話？",@"上課時怎樣問問題？",@"老師沒有叫我的名字我該怎麼辦？",@"老師請其他小朋友幫忙做事情，我可以怎樣做？",@"遇到問題我可以找誰幫忙？",@"排隊時要怎樣做？",@"每位小朋友都有機會排第一",@"有小朋友在哭叫我可以怎樣做？",@"在圖書館裡學習，要保持安靜", nil];
    NSArray*titleArray3=[NSArray arrayWithObjects:@"媽媽上班去，我可以做些什麼？",@"爸爸媽媽要到其他地方去，那麼我又會怎樣？",@"為甚麼我有一個「姐姐」？",@"我可以晚一點睡覺嗎？",@"為甚麼小朋友要收拾玩具？",@"學習輪流玩電腦",@"為甚麼生病時要留在家裡？",@"___病了，不能上學",@"開生日會是怎樣的？",@"我在什麼時候開燈？什麼時候關燈？",@"誰可以用洗衣機？",@"聽到吸塵器在響，我可以怎樣做？",@"什麼時候會聽到雷聲？",@"聽到打雷聲我可以怎樣做？",nil];
       NSArray*titleArray3_s=[NSArray arrayWithObjects:@"媽媽上班去，我可以做些什麼？",@"爸爸媽媽要到其他地方去，那麼我又會怎樣？",@"為甚麼我有一個「姐姐」？",@"我可以晚一點睡覺嗎？",@"為甚麼小朋友要收拾玩具？",@"學習輪流玩计算机",@"為甚麼生病時要留在家裡？",@"___病了，不能上學",@"開生日會是怎樣的？",@"我在什麼時候開燈？什麼時候關燈？",@"誰可以用洗衣機？",@"聽到吸塵器在響，我可以怎樣做？",@"什麼時候會聽到雷聲？",@"聽到打雷聲我可以怎樣做？",nil];
    
    NSArray*titleArray4=[NSArray arrayWithObjects:@"飯餐裡有不同的食物，我可以怎樣做？",@"吃飯時，我可以做什麼？",@"為甚麼要坐在椅子上吃飯？",@"看到地上有食物，我可以怎樣做？",@"在街上的廁所如廁是沒問題的？",@"什麼時候要沖廁？",@"衣服髒了要更換",@"什麼時候要抹嘴？",@"如果洗頭水的泡泡或水流到臉上、眼睛或耳朵裡，我可以怎樣做？",@"聽到風筒發出聲音，我可以怎麼辦？",@"我用什麼抹鼻涕？",@"小朋友怎樣學會習慣戴上口罩？",@"為甚麼我要吃藥？",@"為甚麼我要剪髮？",@"剪髮是怎樣的？",@"長度不同的髮型，各有各的好看",@"為甚麼要剪指甲？",nil];
    NSArray*titleArray5=[NSArray arrayWithObjects:@"為甚麼要扣上安全帶？",@"從哪個車門上車最安全？",@"為甚麼我要到外面玩耍？",@"小朋友在公園裡做什麼？",@"為甚麼要排隊付錢？",@"在餐廳裡吃東西是怎樣的？",@"怎樣在快餐店裡買食物？",@"為甚麼到不同的地方吃飯？",@"為甚麼要看醫生？",@"怎麼看醫生？",nil];
    
    
    
    if (!self.VCBookcase1 || !self.VCBookcase2 || !self.VCBookcase3 || !self.VCBookcase4 || !self.VCBookcase5) {
        //VCBookcase1
        if (self.VCBookcase1) {
            self.VCBookcase1.delegateBookcaseViewController = nil;
            [self.VCBookcase1.view removeFromSuperview];
        }
        self.VCBookcase1 = [[[BookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseViewController"] bundle:nil] autorelease];
        self.VCBookcase1.delegateBookcaseViewController = self;
        
        NSArray *arrayBookID = [Bookcase1ID componentsSeparatedByString:@","];
        NSMutableArray *MABook = [NSMutableArray new];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            NSDictionary *dictionaryBook = [NSDictionary dictionaryWithObject:[arrayBookID objectAtIndex:x] forKey:@"bookID"];
            [MABook addObject:dictionaryBook];
        }
        self.VCBookcase1.MABook = [[MABook mutableCopy] autorelease];
        if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
            self.VCBookcase1.titleArray=titleArray1;
            
        }else{
            
            self.VCBookcase1.titleArray=titleArray1_s;
        }
        self.VCBookcase1.clearTitle=@"人际关系";

        self.VCBookcase1.view.transform = CGAffineTransformIdentity;
        self.VCBookcase1.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        
        
        //VCBookcase2
        if (self.VCBookcase2) {
            self.VCBookcase2.delegateBookcaseViewController = nil;
            [self.VCBookcase2.view removeFromSuperview];
        }
        self.VCBookcase2 = [[[BookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseViewController"] bundle:nil] autorelease];
        self.VCBookcase2.delegateBookcaseViewController = self;
        
        arrayBookID = [Bookcase2ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            NSDictionary *dictionaryBook = [NSDictionary dictionaryWithObject:[arrayBookID objectAtIndex:x] forKey:@"bookID"];
            [MABook addObject:dictionaryBook];
        }
        self.VCBookcase2.MABook = [[MABook mutableCopy] autorelease];
        self.VCBookcase2.titleArray=titleArray2;
        self.VCBookcase2.clearTitle=@"学校";

        self.VCBookcase2.view.transform = CGAffineTransformIdentity;
        self.VCBookcase2.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCBookcase3
        if (self.VCBookcase3) {
            self.VCBookcase3.delegateBookcaseViewController = nil;
            [self.VCBookcase3.view removeFromSuperview];
        }
        self.VCBookcase3 = [[[BookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseViewController"] bundle:nil] autorelease];
        self.VCBookcase3.delegateBookcaseViewController = self;
        
        
        arrayBookID = [Bookcase3ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            NSDictionary *dictionaryBook = [NSDictionary dictionaryWithObject:[arrayBookID objectAtIndex:x] forKey:@"bookID"];
            [MABook addObject:dictionaryBook];
        }
        self.VCBookcase3.MABook = [[MABook mutableCopy] autorelease];
        if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
            
            self.VCBookcase3.titleArray=titleArray3;
            
        }else{
            
            self.VCBookcase3.titleArray=titleArray3_s;
            
        }
        self.VCBookcase3.clearTitle=@"家庭";

        self.VCBookcase3.view.transform = CGAffineTransformIdentity;
        self.VCBookcase3.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCBookcase4
        if (self.VCBookcase4) {
            self.VCBookcase4.delegateBookcaseViewController = nil;
            [self.VCBookcase4.view removeFromSuperview];
        }
        self.VCBookcase4 = [[[BookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseViewController"] bundle:nil] autorelease];
        self.VCBookcase4.delegateBookcaseViewController = self;
        
        arrayBookID = [Bookcase4ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            NSDictionary *dictionaryBook = [NSDictionary dictionaryWithObject:[arrayBookID objectAtIndex:x] forKey:@"bookID"];
            [MABook addObject:dictionaryBook];
        }
        self.VCBookcase4.MABook = [[MABook mutableCopy] autorelease];
        self.VCBookcase4.titleArray=titleArray4;
        self.VCBookcase4.clearTitle=@"照顾自己";

        self.VCBookcase4.view.transform = CGAffineTransformIdentity;
        self.VCBookcase4.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCBookcase5
        if (self.VCBookcase5) {
            self.VCBookcase5.delegateBookcaseViewController = nil;
            [self.VCBookcase5.view removeFromSuperview];
        }
        self.VCBookcase5 = [[[BookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseViewController"] bundle:nil] autorelease];
        self.VCBookcase5.delegateBookcaseViewController = self;
        arrayBookID = [Bookcase5ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            NSDictionary *dictionaryBook = [NSDictionary dictionaryWithObject:[arrayBookID objectAtIndex:x] forKey:@"bookID"];
            [MABook addObject:dictionaryBook];
        }
        self.VCBookcase5.MABook = [[MABook mutableCopy] autorelease];
        self.VCBookcase5.titleArray=titleArray5;
        self.VCBookcase5.clearTitle=@"外出";

        self.VCBookcase5.view.transform = CGAffineTransformIdentity;
        self.VCBookcase5.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        [MABook removeAllObjects];
        [MABook release];
        
        if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
            [self.SVBookBase addSubview:self.VCBookcase1.view];
            self.VCBookcase1.view.frame = CGRectMake(0.0, 0.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCBookcase2.view];
            self.VCBookcase2.view.frame = CGRectMake(0.0, 185.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCBookcase3.view];
            self.VCBookcase3.view.frame = CGRectMake(0.0, 370.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCBookcase4.view];
            self.VCBookcase4.view.frame = CGRectMake(0.0, 555.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCBookcase5.view];
            self.VCBookcase5.view.frame = CGRectMake(0.0, 740.0, 768.0, 185.0);
        }
        else {
            [self.SVBookBase addSubview:self.VCBookcase1.view];
            self.VCBookcase1.view.frame = CGRectMake(0.0, 0.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCBookcase2.view];
            self.VCBookcase2.view.frame = CGRectMake(0.0, 130.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCBookcase3.view];
            self.VCBookcase3.view.frame = CGRectMake(0.0, 260.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCBookcase4.view];
            self.VCBookcase4.view.frame = CGRectMake(0.0, 390.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCBookcase5.view];
            self.VCBookcase5.view.frame = CGRectMake(0.0, 520.0, 320.0, 130.0);
        }
    }
    
    [self.VCBookcase1 showRating:NO];
    [self.VCBookcase2 showRating:NO];
    [self.VCBookcase3 showRating:NO];
    [self.VCBookcase4 showRating:NO];
    [self.VCBookcase5 showRating:NO];
    [self.VCBookcase1 refreshBookcase];
    [self.VCBookcase2 refreshBookcase];
    [self.VCBookcase3 refreshBookcase];
    [self.VCBookcase4 refreshBookcase];
    [self.VCBookcase5 refreshBookcase];
    
    [self.SVBookBase bringSubviewToFront:self.IVCat1];
    [self.SVBookBase bringSubviewToFront:self.IVCat2];
    [self.SVBookBase bringSubviewToFront:self.IVCat3];
    [self.SVBookBase bringSubviewToFront:self.IVCat4];
    [self.SVBookBase bringSubviewToFront:self.IVCat5];
    
    NSString *stringDeviceSuffix;
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        stringDeviceSuffix = iPadXibSuffix;
    }
    else {
        stringDeviceSuffix = iPhoneXibSuffix;
    }
    
    self.IVCat1.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_greenbanner_1%@", stringDeviceSuffix]];
    self.IVCat2.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_yollowbanner_1%@", stringDeviceSuffix]];
    self.IVCat3.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_Purplebanner_1%@", stringDeviceSuffix]];
    self.IVCat4.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_bluebanner_1%@", stringDeviceSuffix]];
    self.IVCat5.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_redbanner_1%@", stringDeviceSuffix]];
}

#pragma mark - Handle Click Button Events

- (IBAction)clickShowRatingButton:(UIButton *)button
{
    button.selected = !button.selected;
    [self.VCBookcase1 showRating:button.selected];
    [self.VCBookcase2 showRating:button.selected];
    [self.VCBookcase3 showRating:button.selected];
    [self.VCBookcase4 showRating:button.selected];
    [self.VCBookcase5 showRating:button.selected];
    [self.VCBookcase1 refreshBookcase];
    [self.VCBookcase2 refreshBookcase];
    [self.VCBookcase3 refreshBookcase];
    [self.VCBookcase4 refreshBookcase];
    [self.VCBookcase5 refreshBookcase];
}

- (IBAction)clickLastReadStarButton:(UIButton *)button
{
    for (int x = 0; self.arrayButtonLastReadStar && x < self.arrayButtonLastReadStar.count; x++) {
        if ([((UIButton *)[self.arrayButtonLastReadStar objectAtIndex:x]) isEqual:button]) {
            self.iCurrentStarNum = x + 1;
            button.selected = YES;
            for (int y = x + 1; self.arrayButtonLastReadStar && y < self.arrayButtonLastReadStar.count; y++) {
                ((UIButton *)[self.arrayButtonLastReadStar objectAtIndex:y]).selected = NO;
            }
            break;
        }
        ((UIButton *)[self.arrayButtonLastReadStar objectAtIndex:x]).selected = YES;
    }
}

- (IBAction)clickLastReadSkipButton:(UIButton *)button
{
    self.viewLastReadBase.hidden = YES;
    for (int x = 0; self.arrayButtonLastReadStar && x < self.arrayButtonLastReadStar.count; x++) {
     ((UIButton *)[self.arrayButtonLastReadStar objectAtIndex:x]).selected = NO;
    }
    self.iCurrentStarNum = UndefinedInt;
    BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
    VCBookContent.dictionaryBook = self.dictionaryCurrentLastReadBook;
    [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
    [VCBookContent release];
}

- (IBAction)clickLastReadDoneButton:(UIButton *)button
{
    if (self.dictionaryCurrentLastReadBook && self.iCurrentStarNum != UndefinedInt) {
        for (int x = 0; self.MABookScore && x < self.MABookScore.count; x++) {
            if ([[self.dictionaryCurrentLastReadBook objectForKey:@"bookID"] isEqualToString:[[self.MABookScore objectAtIndex:x] objectForKey:@"bookID"]]) {
                NSMutableArray *MAScoreList = [[self.MABookScore objectAtIndex:x] objectForKey:@"scoreList"];
                if (MAScoreList) {
                    MAScoreList = [MAScoreList mutableCopy];
                }
                else {
                    MAScoreList = [NSMutableArray new];
                }
                
                [MAScoreList addObject:[NSString stringWithFormat:@"%d", self.iCurrentStarNum]];
                [[self.MABookScore objectAtIndex:x] setObject:MAScoreList forKey:@"scoreList"];
                
                int totalScore = 0;
                for (int y = 0; MAScoreList && y < MAScoreList.count; y++) {
                    totalScore += [[MAScoreList objectAtIndex:y] intValue];
                }
                
                [[self.MABookScore objectAtIndex:x] setObject:[NSString stringWithFormat:@"%d", (int)(roundf((totalScore / MAScoreList.count)))] forKey:@"avgScore"];
                [MAScoreList release];

                
                int iViewTime = [[[self.MABookScore objectAtIndex:x] objectForKey:@"viewTime"] intValue] + 1;
                [[self.MABookScore objectAtIndex:x] setObject:[NSString stringWithFormat:@"%d", iViewTime] forKey:@"viewTime"];
                [self.MABookScore writeToFile:PlistPathBookScore atomically:YES];
                
                self.viewLastReadBase.hidden = YES;
                for (int x = 0; self.arrayButtonLastReadStar && x < self.arrayButtonLastReadStar.count; x++) {
                    ((UIButton *)[self.arrayButtonLastReadStar objectAtIndex:x]).selected = NO;
                }
                self.iCurrentStarNum = UndefinedInt;
                
                BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
                VCBookContent.dictionaryBook = self.dictionaryCurrentLastReadBook;
                [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
                [VCBookContent release];
                
                break;
            }
        }
    }
}

#pragma mark - BookcaseViewControllerDelegate

- (void)selectedBook:(NSDictionary *)dictionaryBook
{
    int iViewTime = UndefinedInt;
    for (int x = 0; self.MABookScore && x < self.MABookScore.count; x++) {
        if ([[dictionaryBook objectForKey:@"bookID"] isEqualToString:[[self.MABookScore objectAtIndex:x] objectForKey:@"bookID"]]) {
            
            self.dictionaryCurrentLastReadBook = dictionaryBook;
            
            iViewTime = [[[self.MABookScore objectAtIndex:x] objectForKey:@"viewTime"] intValue];
            
            if (iViewTime == 0) {
                DEBUGMSG(@"iViewTime == 0");
                iViewTime++;
                [[self.MABookScore objectAtIndex:x] setObject:[NSString stringWithFormat:@"%d", iViewTime] forKey:@"viewTime"];
                [self.MABookScore writeToFile:PlistPathBookScore atomically:YES];
                BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
                VCBookContent.dictionaryBook = dictionaryBook;
                [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
                [VCBookContent release];
            }
            else {
                DEBUGMSG(@"viewTime > 1");
                self.viewLastReadBase.hidden = NO;
            }
        }
    }
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [topLogo release];
    topLogo = nil;
    [leftBtn release];
    leftBtn = nil;
    [rightBtn release];
    rightBtn = nil;
    [grayImg release];
    grayImg = nil;
    [story100Logo release];
    story100Logo = nil;
    [skipBtn release];
    skipBtn = nil;
    [lastReadDoneBtn release];
    lastReadDoneBtn = nil;
    [super viewDidUnload];
}
@end
