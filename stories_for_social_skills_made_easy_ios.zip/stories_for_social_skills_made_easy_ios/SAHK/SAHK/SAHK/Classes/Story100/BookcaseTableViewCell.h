//
//  BookcaseTableViewCell.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookcaseTableViewCell : UITableViewCell

@property (nonatomic, retain) NSString *stringBookID;
@property (retain, nonatomic) IBOutlet UILabel *clearLbl;

#pragma mark - Core

- (void)reset;
- (void)setupView:(UIImage *)imageBook;
- (void)showRating:(BOOL)bShow;

@end
