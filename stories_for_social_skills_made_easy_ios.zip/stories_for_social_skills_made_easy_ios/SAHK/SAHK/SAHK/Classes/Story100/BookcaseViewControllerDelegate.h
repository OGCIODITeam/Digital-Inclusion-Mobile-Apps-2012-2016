//
//  BookcaseViewControllerDelegate.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BookcaseViewController;

@protocol BookcaseViewControllerDelegate <NSObject>

@optional

- (void)selectedBook:(NSDictionary *)dictionaryBook;
@end
