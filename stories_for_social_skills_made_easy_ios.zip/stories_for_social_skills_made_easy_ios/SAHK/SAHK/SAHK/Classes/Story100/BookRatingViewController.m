//
//  BookRatingViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookRatingViewController.h"

@interface BookRatingViewController ()

@end

@implementation BookRatingViewController

@synthesize labelViewTimeValue = _labelViewTimeValue;
@synthesize IVStar1 = _IVStar1, IVStar2 = _IVStar2, IVStar3 = _IVStar3, IVStar4 = _IVStar4, IVStar5 = _IVStar5;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.labelViewTimeValue = nil;
    self.IVStar1 = nil;
    self.IVStar2 = nil;
    self.IVStar3 = nil;
    self.IVStar4 = nil;
    self.IVStar5 = nil;
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
