//
//  SocialStoryRecordFormViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月30日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "SocialStoryRecordFormViewController.h"

@interface SocialStoryRecordFormViewController () <UIWebViewDelegate>

@property (nonatomic, retain) IBOutlet UIWebView *WV;
@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

@end

@implementation SocialStoryRecordFormViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.WV.delegate = nil;
    self.WV = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    [topNav release];
    [leftBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        self.WV.frame=CGRectMake( self.WV.frame.origin.x,  self.WV.frame.origin.y+20,  self.WV.frame.size.width,  self.WV.frame.size.height-20);
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"sahk_form"];
    if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
        [self.WV loadHTMLString:@"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><title>Untitled Document</title></head><body><!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"><HTML><!-- 		@page { margin: 2cm } 		P { margin-bottom: 0.21cm } 		A:link { color: #0000ff } 	--><BODY LANG=\"zh-HK\" LINK=\"#0000ff\" DIR=\"LTR\"><p><U><strong>紀錄表格</strong></U></p><p><BR></p><p>請按有關連結下載所需表格：</p><p><SPAN LANG=\"en-US\"><BR></SPAN>社交故事施行計畫紀錄表<SPAN LANG=\"en-US\"><BR><U><A HREF=\"http://www.sahk1963.org.hk/files/download_public/24092013_1.pdf\" TARGET=\"_blank\">http://www.sahk1963.org.hk/files/download_public/24092013_1.pdf</A></U><BR></SPAN><BR></p><p>社文故事效用檢討表<SPAN LANG=\"en-US\"><BR><U><A HREF=\"http://www.sahk1963.org.hk/files/download_public/24092013_2.pdf\" TARGET=\"_blank\">http://www.sahk1963.org.hk/files/download_public/24092013_2.pdf</A></U><BR></SPAN><BR></p><p>社交故事編寫檢討表<SPAN LANG=\"en-US\"><BR><U><A HREF=\"http://www.sahk1963.org.hk/files/download_public/24092013_3.pdf\" TARGET=\"_blank\">http://www.sahk1963.org.hk/files/download_public/24092013_3.pdf</A></U></SPAN></p></body></html>" baseURL:nil];
    }
    else {
        [self.WV loadHTMLString:@"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><title>Untitled Document</title></head><body><!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"><HTML><!-- 		@page { margin: 2cm } 		P { margin-bottom: 0.21cm } 		A:link { color: #0000ff } 	--><BODY LANG=\"zh-HK\" LINK=\"#0000ff\" DIR=\"LTR\"><p><U><strong>纪录表格</strong></U></p><p><BR></p><p>请按有关连结下载所需表格：</p><p><SPAN LANG=\"en-US\"><BR></SPAN>社交故事施行计画纪录表<SPAN LANG=\"en-US\"><BR><U><A HREF=\"http://www.sahk1963.org.hk/files/download_public/24092013_1.pdf\" TARGET=\"_blank\">http://www.sahk1963.org.hk/files/download_public/24092013_1.pdf</A></U><BR></SPAN><BR></p><p>社文故事效用检讨表<SPAN LANG=\"en-US\"><BR><U><A HREF=\"http://www.sahk1963.org.hk/files/download_public/24092013_2.pdf\" TARGET=\"_blank\">http://www.sahk1963.org.hk/files/download_public/24092013_2.pdf</A></U><BR></SPAN><BR></p><p>社交故事编写检讨表<SPAN LANG=\"en-US\"><BR><U><A HREF=\"http://www.sahk1963.org.hk/files/download_public/24092013_3.pdf\" TARGET=\"_blank\">http://www.sahk1963.org.hk/files/download_public/24092013_3.pdf</A></U></SPAN></p></body></html>" baseURL:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if ([request.URL.absoluteString isEqualToString:@"http://www.sahk1963.org.hk/files/download_public/24092013_1.pdf"] || [request.URL.absoluteString isEqualToString:@"http://www.sahk1963.org.hk/files/download_public/24092013_2.pdf"] || [request.URL.absoluteString isEqualToString:@"http://www.sahk1963.org.hk/files/download_public/24092013_3.pdf"]) {
        [[UIApplication sharedApplication] openURL:request.URL];
        return NO;
    }
    return YES;
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [super viewDidUnload];
}
@end
