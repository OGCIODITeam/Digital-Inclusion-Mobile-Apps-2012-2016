//
//  SocialStoryNoticeViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月30日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "SocialStoryNoticeViewController.h"

@interface SocialStoryNoticeViewController () <UIWebViewDelegate>

@property (nonatomic, retain) IBOutlet UIWebView *WV;
@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

@end

@implementation SocialStoryNoticeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.WV.delegate = nil;
    self.WV = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    [topNav release];
    [leftBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        self.WV.frame=CGRectMake( self.WV.frame.origin.x,  self.WV.frame.origin.y+20,  self.WV.frame.size.width,  self.WV.frame.size.height-20);
        
    }
    
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"sahk_note"];
    
    if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
            [self.WV loadHTMLString:@"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><title>Untitled Document</title><style type=\"text/css\">.blue1 {color: #5592DB;}.green1 {color: #479946;}</style></head><body><!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"><HTML><!-- 		@page { margin: 2cm } 		P { margin-bottom: 0.21cm }A:link { so-language: zxx } --><BODY DIR=\"LTR\"><p ALIGN=\"JUSTIFY\"><U><strong>使用社交故事需知</strong></U></p><p ALIGN=\"JUSTIFY\"><BR></p><OL><LI><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK140\"></A><A NAME=\"OLE_LINK141\"></A> <strong>《社交故事一按通》是什麼？</strong></p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK54\"></A><A NAME=\"OLE_LINK55\"></A><A NAME=\"OLE_LINK63\"></A><A NAME=\"OLE_LINK64\"></A> 自閉症兒童往往對多變的社交處境感到無所適從，《社交故事一按通》軟件，藉着故事與自閉症兒童客觀地分享社交處境的資料，從而加深他們對社交處境的理解，讓他們明白在處境中別人對他們的期望，並引導他們學習作出恰當的社交行為和態度。</p><p LANG=\"zh-HK\" ALIGN=\"JUSTIFY\"><BR></p><OL START=\"2\"><LI><p><A NAME=\"OLE_LINK98\"></A><A NAME=\"OLE_LINK99\"></A> <strong>如何選擇合適的社交故事？</strong></p></OL><p>選擇社交故事時可跟隨以下流程進行：</p><OL><OL><LI><p>了解兒童的需要</p></OL></OL><p> 可以訪問熟悉兒童的人或者兒童自己，亦可以觀察兒童在不同場合或環境的表現，以了解行為的原因。從兒童的角度出發，觀察兒童會在哪些時候可能會做出恰當的行為，哪些東西在兒童眼中是很重要的等等。</p><OL><OL START=\"2\"><LI><p>確定目標</p><OL><LI><p ALIGN=\"JUSTIFY\">引導恰當的社交技巧</p><LI><p ALIGN=\"JUSTIFY\">教導日常的程序或常規</p><LI><p ALIGN=\"JUSTIFY\">預備兒童適應新轉變</p><LI><p ALIGN=\"JUSTIFY\">讓幼兒學習處理負面情緒</p><LI><p ALIGN=\"JUSTIFY\">幫助兒童掌握不熟悉的社交處境資料</p><LI><p ALIGN=\"JUSTIFY\">提供有關最困擾兒童的社交場合或情景的資料</p></OL><LI><p>檢視社交故事</p></OL></OL><p> 本軟件內故事共分五個主題：</p><OL><OL><OL><LI><p>人際關係</p><LI><p>學校</p><LI><p>家庭</p><LI><p>照顧自己</p><LI><p>外出</p></OL></OL></OL><p> 使用者可根據已訂立目標，選用適當故事並在需要時對內容作出修改。進階使用者在熟習社交故事的使用後，可自行編寫有關內容。請留意，本軟件的故事內容可作基本修改，但不包括自行編寫功能。</p><OL><OL START=\"4\"><LI><p>訂立施行計劃</p></OL></OL><p> 完整的施行計劃需包含下列元素：</p><OL><OL><OL><LI><p>具體目標</p><LI><p>施行時段</p><LI><p>閱讀頻次（如每天一遍、兩遍或兩天一遍）</p><LI><p>閱讀次數</p><LI> <p>閱讀時間</p></OL></OL></OL><p><BR></p><OL START=\"3\"><LI><p><A NAME=\"OLE_LINK94\"></A><A NAME=\"OLE_LINK95\"></A> <strong>修改故事內容時有甚麼注意事項？</strong></p></OL><p ALIGN=\"JUSTIFY\">由於每個兒童都是獨特的個體，他們的需要也各有不同。因此，本軟件使用括號標示出部份的故事內容，讓用家根據兒童實際的生活或需要，更改被括號標示的部份，例如：</p><OL><LI><p ALIGN=\"JUSTIFY\"> 修改背景資料：</p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK35\"></A><A NAME=\"OLE_LINK36\"></A> 用家可依兒童實際的生活情景和理解能力修改時間、地點、人物等背景資料，好像：把「等候司機<span class=\"blue1\">(叔叔)</span>開車」改為「等候司機<span class=\"green1\">嬸嬸</span>開車」、把較抽象的「我見到<span class=\"blue1\">(喜歡的小朋友)</span>時</p><p ALIGN=\"JUSTIFY\"> 改為具體的「我見到<span class=\"green1\">小傑</span>時」…等。</p><OL START=\"2\"><LI><p ALIGN=\"JUSTIFY\"> 修改建議的方法：</p></OL><p ALIGN=\"JUSTIFY\"> 用家可以把故事建議的方法改為對個別兒童來說更有效的方法，例如：把「嘗試<span class=\"blue1\">(深呼吸)</span>」改為「嘗試<span class=\"green1\">在心裡數數目字一至十</span></p><p ALIGN=\"JUSTIFY\"> 。</p><OL START=\"3\"><LI><p ALIGN=\"JUSTIFY\"> 修改建議的幼兒用語：</p></OL><p ALIGN=\"JUSTIFY\"> 部份故事設有建議的幼兒用語，如：「<span class=\"blue1\">(問)</span>媽媽:『<span class=\"blue1\">(我可唔可以遲啲先瞓覺呀?)</span> 』。用家可依幼兒的語言能力增減其句子長度和複雜性，或適量地修改句子的類型，例如：為較少發問的幼兒把以上問句改為「<span class=\"green1\">告訴</span>媽媽：『<span class=\"green1\">我想遲啲先瞓覺</span>!』」。</p><OL START=\"4\"><LI><p ALIGN=\"JUSTIFY\"> 修改<U class=\"blue1\">透視句</U>和<span class=\"blue1\"><U>肯定句</U></span>：</p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK11\"></A><A NAME=\"OLE_LINK12\"></A> 兒童理解情感詞的能力各有不同，好像：有些兒童會明白什麼是「人們會感到很舒服」，有些兒童則不太明白。有些兒童喜歡被人稱讚為「好孩子」、「聰明」、「有禮貌」…等等；有些兒童則更喜歡一些相對具體的回應，如：「爸爸媽媽就會帶我到公園玩」，用家可因應兒童的喜好和理解能力加以修改<U class=\"blue1\">透視句</U>和<U class=\"blue1\">肯定句</U>。</p><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK57\"></A><A NAME=\"OLE_LINK58\"></A><A NAME=\"OLE_LINK9\"></A><A NAME=\"OLE_LINK10\"></A><A NAME=\"OLE_LINK125\"></A> 為確保每一個故事都依照Carol Gray所建議的社交故事句子比例而編寫，我們建議用家<strong>只</strong>按需要<strong>修改括號標示出的部份</strong>，並使用<strong>社交故事編寫檢討表</strong>作檢討。</p><p><BR></p><OL START=\"4\"><LI><p><strong>如何進行成效檢討？</strong></p></OL><p ALIGN=\"JUSTIFY\"> 家長和老師與兒童閱讀社交故事後，除了需要持續地觀察兒童的反應和表現，也要檢討社交故事施行的成效，以評估社交活動對兒童的影響，釐定是否有修改故事內容的必要。成效檢討請參考以下資料：</p><p ALIGN=\"JUSTIFY\"><BR></p><OL><LI><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK102\"></A><A NAME=\"OLE_LINK103\"></A> 資料搜集</p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK104\"></A><A NAME=\"OLE_LINK105\"></A> 要考慮檢討資料搜集的方法是否恰當、所搜集的資料是否全面準確 ，例如有沒有現場觀察兒童的表現；訪問有關教職員、家長，甚至兒童本身；從兒童的角度出發考慮需要或問題所在；深入了解兒童的能力、興趣和喜好等等。</p><OL START=\"2\"><LI><p ALIGN=\"JUSTIFY\"> 目標訂立</p></OL><p ALIGN=\"JUSTIFY\"> 評估施行社交故事的目標是否由兒童的角度出發並針對兒童的需要或困難，這能確保社交故事是為兒童的需要而編寫，並非是一種用來控制兒童社交行為的工具。</p><OL START=\"3\"><LI><p ALIGN=\"JUSTIFY\"> 問題分析</p></OL><p ALIGN=\"JUSTIFY\"> 家長和老師要仔細地檢討之前的分析是否客觀正確，有否清楚地探究行為背後的原因。這些資料都直接影響社交故事的效用。舉例來說，我們曾為一名不懂得參與小組遊戲而表現不知所措的兒童編寫社交故事，描述老師會教導小朋友玩遊戲，引導兒童了解可以嘗試跟從老師的指示學習玩遊戲的信息。經過多次觀察，我們發現兒童雖然能明白故事的內容，但卻並未因此而做出目標行為。檢討過兒童的反應和故事內容後，我們發現兒童表現不知所措背後的原因，其實在於他不懂得玩遊戲但又不懂得向人求助，於是我們把「跟從老師學習」的信息修改為「可以舉手請老師教導」，把故事內容修訂得更切合兒童的需要。</p><OL START=\"4\"><LI><p ALIGN=\"JUSTIFY\"> <strong>社交故事</strong></p></OL><p ALIGN=\"JUSTIFY\"> 教導者需要評估故事本身能否切合所訂立的目標，內容是否交待準確的社交資料和社交處境的重心、一般人的觀點及預期的反應。此外，亦要檢討故事內容是否配合兒童的需要而加入引導正確、可接受行為和態度的資料。</p><OL START=\"5\"><LI><p ALIGN=\"JUSTIFY\"> <strong>施行方法與技巧</strong></p></OL><p ALIGN=\"JUSTIFY\"> 分析閱讀的時間、地點及人選是否恰當；閱讀的方法能否配合兒童的能力和興趣。若果是由一位以上的教導者跟兒童閱讀故事，要檢討各人閱讀方法是否一致。</p><p ALIGN=\"JUSTIFY\"> 整個施行過程是否包括「介紹」、「閱讀」及「淡出」三個階段、有否因應兒童的進展而調適。到兒童已能明白並掌握社交故事所描述的技巧，便可以逐漸減少閱讀的次數，但仍然把社交故事書放在當眼處，方便兒童在有需要時馬上翻閱。相反，若兒童對故事內容還不能理解，就需要考慮在日常生活中加插相關的活動或角色扮演，幫助兒童加快理解內容。</p><p ALIGN=\"JUSTIFY\"><BR></p><p ALIGN=\"JUSTIFY\">若想了解多一些關於社交故事的資料，可登入以下連結：</p><p ALIGN=\"JUSTIFY\"><A HREF=\"http://rehabguide.hk/skill_ss.php?id=10\">http://rehabguide.hk/skill_ss.php?id=10</A></p></body></html>" baseURL:nil];
    }
    else {
        [self.WV loadHTMLString:@"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><title>Untitled Document</title><style type=\"text/css\">.blue1 {color: #5592DB;}.green1 {color: #479946;}</style></head><body><!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"><HTML><!-- 		@page { margin: 2cm } 		P { margin-bottom: 0.21cm }A:link { so-language: zxx } --><BODY DIR=\"LTR\"><p ALIGN=\"JUSTIFY\"><U><strong>使用社交故事需知</strong></U></p><p ALIGN=\"JUSTIFY\"><BR></p><OL><LI><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK140\"></A><A NAME=\"OLE_LINK141\"></A> <strong>《社交故事一按通》是什麽？</strong></p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK54\"></A><A NAME=\"OLE_LINK55\"></A><A NAME=\"OLE_LINK63\"></A><A NAME=\"OLE_LINK64\"></A> 自闭症儿童往往对多变的社交处境感到无所适从，《社交故事一按通》软件，藉着故事与自闭症儿童客观地分享社交处境的资料，从而加深他们对社交处境的理解，让他们明白在处境中别人对他们的期望，并引导他们学习作出恰当的社交行为和态度。</p><p LANG=\"zh-HK\" ALIGN=\"JUSTIFY\"><BR></p><OL START=\"2\"><LI><p><A NAME=\"OLE_LINK98\"></A><A NAME=\"OLE_LINK99\"></A> <strong>如何选择合适的社交故事？</strong></p></OL><p>选择社交故事时可跟随以下流程进行：</p><OL><OL><LI><p>了解儿童的需要</p></OL></OL><p> 可以访问熟悉儿童的人或者儿童自己，亦可以观察儿童在不同场合或环境的表现，以了解行为的原因。从儿童的角度出发，观察儿童会在哪些时候可能会做出恰当的行为，哪些东西在儿童眼中是很重要的等等。</p><OL><OL START=\"2\"><LI><p>确定目标</p><OL><LI><p ALIGN=\"JUSTIFY\">引导恰当的社交技巧</p><LI><p ALIGN=\"JUSTIFY\">教导日常的程序或常规</p><LI><p ALIGN=\"JUSTIFY\">预备儿童适应新转变</p><LI><p ALIGN=\"JUSTIFY\">让幼儿学习处理负面情绪</p><LI><p ALIGN=\"JUSTIFY\">帮助儿童掌握不熟悉的社交处境资料</p><LI><p ALIGN=\"JUSTIFY\">提供有关最困扰儿童的社交场合或情景的资料</p></OL><LI><p>检视社交故事</p></OL></OL><p> 本软件内故事共分五个主题：</p><OL><OL><OL><LI><p>人际关系</p><LI><p>学校</p><LI><p>家庭</p><LI><p>照顾自己</p><LI><p>外出</p></OL></OL></OL><p> 使用者可根据已订立目标，选用适当故事并在需要时对内容作出修改。进阶使用者在熟习社交故事的使用後，可自行编写有关内容。请留意，本软件的故事内容可作基本修改，但不包括自行编写功能。</p><OL><OL START=\"4\"><LI><p>订立施行计划</p></OL></OL><p> 完整的施行计划需包含下列元素：</p><OL><OL><OL><LI><p>具体目标</p><LI><p>施行时段</p><LI><p>阅读频次（如每天一遍丶两遍或两天一遍）</p><LI><p>阅读次数</p><LI> <p>阅读时间</p></OL></OL></OL><p><BR></p><OL START=\"3\"><LI><p><A NAME=\"OLE_LINK94\"></A><A NAME=\"OLE_LINK95\"></A> <strong>修改故事内容时有甚麽注意事项？</strong></p></OL><p ALIGN=\"JUSTIFY\">由於每个儿童都是独特的个体，他们的需要也各有不同。因此，本软件使用括号标示出部份的故事内容，让用家根据儿童实际的生活或需要，更改被括号标示的部份，例如：</p><OL><LI><p ALIGN=\"JUSTIFY\"> 修改背景资料：</p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK35\"></A><A NAME=\"OLE_LINK36\"></A> 用家可依儿童实际的生活情景和理解能力修改时间丶地点丶人物等背景资料，好像：把「等候司机<span class=\"blue1\">(叔叔)</span>开车」改为「等候司机<span class=\"green1\">婶婶</span>开车」丶把较抽象的「我见到<span class=\"blue1\">(喜欢的小朋友)</span>时</p><p ALIGN=\"JUSTIFY\"> 改为具体的「我见到<span class=\"green1\">小杰</span>时」…等。</p><OL START=\"2\"><LI><p ALIGN=\"JUSTIFY\"> 修改建议的方法：</p></OL><p ALIGN=\"JUSTIFY\"> 用家可以把故事建议的方法改为对个别儿童来说更有效的方法，例如：把「尝试<span class=\"blue1\">(深呼吸)</span>」改为「尝试<span class=\"green1\">在心里数数目字一至十</span></p><p ALIGN=\"JUSTIFY\"> 。</p><OL START=\"3\"><LI><p ALIGN=\"JUSTIFY\"> 修改建议的幼儿用语：</p></OL><p ALIGN=\"JUSTIFY\"> 部份故事设有建议的幼儿用语，如：「<span class=\"blue1\">(问)</span>妈妈:『<span class=\"blue1\">(我可唔可以迟啲先瞓觉呀?)</span> 』。用家可依幼儿的语言能力增减其句子长度和复杂性，或适量地修改句子的类型，例如：为较少发问的幼儿把以上问句改为「<span class=\"green1\">告诉</span>妈妈：『<span class=\"green1\">我想迟啲先瞓觉</span>!』」。</p><OL START=\"4\"><LI><p ALIGN=\"JUSTIFY\"> 修改<U class=\"blue1\">透视句</U>和<span class=\"blue1\"><U>肯定句</U></span>：</p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK11\"></A><A NAME=\"OLE_LINK12\"></A> 儿童理解情感词的能力各有不同，好像：有些儿童会明白什麽是「人们会感到很舒服」，有些儿童则不太明白。有些儿童喜欢被人称赞为「好孩子」丶「聪明」丶「有礼貌」…等等；有些儿童则更喜欢一些相对具体的回应，如：「爸爸妈妈就会带我到公园玩」，用家可因应儿童的喜好和理解能力加以修改<U class=\"blue1\">透视句</U>和<U class=\"blue1\">肯定句</U>。</p><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK57\"></A><A NAME=\"OLE_LINK58\"></A><A NAME=\"OLE_LINK9\"></A><A NAME=\"OLE_LINK10\"></A><A NAME=\"OLE_LINK125\"></A> 为确保每一个故事都依照Carol Gray所建议的社交故事句子比例而编写，我们建议用家<strong>只</strong>按需要<strong>修改括号标示出的部份</strong>，并使用<strong>社交故事编写检讨表</strong>作检讨。</p><p><BR></p><OL START=\"4\"><LI><p><strong>如何进行成效检讨？</strong></p></OL><p ALIGN=\"JUSTIFY\"> 家长和老师与儿童阅读社交故事後，除了需要持续地观察儿童的反应和表现，也要检讨社交故事施行的成效，以评估社交活动对儿童的影响，厘定是否有修改故事内容的必要。成效检讨请参考以下资料：</p><p ALIGN=\"JUSTIFY\"><BR></p><OL><LI><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK102\"></A><A NAME=\"OLE_LINK103\"></A> 资料搜集</p></OL><p ALIGN=\"JUSTIFY\"><A NAME=\"OLE_LINK104\"></A><A NAME=\"OLE_LINK105\"></A> 要考虑检讨资料搜集的方法是否恰当丶所搜集的资料是否全面准确 ，例如有没有现场观察儿童的表现；访问有关教职员丶家长，甚至儿童本身；从儿童的角度出发考虑需要或问题所在；深入了解儿童的能力丶兴趣和喜好等等。</p><OL START=\"2\"><LI><p ALIGN=\"JUSTIFY\"> 目标订立</p></OL><p ALIGN=\"JUSTIFY\"> 评估施行社交故事的目标是否由儿童的角度出发并针对儿童的需要或困难，这能确保社交故事是为儿童的需要而编写，并非是一种用来控制儿童社交行为的工具。</p><OL START=\"3\"><LI><p ALIGN=\"JUSTIFY\"> 问题分析</p></OL><p ALIGN=\"JUSTIFY\"> 家长和老师要仔细地检讨之前的分析是否客观正确，有否清楚地探究行为背後的原因。这些资料都直接影响社交故事的效用。举例来说，我们曾为一名不懂得参与小组游戏而表现不知所措的儿童编写社交故事，描述老师会教导小朋友玩游戏，引导儿童了解可以尝试跟从老师的指示学习玩游戏的信息。经过多次观察，我们发现儿童虽然能明白故事的内容，但却并未因此而做出目标行为。检讨过儿童的反应和故事内容後，我们发现儿童表现不知所措背後的原因，其实在於他不懂得玩游戏但又不懂得向人求助，於是我们把「跟从老师学习」的信息修改为「可以举手请老师教导」，把故事内容修订得更切合儿童的需要。</p><OL START=\"4\"><LI><p ALIGN=\"JUSTIFY\"> <strong>社交故事</strong></p></OL><p ALIGN=\"JUSTIFY\"> 教导者需要评估故事本身能否切合所订立的目标，内容是否交待准确的社交资料和社交处境的重心丶一般人的观点及预期的反应。此外，亦要检讨故事内容是否配合儿童的需要而加入引导正确丶可接受行为和态度的资料。</p><OL START=\"5\"><LI><p ALIGN=\"JUSTIFY\"> <strong>施行方法与技巧</strong></p></OL><p ALIGN=\"JUSTIFY\"> 分析阅读的时间丶地点及人选是否恰当；阅读的方法能否配合儿童的能力和兴趣。若果是由一位以上的教导者跟儿童阅读故事，要检讨各人阅读方法是否一致。</p><p ALIGN=\"JUSTIFY\"> 整个施行过程是否包括「介绍」丶「阅读」及「淡出」三个阶段丶有否因应儿童的进展而调适。到儿童已能明白并掌握社交故事所描述的技巧，便可以逐渐减少阅读的次数，但仍然把社交故事书放在当眼处，方便儿童在有需要时马上翻阅。相反，若儿童对故事内容还不能理解，就需要考虑在日常生活中加插相关的活动或角色扮演，帮助儿童加快理解内容。</p><p ALIGN=\"JUSTIFY\"><BR></p><p ALIGN=\"JUSTIFY\">若想了解多一些关於社交故事的资料，可登入以下连结：</p><p ALIGN=\"JUSTIFY\"><A HREF=\"http://rehabguide.hk/skill_ss.php?id=10\">http://rehabguide.hk/skill_ss.php?id=10</A></p></body></html>" baseURL:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if ([request.URL.absoluteString isEqualToString:@"http://rehabguide.hk/skill_ss.php?id=10"]) {
        [[UIApplication sharedApplication] openURL:request.URL];
        return NO;
    }
    return YES;
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [super viewDidUnload];
}
@end
