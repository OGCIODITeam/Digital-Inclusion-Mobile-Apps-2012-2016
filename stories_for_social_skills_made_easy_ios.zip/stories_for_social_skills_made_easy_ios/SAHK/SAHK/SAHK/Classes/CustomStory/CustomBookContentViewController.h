//
//  CustomBookContentViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月22日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface CustomBookContentViewController : UIViewController{

    IBOutlet UIButton *editButton;
    
    IBOutlet UIButton *newAddHeadBtn;
    
    
    IBOutlet UIButton *startRecordBtn;
    
    IBOutlet UIButton *closeRecordBtn;
    
    IBOutlet UIImageView *topNav;
    
    IBOutlet LeftMenuButton *leftBtn;
    
    IBOutlet UIImageView *topLogo;
    
    

}

@property (nonatomic, retain) NSDictionary *dictionaryBook;
@property (nonatomic, retain) UIImage *imageFromVCNewHead;
@property (nonatomic, assign) BOOL bIsEditMode;
@property (nonatomic, assign) BOOL bPushFromBookmarkView;
@end
