//
//  CustomBookTitleViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomBookTitleViewController : UIViewController

@property (nonatomic, retain) IBOutlet UILabel *labelCutomTitle;

@end
