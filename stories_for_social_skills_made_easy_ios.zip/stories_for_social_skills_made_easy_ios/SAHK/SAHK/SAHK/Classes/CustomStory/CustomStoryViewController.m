//
//  CustomStoryViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月18日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "CustomStoryViewController.h"
#import "CustomStoryBookcaseTableViewCell.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "SSZipArchive.h"

@interface CustomStoryViewController () <UITableViewDataSource, UITableViewDelegate, CBCentralManagerDelegate, CBPeripheralDelegate, SSZipArchiveDelegate>

@property (nonatomic, retain) NSMutableArray *MACustomBook;
@property (nonatomic, retain) IBOutlet UITableView *TBVCustomBook;
@property (nonatomic, retain) IBOutlet UIImageView *IVTitleCustomStory;
@property (nonatomic, retain) IBOutlet UIView *viewBluetoothShareBase;
@property (nonatomic, retain) IBOutlet UILabel *labelBluetoothShareValue;

@property (nonatomic, retain) CBCentralManager *CM;
@property (nonatomic, retain) CBPeripheral *peripheralDiscovered;
@property (nonatomic, retain) NSMutableData *MData;
@property (nonatomic, assign) int iSavingDataHeartbeat;
@property (nonatomic, retain) IBOutlet UIButton *buttonBluetoothShareDone;

@property (nonatomic, retain) NSDictionary *dictionaryStoryText;

#pragma mark - Core

- (void)setup;
- (void)setupView;

#pragma mark - Handle Click Button Events

- (IBAction)clickBluetoothButton:(UIButton *)button;
- (IBAction)clickBluetoothShareDoneButton:(UIButton *)button;

@end

@implementation CustomStoryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.MACustomBook = [[NSMutableArray new] autorelease];
        self.MData = [[NSMutableData new] autorelease];
        self.iSavingDataHeartbeat = 1;
    }
    return self;
}

- (void)dealloc
{
    [self.MACustomBook removeAllObjects];
    self.MACustomBook = nil;
    
    self.TBVCustomBook.delegate = nil;
    self.TBVCustomBook.dataSource = nil;
    self.TBVCustomBook = nil;
    
    self.IVTitleCustomStory.image = nil;
    self.IVTitleCustomStory = nil;
    
    self.viewBluetoothShareBase = nil;
    self.labelBluetoothShareValue = nil;
    
    self.CM.delegate = nil;
    self.CM = nil;
    
    self.peripheralDiscovered = nil;
    self.MData = nil;
    
    self.buttonBluetoothShareDone = nil;
    
    [topNav release];
    [leftBtn release];
    [rightBtn release];
    [topLogo release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.x, topNav.frame.size.width, topNav.frame.size.height+20);
        topLogo.frame=CGRectMake(topLogo.frame.origin.x,topLogo.frame.origin.y+20, topLogo.frame.size.width, topLogo.frame.size.height);
        //        grayImg.frame=CGRectMake(grayImg.frame.origin.x, grayImg.frame.origin.y+20, grayImg.frame.size.width, grayImg.frame.size.height);
        //
        //        Story100Logo.frame=CGRectMake(Story100Logo.frame.origin.x, Story100Logo.frame.origin.y+20, Story100Logo.frame.size.width, Story100Logo.frame.size.height);
        rightBtn.frame=CGRectMake(rightBtn.frame.origin.x, rightBtn.frame.origin.y+20, rightBtn.frame.size.width, rightBtn.frame.size.height);
        
        self.TBVCustomBook.frame=CGRectMake( self.TBVCustomBook.frame.origin.x,  self.TBVCustomBook.frame.origin.y+20,  self.TBVCustomBook.frame.size.width,  self.TBVCustomBook.frame.size.height-20);
        
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [rightBtn setTitle:@"蓝牙" forState:UIControlStateNormal];
    [rightBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [rightBtn setImage:[UIImage imageNamed:@"cs_report_bluetooth_up.png"] forState:UIControlStateNormal];

    [self setup];
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    //20131104
    NSFileManager *FM = [NSFileManager defaultManager];
    if (![FM fileExistsAtPath:PathCustomFolder]) {
        BOOL bIsSuccessful = [FM createDirectoryAtPath:PathCustomFolder withIntermediateDirectories:YES attributes:nil error:nil];
        if (!bIsSuccessful) {
            return;
        }
    }
    
    [self.MACustomBook removeAllObjects];
    FM = [NSFileManager defaultManager];
    NSError *Err;
    for (NSString *stringCustomBookFolderName in [FM contentsOfDirectoryAtPath:PathCustomFolder error:&Err]) {
        NSString *stringCustomBookFolderPath = [NSString stringWithFormat:@"%@/%@", PathCustomFolder, stringCustomBookFolderName];
        for (NSString *stringFileName in [FM contentsOfDirectoryAtPath:stringCustomBookFolderPath error:&Err]) {
            NSString *stringFilePath = [NSString stringWithFormat:@"%@/%@", stringCustomBookFolderPath, stringFileName];
            if (stringFileName && [stringFileName rangeOfString:@".plist"].location != NSNotFound) {
                NSDictionary *dictionaryStoryContent = [NSDictionary dictionaryWithContentsOfFile:stringFilePath];
                [self.MACustomBook addObject:[NSDictionary dictionaryWithObjectsAndKeys:stringCustomBookFolderPath, @"customStoryFolderPath", [dictionaryStoryContent objectForKey:@"originalStoryID"], @"bookID",  nil]];
            }
        }
        
    }
    
    self.dictionaryStoryText = [NSDictionary dictionaryWithContentsOfFile:PlistFilename];
    
    DEBUGMSG(@"＝＝反反复复反复＝%@", self.MACustomBook);
}

- (void)setupView
{
    self.IVTitleCustomStory.image = [[CoreData sharedCoreData] getImageByLanguage:@"sahk_my_story"];
    [self.TBVCustomBook reloadData];
}

- (NSString *)loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:(NSString *)stringStoryContentKey CustomStoryFolderPath:(NSString *)stringCustomStoryFolderPath bookID:(int)iBookID
{
    if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/%@", stringCustomStoryFolderPath, [NSString stringWithFormat:@"storyContent%d.plist", iBookID]]] && [[NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",stringCustomStoryFolderPath, [NSString stringWithFormat:@"storyContent%d.plist", iBookID]]] objectForKey:stringStoryContentKey]) {
        
        return [[NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", stringCustomStoryFolderPath, [NSString stringWithFormat:@"storyContent%d.plist", iBookID]]] objectForKey:stringStoryContentKey];
    }
    return [self.dictionaryStoryText objectForKey:stringStoryContentKey];
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        return ceilf(self.MACustomBook.count / 5.0);
    }
    return ceilf(self.MACustomBook.count / 3.0);
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        return 185.0;
    }
    return 130.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"CustomStoryBookcaseTableViewCell";
    CustomStoryBookcaseTableViewCell *cell = (CustomStoryBookcaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomStoryBookcaseTableViewCell"] owner:nil options:nil];
        for(id currentObject in objectArray) {
            if([currentObject isKindOfClass:[UITableViewCell class]]) {
                cell = (CustomStoryBookcaseTableViewCell *)currentObject;
                break;
            }
        }
    }
    
    
    NSString *stringIVBookImageSuffix;
    if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
        stringIVBookImageSuffix = @"_c_t_ct.png";
    }
    else {
        stringIVBookImageSuffix = @"_c_s_sc.png";
    }
    
    [cell reset];
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        if ((indexPath.row * 5) < self.MACustomBook.count) {
            cell.dictionaryBook1 = [self.MACustomBook objectAtIndex:(indexPath.row * 5)];
            cell.IVBook1.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:(indexPath.row * 5)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase1.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook1 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook1 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle1.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
        if (((indexPath.row * 5) + 1) < self.MACustomBook.count) {
            cell.dictionaryBook2 = [self.MACustomBook objectAtIndex:((indexPath.row * 5) + 1)];
            cell.IVBook2.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:((indexPath.row * 5) + 1)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase2.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook2 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook2 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle2.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
        if (((indexPath.row * 5) + 2) < self.MACustomBook.count) {
            cell.dictionaryBook3 = [self.MACustomBook objectAtIndex:((indexPath.row * 5) + 2)];
            cell.IVBook3.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:((indexPath.row * 5) + 2)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase3.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook3 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook3 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle3.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
        if (((indexPath.row * 5) + 3) < self.MACustomBook.count) {
            cell.dictionaryBook4 = [self.MACustomBook objectAtIndex:((indexPath.row * 5) + 3)];
            cell.IVBook4.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:((indexPath.row * 5) + 3)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase4.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook4 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook4 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle4.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
        if (((indexPath.row * 5) + 4) < self.MACustomBook.count) {
            cell.dictionaryBook5 = [self.MACustomBook objectAtIndex:((indexPath.row * 5) + 4)];
            cell.IVBook5.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:((indexPath.row * 5) + 4)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase5.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook5 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook5 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle5.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
    }
    else {
        if ((indexPath.row * 3) < self.MACustomBook.count) {
            cell.dictionaryBook1 = [self.MACustomBook objectAtIndex:(indexPath.row * 3)];
            cell.IVBook1.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:(indexPath.row * 3)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase1.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook1 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook1 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle1.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
        if (((indexPath.row * 3) + 1) < self.MACustomBook.count) {
            cell.dictionaryBook2 = [self.MACustomBook objectAtIndex:((indexPath.row * 3) + 1)];
            cell.IVBook2.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:((indexPath.row * 3) + 1)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase2.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook2 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook2 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle2.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
        if (((indexPath.row * 3) + 2) < self.MACustomBook.count) {
            cell.dictionaryBook3 = [self.MACustomBook objectAtIndex:((indexPath.row * 3) + 2)];
            cell.IVBook3.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MACustomBook objectAtIndex:((indexPath.row * 3) + 2)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            cell.viewTitleBase3.hidden = NO;
            
            int iBookID = [[cell.dictionaryBook3 objectForKey:@"bookID"] intValue];
            NSString *stringCustomStoryFolderPath = [cell.dictionaryBook3 objectForKey:@"customStoryFolderPath"];
            cell.labelCustomTitle3.text = [self loadTextFromCustomStoryFolderIfExistIfNotLoadFromDictionaryStoryText:[NSString stringWithFormat:@"story%d_c_%@", iBookID, [CoreData sharedCoreData].stringLanguage] CustomStoryFolderPath:stringCustomStoryFolderPath bookID:iBookID];
        }
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark - Handle Click Button Events

- (IBAction)clickBluetoothButton:(UIButton *)button
{
    DEBUGMSG(@"iOS version: %f", [CoreData sharedCoreData].fOSVersion);
    if ([CoreData sharedCoreData].fOSVersion < 6.1) {
        UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_bluetooth_function_available") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil, nil];
        [AV show];
        [AV release];
        return;
    }
    
    self.viewBluetoothShareBase.hidden = NO;
    self.CM = [[[CBCentralManager alloc] initWithDelegate:self queue:nil] autorelease];
    [self.buttonBluetoothShareDone setTitle:@"确定" forState:UIControlStateNormal];
    [self.buttonBluetoothShareDone setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [self.buttonBluetoothShareDone setImage:[UIImage imageNamed:@"cm_ok_1.png"] forState:UIControlStateNormal];
}

- (IBAction)clickBluetoothShareDoneButton:(UIButton *)button
{
    [self cleanup];
    [self.CM stopScan];
    self.CM.delegate = nil;
    self.CM = nil;
    self.viewBluetoothShareBase.hidden = YES;
}

#pragma mark - CBCentralManagerDelegate

/** centralManagerDidUpdateState is a required protocol method.
 *  Usually, you'd check for other states to make sure the current device supports LE, is powered on, etc.
 *  In this instance, we're just using it to wait for CBCentralManagerStatePoweredOn, which indicates
 *  the Central is ready to be used.
 */

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state != CBCentralManagerStatePoweredOn) {
        // In a real app, you'd deal with all the states correctly
        return;
    }
    
    // The state must be CBCentralManagerStatePoweredOn...
    
    // ... so start scanning
    [self scan];
    
}


/** Scan for peripherals - specifically for our service's 128bit CBUUID
 */
- (void)scan
{
    self.labelBluetoothShareValue.text = LocalizedString(@"bluetooth_scanning_peripheral");
    [self.CM scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:TRANSFER_SERVICE_UUID]]
                                                options:@{CBCentralManagerScanOptionAllowDuplicatesKey:@YES}];
    DEBUGMSG(@"Scanning started");
}

/** This callback comes whenever a peripheral that is advertising the TRANSFER_SERVICE_UUID is discovered.
 *  We check the RSSI, to make sure it's close enough that we're interested in it, and if it is,
 *  we start the connection process
 */

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    
//    // Reject any where the value is above reasonable range
//    if (RSSI.integerValue > -15) {
//        return;
//    }
//    
//    // Reject if the signal strength is too low to be close enough (Close is around -22dB)
//    if (RSSI.integerValue < -35) {
//        return;
//    }
    
    DEBUGMSG(@"Discovered %@ at %@", peripheral.name, RSSI);
    
    // Ok, it's in range - have we already seen it?
    if (self.peripheralDiscovered != peripheral) {
        
        // Save a local copy of the peripheral, so CoreBluetooth doesn't get rid of it
        self.peripheralDiscovered = peripheral;
        
        // And connect
        DEBUGMSG(@"Connecting to peripheral %@", peripheral);
        [self.CM connectPeripheral:peripheral options:nil];
    }
}

/** If the connection fails for whatever reason, we need to deal with it.
 */
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    DEBUGMSG(@"Failed to connect to %@. (%@)", peripheral, [error localizedDescription]);
    [self cleanup];
}

/** We've connected to the peripheral, now we need to discover the services and characteristics to find the 'transfer' characteristic.
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    DEBUGMSG(@"Peripheral Connected");
    
    // Stop scanning
    [self.CM stopScan];
    DEBUGMSG(@"Scanning stopped");
    
    // Clear the data that we may already have
    [self.MData setLength:0];
    
    // Make sure we get the discovery callbacks
    peripheral.delegate = self;
    
    // Search only for services that match our UUID
    [peripheral discoverServices:@[[CBUUID UUIDWithString:TRANSFER_SERVICE_UUID]]];
}

/** Once the disconnection happens, we need to clean up our local copy of the peripheral
 */
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    DEBUGMSG(@"Peripheral Disconnected");
    self.peripheralDiscovered = nil;
    // We're disconnected, so start scanning again
    [self scan];
}


#pragma mark - CBPeripheralDelegate

/** The Transfer Service was discovered
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    if (error) {
        NSLog(@"Error discovering services: %@", [error localizedDescription]);
        [self cleanup];
        return;
    }
    
    // Discover the characteristic we want...
    
    // Loop through the newly filled peripheral.services array, just in case there's more than one.
    for (CBService *service in peripheral.services) {
        [peripheral discoverCharacteristics:@[[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]] forService:service];
    }
}


/** The Transfer characteristic was discovered.
 *  Once this has been found, we want to subscribe to it, which lets the peripheral know we want the data it contains
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    // Deal with errors (if any)
    if (error) {
        NSLog(@"Error discovering characteristics: %@", [error localizedDescription]);
        [self cleanup];
        return;
    }
    
    // Again, we loop through the array, just in case.
    for (CBCharacteristic *characteristic in service.characteristics) {
        
        // And check if it's the right one
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]]) {
            
            // If it is, subscribe to it
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
    }
    
    // Once this is complete, we just need to wait for the data to come in.
}


/** This callback lets us know more data has arrived via notification on the characteristic
 */
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        NSLog(@"Error discovering characteristics: %@", [error localizedDescription]);
        return;
    }
    
    NSString *stringFromData = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    
    // Have we got everything we need?
    if ([stringFromData isEqualToString:@"EOM"]) {
        
        // We have, so show the data,
        
        DEBUGMSG(@"Received: %@", stringFromData);
        BOOL bSuccessfulWriteToFile = [self.MData writeToFile:[NSString stringWithFormat:@"%@/temp.zip", PathCustomFolder] atomically:YES];
        if (bSuccessfulWriteToFile) {
            DEBUGMSG(@"bSuccessfulWriteToFile");
            self.labelBluetoothShareValue.text = LocalizedString(@"bt_saving_custom_story");
            
            NSDateFormatter *DF = [[NSDateFormatter alloc] init];
            [DF setDateFormat:@"yyyyMMddHHmmss"];
            NSString *stringUnzipDestinationFilePath = [NSString stringWithFormat:@"%@/%@-%@", PathCustomFolder, [CoreData sharedCoreData].stringDeviceID, [DF stringFromDate:[NSDate date]]];
            DEBUGMSG(@"stringUnzipDestinationFilePath: %@", stringUnzipDestinationFilePath);
            [SSZipArchive unzipFileAtPath:[NSString stringWithFormat:@"%@/temp.zip", PathCustomFolder] toDestination:stringUnzipDestinationFilePath delegate:self];
        }
        else {
            DEBUGMSG(@"!bSuccessfulWriteToFile");
        }
        
        // Cancel our subscription to the characteristic
        [peripheral setNotifyValue:NO forCharacteristic:characteristic];
        
        // and disconnect from the peripehral
        [self.CM cancelPeripheralConnection:peripheral];
        
        [self cleanup];
        [self.CM stopScan];
        self.CM.delegate = nil;
        self.CM = nil;
        [stringFromData release];
        return;
    }
    
    // Otherwise, just add the data on to what we already have
    [self.MData appendData:characteristic.value];
    
    // Log it
    DEBUGMSG(@"Received: %@", stringFromData);
    DEBUGMSG(@"self.MData.length: %d", self.MData.length);
    
    NSString *stringHeartbeat = @"";
    for (int x = 0; x < self.iSavingDataHeartbeat; x++) {
        stringHeartbeat = [stringHeartbeat stringByAppendingString:@"."];
    }
    
    self.labelBluetoothShareValue.text = [NSString stringWithFormat:@"%@%@", LocalizedString(@"bt_receiving_data"), stringHeartbeat];
#ifdef DEBUG
    self.labelBluetoothShareValue.text = [NSString stringWithFormat:@"%@\n%d", self.labelBluetoothShareValue.text, self.MData.length];
#endif
    self.iSavingDataHeartbeat++;
    if (self.iSavingDataHeartbeat > 10) {
        self.iSavingDataHeartbeat = 0;
    }
    [stringFromData release];
}


/** The peripheral letting us know whether our subscribe/unsubscribe happened or not
 */
- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        DEBUGMSG(@"Error changing notification state: %@", error.localizedDescription);
    }
    
    // Exit if it's not the transfer characteristic
    if (![characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]]) {
        return;
    }
    
    // Notification has started
    if (characteristic.isNotifying) {
        DEBUGMSG(@"Notification began on %@", characteristic);
    }
    
    // Notification has stopped
    else {
        // so disconnect from the peripheral
        DEBUGMSG(@"Notification stopped on %@.  Disconnecting", characteristic);
        [self.CM cancelPeripheralConnection:peripheral];
    }
}

/** Call this when things either go wrong, or you're done with the connection.
 *  This cancels any subscriptions if there are any, or straight disconnects if not.
 *  (didUpdateNotificationStateForCharacteristic will cancel the connection if a subscription is involved)
 */
- (void)cleanup
{
    // Don't do anything if we're not connected
    if (!self.peripheralDiscovered.isConnected) {
        return;
    }
    
    // See if we are subscribed to a characteristic on the peripheral
    if (self.peripheralDiscovered.services != nil) {
        for (CBService *service in self.peripheralDiscovered.services) {
            if (service.characteristics != nil) {
                for (CBCharacteristic *characteristic in service.characteristics) {
                    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID]]) {
                        if (characteristic.isNotifying) {
                            // It is notifying, so unsubscribe
                            [self.peripheralDiscovered setNotifyValue:NO forCharacteristic:characteristic];
                            
                            // And we're done.
                            return;
                        }
                    }
                }
            }
        }
    }
    
    // If we've got this far, we're connected, but we're not subscribed, so we just disconnect
    [self.CM cancelPeripheralConnection:self.peripheralDiscovered];
}

#pragma mark - SSZipArchiveDelegate

- (void)zipArchiveDidUnzipArchiveAtPath:(NSString *)path zipInfo:(unz_global_info)zipInfo unzippedPath:(NSString *)unzippedPath
{
    DEBUGMSG(@"path: %@\nunzippedPath: %@", path, unzippedPath);
    
    self.labelBluetoothShareValue.text = LocalizedString(@"bt_saved");
    self.MACustomBook = [[NSMutableArray new] autorelease];
    self.MData = [[NSMutableData new] autorelease];
    self.iSavingDataHeartbeat = 1;
    [self setup];
    [self setupView];
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [rightBtn release];
    rightBtn = nil;
    [topLogo release];
    topLogo = nil;
    [super viewDidUnload];
}
@end
