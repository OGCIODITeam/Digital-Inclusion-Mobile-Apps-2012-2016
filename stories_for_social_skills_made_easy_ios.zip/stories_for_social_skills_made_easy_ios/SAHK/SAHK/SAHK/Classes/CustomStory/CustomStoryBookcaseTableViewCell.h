//
//  CustomStoryBookcaseTableViewCell.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomStoryBookcaseTableViewCell : UITableViewCell{

    IBOutlet UIButton *btn1;

    IBOutlet UIButton *btn2;
    
    IBOutlet UIButton *btn3;
    
    IBOutlet UIButton *btn4;
    
    IBOutlet UIButton *btn5;
    
    
    
    
    
}

@property (nonatomic, retain) IBOutlet UIImageView *IVBook1, *IVBook2, *IVBook3, *IVBook4, *IVBook5;
@property (nonatomic, retain) NSDictionary *dictionaryBook1, *dictionaryBook2, *dictionaryBook3, *dictionaryBook4, *dictionaryBook5;
@property (nonatomic, retain) IBOutlet UIView *viewTitleBase1, *viewTitleBase2, *viewTitleBase3, *viewTitleBase4, *viewTitleBase5;
@property (nonatomic, retain) IBOutlet UILabel *labelCustomTitle1, *labelCustomTitle2, *labelCustomTitle3, *labelCustomTitle4, *labelCustomTitle5;

#pragma mark - Core

- (void)reset;

@end
