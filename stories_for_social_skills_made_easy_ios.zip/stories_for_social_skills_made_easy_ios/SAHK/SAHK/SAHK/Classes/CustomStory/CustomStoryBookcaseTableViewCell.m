//
//  CustomStoryBookcaseTableViewCell.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "CustomStoryBookcaseTableViewCell.h"
#import "CustomBookContentViewController.h"

@interface CustomStoryBookcaseTableViewCell ()


#pragma mark - Handle Click Button Events

- (IBAction)clickBook1Button:(UIButton *)button;
- (IBAction)clickBook2Button:(UIButton *)button;
- (IBAction)clickBook3Button:(UIButton *)button;
- (IBAction)clickBook4Button:(UIButton *)button;
- (IBAction)clickBook5Button:(UIButton *)button;

@end

@implementation CustomStoryBookcaseTableViewCell

@synthesize IVBook1 = _IVBook1, IVBook2 = _IVBook2, IVBook3 = _IVBook3, IVBook4 = _IVBook4, IVBook5 = _IVBook5;
@synthesize dictionaryBook1 = _dictionaryBook1, dictionaryBook2 = _dictionaryBook2, dictionaryBook3 = _dictionaryBook3, dictionaryBook4 = _dictionaryBook4, dictionaryBook5 = _dictionaryBook5;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
- (void)dealloc
{
    self.IVBook1.image = nil;
    self.IVBook1 = nil;
    
    self.IVBook2.image = nil;
    self.IVBook2 = nil;
    
    self.IVBook3.image = nil;
    self.IVBook3 = nil;
    
    self.IVBook4.image = nil;
    self.IVBook4 = nil;
    
    self.IVBook5.image = nil;
    self.IVBook5 = nil;
    
    self.dictionaryBook1 = nil;
    self.dictionaryBook2 = nil;
    self.dictionaryBook3 = nil;
    self.dictionaryBook4 = nil;
    self.dictionaryBook5 = nil;
    [btn1 release];
    [btn2 release];
    [btn3 release];
    [btn4 release];
    [btn5 release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
    
    [btn1 setTitle:self.labelCustomTitle1.text forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    [btn2 setTitle:self.labelCustomTitle2.text forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [btn3 setTitle:self.labelCustomTitle3.text forState:UIControlStateNormal];
    [btn3 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [btn4 setTitle:self.labelCustomTitle4.text forState:UIControlStateNormal];
    [btn4 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [btn5 setTitle:self.labelCustomTitle5.text forState:UIControlStateNormal];
    [btn5 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

}

#pragma mark - Core

- (void)reset
{
    self.dictionaryBook1 = nil;
    self.dictionaryBook2 = nil;
    self.dictionaryBook3 = nil;
    self.dictionaryBook4 = nil;
    self.dictionaryBook5 = nil;
    self.IVBook1.image = nil;
    self.IVBook2.image = nil;
    self.IVBook3.image = nil;
    self.IVBook4.image = nil;
    self.IVBook5.image = nil;
    
    self.viewTitleBase1.hidden = YES;
    self.viewTitleBase2.hidden = YES;
    self.viewTitleBase3.hidden = YES;
    self.viewTitleBase4.hidden = YES;
    self.viewTitleBase5.hidden = YES;
}

#pragma mark - Handle Click Button Events

- (IBAction)clickBook1Button:(UIButton *)button
{
    if (self.dictionaryBook1) {
        CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];    [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
        VCCustomBookContent.dictionaryBook = self.dictionaryBook1;
        [VCCustomBookContent release];
    }
}

- (IBAction)clickBook2Button:(UIButton *)button
{
    if (self.dictionaryBook2) {
        CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];    [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
        VCCustomBookContent.dictionaryBook = self.dictionaryBook2;
        [VCCustomBookContent release];
    }
}

- (IBAction)clickBook3Button:(UIButton *)button
{
    if (self.dictionaryBook3) {
        CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];    [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
        VCCustomBookContent.dictionaryBook = self.dictionaryBook3;
        [VCCustomBookContent release];
    }
}

- (IBAction)clickBook4Button:(UIButton *)button
{
    if (self.dictionaryBook4) {
        CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];    [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
        VCCustomBookContent.dictionaryBook = self.dictionaryBook4;
        [VCCustomBookContent release];
    }
}

- (IBAction)clickBook5Button:(UIButton *)button
{
    if (self.dictionaryBook5) {
        CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];    [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
        VCCustomBookContent.dictionaryBook = self.dictionaryBook5;
        [VCCustomBookContent release];
    }
}

@end
