//
//  CustomStoryViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月18日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface CustomStoryViewController : UIViewController{

    IBOutlet UIImageView *topNav;
    IBOutlet LeftMenuButton *leftBtn;
    IBOutlet UIButton *rightBtn;
    IBOutlet UIImageView *topLogo;


}

@end
