//
//  RLSBookcaseTableViewCell.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "RLSBookcaseTableViewCell.h"

@interface RLSBookcaseTableViewCell ()

@property (nonatomic, retain) IBOutlet UIImageView *IVBook;
@property (nonatomic, retain) IBOutlet UIImageView *IVAdd;

@end

@implementation RLSBookcaseTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    self.IVBook.transform = CGAffineTransformIdentity;
    self.IVBook.transform = CGAffineTransformMakeRotation(M_PI_2);
    
    self.IVAdd.transform = CGAffineTransformIdentity;
    self.IVAdd.transform = CGAffineTransformMakeRotation(M_PI_2);
    
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        self.IVBook.frame = CGRectMake(15.0, 20.0, 136.0, 100.0);
        self.IVAdd.center = CGPointMake(15.0 + 136.0 - 2.0, 20.0 + 100.0);
        self.clearLbl.frame=CGRectMake(15.0, 20.0, 136.0, 100.0);
    }
    else {
        self.IVBook.frame = CGRectMake(10.0, 10.0, 101.0, 72.0);
        self.IVAdd.center = CGPointMake(10 + 101.0 - 2.0, 10.0 + 72.0);
        self.clearLbl.frame=CGRectMake(10.0, 10.0, 101.0, 72.0);

    }
    
    
//    self.clearImgLbl.text=@"增加";
}

- (void)dealloc
{
    self.IVBook.image = nil;
    self.IVBook = nil;
    
    self.IVAdd.image = nil;
    self.IVAdd = nil;
    [_clearLbl release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

#pragma mark - Core

- (void)setupView:(UIImage *)imageBook imageAdd:(UIImage *)imageAdd
{
    self.IVBook.image = imageBook;
    self.IVAdd.image = imageAdd;
}

@end
