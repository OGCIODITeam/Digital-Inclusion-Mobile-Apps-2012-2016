//
//  StudentProfileViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月23日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"
@interface StudentProfileViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet LeftMenuButton *leftBtn;

    IBOutlet UIButton *right1Btn;
    
    IBOutlet UIButton *right2Btn;
    
    IBOutlet UIView *newAdd;
    
    IBOutlet UIButton *newAddListBtn;
    
    
    
    
}

#pragma mark - Core

- (void)shareReadingList:(NSArray *)arrayReadingList;
- (void)deleteReadingList:(int)iSelectedReadingListListIndex;

@end
