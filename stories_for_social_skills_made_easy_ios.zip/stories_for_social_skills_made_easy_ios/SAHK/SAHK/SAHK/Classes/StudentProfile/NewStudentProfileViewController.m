//
//  NewStudentProfileViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月24日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "NewStudentProfileViewController.h"

@interface NewStudentProfileViewController () <UITextFieldDelegate>

@property (nonatomic, retain) IBOutlet UIView *viewStudentProfileBase;
@property (nonatomic, retain) IBOutlet UITextField *TFLastNameValue, *TFFirstNameValue, *TFSchoolValue, *TFClassValue, *TFParentValue, *TFParentEmailValue, *TFTeacherValue, *TFTeacherEmailValue;

@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;
@property (nonatomic, retain) IBOutlet UILabel *labelMustInput, *labelF1, *labelF2, *labelF3, *labelF4, *labelF5, *labelF6, *labelF7, *labelF8;

@property (nonatomic, retain) IBOutlet UIView *viewDeleteBase;

#pragma mark - Core

- (void)setup;
- (void)setupView;
- (BOOL)doChecking;
- (BOOL)isValidateEmail:(NSString *)stringInput;

#pragma mark - Handle Click Button Events

- (IBAction)clickSaveButton:(UIButton *)button;

@end

@implementation NewStudentProfileViewController

@synthesize bNewStudentProfile = _bNewStudentProfile;
@synthesize MDCurrentStudentProfile = _MDCurrentStudentProfile;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.bNewStudentProfile = NO;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        rightBtn.frame=CGRectMake(rightBtn.frame.origin.x, rightBtn.frame.origin.y+20, rightBtn.frame.size.width, rightBtn.frame.size.height);

        self.viewStudentProfileBase.frame=CGRectMake( self.viewStudentProfileBase.frame.origin.x,  self.viewStudentProfileBase.frame.origin.y+20,  self.viewStudentProfileBase.frame.size.width,  self.viewStudentProfileBase.frame.size.height-20);
        
            }

    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    [rightBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [rightBtn setImage:[UIImage imageNamed:@"story100_save_1.png"] forState:UIControlStateNormal];

    
    [deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [deleteBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [deleteBtn setImage:[UIImage imageNamed:@"sp_remove_3.png"] forState:UIControlStateNormal];


    
    
    [self setup];
    [self setupView];
}

- (void)dealloc
{
    self.viewStudentProfileBase = nil;
    
    self.TFLastNameValue.delegate = nil;
    self.TFLastNameValue = nil;
    
    self.TFFirstNameValue.delegate = nil;
    self.TFFirstNameValue = nil;
    
    self.TFSchoolValue.delegate = nil;
    self.TFSchoolValue = nil;
    
    self.TFClassValue.delegate = nil;
    self.TFClassValue = nil;
    
    self.TFParentValue.delegate = nil;
    self.TFParentValue = nil;
    
    self.TFParentEmailValue.delegate = nil;
    self.TFParentEmailValue = nil;
    
    self.TFTeacherValue.delegate = nil;
    self.TFTeacherValue = nil;
    
    self.TFTeacherEmailValue.delegate = nil;
    self.TFTeacherEmailValue = nil;
    
    self.MDCurrentStudentProfile = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    
    self.labelMustInput = nil;
    self.labelF1 = nil;
    self.labelF2 = nil;
    self.labelF3 = nil;
    self.labelF4 = nil;
    self.labelF5 = nil;
    self.labelF6 = nil;
    self.labelF7 = nil;
    self.labelF8 = nil;
    
    self.viewDeleteBase = nil;
    
    [topNav release];
    [leftBtn release];
    [rightBtn release];
    [deleteBtn release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    
}

- (void)setupView
{
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"sp_profile"];
    self.labelMustInput.text = LocalizedString(@"sp_new_student_must_input");
    self.labelF1.text = LocalizedString(@"sp_new_student_f1");
    self.labelF2.text = LocalizedString(@"sp_new_student_f2");
    self.labelF3.text = LocalizedString(@"sp_new_student_f3");
    self.labelF4.text = LocalizedString(@"sp_new_student_f4");
    self.labelF5.text = LocalizedString(@"sp_new_student_f5");
    self.labelF6.text = LocalizedString(@"sp_new_student_f6");
    self.labelF7.text = LocalizedString(@"sp_new_student_f7");
    self.labelF8.text = LocalizedString(@"sp_new_student_f8");
    //sp_new_student_must_input_t
    //sp_new_student_f1_t
    if (!self.bNewStudentProfile) {
        self.TFLastNameValue.text = [self.MDCurrentStudentProfile objectForKey:@"lastName"];
        self.TFFirstNameValue.text = [self.MDCurrentStudentProfile objectForKey:@"firstName"];
        self.TFSchoolValue.text = [self.MDCurrentStudentProfile objectForKey:@"school"];
        self.TFClassValue.text = [self.MDCurrentStudentProfile objectForKey:@"class"];
        self.TFParentValue.text = [self.MDCurrentStudentProfile objectForKey:@"parent"];
        self.TFParentEmailValue.text = [self.MDCurrentStudentProfile objectForKey:@"parentEmail"];
        self.TFTeacherValue.text = [self.MDCurrentStudentProfile objectForKey:@"teacher"];
        self.TFTeacherEmailValue.text = [self.MDCurrentStudentProfile objectForKey:@"teacherEmail"];
        self.viewDeleteBase.hidden = NO;
    }
    else {
        self.viewDeleteBase.hidden = YES;
    }
}

- (BOOL)doChecking
{
    BOOL bCheckingResult = YES;
    if (self.TFLastNameValue.text && [self.TFLastNameValue.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
        bCheckingResult = NO;
    }
    if (self.TFFirstNameValue.text && [self.TFFirstNameValue.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
        bCheckingResult = NO;
    }
    if (self.TFParentValue.text && [self.TFParentValue.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
        bCheckingResult = NO;
    }
    if (self.TFParentEmailValue.text && [self.TFParentEmailValue.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
        bCheckingResult = NO;
    }
    if (self.TFTeacherValue.text && [self.TFTeacherValue.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
        bCheckingResult = NO;
    }
    if (self.TFTeacherEmailValue.text && [self.TFTeacherEmailValue.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
        bCheckingResult = NO;
    }
    
    if (!bCheckingResult) {
        UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"sp_fill_info") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
        [AV show];
        [AV release];
        return bCheckingResult;
    }
    
    if (![self isValidateEmail:self.TFParentEmailValue.text]) {
        bCheckingResult = NO;
        UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_parent_email_format_wrong") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
        [AV show];
        [AV release];
        return bCheckingResult;
    }
    
    if (![self isValidateEmail:self.TFTeacherEmailValue.text]) {
        bCheckingResult = NO;
        UIAlertView *AV = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_teacher_email_format_wrong") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
        [AV show];
        [AV release];
        return bCheckingResult;
    }
    
    return bCheckingResult;
}

- (BOOL)isValidateEmail:(NSString *)stringInput
{
    NSString *stringEmailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *predicateEmail = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", stringEmailRegex];
    return [predicateEmail evaluateWithObject:stringInput];
}

#pragma mark - Handle Click Button Events

- (IBAction)clickSaveButton:(UIButton *)button
{
    if (![self doChecking]) {
        return;
    }
    
    if (self.bNewStudentProfile) {
        NSMutableDictionary *MDStudentProfile = [NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile];
        
        if (MDStudentProfile) {
            MDStudentProfile = [MDStudentProfile mutableCopy];
        }
        else {
            MDStudentProfile = [NSMutableDictionary new];
            [MDStudentProfile setObject:@"0" forKey:@"nextStudentProfileID"];
        }
        
        NSDictionary *dictionaryStudentProfile = [NSDictionary dictionaryWithObjectsAndKeys:self.TFLastNameValue.text, @"lastName", self.TFFirstNameValue.text, @"firstName", self.TFSchoolValue.text, @"school", self.TFClassValue.text, @"class", self.TFParentValue.text, @"parent", self.TFParentEmailValue.text, @"parentEmail", self.TFTeacherValue.text, @"teacher", self.TFTeacherEmailValue.text, @"teacherEmail", [MDStudentProfile objectForKey:@"nextStudentProfileID"], @"studentProfileID", nil];
        
        NSMutableArray *MAStudentProfileList;
        NSArray *arrayStudentProfileList = [MDStudentProfile objectForKey:@"studentProfileList"];
        (arrayStudentProfileList)?(MAStudentProfileList = [arrayStudentProfileList mutableCopy]):(MAStudentProfileList = [NSMutableArray new]);
        
        [MAStudentProfileList addObject:dictionaryStudentProfile];
        
        [MDStudentProfile setObject:MAStudentProfileList forKey:@"studentProfileList"];
        [MAStudentProfileList release];
        
        [MDStudentProfile setObject:[NSString stringWithFormat:@"%d", ([[MDStudentProfile objectForKey:@"nextStudentProfileID"] intValue] + 1)] forKey:@"nextStudentProfileID"];
        
        [MDStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
        
        [MDStudentProfile release];
    }
    else {
        NSMutableDictionary *MDStudentProfile = [[NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile] mutableCopy];
        NSMutableArray *MAStudentProfileList = [MDStudentProfile objectForKey:@"studentProfileList"];
        NSDictionary *dictionaryStudentProfile;
        
        if ([self.MDCurrentStudentProfile objectForKey:@"readingListList"] && ((NSArray *)[self.MDCurrentStudentProfile objectForKey:@"readingListList"]).count > 0) {
            dictionaryStudentProfile = [NSDictionary dictionaryWithObjectsAndKeys:self.TFLastNameValue.text, @"lastName", self.TFFirstNameValue.text, @"firstName", self.TFSchoolValue.text, @"school", self.TFClassValue.text, @"class", self.TFParentValue.text, @"parent", self.TFParentEmailValue.text, @"parentEmail", self.TFTeacherValue.text, @"teacher", self.TFTeacherEmailValue.text, @"teacherEmail", [self.MDCurrentStudentProfile objectForKey:@"studentProfileID"], @"studentProfileID", [self.MDCurrentStudentProfile objectForKey:@"readingListList"], @"readingListList", nil];
        }
        else {
            dictionaryStudentProfile = [NSDictionary dictionaryWithObjectsAndKeys:self.TFLastNameValue.text, @"lastName", self.TFFirstNameValue.text, @"firstName", self.TFSchoolValue.text, @"school", self.TFClassValue.text, @"class", self.TFParentValue.text, @"parent", self.TFParentEmailValue.text, @"parentEmail", self.TFTeacherValue.text, @"teacher", self.TFTeacherEmailValue.text, @"teacherEmail", [self.MDCurrentStudentProfile objectForKey:@"studentProfileID"], @"studentProfileID", nil];   
        }
        
        for (int x = 0; MAStudentProfileList && x < MAStudentProfileList.count; x++) {
            if ([[[MAStudentProfileList objectAtIndex:x] objectForKey:@"studentProfileID"] isEqualToString:[self.MDCurrentStudentProfile objectForKey:@"studentProfileID"]]) {
                [MAStudentProfileList replaceObjectAtIndex:x withObject:dictionaryStudentProfile];
                break;
            }
        }
        [MDStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
        [MDStudentProfile release];
    }
    
    
    [[CoreData sharedCoreData].JNC popViewControllerAnimated:NO];
}

- (IBAction)clickDeleteButton:(UIButton *)button
{
    NSMutableDictionary *mutableDictionaryStudentProfile = [[NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile] mutableCopy];
    NSMutableArray *mutableArrayStudentProfileList = [mutableDictionaryStudentProfile objectForKey:@"studentProfileList"];
    [mutableArrayStudentProfileList removeObjectAtIndex:self.iIndexForStudentProfileList];
    [mutableDictionaryStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
    [mutableDictionaryStudentProfile release];
    
    
//    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"sp_student_profile_delete") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
//    [alertView show];
//    [alertView release];
    
    [[CoreData sharedCoreData].JNC popViewControllerAnimated:NO];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (![[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        if (IOS7_OR_LATER){
        
        if (textField == self.TFParentValue || textField == self.TFParentEmailValue || textField == self.TFTeacherValue || textField == self.TFTeacherEmailValue) {
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                self.viewStudentProfileBase.frame = CGRectMake(self.viewStudentProfileBase.frame.origin.x, -150.0, self.viewStudentProfileBase.frame.size.width, self.viewStudentProfileBase.frame.size.height);
            } completion:^(BOOL finished) {
                
            }];
        }
        else {
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                self.viewStudentProfileBase.frame = CGRectMake(self.viewStudentProfileBase.frame.origin.x,10, self.viewStudentProfileBase.frame.size.width, self.viewStudentProfileBase.frame.size.height);
            } completion:^(BOOL finished) {
                
            }];
        }
        
        }else{
        
        
        if (textField == self.TFParentValue || textField == self.TFParentEmailValue || textField == self.TFTeacherValue || textField == self.TFTeacherEmailValue) {
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                self.viewStudentProfileBase.frame = CGRectMake(self.viewStudentProfileBase.frame.origin.x, -172.0, self.viewStudentProfileBase.frame.size.width, self.viewStudentProfileBase.frame.size.height);
            } completion:^(BOOL finished) {
                
            }];
        }
        else {
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                self.viewStudentProfileBase.frame = CGRectMake(self.viewStudentProfileBase.frame.origin.x, -12.0, self.viewStudentProfileBase.frame.size.width, self.viewStudentProfileBase.frame.size.height);
            } completion:^(BOOL finished) {
                
            }];
        }
    }
}
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (![[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        if (self.viewStudentProfileBase.frame.origin.y < 0) {
            [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                self.viewStudentProfileBase.frame = CGRectMake(self.viewStudentProfileBase.frame.origin.x, 50.0, self.viewStudentProfileBase.frame.size.width, self.viewStudentProfileBase.frame.size.height);
            } completion:^(BOOL finished) {
                
            }];
        }
    }
    [textField resignFirstResponder];
    return YES;
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [rightBtn release];
    rightBtn = nil;
    [deleteBtn release];
    deleteBtn = nil;
    [super viewDidUnload];
}
@end
