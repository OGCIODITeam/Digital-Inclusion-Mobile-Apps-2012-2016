//
//  ReadingListSelectionViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月13日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"
@interface ReadingListSelectionViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet LeftMenuButton *leftBtn;

    IBOutlet UIImageView *grayBg;
    IBOutlet UIButton *confirmBtn;
    
}

@property (nonatomic, retain) NSMutableDictionary *MDCurrentStudentProfile;
@property (nonatomic, assign) int iSelectedReadingListListIndex;
@property (nonatomic, retain) NSMutableArray *MAReadingList;

@end
