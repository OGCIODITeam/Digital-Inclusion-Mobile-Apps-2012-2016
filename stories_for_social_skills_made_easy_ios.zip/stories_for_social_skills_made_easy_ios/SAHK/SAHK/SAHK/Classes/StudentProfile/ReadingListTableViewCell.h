//
//  ReadingListTableViewCell.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StudentProfileViewController.h"

@interface ReadingListTableViewCell : UITableViewCell{

    IBOutlet UIButton *shareBtn;

    IBOutlet UIButton *deleteBtn;
}

@property (nonatomic, retain) IBOutlet UILabel *labelReadingListValue;
@property (nonatomic, assign) StudentProfileViewController *VCStudentProfile;
@property (nonatomic, retain) NSArray *arrayReadingList;
@property (nonatomic, assign) int iSelectedReadingListListIndex;

#pragma mark - Core

- (void)reset;

@end
