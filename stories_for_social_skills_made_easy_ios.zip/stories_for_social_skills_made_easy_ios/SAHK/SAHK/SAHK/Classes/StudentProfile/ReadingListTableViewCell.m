//
//  ReadingListTableViewCell.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "ReadingListTableViewCell.h"

@interface ReadingListTableViewCell ()

#pragma mark - Handle Click Button Events

- (IBAction)clickShareButton:(UIButton *)button;

@end

@implementation ReadingListTableViewCell

@synthesize labelReadingListValue = _labelReadingListValue;
@synthesize VCStudentProfile = _VCStudentProfile;
@synthesize arrayReadingList = _arrayReadingList;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
- (void)dealloc
{
    self.labelReadingListValue = nil;
    self.arrayReadingList = nil;
    [shareBtn release];
    [deleteBtn release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
    
    [shareBtn setTitle:@"分享" forState:UIControlStateNormal];
    [shareBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [shareBtn setImage:[UIImage imageNamed:@" sp_share_2.png"] forState:UIControlStateNormal];
    [deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [deleteBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [deleteBtn setImage:[UIImage imageNamed:@" sp_remove_2.png"] forState:UIControlStateNormal];


}

#pragma mark - Core

- (void)reset
{
    self.labelReadingListValue.text = @"";
}

#pragma mark - Handle Click Button Events

- (IBAction)clickShareButton:(UIButton *)button
{
    [self.VCStudentProfile shareReadingList:self.arrayReadingList];
}

- (IBAction)clickDeleteButton:(UIButton *)button
{
    [self.VCStudentProfile deleteReadingList:self.iSelectedReadingListListIndex];
}

@end
