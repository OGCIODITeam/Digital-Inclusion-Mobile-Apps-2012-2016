//
//  ReadingListSelectionViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月13日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "ReadingListSelectionViewController.h"
#import "RLSBookcaseViewController.h"

#define TitleWidth 38.0
#define TitleWidthiPad 68.0

@interface ReadingListSelectionViewController ()

@property (nonatomic, retain) IBOutlet UIScrollView *SVBookBase;
@property (nonatomic, retain) RLSBookcaseViewController *VCRLSBookcase1, *VCRLSBookcase2, *VCRLSBookcase3, *VCRLSBookcase4, *VCRLSBookcase5;

@property (nonatomic, retain) NSDictionary *dictionaryStoryFilename;

@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

@property (nonatomic, retain) IBOutlet UIImageView *IVCat1, *IVCat2, *IVCat3, *IVCat4, *IVCat5;

#pragma mark - Core

- (void)setup;
- (void)setupView;

#pragma mark - Handle Click Button Events

- (IBAction)clickConfirmButton:(UIButton *)button;

@end

@implementation ReadingListSelectionViewController

@synthesize MDCurrentStudentProfile = _MDCurrentStudentProfile;
@synthesize iSelectedReadingListListIndex = _iSelectedReadingListListIndex;
@synthesize MAReadingList = _MAReadingList;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.SVBookBase.delegate = nil;
    self.SVBookBase = nil;
    
    [self.VCRLSBookcase1.view removeFromSuperview];
    self.VCRLSBookcase1 = nil;

    [self.VCRLSBookcase2.view removeFromSuperview];
    self.VCRLSBookcase2 = nil;

    [self.VCRLSBookcase3.view removeFromSuperview];
    self.VCRLSBookcase3 = nil;

    [self.VCRLSBookcase4.view removeFromSuperview];
    self.VCRLSBookcase4 = nil;

    [self.VCRLSBookcase5.view removeFromSuperview];
    self.VCRLSBookcase5 = nil;
    
    self.dictionaryStoryFilename = nil;
    
    self.MDCurrentStudentProfile = nil;
    
    [self.MAReadingList removeAllObjects];
    self.MAReadingList = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    
    self.IVCat1.image = nil;
    self.IVCat1 = nil;
    self.IVCat2.image = nil;
    self.IVCat2 = nil;
    self.IVCat3.image = nil;
    self.IVCat3 = nil;
    self.IVCat4.image = nil;
    self.IVCat4 = nil;
    self.IVCat5.image = nil;
    self.IVCat5 = nil;
    [topNav release];
    [leftBtn release];
    [grayBg release];
    [confirmBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
              self.SVBookBase.frame=CGRectMake( self.SVBookBase.frame.origin.x,  self.SVBookBase.frame.origin.y+20,  self.SVBookBase.frame.size.width,  self.SVBookBase.frame.size.height-20);
        
        
        
        
        
        
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
    [confirmBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [confirmBtn setImage:[UIImage imageNamed:@"sp_long_ok_1_t.png"] forState:UIControlStateNormal];

    
    
    [self setup];
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    self.dictionaryStoryFilename = [NSDictionary dictionaryWithContentsOfFile:PlistFilename];
}

- (void)setupView
{
    
    NSArray*titleArray1_s=[NSArray arrayWithObjects:@"怎样打招呼？",@"什么时候握手？",@"什么时候说［谢谢］（1）？",@"什么时候说［谢谢］（2）？",@"什么时候说［对不起］？",@"我可以怎样拿到想要的东西？",@"怎样令人开心？",@"见到喜欢得小朋友，我可以怎样做？",@"怎样帮助别人？",@"小朋友还未把事情做好，我可以怎样做？",@"事情做错了，应该怎么办？",@"不开心时，我可以怎样做？",@"生气时，我可以怎样做？",@"怎样保持冷静？",@"想玩玩具时，我可以怎样做？",@"想玩别人得玩具时，我可以怎样做？",@"小朋友不想借玩具、借图书给我，我可以怎样做？",@"在我家里，朋友可以玩我的玩具吗？",@"怎样才能拿回自己得玩具？",@"怎样分享玩具？",@"什么时候轮到我玩玩具？",@"怎样学些玩游戏？",@"玩游戏时，我可以怎样做？",@"怎样接受比赛得胜负？",@"别人向我说话时，我可以做什么？",@"朋友正在谈话，我有话要说，我可以怎样做？",@"为什么要等别人把话说完，我才开始说话？",@"当我不知道别人说什么时，可以怎样做？",@"别人向我发问时，我可以怎样做？",@"为什么谈话要有不同得话题？",@"人人都有机会表达意见",@"保持适当得声量", nil];
    
    NSArray*titleArray1=[NSArray arrayWithObjects:@"怎样打招呼？",@"什麼時候握手？",@"什麼時候說多謝？",@"什麼時候說唔該？",@"什麼時候說對唔住？",@"我可以怎樣拿到想要的東西？",@"怎樣令人開心？",@"見到喜歡的小朋友，我可以怎樣做？",@"怎樣幫助別人？",@"小朋友還未把事情做好，我可以怎樣做？",@"事情做錯了，應該怎麼辦？",@"不開心時，我可以怎樣做？",@"生氣時，我可以怎樣做？",@"怎樣保持冷靜？",@"想玩玩具時，我可以怎樣做？",@"想玩別人的玩具時，我可以怎樣做？",@"小朋友不想借玩具、借圖書給我，我可以怎樣做？",@"在我家裡，朋友可以玩我的玩具嗎？",@"怎樣才能拿回自己的玩具？",@"怎樣分享玩具？",@"什麼時候輪到我玩玩具？",@"怎樣學習玩遊戲？",@"玩遊戲時，我可以怎樣做？",@"怎樣接受比賽的勝負？",@"別人向我說話時，我可以做什麼？",@"朋友正在談話，我有話要說，我可以怎樣做？",@"為甚麼要等別人把話說完，我才開始說話？",@"當我不知道別人說什麼時，可以怎樣做？",@"別人向我發問時，我可以怎樣做？",@"為甚麼談話要有不同的話題？",@"人人都有機會表達意見",@"保持適當的聲量", nil];
    
    
    NSArray*titleArray2=[NSArray arrayWithObjects:@"學校是什麼地方？",@"為甚麼我要上學？",@"我在學校裡，做些什麼事？",@"課間休息時候做些什麼事？",@"回到學校後，媽媽為甚麼便要走？",@"怎樣乘搭校車？",@"乘坐校車時，我可以怎樣做？",@"為甚麼我要午睡？",@"我在午睡時間可以怎樣做？",@"如果我不想午睡，我可以怎麼辦？",@"為甚麼會有代課老師？",@"什麼是假期？",@"為甚麼要留心上課？",@"上課時，小朋友想做其他事情，他可以怎樣做？",@"當我看到有趣的教材或玩具時，可以怎樣做？",@"老師說話時，為甚麼我要保持安靜？",@"老師在說話，我有話說，我可以怎樣做？",@"老師，你說了些什麼？",@"為甚麼要舉手輪流說話？",@"上課時怎樣問問題？",@"老師沒有叫我的名字我該怎麼辦？",@"老師請其他小朋友幫忙做事情，我可以怎樣做？",@"遇到問題我可以找誰幫忙？",@"排隊時要怎樣做？",@"每位小朋友都有機會排第一",@"有小朋友在哭叫我可以怎樣做？",@"在圖書館裡學習，要保持安靜", nil];
    
    NSArray*titleArray3=[NSArray arrayWithObjects:@"媽媽上班去，我可以做些什麼？",@"爸爸媽媽要到其他地方去，那麼我又會怎樣？",@"為甚麼我有一個「姐姐」？",@"我可以晚一點睡覺嗎？",@"為甚麼小朋友要收拾玩具？",@"學習輪流玩電腦",@"為甚麼生病時要留在家裡？",@"___病了，不能上學",@"開生日會是怎樣的？",@"我在什麼時候開燈？什麼時候關燈？",@"誰可以用洗衣機？",@"聽到吸塵器在響，我可以怎樣做？",@"什麼時候會聽到雷聲？",@"聽到打雷聲我可以怎樣做？",nil];
    
    NSArray*titleArray3_s=[NSArray arrayWithObjects:@"媽媽上班去，我可以做些什麼？",@"爸爸媽媽要到其他地方去，那麼我又會怎樣？",@"為甚麼我有一個「姐姐」？",@"我可以晚一點睡覺嗎？",@"為甚麼小朋友要收拾玩具？",@"學習輪流玩计算机",@"為甚麼生病時要留在家裡？",@"___病了，不能上學",@"開生日會是怎樣的？",@"我在什麼時候開燈？什麼時候關燈？",@"誰可以用洗衣機？",@"聽到吸塵器在響，我可以怎樣做？",@"什麼時候會聽到雷聲？",@"聽到打雷聲我可以怎樣做？",nil];
    
    
    
    NSArray*titleArray4=[NSArray arrayWithObjects:@"飯餐裡有不同的食物，我可以怎樣做？",@"吃飯時，我可以做什麼？",@"為甚麼要坐在椅子上吃飯？",@"看到地上有食物，我可以怎樣做？",@"在街上的廁所如廁是沒問題的？",@"什麼時候要沖廁？",@"衣服髒了要更換",@"什麼時候要抹嘴？",@"如果洗頭水的泡泡或水流到臉上、眼睛或耳朵裡，我可以怎樣做？",@"聽到風筒發出聲音，我可以怎麼辦？",@"我用什麼抹鼻涕？",@"小朋友怎樣學會習慣戴上口罩？",@"為甚麼我要吃藥？",@"為甚麼我要剪髮？",@"剪髮是怎樣的？",@"長度不同的髮型，各有各的好看",@"為甚麼要剪指甲？",nil];
    
    
    NSArray*titleArray5=[NSArray arrayWithObjects:@"為甚麼要扣上安全帶？",@"從哪個車門上車最安全？",@"為甚麼我要到外面玩耍？",@"小朋友在公園裡做什麼？",@"為甚麼要排隊付錢？",@"在餐廳裡吃東西是怎樣的？",@"怎樣在快餐店裡買食物？",@"為甚麼到不同的地方吃飯？",@"為甚麼要看醫生？",@"怎麼看醫生？",nil];
    

    
    
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"sp_profile"];
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        self.SVBookBase.contentSize = CGSizeMake(768.0, 925.0 + 68.0);
    }
    else {
        self.SVBookBase.contentSize = CGSizeMake(320.0, 650.0 + 68.0);
    }
    if (!self.VCRLSBookcase1 || !self.VCRLSBookcase2 || !self.VCRLSBookcase3 || !self.VCRLSBookcase4 || !self.VCRLSBookcase5) {
        //VCRLSBookcase1
        if (self.VCRLSBookcase1) {
            [self.VCRLSBookcase1.view removeFromSuperview];
        }
        self.VCRLSBookcase1 = [[[RLSBookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RLSBookcaseViewController"] bundle:nil] autorelease];
        
        NSArray *arrayBookID = [Bookcase1ID componentsSeparatedByString:@","];
        NSMutableArray *MABook = [NSMutableArray new];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            BOOL bFoundInReadingList = NO;
            for (int y = self.MAReadingList.count - 1; self.MAReadingList && y >= 0; y--) {
                if ([[arrayBookID objectAtIndex:x] isEqualToString:[self.MAReadingList objectAtIndex:y]]) {
                    bFoundInReadingList = YES;
                    break;
                }
            }
            
            NSDictionary *dictionaryBook;
            
            if (!bFoundInReadingList) {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"NO", @"isInReadingList", nil];
            }
            else {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"YES", @"isInReadingList", nil];
            }
            
            [MABook addObject:dictionaryBook];
        }
        self.VCRLSBookcase1.MABook = [[MABook mutableCopy] autorelease];
        if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
            
            self.VCRLSBookcase1.titleArray=titleArray1;
            
        }else{
            
            self.VCRLSBookcase1.titleArray=titleArray1_s;
            
        }
        
        self.VCRLSBookcase1.clearTitle=@"人际关系";
        self.VCRLSBookcase1.view.backgroundColor=[UIColor clearColor];

        self.VCRLSBookcase1.view.transform = CGAffineTransformIdentity;
        self.VCRLSBookcase1.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCRLSBookcase2
        if (self.VCRLSBookcase2) {
            [self.VCRLSBookcase2.view removeFromSuperview];
        }
        self.VCRLSBookcase2 = [[[RLSBookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RLSBookcaseViewController"] bundle:nil] autorelease];
        
        arrayBookID = [Bookcase2ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            BOOL bFoundInReadingList = NO;
            for (int y = self.MAReadingList.count - 1; self.MAReadingList && y >= 0; y--) {
                if ([[arrayBookID objectAtIndex:x] isEqualToString:[self.MAReadingList objectAtIndex:y]]) {
                    bFoundInReadingList = YES;
                    break;
                }
            }
            
            NSDictionary *dictionaryBook;
            
            if (!bFoundInReadingList) {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"NO", @"isInReadingList", nil];
            }
            else {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"YES", @"isInReadingList", nil];
            }
            
            [MABook addObject:dictionaryBook];
        }
        self.VCRLSBookcase2.MABook = [[MABook mutableCopy] autorelease];
        self.VCRLSBookcase2.titleArray=titleArray2;
        self.VCRLSBookcase2.clearTitle=@"学校";
        self.VCRLSBookcase2.view.backgroundColor=[UIColor clearColor];
        self.VCRLSBookcase2.view.transform = CGAffineTransformIdentity;
        self.VCRLSBookcase2.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCRLSBookcase3
        if (self.VCRLSBookcase3) {
            [self.VCRLSBookcase3.view removeFromSuperview];
        }
        self.VCRLSBookcase3 = [[[RLSBookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RLSBookcaseViewController"] bundle:nil] autorelease];
        
        arrayBookID = [Bookcase3ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            BOOL bFoundInReadingList = NO;
            for (int y = self.MAReadingList.count - 1; self.MAReadingList && y >= 0; y--) {
                if ([[arrayBookID objectAtIndex:x] isEqualToString:[self.MAReadingList objectAtIndex:y]]) {
                    bFoundInReadingList = YES;
                    break;
                }
            }
            
            NSDictionary *dictionaryBook;
            
            if (!bFoundInReadingList) {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"NO", @"isInReadingList", nil];
            }
            else {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"YES", @"isInReadingList", nil];
            }
            
            [MABook addObject:dictionaryBook];
        }
        self.VCRLSBookcase3.MABook = [[MABook mutableCopy] autorelease];
        if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
            
            self.VCRLSBookcase3.titleArray=titleArray3;
            
        }else{
            
            self.VCRLSBookcase3.titleArray=titleArray3_s;
            
        }
        
        self.VCRLSBookcase3.clearTitle=@"家庭";
        self.VCRLSBookcase3.view.backgroundColor=[UIColor clearColor];
        self.VCRLSBookcase3.view.transform = CGAffineTransformIdentity;
        self.VCRLSBookcase3.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCRLSBookcase4
        if (self.VCRLSBookcase4) {
            [self.VCRLSBookcase4.view removeFromSuperview];
        }
        self.VCRLSBookcase4 = [[[RLSBookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RLSBookcaseViewController"] bundle:nil] autorelease];
        
        arrayBookID = [Bookcase4ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            BOOL bFoundInReadingList = NO;
            for (int y = self.MAReadingList.count - 1; self.MAReadingList && y >= 0; y--) {
                if ([[arrayBookID objectAtIndex:x] isEqualToString:[self.MAReadingList objectAtIndex:y]]) {
                    bFoundInReadingList = YES;
                    break;
                }
            }
            
            NSDictionary *dictionaryBook;
            
            if (!bFoundInReadingList) {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"NO", @"isInReadingList", nil];
            }
            else {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"YES", @"isInReadingList", nil];
            }
            
            [MABook addObject:dictionaryBook];
        }
        self.VCRLSBookcase4.MABook = [[MABook mutableCopy] autorelease];
        self.VCRLSBookcase4.titleArray=titleArray4;
        self.VCRLSBookcase4.clearTitle=@"照顾自己";
        self.VCRLSBookcase4.view.transform = CGAffineTransformIdentity;
        self.VCRLSBookcase4.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        //VCRLSBookcase5
        if (self.VCRLSBookcase5) {
            [self.VCRLSBookcase5.view removeFromSuperview];
        }
        self.VCRLSBookcase5 = [[[RLSBookcaseViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RLSBookcaseViewController"] bundle:nil] autorelease];
        arrayBookID = [Bookcase5ID componentsSeparatedByString:@","];
        [MABook removeAllObjects];
        for (int x = 0; arrayBookID && x < arrayBookID.count; x++) {
            BOOL bFoundInReadingList = NO;
            for (int y = self.MAReadingList.count - 1; self.MAReadingList && y >= 0; y--) {
                if ([[arrayBookID objectAtIndex:x] isEqualToString:[self.MAReadingList objectAtIndex:y]]) {
                    bFoundInReadingList = YES;
                    break;
                }
            }
            
            NSDictionary *dictionaryBook;
            
            if (!bFoundInReadingList) {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"NO", @"isInReadingList", nil];
            }
            else {
                dictionaryBook = [NSDictionary dictionaryWithObjectsAndKeys:[arrayBookID objectAtIndex:x], @"bookID", @"YES", @"isInReadingList", nil];
            }
            
            [MABook addObject:dictionaryBook];
        }
        self.VCRLSBookcase5.MABook = [[MABook mutableCopy] autorelease];
        self.VCRLSBookcase5.titleArray=titleArray5;
        self.VCRLSBookcase5.clearTitle=@"外出";

        self.VCRLSBookcase5.view.transform = CGAffineTransformIdentity;
        self.VCRLSBookcase5.view.transform = CGAffineTransformMakeRotation(-M_PI_2);
        
        [MABook removeAllObjects];
        [MABook release];
        
        if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
            [self.SVBookBase addSubview:self.VCRLSBookcase1.view];
            self.VCRLSBookcase1.view.frame = CGRectMake(0.0, 0.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase2.view];
            self.VCRLSBookcase2.view.frame = CGRectMake(0.0, 185.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase3.view];
            self.VCRLSBookcase3.view.frame = CGRectMake(0.0, 370.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase4.view];
            self.VCRLSBookcase4.view.frame = CGRectMake(0.0, 555.0, 768.0, 185.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase5.view];
            self.VCRLSBookcase5.view.frame = CGRectMake(0.0, 740.0, 768.0, 185.0);
        }
        else {
            [self.SVBookBase addSubview:self.VCRLSBookcase1.view];
            self.VCRLSBookcase1.view.frame = CGRectMake(0.0, 0.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase2.view];
            self.VCRLSBookcase2.view.frame = CGRectMake(0.0, 130.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase3.view];
            self.VCRLSBookcase3.view.frame = CGRectMake(0.0, 260.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase4.view];
            self.VCRLSBookcase4.view.frame = CGRectMake(0.0, 390.0, 320.0, 130.0);
            
            [self.SVBookBase addSubview:self.VCRLSBookcase5.view];
            self.VCRLSBookcase5.view.frame = CGRectMake(0.0, 520.0, 320.0, 130.0);
        }
    }
    
    [self.VCRLSBookcase1 refreshBookcase];
    [self.VCRLSBookcase2 refreshBookcase];
    [self.VCRLSBookcase3 refreshBookcase];
    [self.VCRLSBookcase4 refreshBookcase];
    [self.VCRLSBookcase5 refreshBookcase];
    
    [self.SVBookBase bringSubviewToFront:self.IVCat1];
    [self.SVBookBase bringSubviewToFront:self.IVCat2];
    [self.SVBookBase bringSubviewToFront:self.IVCat3];
    [self.SVBookBase bringSubviewToFront:self.IVCat4];
    [self.SVBookBase bringSubviewToFront:self.IVCat5];
    
    //20131104
    
    NSString *stringDeviceSuffix;
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        stringDeviceSuffix = iPadXibSuffix;
    }
    else {
        stringDeviceSuffix = iPhoneXibSuffix;
    }
    
    self.IVCat1.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_greenbanner_1%@", stringDeviceSuffix]];
    self.IVCat2.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_yollowbanner_1%@", stringDeviceSuffix]];
    self.IVCat3.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_Purplebanner_1%@", stringDeviceSuffix]];
    self.IVCat4.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_bluebanner_1%@", stringDeviceSuffix]];
    self.IVCat5.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_y_redbanner_1%@", stringDeviceSuffix]];
}

#pragma mark - Handle Click Button Events

- (IBAction)clickConfirmButton:(UIButton *)button
{
    NSMutableArray *MAReadingList = [NSMutableArray new];
    
    for (int x = 0; self.VCRLSBookcase1.MABook && x < self.VCRLSBookcase1.MABook.count; x++) {
        if ([[[self.VCRLSBookcase1.MABook objectAtIndex:x] objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
            [MAReadingList addObject:[[self.VCRLSBookcase1.MABook objectAtIndex:x] objectForKey:@"bookID"]];
        }
    }
    for (int x = 0; self.VCRLSBookcase2.MABook && x < self.VCRLSBookcase2.MABook.count; x++) {
        if ([[[self.VCRLSBookcase2.MABook objectAtIndex:x] objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
            [MAReadingList addObject:[[self.VCRLSBookcase2.MABook objectAtIndex:x] objectForKey:@"bookID"]];
        }
    }
    for (int x = 0; self.VCRLSBookcase3.MABook && x < self.VCRLSBookcase3.MABook.count; x++) {
        if ([[[self.VCRLSBookcase3.MABook objectAtIndex:x] objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
            [MAReadingList addObject:[[self.VCRLSBookcase3.MABook objectAtIndex:x] objectForKey:@"bookID"]];
        }
    }
    for (int x = 0; self.VCRLSBookcase4.MABook && x < self.VCRLSBookcase4.MABook.count; x++) {
        if ([[[self.VCRLSBookcase4.MABook objectAtIndex:x] objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
            [MAReadingList addObject:[[self.VCRLSBookcase4.MABook objectAtIndex:x] objectForKey:@"bookID"]];
        }
    }
    for (int x = 0; self.VCRLSBookcase5.MABook && x < self.VCRLSBookcase5.MABook.count; x++) {
        if ([[[self.VCRLSBookcase5.MABook objectAtIndex:x] objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
            [MAReadingList addObject:[[self.VCRLSBookcase5.MABook objectAtIndex:x] objectForKey:@"bookID"]];
        }
    }

    NSMutableArray *MAReadingListList;
    if (self.iSelectedReadingListListIndex == UndefinedInt) {
        MAReadingListList = [self.MDCurrentStudentProfile objectForKey:@"readingListList"];
        if (MAReadingListList) {
            MAReadingListList = [MAReadingListList mutableCopy];
        }
        else {
            MAReadingListList = [NSMutableArray new];   
        }
        [MAReadingListList addObject:MAReadingList];
        [MAReadingList release];
    }
    else {
        MAReadingListList = [[self.MDCurrentStudentProfile objectForKey:@"readingListList"] mutableCopy];
        [MAReadingListList replaceObjectAtIndex:self.iSelectedReadingListListIndex withObject:MAReadingList];
    }
    
    [self.MDCurrentStudentProfile setObject:MAReadingListList forKey:@"readingListList"];
    [MAReadingListList release];
    
    NSMutableDictionary *MDStudentProfile = [[NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile] mutableCopy];
    
    NSMutableArray *MAStudentProfileList = [MDStudentProfile objectForKey:@"studentProfileList"];
    for (int x = 0; MAStudentProfileList && x < MAStudentProfileList.count; x++) {
        if ([[[MAStudentProfileList objectAtIndex:x] objectForKey:@"studentProfileID"] isEqualToString:[self.MDCurrentStudentProfile objectForKey:@"studentProfileID"]]) {
            [MAStudentProfileList replaceObjectAtIndex:x withObject:self.MDCurrentStudentProfile];
        }
    }
    
    [MDStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
    [MDStudentProfile release];
    
    [[CoreData sharedCoreData].JNC popViewControllerAnimated:NO];
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [grayBg release];
    grayBg = nil;
    [confirmBtn release];
    confirmBtn = nil;
    [super viewDidUnload];
}
@end
