//
//  NewStudentProfileViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月24日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface NewStudentProfileViewController : UIViewController{

    IBOutlet UIImageView *topNav;

    IBOutlet LeftMenuButton *leftBtn;

    IBOutlet UIButton *rightBtn;

    IBOutlet UIButton *deleteBtn;
}

@property (nonatomic, assign) BOOL bNewStudentProfile;
@property (nonatomic, retain) NSDictionary *MDCurrentStudentProfile;
@property (nonatomic, assign) int iIndexForStudentProfileList;

@end
