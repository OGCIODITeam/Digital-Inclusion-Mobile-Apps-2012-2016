//
//  StudentProfileViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月23日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#define AddSubviewTag 100
#define DeleteReadingListAlertViewTag 200

#import "StudentProfileViewController.h"
#import "ReadingListTableViewCell.h"
#import "NewStudentProfileViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ReadingListSelectionViewController.h"
#import <MessageUI/MessageUI.h>

@interface StudentProfileViewController () <UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate, UIAlertViewDelegate>

@property (nonatomic, retain) IBOutlet UIView *viewStudentProfileBase;
@property (nonatomic, retain) IBOutlet UILabel *labelStudentName, *labelStudentClass, *labelStudentSchool, *labelStudentParent, *labelStudentTeacher, *labelStudentParentEmail, *labelStudentTeacherEmail, *labelStudentParentTitle, *labelStudentTeacherTitle;

@property (nonatomic, retain) IBOutlet UITableView *TBVReadList;

@property (nonatomic, assign) int iCurrentStudentProfileIndex;
@property (nonatomic, retain) NSMutableArray *MACurrentReadingListList;
@property (nonatomic, retain) NSMutableArray *MAStudentProfileList;
@property (nonatomic, retain) NSMutableDictionary *MDCurrentStudentProfile;
@property (nonatomic, retain) IBOutlet UIImageView *IVStudentProfileLeftArrow, *IVStudentProfileRightArrow;

@property (nonatomic, assign) BOOL bClickedNewOrEditStudentProfileOrEditReadingList;

@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

@property (nonatomic, assign) int iReadingListIndexForDelete;

#pragma mark - Core

- (void)setup;
- (void)setupView;
- (void)setupStudentProfileView;

#pragma mark - Handle Gesture Recognizer Events

- (IBAction)swipeLeftGestureRecognizer:(UISwipeGestureRecognizer *)SGR;
- (IBAction)swipeRightGestureRecognizer:(UISwipeGestureRecognizer *)SGR;


#pragma mark - Handle Click Button Events

- (IBAction)clickNewStudentProfileButton:(UIButton *)button;
- (IBAction)clickEditStudentProfileButton:(UIButton *)button;
- (IBAction)clickAddReadingListButton:(UIButton *)button;

@end

@implementation StudentProfileViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.bClickedNewOrEditStudentProfileOrEditReadingList = NO;
    }
    return self;
}

- (void)dealloc
{
    self.viewStudentProfileBase = nil;
    self.labelStudentName = nil;
    self.labelStudentClass = nil;
    self.labelStudentSchool = nil;
    self.labelStudentParent = nil;
    self.labelStudentTeacher = nil;
    self.labelStudentParentEmail = nil;
    self.labelStudentTeacherEmail = nil;
    
    self.TBVReadList.delegate = nil;
    self.TBVReadList.dataSource = nil;
    self.TBVReadList = nil;
    
    [self.MACurrentReadingListList removeAllObjects];
    self.MACurrentReadingListList = nil;
    
    [self.MAStudentProfileList removeAllObjects];
    self.MAStudentProfileList = nil;
    
    self.MDCurrentStudentProfile = nil;
    
    self.IVStudentProfileLeftArrow.image = nil;
    self.IVStudentProfileLeftArrow = nil;
    
    self.IVStudentProfileRightArrow.image = nil;
    self.IVStudentProfileRightArrow = nil;
    
    self.labelStudentParentTitle = nil;
    self.labelStudentTeacherTitle = nil;
    
    self.IVTitle.image = nil;
    self.IVTitle = nil;
    DEBUGMSG(@"%@: dealloc", self.class);
    [topNav release];
    [leftBtn release];
    [right1Btn release];
    [right2Btn release];
    [newAdd release];
    [newAddListBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
        right1Btn.frame=CGRectMake(right1Btn.frame.origin.x, right1Btn.frame.origin.y+20, right1Btn.frame.size.width, right1Btn.frame.size.height);
        right2Btn.frame=CGRectMake(right2Btn.frame.origin.x, right2Btn.frame.origin.y+20, right2Btn.frame.size.width, right2Btn.frame.size.height);
        self.TBVReadList.frame=CGRectMake( self.TBVReadList.frame.origin.x,  self.TBVReadList.frame.origin.y+20,  self.TBVReadList.frame.size.width,  self.TBVReadList.frame.size.height-20);

        self.viewStudentProfileBase.frame=CGRectMake( self.viewStudentProfileBase.frame.origin.x,  self.viewStudentProfileBase.frame.origin.y+20,  self.viewStudentProfileBase.frame.size.width,  self.viewStudentProfileBase.frame.size.height);
        
        self.IVStudentProfileLeftArrow.frame=CGRectMake( self.IVStudentProfileLeftArrow.frame.origin.x,  self.IVStudentProfileLeftArrow.frame.origin.y+20,  self.IVStudentProfileLeftArrow.frame.size.width,  self.IVStudentProfileLeftArrow.frame.size.height);
        self.IVStudentProfileRightArrow.frame=CGRectMake( self.IVStudentProfileRightArrow.frame.origin.x,  self.IVStudentProfileRightArrow.frame.origin.y+20,  self.IVStudentProfileRightArrow.frame.size.width,  self.IVStudentProfileRightArrow.frame.size.height);
        newAdd.frame=CGRectMake(newAdd.frame.origin.x, newAdd.frame.origin.y, newAdd.frame.size.width, newAdd.frame.size.height);

        
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [right1Btn setTitle:@"添加新学生档案" forState:UIControlStateNormal];
    [right1Btn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
//    [right1Btn setImage:[UIImage imageNamed:@"sp_plus.png"] forState:UIControlStateNormal];

    [right2Btn setTitle:@"修改学生档案" forState:UIControlStateNormal];
    [right2Btn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [right2Btn setImage:[UIImage imageNamed:@"story100_pen_1.png"] forState:UIControlStateNormal];

    
    [newAddListBtn setTitle:@"新增阅读表" forState:UIControlStateNormal];
    [newAddListBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [newAddListBtn setImage:[UIImage imageNamed:@"sp_add_form_2.png"] forState:UIControlStateNormal];

    [self setup];
    [self setupView];
}

- (void)viewWillAppear:(BOOL)animated
{
    DEBUGMSG(@"%@: viewWillAppear", self.class);
    [super viewWillAppear:animated];
    NSDictionary *dictionaryStudentProfile = [NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile];
    if (dictionaryStudentProfile) {
        if ([dictionaryStudentProfile objectForKey:@"studentProfileList"] && ((NSArray *)[dictionaryStudentProfile objectForKey:@"studentProfileList"]).count > 0) {
            self.labelStudentParentTitle.hidden = NO;
            self.labelStudentTeacherTitle.hidden = NO;
        }
        else {
            self.labelStudentParentTitle.hidden = YES;
            self.labelStudentTeacherTitle.hidden = YES;
        }
    }
    else {
        self.labelStudentParentTitle.hidden = YES;
        self.labelStudentTeacherTitle.hidden = YES;
    }
    
    if (self.bClickedNewOrEditStudentProfileOrEditReadingList) {
        NSDictionary *dictionaryStudentProfile = [NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile];
        DEBUGMSG(@"dictionaryStudentProfile:\n%@", dictionaryStudentProfile);
        if (dictionaryStudentProfile) {
            self.MAStudentProfileList = [dictionaryStudentProfile objectForKey:@"studentProfileList"];
            if (self.MAStudentProfileList && self.MAStudentProfileList.count > 0) {
                self.MAStudentProfileList = [[self.MAStudentProfileList mutableCopy] autorelease];
                
                if (self.iCurrentStudentProfileIndex == UndefinedInt) {
                    self.iCurrentStudentProfileIndex = 0;
                }
                //201401201731
                else if (self.iCurrentStudentProfileIndex >= self.MAStudentProfileList.count) {
                    self.iCurrentStudentProfileIndex = 0;
                }
                    
                
                if (self.iCurrentStudentProfileIndex + 1 < self.MAStudentProfileList.count) {
                    self.IVStudentProfileRightArrow.hidden = NO;
                }
                else {
                    self.IVStudentProfileRightArrow.hidden = YES;
                }
                
                if (self.iCurrentStudentProfileIndex > 0) {
                    self.IVStudentProfileLeftArrow.hidden = NO;
                }
                else {
                    self.IVStudentProfileLeftArrow.hidden = YES;
                }
                
                self.MDCurrentStudentProfile = [self.MAStudentProfileList objectAtIndex:self.iCurrentStudentProfileIndex];
                self.MACurrentReadingListList = [self.MDCurrentStudentProfile objectForKey:@"readingListList"];
                [self setupStudentProfileView];
                DEBUGMSG(@"MACurrentReadingListList\n%@", self.MACurrentReadingListList);
                [self.TBVReadList reloadData];
            }
            //201401201731
            else {
                self.labelStudentName.text = @"";;
                self.labelStudentClass.text = @"";
                self.labelStudentSchool.text = @"";
                self.labelStudentParent.text = @"";
                self.labelStudentParentEmail.text = @"";
                self.labelStudentTeacher.text = @"";
                self.labelStudentTeacherEmail.text = @"";
                
                self.MACurrentReadingListList = nil;
                [self.TBVReadList reloadData];
            }
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    NSDictionary *dictionaryStudentProfile = [NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile];
    if (dictionaryStudentProfile) {
        self.MAStudentProfileList = [dictionaryStudentProfile objectForKey:@"studentProfileList"];
    }
    
    if (self.MAStudentProfileList && self.MAStudentProfileList.count > 0) {
        self.MAStudentProfileList = [[self.MAStudentProfileList mutableCopy] autorelease];
        self.iCurrentStudentProfileIndex = 0;
        self.MDCurrentStudentProfile = [self.MAStudentProfileList objectAtIndex:self.iCurrentStudentProfileIndex];
        self.MACurrentReadingListList = [self.MDCurrentStudentProfile objectForKey:@"readingListList"];
    }
    else {
        self.iCurrentStudentProfileIndex = UndefinedInt;
    }
}

- (void)setupView
{
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"sp_profile"];
    
    self.IVStudentProfileLeftArrow.hidden = YES;
    if (self.MAStudentProfileList.count > 1) {
        self.IVStudentProfileRightArrow.hidden = NO;
    }
    else {
        self.IVStudentProfileRightArrow.hidden = YES;
    }
    
    [self setupStudentProfileView];
    [self.TBVReadList reloadData];
}

- (void)setupStudentProfileView
{
    DEBUGMSG(@"setupStudentProfileView:\n%@", self.MDCurrentStudentProfile);
    DEBUGMSG(@"MAStudentProfileList:\n%@\nindex: %d", self.MAStudentProfileList, self.iCurrentStudentProfileIndex);
    if (self.MDCurrentStudentProfile) {
        self.labelStudentName.text = [NSString stringWithFormat:@"%@%@", [self.MDCurrentStudentProfile objectForKey:@"lastName"], [self.MDCurrentStudentProfile objectForKey:@"firstName"]];
        self.labelStudentClass.text = [self.MDCurrentStudentProfile objectForKey:@"class"];
        self.labelStudentSchool.text = [self.MDCurrentStudentProfile objectForKey:@"school"];
        self.labelStudentParent.text = [self.MDCurrentStudentProfile objectForKey:@"parent"];
        self.labelStudentParentEmail.text = [self.MDCurrentStudentProfile objectForKey:@"parentEmail"];
        self.labelStudentTeacher.text = [self.MDCurrentStudentProfile objectForKey:@"teacher"];
        self.labelStudentTeacherEmail.text = [self.MDCurrentStudentProfile objectForKey:@"teacherEmail"];
    }
}

- (void)shareReadingList:(NSArray *)arrayReadingList
{
    Class mailClass = NSClassFromString(@"MFMailComposeViewController");
    if (mailClass && [mailClass canSendMail]) {
        MFMailComposeViewController *VCMC = [[MFMailComposeViewController alloc] init];
        VCMC.mailComposeDelegate = self;
        NSString *stringReadingList = @"";
        for (int x = 0; arrayReadingList && x < arrayReadingList.count; x++) {
            if (x == arrayReadingList.count - 1) {
                stringReadingList = [stringReadingList stringByAppendingString:[arrayReadingList objectAtIndex:x]];
            }
            else {
                stringReadingList = [stringReadingList stringByAppendingFormat:@"%@,", [arrayReadingList objectAtIndex:x]];
            }
        }
        
        DEBUGMSG(@"stringReadingList: %@", stringReadingList);
        
        NSString *stringStoryName = @"";
        
        NSDictionary *dictionaryStoryFilename = [NSDictionary dictionaryWithContentsOfFile:PlistFilename];
        if (dictionaryStoryFilename) {
            for (int x = 0; arrayReadingList && x < arrayReadingList.count; x++) {
                if (x == 0) {
                    stringStoryName = [stringStoryName stringByAppendingFormat:@"%@", [dictionaryStoryFilename objectForKey:[NSString stringWithFormat:@"story%d_c_%@", [[arrayReadingList objectAtIndex:x] intValue], [CoreData sharedCoreData].stringLanguage]]];   
                }
                else {
                    stringStoryName = [stringStoryName stringByAppendingFormat:@"<br>%@", [dictionaryStoryFilename objectForKey:[NSString stringWithFormat:@"story%d_c_%@", [[arrayReadingList objectAtIndex:x] intValue], [CoreData sharedCoreData].stringLanguage]]];
                }
            }
        }
        
        [VCMC setToRecipients:[NSArray arrayWithObjects:[[self.MAStudentProfileList objectAtIndex:self.iCurrentStudentProfileIndex] objectForKey:@"parentEmail"], nil]];
        
        NSString *stringHTML = [NSString stringWithFormat:@"%@<p><a href=\"%@\">%@</a></p>", stringStoryName, [NSString stringWithFormat:@"govsahk://%@", stringReadingList], [NSString stringWithFormat:@"govsahk://%@", stringReadingList]];
        
        [VCMC setMessageBody:stringHTML isHTML:YES];
        [self presentModalViewController:VCMC animated:YES];
        [VCMC release];
    }
}

- (void)deleteReadingList:(int)iSelectedReadingListListIndex
{
//    [self.MACurrentReadingListList removeObjectAtIndex:iSelectedReadingListListIndex];
//    [self.TBVReadList reloadData];
//    [self.MDCurrentStudentProfile setObject:self.MACurrentReadingListList forKey:@"readingListList"];
//    
//    NSMutableDictionary *mutableDictionaryStudentProfile = [[NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile] mutableCopy];
//    [mutableDictionaryStudentProfile setObject:self.MAStudentProfileList forKey:@"studentProfileList"];
//    [mutableDictionaryStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
//    [mutableDictionaryStudentProfile release];
    
    self.iReadingListIndexForDelete = iSelectedReadingListListIndex;
    
//    %@%d", LocalizedString(@"sp_reading_list"), (indexPath.row + 1)
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@%@%d", LocalizedString(@"sp_confirm_to_delete"),  LocalizedString(@"sp_reading_list"), (self.iReadingListIndexForDelete + 1)] delegate:self cancelButtonTitle:LocalizedString(@"cm_cancel") otherButtonTitles:LocalizedString(@"cm_ok"), nil];
    alertView.tag = DeleteReadingListAlertViewTag;
    [alertView show];
    [alertView release];
}

#pragma mark - Handle Click Button Events

- (IBAction)clickNewStudentProfileButton:(UIButton *)button
{
    self.bClickedNewOrEditStudentProfileOrEditReadingList = YES;
    NewStudentProfileViewController *VCNewStudentProfile = [[NewStudentProfileViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"NewStudentProfileViewController"] bundle:nil];
    VCNewStudentProfile.bNewStudentProfile = YES;
    VCNewStudentProfile.MDCurrentStudentProfile = self.MDCurrentStudentProfile;
    [[CoreData sharedCoreData].JNC pushViewController:VCNewStudentProfile animated:NO];
    [VCNewStudentProfile release];
}

- (IBAction)clickEditStudentProfileButton:(UIButton *)button
{
    self.bClickedNewOrEditStudentProfileOrEditReadingList = YES;
    NewStudentProfileViewController *VCNewStudentProfile = [[NewStudentProfileViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"NewStudentProfileViewController"] bundle:nil];
    VCNewStudentProfile.bNewStudentProfile = NO;
    VCNewStudentProfile.MDCurrentStudentProfile = self.MDCurrentStudentProfile;
    VCNewStudentProfile.iIndexForStudentProfileList = self.iCurrentStudentProfileIndex;
    [[CoreData sharedCoreData].JNC pushViewController:VCNewStudentProfile animated:NO];
    [VCNewStudentProfile release];
}

- (IBAction)clickAddReadingListButton:(UIButton *)button
{
    if (self.MDCurrentStudentProfile) {
        self.bClickedNewOrEditStudentProfileOrEditReadingList = YES;
        ReadingListSelectionViewController *VCReadingListSelection = [[ReadingListSelectionViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"ReadingListSelectionViewController"] bundle:nil];
        VCReadingListSelection.iSelectedReadingListListIndex = UndefinedInt;
        VCReadingListSelection.MDCurrentStudentProfile = [[self.MDCurrentStudentProfile mutableCopy] autorelease];
        VCReadingListSelection.MAReadingList = nil;
        [[CoreData sharedCoreData].JNC pushViewController:VCReadingListSelection animated:NO];
        [VCReadingListSelection release];
    }
}

#pragma mark - Handle Gesture Recognizer Events

- (IBAction)swipeLeftGestureRecognizer:(UISwipeGestureRecognizer *)SGR
{
    if (self.iCurrentStudentProfileIndex + 1 < self.MAStudentProfileList.count) {
        self.iCurrentStudentProfileIndex++;
        
        self.IVStudentProfileLeftArrow.hidden = NO;
        if (self.iCurrentStudentProfileIndex + 1 < self.MAStudentProfileList.count) {
            self.IVStudentProfileRightArrow.hidden = NO;
        }
        else {
            self.IVStudentProfileRightArrow.hidden = YES;
        }
        //change content
        self.MDCurrentStudentProfile = [self.MAStudentProfileList objectAtIndex:self.iCurrentStudentProfileIndex];
        self.MACurrentReadingListList = [self.MDCurrentStudentProfile objectForKey:@"readingListList"];
        [self setupStudentProfileView];
        [self.TBVReadList reloadData];
        //
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionPush;
        transition.subtype = kCATransitionFromRight;
        [self.viewStudentProfileBase.layer removeAllAnimations];
		[self.viewStudentProfileBase.layer addAnimation:transition forKey:@""];
        [self.TBVReadList.layer removeAllAnimations];
		[self.TBVReadList.layer addAnimation:transition forKey:@""];
    }
}

- (IBAction)swipeRightGestureRecognizer:(UISwipeGestureRecognizer *)SGR
{
    if (self.iCurrentStudentProfileIndex - 1 >= 0) {
        self.iCurrentStudentProfileIndex--;
        
        self.IVStudentProfileRightArrow.hidden = NO;
        if (self.iCurrentStudentProfileIndex > 0) {
            self.IVStudentProfileLeftArrow.hidden = NO;
        }
        else {
            self.IVStudentProfileLeftArrow.hidden = YES;
        }
        
        //change content
        self.MDCurrentStudentProfile = [self.MAStudentProfileList objectAtIndex:self.iCurrentStudentProfileIndex];
        self.MACurrentReadingListList = [self.MDCurrentStudentProfile objectForKey:@"readingListList"];
        [self setupStudentProfileView];
        [self.TBVReadList reloadData];
        //
        CATransition *transition = [CATransition animation];
		transition.duration = 0.5;
		transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionPush;
        transition.subtype = kCATransitionFromLeft;
        [self.viewStudentProfileBase.layer removeAllAnimations];
		[self.viewStudentProfileBase.layer addAnimation:transition forKey:@""];
        [self.TBVReadList.layer removeAllAnimations];
		[self.TBVReadList.layer addAnimation:transition forKey:@""];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.MACurrentReadingListList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 46.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"ReadingListTableViewCell";
    ReadingListTableViewCell *cell = (ReadingListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"ReadingListTableViewCell"] owner:nil options:nil];
        for(id currentObject in objectArray) {
            if([currentObject isKindOfClass:[UITableViewCell class]]) {
                cell = (ReadingListTableViewCell *)currentObject;
                break;
            }
        }
    }
    
    [cell reset];
    cell.VCStudentProfile = self;
    cell.labelReadingListValue.text = [NSString stringWithFormat:@"%@%d", LocalizedString(@"sp_reading_list"), (indexPath.row + 1)];
    cell.arrayReadingList = [self.MACurrentReadingListList objectAtIndex:indexPath.row];
    cell.iSelectedReadingListListIndex = indexPath.row;
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.MDCurrentStudentProfile) {
        self.bClickedNewOrEditStudentProfileOrEditReadingList = YES;
        ReadingListSelectionViewController *VCReadingListSelection = [[ReadingListSelectionViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"ReadingListSelectionViewController"] bundle:nil];
        VCReadingListSelection.iSelectedReadingListListIndex = indexPath.row;
        VCReadingListSelection.MDCurrentStudentProfile = [[self.MDCurrentStudentProfile mutableCopy] autorelease];
        VCReadingListSelection.MAReadingList = [[[self.MACurrentReadingListList objectAtIndex:indexPath.row] mutableCopy] autorelease];
        [[CoreData sharedCoreData].JNC pushViewController:VCReadingListSelection animated:NO];
        [VCReadingListSelection release];
    }
}

#pragma mark - MFMailComposeViewControllerDelegate

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == DeleteReadingListAlertViewTag && buttonIndex == 1) {
        [self.MACurrentReadingListList removeObjectAtIndex:self.iReadingListIndexForDelete];
        [self.TBVReadList reloadData];
        [self.MDCurrentStudentProfile setObject:self.MACurrentReadingListList forKey:@"readingListList"];

        NSMutableDictionary *mutableDictionaryStudentProfile = [[NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile] mutableCopy];
        [mutableDictionaryStudentProfile setObject:self.MAStudentProfileList forKey:@"studentProfileList"];
        [mutableDictionaryStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
        [mutableDictionaryStudentProfile release];
    }
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [right1Btn release];
    right1Btn = nil;
    [right2Btn release];
    right2Btn = nil;
    [newAdd release];
    newAdd = nil;
    [newAddListBtn release];
    newAddListBtn = nil;
    [super viewDidUnload];
}
@end
