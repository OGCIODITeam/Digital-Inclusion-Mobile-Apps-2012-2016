//
//  RLSBookcaseViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RLSBookcaseViewController : UIViewController

@property (nonatomic, retain) NSMutableArray *MABook;
@property (nonatomic, retain) NSArray *titleArray;
@property (nonatomic, retain) NSString *clearTitle;
#pragma mark - Core

- (void)refreshBookcase;

@end
