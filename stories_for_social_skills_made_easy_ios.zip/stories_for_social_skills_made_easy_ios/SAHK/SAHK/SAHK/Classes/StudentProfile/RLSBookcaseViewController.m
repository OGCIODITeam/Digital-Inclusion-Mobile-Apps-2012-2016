//
//  RLSBookcaseViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月16日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "RLSBookcaseViewController.h"
#import "RLSBookcaseTableViewCell.h"
#import "BookcaseHeaderTableViewCell.h"

@interface RLSBookcaseViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, retain) IBOutlet UITableView *TBVBookcase;

@end

@implementation RLSBookcaseViewController

@synthesize MABook = _MABook;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    self.TBVBookcase.delegate = nil;
    self.TBVBookcase.dataSource = nil;
    self.TBVBookcase = nil;
    
    [self.MABook removeAllObjects];
    self.MABook = nil;
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)refreshBookcase
{
    [self.TBVBookcase reloadData];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.MABook.count + 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        if (indexPath.row == 0) {
            return 68.0;
        }
        return (20.0 + 100.0 + 20.0);
    }
    if (indexPath.row == 0) {
        return 38.0;
    }
    return (10.0 + 74.0 + 10.0);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == 0) {
        static NSString *identifier = @"BookcaseHeaderTableViewCell";
        BookcaseHeaderTableViewCell *cell = (BookcaseHeaderTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookcaseHeaderTableViewCell"] owner:nil options:nil];
            for(id currentObject in objectArray) {
                if([currentObject isKindOfClass:[UITableViewCell class]]) {
                    cell = (BookcaseHeaderTableViewCell *)currentObject;
                    cell.backgroundColor=[UIColor clearColor];

                    cell.userInteractionEnabled=NO;

                    cell.titleClearLbl.text=self.clearTitle;

                    break;
                }
            }
        }
        
        return cell;
    }
    
    static NSString *identifier = @"RLSBookcaseTableViewCell";
    RLSBookcaseTableViewCell *cell = (RLSBookcaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RLSBookcaseTableViewCell"] owner:nil options:nil];
        for(id currentObject in objectArray) {
            if([currentObject isKindOfClass:[UITableViewCell class]]) {
                cell = (RLSBookcaseTableViewCell *)currentObject;
                cell.backgroundColor=[UIColor clearColor];

                cell.clearLbl.text=[self.titleArray objectAtIndex:indexPath.row - 1];
                break;
            }
        }
    }
    
    NSString *stringBookCoverImageName = @"story";
    
    stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:[[self.MABook objectAtIndex:indexPath.row - 1] objectForKey:@"bookID"]];
    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:@"t"]) {
        stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
    }
    else {
       stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"]; 
    }
    
    if ([[[self.MABook objectAtIndex:indexPath.row - 1] objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
        [cell setupView:[UIImage imageNamed:stringBookCoverImageName] imageAdd:[UIImage imageNamed:@"sp_profile_add_1.png"]];
    }
    else {
        [cell setupView:[UIImage imageNamed:stringBookCoverImageName] imageAdd:[UIImage imageNamed:@"sp_profile_add_2.png"]];
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *MDBook = [[self.MABook objectAtIndex:indexPath.row - 1] mutableCopy];
    if ([MDBook objectForKey:@"isInReadingList"] && [[MDBook objectForKey:@"isInReadingList"] isEqualToString:@"YES"]) {
        [MDBook setObject:@"NO" forKey:@"isInReadingList"];
    }
    else {
        [MDBook setObject:@"YES" forKey:@"isInReadingList"];
    }
    [self.MABook replaceObjectAtIndex:(indexPath.row - 1) withObject:MDBook];
    [MDBook release];
    
    [self.TBVBookcase reloadData];
}

@end
