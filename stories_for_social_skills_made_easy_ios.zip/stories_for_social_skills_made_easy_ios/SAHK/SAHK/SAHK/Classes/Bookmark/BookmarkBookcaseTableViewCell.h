//
//  BookmarkBookcaseTableViewCell.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookmarkBookcaseTableViewCell : UITableViewCell{


    
    
    IBOutlet UIButton *btn1;
    
    IBOutlet UIButton *btn2;
    
    IBOutlet UIButton *btn3;
    
    IBOutlet UIButton *btn4;
    
    IBOutlet UIButton *btn5;
    
    
}

@property (nonatomic, retain) IBOutlet UIImageView *IVBook1, *IVBook2, *IVBook3, *IVBook4, *IVBook5;
@property (nonatomic, retain) NSDictionary *dictionaryBook1, *dictionaryBook2, *dictionaryBook3, *dictionaryBook4, *dictionaryBook5;


@property (retain ,nonatomic)NSString*text1;
@property (retain ,nonatomic)NSString*text2;
@property (retain ,nonatomic)NSString*text3;
@property (retain ,nonatomic)NSString*text4;
@property (retain ,nonatomic)NSString*text5;

#pragma mark - Core

- (void)reset;

@end
