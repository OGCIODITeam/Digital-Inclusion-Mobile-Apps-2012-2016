//
//  BookmarkBookcaseTableViewCell.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月15日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookmarkBookcaseTableViewCell.h"
#import "CustomBookContentViewController.h"
#import "BookContentViewController.h"

@interface BookmarkBookcaseTableViewCell ()


#pragma mark - Handle Click Button Events

- (IBAction)clickBook1Button:(UIButton *)button;
- (IBAction)clickBook2Button:(UIButton *)button;
- (IBAction)clickBook3Button:(UIButton *)button;
- (IBAction)clickBook4Button:(UIButton *)button;
- (IBAction)clickBook5Button:(UIButton *)button;

@end

@implementation BookmarkBookcaseTableViewCell

@synthesize IVBook1 = _IVBook1, IVBook2 = _IVBook2, IVBook3 = _IVBook3, IVBook4 = _IVBook4, IVBook5 = _IVBook5;
@synthesize dictionaryBook1 = _dictionaryBook1, dictionaryBook2 = _dictionaryBook2, dictionaryBook3 = _dictionaryBook3, dictionaryBook4 = _dictionaryBook4, dictionaryBook5 = _dictionaryBook5;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code


        
       
    }
    return self;
}
- (void)dealloc
{
    self.IVBook1.image = nil;
    self.IVBook1 = nil;
    
    self.IVBook2.image = nil;
    self.IVBook2 = nil;
    
    self.IVBook3.image = nil;
    self.IVBook3 = nil;
    
    self.IVBook4.image = nil;
    self.IVBook4 = nil;
    
    self.IVBook5.image = nil;
    self.IVBook5 = nil;
    
    self.dictionaryBook1 = nil;
    self.dictionaryBook2 = nil;
    self.dictionaryBook3 = nil;
    self.dictionaryBook4 = nil;
    self.dictionaryBook5 = nil;


    [btn1 release];
    [btn2 release];
    [btn3 release];
    [btn4 release];
    [btn5 release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
    
//    clearLbl_1.text=self.text1;
//    clearLbl_2.text=self.text2;
//    clearLbl_3.text=self.text3;
//    clearLbl_4.text=self.text4;
//    clearLbl_5.text=self.text5;
    [btn1 setTitle:self.text1 forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    [btn2 setTitle:self.text2 forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    [btn3 setTitle:self.text3 forState:UIControlStateNormal];
    [btn3 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    [btn4 setTitle:self.text4 forState:UIControlStateNormal];
    [btn4 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    
    [btn5 setTitle:self.text5 forState:UIControlStateNormal];
    [btn5 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

}

#pragma mark - Core

- (void)reset
{
    self.dictionaryBook1 = nil;
    self.dictionaryBook2 = nil;
    self.dictionaryBook3 = nil;
    self.dictionaryBook4 = nil;
    self.dictionaryBook5 = nil;
    self.IVBook1.image = nil;
    self.IVBook2.image = nil;
    self.IVBook3.image = nil;
    self.IVBook4.image = nil;
    self.IVBook5.image = nil;
    
    
    

}

#pragma mark - Handle Click Button Events

- (IBAction)clickBook1Button:(UIButton *)button
{
    if (self.dictionaryBook1) {
        if ([[self.dictionaryBook1 objectForKey:@"isCustomStory"] isEqualToString:@"YES"]) {
            CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];
            VCCustomBookContent.bPushFromBookmarkView = YES;
            VCCustomBookContent.dictionaryBook = self.dictionaryBook1;
            [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
            [VCCustomBookContent release];
        }
        else {
            BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
            VCBookContent.bPushFromBookmarkView = YES;
            VCBookContent.dictionaryBook = self.dictionaryBook1;
            [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
            [VCBookContent release];
        }
    }
}

- (IBAction)clickBook2Button:(UIButton *)button
{
    if (self.dictionaryBook2) {
        if ([[self.dictionaryBook2 objectForKey:@"isCustomStory"] isEqualToString:@"YES"]) {
            CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];
            VCCustomBookContent.bPushFromBookmarkView = YES;
            VCCustomBookContent.dictionaryBook = self.dictionaryBook2;
            [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
            [VCCustomBookContent release];
        }
        else {
            BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
            VCBookContent.bPushFromBookmarkView = YES;
            VCBookContent.dictionaryBook = self.dictionaryBook2;
            [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
            [VCBookContent release];
        }
    }
}

- (IBAction)clickBook3Button:(UIButton *)button
{
    if (self.dictionaryBook3) {
        if ([[self.dictionaryBook3 objectForKey:@"isCustomStory"] isEqualToString:@"YES"]) {
            CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];
            VCCustomBookContent.bPushFromBookmarkView = YES;
            VCCustomBookContent.dictionaryBook = self.dictionaryBook3;
            [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
            [VCCustomBookContent release];
        }
        else {
            BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
            VCBookContent.bPushFromBookmarkView = YES;
            VCBookContent.dictionaryBook = self.dictionaryBook3;
            [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
            [VCBookContent release];
        }
    }
}

- (IBAction)clickBook4Button:(UIButton *)button
{
    if (self.dictionaryBook4) {
        if ([[self.dictionaryBook4 objectForKey:@"isCustomStory"] isEqualToString:@"YES"]) {
            CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];
            VCCustomBookContent.bPushFromBookmarkView = YES;
            VCCustomBookContent.dictionaryBook = self.dictionaryBook4;
            [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
            [VCCustomBookContent release];
        }
        else {
            BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
            VCBookContent.bPushFromBookmarkView = YES;
            VCBookContent.dictionaryBook = self.dictionaryBook4;
            [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
            [VCBookContent release];
        }
    }
}

- (IBAction)clickBook5Button:(UIButton *)button
{
    if (self.dictionaryBook5) {
        if ([[self.dictionaryBook5 objectForKey:@"isCustomStory"] isEqualToString:@"YES"]) {
            CustomBookContentViewController *VCCustomBookContent = [[CustomBookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomBookContentViewController"] bundle:nil];
            VCCustomBookContent.bPushFromBookmarkView = YES;
            VCCustomBookContent.dictionaryBook = self.dictionaryBook5;
            [[CoreData sharedCoreData].JNC pushViewController:VCCustomBookContent animated:NO];
            [VCCustomBookContent release];
        }
        else {
            BookContentViewController *VCBookContent = [[BookContentViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookContentViewController"] bundle:nil];
            VCBookContent.bPushFromBookmarkView = YES;
            VCBookContent.dictionaryBook = self.dictionaryBook5;
            [[CoreData sharedCoreData].JNC pushViewController:VCBookContent animated:NO];
            [VCBookContent release];
        }
    }
}

@end
