//
//  BookmarkViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年9月23日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftMenuButton.h"

@interface BookmarkViewController : UIViewController{

    IBOutlet UIImageView *topNav;
    IBOutlet LeftMenuButton *leftBtn;

    NSArray*titleArray_s;
    NSArray*titleArray_t;


}

@end
