//
//  BookmarkViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月23日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "BookmarkViewController.h"
#import "BookmarkBookcaseTableViewCell.h"

@interface BookmarkViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) NSMutableArray *MABookmark;
@property (nonatomic, retain) IBOutlet UITableView *TBVBookmark;
@property (nonatomic, retain) IBOutlet UIImageView *IVTitle;

#pragma mark - Core

- (void)setup;
- (void)setupView;

@end

@implementation BookmarkViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [self.MABookmark removeAllObjects];
    self.MABookmark = nil;
    
    self.TBVBookmark.delegate = nil;
    self.TBVBookmark.dataSource = nil;
    self.TBVBookmark = nil;
    
    self.IVTitle = nil;
    [topNav release];
    [leftBtn release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IOS7_OR_LATER) {
        
        
        topNav.frame=CGRectMake(topNav.frame.origin.x, topNav.frame.origin.y, topNav.frame.size.width, topNav.frame.size.height+20);
        self.IVTitle.frame=CGRectMake(self.IVTitle.frame.origin.x, self.IVTitle.frame.origin.y+20, self.IVTitle.frame.size.width, self.IVTitle.frame.size.height);
        leftBtn.frame=CGRectMake(leftBtn.frame.origin.x, leftBtn.frame.origin.y+20, leftBtn.frame.size.width, leftBtn.frame.size.height);
      
        self.TBVBookmark.frame=CGRectMake( self.TBVBookmark.frame.origin.x,  self.TBVBookmark.frame.origin.y+20,  self.TBVBookmark.frame.size.width,  self.TBVBookmark.frame.size.height-20);
        
    }
    [leftBtn setTitle:@"選單鍵" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"cm_manu_bu_iPhone.png"] forState:UIControlStateNormal];

    [self setup];
    [self setupView];
    
    
titleArray_s=[NSArray arrayWithObjects:@"怎样打招呼？",@"什么时候握手？",@"什么时候说［谢谢］（1）？",@"什么时候说［谢谢］（2）？",@"什么时候说［对不起］？",@"我可以怎样拿到想要的东西？",@"怎样令人开心？",@"见到喜欢得小朋友，我可以怎样做？",@"怎样帮助别人？",@"小朋友还未把事情做好，我可以怎样做？",@"事情做错了，应该怎么办？",@"不开心时，我可以怎样做？",@"生气时，我可以怎样做？",@"怎样保持冷静？",@"想玩玩具时，我可以怎样做？",@"想玩别人得玩具时，我可以怎样做？",@"小朋友不想借玩具、借图书给我，我可以怎样做？",@"在我家里，朋友可以玩我的玩具吗？",@"怎样才能拿回自己得玩具？",@"怎样分享玩具？",@"什么时候轮到我玩玩具？",@"怎样学些玩游戏？",@"玩游戏时，我可以怎样做？",@"怎样接受比赛得胜负？",@"别人向我说话时，我可以做什么？",@"朋友正在谈话，我有话要说，我可以怎样做？",@"为什么要等别人把话说完，我才开始说话？",@"当我不知道别人说什么时，可以怎样做？",@"别人向我发问时，我可以怎样做？",@"为什么谈话要有不同得话题？",@"人人都有机会表达意见",@"保持适当得声量",@"學校是什麼地方？",@"為甚麼我要上學？",@"我在學校裡，做些什麼事？",@"小時候做些什麼事？",@"回到學校後，媽媽為甚麼便要走？",@"怎樣乘搭校車？",@"乘坐校車時，我可以怎樣做？",@"為甚麼我要午睡？",@"我在午睡時間可以怎樣做？",@"如果我不想午睡，我可以怎麼辦？",@"為甚麼會有代課老師？",@"什麼是假期？",@"為甚麼要留心上課？",@"上課時，小朋友想做其他事情，他可以怎樣做？",@"當我看到有趣的教材或玩具時，可以怎樣做？",@"老師說話時，為甚麼我要保持安靜？",@"老師在說話，我有話說，我可以怎樣做？",@"老師，你說了些什麼？",@"為甚麼要舉手輪流說話？",@"上課時怎樣問問題？",@"老師沒有叫我的名字我該怎麼辦？",@"老師請其他小朋友幫忙做事情，我可以怎樣做？",@"遇到問題我可以找誰幫忙？",@"排隊時要怎樣做？",@"每位小朋友都有機會排第一",@"有小朋友在哭叫我可以怎樣做？",@"在圖書館裡學習，要保持安靜", @"媽媽上班去，我可以做些什麼？",@"爸爸媽媽要到其他地方去，那麼我又會怎樣？",@"為甚麼我有一個「姐姐」？",@"我可以晚一點睡覺嗎？",@"為甚麼小朋友要收拾玩具？",@"學習輪流玩计算机",@"為甚麼生病時要留在家裡？",@"___病了，不能上學",@"開生日會是怎樣的？",@"我在什麼時候開燈？什麼時候關燈？",@"誰可以用洗衣機？",@"聽到吸塵器在響，我可以怎樣做？",@"什麼時候會聽到雷聲？",@"聽到打雷聲我可以怎樣做？",@"飯餐裡有不同的食物，我可以怎樣做？",@"吃飯時，我可以做什麼？",@"為甚麼要坐在椅子上吃飯？",@"看到地上有食物，我可以怎樣做？",@"在街上的廁所如廁是沒問題的？",@"什麼時候要沖廁？",@"衣服髒了要更換",@"什麼時候要抹嘴？",@"如果洗頭水的泡泡或水流到臉上、眼睛或耳朵裡，我可以怎樣做？",@"聽到風筒發出聲音，我可以怎麼辦？",@"我用什麼抹鼻涕？",@"小朋友怎樣學會習慣戴上口罩？",@"為甚麼我要吃藥？",@"為甚麼我要剪髮？",@"剪髮是怎樣的？",@"長度不同的髮型，各有各的好看",@"為甚麼要剪指甲？",@"為甚麼要扣上安全帶？",@"從哪個車門上車最安全？",@"為甚麼我要到外面玩耍？",@"小朋友在公園裡做什麼？",@"為甚麼要排隊付錢？",@"在餐廳裡吃東西是怎樣的？",@"怎樣在快餐店裡買食物？",@"為甚麼到不同的地方吃飯？",@"為甚麼要看醫生？",@"怎麼看醫生？", nil];
    

    titleArray_t=[NSArray arrayWithObjects:@"怎样打招呼？",@"什麼時候握手？",@"什麼時候說多謝？",@"什麼時候說唔該？",@"什麼時候說對唔住？",@"我可以怎樣拿到想要的東西？",@"怎樣令人開心？",@"見到喜歡的小朋友，我可以怎樣做？",@"怎樣幫助別人？",@"小朋友還未把事情做好，我可以怎樣做？",@"事情做錯了，應該怎麼辦？",@"不開心時，我可以怎樣做？",@"生氣時，我可以怎樣做？",@"怎樣保持冷靜？",@"想玩玩具時，我可以怎樣做？",@"想玩別人的玩具時，我可以怎樣做？",@"小朋友不想借玩具、借圖書給我，我可以怎樣做？",@"在我家裡，朋友可以玩我的玩具嗎？",@"怎樣才能拿回自己的玩具？",@"怎樣分享玩具？",@"什麼時候輪到我玩玩具？",@"怎樣學習玩遊戲？",@"玩遊戲時，我可以怎樣做？",@"怎樣接受比賽的勝負？",@"別人向我說話時，我可以做什麼？",@"朋友正在談話，我有話要說，我可以怎樣做？",@"為甚麼要等別人把話說完，我才開始說話？",@"當我不知道別人說什麼時，可以怎樣做？",@"別人向我發問時，我可以怎樣做？",@"為甚麼談話要有不同的話題？",@"人人都有機會表達意見",@"保持適當的聲量",@"學校是什麼地方？",@"為甚麼我要上學？",@"我在學校裡，做些什麼事？",@"小時候做些什麼事？",@"回到學校後，媽媽為甚麼便要走？",@"怎樣乘搭校車？",@"乘坐校車時，我可以怎樣做？",@"為甚麼我要午睡？",@"我在午睡時間可以怎樣做？",@"如果我不想午睡，我可以怎麼辦？",@"為甚麼會有代課老師？",@"什麼是假期？",@"為甚麼要留心上課？",@"上課時，小朋友想做其他事情，他可以怎樣做？",@"當我看到有趣的教材或玩具時，可以怎樣做？",@"老師說話時，為甚麼我要保持安靜？",@"老師在說話，我有話說，我可以怎樣做？",@"老師，你說了些什麼？",@"為甚麼要舉手輪流說話？",@"上課時怎樣問問題？",@"老師沒有叫我的名字我該怎麼辦？",@"老師請其他小朋友幫忙做事情，我可以怎樣做？",@"遇到問題我可以找誰幫忙？",@"排隊時要怎樣做？",@"每位小朋友都有機會排第一",@"有小朋友在哭叫我可以怎樣做？",@"在圖書館裡學習，要保持安靜", @"媽媽上班去，我可以做些什麼？",@"爸爸媽媽要到其他地方去，那麼我又會怎樣？",@"為甚麼我有一個「姐姐」？",@"我可以晚一點睡覺嗎？",@"為甚麼小朋友要收拾玩具？",@"學習輪流玩電腦",@"為甚麼生病時要留在家裡？",@"___病了，不能上學",@"開生日會是怎樣的？",@"我在什麼時候開燈？什麼時候關燈？",@"誰可以用洗衣機？",@"聽到吸塵器在響，我可以怎樣做？",@"什麼時候會聽到雷聲？",@"聽到打雷聲我可以怎樣做？",@"飯餐裡有不同的食物，我可以怎樣做？",@"吃飯時，我可以做什麼？",@"為甚麼要坐在椅子上吃飯？",@"看到地上有食物，我可以怎樣做？",@"在街上的廁所如廁是沒問題的？",@"什麼時候要沖廁？",@"衣服髒了要更換",@"什麼時候要抹嘴？",@"如果洗頭水的泡泡或水流到臉上、眼睛或耳朵裡，我可以怎樣做？",@"聽到風筒發出聲音，我可以怎麼辦？",@"我用什麼抹鼻涕？",@"小朋友怎樣學會習慣戴上口罩？",@"為甚麼我要吃藥？",@"為甚麼我要剪髮？",@"剪髮是怎樣的？",@"長度不同的髮型，各有各的好看",@"為甚麼要剪指甲？",@"為甚麼要扣上安全帶？",@"從哪個車門上車最安全？",@"為甚麼我要到外面玩耍？",@"小朋友在公園裡做什麼？",@"為甚麼要排隊付錢？",@"在餐廳裡吃東西是怎樣的？",@"怎樣在快餐店裡買食物？",@"為甚麼到不同的地方吃飯？",@"為甚麼要看醫生？",@"怎麼看醫生？", nil];
    
  }

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    if (self.MABookmark) {
        [self.MABookmark removeAllObjects];
    }
    
    NSArray *arrayBookmark = [NSArray arrayWithContentsOfFile:PlistPathBookmark];
    if (arrayBookmark) {
        self.MABookmark = [[arrayBookmark mutableCopy] autorelease];
    }
}

- (void)setupView
{
    self.IVTitle.image = [[CoreData sharedCoreData] getImageByLanguage:@"bookmark_title"];
    [self.TBVBookmark reloadData];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        return ceilf(self.MABookmark.count / 5.0);
    }
    return ceilf(self.MABookmark.count / 3.0);
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        return 185.0;
    }
    return 130.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"BookmarkBookcaseTableViewCell";
    BookmarkBookcaseTableViewCell *cell = (BookmarkBookcaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        NSArray *objectArray = [[NSBundle mainBundle] loadNibNamed:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookmarkBookcaseTableViewCell"] owner:nil options:nil];
        for(id currentObject in objectArray) {
            if([currentObject isKindOfClass:[UITableViewCell class]]) {
                cell = (BookmarkBookcaseTableViewCell *)currentObject;
                break;
            }
        }
    }
    
    
    
    
    
    NSString *stringIVBookImageSuffix;
    if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
        stringIVBookImageSuffix = @"_c_t_ct.png";
    }
    else {
        stringIVBookImageSuffix = @"_c_s_sc.png";
    }
    
    [cell reset];    
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        if ((indexPath.row * 5) < self.MABookmark.count) {
            cell.dictionaryBook1 = [self.MABookmark objectAtIndex:(indexPath.row * 5)];
            cell.IVBook1.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:(indexPath.row * 5)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                  cell.text1=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:(indexPath.row * 5)] objectForKey:@"bookID"] intValue]-1];
            }else{
                cell.text1=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:(indexPath.row * 5)] objectForKey:@"bookID"] intValue]-1];
            }
//           NSString*clearTitle1=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:(indexPath.row * 5)] objectForKey:@"bookID"] intValue]-1];
            
            NSLog(@"什么时候＝＝＝＝＝%d",[[[self.MABookmark objectAtIndex:(indexPath.row * 5)] objectForKey:@"bookID"] intValue]-1);
            NSLog(@"内容＝＝＝＝＝%@", cell.dictionaryBook1);

        }
        if (((indexPath.row * 5) + 1) < self.MABookmark.count) {
            cell.dictionaryBook2 = [self.MABookmark objectAtIndex:((indexPath.row * 5) + 1)];
            cell.IVBook2.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 1)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text2=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 1)] objectForKey:@"bookID"] intValue]-1];

            }else{
                cell.text2=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 1)] objectForKey:@"bookID"] intValue]-1];
            }

        }
        if (((indexPath.row * 5) + 2) < self.MABookmark.count) {
            cell.dictionaryBook3 = [self.MABookmark objectAtIndex:((indexPath.row * 5) + 2)];
            cell.IVBook3.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 2)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text3=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 2)] objectForKey:@"bookID"] intValue]-1];

            }else{
          
            cell.text3=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 2)] objectForKey:@"bookID"] intValue]-1];
                  }

        }
        if (((indexPath.row * 5) + 3) < self.MABookmark.count) {
            cell.dictionaryBook4 = [self.MABookmark objectAtIndex:((indexPath.row * 5) + 3)];
            cell.IVBook4.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 3)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text4=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 3)] objectForKey:@"bookID"] intValue]-1];

            }else{
            cell.text4=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 3)] objectForKey:@"bookID"] intValue]-1];
            }

        }
        if (((indexPath.row * 5) + 4) < self.MABookmark.count) {
            cell.dictionaryBook5 = [self.MABookmark objectAtIndex:((indexPath.row * 5) + 4)];
            cell.IVBook5.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 4)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text5=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 4)] objectForKey:@"bookID"] intValue]-1];

            }else{
                cell.text5=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 5) + 4)] objectForKey:@"bookID"] intValue]-1];
            }

        }
    }
    else {
        if ((indexPath.row * 3) < self.MABookmark.count) {
            cell.dictionaryBook1 = [self.MABookmark objectAtIndex:(indexPath.row * 3)];
            cell.IVBook1.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:(indexPath.row * 3)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text1=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:(indexPath.row * 3)] objectForKey:@"bookID"] intValue]-1];

            }else{
            cell.text1=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:(indexPath.row * 3)] objectForKey:@"bookID"] intValue]-1];
            }

        }
        if (((indexPath.row * 3) + 1) < self.MABookmark.count) {
            cell.dictionaryBook2 = [self.MABookmark objectAtIndex:((indexPath.row * 3) + 1)];
            cell.IVBook2.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:((indexPath.row * 3) + 1)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text2=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 3) + 1)] objectForKey:@"bookID"] intValue]-1];

            }else{
            cell.text2=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 3) + 1)] objectForKey:@"bookID"] intValue]-1];
                }

        }
        if (((indexPath.row * 3) + 2) < self.MABookmark.count) {
            cell.dictionaryBook3 = [self.MABookmark objectAtIndex:((indexPath.row * 3) + 2)];
            cell.IVBook3.image = [UIImage imageNamed:[NSString stringWithFormat:@"story%d%@", [[[self.MABookmark objectAtIndex:((indexPath.row * 3) + 2)] objectForKey:@"bookID"] intValue], stringIVBookImageSuffix]];
            if ([[CoreData sharedCoreData].stringLanguage isEqualToString:@"t"]) {
                cell.text3=[titleArray_t objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 3) + 2)] objectForKey:@"bookID"] intValue]-1];

            }else{
            cell.text3=[titleArray_s objectAtIndex:[[[self.MABookmark objectAtIndex:((indexPath.row * 3) + 2)] objectForKey:@"bookID"] intValue]-1];
                }

        }
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)viewDidUnload {
    [topNav release];
    topNav = nil;
    [leftBtn release];
    leftBtn = nil;
    [super viewDidUnload];
}
@end
