//
//  LeftRootViewController.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月12日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftRootViewController : UIViewController{


    
    IBOutlet UILabel *aboutUs;
    
    IBOutlet UILabel *aboutUs_ipad;
    
}

#pragma mark - Core

- (void)openAppProcess;
- (void)reloadView;

@end
