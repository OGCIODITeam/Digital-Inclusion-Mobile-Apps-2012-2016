//
//  LeftRootViewController.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月12日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "LeftRootViewController.h"
#import "Story100ViewController.h"
#import "SettingsViewController.h"
#import "CustomStoryViewController.h"
#import "BookmarkViewController.h"
#import "StudentProfileViewController.h"
#import "AboutSAHKViewController.h"
#import "SocialStoryNoticeViewController.h"
#import "SocialStoryRecordFormViewController.h"
#import "BookRatingViewController.h"

#define AddSubViewTag 101

@interface LeftRootViewController ()

@property (nonatomic, retain) NSMutableArray *MAButton;
@property (nonatomic, retain) IBOutlet UIButton *button1, *button2, *button3, *button4, *button5, *button6, *button7, *button8;
@property (nonatomic, retain) IBOutlet UIView *viewDateBase;
@property (nonatomic, retain) IBOutlet UILabel *labelDateDay, *labelDateMonth, *labelDateYear;
@property (nonatomic, retain) IBOutlet UIView *viewReportBase;
@property (nonatomic, retain) IBOutlet UIImageView *IVBookcaseCat1Base, *IVBookcaseCat2Base, *IVBookcaseCat3Base, *IVBookcaseCat4Base, *IVBookcaseCat5Base;
@property (nonatomic, retain) IBOutlet UIImageView *IVAboutUs;

#pragma mark - Core

- (void)setup;
- (void)setupView;

#pragma mark - Handle Click Button Events

- (IBAction)clickButton:(UIButton *)button;

@end

@implementation LeftRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [self.MAButton removeAllObjects];
    self.MAButton = nil;
    
    self.button1 = nil;
    self.button2 = nil;
    self.button3 = nil;
    self.button4 = nil;
    self.button5 = nil;
    self.button6 = nil;
    self.button7 = nil;
    self.button8 = nil;
    
    self.viewDateBase = nil;
    self.labelDateDay = nil;
    self.labelDateMonth = nil;
    self.labelDateYear = nil;
    
    self.viewReportBase = nil;
    
    self.IVBookcaseCat1Base = nil;
    self.IVBookcaseCat2Base = nil;
    self.IVBookcaseCat3Base = nil;
    self.IVBookcaseCat4Base = nil;
    self.IVBookcaseCat5Base = nil;
    
    self.IVAboutUs = nil;
    [aboutUs release];
    [aboutUs_ipad release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (IOS7_OR_LATER) {
        
        self.button1.frame=CGRectMake(self.button1.frame.origin.x, self.button1.frame.origin.y+20, self.button1.frame.size.width, self.button1.frame.size.height);
        self.button2.frame=CGRectMake(self.button2.frame.origin.x, self.button2.frame.origin.y+20, self.button2.frame.size.width, self.button2.frame.size.height);
        self.button3.frame=CGRectMake(self.button3.frame.origin.x, self.button3.frame.origin.y+20, self.button3.frame.size.width, self.button3.frame.size.height);
        self.button4.frame=CGRectMake(self.button4.frame.origin.x, self.button4.frame.origin.y+20, self.button4.frame.size.width, self.button4.frame.size.height);
        self.button5.frame=CGRectMake(self.button5.frame.origin.x, self.button5.frame.origin.y+20, self.button5.frame.size.width, self.button5.frame.size.height);
        self.button6.frame=CGRectMake(self.button6.frame.origin.x, self.button6.frame.origin.y+20, self.button6.frame.size.width, self.button6.frame.size.height);
        self.button7.frame=CGRectMake(self.button7.frame.origin.x, self.button7.frame.origin.y+20, self.button7.frame.size.width, self.button7.frame.size.height);
        self.button8.frame=CGRectMake(self.button8.frame.origin.x, self.button8.frame.origin.y+20, self.button8.frame.size.width, self.button8.frame.size.height);
        self.IVAboutUs.frame=CGRectMake(self.IVAboutUs.frame.origin.x, self.IVAboutUs.frame.origin.y+20, self.IVAboutUs.frame.size.width, self.IVAboutUs.frame.size.height);
   aboutUs.frame=CGRectMake(aboutUs.frame.origin.x, aboutUs.frame.origin.y+20, aboutUs.frame.size.width, aboutUs.frame.size.height);
        aboutUs_ipad.frame=CGRectMake(aboutUs_ipad.frame.origin.x, aboutUs_ipad.frame.origin.y+20, aboutUs_ipad.frame.size.width, aboutUs_ipad.frame.size.height);

        
    }
    
    
    [self setup];
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Core

- (void)setup
{
    if (!self.MAButton) {
        self.MAButton = [[NSMutableArray new] autorelease];
        [self.MAButton addObject:self.button1];
        [self.MAButton addObject:self.button2];
        [self.MAButton addObject:self.button3];
        [self.MAButton addObject:self.button4];
        [self.MAButton addObject:self.button5];
        [self.MAButton addObject:self.button6];
        [self.MAButton addObject:self.button7];
        [self.MAButton addObject:self.button8];
    }
}

- (void)setupView
{
    [self reloadView];
}

- (void)reloadView
{
    [self.button1 setTitle:@"100个社交小故事" forState:UIControlStateNormal];
    [self.button1 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    
    [self.button2 setTitle:@"自制小故事" forState:UIControlStateNormal];
    [self.button2 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self.button3 setTitle:@"学生档案" forState:UIControlStateNormal];
    [self.button3 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self.button4 setTitle:@"书签" forState:UIControlStateNormal];
    [self.button4 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self.button5 setTitle:@"关于香港耀能协会" forState:UIControlStateNormal];
    [self.button5 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self.button6 setTitle:@"使用社交故事需知" forState:UIControlStateNormal];
    [self.button6 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self.button7 setTitle:@"社交故事记录表格" forState:UIControlStateNormal];
    [self.button7 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];

    [self.button8 setTitle:@"设定" forState:UIControlStateNormal];
    [self.button8 setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
    
    aboutUs.text=@"关于我们";
    aboutUs_ipad.text=@"关于我们";
    NSString *stringDeviceSuffix;
    if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:iPad]) {
        stringDeviceSuffix = iPadXibSuffix;
    }
    else {
        stringDeviceSuffix = iPhoneXibSuffix;
    }
    
//    [self.button1 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu1_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button1 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu1_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button2 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu2_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button2 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu2_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button3 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu3_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button3 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu3_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button4 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu4_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button4 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu4_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button5 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu6_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button5 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu6_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button6 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu7_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button6 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu7_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button7 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu8_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button7 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu8_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//    
//    [self.button8 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu9_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
//    [self.button8 setBackgroundImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu9_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
//
    
    [self.button1 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu1_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button1 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu1_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button2 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu2_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button2 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu2_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button3 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu3_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button3 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu3_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button4 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu4_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button4 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu4_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button5 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu6_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button5 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu6_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button6 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu7_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button6 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu7_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button7 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu8_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button7 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu8_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    
    [self.button8 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu9_up%@", stringDeviceSuffix]] forState:UIControlStateNormal];
    [self.button8 setImage:[[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu9_down%@", stringDeviceSuffix]] forState:UIControlStateSelected];
    

    
    
    
    
    self.IVAboutUs.image = [[CoreData sharedCoreData] getImageByLanguage:[NSString stringWithFormat:@"cm_sahk_manu_bu5_down%@", stringDeviceSuffix]];
    
    
    
    
    
}

- (void)openAppProcess
{
    self.button1.selected = YES;
    
    //    self.button1.userInteractionEnabled = NO;
    [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
    Story100ViewController *VCStory100 = [[Story100ViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"Story100ViewController"] bundle:nil];
    [[CoreData sharedCoreData].JNC OriginalPushViewController:VCStory100 animated:NO];
    [VCStory100 release];
    
    //notification time
    NSMutableDictionary *MDReport = [NSDictionary dictionaryWithContentsOfFile:PlistPathReport];
    if (![MDReport objectForKey:@"lastNotifyTime"]) {
        MDReport = [NSMutableDictionary new];
        NSDate *dateNow = [NSDate date];
        DEBUGMSG(@"Set current time to lastNotifyTime: %f", [dateNow timeIntervalSince1970]);
        [MDReport setObject:[NSString stringWithFormat:@"%f", [dateNow timeIntervalSince1970] + 0.0000001] forKey:@"lastNotifyTime"];
    }
    else {
        MDReport = [MDReport mutableCopy];
        NSTimeInterval TILastNotifyTime = [[MDReport objectForKey:@"lastNotifyTime"] doubleValue];
        NSDate *dateNow = [NSDate date];
        NSTimeInterval TIDiff = [dateNow timeIntervalSince1970] - TILastNotifyTime;
        DEBUGMSG(@"TIDiff: %f", TIDiff);
        if (TIDiff >= 60.0 * 60.0 * 24.0 * 30.0) {
            //generate report and save to photo album
            DEBUGMSG(@"more than 1 month: TIDiff: %f > %f", TIDiff, 60.0 * 60.0 * 24.0 * 30.0);
            NSMutableArray *MABookScore = [NSArray arrayWithContentsOfFile:PlistPathBookScore];
            if (MABookScore) {
                MABookScore = [MABookScore mutableCopy];
                
                NSMutableArray *MABookcase5 = [NSMutableArray new];
                NSArray *arrayBookID = [Bookcase5ID componentsSeparatedByString:@","];
                for (int x = MABookScore.count - 1; MABookScore && x >= 0; x--) {
                    for (int y = 0; arrayBookID && y < arrayBookID.count; y++) {
                        if ([[MABookScore objectAtIndex:x] objectForKey:@"avgScore"] && [[[MABookScore objectAtIndex:x] objectForKey:@"bookID"] isEqualToString:[arrayBookID objectAtIndex:y]]) {
                            [MABookcase5 addObject:[MABookScore objectAtIndex:x]];
                            [MABookScore removeObjectAtIndex:x];
                            break;
                        }
                    }
                }
                
                NSMutableArray *MABookcase4 = [NSMutableArray new];
                arrayBookID = [Bookcase4ID componentsSeparatedByString:@","];
                for (int x = MABookScore.count - 1; MABookScore && x >= 0; x--) {
                    for (int y = 0; arrayBookID && y < arrayBookID.count; y++) {
                        if ([[MABookScore objectAtIndex:x] objectForKey:@"avgScore"] && [[[MABookScore objectAtIndex:x] objectForKey:@"bookID"] isEqualToString:[arrayBookID objectAtIndex:y]]) {
                            [MABookcase4 addObject:[MABookScore objectAtIndex:x]];
                            [MABookScore removeObjectAtIndex:x];
                            break;
                        }
                    }
                }
                
                NSMutableArray *MABookcase3 = [NSMutableArray new];
                arrayBookID = [Bookcase3ID componentsSeparatedByString:@","];
                for (int x = MABookScore.count - 1; MABookScore && x >= 0; x--) {
                    for (int y = 0; arrayBookID && y < arrayBookID.count; y++) {
                        if ([[MABookScore objectAtIndex:x] objectForKey:@"avgScore"] && [[[MABookScore objectAtIndex:x] objectForKey:@"bookID"] isEqualToString:[arrayBookID objectAtIndex:y]]) {
                            [MABookcase3 addObject:[MABookScore objectAtIndex:x]];
                            [MABookScore removeObjectAtIndex:x];
                            break;
                        }
                    }
                }
                
                NSMutableArray *MABookcase2 = [NSMutableArray new];
                arrayBookID = [Bookcase2ID componentsSeparatedByString:@","];
                for (int x = MABookScore.count - 1; MABookScore && x >= 0; x--) {
                    for (int y = 0; arrayBookID && y < arrayBookID.count; y++) {
                        if ([[MABookScore objectAtIndex:x] objectForKey:@"avgScore"] && [[[MABookScore objectAtIndex:x] objectForKey:@"bookID"] isEqualToString:[arrayBookID objectAtIndex:y]]) {
                            [MABookcase2 addObject:[MABookScore objectAtIndex:x]];
                            [MABookScore removeObjectAtIndex:x];
                            break;
                        }
                    }
                }
                
                NSMutableArray *MABookcase1 = [NSMutableArray new];
                arrayBookID = [Bookcase1ID componentsSeparatedByString:@","];
                for (int x = MABookScore.count - 1; MABookScore && x >= 0; x--) {
                    for (int y = 0; arrayBookID && y < arrayBookID.count; y++) {
                        if ([[MABookScore objectAtIndex:x] objectForKey:@"avgScore"] && [[[MABookScore objectAtIndex:x] objectForKey:@"bookID"] isEqualToString:[arrayBookID objectAtIndex:y]]) {
                            [MABookcase1 addObject:[MABookScore objectAtIndex:x]];
                            [MABookScore removeObjectAtIndex:x];
                            break;
                        }
                    }
                }
                
                
                float fViewWidth = 0.0;
                NSArray *arrayBookcaseNum = [NSArray arrayWithObjects:[NSString stringWithFormat:@"%d", MABookcase1.count], [NSString stringWithFormat:@"%d", MABookcase2.count], [NSString stringWithFormat:@"%d", MABookcase3.count], [NSString stringWithFormat:@"%d", MABookcase4.count], [NSString stringWithFormat:@"%d", MABookcase5.count], nil];
                
                int iLongestBookcaseNumIndex = 0;
                for (int x = 1; arrayBookcaseNum && x < arrayBookcaseNum.count; x++) {
                    if ([[arrayBookcaseNum objectAtIndex:iLongestBookcaseNumIndex] intValue] < [[arrayBookcaseNum objectAtIndex:x] intValue]) {
                        iLongestBookcaseNumIndex = x;
                    }
                }
                
                fViewWidth = 91.0 * ([[arrayBookcaseNum objectAtIndex:iLongestBookcaseNumIndex] intValue]) + 48.0;
                if (fViewWidth < 48.0 + (91.0 * 3)) {
                    fViewWidth = 48.0 + (91.0 * 3);
                }
                float fViewHeight = self.viewDateBase.frame.size.height + (125.0 * 5);
                self.viewReportBase.frame = CGRectMake(0.0, 0.0, fViewWidth, fViewHeight);
                
                
                
                float fOffsetX = self.IVBookcaseCat1Base.frame.origin.x + self.IVBookcaseCat1Base.frame.size.width;
                int iBookcaseLongestNum = [[arrayBookcaseNum objectAtIndex:iLongestBookcaseNumIndex] intValue];
                for (int iRow = 0; iRow < 5; iRow++) {
                    float yOffsetY = 41.0 + (125.0 * iRow);
                    for (int x = 0; x < iBookcaseLongestNum; x++) {
                        if (x > 2) {
                            UIImageView *IVBookcaseBase = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"report_stand.png"]];
                            IVBookcaseBase.tag = AddSubViewTag;
                            [self.viewReportBase addSubview:IVBookcaseBase];
                            IVBookcaseBase.frame = CGRectMake(fOffsetX + (91.0 * x) , yOffsetY, 91.0, 125.0);
                            [IVBookcaseBase release];
                        }
                        
                        NSString *stringBookCoverImageName = nil;
                        NSString *stringViewTime = nil;
                        NSString *stringAvgScore = nil;
                        
                        if (iRow == 0 && x < MABookcase1.count) {
                            stringBookCoverImageName = [NSString stringWithFormat:@"story%d", [[[MABookcase1 objectAtIndex:x] objectForKey:@"bookID"] intValue]];
                            if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:@"t"]) {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
                            }
                            else {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"];
                            }
                            stringViewTime = [[MABookcase1 objectAtIndex:x] objectForKey:@"viewTime"];
                            stringAvgScore = [[MABookcase1 objectAtIndex:x] objectForKey:@"avgScore"];
                        }
                        else if (iRow == 1 && x < MABookcase2.count) {
                            stringBookCoverImageName = [NSString stringWithFormat:@"story%d", [[[MABookcase2 objectAtIndex:x] objectForKey:@"bookID"] intValue]];
                            if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:@"t"]) {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
                            }
                            else {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"];
                            }
                            stringViewTime = [[MABookcase2 objectAtIndex:x] objectForKey:@"viewTime"];
                            stringAvgScore = [[MABookcase2 objectAtIndex:x] objectForKey:@"avgScore"];
                        }
                        else if (iRow == 2 && x < MABookcase3.count) {
                            stringBookCoverImageName = [NSString stringWithFormat:@"story%d", [[[MABookcase3 objectAtIndex:x] objectForKey:@"bookID"] intValue]];
                            if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:@"t"]) {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
                            }
                            else {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"];
                            }
                            stringViewTime = [[MABookcase3 objectAtIndex:x] objectForKey:@"viewTime"];
                            stringAvgScore = [[MABookcase3 objectAtIndex:x] objectForKey:@"avgScore"];
                        }
                        else if (iRow == 3 && x < MABookcase4.count) {
                            stringBookCoverImageName = [NSString stringWithFormat:@"story%d", [[[MABookcase4 objectAtIndex:x] objectForKey:@"bookID"] intValue]];
                            if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:@"t"]) {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
                            }
                            else {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"];
                            }
                            stringViewTime = [[MABookcase4 objectAtIndex:x] objectForKey:@"viewTime"];
                            stringAvgScore = [[MABookcase4 objectAtIndex:x] objectForKey:@"avgScore"];
                        }
                        else if (iRow == 4 && x < MABookcase5.count) {
                            stringBookCoverImageName = [NSString stringWithFormat:@"story%d", [[[MABookcase5 objectAtIndex:x] objectForKey:@"bookID"] intValue]];
                            if ([[CoreData sharedCoreData].stringDeviceType isEqualToString:@"t"]) {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_t_ct.png"];
                            }
                            else {
                                stringBookCoverImageName = [stringBookCoverImageName stringByAppendingString:@"_c_s_sc.png"];
                            }
                            stringViewTime = [[MABookcase5 objectAtIndex:x] objectForKey:@"viewTime"];
                            stringAvgScore = [[MABookcase5 objectAtIndex:x] objectForKey:@"avgScore"];
                        }
                        if (stringBookCoverImageName) {
                            UIImageView *IVBook = [[UIImageView alloc] initWithImage:[UIImage imageNamed:stringBookCoverImageName]];
                            IVBook.tag = AddSubViewTag;
                            [self.viewReportBase addSubview:IVBook];
                            IVBook.frame = CGRectMake(fOffsetX + (91.0 * x) + 8.0, yOffsetY + 15.0, 74.0, 101.0);
                            [IVBook release];
                            
                            BookRatingViewController *VCBookRating = [[BookRatingViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookRatingViewController"] bundle:nil];
                            VCBookRating.view.tag = AddSubViewTag;
                            [self.viewReportBase addSubview:VCBookRating.view];
                            VCBookRating.view.frame = CGRectMake(fOffsetX + (91.0 * x) + 6.0, yOffsetY + 15.0 + 101.0 - 35.0, 78.0, 35.0);
                            VCBookRating.labelViewTimeValue.text = stringViewTime;
                            int iAvgScore = [stringAvgScore intValue];
                            if (iAvgScore >= 1) {
                                VCBookRating.IVStar1.hidden = NO;
                            }
                            if (iAvgScore >= 2) {
                                VCBookRating.IVStar2.hidden = NO;
                            }
                            if (iAvgScore >= 3) {
                                VCBookRating.IVStar3.hidden = NO;
                            }
                            if (iAvgScore >= 4) {
                                VCBookRating.IVStar4.hidden = NO;
                            }
                            if (iAvgScore == 5) {
                                VCBookRating.IVStar5.hidden = NO;
                            }
                            [VCBookRating release];
                        }
                    }
                }
                
                //
                
                NSDateFormatter *DF = [[NSDateFormatter alloc] init];
                [DF setDateFormat:@"dd"];
                self.labelDateDay.text = [DF stringFromDate:dateNow];
                [DF setDateFormat:@"MM"];
                self.labelDateMonth.text = [DF stringFromDate:dateNow];
                [DF setDateFormat:@"yyyy"];
                self.labelDateYear.text = [DF stringFromDate:dateNow];
                [DF release];
                
                self.viewDateBase.center = CGPointMake(self.viewReportBase.frame.size.width / 2.0, self.viewDateBase.center.y);
                UIImageWriteToSavedPhotosAlbum([[CoreData sharedCoreData] getImageByCombiningBaseView:self.viewReportBase], nil, nil, nil);
                [MDReport setObject:[NSString stringWithFormat:@"%f", [dateNow timeIntervalSince1970] + 0.0000001] forKey:@"lastNotifyTime"];
                DEBUGMSG(@"UIImageWriteToSavedPhotosAlbum");
                
                if ([[CoreData sharedCoreData].stringNotificationCenter isEqualToString:@"on"]) {
                    UIAlertView *AVSavedReport = [[UIAlertView alloc] initWithTitle:@"" message:LocalizedString(@"cm_save_report") delegate:nil cancelButtonTitle:LocalizedString(@"cm_ok") otherButtonTitles:nil];
                    [AVSavedReport show];
                    [AVSavedReport release];
                }
                
                [MABookcase5 release];
                [MABookcase4 release];
                [MABookcase3 release];
                [MABookcase2 release];
                [MABookcase1 release];
                
                [MABookScore release];
            }
        }
        else {
            DEBUGMSG(@"do not need to generate report");
        }
    }
    
    [MDReport writeToFile:PlistPathReport atomically:YES];
    
    [MDReport release];
    
}

#pragma mark - Handle Click Button Events

- (IBAction)clickButton:(UIButton *)button
{
    
    for (int x = 0; self.MAButton && x < self.MAButton.count; x++) {
        if ((UIButton *)[self.MAButton objectAtIndex:x] != button) {
            ((UIButton *)[self.MAButton objectAtIndex:x]).selected = NO;
            //((UIButton *)[self.MAButton objectAtIndex:x]).userInteractionEnabled = YES;
        }
    }
    button.selected = YES;
    //button.userInteractionEnabled = NO;
    
    if (button == self.button1) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        Story100ViewController *VCStory100 = [[Story100ViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"Story100ViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCStory100 animated:NO];
        [VCStory100 release];
    }
    else if (button == self.button2) {
        [self.button2 setTitleColor:[UIColor clearColor] forState:UIControlStateHighlighted];

        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        CustomStoryViewController *VCCustomStory = [[CustomStoryViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"CustomStoryViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCCustomStory animated:NO];
        [VCCustomStory release];
    }
    else if (button == self.button3) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        StudentProfileViewController *VCStudentProfile= [[StudentProfileViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"StudentProfileViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCStudentProfile animated:NO];
        [VCStudentProfile release];
    }
    else if (button == self.button4) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        BookmarkViewController *VCBookmark = [[BookmarkViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"BookmarkViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCBookmark animated:NO];
        [VCBookmark release];
    }
    else if (button == self.button5) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        AboutSAHKViewController *VCAboutSAHK = [[AboutSAHKViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"AboutSAHKViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCAboutSAHK animated:NO];
        [VCAboutSAHK release];
    }
    else if (button == self.button6) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        SocialStoryNoticeViewController *VCSocialStoryNotice = [[SocialStoryNoticeViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"SocialStoryNoticeViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCSocialStoryNotice animated:NO];
        [VCSocialStoryNotice release];
    }
    else if (button == self.button7) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        SocialStoryRecordFormViewController *VCSocialStoryRecordForm = [[SocialStoryRecordFormViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"SocialStoryRecordFormViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCSocialStoryRecordForm animated:NO];
        [VCSocialStoryRecordForm release];
    }
    else if (button == self.button8) {
        [[CoreData sharedCoreData].VCSideMenuContainer closeMenu];
        [[CoreData sharedCoreData].JNC OriginalPopToRootViewControllerAnimated:NO];
        SettingsViewController *VCSettings = [[SettingsViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"SettingsViewController"] bundle:nil];
        [[CoreData sharedCoreData].JNC OriginalPushViewController:VCSettings animated:NO];
        [VCSettings release];
    }
}

- (void)viewDidUnload {
    [aboutUs release];
    aboutUs = nil;
    [aboutUs_ipad release];
    aboutUs_ipad = nil;
    [super viewDidUnload];
}
@end
