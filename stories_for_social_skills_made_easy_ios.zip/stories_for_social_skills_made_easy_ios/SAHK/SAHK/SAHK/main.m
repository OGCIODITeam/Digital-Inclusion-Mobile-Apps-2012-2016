//
//  main.m
//  SAHK
//
//  Created by Jeff Cheung on 13年9月24日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SAHKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SAHKAppDelegate class]));
    }
}
