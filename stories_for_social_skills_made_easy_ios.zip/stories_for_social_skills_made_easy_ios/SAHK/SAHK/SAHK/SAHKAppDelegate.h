//
//  SAHKAppDelegate.h
//  SAHK
//
//  Created by Jeff Cheung on 13年8月12日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SAHKAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, retain) UIWindow *window;

#pragma mark - Core

- (void)setupDefaultSettings;

@end
