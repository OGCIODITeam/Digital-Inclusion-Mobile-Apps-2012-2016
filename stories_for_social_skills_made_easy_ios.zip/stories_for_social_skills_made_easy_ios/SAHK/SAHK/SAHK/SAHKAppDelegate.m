//
//  SAHKAppDelegate.m
//  SAHK
//
//  Created by Jeff Cheung on 13年8月12日.
//  Copyright (c) 2013年 Jeff Cheung. All rights reserved.
//

#import "SAHKAppDelegate.h"
#import "MFSideMenu.h"
#import "RootViewController.h"
#import "LeftRootViewController.h"

@implementation SAHKAppDelegate

@synthesize window = _window;

- (void)dealloc
{
    self.window.rootViewController = nil;
    self.window = nil;
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
//    NSString *wline = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"sc" ofType:@"txt"] encoding:NSUTF8StringEncoding error:nil];
//    NSArray *wlines_info = [wline componentsSeparatedByString:@"\r"];
//    NSLog(@"%d", [wlines_info count]);
//    NSMutableDictionary *conlines = [NSMutableDictionary new];
//    for (int i=0; i<[wlines_info count]; i++) {
//        NSArray *info = [wlines_info[i] componentsSeparatedByString:@"	"];
//        if ([info count]==2) {
//            [conlines setObject:info[1] forKey:info[0]];
//        }
//    }
//    NSString* path = [[NSSearchPathForDirectoriesInDomains(
//                                                           NSLibraryDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingString:@"/story_filename_s.plist"];
//    [conlines writeToFile:path atomically:YES];
    
    DEBUGMSG(@"vendor ID: %@", [CoreData sharedCoreData].stringDeviceID);
    DEBUGMSG(@"reversed vendor ID: %@", [CoreData sharedCoreData].stringCharacteristicUUID);
    [[CoreData sharedCoreData] checkAndSaveDeviceType];
    [self setupDefaultSettings];
    [[CoreData sharedCoreData] clearAllFileInFolder:PathEditFolder];
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    RootViewController *VCRoot = [[RootViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"RootViewController"] bundle:nil];
    JNavigationController *JNC = [[JNavigationController alloc] initWithRootViewController:VCRoot];
    [JNC setNavigationBarHidden:YES];
    [VCRoot release];
    
    LeftRootViewController *VCLeftRoot = [[LeftRootViewController alloc] initWithNibName:[[CoreData sharedCoreData] getXibNameBasedOnDeviceType:@"LeftRootViewController"] bundle:nil];
    self.window.rootViewController = [CoreData sharedCoreData].VCSideMenuContainer = [MFSideMenuContainerViewController containerWithCenterViewController:JNC leftMenuViewController:VCLeftRoot rightMenuViewController:nil];
    [CoreData sharedCoreData].VCLeftRoot = VCLeftRoot;
    [CoreData sharedCoreData].JNC = JNC;
    
    [JNC release];
    [VCLeftRoot release];
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    DEBUGMSG(@"handleOpenURL: %@", url);
    //govsahk://34,35,36,37
    
    NSArray *arrayReadingList = [[url.absoluteString stringByReplacingOccurrencesOfString:@"govsahk://" withString:@""] componentsSeparatedByString:@","];
    
    if (!arrayReadingList || arrayReadingList.count == 0) {
        return YES;
    }
    
    NSMutableDictionary *MDStudentProfile = [NSDictionary dictionaryWithContentsOfFile:PlistPathStudentProfile];
    if (MDStudentProfile) {
        MDStudentProfile = [MDStudentProfile mutableCopy];
        
        NSMutableArray *MAStudentProfileList = [MDStudentProfile objectForKey:@"studentProfileList"];
        
        for (int x = 0; MAStudentProfileList && x < MAStudentProfileList.count; x++) {
            NSMutableArray *MAReadingListList = [[MAStudentProfileList objectAtIndex:x] objectForKey:@"readingListList"];
            if (MAReadingListList) {
                [MAReadingListList addObject:arrayReadingList];
            }
            else {
                MAReadingListList = [NSMutableArray new];
                [MAReadingListList addObject:arrayReadingList];
                [[MAStudentProfileList objectAtIndex:x] setObject:MAReadingListList forKey:@"readingListList"];
                [MAReadingListList release];
            }
        }
        
        [MDStudentProfile writeToFile:PlistPathStudentProfile atomically:YES];
        
        [MDStudentProfile release];
    }
    
    
    return YES;
}

#pragma mark - Core

- (void)setupDefaultSettings
{
	NSUserDefaults *UD = [NSUserDefaults standardUserDefaults];
	if (![UD objectForKey:@"language"]) {
		NSArray *arrayAppleLanguages = [UD objectForKey:@"AppleLanguages"];
		if (!arrayAppleLanguages || arrayAppleLanguages.count == 0)
			return;
		
		NSString *stringSystemLanguage = [arrayAppleLanguages objectAtIndex:0];
		if (!stringSystemLanguage)
			return;
		
        if ([stringSystemLanguage isEqualToString:@"zh-Hant"]) {
			[UD setObject:@"t" forKey:@"language"];
            [UD setObject:@"c" forKey:@"voice"];
		}
		else if ([stringSystemLanguage isEqualToString:@"zh-Hans"]) {
			[UD setObject:@"s" forKey:@"language"];
            [UD setObject:@"m" forKey:@"voice"];
		}
        else {
            [UD setObject:@"t" forKey:@"language"];
            [UD setObject:@"c" forKey:@"voice"];
        }
        [UD setObject:@"on" forKey:@"notificationCenter"];
		[UD synchronize];
	}
	[CoreData sharedCoreData].stringLanguage = [UD objectForKey:@"language"];
    [CoreData sharedCoreData].stringVoice = [UD objectForKey:@"voice"];
    [CoreData sharedCoreData].stringNotificationCenter = [UD objectForKey:@"notificationCenter"];
}

@end
