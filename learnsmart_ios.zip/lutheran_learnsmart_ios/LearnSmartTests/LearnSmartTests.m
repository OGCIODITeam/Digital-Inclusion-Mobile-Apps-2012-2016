//
//  LearnSmartTests.m
//  LearnSmartTests
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "LearnSmartTests.h"

@implementation LearnSmartTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in LearnSmartTests");
}

@end
