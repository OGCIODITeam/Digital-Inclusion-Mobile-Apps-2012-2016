//
//  AppDelegate.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BWQuincyManager.h"

@class MainViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, BWQuincyManagerDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainViewController *viewController;

@end
