//
//  Rank.m
//  LearnSmart
//
//  Created by Jack Cheung on 2/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "Rank.h"

@implementation Rank

@synthesize rank, score;

- (id)init {
	self = [super init];
	if (self) {
		rank = 1;
		score = 0;
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	if (self) {
		rank = [[JSON valueForKeyPath:@"rank"] integerValue];
		score = [[JSON valueForKeyPath:@"score"] doubleValue];
	}
	return self;
}

- (id)initWithRank:(NSInteger)_rank score:(double)_score {
	self = [self init];
	if (self) {
		rank = _rank;
		score = _score;
	}
	return self;
}

@end
