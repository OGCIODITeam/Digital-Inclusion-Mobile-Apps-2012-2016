//
//  Training.h
//  LearnSmart
//
//  Created by Jack Cheung on 2/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Training : NSObject

@property (nonatomic, assign) NSInteger trainingId;
@property (nonatomic, strong) NSString * thumbnail;
@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * description;
@property (nonatomic, assign) NSInteger priority;
@property (nonatomic, strong) NSDate * lastUpdated;

- (id)initWithJSON:(id)JSON;
- (BOOL)isEqualToTraining:(Training *)training;

@end
