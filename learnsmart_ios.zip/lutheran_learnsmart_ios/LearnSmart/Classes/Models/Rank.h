//
//  Rank.h
//  LearnSmart
//
//  Created by Jack Cheung on 2/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Rank : NSObject

@property (nonatomic, assign) NSInteger rank;
@property (nonatomic, assign) double score;

- (id)initWithJSON:(id)JSON;
- (id)initWithRank:(NSInteger)rank score:(double)score;

@end
