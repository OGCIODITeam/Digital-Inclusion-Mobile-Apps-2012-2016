//
//  LoginToken.h
//  LearnSmart
//
//  Created by Jack Cheung on 2/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginToken : NSObject<NSCoding>

@property (nonatomic, strong) NSString * username;
@property (nonatomic, strong) NSString * authToken;
@property (nonatomic, assign) BOOL isTrainer;
@property (nonatomic, strong) NSDate * tokenExpiryDate;

- (id)initWithJSON:(id)JSON;

@end
