//
//  TrainingCategoryScore.m
//  LearnSmart
//
//  Created by Jack Cheung on 25/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingCategoryScore.h"

@implementation TrainingCategoryScore

@synthesize title, score;

- (id)init {
	self = [super init];
	if (self) {
		title = @"";
		score = 0;
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	
	if (self) {
		title = [JSON valueForKeyPath:@"title"];
		score = [[JSON valueForKeyPath:@"score"] doubleValue];
	}
	return self;
}

@end
