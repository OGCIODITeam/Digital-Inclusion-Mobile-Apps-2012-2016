//
//  TrainingProfile.h
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrainingProfile : NSObject<NSCopying>

@property (nonatomic, strong) NSString * organization;
@property (nonatomic, strong) NSString * fullName;
@property (nonatomic, strong) NSString * email;
@property (nonatomic, strong) NSString * role;
@property (nonatomic, strong) NSString * profilePhoto;
@property (nonatomic, strong) NSDate * lastFetched;
@property (nonatomic, strong) NSDate * lastUpdated;

- (id)initWithJSON:(id)JSON;
- (BOOL)isProfilePhotoDefined;
- (void)updateLastFetched;

@end
