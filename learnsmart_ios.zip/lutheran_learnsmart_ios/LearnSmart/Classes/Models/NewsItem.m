//
//  NewsItem.m
//  LearnSmart
//
//  Created by Jack Cheung on 1/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "NewsItem.h"

@implementation NewsItem

@synthesize title, description, priority, lastUpdated;

- (id)init {
	self = [super init];
	if (self) {
		title = @"";
		description = @"";
		priority = 100;
		lastUpdated = nil;
	}
	return self;
}

@end
