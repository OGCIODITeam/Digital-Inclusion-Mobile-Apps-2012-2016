//
//  TrainingHistory.h
//  LearnSmart
//
//  Created by Jack Cheung on 30/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrainingHistory : NSObject

@property (nonatomic, strong) NSString * comment;
@property (nonatomic, assign) double averageScore;
@property (nonatomic, strong) NSDate * lastUpdated;

- (id)initWithJSON:(id)JSON;

@end
