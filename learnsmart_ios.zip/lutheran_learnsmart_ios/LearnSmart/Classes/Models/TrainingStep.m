//
//  TrainingStep.m
//  LearnSmart
//
//  Created by Jack Cheung on 11/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingStep.h"

@implementation TrainingStep

@synthesize stepId, stepType, picture, text, sound, url, step, rating, lastUpdated;

- (id)init {
	self = [super init];
	if (self) {
		stepId = 0;
		stepType = @"p";
		picture = @"";
		text = @"";
		sound = @"";
		url = @"";
		step = 0;
		lastUpdated = [NSDate distantPast];
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	
	if (self) {
		NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
		[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
		
		stepId = [[JSON valueForKeyPath:@"id"] integerValue];
		stepType = [JSON valueForKeyPath:@"stepType"];
		picture = [JSON valueForKeyPath:@"picture"];
		text = [JSON valueForKeyPath:@"text"];
		sound = [JSON valueForKeyPath:@"sound"];
		url = [JSON valueForKeyPath:@"url"];
		step = [[JSON valueForKeyPath:@"step"] integerValue];
		lastUpdated = [dateFormatter dateFromString:[JSON valueForKeyPath:@"lastUpdated"]];
	}
	return self;
}

@end