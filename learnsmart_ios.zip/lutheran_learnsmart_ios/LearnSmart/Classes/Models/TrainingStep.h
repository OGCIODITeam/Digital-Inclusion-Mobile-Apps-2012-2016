//
//  TrainingStep.h
//  LearnSmart
//
//  Created by Jack Cheung on 11/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrainingStep : NSObject

@property (nonatomic, assign) NSInteger stepId;
@property (nonatomic, strong) NSString * stepType;
@property (nonatomic, strong) NSString * picture;
@property (nonatomic, strong) NSString * text;
@property (nonatomic, strong) NSString * sound;
@property (nonatomic, strong) NSString * url;
@property (nonatomic, assign) NSUInteger step;
@property (nonatomic, assign) NSUInteger rating;
@property (nonatomic, strong) NSDate * lastUpdated;

- (id)initWithJSON:(id)JSON;

@end
