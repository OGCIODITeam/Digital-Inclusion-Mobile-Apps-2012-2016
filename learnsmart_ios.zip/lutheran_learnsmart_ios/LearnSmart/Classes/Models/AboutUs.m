//
//  AboutUs.m
//  LearnSmart
//
//  Created by Jack Cheung on 1/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "AboutUs.h"

@implementation AboutUs

@synthesize aboutUsText, newsItems;

- (id)init {
	self = [super init];
	if (self) {
		aboutUsText = @"";
		newsItems = [NSMutableArray new];
	}
	return self;
}

@end
