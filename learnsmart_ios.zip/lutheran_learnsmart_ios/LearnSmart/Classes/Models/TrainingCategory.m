//
//  TrainingCategory.m
//  LearnSmart
//
//  Created by Jack Cheung on 2/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingCategory.h"

@implementation TrainingCategory

@synthesize catId, title, priority, lastUpdated;

- (id)init {
	self = [super init];
	if (self) {
		catId = 0;
		title = @"";
		priority = 100;
		lastUpdated = [NSDate distantPast];
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	
	NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	
	catId = [[JSON valueForKeyPath:@"id"] unsignedIntegerValue];
	title = [JSON valueForKeyPath:@"title"];
	priority = [[JSON valueForKeyPath:@"priority"] integerValue];
	lastUpdated = [dateFormatter dateFromString:[JSON valueForKeyPath:@"lastUpdated"]];

	
	return self;
}

@end
