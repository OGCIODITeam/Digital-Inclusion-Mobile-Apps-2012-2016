//
//  TrainingHistory.m
//  LearnSmart
//
//  Created by Jack Cheung on 30/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingHistory.h"

@implementation TrainingHistory

@synthesize  comment, averageScore, lastUpdated;

- (id)init {
	self = [super init];
	if (self) {
		comment = @"";
		averageScore = 0;
		lastUpdated = [NSDate distantPast];
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	if (self) {
		NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
		[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
		
		comment = [JSON valueForKeyPath:@"comment"];
		averageScore = [[JSON valueForKeyPath:@"averageScore"] doubleValue];
		lastUpdated = [dateFormatter dateFromString:[JSON valueForKeyPath:@"lastUpdated"]];
	}
	return self;
}

@end
