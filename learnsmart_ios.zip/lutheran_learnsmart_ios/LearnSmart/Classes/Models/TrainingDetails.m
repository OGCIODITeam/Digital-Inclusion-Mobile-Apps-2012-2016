//
//  TrainingDetails.m
//  LearnSmart
//
//  Created by Jack Cheung on 2/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingDetails.h"

@implementation TrainingDetails

@synthesize title, category, background, traineeName, tutorName, longTermTarget, shortTermTarget, startDate, endDate;

- (id)init {
	self = [super init];
	if (self) {
		title = @"";
		category = @"";
		background = @"";
		traineeName = @"";
		tutorName = @"";
		longTermTarget = @"";
		shortTermTarget = @"";
		startDate = @"";
		endDate = @"";
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	if (self) {
		title = [JSON valueForKeyPath:@"title"];
		category = [JSON valueForKeyPath:@"category"];
		background = [JSON valueForKeyPath:@"background"];
		traineeName = [JSON valueForKeyPath:@"traineeName"];
		tutorName = [JSON valueForKeyPath:@"tutorName"];
		longTermTarget = [JSON valueForKeyPath:@"longTermTarget"];
		shortTermTarget = [JSON valueForKeyPath:@"shortTermTarget"];
		startDate = [JSON valueForKeyPath:@"startDate"];
		endDate = [JSON valueForKeyPath:@"endDate"];
	}
	return self;
}

@end
