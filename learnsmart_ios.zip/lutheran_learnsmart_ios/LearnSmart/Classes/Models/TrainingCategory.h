//
//  TrainingCategory.h
//  LearnSmart
//
//  Created by Jack Cheung on 2/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrainingCategory : NSObject

@property (nonatomic, readwrite) NSUInteger catId;
@property (nonatomic, strong) NSString * title;
@property (nonatomic, readwrite) NSInteger priority;
@property (nonatomic, readwrite) NSDate * lastUpdated;

- (id)initWithJSON:(id)JSON;

@end
