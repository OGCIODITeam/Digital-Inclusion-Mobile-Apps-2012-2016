//
//  TrainingCategoryScore.h
//  LearnSmart
//
//  Created by Jack Cheung on 25/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrainingCategoryScore : NSObject

@property (nonatomic, strong) NSString * title;
@property (nonatomic, assign) double score;

- (id)initWithJSON:(id)JSON;

@end
