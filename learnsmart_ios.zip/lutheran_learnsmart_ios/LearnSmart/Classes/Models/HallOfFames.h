//
//  HallOfFames.h
//  LearnSmart
//
//  Created by Jack Cheung on 2/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Rank;

@interface HallOfFames : NSObject

@property (nonatomic, strong) Rank * userRank;
@property (nonatomic, strong) NSMutableArray * hallOfFames;

- (id)initWithJSON:(id)JSON;

@end
