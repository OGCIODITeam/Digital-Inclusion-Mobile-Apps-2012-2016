//
//  HallOfFames.m
//  LearnSmart
//
//  Created by Jack Cheung on 2/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "HallOfFames.h"
#import "Rank.h"

@implementation HallOfFames

@synthesize userRank, hallOfFames;

- (id)init {
	self = [super init];
	if (self) {
		userRank = [Rank new];
		hallOfFames = [NSMutableArray array];
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	if (self) {		
		for (id hofEntry in JSON) {
			BOOL isMe = [[hofEntry valueForKeyPath:@"me"] boolValue];
			Rank * rank = [Rank new];
			
			rank.rank = [[hofEntry valueForKeyPath:@"rank"] integerValue];
			rank.score = [[hofEntry valueForKeyPath:@"score"] doubleValue];
			
			if (isMe) {
				userRank = rank;
			} else {
				[hallOfFames addObject:rank];
			}
		}
	}
	return self;
}

@end
