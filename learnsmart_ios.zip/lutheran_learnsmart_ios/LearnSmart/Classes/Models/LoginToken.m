//
//  LoginToken.m
//  LearnSmart
//
//  Created by Jack Cheung on 2/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//
#define IS_DEBUG_MODE NO
#import "LoginToken.h"

@implementation LoginToken

@synthesize username, authToken, isTrainer, tokenExpiryDate;

- (id)init {
	self = [super init];
	if (self) {
		username = @"";
		authToken = @"";
		if (IS_DEBUG_MODE) {
			isTrainer = YES;
		} else {
			isTrainer = NO;
		}
		tokenExpiryDate = [NSDate distantPast];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super init];
	if (self) {
		username = [aDecoder decodeObjectForKey:@"username"];
		authToken = [aDecoder decodeObjectForKey:@"authToken"];
		if (IS_DEBUG_MODE) {
			isTrainer = YES;
		} else {
			isTrainer = [aDecoder decodeBoolForKey:@"isTrainer"];
		}
		tokenExpiryDate = [aDecoder decodeObjectForKey:@"tokenExpiryDate"];
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	
	authToken = [JSON valueForKeyPath:@"result.token"];
	if (IS_DEBUG_MODE) {
		isTrainer = YES;
	} else {
		isTrainer = [[JSON valueForKeyPath:@"result.isTrainer"] boolValue];
	}
	tokenExpiryDate = [JSON valueForKeyPath:@"result.tokenExpiryDate"];
	
	return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder {
	[aCoder encodeObject:username forKey:@"username"];
	[aCoder encodeObject:authToken forKey:@"authToken"];
	[aCoder encodeBool:isTrainer forKey:@"isTrainer"];
	[aCoder encodeObject:tokenExpiryDate forKey:@"tokenExpiryDate"];
}

@end
