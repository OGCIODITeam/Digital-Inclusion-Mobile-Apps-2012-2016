//
//  TrainingDetails.h
//  LearnSmart
//
//  Created by Jack Cheung on 2/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrainingDetails : NSObject

@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * category;
@property (nonatomic, strong) NSString * background;
@property (nonatomic, strong) NSString * traineeName;
@property (nonatomic, strong) NSString * tutorName;
@property (nonatomic, strong) NSString * longTermTarget;
@property (nonatomic, strong) NSString * shortTermTarget;
@property (nonatomic, strong) NSString * startDate;
@property (nonatomic, strong) NSString * endDate;

- (id)initWithJSON:(id)JSON;

@end
