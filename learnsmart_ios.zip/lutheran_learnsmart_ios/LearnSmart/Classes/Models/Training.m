//
//  Training.m
//  LearnSmart
//
//  Created by Jack Cheung on 2/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "Training.h"

@implementation Training

@synthesize trainingId, thumbnail, title, description, priority, lastUpdated;

- (id)init {
	self = [super init];
	if (self) {
		
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSLog(@"! Training: JSON content:\n%@", [JSON description]);
	
	trainingId = [[JSON valueForKeyPath:@"id"] integerValue];
	thumbnail = [JSON valueForKeyPath:@"thumbnail"];
	title = [JSON valueForKeyPath:@"title"];
	description = [JSON valueForKeyPath:@"description"];
	priority = [[JSON valueForKeyPath:@"priority"] integerValue];
	lastUpdated = [dateFormatter dateFromString:[JSON valueForKeyPath:@"lastUpdated"]];
	
	return self;
}

- (BOOL)isEqualToTraining:(Training *)training {
	return trainingId == training.trainingId && [lastUpdated isEqualToDate:training.lastUpdated];
}

@end
