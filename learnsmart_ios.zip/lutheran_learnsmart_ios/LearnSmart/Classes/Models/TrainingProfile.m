//
//  TrainingProfile.m
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingProfile.h"

@implementation TrainingProfile

@synthesize organization, fullName, email, role, profilePhoto, lastFetched, lastUpdated;

- (id)init {
	self = [super init];
	if (self) {
		organization = @"";
		fullName = @"";
		email = @"";
		role = @"";
		profilePhoto = @"";
		lastFetched = [NSDate distantPast];
		lastUpdated = [NSDate distantPast];
	}
	return self;
}

- (id)initWithJSON:(id)JSON {
	self = [self init];
	
	NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	
	organization = [JSON valueForKeyPath:@"result.organization"];
	fullName = [JSON valueForKeyPath:@"result.fullName"];
	email = [JSON valueForKeyPath:@"result.email"];
	role = [JSON valueForKeyPath:@"result.role"];
	profilePhoto = [JSON valueForKeyPath:@"result.profilePhoto"];
	lastUpdated = [dateFormatter dateFromString:[JSON valueForKeyPath:@"result.lastUpdated"]];
	
	[self updateLastFetched];
	
	return self;
}

- (id)copyWithZone:(NSZone *)zone {
	TrainingProfile * newProfile = [[TrainingProfile alloc] init];
	
	newProfile.organization = [organization copyWithZone:zone];
	newProfile.fullName = [fullName copyWithZone:zone];
	newProfile.email = [email copyWithZone:zone];
	newProfile.role = [role copyWithZone:zone];
	newProfile.profilePhoto = [profilePhoto copyWithZone:zone];
	newProfile.lastFetched = [lastFetched copyWithZone:zone];
	newProfile.lastUpdated = [lastUpdated copyWithZone:zone];
	
	return newProfile;
}

- (BOOL)isProfilePhotoDefined {
	return !(profilePhoto == nil || [profilePhoto isEqualToString:@""] || [profilePhoto hasSuffix:@"/"]);
}

- (void)updateLastFetched {
	lastFetched = [NSDate new];
}

@end
