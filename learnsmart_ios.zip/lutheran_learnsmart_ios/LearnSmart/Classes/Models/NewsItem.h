//
//  NewsItem.h
//  LearnSmart
//
//  Created by Jack Cheung on 1/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsItem : NSObject

@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * description;
@property (nonatomic, assign) int priority;
@property (nonatomic, strong) NSDate * lastUpdated;

@end
