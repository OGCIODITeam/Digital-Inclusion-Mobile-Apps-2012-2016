//
//  WebServiceClient.m
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WebServiceClient.h"
#import "AppConfig.h"
#import <AFNetworking/AFHTTPClient.h>
#import <AFNetworking/AFJSONRequestOperation.h>
#import "CocoaLumberjackConfig.h"
#import "AboutUs.h"
#import "HallOfFames.h"
#import "LoginToken.h"
#import "NewsItem.h"
#import "TrainingCategory.h"
#import "TrainingCategoryScore.h"
#import "TrainingDetails.h"
#import "Training.h"
#import "TrainingStep.h"
#import "TrainingProfile.h"
#import "TrainingHistory.h"

static WebServiceClient * wsClient = nil;

@interface NSString(TrainingStep)

+ (NSString *)stringFromTrainingStepRatings:(NSArray *)trainingSteps;

@end;

@interface WebServiceClient()

- (NSString *)getWSResponseStatusWithJSON:(id)JSON;

@end

@implementation NSString(TrainingStep)

+ (NSString *)stringFromTrainingStepRatings:(NSArray *)trainingSteps {
	NSMutableArray * stepStrings = [NSMutableArray new];
	for (TrainingStep * step in trainingSteps) {
		[stepStrings addObject:[NSString stringWithFormat:@"%d",step.rating]];
	}
	return [stepStrings componentsJoinedByString:@";"];
}

@end

@implementation WebServiceClient

-(id)init {
	self = [super init];
	if (self) {
		appConfig = [AppConfig getInstance];
	}
	return self;
}

+ (id)getInstance {
	@synchronized(self) {
		if (wsClient == nil) {
			wsClient = [WebServiceClient new];
		}
	}
	return wsClient;
}

#pragma internal methods

/**
 * retrieve the "status" node from the response json
 **/
- (NSString *)getWSResponseStatusWithJSON:(id)JSON {
	NSString * wsResult = [JSON valueForKeyPath:@"status"];
	return [wsResult stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

#pragma public methods implementation

- (void)getAboutUsWithSuccess:(void (^)(AboutUs *))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"%@aboutus.json", appConfig.wsUrlPrefix]];
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			AboutUs * aboutUs = [AboutUs new];
			NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
			[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
			
			aboutUs.aboutUsText = [[JSON valueForKeyPath:@"result.aboutUs"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			NSArray * newsJSONArray = [JSON valueForKeyPath:@"result.news"];
			for (id newsJSON in newsJSONArray) {
				NewsItem * newsItem = [NewsItem new];
				
				newsItem.title = [newsJSON valueForKeyPath:@"title"];
				newsItem.description = [newsJSON valueForKeyPath:@"description"];
				newsItem.priority = [[newsJSON valueForKeyPath:@"priority"] integerValue];
				newsItem.lastUpdated = [dateFormatter dateFromString:[newsJSON valueForKeyPath:@"lastUpdated"]];
				
				[aboutUs.newsItems addObject:newsItem];
			}
			
			success(aboutUs);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve about us info; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve about us info; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getHOFWithLoginToken:(LoginToken *)loginToken success:(void (^)(HallOfFames * hof))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:
							 loginToken.username, @"username",
							 loginToken.authToken, @"token",
							 nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"GET" path:@"hallOfFames.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		DDLogInfo(@"! hof response: %@", [JSON description]);
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSArray * hallOfFamesJSON = [JSON valueForKeyPath:@"result.hallOfFames"];
			HallOfFames * hallOfFames = [[HallOfFames alloc] initWithJSON:hallOfFamesJSON];
			
			success(hallOfFames);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve hall of fames; username=%@; result=%@; errorCode=%d; error=%@", loginToken.username, wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve hall of fames; username=%@; error=%@", loginToken.username, errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingCategoriesWithSuccess:(void (^)(NSMutableArray *))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/trainingCats.json", appConfig.wsUrlPrefix]];
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSMutableArray * trainingCats = [NSMutableArray new];
			NSArray * trainingCatsJSONArray = [JSON valueForKeyPath:@"result.cats"];
			
			for (id trainingCatJSON in trainingCatsJSONArray) {
				TrainingCategory * trainingCat = [[TrainingCategory alloc] initWithJSON:trainingCatJSON];
				[trainingCats addObject:trainingCat];
			}
			
			success(trainingCats);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve training categories; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve about us info; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingDetailsWithLoginToken:(LoginToken *)loginToken trainingId:(NSInteger)trainingId success:(void (^)(TrainingDetails * details))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:
							 loginToken.username, @"username",
							 loginToken.authToken, @"token",
							 [NSString stringWithFormat:@"%d", trainingId], @"tid",
							 nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"GET" path:@"trainingDetails.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSArray * trainingDetailsJSON = [JSON valueForKeyPath:@"result.training"];
			TrainingDetails * trainingDetails = [[TrainingDetails alloc] initWithJSON:trainingDetailsJSON];
			
			success(trainingDetails);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve training details; username=%@; trainingId=%d; result=%@; errorCode=%d; error=%@", loginToken.username, trainingId, wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve training details; username=%@; trainingId=%d; error=%@", loginToken.username, trainingId, errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingHistoryWithLoginToken:(LoginToken *)loginToken trainingId:(NSInteger)trainingId success:(void (^)(NSMutableArray * trainingSessions))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:
							 loginToken.username, @"username",
							 loginToken.authToken, @"token",
							 [NSString stringWithFormat:@"%d", trainingId], @"tid",
							 nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"GET" path:@"pastTrainingSessions.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSMutableArray * histories = [NSMutableArray array];
			NSArray * trainingSessionsJSONArray = [JSON valueForKeyPath:@"result.trainingSessions"];
			
			for (id trainingSessionJSON in trainingSessionsJSONArray) {
				TrainingHistory * trainingHistory = [[TrainingHistory alloc] initWithJSON:trainingSessionJSON];
				[histories addObject:trainingHistory];
			}
			
			success(histories);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve training history; username=%@; trainingId=%d; result=%@; errorCode=%d; error=%@", loginToken.username, trainingId, wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve training history; username=%@; trainingId=%d; error=%@", loginToken.username, trainingId, errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingProfileScoreWithLoginToken:(LoginToken *)loginToken success:(void (^)(NSMutableArray * scores))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:loginToken.username, @"username", loginToken.authToken, @"token", nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"GET" path:@"categoryScores.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSMutableArray * scores = [NSMutableArray array];
			NSArray * scoresJSONArray = [JSON valueForKeyPath:@"result.scores"];
			
			for (id scoreJSON in scoresJSONArray) {
				TrainingCategoryScore * score = [[TrainingCategoryScore alloc] initWithJSON:scoreJSON];
				[scores addObject:score];
			}
			
			success(scores);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve training profile scores; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve training profile scores; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingProfileWithLoginToken:(LoginToken *)loginToken success:(void (^)(TrainingProfile *))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:loginToken.username, @"username", loginToken.authToken, @"token", nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"GET" path:@"mobileUserProfile.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			TrainingProfile * profile = [[TrainingProfile alloc] initWithJSON:JSON];
			success(profile);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve training profile; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve training profile; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingsWithCategoryId:(NSUInteger)catId success:(void (^)(NSMutableArray *))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"%@trainings/%d.json", appConfig.wsUrlPrefix, catId]];
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSMutableArray * trainings = [NSMutableArray new];
			NSArray * trainingJSONArray = [JSON valueForKeyPath:@"result.trainings"];
			
			for (id trainingJSON in trainingJSONArray) {
				Training * training = [[Training alloc] initWithJSON:trainingJSON];
				[trainings addObject:training];
			}
			
			success(trainings);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve trainings by catId=%d; result=%@; errorCode=%d; reason=%@", catId, wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve trainings by catId; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingsWithLoginToken:(LoginToken *)loginToken success:(void (^)(NSMutableArray * trainings))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:loginToken.username, @"username", loginToken.authToken, @"token", nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"GET" path:@"trainings.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSMutableArray * trainings = [NSMutableArray new];
			NSArray * trainingJSONArray = [JSON valueForKeyPath:@"result.trainings"];
			
			for (id trainingJSON in trainingJSONArray) {
				Training * training = [[Training alloc] initWithJSON:trainingJSON];
				[trainings addObject:training];
			}
			
			success(trainings);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve trainings by loginToken; username=%@; result=%@; errorCode=%d; reason=%@", loginToken.username, wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve trainings by loginToken; username=%@; error=%@", loginToken.username, errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)getTrainingStepsWithTrainingId:(NSUInteger)trainingId success:(void (^)(NSMutableArray * trainingSteps))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure {
	NSURL * url = [NSURL URLWithString:[NSString stringWithFormat:@"%@trainingSteps/%d.json", appConfig.wsUrlPrefix, trainingId]];
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			NSMutableArray * trainingSteps = [NSMutableArray new];
			NSArray * trainingStepsJSONArray = [JSON valueForKeyPath:@"result.trainingSteps"];
			
			for (id trainingStepJSON in trainingStepsJSONArray) {
				TrainingStep * step = [[TrainingStep alloc] initWithJSON:trainingStepJSON];
				[trainingSteps addObject:step];
			}
			
			success(trainingSteps);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to retrieve training steps by trainingId=%d; result=%@; errorCode=%d; reason=%@", trainingId, wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to retrieve training steps by trainingId=%d; error=%@", trainingId, errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)loginWithUsername:(NSString *)username password:(NSString *)password success:(void (^)(BOOL, LoginToken * loginToken))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:username, @"username", password, @"password", nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"POST" path:@"login.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			BOOL isAuthenticated = [[JSON valueForKeyPath:@"result.authenticated"] boolValue];
			LoginToken * loginToken = nil;
			
			if (isAuthenticated) {
				loginToken = [[LoginToken alloc] initWithJSON:JSON];
				loginToken.username = username;
				DDLogInfo(@"! login successful; username=%@; token=%@; expiryDate=%@", username, loginToken.authToken, [loginToken.tokenExpiryDate description]);
			} else {
				loginToken = nil;
				DDLogInfo(@"! login failure; password incorrect");
			}
			success(isAuthenticated, loginToken);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! login failure; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! login failure; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)submitPasswordResetRequest:(NSString *)username success:(void (^)(BOOL))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:
							 username, @"username",
							 nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"POST" path:@"forgetPassword.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			success(YES);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to submit password reset request; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to submit password reset request; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)submitTrainingResultWithLoginToken:(LoginToken *)loginToken trainingId:(NSInteger)trainingId trainingSteps:(NSMutableArray *)trainingSteps comment:(NSString *)comment success:(void (^)())success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	DDLogInfo(@"! WebServiceClient: submitTrainingResultWithLoginToken; username=%@; trainingId=%d; comment=%@", loginToken.username, trainingId, comment);
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:
							 loginToken.username, @"username",
							 loginToken.authToken, @"token",
							 [NSString stringWithFormat:@"%d", trainingId], @"trainingId",
							 comment, @"comment",
							 [NSString stringFromTrainingStepRatings:trainingSteps], @"stepScores",
							 nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"POST" path:@"trainingSession.json" parameters:params];
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			success();
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to submit training result; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! failed to submit training result; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)updateTrainingProfileWithLoginToken:(LoginToken *)loginToken profileImage:(UIImage *)profileImage success:(void (^)(BOOL))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:loginToken.username, @"username", loginToken.authToken, @"token", nil];
	NSMutableURLRequest * request = [httpClient multipartFormRequestWithMethod:@"POST" path:@"updateMobileUserProfile.json" parameters:params constructingBodyWithBlock:^(id <AFMultipartFormData> formData) {
		[formData appendPartWithFileData:UIImageJPEGRepresentation(profileImage, .80f) name:@"data[profilePhoto]" fileName:@"profile.jpg" mimeType:@"image/jpeg"];
	}];
	
	DDLogInfo(@"! update profile; username=%@; authToken=%@", loginToken.username, loginToken.authToken);
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			DDLogInfo(@"! profile updated successfully");
			success(YES);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! failed to update profile; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! update profile failure; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

- (void)verifyLoginToken:(NSString *)username authToken:(NSString *)authToken success:(void (^)(BOOL, LoginToken *))success failure:(void (^)(BOOL, NSInteger, NSString *))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:appConfig.wsUrlPrefix]];
	NSDictionary * params = [NSDictionary dictionaryWithObjectsAndKeys:username, @"username", authToken, @"token", nil];
	NSMutableURLRequest * request = [httpClient requestWithMethod:@"POST" path:@"verifyLogin.json" parameters:params];
	
	DDLogInfo(@"! verifyLoginToken; username=%@; authToken=%@", username, authToken);
	
	AFJSONRequestOperation * operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest * request, NSHTTPURLResponse * response, id JSON) {
		NSString * wsResult = [self getWSResponseStatusWithJSON:JSON];
		
		if ([wsResult isEqualToString:@"ok"]) {
			BOOL isValid = [[JSON valueForKeyPath:@"result.isValid"] boolValue];
			LoginToken * loginToken = nil;
			
			if (isValid) {
				DDLogInfo(@"! login token verification successful");
				
				loginToken = [LoginToken new];
				loginToken.username = username;
                loginToken.isTrainer = [[JSON valueForKeyPath:@"result.isTrainer"] boolValue];
				loginToken.authToken = authToken;
				loginToken.tokenExpiryDate = [JSON valueForKeyPath:@"result.tokenExpiryDate"];
			} else {
				DDLogInfo(@"! login token verification failure; incorrect token");
			}
			success(isValid, loginToken);
		} else {
			NSInteger errorCode = [[JSON valueForKeyPath:@"errorCode"] integerValue];
			NSString * reason = [JSON valueForKeyPath:@"reason"];
			
			DDLogWarn(@"! login token verification failure; result=%@; errorCode=%d; reason=%@", wsResult, errorCode, reason);
			failure(NO, errorCode, reason);
		}
	} failure:^(NSURLRequest * request, NSHTTPURLResponse * response, NSError * error, id JSON) {
		NSString * errorDescription = [error localizedDescription];
		DDLogError(@"! verify login token failure; error=%@", errorDescription);
		failure(YES, -1, errorDescription);
	}];
	[operation start];
}

#pragma misc
- (UIImage *)getResizedImage:(UIImage *)image withSize:(CGSize)size {
	UIGraphicsBeginImageContextWithOptions(size, NO, .0f);
	[image drawInRect:CGRectMake(0, 0, size.width, size.height)];
	UIImage * resizedImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	return resizedImage;
}

@end
