//
//  WebServiceClient.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WebServiceClientDelegate;
@class AppConfig;
@class AboutUs, HallOfFames, LoginToken, TrainingDetails, TrainingProfile;

@interface WebServiceClient : NSObject {
	AppConfig * appConfig;
}

+ (id)getInstance;
- (void)getAboutUsWithSuccess:(void (^)(AboutUs * aboutUs))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getHOFWithLoginToken:(LoginToken *)loginToken success:(void (^)(HallOfFames * hof))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingCategoriesWithSuccess:(void (^)(NSMutableArray * trainingCats))success failure:(void(^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingDetailsWithLoginToken:(LoginToken *)loginToken trainingId:(NSInteger)trainingId success:(void (^)(TrainingDetails * details))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingHistoryWithLoginToken:(LoginToken *)loginToken trainingId:(NSInteger)trainingId success:(void (^)(NSMutableArray * trainingSessions))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingProfileScoreWithLoginToken:(LoginToken *)loginToken success:(void (^)(NSMutableArray * scores))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingProfileWithLoginToken:(LoginToken *)loginToken success:(void (^)(TrainingProfile * profile))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingsWithCategoryId:(NSUInteger)catId success:(void (^)(NSMutableArray * trainings))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingsWithLoginToken:(LoginToken *)loginToken success:(void (^)(NSMutableArray * trainings))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)getTrainingStepsWithTrainingId:(NSUInteger)trainingId success:(void (^)(NSMutableArray * trainingSteps))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)loginWithUsername:(NSString *)username password:(NSString *)password success:(void (^)(BOOL isLoggedIn, LoginToken * loginToken))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)submitPasswordResetRequest:(NSString *)username success:(void (^)(BOOL success))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;
- (void)submitTrainingResultWithLoginToken:(LoginToken *)loginToken trainingId:(NSInteger)trainingId trainingSteps:(NSMutableArray *)trainingSteps comment:(NSString *)comment success:(void (^)())success failure:(void (^)(BOOL, NSInteger, NSString *))failure;
- (void)updateTrainingProfileWithLoginToken:(LoginToken *)loginToken profileImage:(UIImage *)profileImage success:(void (^)(BOOL))success failure:(void (^)(BOOL, NSInteger, NSString *))failure ;
- (void)verifyLoginToken:(NSString *)username authToken:(NSString *)authToken success:(void (^)(BOOL isValid, LoginToken * loginToken))success failure:(void (^)(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage))failure;

@end