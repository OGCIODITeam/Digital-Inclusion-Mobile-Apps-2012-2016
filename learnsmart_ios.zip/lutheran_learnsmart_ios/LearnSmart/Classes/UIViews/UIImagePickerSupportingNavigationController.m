//
//  UIImagePickerSupportingNavigationController.m
//  LearnSmart
//
//  Created by Jack Cheung on 8/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "UIImagePickerSupportingNavigationController.h"

@interface UIImagePickerSupportingNavigationController ()

@end

@implementation UIImagePickerSupportingNavigationController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Ref: https://devforums.apple.com/message/731764#731764
// Ref: https://developer.apple.com/library/ios/#releasenotes/General/RN-iOSSDK-6_0/_index.html#//apple_ref/doc/uid/TP40012166
- (NSUInteger)supportedInterfaceOrientations {
	return UIInterfaceOrientationMaskLandscape;
}

@end
