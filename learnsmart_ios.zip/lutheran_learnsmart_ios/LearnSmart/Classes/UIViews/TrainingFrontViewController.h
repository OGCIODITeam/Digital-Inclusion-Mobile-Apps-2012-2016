//
//  TrainingFrontViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 8/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"

@class CacheManager, DeviceHelper, MobileLoginSessionManager, Training, WebServiceClient;

@interface TrainingFrontViewController : WSAbstractUIViewController<UIAlertViewDelegate> {
	CacheManager * cacheManager;
	DeviceHelper * deviceHelper;
	MobileLoginSessionManager * loginSessionManager;
	BOOL hasPromptError;
	IBOutlet UIButton * profileButton;
	IBOutlet UIButton * resultAndCommentsButton;
	IBOutlet UILabel * trainingDescriptionLabel;
	IBOutlet UIButton * trainingDetailsButton;
	Training * training;
	IBOutlet UILabel * trainingTitleLabel;
	IBOutlet UIImageView * trainingThumbnailImageView;
	WebServiceClient * wsClient;
}

- (id)initWithTraining:(Training *)training;
- (IBAction)tappedBackButtom:(id)sender;
- (IBAction)tappedProfileButton:(id)sender;
- (IBAction)tappedResultAndCommentsButton:(id)sender;
- (IBAction)tappedStartExerciseButton:(id)sender;
- (IBAction)tappedTrainingDetailsButton:(id)sender;

@end
