//
//  TrainingStepViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 4/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WSAbstractUIViewController.h"
#import "TrainingFinishViewController.h"
#import "TrainingStepRatingViewController.h"

@class MobileLoginSessionManager, CacheManager, CopyRestrictedTextView, SoundPlayer, TrainingStep;

@interface TrainingStepViewController : WSAbstractUIViewController<UIAlertViewDelegate, TrainingFinishViewDelegate, TrainingStepRatingDelegate> {
	BOOL allowIncompleteRatings;
	CacheManager * cacheManager;
	TrainingStep * currentTrainingStep;
	IBOutlet UIImageView * instructionImage;
	IBOutlet UILabel * instructionTitle;
	IBOutlet CopyRestrictedTextView * instructionText;
	MobileLoginSessionManager * loginSessionManager;
    IBOutlet UILabel * noPhotoIndicatorLabel;
	IBOutlet UIButton * prevButton;
	IBOutlet UIButton * nextButton;
	IBOutlet UIButton * ratingButton;
	IBOutlet UIButton * speakAgainButton;
	SoundPlayer * soundPlayer;
}

- (IBAction)tappedBackButton:(id)sender;
- (IBAction)tappedNextButton:(id)sender;
- (IBAction)tappedPreviousButton:(id)sender;
- (IBAction)tappedRatingButton:(id)sender;
- (IBAction)tappedSpeakAgainButton:(id)sender;

@end
