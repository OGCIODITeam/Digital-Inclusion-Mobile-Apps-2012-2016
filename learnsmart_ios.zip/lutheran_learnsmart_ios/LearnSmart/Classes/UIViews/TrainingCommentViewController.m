//
//  TrainingCommentViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 9/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingCommentViewController.h"
#import "CocoaLumberjackConfig.h"
#import "CacheManager.h"
#import "Training.h"

@interface TrainingCommentViewController ()

- (void)dismiss;
- (void)initBackgroundGesture;
- (void)updateTrainingTitleView;

@end

@implementation TrainingCommentViewController

@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)initBackgroundGesture {
	UITapGestureRecognizer * gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    gestureRecognizer.delegate = self;
	gestureRecognizer.cancelsTouchesInView = NO;
	[self.view addGestureRecognizer:gestureRecognizer];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	[self initBackgroundGesture];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
	DDLogInfo(@"! TrainingCommentVC: viewWillAppear");
	[self updateTrainingTitleView];
	[super viewWillAppear:animated];
}

#pragma training view
- (void)updateTrainingTitleView {
	CacheManager * cacheManager = [CacheManager getInstance];
	trainingCategoryLabel.text = cacheManager.currentTraining.title;
}

#pragma UIGestureRecognizer delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    return !([touch.view isKindOfClass:[UIButton class]] || [touch.view isKindOfClass:[UITextView class]]);
}

#pragma UITextView delegate
- (void)textViewDidChange:(UITextView *)textView {
	DDLogInfo(@"! TrainingCommentVC: textViewDidChange; textView.text=\"%@\"", textView.text);
	commentTips.hidden = ![textView.text isEqualToString:@""];
}

#pragma view shifting & textbox animation processing
- (void)hideKeyboard {
	[commentText resignFirstResponder];
}

#pragma button click handling
- (IBAction)tappedDoneButton:(id)sender {
	[self playClickSound];
	[delegate didFinishComment:commentText.text];
	[self dismiss];
}

- (IBAction)tappedSkipButton:(id)sender {
	[self playClickSound];
	
	[self dismiss];
}

- (void)dismiss {
	[self.navigationController popViewControllerAnimated:YES];
}

@end
