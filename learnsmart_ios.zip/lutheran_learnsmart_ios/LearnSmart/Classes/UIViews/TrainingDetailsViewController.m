//
//  TrainingDetailsViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 12/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingDetailsViewController.h"
#import "AppConfig.h"
#import "CacheManager.h"
#import "CocoaLumberjackConfig.h"
#import "DeviceHelper.h"
#import "LoginToken.h"
#import "MobileLoginSessionManager.h"
#import "TrainingDetails.h"
#import "WebServiceClient.h"

@interface TrainingDetailsViewController ()

- (void)initWebView;
- (void)initWSClient;
- (void)updateTrainingDetailsView;

@end

@implementation TrainingDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithTrainingId:(NSInteger)_trainingId {
	deviceHelper = [DeviceHelper getInstance];
	NSString * nibName;
	
	if ([deviceHelper isiPad]) {
		nibName = @"TrainingDetailsView_iPad";
	} else {
		nibName = @"TrainingDetailsView_iPhone";
	}
	
	self = [self initWithNibName:nibName bundle:nil];
	if (self) {
		trainingId = _trainingId;
	}
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	appConfig = [AppConfig getInstance];
	cacheManager = [CacheManager getInstance];
	deviceHelper = [DeviceHelper getInstance];
	loginSessionManager = [MobileLoginSessionManager getInstance];
	[self initWebView];
	[self initWSClient];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initWebView {
	[self removeShadowFromWebView:detailsContentView];
}

- (void)initWSClient {
	wsClient = [WebServiceClient getInstance];
}

- (void)viewWillAppear:(BOOL)animated {
	[self loadTrainingDetails];
	[super viewWillAppear:animated];
}

#pragma data related
- (void)loadTrainingDetails {
	LoginToken * loginToken = loginSessionManager.loginToken;
	
	trainingDetails = [cacheManager getCachedTrainingDetailsWithUsername:loginToken.username trainingId:trainingId];
	[self updateTrainingDetailsView];
	
	[self showProgressHUD];
	[wsClient getTrainingDetailsWithLoginToken:loginToken trainingId:trainingId success:^(TrainingDetails *details) {
		[self hideProgressHUD];
		trainingDetails = details;
		[self updateTrainingDetailsView];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString *errorMessage) {
		DDLogError(@"! ResultAndCommentsVC: failed to retrieve training details; isHttpError=%@; errorCode=%d; error=%@", isHttpError?@"YES":@"NO", errorCode, errorMessage);
		[self hideProgressHUD];
	}];
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	[self playClickSound];
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma Details Content related
- (void)updateTrainingDetailsView {
	NSString * textStyle;
	NSMutableString * detailsContent = [NSMutableString string];
	
	if ([deviceHelper isiPad]) {
		textStyle = appConfig.aboutUsTextStyleIPad;
	} else {
		textStyle = appConfig.aboutUsTextStyleIPhone;
	}
	[detailsContent appendString:textStyle];
	[detailsContent appendString:@"<style type=\"text/css\">* { -webkit-touch-callout: none; -webkit-user-select: none;}</style>"];
	
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.TrainingTitle", @""), trainingDetails.title?trainingDetails.title:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.TrainingCategory", @""), trainingDetails.category?trainingDetails.category:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.TrainingBackground", @""), trainingDetails.background?trainingDetails.background:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.FullName", @""), trainingDetails.traineeName?trainingDetails.traineeName:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.MentorName", @""), trainingDetails.tutorName?trainingDetails.tutorName:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.StartDate", @""), trainingDetails.startDate?trainingDetails.startDate:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.EndDate", @""), trainingDetails.endDate?trainingDetails.endDate:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.LongTermGoal", @""), trainingDetails.longTermTarget?trainingDetails.longTermTarget:@""];
	[detailsContent appendFormat:@"<b>%@</b>%@<br>", NSLocalizedString(@"TrainingDetails.Label.ShortTermGoal", @""), trainingDetails.shortTermTarget?trainingDetails.shortTermTarget:@""];
	
	[detailsContentView loadHTMLString:detailsContent baseURL:[NSURL URLWithString:@"http://localhost/"]];
}

@end