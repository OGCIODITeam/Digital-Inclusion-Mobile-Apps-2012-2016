//
//  CarouselItemView.m
//  LearnSmart
//
//  Created by Jack Cheung on 11/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "CarouselItemView.h"
#import "DeviceHelper.h"
#import "CocoaLumberjackConfig.h"

@implementation CarouselItemView

@synthesize accessibilityLabel;

- (id)initWithFrame:(CGRect)frame
{	
	DeviceHelper * deviceHelper = [DeviceHelper getInstance];
	NSString * nibName = nil;
	NSString * backgroundImageNameFormat = nil;
	
	if ([deviceHelper isiPad]) {
		backgroundImageNameFormat = @"training_item_%02d_ipad";
		nibName = @"CarouselItemView_iPad";
	} else {
		backgroundImageNameFormat = @"training_item_%02d_iphone";
		nibName = @"CarouselItemView_iPhone";
	}
	
	self = [[[NSBundle mainBundle] loadNibNamed:nibName owner:self options:nil] lastObject];
    if (self) {
        // Initialization code
        accessibilityLabel = @"";
		textLabel.text = @"";
		backgroundImage.image = [UIImage imageNamed:[NSString stringWithFormat:backgroundImageNameFormat, 1]];
    }
    return self;
}

- (id)initWithTitle:(NSString *)title theme:(NSUInteger)themeIdx {
	DeviceHelper * deviceHelper = [DeviceHelper getInstance];
	NSString * nibName = nil;
	NSString * backgroundImageNameFormat = nil;
	
	if ([deviceHelper isiPad]) {
		backgroundImageNameFormat = @"training_item_%02d_ipad";
		nibName = @"CarouselItemView_iPad";
	} else {
		backgroundImageNameFormat = @"training_item_%02d_iphone";
		nibName = @"CarouselItemView_iPhone";
	}
		
	self = [[[NSBundle mainBundle] loadNibNamed:nibName owner:self options:nil] lastObject];
	if (self) {
        accessibilityLabel = title;
		textLabel.text = title;
		backgroundImage.image = [UIImage imageNamed:[NSString stringWithFormat:backgroundImageNameFormat, themeIdx]];
	}
	return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma misc
- (void)updateTitle:(NSString *)title theme:(NSUInteger)themeIdx {
	DeviceHelper * deviceHelper = [DeviceHelper getInstance];
	NSString * backgroundImageNameFormat = nil;
	
	if ([deviceHelper isiPad]) {
		backgroundImageNameFormat = @"training_item_%02d_ipad";
	} else {
		backgroundImageNameFormat = @"training_item_%02d_iphone";
	}
	
    accessibilityLabel = title;
	textLabel.text = title;
	backgroundImage.image = [UIImage imageNamed:[NSString stringWithFormat:backgroundImageNameFormat, themeIdx % 6 + 1]];
}

@end
