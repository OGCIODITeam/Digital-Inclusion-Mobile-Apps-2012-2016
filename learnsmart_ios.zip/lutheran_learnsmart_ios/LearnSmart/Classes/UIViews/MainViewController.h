//
//  ViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WSAbstractUIViewController.h"

@class AppConfig,BGMusicPlayer, DeviceHelper, MobileLoginSessionManager, WebServiceClient;

@interface MainViewController : WSAbstractUIViewController {
	IBOutlet UIImageView * animatedGirlView;
	AppConfig * appConfig;
	BGMusicPlayer * bgMusicPlayer;
	DeviceHelper * deviceHelper;
	MobileLoginSessionManager * loginSessionManager;
	WebServiceClient * wsClient;
	IBOutlet UIView * welcomeView;
	IBOutlet UILabel * welcomeMessageLabel;
    IBOutlet UIButton * soundButton;

    BOOL isClosedSound;
}

- (void)didReceiveMobileLoginNotification:(NSNotification *)notification;
- (void)verifyLoginToken;
- (IBAction)tappedMiniGamesButton:(id)sender;
- (IBAction)tappedScenarioTrainingButton:(id)sender;
- (IBAction)tappedLoginButton:(id)sender;
- (IBAction)tappedAboutUsButton:(id)sender;
- (IBAction)tappedSoundButton:(id)sender;

@end
