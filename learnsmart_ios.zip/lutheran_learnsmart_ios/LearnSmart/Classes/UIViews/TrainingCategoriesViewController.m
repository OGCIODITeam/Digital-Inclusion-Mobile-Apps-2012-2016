//
//  TrainingCategoriesViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingCategoriesViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "AppConfig.h"
#import "CocoaLumberjackConfig.h"
#import "DeviceHelper.h"
#import "TrainingCategory.h"
#import "TrainingListViewController.h"

@interface TrainingCategoriesViewController ()

- (void)initCarousel;
- (void)initGirlAnimation;
- (void)loadTrainingCategories;
- (void)startCarouselSoundEffect;
- (void)startGirlAnimation;
- (void)stopCarouselSoundEffect;
- (void)stopGirlAnimation;

@end

@implementation TrainingCategoriesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	
    currentItemIdx = 0;
	deviceHelper = [DeviceHelper getInstance];
	[self initCarousel];
	[self initGirlAnimation];
}

- (void)viewWillAppear:(BOOL)animated {
	[self loadTrainingCategories];
	[self startGirlAnimation];
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
	[self stopGirlAnimation];
	[self stopCarouselSoundEffect];
	[super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma training categories fetching
- (void)loadTrainingCategories {
	trainingCategories = [[NSMutableArray alloc] init];
	
	TrainingCategory * trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 1;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat1.Title", @"");
	trainingCategory.priority = 1;
	trainingCategory.lastUpdated = [NSDate new];
	[trainingCategories addObject:trainingCategory];
	
	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 8;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat8.Title", @"");
	trainingCategory.priority = 2;
	[trainingCategories addObject:trainingCategory];
	
	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 2;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat2.Title", @"");
	trainingCategory.priority = 3;
	[trainingCategories addObject:trainingCategory];
	
	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 3;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat3.Title", @"");
	trainingCategory.priority = 4;
	[trainingCategories addObject:trainingCategory];

	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 4;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat4.Title", @"");
	trainingCategory.priority = 5;
	[trainingCategories addObject:trainingCategory];

	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 5;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat5.Title", @"");
	trainingCategory.priority = 6;
	[trainingCategories addObject:trainingCategory];

	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 6;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat6.Title", @"");
	trainingCategory.priority = 7;
	[trainingCategories addObject:trainingCategory];

	trainingCategory = [TrainingCategory new];
	trainingCategory.catId = 7;
	trainingCategory.title = NSLocalizedString(@"TrainingCategory.Cat7.Title", @"");
	trainingCategory.priority = 8;
	[trainingCategories addObject:trainingCategory];
	
    if (currentItemIdx >= trainingCategories.count) {
        currentItemIdx = 0;
    }
    
	[carouselView reloadData];
	[carouselView scrollToItemAtIndex:currentItemIdx animated:YES];
}

#pragma girl animation
- (void)initGirlAnimation {
	AppConfig * appConfig = [AppConfig getInstance];
	NSMutableArray * animatedGirlFrames = [NSMutableArray array];
	NSString * deviceSuffix;
	
	if ([deviceHelper isiPad]) {
		deviceSuffix = @"ipad";
	} else {
		deviceSuffix = @"iphone";
	}
	
	for (int i=1; i<=appConfig.numAnimatedGirlFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", i, deviceSuffix]]];
	}
	
	for (int i=1; i<appConfig.numAnimatedGirlPauseFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", appConfig.numAnimatedGirlFrames, deviceSuffix]]];
	}
	
	animatedGirlView.animationImages = animatedGirlFrames;
	animatedGirlView.animationDuration = 1.50f;
	animatedGirlView.animationRepeatCount = INFINITY;
}

- (void)startGirlAnimation {
	[animatedGirlView startAnimating];
}

- (void)stopGirlAnimation {
	[animatedGirlView stopAnimating];
}

#pragma iCarousel related methods
- (void)initCarousel {
	NSBundle * mainBundle = [NSBundle mainBundle];
	NSURL * scrollingSoundUrl = [mainBundle URLForResource:@"scrolling" withExtension:@"mp3"];
	NSError * error = nil;
	
	carouselView.type = iCarouselTypeRotary;
	carouselView.vertical = YES;
	
	carouselSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:scrollingSoundUrl error:&error];
	carouselSoundPlayer.numberOfLoops = INFINITY;
	[carouselSoundPlayer prepareToPlay];
	if (error) {
		DDLogError(@"! TrainingCategoriesVC: failed to init carousel scrolling sound; error=%@", error.description);
	}
}

- (void)carouselWillBeginDragging:(iCarousel *)carousel {
	if (carousel.numberOfItems > 0) {
		[self startCarouselSoundEffect];
	}
}

- (void)carouselDidEndDecelerating:(iCarousel *)carousel {
	[self stopCarouselSoundEffect];
}

- (void)carouselDidEndScrollingAnimation:(iCarousel *)carousel {
	[self stopCarouselSoundEffect];
}

- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel {
	return trainingCategories.count;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index reusingView:(UIView *)view {
	TrainingCategory * trainingCategory = nil;
	NSString * imageFilename = nil;
	CGRect viewFrame;
	
	for (TrainingCategory * category in trainingCategories) {
		if (category.priority == index+1) {
			trainingCategory = category;
			break;
		}
	}
	
	if ([deviceHelper isiPad]) {
		imageFilename = [NSString stringWithFormat:@"training_cat_%02d_ipad", trainingCategory.catId];
		viewFrame = CGRectMake(0, 0, 440.0f, 134.0f);
	} else {
		imageFilename = [NSString stringWithFormat:@"training_cat_%02d_iphone", trainingCategory.catId];
		viewFrame = CGRectMake(0, 0, 184.0f, 56.0f);
	}
	
	if (view == nil) {
		view = [[UIImageView alloc] initWithFrame:viewFrame];
		view.layer.borderColor = [[UIColor clearColor] CGColor];
		view.layer.borderWidth = 20.0f;
	} else {
	}
		
	((UIImageView *) view).image = [UIImage imageNamed:imageFilename];
    view.isAccessibilityElement = YES;
    NSLog(@"! cat title: %@", trainingCategory.title);
    [view setAccessibilityLabel:trainingCategory.title];
	
	return view;
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value {
	switch (option) {
		case iCarouselOptionArc: {
			if ([deviceHelper isiPad]) {
				return 2.9;
			} else {
				return 2.3;
			}
		}
		case iCarouselOptionCount: {
			return 10;
		}
		case iCarouselOptionFadeMin:
			return -0.3;
		case iCarouselOptionFadeMax:
			return 0.3;
		case iCarouselOptionFadeRange:
			return 2.0;
		case iCarouselOptionRadius: {
			if ([deviceHelper isiPad]) {
				return 470;
			} else {
				return 349;
			}
		}
		case iCarouselOptionSpacing: {
			return 1;
		}
		case iCarouselOptionWrap: {
			return 0;
		}
		default:
			return value;
	}
}

#pragma Carousel sound effects
- (void)startCarouselSoundEffect {
	[carouselSoundPlayer play];
}

- (void)stopCarouselSoundEffect {
	if ([carouselSoundPlayer isPlaying]) {
		[carouselSoundPlayer stop];
	}
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	[self playClickSound];
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)tappedGotoButton:(id)sender {
	[self playClickSound];
	
    currentItemIdx = carouselView.currentItemIndex;
    
	TrainingCategory * selectedCategory = [trainingCategories objectAtIndex:carouselView.currentItemIndex];
	NSInteger catId = selectedCategory.catId;
	
	TrainingListViewController * trainingListVC = [[TrainingListViewController alloc] initWithCategory:catId];
	[self.navigationController pushViewController:trainingListVC animated:YES];
}

@end
