//
//  ViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "MainViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "AppConfig.h"
#import "DeviceHelper.h"
#import "LoginToken.h"
#import "BGMusicPlayer.h"
#import "MobileLoginSessionManager.h"
#import "WebServiceClient.h"
#import "CocoaLumberjackConfig.h"
#import "AboutUsViewController.h"
#import "MobileLoginViewController.h"
#import "TrainingCategoriesViewController.h"
#import "TrainingListViewController.h"
#import "GameAppViewController.h"	// mini-game

#define WELCOME_ANIMATION_DURATION .5f
#define WELCOME_MESSAGE_STAY_DURATION 2.0f

@interface MainViewController ()

- (void)initGirlAnimation;
- (void)startGirlAnimation;
- (void)stopGirlAnimation;
- (void)initSoundButton;
@end

@implementation MainViewController

- (void)initNotificationObserver {
	id notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter addObserver:self selector:@selector(didReceiveMobileLoginNotification:) name:MOBILE_LOGIN_NOTIFICATION_NAME object:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    isClosedSound=[[NSUserDefaults standardUserDefaults]boolForKey:@"sound"];
    NSLog(@"!viewDidLoad, is Closed sound: %@",isClosedSound?@"Yes":@"No");

	appConfig = [AppConfig getInstance];
	deviceHelper = [DeviceHelper getInstance];
	loginSessionManager = [MobileLoginSessionManager getInstance];
	wsClient = [WebServiceClient getInstance];
	bgMusicPlayer = [BGMusicPlayer getInstance];
	[self initNotificationObserver];
	[self initGirlAnimation];
    [self initSoundButton];
	[self verifyLoginToken];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

- (void)viewWillAppear:(BOOL)animated {
	DDLogInfo(@"! MainVC: viewWillAppear");
	[self hideWelcomeView];
	if(!isClosedSound){[bgMusicPlayer start];}
	[self startGirlAnimation];
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
	DDLogInfo(@"! MainVC: viewWillDisappear");
	[self stopGirlAnimation];
	if(!isClosedSound){[bgMusicPlayer stop];}
	[super viewWillDisappear:animated];
}

- (void)dealloc {
	id notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter removeObserver:self];
}

#pragma Welcome View initialization
- (void)hideWelcomeView {
	welcomeView.hidden = YES;
	
	CGRect viewFrame = welcomeView.frame;
	viewFrame.origin.y = -viewFrame.size.height;
	welcomeView.frame = viewFrame;
}

- (void)initWelcomeView {
	welcomeView.layer.cornerRadius = 5;
	welcomeView.layer.masksToBounds = YES;
	[self hideWelcomeView];
}

- (void)startWelcomeViewAnimation {
	welcomeMessageLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Login.Welcome.Message", @""), loginSessionManager.loginToken.username];
				
	[self hideWelcomeView];
	welcomeView.hidden = NO;
	
	[UIView animateWithDuration:WELCOME_ANIMATION_DURATION animations:^{
		DDLogInfo(@"! animation starts");
		CGRect viewFrame = welcomeView.frame;
		viewFrame.origin.y = 10;
		welcomeView.frame = viewFrame;
	} completion:^(BOOL finished) {
		DDLogInfo(@"! animation stops");
		[self performSelector:@selector(hideWelcomeView) withObject:self afterDelay:WELCOME_MESSAGE_STAY_DURATION];
	}];
}

#pragma girl animation
- (void)initGirlAnimation {
	NSMutableArray * animatedGirlFrames = [NSMutableArray array];
	NSString * deviceSuffix;
	
	if ([deviceHelper isiPad]) {
		deviceSuffix = @"ipad";
	} else {
		deviceSuffix = @"iphone";
	}
	
	for (int i=1; i<=appConfig.numAnimatedGirlFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", i, deviceSuffix]]];
	}
	
	for (int i=1; i<appConfig.numAnimatedGirlPauseFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", appConfig.numAnimatedGirlFrames, deviceSuffix]]];
	}
	
	animatedGirlView.animationImages = animatedGirlFrames;
	animatedGirlView.animationDuration = 1.50f;
	animatedGirlView.animationRepeatCount = INFINITY;
}

- (void)startGirlAnimation {
	[animatedGirlView startAnimating];
}

- (void)stopGirlAnimation {
	[animatedGirlView stopAnimating];
}

- (void)initSoundButton{
    NSLog(@"!initSoundButton, is Closed sound: %@",isClosedSound?@"Yes":@"No");
    if(isClosedSound){
        NSLog(@"isClosedSound");
        if ([deviceHelper isiPad]) {
            NSLog(@"isiPad");
            [soundButton setBackgroundImage:[UIImage imageNamed:@"speaker_mute_ipad.png"] forState:UIControlStateNormal];
        }
        else{
            NSLog(@"isiPhone");
            [soundButton setBackgroundImage:[UIImage imageNamed:@"speaker_mute_iphone.png"] forState:UIControlStateNormal];
        }
        
    }
    else{
        NSLog(@"is not ClosedSound");
        if ([deviceHelper isiPad]) {
            NSLog(@"isiPad");
            [soundButton setBackgroundImage:[UIImage imageNamed:@"speaker_button_ipad.png"] forState:UIControlStateNormal];
        }
        else{
            NSLog(@"isiPhone");
            [soundButton setBackgroundImage:[UIImage imageNamed:@"speaker_button_iphone.png"] forState:UIControlStateNormal];
        }
    }
}

#pragma NSNotificationCenter handler
- (void)didReceiveMobileLoginNotification:(NSNotification *)notification {
	LoginToken * loginToken = notification.object;
	DDLogInfo(@"! received login token via notification; username=%@; authToken=%@; expiryDate=%@", loginToken.username, loginToken.authToken, [loginToken.tokenExpiryDate description]);
	if ([self.navigationController.topViewController isKindOfClass:[MobileLoginViewController class]]) {
		[self.navigationController popToViewController:self animated:YES];
	}
	[self startWelcomeViewAnimation];
}

- (void)postLoginSuccessfulNotificationWithLoginToken:(LoginToken *)token {
	id notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter postNotificationName:MOBILE_LOGIN_NOTIFICATION_NAME object:token];
}

#pragma Login Token verification
- (void)verifyLoginToken {
	
	LoginToken * loginToken = loginSessionManager.loginToken;

	if (loginToken == nil) {
		DDLogInfo(@"! MainVC: skip verifyLoginToken as no valid loginToken");
	} else {
		DDLogInfo(@"! MainVC: verifyLoginToken");
		[wsClient verifyLoginToken:loginToken.username authToken:loginToken.authToken success:^(BOOL isValid, LoginToken * _loginToken) {
			if (isValid) {
				DDLogInfo(@"! MainVC: token verified successfully");
				
				[[MobileLoginSessionManager getInstance] setLoginToken:_loginToken];
				[self postLoginSuccessfulNotificationWithLoginToken:_loginToken];
			} else {
				DDLogInfo(@"! MainVC: verify token returns false");
				loginSessionManager.loginToken = nil;
				UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Login.Failure.InvalidOrExpiredToken", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
				[alertView show];
			}
		} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
			if (isHttpError) {
				DDLogError(@"! MainVC: http error occured; ignore verify token result; errorMessage=%@", errorMessage);
			} else {
				DDLogError(@"! MainVC: failed to verify token; errorCode=%d; errorMessage=%@", errorCode, errorMessage);
				loginSessionManager.loginToken = nil;
                switch (errorCode) {
                    case ERROR_CODE_INVALID_MOBILE_USER:
                    case ERROR_CODE_INVALID_OR_EXPIRED_TOKEN: {
                        [[[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Login.Failure.InvalidOrExpiredToken", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil] show];
                        break;
                    }
                    default:
                        break;
                }
			}
		}];
	}
}

#pragma UIButton tapping handling
- (IBAction)tappedAboutUsButton:(id)sender {
	AboutUsViewController * aboutUsVC;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		aboutUsVC = [[AboutUsViewController alloc] initWithNibName:@"AboutUsView_iPad" bundle:nil];
	} else {
		aboutUsVC = [[AboutUsViewController alloc] initWithNibName:@"AboutUsView_iPhone" bundle:nil];
	}
	
	[self.navigationController pushViewController:aboutUsVC animated:YES];
}

- (IBAction)tappedLoginButton:(id)sender {
	MobileLoginViewController * mobileLoginVC;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		mobileLoginVC = [[MobileLoginViewController alloc] initWithNibName:@"MobileLoginView_iPad" bundle:nil];
	} else {
		mobileLoginVC = [[MobileLoginViewController alloc] initWithNibName:@"MobileLoginView_iPhone" bundle:nil];
	}
	
	[self.navigationController pushViewController:mobileLoginVC animated:YES];
}

- (IBAction)tappedMiniGamesButton:(id)sender {
	GameAppViewController * gameAppVC;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		gameAppVC = [[GameAppViewController alloc] initWithNibName:@"GameAppViewController_iPad" bundle:nil];
	} else {
		gameAppVC = [[GameAppViewController alloc] initWithNibName:@"GameAppViewController_iPhone" bundle:nil];
	}
	
	[self.navigationController pushViewController:gameAppVC animated:YES];
}

- (IBAction)tappedScenarioTrainingButton:(id)sender {
	LoginToken * loginToken = loginSessionManager.loginToken;
	
	[self playClickSound];
	
	if (loginToken == nil) {
		TrainingCategoriesViewController * trainingCatVC;
		
		if ([deviceHelper isiPad]) {
			trainingCatVC = [[TrainingCategoriesViewController alloc] initWithNibName:@"TrainingCategoriesView_iPad" bundle:nil];
		} else {
			trainingCatVC = [[TrainingCategoriesViewController alloc] initWithNibName:@"TrainingCategoriesView_iPhone" bundle:nil];
		}
			
		[self.navigationController pushViewController:trainingCatVC animated:YES];
	} else {
		TrainingListViewController * trainingListVC = [[TrainingListViewController alloc] initWithLoginToken:loginToken];		
		[self.navigationController pushViewController:trainingListVC animated:YES];
	}
}

-(void)tappedSoundButton:(id)sender{
    NSLog(@"!tappedSoundButton, is Closed sound: %@",isClosedSound?@"Yes":@"No");
    if(isClosedSound){
        [[NSUserDefaults standardUserDefaults]setBool:false forKey:@"sound"];
        [bgMusicPlayer start];
        NSLog(@"!tappedSoundButton1");
    }
    else{
        [[NSUserDefaults standardUserDefaults]setBool:true forKey:@"sound"];
        [bgMusicPlayer stop];
        NSLog(@"!tappedSoundButton2");
    }
    isClosedSound=[[NSUserDefaults standardUserDefaults]boolForKey:@"sound"];
    NSLog(@"!tappedSoundButton End, is Closed sound: %@",isClosedSound?@"Yes":@"No");
    [self initSoundButton];
}

@end
