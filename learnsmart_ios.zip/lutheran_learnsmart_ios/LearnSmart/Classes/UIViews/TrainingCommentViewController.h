//
//  TrainingCommentViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 9/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"

@protocol TrainingCommentDelegate
- (void)didFinishComment:(NSString *)comment;
@end

@interface TrainingCommentViewController : WSAbstractUIViewController<UIGestureRecognizerDelegate, UITextViewDelegate> {
	IBOutlet UILabel * trainingCategoryLabel;
	IBOutlet UITextView * commentText;
	IBOutlet UIImageView * commentTips;
}

@property (nonatomic, strong) id<TrainingCommentDelegate> delegate;

- (IBAction)tappedDoneButton:(id)sender;
- (IBAction)tappedSkipButton:(id)sender;

@end