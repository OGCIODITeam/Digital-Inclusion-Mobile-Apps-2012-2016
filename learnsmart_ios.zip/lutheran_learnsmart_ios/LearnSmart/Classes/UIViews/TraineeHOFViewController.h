//
//  TraineeHOFViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 8/8/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TraineeHOFViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIImageView * profileImageView;

- (id)initWithProfileImage:(UIImage *)image;

@end
