//
//  TrainingCategoriesViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WSAbstractUIViewController.h"
#import <iCarousel/iCarousel.h>

@class AVAudioPlayer, DeviceHelper;

@interface TrainingCategoriesViewController : WSAbstractUIViewController<iCarouselDataSource, iCarouselDelegate> {
	IBOutlet UIImageView * animatedGirlView;
	AVAudioPlayer * carouselSoundPlayer;
	IBOutlet iCarousel * carouselView;
    NSInteger currentItemIdx;
	DeviceHelper * deviceHelper;
	NSMutableArray * trainingCategories;
}

- (IBAction)tappedBackButton:(id)sender;
- (IBAction)tappedGotoButton:(id)sender;

@end
