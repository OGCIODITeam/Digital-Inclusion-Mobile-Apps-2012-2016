//
//  TrainingFrontViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 8/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingFrontViewController.h"
#import "TrainingStepViewController.h"
#import "CacheManager.h"
#import "DeviceHelper.h"
#import "MobileLoginSessionManager.h"
#import "WebServiceClient.h"
#import "CocoaLumberjackConfig.h"
#import "Training.h"
#import "TrainingStep.h"
#import "TrainingDetailsViewController.h"
#import "TrainingProfileViewController.h"
#import "ResultAndCommentsViewController.h"

#define NETWORK_ERROR_ALERT 500
#define FAILED_MEDIA_DOWNLOAD_ALERT 510
#define CLICKED_CANCEL_BUTTON 0
#define CLICKED_RETRY_BUTTON 1

@interface TrainingFrontViewController ()

- (void)loadTrainingSteps;
- (void)loadTrainingStepsMedia;
- (void)showLoadingFailureAlertView;
- (void)showNetworkErrorAlertView;
- (void)showTrainingStepsView;
- (void)updateButtonsVisibilities;
- (void)updateTrainingViews;

@end

@implementation TrainingFrontViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithTraining:(Training *)_training {
	deviceHelper = [DeviceHelper getInstance];
	NSString * nibName = nil;
	
	if ([deviceHelper isiPad]) {
		nibName = @"TrainingFrontView_iPad";
	} else {
		nibName = @"TrainingFrontView_iPhone";
	}
	
	self = [super initWithNibName:nibName bundle:nil];
	if (self) {
		training = _training;
	}
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	cacheManager = [CacheManager getInstance];
	deviceHelper = [DeviceHelper getInstance];
	loginSessionManager = [MobileLoginSessionManager getInstance];
	wsClient = [WebServiceClient getInstance];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

- (void)viewWillAppear:(BOOL)animated {
	hasPromptError = NO;
	[self updateTrainingViews];
	[super viewWillAppear:animated];
}

#pragma UIAlertView related
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
	switch (alertView.tag) {
		case NETWORK_ERROR_ALERT: {
			switch (buttonIndex) {
				case CLICKED_CANCEL_BUTTON:
					[self loadTrainingStepsMedia];
					break;
				case CLICKED_RETRY_BUTTON:
					[self loadTrainingSteps];
					break;
				default:
					break;
			}
			break;
		}
		case FAILED_MEDIA_DOWNLOAD_ALERT: {
			switch (buttonIndex) {
				case CLICKED_CANCEL_BUTTON:
					[self showTrainingStepsView];
					break;
				case CLICKED_RETRY_BUTTON:
					[self loadTrainingStepsMedia];
					break;
				default:
					break;
			}
			break;
		}
		default: {
			break;
		}
	}
}

- (void)showLoadingFailureAlertView {
	UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"NetworkError.RetryPrompt", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles:NSLocalizedString(@"OK", @""), nil];
    alertView.tag = NETWORK_ERROR_ALERT;
    [alertView show];
}

- (void)showNetworkErrorAlertView {
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"NetworkError.InternetConnectionFailure", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
    alertView.tag = NETWORK_ERROR_ALERT;
    [alertView show];
	hasPromptError = YES;
}

- (void)showTrainingStepsView {
	TrainingStepViewController * trainingStepVC = nil;
	NSString * nibName = nil;
	
	if (cacheManager.currentTrainingSteps.count < 1) {
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"TrainingStep.NoSteps", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
		[alertView show];
		return;
	}
	
	if ([deviceHelper isiPad]) {
		nibName = @"TrainingStepView_iPad";
	} else {
		nibName = @"TrainingStepView_iPhone";
	}
	trainingStepVC = [[TrainingStepViewController alloc] initWithNibName:nibName bundle:nil];
	
	[self.navigationController pushViewController:trainingStepVC animated:YES];
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButtom:(id)sender {
	[self playClickSound];
	
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)tappedProfileButton:(id)sender {
	TrainingProfileViewController * trainingStepVC;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		trainingStepVC = [[TrainingProfileViewController alloc] initWithNibName:@"TrainingProfileView_iPad" bundle:nil];
	} else {
		trainingStepVC = [[TrainingProfileViewController alloc] initWithNibName:@"TrainingProfileView_iPhone" bundle:nil];
	}
	
	[self.navigationController pushViewController:trainingStepVC animated:YES];
}

- (IBAction)tappedResultAndCommentsButton:(id)sender {
	ResultAndCommentsViewController * resultAndCommentsVC = nil;
	[self playClickSound];
	
	resultAndCommentsVC = [[ResultAndCommentsViewController alloc] initWithTrainingId:training.trainingId];
	
	[self.navigationController pushViewController:resultAndCommentsVC animated:YES];
}

- (IBAction)tappedStartExerciseButton:(id)sender {
	[self playClickSound];
	
	[self loadTrainingSteps];
}

- (IBAction)tappedTrainingDetailsButton:(id)sender {
	TrainingDetailsViewController * trainingDetailsVC = nil;
	[self playClickSound];
	
	trainingDetailsVC = [[TrainingDetailsViewController alloc] initWithTrainingId:training.trainingId];
		
	[self.navigationController pushViewController:trainingDetailsVC animated:YES];
}

#pragma misc
- (void)loadTrainingSteps {
	
	cacheManager.currentTraining = training;
	cacheManager.currentTrainingSteps = [cacheManager getCachedTrainingStepsWithTrainingId:training.trainingId];
	
	if ([cacheManager isTrainingStepsCacheExpiredWithTrainingId:training.trainingId]) {
		[self showProgressHUD];
		[wsClient getTrainingStepsWithTrainingId:training.trainingId success:^(NSMutableArray * trainingSteps) {
			DDLogInfo(@"! retrieved %d training steps", trainingSteps.count);
			
			[self hideProgressHUD];
			cacheManager.currentTrainingSteps = trainingSteps;
			[cacheManager cacheTrainingSteps:trainingSteps withTrainingId:training.trainingId];
			
			[self loadTrainingStepsMedia];
		} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
			[self hideProgressHUD];
			
			if (isHttpError) {
				DDLogError(@"! TrainingFrontVC: http error occured; errorMessage = %@", errorMessage);
				[self showNetworkErrorAlertView];
			} else {
				DDLogError(@"! TrainingFrontVC: failed to load training steps; errorMessage = %@", errorMessage);
				[self showLoadingFailureAlertView];
			}
		}];
	} else {
		[self loadTrainingStepsMedia];
	}
}

- (void)loadTrainingStepsMedia {
	NSFileManager * fileManager = [NSFileManager defaultManager];
	NSMutableArray * mediaFiles = [NSMutableArray array];
	
	for (TrainingStep * step in cacheManager.currentTrainingSteps) {
		DDLogInfo(@"! TrainingFrontVC: processing step media; pic=%@; sound=%@", step.picture, step.sound);
		
		if (![fileManager fileExistsAtPath:[cacheManager getCachedPathForUrl:step.picture]]) {
			[mediaFiles addObject:step.picture];
		}
		if (![fileManager fileExistsAtPath:[cacheManager getCachedPathForUrl:step.sound]]) {
			[mediaFiles addObject:step.sound];
		}
	}
	
	if (mediaFiles.count < 1) {
		[self showTrainingStepsView];
	} else {
		[self showProgressHUD];
		[cacheManager cacheFilesAtUrlList:mediaFiles success:^(NSArray *pathList) {
			DDLogInfo(@"! TrainingFrontVC: cached files");
			[self hideProgressHUD];
			[self showTrainingStepsView];
		} failure:^(NSInteger httpErrorCode, NSString *errorMessage) {
			DDLogError(@"! TraininingFrontVC: failed to load training steps media; error=%@", errorMessage);
			[self hideProgressHUD];
			
			if (hasPromptError) {
				[self showTrainingStepsView];
			} else {
				UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"NetworkError.InternetConnectionFailure", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
				alertView.tag = FAILED_MEDIA_DOWNLOAD_ALERT;
				[alertView show];
			}
		}];
	}
}

- (void)updateButtonsVisibilities {
    LoginToken * loginToken = loginSessionManager.loginToken;
	
	if (loginToken == nil) {
		profileButton.hidden = YES;
		resultAndCommentsButton.hidden = YES;
		trainingDetailsButton.hidden = YES;
	} else {
		profileButton.hidden = NO;
		resultAndCommentsButton.hidden = NO;
		trainingDetailsButton.hidden = NO;
	}
}

- (void)updateTrainingViews {
	[self updateButtonsVisibilities];
	
	if ([cacheManager isURLCached:training.thumbnail]) {
		NSString * cachedPath = [cacheManager getCachedPathForUrl:training.thumbnail];
		DDLogInfo(@"! already cached; thumbnail.imagePath=%@", cachedPath);
		[trainingThumbnailImageView setImage:[[UIImage alloc] initWithContentsOfFile:cachedPath]];
	} else {
		[self showProgressHUD];
		[cacheManager cacheFileAtUrl:training.thumbnail success:^(NSString * cachedPath) {
			[self hideProgressHUD];
			NSString * fullPath = [cacheManager getFullCachePathForFile:cachedPath];
			
			DDLogInfo(@"! thumbnail.imagePath=%@", fullPath);
			[trainingThumbnailImageView setImage:[[UIImage alloc] initWithContentsOfFile:fullPath]];
		} failure:^(NSInteger httpErrorCode, NSString * errorMessage) {
			[self hideProgressHUD];
			DDLogError(@"! TrainingFrontVC: failed to fetch thumbnail image; httpStatus=%d; errorMessage=%@", httpErrorCode, errorMessage);
		}];
	}
	
	trainingTitleLabel.text = training.title;
	trainingDescriptionLabel.text = training.description;
}

@end
