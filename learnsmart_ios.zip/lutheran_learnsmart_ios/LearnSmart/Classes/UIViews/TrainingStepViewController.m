//
//  TrainingStepViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 4/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingStepViewController.h"
#import "TrainingCommentViewController.h"
#import "TrainingFinishViewController.h"
#import "TrainingStepRatingViewController.h"
#import "LoginToken.h"
#import "CacheManager.h"
#import "DeviceHelper.h"
#import "Training.h"
#import "TrainingStep.h"
#import "MobileLoginSessionManager.h"
#import "CocoaLumberjackConfig.h"
#import "SoundPlayer.h"
#import "CopyRestrictedTextView.h"

#define ALLOW_INCOMPLETE_RATING 100
#define ABORT_TRAINING_ALERT 101

#define CLICKED_CANCEL_BUTTON 0
#define CLICKED_OK_BUTTON 1

@interface TrainingStepViewController ()

- (void)dismiss;
- (BOOL)isExpectingRating;
- (void)nextTrainingStep;
- (void)showTrainingFinishView;
- (void)showUnratedStepAlert;
- (void)updateTrainingStep;

@end

@implementation TrainingStepViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	allowIncompleteRatings = NO;
	cacheManager = [CacheManager getInstance];
	loginSessionManager = [MobileLoginSessionManager getInstance];
	soundPlayer = [SoundPlayer getInstance];
	
	[self updateTrainingStep];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma view update

#pragma UIAlertView related
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
	switch (alertView.tag) {
		case ALLOW_INCOMPLETE_RATING: {
			switch (buttonIndex) {
				case CLICKED_OK_BUTTON: {
					allowIncompleteRatings = YES;
					[self nextTrainingStep];
					break;
				}
			}
			break;
		}
		case ABORT_TRAINING_ALERT: {
			switch (buttonIndex) {
				case CLICKED_CANCEL_BUTTON:
					break;
				case CLICKED_OK_BUTTON: {
					[self dismiss];
					break;
				}
			}
			break;
		}
		default:
			break;
	}
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	[self playClickSound];
	
	UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Training.Abort.Confirmation", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles:NSLocalizedString(@"OK", @""), nil];
	alertView.tag = ABORT_TRAINING_ALERT;
	[alertView show];
}

- (IBAction)tappedNextButton:(id)sender {
	[self playClickSound];
	
	if ([self isExpectingRating] && ![cacheManager isCurrentTrainingStepRated]) {
		[self showUnratedStepAlert];
		return;
	}

	[self nextTrainingStep];
}

- (IBAction)tappedPreviousButton:(id)sender {
	[self playClickSound];

	[cacheManager prevStep];
	[self updateTrainingStep];
}

- (IBAction)tappedRatingButton:(id)sender {
	TrainingStepRatingViewController * trainingStepRatingVC = [[TrainingStepRatingViewController alloc] initWithSelection:currentTrainingStep.rating delegate:self];
	[self playClickSound];
	
	[self.navigationController pushViewController:trainingStepRatingVC animated:YES];
}

- (IBAction)tappedSpeakAgainButton:(id)sender {
	if (currentTrainingStep.sound != nil && ![currentTrainingStep.sound isEqualToString:@""]) {
		[soundPlayer playAudio:[cacheManager getCachedPathForUrl:currentTrainingStep.sound]];
	}
}

#pragma training finish view
- (void)dismissedTrainingFinishView {
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma training step rating view
- (void)dismissedTrainingStepRatingVC {
	[self.navigationController popToViewController:self animated:YES];
}

#pragma misc
- (void)dismiss {
	[self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)isExpectingRating {
	LoginToken * loginToken = loginSessionManager.loginToken;
	return loginToken.isTrainer && !allowIncompleteRatings;
}

- (void)nextTrainingStep {
	if ([cacheManager isLastStep]) {
		[self showTrainingFinishView];
	} else {
		[cacheManager nextStep];
		[self updateTrainingStep];
	}
}

- (void)showTrainingFinishView {
	DeviceHelper * deviceHelper = [DeviceHelper getInstance];
	TrainingCommentViewController * trainingCommentVC = nil;
	TrainingFinishViewController * trainingFinishVC = nil;
	
	if ([deviceHelper isiPad]) {
		trainingCommentVC = [[TrainingCommentViewController alloc] initWithNibName:@"TrainingCommentView_iPad" bundle:nil];
		trainingFinishVC = [[TrainingFinishViewController alloc] initWithNibName:@"TrainingFinishView_iPad" bundle:nil];
	} else {
		trainingCommentVC = [[TrainingCommentViewController alloc] initWithNibName:@"TrainingCommentView_iPhone" bundle:nil];
		trainingFinishVC = [[TrainingFinishViewController alloc] initWithNibName:@"TrainingFinishView_iPhone" bundle:nil];
	}
	
	[self.navigationController pushViewController:trainingFinishVC animated:NO];
	if ([self isExpectingRating]) {
		[self.navigationController pushViewController:trainingCommentVC animated:YES];
	}
	trainingCommentVC.delegate = trainingFinishVC;
	trainingFinishVC.delegate = self;
}

- (void)showUnratedStepAlert {
	UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"TrainingStep.Unrated", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles:NSLocalizedString(@"Continue", @""), nil];
	alertView.tag = ALLOW_INCOMPLETE_RATING;
	[alertView show];
}

- (void)updateTrainingStep {
	NSFileManager * fileManager = [NSFileManager defaultManager];
	
	currentTrainingStep = [cacheManager getCurrentTrainingStep];
	ratingButton.hidden = !loginSessionManager.loginToken.isTrainer;
	
	prevButton.enabled = ![cacheManager isFirstStep];
	if (prevButton.isEnabled) {
		prevButton.alpha = 1.0f;
	} else {
		prevButton.alpha = .5f;
	}
	
	if (currentTrainingStep.sound == nil || [currentTrainingStep.sound isEqualToString:@""]) {
		speakAgainButton.alpha = .5f;
		speakAgainButton.enabled = NO;
	} else {
		speakAgainButton.alpha = 1.0f;
		speakAgainButton.enabled = YES;
		[soundPlayer playAudio:[cacheManager getCachedPathForUrl:currentTrainingStep.sound]];
	}
	
	DDLogInfo(@"! TrainingStepVC: pic=%@", currentTrainingStep.picture);
	NSString * cachedImagePath = [cacheManager getCachedPathForUrl:currentTrainingStep.picture];
	
	DDLogInfo(@"! TrainingStepVC: cached pic=%@; exists=%@", cachedImagePath, [fileManager fileExistsAtPath:cachedImagePath]?@"YES":@"NO");
	[instructionImage setImage:[[UIImage alloc] initWithContentsOfFile:cachedImagePath]];
    noPhotoIndicatorLabel.isAccessibilityElement = !instructionImage.image;
	instructionTitle.text = cacheManager.currentTraining.title;
	if ([currentTrainingStep.text isEqualToString:@""]) {
		instructionText.text = @"";
	} else {
		instructionText.text = [NSString stringWithFormat:@"%02d. %@", cacheManager.currentTrainingStepIdx+1, currentTrainingStep.text];
	}
	
	DDLogInfo(@"! TrainingStepVC: update instruction text: %@", currentTrainingStep.text);
}

@end
