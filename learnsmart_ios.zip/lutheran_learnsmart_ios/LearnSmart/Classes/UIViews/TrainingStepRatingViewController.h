//
//  TrainingStepRatingViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 7/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"

@class CacheManager, DeviceHelper;

@protocol TrainingStepRatingDelegate <NSObject>

- (void)dismissedTrainingStepRatingVC;

@end


@interface TrainingStepRatingViewController : WSAbstractUIViewController {
	CacheManager * cacheManager;
	DeviceHelper * deviceHelper;
	IBOutletCollection(UIButton) NSArray * radioButtons;
	NSInteger selectedStars;
}

@property (nonatomic, strong) id<TrainingStepRatingDelegate> delegate;

- (id)initWithSelection:(NSInteger)_selectedStars delegate:(id)_delegate;
- (void)dismiss;
- (IBAction)tappedCancelButton:(id)sender;
- (IBAction)tappedFinishButton:(id)sender;
- (IBAction)tappedRadioButton:(id)sender;

@end