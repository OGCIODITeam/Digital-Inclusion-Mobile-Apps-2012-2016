//
//  ResultAndCommentsViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 12/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "ResultAndCommentsViewController.h"
#import "AppConfig.h"
#import "CacheManager.h"
#import "DeviceHelper.h"
#import "LoginToken.h"
#import "TrainingHistory.h"
#import "MobileLoginSessionManager.h"
#import "WebServiceClient.h"
#import "CocoaLumberjackConfig.h"

@interface ResultAndCommentsViewController ()

- (void)initWebView;
- (void)initWSClient;
- (void)loadTrainingHistories;
- (void)updateCommentsContentView;

@end

@implementation ResultAndCommentsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithTrainingId:(NSInteger)_trainingId {
	DeviceHelper * deviceHelper = [DeviceHelper getInstance];
	NSString * nibName = nil;
	
	if ([deviceHelper isiPad]) {
		nibName = @"ResultAndCommentsView_iPad";
	} else {
		nibName = @"ResultAndCommentsView_iPhone";
	}
	
	self = [self initWithNibName:nibName bundle:nil];
	if (self) {
		trainingId = _trainingId;
	}
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	appConfig = [AppConfig getInstance];
	cacheManager = [CacheManager getInstance];
	loginSessionManager = [MobileLoginSessionManager getInstance];
	trainingHistories = [NSMutableArray array];
	[self initWebView];
	[self initWSClient];
}

- (void)viewWillAppear:(BOOL)animated {
	[self loadTrainingHistories];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initWebView {
	[self removeShadowFromWebView:commentsContentView];
}

- (void)initWSClient {
	wsClient = [WebServiceClient getInstance];
}

#pragma data related
- (void)loadTrainingHistories {
	trainingHistories = [cacheManager getCachedTrainingHistoriesWithUsername:loginSessionManager.loginToken.username trainingId:trainingId];
	[self updateCommentsContentView];
	
	[self showProgressHUD];
	[wsClient getTrainingHistoryWithLoginToken:loginSessionManager.loginToken trainingId:trainingId success:^(NSMutableArray *trainingSessions) {
		[self hideProgressHUD];
		trainingHistories = trainingSessions;
		[self updateCommentsContentView];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString *errorMessage) {
		DDLogError(@"! ResultAndCommentsVC: failed to retrieve training histories; isHttpError=%@; errorCode=%d; error=%@", isHttpError?@"YES":@"NO", errorCode, errorMessage);
		[self hideProgressHUD];
	}];
	
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	[self playClickSound];
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma misc
- (void)updateCommentsContentView {
	NSString * textStyle;
	DeviceHelper * deviceHelper = [DeviceHelper getInstance];
	NSDateFormatter * dateFormat = [[NSDateFormatter alloc] init];
	
	[dateFormat setDateFormat:@"yyyy-MM-dd HH:mm"];
	
	if ([deviceHelper isiPad]) {
		textStyle = appConfig.commentsTextStyleIPad;
	} else {
		textStyle = appConfig.commentsTextStyleIPhone;
	}
	
	NSMutableString * commentsText = [NSMutableString stringWithString:textStyle];
	if (trainingHistories.count > 0) {
		for (TrainingHistory * trainingHistory in trainingHistories) {
			[commentsText appendFormat:@"<p>%@<br>%@</p>", [dateFormat stringFromDate:trainingHistory.lastUpdated], trainingHistory.comment];
		}
		[commentsContentView loadHTMLString:commentsText baseURL:nil];
	} else {
		[commentsText appendString:NSLocalizedString(@"ResultAndComments.NoComment", @"")];
		[commentsContentView loadHTMLString:commentsText baseURL:nil];
	}
}

@end
