//
//  TrainingFinishViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 11/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingFinishViewController.h"
#import "MobileLoginSessionManager.h"
#import "CacheManager.h"
#import "LoginToken.h"
#import "Training.h"
#import "TrainingStep.h"
#import "WebServiceClient.h"
#import "CocoaLumberjackConfig.h"

#define CLICKED_CANCEL_BUTTON 0
#define CLICKED_RETRY_BUTTON 1

#define INVALID_LOGIN_TOKEN_ALERT 103
#define SUBMIT_RESULT_ERROR_ALERT 500

@interface TrainingFinishViewController ()

- (void)dismiss;
- (void)submitToServer;

@end

@implementation TrainingFinishViewController

@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	cacheManager = [CacheManager getInstance];
	loginSessionManager = [MobileLoginSessionManager getInstance];
	/*****
		The comment variable null-checking is necessary, as viewDidLoad is only called after the view appears
		This checking make sure the value received from TrainingCommentVC is not overwritten
	 *****/
	if (comment == nil) {
		DDLogWarn(@"! TrainingFinishVC: comment is not set, change to empty string");
		comment = @"";
	}
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
	DDLogInfo(@"! TrainingFinishVC: viewWillAppear");
	loginToken = loginSessionManager.loginToken;
	[self updateDialogText];
	[super viewWillAppear:animated];
}

#pragma button click handling
- (IBAction)tappedContinueButton:(id)sender {
	[self playClickSound];
	
	DDLogInfo(@"! submit to server?%@", loginToken.isTrainer?@"YES":@"NO");
	if (loginToken.isTrainer && [cacheManager areAllTrainingStepsRated]) {
		[self submitToServer];
	} else {
		[self dismiss];
	}
}

#pragma alert view related
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
	switch (alertView.tag) {
		case INVALID_LOGIN_TOKEN_ALERT: {
			[self.navigationController popToRootViewControllerAnimated:YES];
			break;
		}
		case SUBMIT_RESULT_ERROR_ALERT:
		default: {
			switch (buttonIndex) {
				case CLICKED_CANCEL_BUTTON: {
					[self dismiss];
					break;
				}
				case CLICKED_RETRY_BUTTON: {
					[self submitToServer];
					break;
				}
			}
			break;
		}
	}
}

#pragma web service related methods
- (void)submitToServer {
	DDLogInfo(@"! TrainingFinishVC: submitToServer; trainingId=%d; comment=%@", cacheManager.currentTraining.trainingId, comment);
	WebServiceClient * wsClient = [WebServiceClient getInstance];
	
	[self showProgressHUD];
	
	for (TrainingStep * step in cacheManager.currentTrainingSteps) {
		DDLogInfo(@"! step title=%@, step rating=%d", step.text, step.rating);
	}
	
	[wsClient submitTrainingResultWithLoginToken:loginToken trainingId:cacheManager.currentTraining.trainingId trainingSteps:cacheManager.currentTrainingSteps comment:comment success:^() {
		[self hideProgressHUD];
		
		[self dismiss];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
		UIAlertView * alertView;
		
		DDLogError(@"! failed to submit training result to server; errorCode=%d; errorMessage=%@", errorCode, errorMessage);
		[self hideProgressHUD];
		
		switch (errorCode) {
			case ERROR_CODE_INVALID_MOBILE_USER:
			case ERROR_CODE_INVALID_OR_EXPIRED_TOKEN: {
				loginSessionManager.loginToken = nil;
				alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Login.Failure.InvalidOrExpiredToken", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles:nil];
				alertView.tag = INVALID_LOGIN_TOKEN_ALERT;
				break;
			}
			default: {
				alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"TrainingFinish.Submit.Error.RetryPrompt", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles:NSLocalizedString(@"Retry", @""), nil];
				alertView.tag = SUBMIT_RESULT_ERROR_ALERT;
				break;
			}
		}
		
		[alertView show];

	}];
}

#pragma misc methods
- (void)dismiss {
	[self.navigationController popViewControllerAnimated:NO];
	[delegate dismissedTrainingFinishView];
}

- (void)updateDialogText {
	DDLogInfo(@"! is trainer?%@; username=%@", loginToken.isTrainer?@"YES":@"NO", loginToken.username);
	DDLogInfo(@"! are all training steps rated?%@", [cacheManager areAllTrainingStepsRated]?@"YES":@"NO");
	trainingTitleLabel.text = cacheManager.currentTraining.title;
	if (loginToken.isTrainer && [cacheManager areAllTrainingStepsRated]) {
        if([cacheManager averageRating]==0){
            dialogTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"TrainingFinish.DialogText.Rated.StringFormat", @""), [cacheManager averageRating]];
        }
        if([cacheManager averageRating]<2.5){
            dialogTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"TrainingFinish.DialogText.Rated.StringFormat.OneToTwo.Star", @""), [cacheManager averageRating]];
        }
        else if([cacheManager averageRating]<4.5){
            dialogTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"TrainingFinish.DialogText.Rated.StringFormat.ThreeToFour.Star", @""), [cacheManager averageRating]];
        }
        else if([cacheManager averageRating]>=4.5){
            dialogTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"TrainingFinish.DialogText.Rated.StringFormat.Five.Star", @""), [cacheManager averageRating]];
        }
            
	} else {
		dialogTextLabel.text = NSLocalizedString(@"TrainingFinish.DialogText.Unrated.String", @"");
	}
}

#pragma TrainingCommentDelegate
- (void)didFinishComment:(NSString *)_comment {
	DDLogInfo(@"! TrainingFinishVC: didFinishComment:%@", _comment);
	comment = _comment.copy;
}

@end
