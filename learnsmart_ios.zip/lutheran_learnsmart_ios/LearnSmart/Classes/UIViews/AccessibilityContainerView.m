//
//  AccessibilityContainerView.m
//  LearnSmart
//
//  Created by Jack Cheung on 27/2/14.
//  Copyright (c) 2014 Cloud Pillar Limited. All rights reserved.
//

#import "AccessibilityContainerView.h"

@implementation AccessibilityContainerView

@synthesize accessibilityElements = _accessibilityElements;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma accessibility handling
- (NSMutableArray *)accessibilityElements {
    @synchronized(self) {
        if (!_accessibilityElements) {
            _accessibilityElements = [NSMutableArray array];
        }
        return _accessibilityElements;
    }
}

- (NSInteger)accessibilityElementCount {
    return self.accessibilityElements.count;
}

- (id)accessibilityElementAtIndex:(NSInteger)index {
    return [self.accessibilityElements objectAtIndex:index];
}

- (NSInteger)indexOfAccessibilityElement:(id)element {
    return [self.accessibilityElements indexOfObject:element];
}

- (void)didAddSubview:(UIView *)subview {
    [super didAddSubview:subview];
    if (subview.isAccessibilityElement || [subview isKindOfClass:[UIWebView class]]) {
        [self.accessibilityElements addObject:subview];
        [self.accessibilityElements sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
            NSInteger obj1Tag = ((UIView *)obj1).tag;
            NSInteger obj2Tag = ((UIView *)obj2).tag;
            if (obj1Tag < obj2Tag) {
                return NSOrderedAscending;
            } else if (obj1Tag > obj2Tag) {
                return NSOrderedDescending;
            }
            return NSOrderedSame;
        }];
    }
}

@end
