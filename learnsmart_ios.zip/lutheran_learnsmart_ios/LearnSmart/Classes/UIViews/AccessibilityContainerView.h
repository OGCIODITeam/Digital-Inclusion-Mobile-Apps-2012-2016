//
//  AccessibilityContainerView.h
//  LearnSmart
//
//  Created by Jack Cheung on 27/2/14.
//  Copyright (c) 2014 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccessibilityContainerView : UIView

@property (nonatomic, strong) NSMutableArray * accessibilityElements;

@end
