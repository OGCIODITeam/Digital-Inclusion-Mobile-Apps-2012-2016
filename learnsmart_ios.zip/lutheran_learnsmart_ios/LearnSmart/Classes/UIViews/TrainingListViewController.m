//
//  TrainingListViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 7/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingListViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "AppConfig.h"
#import "WebServiceClient.h"
#import "DeviceHelper.h"
#import "LoginToken.h"
#import "MobileLoginSessionManager.h"
#import "CacheManager.h"
#import "CarouselItemView.h"
#import "Training.h"
#import "TrainingFrontViewController.h"
#import "TrainingProfileViewController.h"
#import "CocoaLumberjackConfig.h"

#define INVALID_MOBILE_USER_ALERT 102
#define INVALID_LOGIN_TOKEN_ALERT 103

@implementation iCarousel(Accessibility)

- (NSString *)accessibilityLabel {
    NSMutableString * labelText = [NSMutableString string];
    NSUInteger numItems = [self.dataSource numberOfItemsInCarousel:self];
    CarouselItemView * view = [CarouselItemView new];
    for (NSUInteger i=0; i<numItems; i++) {
        view = (CarouselItemView *)[self.dataSource carousel:self viewForItemAtIndex:i reusingView:view];
        [labelText appendFormat:@"%@\n", view.accessibilityLabel];
    }
    return labelText;
}

@end

@interface TrainingListViewController ()

- (void)initCarousel;
- (void)initGirlAnimation;
- (void)loadTrainingList:(NSInteger)catId;
- (void)loadTrainingListWithLoginToken;
- (void)scrollToLastSelectedItem;
- (void)startCarouselSoundEffect;
- (void)startGirlAnimation;
- (void)stopCarouselSoundEffect;
- (void)stopGirlAnimation;
- (void)updateButtonsVisibilities;

@end

@implementation TrainingListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
		selectedCatId = 0;
    }
    return self;
}

- (id)initWithCategory:(NSUInteger)catId {
	NSString * nibName = nil;
		
	deviceHelper = [DeviceHelper getInstance];
	
	if ([deviceHelper isiPad]) {
		nibName = @"TrainingListView_iPad";
	} else {
		nibName = @"TrainingListView_iPhone";
	}
	
	self = [super initWithNibName:nibName bundle:nil];
	if (self) {
		// Custom initialization
		selectedCatId = catId;
		loginToken = nil;
	}
	return self;
}

- (id)initWithLoginToken:(LoginToken *)_loginToken {
	NSString * nibName = nil;
		
	deviceHelper = [DeviceHelper getInstance];
	
	if ([deviceHelper isiPad]) {
		nibName = @"TrainingListView_iPad";
	} else {
		nibName = @"TrainingListView_iPhone";
	}
	
	self = [super initWithNibName:nibName bundle:nil];
	if (self) {
		// Custom initialization
		selectedCatId = 0;
		loginToken = _loginToken;
	}
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	deviceHelper = [DeviceHelper getInstance];
	cacheManager = [CacheManager getInstance];
    currentItemIdx = 0;
	loginSessionManager = [MobileLoginSessionManager getInstance];
	[self initCarousel];
	[self initGirlAnimation];
}

- (void)viewWillAppear:(BOOL)animated {
	[self startGirlAnimation];
	[super viewWillAppear:animated];
	
	[self updateButtonsVisibilities];
	if (selectedCatId > 0) {
		[self loadTrainingList:selectedCatId];
	} else {
		[self loadTrainingListWithLoginToken];
	}
}

- (void)viewWillDisappear:(BOOL)animated {
	[self stopGirlAnimation];
	[self stopCarouselSoundEffect];
	[super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma girl animation
- (void)initGirlAnimation {
	AppConfig * appConfig = [AppConfig getInstance];
	NSMutableArray * animatedGirlFrames = [NSMutableArray array];
	NSString * deviceSuffix;
	
	if ([deviceHelper isiPad]) {
		deviceSuffix = @"ipad";
	} else {
		deviceSuffix = @"iphone";
	}
	
	for (int i=1; i<=appConfig.numAnimatedGirlFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", i, deviceSuffix]]];
	}
	
	for (int i=1; i<appConfig.numAnimatedGirlPauseFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", appConfig.numAnimatedGirlFrames, deviceSuffix]]];
	}
	
	animatedGirlView.animationImages = animatedGirlFrames;
	animatedGirlView.animationDuration = 1.50f;
	animatedGirlView.animationRepeatCount = INFINITY;
}

- (void)startGirlAnimation {
	[animatedGirlView startAnimating];
}

- (void)stopGirlAnimation {
	[animatedGirlView stopAnimating];
}

#pragma data related
- (void)loadTrainingList:(NSInteger)catId {
	WebServiceClient * wsClient = [WebServiceClient getInstance];
	
	[self playClickSound];
	
	trainings = [cacheManager getCachedPublicTrainingsWithCatId:catId];
	DDLogInfo(@"! TrainingListVC: loaded %d trainings from cache; catId=%d", trainings.count, catId);
	[carouselView reloadData];
    [self scrollToLastSelectedItem];
	
	if ([cacheManager isPublicTrainingCacheExpiredWithCatId:catId]) {
		DDLogInfo(@"! public training for catId=%d is expired; fetch update from web", catId);
		[self showProgressHUD];
		[wsClient getTrainingsWithCategoryId:catId success:^(NSMutableArray * _trainings) {
			[self hideProgressHUD];
			
			trainings = _trainings;
			[carouselView reloadData];
			[cacheManager cacheTrainings:_trainings withCategoryId:catId];
            [self scrollToLastSelectedItem];
		} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
			DDLogError(@"! failed to training list with catId=%d; erroCode=%d; error=%@", catId, errorCode, errorMessage);
			
			[self hideProgressHUD];
			
			if (isHttpError) {
				errorMessage = NSLocalizedString(@"NetworkError.InternetConnectionFailure", @"");
			}
			
			switch (errorCode) {
				case ERROR_CODE_INPUT_ERROR:
				case ERROR_CODE_INVALID_MOBILE_USER:
					errorMessage = NSLocalizedString(@"Login.Failure.InvalidMobileUser", @"");
					break;
				case ERROR_CODE_INVALID_OR_EXPIRED_TOKEN: {
					loginSessionManager.loginToken = nil;
					errorMessage = NSLocalizedString(@"Login.Failure.InvalidOrExpiredToken", @"");
					break;
				}
				default:
					break;
			}
			
			UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alertView show];
		}];
	} else {
		DDLogInfo(@"! public training is not expired; load from cache");
	}
}

- (void)loadTrainingListWithLoginToken {
	WebServiceClient * wsClient = [WebServiceClient getInstance];
	
	[self playClickSound];
	
	trainings = [cacheManager getCachedTrainingsWithLoginToken:loginToken];
	DDLogInfo(@"! TrainingListVC: loaded %d trainings from cache; username=%@", trainings.count, loginToken.username);
	[carouselView reloadData];
    [self scrollToLastSelectedItem];
	
	[self showProgressHUD];
	[wsClient getTrainingsWithLoginToken:loginToken success:^(NSMutableArray * _trainings) {
		[self hideProgressHUD];
		
		trainings = _trainings;
        if (currentItemIdx >= trainings.count) {
            currentItemIdx = 0;
        }
		[carouselView reloadData];
		[cacheManager cacheTrainings:trainings withLoginToken:loginToken];
        [self scrollToLastSelectedItem];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
		DDLogError(@"! failed to load training list with loginToken; username=%@; erroCode=%d; error=%@", loginToken.username, errorCode, errorMessage);
		NSInteger tag = 0;
		
		[self hideProgressHUD];
		
		if (isHttpError) {
			errorMessage = NSLocalizedString(@"NetworkError.InternetConnectionFailure", @"");
		}
		
		switch (errorCode) {
			case ERROR_CODE_INPUT_ERROR:
			case ERROR_CODE_INVALID_MOBILE_USER:
				errorMessage = NSLocalizedString(@"Login.Failure.InvalidMobileUser", @"");
				tag = INVALID_MOBILE_USER_ALERT;
				break;
			case ERROR_CODE_INVALID_OR_EXPIRED_TOKEN: {
				loginSessionManager.loginToken = nil;
				errorMessage = NSLocalizedString(@"Login.Failure.InvalidOrExpiredToken", @"");
				tag = INVALID_LOGIN_TOKEN_ALERT;
				break;
			}
			default:
				break;
		}
		
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertView.tag = tag;
		[alertView show];
	}];
}

#pragma iCarousel related methods
- (void)initCarousel {
	NSBundle * mainBundle = [NSBundle mainBundle];
	NSURL * scrollingSoundUrl = [mainBundle URLForResource:@"scrolling" withExtension:@"mp3"];
	NSError * error = nil;
	
	carouselView.type = iCarouselTypeRotary;
	carouselView.vertical = YES;
	
	carouselSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:scrollingSoundUrl error:&error];
	carouselSoundPlayer.numberOfLoops = INFINITY;
	[carouselSoundPlayer prepareToPlay];
	if (error) {
		DDLogError(@"! TrainingListVC: failed to init carousel scrolling sound; error=%@", error.description);
	}
}

- (void)carouselWillBeginDragging:(iCarousel *)carousel {
	if (carousel.numberOfItems > 0) {
		[self startCarouselSoundEffect];
	}
}

- (void)carouselDidEndDecelerating:(iCarousel *)carousel {
	[self stopCarouselSoundEffect];
}

- (void)carouselDidEndScrollingAnimation:(iCarousel *)carousel {
	[self stopCarouselSoundEffect];
}

- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel {
	return trainings.count;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index reusingView:(UIView *)view {
	Training * training = [trainings objectAtIndex:index];
	
	if (view == nil) {
		CarouselItemView * carouselItemView = [[CarouselItemView alloc] initWithTitle:training.title theme:index % 6 + 1];
		view = carouselItemView;
	} else {
		CarouselItemView * carouselItemView = (CarouselItemView *)view;
		[carouselItemView updateTitle:training.title theme:index % 6 + 1];
	}
	
	return view;
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value {
	switch (option) {
		case iCarouselOptionArc: {
			if ([deviceHelper isiPad]) {
				return 2.9;
			} else {
				return 2.3;
			}
		}
		case iCarouselOptionCount: {
			return 10;
		}
		case iCarouselOptionFadeMin:
			return -0.3;
		case iCarouselOptionFadeMax:
			return 0.3;
		case iCarouselOptionFadeRange:
			return 2.0;
		case iCarouselOptionRadius: {
			if ([deviceHelper isiPad]) {
				return 470;
			} else {
				return 349;
			}
		}
		case iCarouselOptionSpacing: {
			return 1;
		}
		case iCarouselOptionWrap: {
			return 0;
		}
		default:
			return value;
	}
}

#pragma Carousel sound effects
- (void)startCarouselSoundEffect {
	DDLogInfo(@"! TrainingList: startCarouselSoundEffect");
//	[carouselSoundPlayer playAtTime:0.5f];
	[carouselSoundPlayer play];
}

- (void)stopCarouselSoundEffect {
	if ([carouselSoundPlayer isPlaying]) {
		[carouselSoundPlayer stop];
	}
}

#pragma UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	switch (alertView.tag) {
		case INVALID_MOBILE_USER_ALERT:
		case INVALID_LOGIN_TOKEN_ALERT: {
			[self.navigationController popViewControllerAnimated:YES];
			break;
		}
		default:
			break;
	}
}

#pragma UIButton tapping handling
- (IBAction)tappedGoToButton:(id)sender {
	[self playClickSound];
	
	if (carouselView.currentItemIndex < 0) {
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Training.List.NoTrainingSelected", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
    
    currentItemIdx = carouselView.currentItemIndex;
	
	TrainingFrontViewController * trainingFrontVC;
	Training * selectedTraining = [trainings objectAtIndex:carouselView.currentItemIndex];
	[self playClickSound];
	
	trainingFrontVC = [[TrainingFrontViewController alloc] initWithTraining:selectedTraining];
		
	[self.navigationController pushViewController:trainingFrontVC animated:YES];
}

- (IBAction)tappedHomeButtom:(id)sender {
	[self playClickSound];
	
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)tappedProfileButton:(id)sender {
	TrainingProfileViewController * trainingStepVC;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		trainingStepVC = [[TrainingProfileViewController alloc] initWithNibName:@"TrainingProfileView_iPad" bundle:nil];
	} else {
		trainingStepVC = [[TrainingProfileViewController alloc] initWithNibName:@"TrainingProfileView_iPhone" bundle:nil];
	}
	
	[self.navigationController pushViewController:trainingStepVC animated:YES];
}

#pragma misc
- (void)scrollToLastSelectedItem {
    if (currentItemIdx >= trainings.count) {
        currentItemIdx = 0;
    }
	[carouselView scrollToItemAtIndex:currentItemIdx animated:NO];
}

- (void)updateButtonsVisibilities {
	if (loginToken == nil) {
		profileButton.hidden = YES;
	} else {
		profileButton.hidden = NO;
	}
}

@end
