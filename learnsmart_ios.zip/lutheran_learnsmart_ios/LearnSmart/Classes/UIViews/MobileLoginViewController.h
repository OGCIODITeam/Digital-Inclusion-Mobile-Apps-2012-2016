//
//  MobileLoginViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WSAbstractUIViewController.h"

@class DeviceHelper, WebServiceClient;

@interface MobileLoginViewController : WSAbstractUIViewController<UIGestureRecognizerDelegate, UITextFieldDelegate> {
	DeviceHelper * deviceHelper;
	IBOutlet UIButton * forgetPasswordButton;
	IBOutlet UIImageView * loginIdLabelView;
	IBOutlet UITextField * loginIdText;
	IBOutlet UIButton * loginButton;
	IBOutlet UIButton * logoutButton;
	IBOutlet UIImageView * passwordLabelView;
	IBOutlet UITextField * passwordText;
	WebServiceClient * wsClient;
}

- (void)shiftViewUpByPixel:(CGFloat)pixel;
- (void)shiftViewDownByPixel:(CGFloat)pixel;

- (IBAction)tappedBackButton:(id)sender;
- (IBAction)tappedForgetPasswordButton:(id)sender;
- (IBAction)tappedLogoutButton:(id)sender;
- (IBAction)tappedOKButton:(id)sender;

@end
