//
//  AboutUsViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WSAbstractUIViewController.h"

@class AppConfig, CacheManager, DeviceHelper, WebServiceClient, AboutUs;

@interface AboutUsViewController : WSAbstractUIViewController {
	IBOutlet UIWebView * aboutUsWebView;
	AppConfig * appConfig;
	CacheManager * cacheManager;
	DeviceHelper * deviceHelper;
	IBOutlet UIWebView * newsWebView;
	WebServiceClient * wsClient;
	AboutUs * aboutUs;
}

- (IBAction)tappedBackButton:(id)sender;

@end
