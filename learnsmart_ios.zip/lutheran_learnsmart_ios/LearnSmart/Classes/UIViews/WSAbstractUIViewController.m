//
//  WSAbstractUIViewController.m
//  LearnSmart
//	This is where all networked UIViewController is based
//
//  Created by Jack Cheung on 4/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"
#import "AppConfig.h"
#import "SoundPlayer.h"
#import <MBProgressHUD/MBProgressHUD.h>

@interface WSAbstractUIViewController ()
@end

@implementation WSAbstractUIViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// default to auto rotate on landscape mode
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma UIWebView related

- (void)removeShadowFromWebView:(UIWebView *)webView {
	for (UIView * webSubView in webView.subviews) {
		if (![webSubView isKindOfClass:[UIScrollView class]]) {
			continue;
		}
		
		for (UIView * shadowView in webSubView.subviews) {
			if ([shadowView isKindOfClass:[UIImageView class]]) {
				shadowView.hidden = YES;
			}
		}
	}
}

#pragma progressHUD related
- (void)hideProgressHUD {
	[MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

- (void)showProgressHUD {
	[MBProgressHUD showHUDAddedTo:self.view animated:YES];
}

#pragma sound effects
- (void)playClickSound {
	AppConfig * appConfig = [AppConfig getInstance];
	[[SoundPlayer getInstance] playAudio:appConfig.clickSoundRelativePath];
}

@end
