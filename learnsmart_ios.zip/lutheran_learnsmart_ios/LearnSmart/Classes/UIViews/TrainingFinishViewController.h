//
//  TrainingFinishViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 11/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"
#import "TrainingCommentViewController.h"

@protocol TrainingFinishViewDelegate

- (void)dismissedTrainingFinishView;

@end

@class CacheManager, LoginToken, MobileLoginSessionManager;

@interface TrainingFinishViewController : WSAbstractUIViewController<UIAlertViewDelegate, TrainingCommentDelegate> {
	CacheManager * cacheManager;
	IBOutlet UILabel * dialogTextLabel;
	NSString * comment;
	MobileLoginSessionManager * loginSessionManager;
	LoginToken * loginToken;
	IBOutlet UILabel * trainingTitleLabel;
}

@property (nonatomic, strong) id<TrainingFinishViewDelegate> delegate;

- (void)updateDialogText;
- (IBAction)tappedContinueButton:(id)sender;

@end
