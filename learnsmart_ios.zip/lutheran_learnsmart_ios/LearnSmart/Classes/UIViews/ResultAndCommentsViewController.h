//
//  ResultAndCommentsViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 12/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"

@class AppConfig, CacheManager, MobileLoginSessionManager, WebServiceClient;

@interface ResultAndCommentsViewController : WSAbstractUIViewController {
	AppConfig * appConfig;
	CacheManager * cacheManager;
	IBOutlet UIWebView * commentsContentView;
	MobileLoginSessionManager * loginSessionManager;
	NSMutableArray * trainingHistories;
	NSInteger trainingId;
	WebServiceClient * wsClient;
}

- (id)initWithTrainingId:(NSInteger)trainingId;
- (void)initWebView;
- (IBAction)tappedBackButton:(id)sender;

@end
