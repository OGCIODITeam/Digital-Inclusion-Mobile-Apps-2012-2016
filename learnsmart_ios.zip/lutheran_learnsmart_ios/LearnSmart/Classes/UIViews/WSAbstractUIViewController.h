//
//  WSAbstractUIViewController.h
//  LearnSmart
//	This is where all networked UIViewController is based
//
//  Created by Jack Cheung on 4/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSAbstractUIViewController : UIViewController

- (void)hideProgressHUD;
- (void)playClickSound;
- (void)removeShadowFromWebView:(UIWebView *)webView;
- (void)showProgressHUD;

@end
