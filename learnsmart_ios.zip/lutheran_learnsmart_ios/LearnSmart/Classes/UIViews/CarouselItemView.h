//
//  CarouselItemView.h
//  LearnSmart
//
//  Created by Jack Cheung on 11/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarouselItemView : UIView {
	IBOutlet UIImageView * backgroundImage;
	IBOutlet UILabel * textLabel;
}

@property (nonatomic, strong) NSString * accessibilityLabel;

- (id)initWithTitle:(NSString *)title theme:(NSUInteger)themeIdx;
- (void)updateTitle:(NSString *)title theme:(NSUInteger)themeIdx;

@end
