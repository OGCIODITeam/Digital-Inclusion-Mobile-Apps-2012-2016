//
//  TrainingStepRatingViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 7/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingStepRatingViewController.h"
#import "CacheManager.h"
#import "DeviceHelper.h"
#import "CocoaLumberjackConfig.h"
#import "TrainingStep.h"

@interface TrainingStepRatingViewController ()

- (void)updateRatingSelection:(UIButton *)selectedRadioButton;

@end

@implementation TrainingStepRatingViewController

@synthesize delegate;

- (id)initWithSelection:(NSInteger)_selectedStars delegate:(id)_delegate {
	NSString * nibName = nil;
	
	deviceHelper = [DeviceHelper getInstance];
	if ([deviceHelper isiPad]) {
		nibName = @"TrainingStepRatingView_iPad";
	} else {
		nibName = @"TrainingStepRatingView_iPhone";
	}

	self = [super initWithNibName:nibName bundle:nil];
	if (self) {
		self.delegate = _delegate;
		selectedStars = _selectedStars;
	}
	return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	cacheManager = [CacheManager getInstance];
	deviceHelper = [DeviceHelper getInstance];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma star radio button related
- (void)updateRatingSelection:(UIButton *)selectedRadioButton {
	NSString * selectedButtonName = nil;
	NSString * unselectedButtonName = nil;
	
	selectedStars = 0;
	
	if ([deviceHelper isiPad]) {
		selectedButtonName = @"radio_button_selected_ipad";
		unselectedButtonName = @"radio_button_unselected_ipad";
	} else {
		selectedButtonName = @"radio_button_selected_iphone";
		unselectedButtonName = @"radio_button_unselected_iphone";
	}
	
	for (UIButton * radioButton in radioButtons) {
		if ([radioButton isEqual:selectedRadioButton]) {
			[radioButton setImage:[UIImage imageNamed:selectedButtonName] forState:UIControlStateNormal];
			selectedStars = radioButton.tag;
		} else {
			[radioButton setImage:[UIImage imageNamed:unselectedButtonName] forState:UIControlStateNormal];
		}
	}
}

#pragma UIButton tapping handling
- (IBAction)tappedCancelButton:(id)sender {
	[self playClickSound];
	
	[self dismiss];
}

- (IBAction)tappedFinishButton:(id)sender {
	[self playClickSound];
	
	[cacheManager getCurrentTrainingStep].rating = selectedStars;
	
	if (selectedStars < 1) {
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Training.Rating.MustSelectStars", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
		[alertView show];
		return;
	}
	
	[self dismiss];
}

- (IBAction)tappedRadioButton:(id)sender {
	if ([sender isKindOfClass:[UIButton class]]) {
		[self updateRatingSelection:sender];
	} else {
		DDLogWarn(@"! expected UIButton class on tappedRadioButton sender, but found %@", [[sender class] description]);
	}
}

#pragma misc
- (void)dismiss {
	[self.navigationController popViewControllerAnimated:YES];
}

@end
