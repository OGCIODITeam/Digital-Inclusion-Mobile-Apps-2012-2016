//
//  AboutUsViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "AboutUsViewController.h"
#import "WebServiceClient.h"
#import "AboutUs.h"
#import "AppConfig.h"
#import "CacheManager.h"
#import "DeviceHelper.h"
#import "NewsItem.h"
#import "CocoaLumberjackConfig.h"

@interface AboutUsViewController ()

- (void)initWebView;
- (void)initWSClient;
- (void)loadAboutUsInfo;
- (void)updateContentView;

@end

@implementation AboutUsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	appConfig = [AppConfig getInstance];
	cacheManager = [CacheManager getInstance];
	deviceHelper = [DeviceHelper getInstance];
	[self initWebView];
	[self initWSClient];
}

- (void)viewWillAppear:(BOOL)animated {
	[self loadAboutUsInfo];
	[super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initWebView {
	[self removeShadowFromWebView:aboutUsWebView];
	[self removeShadowFromWebView:newsWebView];
}

- (void)initWSClient {
	wsClient = [WebServiceClient getInstance];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma About Us fetching
- (void)loadAboutUsInfo {
	aboutUs = [cacheManager getCachedAboutUs];
    if (aboutUs != nil) {
        [self updateContentView];
    }

	if (cacheManager.isAboutUsCacheExpired) {
		DDLogInfo(@"! about us cache is expired; fetch update from web");
		[self showProgressHUD];
		
		[wsClient getAboutUsWithSuccess:^(AboutUs * _aboutUs){
			
			[self hideProgressHUD];
			aboutUs = _aboutUs;
			
			[self updateContentView];
			
			[cacheManager cacheAboutUs:_aboutUs];
		} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
			DDLogError(@"! failed to retrieve aboutUs info; errorCode=%d; errorMessage=%@", errorCode, errorMessage);
			[self hideProgressHUD];
			UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
			[alertView show];
		}];
	}
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	[self playClickSound];
	[self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)shouldGroupAccessibilityChildren{
    return YES;
}

#pragma misc
- (void)updateContentView {
	NSString * textStyle;
	NSDateFormatter * dateFormat = [[NSDateFormatter alloc] init];
	NSBundle * mainBundle = [NSBundle mainBundle];
	
	[dateFormat setDateFormat:@"dd/MM/yyyy"];
	
	if ([deviceHelper isiPad]) {
		textStyle = appConfig.aboutUsTextStyleIPad;
	} else {
		textStyle = appConfig.aboutUsTextStyleIPhone;
	}
	
	NSMutableString * aboutUsWebContent = [NSMutableString stringWithString:aboutUs.aboutUsText];
    if ([deviceHelper isiPad]) {
        [aboutUsWebContent replaceOccurrencesOfString:@"%cSSPath%" withString:[mainBundle URLForResource:@"about_us_ipad" withExtension:@"css"].absoluteString options:NSLiteralSearch range:NSMakeRange(0, aboutUsWebContent.length)];
    } else {
        [aboutUsWebContent replaceOccurrencesOfString:@"%cSSPath%" withString:[mainBundle URLForResource:@"about_us_iphone" withExtension:@"css"].absoluteString options:NSLiteralSearch range:NSMakeRange(0, aboutUsWebContent.length)];
    }
    [aboutUsWebView loadHTMLString:aboutUsWebContent baseURL:[NSURL fileURLWithPath:mainBundle.bundlePath]];
	
	NSMutableString * newsContent = [[NSMutableString alloc] initWithString:textStyle];
    [newsContent appendFormat:@"<section><h1 class=\"columnHeader\">%@</h1></section>\n", NSLocalizedString(@"AboutUs.OrgNews.Title", @"")];
	for (NewsItem * newsItem in aboutUs.newsItems) {
		DDLogInfo(@"newsItem; title=%@; description=%@; priority=%d; lastUpdated=%@", newsItem.title, newsItem.description, newsItem.priority, [newsItem.lastUpdated description]);
		[newsContent appendFormat:@"<p>%@<br><span class=\"timestamp\">%@</span><br><br><span class=\"articleText\">%@</span></p>", newsItem.title, [dateFormat stringFromDate:newsItem.lastUpdated], newsItem.description];
	}
	
    NSLog(@"! news content: %@", newsContent);
	[newsWebView loadHTMLString:newsContent baseURL:nil];
}

@end
