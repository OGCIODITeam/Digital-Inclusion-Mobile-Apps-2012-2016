//
//  TrainingDetailsViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 12/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"

@class AppConfig, CacheManager, DeviceHelper, MobileLoginSessionManager, TrainingDetails, WebServiceClient;

@interface TrainingDetailsViewController : WSAbstractUIViewController {
	AppConfig * appConfig;
	CacheManager * cacheManager;
	DeviceHelper * deviceHelper;
	IBOutlet UIWebView * detailsContentView;
	MobileLoginSessionManager * loginSessionManager;
	TrainingDetails * trainingDetails;
	NSInteger trainingId;
	WebServiceClient * wsClient;
}

- (id)initWithTrainingId:(NSInteger)trainingId;
- (IBAction)tappedBackButton:(id)sender;

@end
