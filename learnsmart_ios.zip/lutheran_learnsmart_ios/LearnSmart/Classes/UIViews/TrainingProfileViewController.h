//
//  TrainingProfileViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 4/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"

@class CacheManager, DeviceHelper, HallOfFames, MobileLoginSessionManager, TraineeHOFViewController, WebServiceClient;

@interface TrainingProfileViewController : WSAbstractUIViewController<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UIWebViewDelegate> {
	NSMutableArray * buddyIcons;
	CacheManager * cacheManager;
	IBOutlet UIWebView * chartView;
	DeviceHelper * deviceHelper;
	HallOfFames * hallOfFames;
	UIImagePickerController * imagePickerVC;
	MobileLoginSessionManager * loginSessionManager;
	UIPopoverController * popOverVC;
	IBOutlet UIActivityIndicatorView * profileImageLoadingIndicatorView;
	IBOutlet UIImageView * profileImageView;
	TraineeHOFViewController * traineeHOFView;
	WebServiceClient * wsClient;
}

- (IBAction)tappedBackButton:(id)sender;
- (IBAction)tappedReloadChartButton:(id)sender;
- (IBAction)tappedUpdateProfileImageButton:(id)sender;

@end
