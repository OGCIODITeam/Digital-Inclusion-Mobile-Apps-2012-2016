//
//  TrainingListViewController.h
//  LearnSmart
//
//  Created by Jack Cheung on 7/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "WSAbstractUIViewController.h"
#import <iCarousel/iCarousel.h>

@class AVAudioPlayer, CacheManager, DeviceHelper, LoginToken, MobileLoginSessionManager;

@interface TrainingListViewController : WSAbstractUIViewController<iCarouselDataSource, iCarouselDelegate, UIAlertViewDelegate> {
	IBOutlet UIImageView * animatedGirlView;
	CacheManager * cacheManager;
	AVAudioPlayer * carouselSoundPlayer;
	IBOutlet iCarousel * carouselView;
    NSInteger currentItemIdx;
	DeviceHelper * deviceHelper;
	MobileLoginSessionManager * loginSessionManager;
	LoginToken * loginToken;
	IBOutlet UIButton * profileButton;
	NSUInteger selectedCatId;
	NSMutableArray * trainings;
}

- (id)initWithCategory:(NSUInteger)catId;
- (id)initWithLoginToken:(LoginToken *)loginToken;
- (IBAction)tappedHomeButtom:(id)sender;
- (IBAction)tappedGoToButton:(id)sender;
- (IBAction)tappedProfileButton:(id)sender;

@end
