//
//  MobileLoginViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "MobileLoginViewController.h"
#import "CacheManager.h"
#import "MobileLoginSessionManager.h"
#import "WebServiceClient.h"
#import "DeviceHelper.h"
#import "LoginToken.h"
#import "CocoaLumberjackConfig.h"

#define SHIFT_DISPLACEMENT_ON_EDITING 0
#define PASSWORD_SHIFT_ADD_DISPLACEMENT_ON_EDITING_IPAD 128
#define PASSWORD_SHIFT_ADD_DISPLACEMENT_ON_EDITING_IPHONE 61

@interface MobileLoginViewController ()

- (void)clearLoginSession;
- (void)updateLoginViewVisability;

@end

@implementation MobileLoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)initBackgroundGesture {
	UITapGestureRecognizer * gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    gestureRecognizer.delegate = self;
	gestureRecognizer.cancelsTouchesInView = NO;
	[self.view addGestureRecognizer:gestureRecognizer];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	deviceHelper = [DeviceHelper getInstance];
	[self initBackgroundGesture];
	wsClient = [WebServiceClient getInstance];
}

- (void)viewWillAppear:(BOOL)animated {
	[self updateLoginViewVisability];
	[super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

#pragma login session handling
- (void)clearLoginSession {
	[[CacheManager getInstance] removeCachedTrainingProfile];
	[[MobileLoginSessionManager getInstance] setLoginToken:nil];
}

#pragma view visability
- (void)updateLoginViewVisability {
	MobileLoginSessionManager * loginSessionManager = [MobileLoginSessionManager getInstance];
	
	if ([loginSessionManager isLoggedIn]) {
		forgetPasswordButton.hidden = YES;
		loginIdLabelView.hidden = YES;
		loginIdText.hidden = YES;
		loginButton.hidden = YES;
		logoutButton.hidden = NO;
		passwordLabelView.hidden = YES;
		passwordText.hidden = YES;
	} else {
		forgetPasswordButton.hidden = NO;
		loginIdLabelView.hidden = NO;
		loginIdText.hidden = NO;
		loginButton.hidden = NO;
		logoutButton.hidden = YES;
		passwordLabelView.hidden = NO;
		passwordText.hidden = NO;
	}
}

#pragma view shifting & textbox animation processing
- (void)hideKeyboard {
	[loginIdText resignFirstResponder];
	[passwordText resignFirstResponder];
}

- (void)shiftViewDownByPixel:(CGFloat)pixel {
	[UIView animateWithDuration:.3 animations:^{
		CGRect viewFrame = self.view.frame;
		viewFrame.origin.y += pixel;
		self.view.frame = viewFrame;
	}];
}

- (void)shiftViewUpByPixel:(CGFloat)pixel {
	[UIView animateWithDuration:.3 animations:^{
		CGRect viewFrame = self.view.frame;
		viewFrame.origin.y -= pixel;
		self.view.frame = viewFrame;
	}];
}

#pragma NotifcationCenter
- (void)postLoginSuccessfulNotificationWithLoginToken:(LoginToken *)token {
	id notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter postNotificationName:MOBILE_LOGIN_NOTIFICATION_NAME object:token];
}

#pragma UIGestureRecognizer delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    return !([touch.view isKindOfClass:[UIButton class]] || [touch.view isKindOfClass:[UITextView class]]);
}

#pragma UITextField delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
	CGFloat displacement = SHIFT_DISPLACEMENT_ON_EDITING;
	if ([textField isEqual:passwordText]) {
		if ([deviceHelper isiPad]) {
			displacement += PASSWORD_SHIFT_ADD_DISPLACEMENT_ON_EDITING_IPAD;
		} else {
			displacement += PASSWORD_SHIFT_ADD_DISPLACEMENT_ON_EDITING_IPHONE;
		}
	}
	[self shiftViewUpByPixel:displacement];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
	CGFloat displacement = SHIFT_DISPLACEMENT_ON_EDITING;
	if ([textField isEqual:passwordText]) {
		if ([deviceHelper isiPad]) {
			displacement += PASSWORD_SHIFT_ADD_DISPLACEMENT_ON_EDITING_IPAD;
		} else {
			displacement += PASSWORD_SHIFT_ADD_DISPLACEMENT_ON_EDITING_IPHONE;
		}
	}
	[self shiftViewDownByPixel:displacement];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if ([textField isEqual:loginIdText]) {
		[passwordText becomeFirstResponder];
	} else if ([textField isEqual:passwordText]) {
		[passwordText resignFirstResponder];
		[self tappedOKButton:textField];
	}
	
	return NO;
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	
	[self playClickSound];
	
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)tappedForgetPasswordButton:(id)sender {
	NSString * username = loginIdText.text;
	
	[self hideKeyboard];
	[self playClickSound];
	
	[self showProgressHUD];
	[wsClient submitPasswordResetRequest:username success:^(BOOL success) {
		[self hideProgressHUD];
		if (success) {
			loginIdText.text = @"";
			passwordText.text = @"";
			
			UIAlertView * alertview = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Login.PasswordReset.Message", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
			[alertview show];
		}
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString *errorMessage) {
		DDLogError(@"! password reset request failure; errorCode=%d; error=%@", errorCode, errorMessage);
		[self hideProgressHUD];
		
		switch (errorCode) {
			case ERROR_CODE_INPUT_ERROR:
			case ERROR_CODE_INVALID_MOBILE_USER:
				errorMessage = NSLocalizedString(@"Login.Failure.InvalidMobileUser", @"");
				break;
			default:
				break;
		}
		
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
		[alertView show];
	}];
}

- (IBAction)tappedLogoutButton:(id)sender {
	[self playClickSound];
	
	[self clearLoginSession];
	[self updateLoginViewVisability];
}

- (IBAction)tappedOKButton:(id)sender {
	NSString * username = loginIdText.text;
	NSString * password = passwordText.text;
	
	[self playClickSound];
	
	[self showProgressHUD];
	[wsClient loginWithUsername:username password:password success:^(BOOL isLoggedIn, LoginToken * loginToken) {
		[self hideProgressHUD];
		
		if (isLoggedIn) {
			[self clearLoginSession];
			[[MobileLoginSessionManager getInstance] setLoginToken:loginToken];
			[self postLoginSuccessfulNotificationWithLoginToken:loginToken];
		} else {
			UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Login.Failure.Title", @"") message:NSLocalizedString(@"Login.Failure.Message", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
			[alertView show];
		}
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
		DDLogError(@"! login failure; errorCode=%d; error=%@", errorCode, errorMessage);
		
		[self hideProgressHUD];
		
		switch (errorCode) {
			case ERROR_CODE_INPUT_ERROR:
			case ERROR_CODE_INVALID_MOBILE_USER:
            case ERROR_CODE_INVALID_OR_EXPIRED_TOKEN:
				errorMessage = NSLocalizedString(@"Login.Failure.InvalidMobileUser", @"");
				break;
			default:
				break;
		}
	
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
		[alertView show];
	}];
}

@end
