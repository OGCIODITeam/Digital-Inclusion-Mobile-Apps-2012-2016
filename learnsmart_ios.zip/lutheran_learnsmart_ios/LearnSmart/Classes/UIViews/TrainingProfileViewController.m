//
//  TrainingProfileViewController.m
//  LearnSmart
//
//  Created by Jack Cheung on 4/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "TrainingProfileViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "MobileLoginSessionManager.h"
#import "CacheManager.h"
#import "DeviceHelper.h"
#import "HallOfFames.h"
#import "WebServiceClient.h"
#import "CocoaLumberjackConfig.h"
#import "Rank.h"
#import "TrainingCategoryScore.h"
#import "TrainingProfile.h"
#import "TraineeHOFViewController.h"

@interface TrainingProfileViewController ()

- (void)initCacheManager;
- (void)initLoginSessionManager;
- (void)initWebView;
- (void)initWSClient;
- (UIImage *)getResizedImage:(UIImage *)image withSize:(CGSize)size;
- (void)hideProfileImageLoadingIndicator;
- (void)launchImagePicker;
- (void)loadHallOfFames;
- (void)loadTrainingProfile;
- (void)loadTrainingProfileScores;
- (void)removeAllBuddyIcons;
- (void)removeShadowFromWebView:(UIWebView *)webView;
- (void)showProfileImageLoadingIndicator;
- (void)updateBuddyIcons;
- (void)updateChartViewFromCache;
- (void)updateProfileImageFromCache;
- (void)updateTraineeIcon;

@end

@implementation TrainingProfileViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	deviceHelper = [DeviceHelper getInstance];
	[self initCacheManager];
	[self initWSClient];
	[self initLoginSessionManager];
	[self initWebView];
}

- (void)viewWillAppear:(BOOL)animated {
	[self updateProfileImageFromCache];
	[self loadTrainingProfile];
	[super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initCacheManager {
	cacheManager = [CacheManager getInstance];
}

- (void)initLoginSessionManager {
	loginSessionManager = [MobileLoginSessionManager getInstance];
}

- (void)removeShadowFromWebView:(UIWebView *)webView {
	for (UIView * webSubView in webView.subviews) {
		if (![webSubView isKindOfClass:[UIScrollView class]]) {
			continue;
		}
		
		for (UIView * shadowView in webSubView.subviews) {
			if ([shadowView isKindOfClass:[UIImageView class]]) {
				shadowView.hidden = YES;
			}
		}
	}
}

- (void)updateChartViewFromCache {
	NSBundle * mainBundle = [NSBundle mainBundle];
	NSURL * webUrl = [mainBundle URLForResource:@"chart" withExtension:@"html"];
	DDLogInfo(@"! load from url: %@", [webUrl description]);
	[chartView loadRequest:[NSURLRequest requestWithURL:webUrl]];
}

- (void)updateProfileImageFromCache {
	DDLogInfo(@"! update profile image to: %@", cacheManager.trainingProfile.profilePhoto);
	CGSize size = profileImageView.frame.size;
	__unsafe_unretained typeof(self) weakSelfRef = self;

	[self showProfileImageLoadingIndicator];
	[profileImageView setImageWithURL:[NSURL URLWithString:cacheManager.trainingProfile.profilePhoto] placeholderImage:
	 nil options:SDWebImageLowPriority success:^(UIImage *image, BOOL cached) {
		DDLogInfo(@"! TrainingProfileVC: finished loading profile image");
		UIGraphicsBeginImageContextWithOptions(size, NO, .0f);
		[image drawInRect:CGRectMake(0, 0, size.width, size.height)];
		UIImage * resizedImage = UIGraphicsGetImageFromCurrentImageContext();
		UIGraphicsEndImageContext();
		
		image = resizedImage;
		 
		 [weakSelfRef hideProfileImageLoadingIndicator];
	} failure:^(NSError *error) {
		DDLogError(@"! TrainingProfileVC: failed to load profile image; error=%@", error.description);
		[weakSelfRef hideProfileImageLoadingIndicator];
	}];
}

- (void)initWebView {
	[self removeShadowFromWebView:chartView];
	[self updateChartViewFromCache];
}

- (void)initWSClient {
	wsClient = [WebServiceClient getInstance];
}

// ref: workaround for bug https://devforums.apple.com/message/731764#731764
- (NSUInteger)supportedInterfaceOrientations {
	return UIInterfaceOrientationMaskLandscape;
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	DDLogInfo(@"! TrainingProfileVC: tapped back button");
	[self playClickSound];
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)tappedReloadChartButton:(id)sender {
	[self initWebView];
}

- (IBAction)tappedUpdateProfileImageButton:(id)sender {
	[self playClickSound];
	[self launchImagePicker];
}

#pragma Image Picker
- (void)launchImagePicker {
	// do this, or the error "More than maximum 5 filtered album lists trying to register" will occur
	// note: don't do this when AFNetwork is working, or request body stream exhausted error occur
	if (imagePickerVC == nil) {
		DDLogInfo(@"! TrainingProfileVC: imagePickerVC is not initialized; init now");
		imagePickerVC = [[UIImagePickerController alloc] init];
	}
	
	imagePickerVC.allowsEditing = NO;
	imagePickerVC.delegate = self;
	imagePickerVC.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
	
	// on iPad, the pickerVC must be presented with popOverVC
	// and the popOverVC must be declared as a VC-wide attribute to prevent itself from auto-released too soon
	if ([deviceHelper isiPad]) {
		popOverVC = [[UIPopoverController alloc] initWithContentViewController:imagePickerVC];
		popOverVC.delegate = self;
		[popOverVC presentPopoverFromRect:CGRectMake(.0f, .0f, 400.0f, 400.0f) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
	} else {
		[self presentModalViewController:imagePickerVC animated:YES];
	}
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	if ([deviceHelper isiPad]) {
		[popOverVC dismissPopoverAnimated:YES];
	} else {
		[picker dismissModalViewControllerAnimated:YES];
	}
	
	UIImage * image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
	[profileImageView setImage:image];
	[self showProgressHUD];
	[wsClient updateTrainingProfileWithLoginToken:loginSessionManager.loginToken profileImage:image success:^(BOOL success) {
		DDLogInfo(@"! update profile image successfully");
		
		[self hideProgressHUD];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
		DDLogError(@"! failed to update profile image; errorCode=%d, errorMessage=%@", errorCode, errorMessage);
		
		[self hideProgressHUD];
		
		switch (errorCode) {
			default:
				break;
		}
		
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alertView show];
	}];
}

#pragma UIWebView delegate
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	if ([webView isEqual:chartView]) {
		DDLogError(@"! TrainingProfileVC: failed to load chart webview content, error: %@", error.localizedDescription);
	}
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	if ([webView isEqual:chartView]) {
        DDLogError(@"! TrainingProfileVC: finished loading chart webview content");
        NSMutableArray * scores = [cacheManager getCachedTrainingCategoryScores];
        DDLogInfo(@"! total num of scores: %d", scores.count);
        NSInteger gutterLeft = 40;
        NSInteger gutterRight = 40;
        
        [chartView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"setCanvasSize(%f, %f)", chartView.frame.size.width, chartView.frame.size.height]];
        
        if ([deviceHelper isiPad]) {
            gutterLeft = gutterRight = 110;
        } else {
            gutterLeft = gutterRight = 40;
        }
        [chartView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"setGutter(%d, %d)", gutterLeft, gutterRight]];

        [chartView stringByEvaluatingJavaScriptFromString:@"resetChartData()"];
        if (scores.count > 2) {
            for (TrainingCategoryScore * score in scores) {
                if (score.score <= 0) {
                    score.score = 0;
                }
                NSLog(@"! TrainingProfileVC: addStrength(%@, %f)", score.title, score.score);
                [chartView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"addStrength('%@', %f);", score.title, score.score]];
            }
            
            [chartView stringByEvaluatingJavaScriptFromString:@"finalize();"];
        }
	}
}

#pragma pop over controller
- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
	
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
	return YES;
}

#pragma hall of fames
- (void)loadHallOfFames {
	[self showProgressHUD];
	[wsClient getHOFWithLoginToken:loginSessionManager.loginToken success:^(HallOfFames *hof) {
		DDLogInfo(@"! retrieved %d hof entries", hof.hallOfFames.count + 1);
		[self hideProgressHUD];
		hallOfFames = hof;
		[self updateBuddyIcons];
		
		if (hallOfFames.hallOfFames.count < 1) {
			UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"Training.Profile.NoTrainingHistory", @"") delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
			[alertView show];
		}
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString *errorMessage) {
		DDLogError(@"! failed to load hall of fames; errorCode=%d, errorMessage=%@", errorCode, errorMessage);
		[self hideProgressHUD];
		
	}];
}

- (void)removeAllBuddyIcons {
	for (UIImageView * buddyIcon in buddyIcons) {
		[buddyIcon removeFromSuperview];
	}
	[buddyIcons removeAllObjects];
	
	if (traineeHOFView) {
		[traineeHOFView.view removeFromSuperview];
	}
}

- (void)updateBuddyIcons {
	NSInteger buddyTheme = 0;
	NSString * buddyImageNameFormat = nil;
	CGRect buddyFrame;
	CGFloat screenWidth = [UIScreen mainScreen].bounds.size.height;
	
	if ([deviceHelper isiPad]) {
		buddyImageNameFormat = @"buddy_%d_ipad";
		buddyFrame = CGRectMake(0, 612, 111, 116);
		
	} else {
		buddyImageNameFormat = @"buddy_%d_iphone";
		buddyFrame = CGRectMake(0, 256, 47, 49);
	}
	
	for (Rank * rank in hallOfFames.hallOfFames) {
		buddyTheme++;
		
		NSString * buddyImageName = [NSString stringWithFormat:buddyImageNameFormat, buddyTheme];
		
		UIImageView * buddyView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:buddyImageName]];
		buddyFrame.origin.x = screenWidth * (rank.rank / 100.0) - buddyFrame.size.width;
		buddyView.frame = buddyFrame;
				
		[self.view addSubview:buddyView];
		[self.view bringSubviewToFront:buddyView];
		[buddyIcons addObject:buddyView];
		
		buddyTheme = buddyTheme % 3;
	}
	
	[self updateTraineeIcon];
}

- (void)updateTraineeIcon {
	CGRect frame;
	CGFloat y;
	NSString * nibName;
	CGFloat screenWidth = [UIScreen mainScreen].bounds.size.height;
	
	if ([deviceHelper isiPad]) {
		nibName = @"TraineeHOFView_iPad";
		y = 612;
	} else{
		nibName = @"TraineeHOFView_iPhone";
		y = 256;
	}
	traineeHOFView = [[TraineeHOFViewController alloc] initWithNibName:nibName bundle:nil];
	
	[self.view addSubview:traineeHOFView.view];
	frame = traineeHOFView.view.frame;
	DDLogInfo(@"! TrainingProfileVC: hallOfFames.hallOfFames.count = %d", hallOfFames.hallOfFames.count);
	if (hallOfFames.hallOfFames.count < 1) {
		frame.origin.x = screenWidth - frame.size.width;
	} else {
		frame.origin.x = screenWidth * (hallOfFames.userRank.rank / 100.0) - frame.size.width;
	}
	frame.origin.y = y;
	traineeHOFView.view.frame = frame;
	
	CGSize profileImageSize = traineeHOFView.profileImageView.frame.size;
	[traineeHOFView.profileImageView setImageWithURL:[NSURL URLWithString:cacheManager.trainingProfile.profilePhoto] placeholderImage:nil options:SDWebImageLowPriority success:^(UIImage *image, BOOL cached) {
		UIGraphicsBeginImageContextWithOptions(profileImageSize, NO, .0f);
		[image drawInRect:CGRectMake(0, 0, profileImageSize.width, profileImageSize.height)];
		UIImage * resizedImage = UIGraphicsGetImageFromCurrentImageContext();
		UIGraphicsEndImageContext();
		
		image = resizedImage;
	} failure:^(NSError *error) {
		DDLogError(@"! TrainingProfileVC: failed to load traineeHOFView image; error=%@", error.description);
	}];
	
	DDLogInfo(@"! profilePhoto = %@", cacheManager.trainingProfile.profilePhoto);
	traineeHOFView.view.hidden = ![cacheManager.trainingProfile isProfilePhotoDefined];
	
	[self.view bringSubviewToFront:traineeHOFView.view];
}

#pragma loading training profile
- (void)loadTrainingProfile {	
	[self showProgressHUD];
	[wsClient getTrainingProfileWithLoginToken:loginSessionManager.loginToken success:^(TrainingProfile * profile) {
		[self hideProgressHUD];
		cacheManager.trainingProfile = profile;
		
		[self updateProfileImageFromCache];
		[self loadTrainingProfileScores];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString * errorMessage) {
		DDLogError(@"! failed to load profile image; errorCode=%d, errorMessage=%@", errorCode, errorMessage);
		
		[self hideProgressHUD];
		
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alertView show];
	}];
}

- (void)loadTrainingProfileScores {
	[self showProgressHUD];
	[wsClient getTrainingProfileScoreWithLoginToken:loginSessionManager.loginToken success:^(NSMutableArray *scores) {
		[self hideProgressHUD];
		
		[cacheManager cacheTrainingCategoryScores:scores];
		[self updateChartViewFromCache];
		[self loadHallOfFames];
	} failure:^(BOOL isHttpError, NSInteger errorCode, NSString *errorMessage) {
		DDLogError(@"! failed to load training profile score; errorCode=%d; errorMessage=%@", errorCode, errorMessage);
		
		[self hideProgressHUD];
		
		UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:errorMessage delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", @"") otherButtonTitles:nil];
		[alertView show];
	}];
}

#pragma profile image loading indicator
- (void)hideProfileImageLoadingIndicator {
	[profileImageLoadingIndicatorView stopAnimating];
	profileImageLoadingIndicatorView.hidden = YES;
}

- (void)showProfileImageLoadingIndicator {
	profileImageLoadingIndicatorView.hidden = NO;
	[profileImageLoadingIndicatorView startAnimating];
}

#pragma misc
- (UIImage *)getResizedImage:(UIImage *)image withSize:(CGSize)size {
	UIGraphicsBeginImageContextWithOptions(size, NO, .0f);
	[image drawInRect:CGRectMake(0, 0, size.width, size.height)];
	UIImage * resizedImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	return resizedImage;
}

@end
