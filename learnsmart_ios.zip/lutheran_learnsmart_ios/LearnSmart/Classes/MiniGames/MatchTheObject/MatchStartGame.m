//
//  MatchStartGame.m
//  GameApp
//
//  Created by Elbin John on 14/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "MatchStartGame.h"
#import "AppConfig.h"
#import "CheckPointLoggerAgent.h"
#import "PlayMusic.h"
#import "CocoaLumberjackConfig.h"

@interface MatchStartGame ()

- (void)logCheckpoint;
- (IBAction) continueClick:(id)sender;
- (IBAction) backClicked  :(id)sender;
@end



@implementation MatchStartGame

@synthesize delegate;
@synthesize gameTypeId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	[self logCheckpoint];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma checkpoint
- (void)logCheckpoint {
	AppConfig * appConfig = [AppConfig getInstance];
	[[CheckPointLoggerAgent new] logForMiniGamePlay:appConfig.miniGameCheckpointMatching];
}

#pragma game implementation

- (IBAction) continueClick:(id)sender
{
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    if(self.delegate && [self.delegate respondsToSelector:@selector(continueClickedDelegate)])
    {
         [self.navigationController popViewControllerAnimated:NO];
        [self.delegate continueClickedDelegate];
    }
}
- (IBAction) backClicked  :(id)sender {
	[[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    [self.navigationController popViewControllerAnimated:YES];
}
/*

- (BOOL)shouldAutorotate{
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}
*/

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}

@end
