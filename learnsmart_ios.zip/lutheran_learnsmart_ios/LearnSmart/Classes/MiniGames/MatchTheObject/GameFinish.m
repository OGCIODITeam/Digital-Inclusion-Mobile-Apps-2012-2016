//
//  GameFinish.m
//  GameApp
//
//  Created by Elbin John on 06/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "GameFinish.h"
#import "PlayMusic.h"
#import "MactchTheObjectGameMenu.h"
#import "MatchTheObjectController.h"


@interface GameFinish ()
- (IBAction)homeclicked:(id)sender;
- (IBAction)loadNext:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *gametime;

@end

@implementation GameFinish
@synthesize gametime;
@synthesize gameType;
@synthesize gameTypeId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
     [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"level clear" ofType:@"mp3"]]];
    [super viewDidLoad];
     self.gametime.text = _finishTime;
   
    cheerAnimation.animationImages  = [NSArray arrayWithObjects:[UIImage imageNamed:@"cheer1.png"], [UIImage imageNamed:@"cheer2.png"], nil];
    cheerAnimation.animationDuration    = 0.8f;
    [cheerAnimation startAnimating];
    
    
    switch (self.gameTypeId) {
        case 1:
            gameFinishText.image        = [UIImage imageNamed:@"paring game_easy.png"];
            break;
        case 2:
            gameFinishText.image        = [UIImage imageNamed:@"pairinggame_medium.png"];
            break;
        case 3:
            gameFinishText.image        = [UIImage imageNamed:@"pairinggame_difficult.png"];
            break;
        case 4:
            gameFinishText.image        = [UIImage imageNamed:@"Memory card.png"];
            break;
            
        default:
            break;
    }
    
    
    
}

- (void)viewDidAppear:(BOOL)animated
{
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)homeclicked:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)loadNext:(id)sender {
    
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    if(self.gameType == 0)
    {

    for(id tmp in self.navigationController.childViewControllers)
    {
        if(tmp && [tmp isKindOfClass:[MactchTheObjectGameMenu class]])
        {
            [self.navigationController popToViewController:tmp animated:YES];
        }
    }
        
    }
    else  if(self.gameType == 1)
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    
   
    
    
    
}

/*
- (BOOL)shouldAutorotate{
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
   return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}
*/

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}


- (void)viewDidUnload {
    [self setGametime:nil];
    [super viewDidUnload];
}
@end
