//
//  MatchMeLineDraw.m
//  FlipTest
//
//  Created by Elbin John on 29/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "MatchMeLineDraw.h"

@implementation MatchMeLineDraw
{
    UIBezierPath *path;
    UIBezierPath *pathFound;        
    BOOL isDrawOk;
     

}

@synthesize delegate;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    

    if(!path)
        path = [UIBezierPath bezierPath];
    if(! pathFound )
        pathFound = [UIBezierPath bezierPath];
    
    
    
    
    [path setLineWidth:5.0];
    const float pa[2] = {0, 0};
    [path setLineDash:pa count:0 phase:0.3];
    
    
    CGFloat dashArray[3];
    dashArray[0] = 0;
    dashArray[1] = 0;
    dashArray[2] = 0;
    [path setLineDash:dashArray count:1 phase: 0.0];
    
    
    
    UITouch *touch = [touches anyObject];
    CGPoint p = [touch locationInView:self];
    _firstPoint = p;
    
    [path moveToPoint:p];
    
    if(self.delegate && [self.delegate respondsToSelector:@selector(lineStart:)])
    {
      isDrawOk =  [self.delegate lineStart:CGRectMake(self.firstPoint.x, self.firstPoint.y, 1, 1) ];
        
    }

    
    //    UITouch *touch = [touches anyObject];
    //    CGPoint point = [touch locationInView:self];
    //    _firstPoint = point;
    //    _imgDrawLine = [[UIImageView alloc] initWithFrame:CGRectMake(point.x, point.y , 0, 0)];
    //    [_imgDrawLine setBackgroundColor:[UIColor redColor]];
    //    [self addSubview:_imgDrawLine];
    
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    [path removeAllPoints];
    if (isDrawOk) {
        
    
    [path moveToPoint:self.firstPointOnDraw];
    UITouch *touch = [touches anyObject];
    CGPoint p = [touch locationInView:self];
    [path addLineToPoint:p]; // (4)
    
        _lastPoint = p;
    }
    [self setNeedsDisplay];
    
 
    
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [path removeAllPoints];
    [self setNeedsDisplay];

    
    if(isDrawOk)
    {
        
    if(self.delegate && [self.delegate respondsToSelector:@selector(lineStartEndFrame::)])
    {
        [self.delegate lineStartEndFrame:CGRectMake(self.firstPoint.x, self.firstPoint.y, 1, 1) :CGRectMake(self.lastPoint.x, self.lastPoint.y, 1, 1)];
    }
    }
    
}

-(void)drawMatchLine :(CGPoint)pointStart :(CGPoint)endPoint
{
    
    CGFloat dashArray[3];
    dashArray[0] = 0;
    dashArray[1] = 0;
    dashArray[2] = 0;
    [pathFound setLineWidth:5.0];
    [pathFound setLineDash:dashArray count:1 phase: 0.0];
    

    [pathFound moveToPoint:CGPointMake(pointStart.x+3, pointStart.y-3)];
    [pathFound addLineToPoint:CGPointMake(endPoint.x-3, endPoint.y+3)];
    [self setNeedsDisplay];

}


- (void)resetPath
{
    [pathFound removeAllPoints];
    [self setNeedsDisplay];
}


- (void)drawRect:(CGRect)rect
{
    [[UIColor blackColor] setStroke];
    [path stroke];
    [pathFound stroke];
    

    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
