//
//  MatchTheObject.m
//  FlipTest
//
//  Created by Elbin John on 28/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "MatchTheObjectController.h"
#import "MactchTheObjectView.h"
#import "PlayMusic.h"
#import "GameFinish.h"


@interface MatchTheObjectController ()
{
    gameFinishView * gameFinishView1;
    GameFinish * gameFinish;
    __unsafe_unretained IBOutlet UILabel *timeTicker;
    NSTimer * tmr;
    BOOL isClosedSound;
    int createGap ;
    int createGaph ;
    int gameLevelCount;
    float totalTime;
    NSInteger x;
}
@property (unsafe_unretained, nonatomic) IBOutlet UIView *matchPlayArea;
@property (strong, nonatomic) NSMutableArray * matchItemsViewList;
@property (unsafe_unretained, nonatomic) IBOutlet MatchMeLineDraw *drawArea;
@property (strong, nonatomic) NSMutableArray * matchItemsFound;
@property (strong, nonatomic) IBOutlet UIImageView *animatingImage;

- (void)initPlayerView;
- (IBAction)backButtonClicked:(id)sender;

@end

@implementation MatchTheObjectController
@synthesize gamestage;
@synthesize gameTypeId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    isClosedSound=[[NSUserDefaults standardUserDefaults]boolForKey:@"sound"];
    gameLevelCount = 0;
    totalTime = 0;
    x = 0;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        createGap = 75;
        createGaph = 5;
    }
    else {
        createGap = 200;
        createGaph = 20;
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self startGame];   
    
}

- (void) startGame {
    if (gameLevelCount == 0) {
        [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Game Start or finished" ofType:@"WAV"]]];
    }
	
    [self initPlayerView];
    
    NSDictionary * dic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"MatchTheObjectLevel" ofType:@"plist"]];
    
    if(!self.gamestage)
        self.gamestage = @"easy";
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        [self setMatchMeToplay:3 :[dic objectForKey:[NSString stringWithFormat:@"%@%d",self.gamestage,gameLevelCount]]];
    }
    else {
        [self setMatchMeToplay:4 :[dic objectForKey:[NSString stringWithFormat:@"%@%d",self.gamestage,gameLevelCount]]];
    }
    self.drawArea.delegate =self;
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];    
}

- (void)viewDidDisappear:(BOOL)animated {
    [PlayMusic sharedInstanceGameBg].repeatSound = NO;
    [[PlayMusic sharedInstanceGameBg]stopPlayback ];
}

- (void)initPlayerView {
    
    gameLevelCount ++;
    
    [self.drawArea resetPath];
    self.animatingImage.transform = CGAffineTransformMakeRotation(-M_PI);
    
    [self.view addSubview:self.animatingImage];
    self.animatingImage.frame = CGRectMake(((self.view.frame.size.width/2)-(self.animatingImage.frame.size.width)/2),-(self.animatingImage.frame.size.width)/2, self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
    [self.animatingImage setAlpha:1];
    
     self.view.userInteractionEnabled = FALSE;
    
    if (gameLevelCount == 1) {        
        [UIView animateWithDuration:0.8f
                         animations:^{
                            self.animatingImage.transform = CGAffineTransformMakeRotation(2*M_PI);
                         }];
        
        [UIView beginAnimations:@"1" context:NULL];
        
        
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:1.5];
        self.animatingImage.frame =CGRectMake(((self.view.frame.size.width/2)-((self.animatingImage.frame.size.width)/2)),(self.view.frame.size.height/2)-((self.animatingImage.frame.size.height)/2), self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
        
        [UIView commitAnimations];
        
    } else {
        CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        animation.fromValue = [NSNumber numberWithFloat:-1];
        animation.toValue = [NSNumber numberWithFloat: 1];
        animation.duration = .1f;///.9
        animation.repeatCount = 1;
        [self.animatingImage.layer addAnimation:animation forKey:@"SpinAnimation"];
        
        self.animatingImage.hidden = YES;
        [UIView beginAnimations:@"1" context:NULL];
        
        
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.1];//////-----1.5
        self.animatingImage.frame =CGRectMake(((self.view.frame.size.width/2)-((self.animatingImage.frame.size.width)/2)),(self.view.frame.size.height/2)-((self.animatingImage.frame.size.height)/2), self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
        
        [UIView commitAnimations];
        
    }  
}

- (IBAction)backButtonClicked:(id)sender {
    NSLog(@"%d", gameLevelCount);
    if (gameLevelCount <= 10) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Learn Smart"
                                                        message:@"確認退出?"
                                                       delegate:self
                                              cancelButtonTitle:nil otherButtonTitles:@"YES", @"NO", nil];
        
        [alert show];
        
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

#pragma UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)initPlayerViewPartTwo {
    if (gameLevelCount == 1) {
        [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"ready go" ofType:@"mp3"]]];
        
        [UIView beginAnimations:@"2" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:1.5];
        self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-50,self.animatingImage.frame.origin.y-50, self.animatingImage.frame.size.width+ 100, self.animatingImage.frame.size.height+100);
        [self.animatingImage setAlpha:0];
        [UIView commitAnimations];
    } else{
        [UIView beginAnimations:@"2" context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.2];
        self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-50,self.animatingImage.frame.origin.y-50, self.animatingImage.frame.size.width+ 100, self.animatingImage.frame.size.height+100);
        [self.animatingImage setAlpha:0];
        [UIView commitAnimations];
    }
}

-(void)animationDidStop:(NSString *)animationId
{
    if([animationId intValue] == 1)   {    
        
        [self performSelector:@selector(initPlayerViewPartTwo) withObject:nil afterDelay:1];
        
    } else {
        [self.animatingImage removeFromSuperview];
        
        
        self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-25,self.animatingImage.frame.origin.y-25, self.animatingImage.frame.size.width- 100, self.animatingImage.frame.size.height- 100);        
        
        
        self.view.userInteractionEnabled = TRUE;
        

        NSDate * date = [NSDate date];
               
        tmr = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(playerTimeGo:) userInfo:date repeats:YES];
        
        if (gameLevelCount == 1) {
            
            if(!isClosedSound){
                [PlayMusic sharedInstanceGameBg].repeatSound = YES;
                [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"bg music during the game" ofType:@"mp3"]]];
            }
        }
        
    }
    
}

- (void)playerTimeGo:(NSTimer *)timer {
    totalTime+=1;
    
    NSInteger ti = (NSInteger)totalTime;
    NSInteger seconds = ti % 60;
    NSInteger minutes = (ti / 60) % 60;
    totalTime=ti;
        
    timeTicker.text = [NSString stringWithFormat:@"%02i:%02i",minutes ,seconds];
}


- (void)setMatchMeToplay:(int)numberOfMatchElement : (NSArray *)itemDetails {
    
    MactchTheObjectView * tmpMactchTheObjectView;
    _matchItemsViewList = [NSMutableArray array];
    _matchItemsFound = [NSMutableArray array];
    
    
    int countGameElement = [itemDetails count];
    int gameRandom[countGameElement],tmpd,tmpswaps;
    
    for(int i = 0; i < countGameElement; i++) {
        gameRandom[i] = i;
    }
    
    for(int i = 0; i < countGameElement -1; i++) {
        tmpd =  arc4random() % countGameElement;
        tmpswaps = gameRandom[i];
        gameRandom[i]   = gameRandom[tmpd];
        gameRandom[tmpd]   = tmpswaps;
        
    }
    
    
    
    int ar[numberOfMatchElement],d,tmpswap;
    
    for(int i = 0; i < numberOfMatchElement; i++) {
        ar[i] = i;
    }
	
    for(int i = 0; i < numberOfMatchElement; i++) {
        d =  arc4random() % numberOfMatchElement;
        tmpswap = ar[i];
        ar[i]   = ar[d];
        ar[d]   = tmpswap;
        
    }
        
    UIImage * imgLeft  = [UIImage imageNamed: @"matchGameItemBackLeft.png"];
    
    int selectItem = 0;
    
    CGRect playArea = self.matchPlayArea.frame;
    CGRect playItemsize;
    
    
    for (int i = 0; i<numberOfMatchElement; i++) {
        
        int gameget = gameRandom[selectItem];
        
        NSString * maintxt = [[itemDetails objectAtIndex:gameget] objectForKey:@"main"];
        NSString * machtxt = [[itemDetails objectAtIndex:gameget] objectForKey:@"match"];
        
        NSString * mainimg = [[itemDetails objectAtIndex:gameget] objectForKey:@"mainImage"];
        NSString * machimg = [[itemDetails objectAtIndex:gameget] objectForKey:@"matchimage"];
        
        UIImage * mainImage  = nil;
        UIImage * matchingimage  = nil;
        
        NSLog(@"%@-----%@   %@----%@", maintxt, machtxt, mainimg, machimg);
        
        if(mainimg) {
            mainImage = [UIImage imageNamed:mainimg ];
        }
        
        if(machimg) {
            matchingimage = [UIImage imageNamed:machimg ];
        }
        
        playItemsize = CGRectMake(0,(playArea.size.height/(numberOfMatchElement)*i)+createGaph
                                  ,(playArea.size.width/2)-createGap, ((playArea.size.height/numberOfMatchElement+1)-createGaph));
        
        
        tmpMactchTheObjectView = (MactchTheObjectView*)[[[NSBundle mainBundle] loadNibNamed:@"MactchTheObjectView" owner:nil options:nil] objectAtIndex:0];
        [self.matchPlayArea addSubview:tmpMactchTheObjectView];
        tmpMactchTheObjectView.itemPlayBack.image = imgLeft;
        tmpMactchTheObjectView.isRishtItem = YES;
        tmpMactchTheObjectView.itemId = selectItem;
        if(!mainImage) {
        
            tmpMactchTheObjectView.itemIdNumber.text = maintxt;//[NSString stringWithFormat:@"%d",i];
        } else {
			tmpMactchTheObjectView.itemIdNumber.text = @"";
            tmpMactchTheObjectView.itemImage.image = mainImage;
        }
        tmpMactchTheObjectView.frame = playItemsize;
        
        [_matchItemsViewList addObject:tmpMactchTheObjectView];
        
        tmpMactchTheObjectView = (MactchTheObjectView*)[[[NSBundle mainBundle] loadNibNamed:@"MactchTheObjectView" owner:nil options:nil] objectAtIndex:0];
        
        if(!matchingimage) {
            
            tmpMactchTheObjectView.itemIdNumber.text = machtxt;//[NSString stringWithFormat:@"%d",i];
        } else {
            tmpMactchTheObjectView.itemIdNumber.text = @"";
            tmpMactchTheObjectView.itemImage.image = matchingimage;
        }
        
        [self.matchPlayArea addSubview:tmpMactchTheObjectView];
        tmpMactchTheObjectView.itemPlayBack.image = imgLeft;
        playItemsize.origin.x =  playItemsize.size.width+(createGap*2);
        playItemsize.origin.y =  (playArea.size.height/numberOfMatchElement*ar[i])+createGaph;
        tmpMactchTheObjectView.frame = playItemsize;
        tmpMactchTheObjectView.itemId = selectItem;
        tmpMactchTheObjectView.imageContainer.transform = CGAffineTransformMake(-1,0,0,1,0,0);
        [_matchItemsViewList addObject:tmpMactchTheObjectView];
        
        
        selectItem++;
        selectItem = (selectItem >= countGameElement  ?0:selectItem);
    }
    
    [self.view bringSubviewToFront:self.drawArea];
    
}

- (void)lineStartEndFrame:(CGRect)startPlot :(CGRect)endPlot {
    
    MactchTheObjectView * selectItem =  (MactchTheObjectView*)[[self.matchPlayArea hitTest:startPlot.origin withEvent:nil]superview];
    MactchTheObjectView * selectItem1 =  (MactchTheObjectView*)[[self.matchPlayArea hitTest:endPlot.origin withEvent:nil]superview];
    
    if( selectItem && selectItem1 && [selectItem isKindOfClass:[MactchTheObjectView class]] && [selectItem1 isKindOfClass:[MactchTheObjectView class]]  && selectItem.itemId == selectItem1.itemId && (selectItem != selectItem1)) {
        
        if(![[self.matchItemsFound filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"itemId = %d",selectItem.itemId]] count]) {
            
            [self.matchItemsFound addObject:selectItem];
            
            [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"correct linked" ofType:@"mp3"]]];
            if ([self.matchItemsFound count] == [self.matchItemsViewList count]/2) {
                
                NSLog(@"Level finished");
                
                [tmr invalidate];
                                
                if (gameLevelCount == 10) {
                    [PlayMusic sharedInstanceGameBg].repeatSound = NO;
                    [[PlayMusic sharedInstanceGameBg]stopPlayback ];
                    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"game finished" ofType:@"mp3"]]];
                }
                else {
                    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"yeah" ofType:@"mp3"]]];
                }
                
                            
                [self levelFinish];
                
            }
			
			[self resetFrame];
			
            CGPoint beginPoint = [selectItem convertPoint:selectItem.dotImage.center toView:self.matchPlayArea];
            CGPoint endPoint   = [selectItem1 convertPoint:selectItem1.dot1.center toView:self.matchPlayArea];
            
            NSLog(@"11%@",NSStringFromCGPoint(beginPoint));
            NSLog(@"22%@",NSStringFromCGPoint(endPoint));
            
            
            [self.drawArea drawMatchLine:endPoint :beginPoint];
            
            [selectItem foundAnimate];
            [selectItem1 foundAnimate];
        }
        
        
    } else {
        [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"wrong linked" ofType:@"mp3"]]];
    }
    
    if( selectItem   && [selectItem isKindOfClass:[MactchTheObjectView class]]) {
        [self resetFrame];
    }
}


- (void) levelFinish {
    NSString * nibname = @"gameFinishView";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibname = @"gameFinishViewIphone";
    }
    
    gameFinishView1  = (gameFinishView*)[[[NSBundle mainBundle] loadNibNamed:nibname owner:nil options:nil] objectAtIndex:0];
    gameFinishView1.frame = CGRectMake(((self.view.frame.size.width/2)-(gameFinishView1.frame.size.width/2)), (self.view.frame.size.height/2)-(gameFinishView1.frame.size.height/2), gameFinishView1.frame.size.width, gameFinishView1.frame.size.height);
    
    ///actual value 10
    if (gameLevelCount == 10) {
        [self.view addSubview:gameFinishView1];
        gameFinishView1.delegate = self;
        
        [gameFinishView1 loadAnimatedGo];
    } else {
        gameFinishView1.delegate = self;
        
        [gameFinishView1 loadAnimatedGo];
    }

}

- (BOOL)lineStart:(CGRect)startPlot {
    MactchTheObjectView * selectItem =  (MactchTheObjectView*)[[self.matchPlayArea hitTest:startPlot.origin withEvent:nil]superview];
    
    NSLog(@"%@",NSStringFromCGRect(selectItem.frame));
    
    CGRect frame = selectItem.frame;
    frame.size.width  = frame.size.width+50;
    if( selectItem   && [selectItem isKindOfClass:[MactchTheObjectView class]] && selectItem.isRishtItem) {
        selectItem.frame = frame;
        self.drawArea.firstPointOnDraw = [selectItem convertPoint:selectItem.dotImage.center toView:self.matchPlayArea];
        
        NSLog(@"%@",NSStringFromCGPoint(self.drawArea.firstPointOnDraw));
        return YES;
    }
    
    return FALSE;
}

- (void)resetFrame {
    CGRect playArea = self.matchPlayArea.frame;
    
    for (MactchTheObjectView * selectItem in self.matchItemsViewList) {
        
        CGRect frame = selectItem.frame;
        frame.size.width  = (playArea.size.width/2)-createGap;
        selectItem.frame = frame;
	}
}


- (void)finishAnimation {
	x+=totalTime;
    
    gameFinishView1.delegate = nil;
    [gameFinishView1 removeFromSuperview];
    if(gameLevelCount>9) {
        [self dismissModalViewControllerAnimated:NO];
        
        NSString * nibname = @"GameFinish";
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            
            nibname = @"GameFinishIphone";
        }
        
        
        gameFinish = [[GameFinish alloc] initWithNibName:nibname bundle:nil];
        gameFinish.gameTypeId = self.gameTypeId;

        gameFinish.finishTime = timeTicker.text;
        gameFinish.gameType =0;
        [self.navigationController pushViewController:gameFinish animated:YES];
    } else {
        [self startGame];
        [self.view setNeedsDisplay];
    }
}

- (void)dealloc {
    gameFinishView1.delegate = nil;
}

- (BOOL)shouldAutorotate {
	return YES;
}

- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
