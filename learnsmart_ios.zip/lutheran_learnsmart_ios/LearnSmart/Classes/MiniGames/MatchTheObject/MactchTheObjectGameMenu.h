//
//  MactchTheObjectGameMenu.h
//  GameApp
//
//  Created by Elbin John on 05/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchStartGame.h"

@class AppConfig, DeviceHelper;

@interface MactchTheObjectGameMenu : UIViewController <MatchStartGameDelegate> {
	IBOutlet UIImageView * animatedGirlView;
	AppConfig * appConfig;
	DeviceHelper * deviceHelper;
}

@end
