//
//  MactchTheObjectView.h
//  FlipTest
//
//  Created by Elbin John on 28/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface MactchTheObjectView : UIView

@property (unsafe_unretained, nonatomic) IBOutlet UILabel    *itemIdNumber;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *itemImage;
@property (nonatomic,assign) int  itemId;
@property (nonatomic,assign) BOOL isRishtItem;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *itemPlayBack;
@property (unsafe_unretained, nonatomic) IBOutlet UIView *imageContainer;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *dotImage;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *foundRinganimate;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *dot1;


- (void)foundAnimate;


@end
