//
//  MactchTheObjectGameMenu.m
//  GameApp
//
//  Created by Elbin John on 05/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "MactchTheObjectGameMenu.h"
#import "MatchTheObjectController.h"
#import "PlayMusic.h"
#import "AppConfig.h"
#import "DeviceHelper.h"

@interface MactchTheObjectGameMenu ()
{
    int selectedLevel;
    NSInteger levelTypeId;
}

- (void)initGirlAnimation;
- (IBAction)levelClicked:(id)sender;
- (void)startGirlAnimation;
- (void)stopGirlAnimation;

@end

@implementation MactchTheObjectGameMenu

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
     
    // Do any additional setup after loading the view from its nib.
	appConfig = [AppConfig getInstance];
	deviceHelper = [DeviceHelper getInstance];
	[self initGirlAnimation];
}


- (void)viewDidAppear:(BOOL)animated
{
//    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"bg music" ofType:@"mp3"]]];
}

- (void)viewWillAppear:(BOOL)animated {
	[self startGirlAnimation];
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
	[self stopGirlAnimation];
	[super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)levelClicked:(id)sender {

    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    selectedLevel = [sender tag];
    
    NSString * nibName = nil;
    if ([deviceHelper isiPad]) {
		nibName = @"MatchStartGame";
    } else {
		nibName = @"MatchStartGameIphone";
	}
    
	MatchStartGame * matchStartGame = [[MatchStartGame alloc] initWithNibName:nibName bundle:nil];
	[self.navigationController pushViewController:matchStartGame animated:YES];
	matchStartGame.delegate = self;
	matchStartGame.gameTypeId   = [sender tag];
	levelTypeId                 = [sender tag];
}


- (void)continueClickedDelegate
{
    NSString * level;
    NSString * nibName = @"MatchTheObjectController";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibName = @"MatchTheObjectControllerIphone";
    }
    
    
    
    switch (selectedLevel) {
        case 1:
            level = @"easy";
            break;
        case 2:
            level = @"normal";
            break;
        case 3:
            level = @"hard";
            break;
            
        default:
            break;
    }
    
    MatchTheObjectController * matchTheObjectController = [[MatchTheObjectController alloc] initWithNibName:nibName bundle:nil];
    matchTheObjectController.gamestage = level;
    matchTheObjectController.gameTypeId = levelTypeId;
    //    [self presentViewController:matchTheObjectController animated:YES completion:nil];
    [self.navigationController pushViewController:matchTheObjectController animated:YES];
    
    
}

- (IBAction)homeClicked:(id)sender {
    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    [self.navigationController popViewControllerAnimated:YES];
}
/*
- (BOOL)shouldAutorotate{
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
  return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}
*/

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}

#pragma girl animation
- (void)initGirlAnimation {
	NSMutableArray * animatedGirlFrames = [NSMutableArray array];
	NSString * deviceSuffix;
	
	if ([deviceHelper isiPad]) {
		deviceSuffix = @"ipad";
	} else {
		deviceSuffix = @"iphone";
	}
	
	for (int i=1; i<=appConfig.numAnimatedGirlFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", i, deviceSuffix]]];
	}
	
	for (int i=1; i<appConfig.numAnimatedGirlPauseFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", appConfig.numAnimatedGirlFrames, deviceSuffix]]];
	}
	
	animatedGirlView.animationImages = animatedGirlFrames;
	animatedGirlView.animationDuration = 1.50f;
	animatedGirlView.animationRepeatCount = INFINITY;
}

- (void)startGirlAnimation {
	[animatedGirlView startAnimating];
}

- (void)stopGirlAnimation {
	[animatedGirlView stopAnimating];
}

@end
