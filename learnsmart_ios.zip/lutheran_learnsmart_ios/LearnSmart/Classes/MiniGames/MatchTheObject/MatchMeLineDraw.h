//
//  MatchMeLineDraw.h
//  FlipTest
//
//  Created by Elbin John on 29/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MatchMeLineDrawDelegate <NSObject>

- (void)lineStartEndFrame :(CGRect)startPlot :(CGRect)endPlot;
- (BOOL)lineStart :(CGRect)startPlot ;

@end

@interface MatchMeLineDraw : UIView

@property(nonatomic,retain)UIImageView * imgDrawLine;
@property(nonatomic,assign)CGPoint  firstPoint;
@property(nonatomic,assign)CGPoint  firstPointOnDraw;
@property(nonatomic,assign)CGPoint  lastPoint;
@property(nonatomic,assign)id <MatchMeLineDrawDelegate>  delegate;

- (void)drawMatchLine :(CGPoint)pointStart :(CGPoint)endPoint;
- (void)resetPath;


@end
