//
//  MactchTheObjectView.m
//  FlipTest
//
//  Created by Elbin John on 28/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "MactchTheObjectView.h"


@implementation MactchTheObjectView




- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (IBAction)selectedItem:(id)sender {
    
}

- (void)foundAnimate
{
    [self.foundRinganimate setHidden:NO];
    [self.foundRinganimate setAlpha:1];
    [UIView beginAnimations:@"2" context:NULL];
    //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:.5];
    //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
    self.foundRinganimate.frame = CGRectMake(self.foundRinganimate.frame.origin.x-10,self.foundRinganimate.frame.origin.y-5, self.foundRinganimate.frame.size.width+ 25, self.foundRinganimate.frame.size.height+25);
    [self.foundRinganimate setAlpha:0];
    [UIView commitAnimations];
}


 

@end
