//
//  gameFinishView.h
//  GameApp
//
//  Created by Elbin John on 06/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol gameFinishViewDelegate <NSObject>

- (void) finishAnimation;

@end

@interface gameFinishView : UIView


- (void)loadAnimatedGo;

@property(nonatomic,assign)id <gameFinishViewDelegate> delegate;

@end
