//
//  MatchTheObject.h
//  FlipTest
//
//  Created by Elbin John on 28/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchMeLineDraw.h"
#import "gameFinishView.h"

@interface MatchTheObjectController : UIViewController <MatchMeLineDrawDelegate,gameFinishViewDelegate, UIAlertViewDelegate>

@property(nonatomic,assign)NSString * gamestage;
@property(nonatomic,assign)NSInteger gameTypeId;


@end
