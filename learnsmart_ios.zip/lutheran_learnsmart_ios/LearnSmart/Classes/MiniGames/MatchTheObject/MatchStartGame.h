//
//  MatchStartGame.h
//  GameApp
//
//  Created by Elbin John on 14/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MatchStartGameDelegate <NSObject>

- (void)continueClickedDelegate;

@end

@interface MatchStartGame : UIViewController


@property (nonatomic,assign) id <MatchStartGameDelegate> delegate;

@property (assign, nonatomic) NSInteger gameTypeId;

@end
