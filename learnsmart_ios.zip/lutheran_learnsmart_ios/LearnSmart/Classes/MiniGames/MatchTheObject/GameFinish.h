//
//  GameFinish.h
//  GameApp
//
//  Created by Elbin John on 06/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameFinish : UIViewController{
    IBOutlet UIImageView *cheerAnimation;
    IBOutlet UIImageView    *gameFinishText;
}
@property(nonatomic,assign)NSString * finishTime;
@property(nonatomic,assign)int levelCount;
@property(nonatomic,assign)int gameType;
@property(nonatomic,assign)NSInteger gameTypeId;

@end
