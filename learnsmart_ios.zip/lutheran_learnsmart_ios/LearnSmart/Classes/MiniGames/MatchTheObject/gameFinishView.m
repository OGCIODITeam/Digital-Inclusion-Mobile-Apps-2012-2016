//
//  gameFinishView.m
//  GameApp
//
//  Created by Elbin John on 06/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "gameFinishView.h"


@interface gameFinishView ()


@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *image1;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *image2;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *image3;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *image4;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *imageThumb;

- (void)fireFinishDelegate;

@end

@implementation gameFinishView

@synthesize delegate;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)loadAnimatedGo
{
    
    self.image1.frame = CGRectMake((self.image1.frame.origin.x - self.frame.size.width),
                                   self.image1.frame.origin.y, self.image1.frame .size.width, self.image1.frame .size.height);
    
    UIImageView * tmpView = self.image2;
    [tmpView setHidden:YES];
    tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
                               tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
    tmpView = self.image3;
    [tmpView setHidden:YES];
    tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
                               tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
    tmpView = self.image4;
    [tmpView setHidden:YES];
    tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
                               tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
    tmpView = self.imageThumb;
    [tmpView setHidden:YES];
//    tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
//                               tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
//    

    
    [UIView beginAnimations:@"1" context:NULL];
    //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:.3];
    //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
    self.image1.frame = CGRectMake((self.image1.frame.origin.x+ self.frame.size.width),
                                   self.image1.frame.origin.y, self.image1.frame .size.width, self.image1.frame .size.height);
    //[self.foundRinganimate setAlpha:0];
    [UIView commitAnimations];
    
}


-(void)animationDidStop:(NSString *)animationId
{
    if([animationId intValue] == 1)
    {
     
        UIImageView * tmpView = self.image2;
        [tmpView setHidden:NO];
//        tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
//                                       tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
        
        [UIView beginAnimations:@"2" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.1];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        tmpView.frame = CGRectMake((tmpView.frame.origin.x+ self.frame.size.width),
                                       tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }
    
    if([animationId intValue] == 2)
    {
        
        UIImageView * tmpView = self.image3;
        [tmpView setHidden:NO];
//        tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
//                                   tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
        
        [UIView beginAnimations:@"3" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        tmpView.frame = CGRectMake((tmpView.frame.origin.x+ self.frame.size.width),
                                   tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }

    
    if([animationId intValue] == 3)
    {
        
        UIImageView * tmpView = self.image4;
        [tmpView setHidden:NO];
//        tmpView.frame = CGRectMake((tmpView.frame.origin.x - self.frame.size.width),
//                                   tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
        
        [UIView beginAnimations:@"4" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        tmpView.frame = CGRectMake((tmpView.frame.origin.x+ self.frame.size.width),
                                   tmpView.frame.origin.y, tmpView.frame .size.width, tmpView.frame .size.height);
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }

    
    if([animationId intValue] == 4)
    {
        
        UIImageView * tmpView = self.imageThumb;
        [tmpView setHidden:NO];
               [UIView beginAnimations:@"5" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        
        tmpView.frame = CGRectMake(tmpView.frame.origin.x ,
                                   tmpView.frame.origin.y, tmpView.frame .size.width+25, tmpView.frame .size.height+25);
        


        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }
    
    if([animationId intValue] == 5)
    {
        
        UIImageView * tmpView = self.imageThumb;
       // tmpView.frame = CGRectMake(tmpView.frame.origin.x ,
//                                   tmpView.frame.origin.y, tmpView.frame .size.width+25, tmpView.frame .size.height+25);
        
        [UIView beginAnimations:@"6" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        tmpView.frame = CGRectMake( tmpView.frame.origin.x  ,
                                   tmpView.frame.origin.y, tmpView.frame .size.width-25, tmpView.frame .size.height-25);
                 
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }
    
    if([animationId intValue] == 6)
    {
        
        UIImageView * tmpView = self.imageThumb;
        [UIView beginAnimations:@"7" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        
        tmpView.frame = CGRectMake(tmpView.frame.origin.x ,
                                   tmpView.frame.origin.y, tmpView.frame .size.width+25, tmpView.frame .size.height+25);
        
        
        
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }
    
    if([animationId intValue] == 7)
    {
        
        UIImageView * tmpView = self.imageThumb;
        // tmpView.frame = CGRectMake(tmpView.frame.origin.x ,
        //                                   tmpView.frame.origin.y, tmpView.frame .size.width+25, tmpView.frame .size.height+25);
        
        [UIView beginAnimations:@"8" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        tmpView.frame = CGRectMake( tmpView.frame.origin.x  ,
                                   tmpView.frame.origin.y, tmpView.frame .size.width-25, tmpView.frame .size.height-25);
        
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }
    
    
    if([animationId intValue] == 8)
    {
        
        UIImageView * tmpView = self.imageThumb;
        [UIView beginAnimations:@"9" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        
        tmpView.frame = CGRectMake(tmpView.frame.origin.x ,
                                   tmpView.frame.origin.y, tmpView.frame .size.width+25, tmpView.frame .size.height+25);
        
        
        
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
    }
    
    if([animationId intValue] == 9)
    {
        
        UIImageView * tmpView = self.imageThumb;
        // tmpView.frame = CGRectMake(tmpView.frame.origin.x ,
        //                                   tmpView.frame.origin.y, tmpView.frame .size.width+25, tmpView.frame .size.height+25);
        
        [UIView beginAnimations:@"10" context:NULL];
        //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.3];
        //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        tmpView.frame = CGRectMake( tmpView.frame.origin.x  ,
                                   tmpView.frame.origin.y, tmpView.frame .size.width-25, tmpView.frame .size.height-25);
        
        //[self.foundRinganimate setAlpha:0];
        [UIView commitAnimations];
        
       
            [self performSelector:@selector(fireFinishDelegate) withObject:nil afterDelay:1];
         
        
        
    }
    

     

    

    
}

- (void)fireFinishDelegate
{
    if(self.delegate && [self.delegate respondsToSelector:@selector(finishAnimation)])
    {
    
        [self.delegate finishAnimation];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

/*
- (BOOL)shouldAutorotate{
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
   return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}

*/

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}
@end
