//
//  CoinView.m
//  new
//
//  Created by Elbin John on 22/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "CoinView.h"

@implementation CoinView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (void) setCoinValue :(float)coin
{
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        self.frame = CGRectMake(0, 0, 50, 50);
    }
    else
    {
        self.frame = CGRectMake(0, 0, 120 , 120);
    }
        
    _coinValue = coin;
    
    NSString * imgname = @"coin1";
    if(coin == 1)
    {
        imgname = @"coin1";
    }
    if(coin == 2)
    {
        imgname = @"coin2";
    }
    if(coin == 5)
    {
        imgname = @"coin1";
    }    
    if(coin == 10)
    {
        imgname = @"coin6";
    }
    
    if(coin == 0.10f)
    {
        imgname = @"coin5";
    }
    
    if(coin == 0.20f)
    {
        imgname = @"coin4";
    }
    
    if(coin == 0.50f)
    {
        imgname = @"coin5";
    }
    
    UIImage * image = [UIImage imageNamed:imgname];
    self.coinImage.image = image;
	
	CGRect coinFrame = self.coinImage.frame;
	if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
		if (coin < 1) {
			coinFrame.size = CGSizeMake(40, 40);
		} else {
			coinFrame.size = CGSizeMake(50, 50);
		}
	} else {
		if (coin < 1) {
			coinFrame.size = CGSizeMake(80, 80);
		} else {
			coinFrame.size = CGSizeMake(120, 120);
		}
	}
	coinFrame.origin.x = (self.frame.size.width - coinFrame.size.width) / 2;
	coinFrame.origin.y = (self.frame.size.height - coinFrame.size.height) / 2;
	
	[self.coinImage setFrame:coinFrame];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    [self.superview bringSubviewToFront:self];
    UITouch *touch = [touches anyObject];
    CGPoint touchPoint = [touch locationInView:self.superview];
    CGRect touchtoFrame = CGRectMake(touchPoint.x, touchPoint.y,10, 10);
    lastpoint = touchPoint;
    
    CGRect cornerOne = CGRectMake(0,0, 10, 10);
    CGRect cornertwo = CGRectMake(self.frame.size.width-1, 0, 10, 10);
    
    CGRect cornerthree = CGRectMake(0,self.frame.size.height-2, 10, 10);
    CGRect cornerfour = CGRectMake(self.frame.size.width-1, self.frame.size.height-1, 10, 10);
    
    NSLog(@"%@",NSStringFromCGRect(cornerthree));
    NSLog(@"%@",NSStringFromCGRect(touchtoFrame));
    
    if (CGRectIntersectsRect(touchtoFrame,cornerOne)|| CGRectIntersectsRect(touchtoFrame,cornertwo)||CGRectIntersectsRect(touchtoFrame,cornerthree)||CGRectIntersectsRect(touchtoFrame,cornerfour)) {
        
        isMove = NO;
        isSize =NO;//Disabled Size
    }
    else {
        isMove = YES;
        isSize =NO;
    }
        if(self.delgate && [self.delgate respondsToSelector:@selector(touchBeganView:)]){
            [self.delgate touchBeganView:self];
        }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    UITouch *touch = [touches anyObject];
    CGPoint touchPoint = [touch locationInView:self.superview];
    
    if(isSize){
        
        int sizeWidth  = (touchPoint.x - lastpoint.x);
        int sizeheight = (touchPoint.y - lastpoint.y);
        
        int width  = self.frame.size.width +(sizeWidth);
        int height = self.frame.size.height+(sizeheight);
        
        [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y,width,height)];
    }
    else if(isMove){
        
        float orginx = self.frame.origin.x+(touchPoint.x - lastpoint.x);
        float orginy = self.frame.origin.y+(touchPoint.y - lastpoint.y);
        
        
        if(orginx > self.superview.frame.size.height-25)
        {
           // orginx = self.superview.frame.size.height-25;
        }

        
        if(orginy > self.superview.frame.size.width-25)
        {
           // orginy = self.superview.frame.size.width-25;
        }

        orginx = (orginx<0? 0: orginx);
        orginy = (orginy<0? 0: orginy);
        
        
        [self setFrame:CGRectMake(orginx,orginy ,self.frame.size.width,self.frame.size.height)];        
        
        
//        NSLog(@"My Frame %@",NSStringFromCGRect(self.frame));
        
        
        [self bringSubviewToFront:self.superview];
        /*
        [UIView beginAnimations:@"1" context:NULL];
//        [UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:.2];
        
        [UIView commitAnimations];
         
         */

        
        
        if(self.delgate && [self.delgate respondsToSelector:@selector(touchMovingView:)]){
            [self.delgate touchMovingView:self];
        }
        
        
        
        
        
        
        
    }
    lastpoint = touchPoint;
}

- (void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event
{
    isMove = NO;
    isSize =NO;
    if(self.delgate && [self.delgate respondsToSelector:@selector(touchEndedView:)])
    {
        [self.delgate touchEndedView:self];
    }

}

- (void)touchesCancelled:(NSSet*)touches withEvent:(UIEvent*)event
{
    isMove = NO;
    isSize =NO;
}

- (void)dropAnimationPlay
{
    
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
