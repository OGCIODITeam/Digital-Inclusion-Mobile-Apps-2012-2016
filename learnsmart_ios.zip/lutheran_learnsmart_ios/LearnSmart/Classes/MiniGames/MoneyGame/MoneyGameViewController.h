//
//  MoneyGameViewController.h
//  new
//
//  Created by Elbin John on 22/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoinView.h"

@interface MoneyGameViewController : UIViewController <CoinViewDelegate> {
	IBOutlet UILabel * plateCoinLabel;
}
@property (assign, nonatomic) NSInteger gameTypeId;
@end
