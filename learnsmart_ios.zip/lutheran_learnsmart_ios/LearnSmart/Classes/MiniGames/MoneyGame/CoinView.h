//
//  CoinView.h
//  new
//
//  Created by Elbin John on 22/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CoinViewDelegate <NSObject>

- (void)touchBeganView:(UIView*)viewselected;
- (void)touchMovingView:(UIView*)viewselected;
- (void)touchEndedView:(UIView*)viewselected;


@end

@interface CoinView : UIView
{
    CGPoint lastpoint;
    BOOL isMove;
    BOOL isSize;
}

@property(nonatomic,assign)IBOutlet UIImageView * coinImage;
@property(nonatomic,assign)IBOutlet UILabel * cointext;

@property(nonatomic,assign)float coinValue;
@property(nonatomic,assign)id <CoinViewDelegate> delgate;

- (void)dropAnimationPlay;

@end
