//
//  MoneyGameViewController.m
//  new
//
//  Created by Elbin John on 22/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "MoneyGameViewController.h"
#import "gameFinishView.h"
#import "PlayMusic.h"
#import "CoinGameFinish.h"
 

@interface MoneyGameViewController ()
{
    NSMutableArray * inList;
    NSMutableArray * outList;
    CGRect movedLast;
    
    float purchasedValue;
    
    NSTimer * tmr;
    NSTimer * gameTime;
    gameFinishView* gameFinishView1;
    int gameLevelCount;
    
    CoinGameFinish *  gameFinish;
     
    float totalTime;
    BOOL isClosedSound;
    BOOL gameStarted;
    BOOL successAttempt;
    
}

@property (assign, nonatomic) IBOutlet UIView *playArea;
@property (assign, nonatomic) IBOutlet UILabel *coinPurchased;
@property (assign, nonatomic) IBOutlet UIView *coinoutView;
@property (assign, nonatomic) IBOutlet UIView *coinInview;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *timeTicker;
@property (strong, nonatomic) IBOutlet UIImageView *animatingImage;

@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *girlstandingAnimate;
- (void)outCoins :(NSArray*) items;
- (void)updatePlateCoinValue:(double)coinValue;
@end

@implementation MoneyGameViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    inList  = [NSMutableArray new];
    outList = [NSMutableArray new];
    isClosedSound=[[NSUserDefaults standardUserDefaults]boolForKey:@"sound"];
    _timeTicker.text = @"00:00";
    gameLevelCount = 0;
    gameStarted = NO;
    successAttempt = NO;
    // Do any additional setup after loading the view from its nib.
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self strartGame];
    if(self.gameTypeId==3){
        plateCoinLabel.hidden=true;
    }
}

- (void)loadgame
{
    switch (self.gameTypeId) {
        case 1:
             [self initiCoins:1:10:NO];
            break;
        case 2:
            [self initiCoins:10:50:NO];
            break;
        case 3:
            [self initiCoins:50:100:YES];
            break;                        
        default:
            break;
    }
   
}



 

- (void) strartGame
{
     
    if (gameLevelCount == 0) {
        
        [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Game Start or finished" ofType:@"WAV"]]];
        [self initPlayerView];
        
    }
    else
    {
        [self animationDidStop:@""];
    }
    gameLevelCount ++;
    
    
    
    
        
}


- (void)initPlayerView
{
    
         
    [self.view addSubview:self.animatingImage];
    self.animatingImage.transform = CGAffineTransformMakeRotation(-M_PI);
    self.animatingImage.frame = CGRectMake(((self.view.frame.size.width/2)-(self.animatingImage.frame.size.width)/2),-(self.animatingImage.frame.size.width)/2, self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
    [self.animatingImage setAlpha:1];
    
    
    //self.animatingImage.transform  = CGAffineTransformRotate(self.animatingImage.transform,2);
    
    //self.animatingImage.frame = CGRectMake((self.view.frame.size.height/2)-75,(self.view.frame.size.width/2)-75, 150, 150);
    self.view.userInteractionEnabled = FALSE;
    
    //self.animatingImage.transform  = CGAffineTransformRotate(self.animatingImage.transform,M_PI/4);
    
    // CGAffineTransform t = CGAffineTransformRotate(self.animatingImage.transform, -0.78);
    //self.animatingImage.transform = t;
    
    // self.animatingImage.transform=CGAffineTransformRotate(self.animatingImage.transform, (((60*22)/7)/240));
    
    
    /*
     CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
     animation.fromValue = [NSNumber numberWithFloat:-1];
     animation.toValue = [NSNumber numberWithFloat: 1];
     animation.duration = .9f;
     animation.repeatCount = 1;
     [self.animatingImage.layer addAnimation:animation forKey:@"SpinAnimation"];
     
     */
    
    [UIView animateWithDuration:0.8f
                     animations:^{
                         self.animatingImage.transform = CGAffineTransformMakeRotation(2*M_PI);
                     }];
    [UIView beginAnimations:@"1" context:NULL];
    
    
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1.5];
    //    self.animatingImage.transform=CGAffineTransformRotate(self.animatingImage.transform, (((60*22)/7)/240));
    //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
    self.animatingImage.frame =CGRectMake(((self.view.frame.size.width/2)-((self.animatingImage.frame.size.width)/2)),(self.view.frame.size.height/2)-((self.animatingImage.frame.size.height)/2), self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
    
    //CGPointMake(((self.view.frame.size.height/2)), (self.view.frame.size.width/2));
    // t = CGAffineTransformRotate(self.animatingImage.transform, 0.78);
    //self.animatingImage.transform  = CGAffineTransformRotate(self.animatingImage.transform,2);
    
    
    
    
    
    [UIView commitAnimations];
    
    
    
    
    
}

- (void)initPlayerViewPartTwo
{
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"ready go" ofType:@"mp3"]]];
    [UIView beginAnimations:@"2" context:NULL];
    //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1.5];
    //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
    self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-50,self.animatingImage.frame.origin.y-50, self.animatingImage.frame.size.width+ 100, self.animatingImage.frame.size.height+100);
    [self.animatingImage setAlpha:0];
    [UIView commitAnimations];
    
}


-(void)animationDidStop:(NSString *)animationId
{
    //    [PlayMusic sharedInstanceGameBg].repeatSound = YES;
    //    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"bg music during the game" ofType:@"mp3"]]];
    
    
    
    
    
    if([animationId intValue] == 1)
    {
        
        
        
        
        [self performSelector:@selector(initPlayerViewPartTwo) withObject:nil afterDelay:1];
        
    }
    else
    {
        [self.animatingImage removeFromSuperview];
        
        
        
        
        
        self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-25,self.animatingImage.frame.origin.y-25, self.animatingImage.frame.size.width- 100, self.animatingImage.frame.size.height- 100);
        
        
        
        self.view.userInteractionEnabled = TRUE;
        NSDate * date = [NSDate date];
        gameTime = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(playerTimeGo:) userInfo:date  repeats:YES];
        
//        _timeTicker.text = @"00:00";
        
        if (!gameStarted) {
            if(!isClosedSound){
                [PlayMusic sharedInstanceGameBg].repeatSound = YES;
                [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"bg music during the game" ofType:@"mp3"]]];
            }
            else{
                [PlayMusic sharedInstanceGameBg].repeatSound = NO;
            }
            gameStarted = YES;
        }
        
        
               
        [self loadgame];
        
        
    }
    
    
    
    
    
}


 - (void)resetGame
{
    
    for (CoinView * ccr in inList)
    {
        [ccr removeFromSuperview];
    }
    
    for (CoinView * ccr in outList)
    {
        [ccr removeFromSuperview];
    }
    
    [inList removeAllObjects];
    [outList removeAllObjects];
    
}

- (void)playerTimeGo:(NSTimer *)timer;
{
    /*NSDate * dd=  timer.userInfo;
     NSDate * dt = [NSDate date];
     NSTimeInterval  cr = [dt timeIntervalSinceDate:dd];
     */
    
    totalTime+=1;
    
    NSInteger ti = (NSInteger)totalTime;
    NSInteger seconds = ti % 60;
    NSInteger minutes = (ti / 60) % 60;
    //NSInteger hrs  = (ti / 3600);
    // NSLog(@"Time added");
   // totalTime=ti;
    
    
    
    //  NSInteger hours = (ti / 3600);
    //[NSString stringWithFormat:@"%02i:%02i:%02i", hours, minutes, seconds];
    
    
    /*
     if(cr>=60.00)
     cr = cr/60;
     else
     cr = cr/100;
     
     */
    
    //    if(cr>50)
    //    {
    //        cr= cr/60;
    //          cr = cr/10;
    //    }
    //    else
    //    {
    //    NSLog(@"|||||| = %02.2f",cr);
    //    cr = cr/100;
    //    }
    
    
    _timeTicker.text = [NSString stringWithFormat:@"%02i:%02i",minutes ,seconds];
}




- (void)viewDidAppear:(BOOL)animated
{
 
    [super viewDidAppear:animated];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initiCoins :(int) minMoney :(int) maxMoney :(BOOL) IsdecimalNeed;
{
    
    [self resetGame];
    
  // int numberOfcoinPass = arc4random() % numberOfcoin;// ------------
    
    
//    int numberOfMatchElement = arc4random() % maxMoney;
    int ar[maxMoney -minMoney ],d;
    int tmpswap;
    
    
    for(int i = 0; i < (  maxMoney- minMoney); i++)
    {
        ar[i]= minMoney+i;
    }
    
    for(int i = 0; i < (maxMoney- minMoney); i++) {
        d =  arc4random() % (maxMoney- minMoney);
       //  NSLog(@"____%d",ar[i]);
        tmpswap = ar[i];
        ar[i]   = ar[d];
        ar[d]   = tmpswap;
        
        //ar[i] = arc4random() % maxMoney;;
    }
    
    /*
    for(int i = 0; i < 6; i++) {
        d =  arc4random() % maxMoney;
        
        
        ar[i]   = d;
         
    }
    purchasedValue = 0;
    for (int i = 0; i< arc4random() % maxMoney; i++)
    {
        
        purchasedValue +=  ar[i];
    }
    */
    

    purchasedValue = 0;
    while (purchasedValue == 0) {
        
         purchasedValue =  ar[arc4random() % (maxMoney- minMoney)];
    }
    
    float decimal =0;
    if(IsdecimalNeed)
    {
        while (0== decimal)
        {
             decimal =  arc4random() % 10;
            
        }
       // decimal = decimal%10;
        decimal = decimal/10;
        
    }
    purchasedValue +=decimal;
   
        
    for (int i = 0; i< 7; i++)
    {
        CoinView * cv = (CoinView*)[[[NSBundle mainBundle] loadNibNamed:@"CoinView" owner:self options:nil] objectAtIndex:0];
         cv.delgate = self;
        
        if(i == 0 )
        {
        
//            [cv setCoinValue:<#(float)#>]
            cv.coinValue =1;
            cv.cointext.text = @"1";
        
        }
        
   
        if(i == 1 )
        {
            
            cv.coinValue =2;
            cv.cointext.text = @"2";
            
        }
        
        
        
        if(i == 2 )
        {
            
            cv.coinValue =5;
            cv.cointext.text = @"5";
            
        }
        

        
        if(i == 3 )
        {
            
            cv.coinValue =10;
            cv.cointext.text = @"10";
            
        }
        
        
        if(i == 4 )
        {
            
            cv.coinValue =.1;
            cv.cointext.text = @"10";
            
        }
        
        
        if(i == 5 )
        {
            
            cv.coinValue =.2;
            cv.cointext.text = @"20";
            
        }
        
        
        if(i == 6 )
        {
            
            cv.coinValue =.5;
            cv.cointext.text = @"50";
            
        }
        
        
        
        
        [inList addObject:cv];
        
    }
    
   
    
    [self incoinRearrange:YES];
    self.coinPurchased.text = [NSString stringWithFormat:@"%.2f",purchasedValue];    
}


- (void)incoinRearrange:(BOOL)isNew {
    CGRect rect = CGRectZero;
    float xval = self.coinInview.frame.origin.x+2;
    float yval = self.coinInview.frame.origin.y+25;
    for (CoinView * ccr in inList) {
        rect = CGRectMake(xval, yval, ccr.frame.size.width, ccr.frame.size.height);
        if(xval+ccr.frame.size.width >= self.coinInview.frame.origin.x+ self.coinInview.frame.size.width) {
            yval += ccr.frame.size.height+2;
			if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
				xval = self.coinInview.frame.origin.x+25;
			} else {
				xval = self.coinInview.frame.origin.x + 70;
			}
            rect = CGRectMake(xval, yval, ccr.frame.size.width, ccr.frame.size.height);
            
        }
        ccr.frame = rect;
        if(isNew) {
			
            [self.playArea addSubview:ccr];
			
        }
        xval += (ccr.frame.size.width + 2 );
    }
}

- (void)outCoins :(NSArray*) items {
    
    CGRect rect = CGRectZero;
    float xval = self.coinoutView.frame.origin.x+2;
    float yval = self.coinoutView.frame.origin.y+2;
    float calculateSum = 0.0f;
    for (CoinView * ccr in outList) {
        
 
        rect = CGRectMake(xval, yval, ccr.frame.size.width, ccr.frame.size.height);
        if(xval+ccr.frame.size.width >= self.coinoutView.frame.origin.x+ self.coinoutView.frame.size.width) {
            yval += ccr.frame.size.height+2;
            xval = self.coinoutView.frame.origin.x+2;
            rect = CGRectMake(xval, yval, ccr.frame.size.width, ccr.frame.size.height);
            
        }
        ccr.frame = rect;
     
        xval += (ccr.frame.size.width + 2 );
        calculateSum += ccr.coinValue;
        
    }
}


- (BOOL)calculateSum
{
    //BOOL retVal =FALSE;
    float calculateSum = 0.0f;
    for (CoinView * ccr in outList)
    {
    
        calculateSum += ccr.coinValue;
        
    }
	[self updatePlateCoinValue:calculateSum];
    
    NSLog(@"%f-------%f", calculateSum, purchasedValue);
    
    NSLog(@" \n /n %@    %@",[NSString stringWithFormat:@"%.2f",calculateSum] ,[NSString stringWithFormat:@"%.2f",purchasedValue]);
    if([[NSString stringWithFormat:@"%.2f",calculateSum] isEqualToString:[NSString stringWithFormat:@"%.2f",purchasedValue]])
    {
		[self updatePlateCoinValue:.0f];
        successAttempt = YES;
        //[[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"coins drop" ofType:@"wav"]]];
        [self levelFinish];
    }else if (calculateSum <= purchasedValue) {
        successAttempt = YES;
        //[[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"coins drop" ofType:@"wav"]]];
    }
    else
    {
        
        successAttempt = NO;
        NSLog(@"Failed");
    }
	
	return successAttempt;
}

#pragma founDelegate
- (void)touchBeganView:(UIView*)viewselected
{
    movedLast = viewselected.frame;
     [self.girlstandingAnimate stopAnimating];
    
//    [viewselected  ]
    
}

- (void)touchMovingView:(UIView *)viewselected {
	// do nothing
}


- (void)touchEndedView:(UIView *)viewselected
{
 
   // [self calculateSum];
    
    if(CGRectContainsRect(self.coinoutView.frame, viewselected.frame) )
    {
     
        
        
        if(CGRectContainsRect(self.coinoutView.frame, movedLast))
        {
            
        }
        else
        {
         
           
         
            
            CoinView * cv = (CoinView*)[[[NSBundle mainBundle] loadNibNamed:@"CoinView" owner:self options:nil] objectAtIndex:0];
            float cval = ((CoinView*)viewselected).coinValue;
            NSString * cvaltext =  ((CoinView*)viewselected).cointext.text;
            cv.coinValue =  cval;
            cv.cointext.text = cvaltext;
            
            cv.delgate = self;
            cv.frame = movedLast;
            [self.playArea addSubview:cv];
            [cv setNeedsDisplay];
            [inList addObject:cv];
            
            
            [outList removeObject:viewselected];
            [inList removeObject:viewselected];
            
            CoinView *selctdCoin = (CoinView*)viewselected;
            
            float calculateSum = 0.0f;
            for (CoinView * ccr in outList)
            {
                
                calculateSum += ccr.coinValue;
                
            }
            
            
            if (selctdCoin.coinValue <= purchasedValue && (calculateSum + selctdCoin.coinValue) <= purchasedValue) {
                [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"coins drop" ofType:@"wav"]]];
                [outList addObject:viewselected];
            }
            else{
                [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"wrong linked" ofType:@"mp3"]]];
                viewselected.frame = movedLast;
                [viewselected bringSubviewToFront:viewselected.superview];
            }
            
            
            
            
           /* [self calculateSum];
            
            if (successAttempt) {
                
                
                [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"yeah" ofType:@"mp3"]]];

            }
            else{
                viewselected.frame = movedLast;
                [viewselected bringSubviewToFront:viewselected.superview];
            }
            
        */
            
        }
       
        
    }
    else if(CGRectContainsRect(self.coinInview.frame, viewselected.frame))
    {
        if(CGRectContainsRect(self.coinInview.frame, movedLast))
        {
      /*  [outList removeObject:viewselected];
        [inList removeObject:viewselected];        
        [inList addObject:viewselected];
          */
            
            viewselected.frame = movedLast;
            [viewselected bringSubviewToFront:viewselected.superview];
            
        }
        else
        {
            [outList removeObject:viewselected];
            [inList removeObject:viewselected];
             [viewselected removeFromSuperview];
        }
        
    }
    else
    {
        
        if(CGRectContainsRect(self.coinoutView.frame, movedLast))
        {
            [outList removeObject:viewselected];
            [inList removeObject:viewselected];
            [viewselected removeFromSuperview];
        }
        else
        {
        viewselected.frame = movedLast;
        [viewselected bringSubviewToFront:viewselected.superview];
        }
    }

    [self calculateSum];
    
    
    //[self incoinRearrange:NO];
//[self outCoins:nil];


}


- (void) levelFinish
{
    //////////////////
    
    //[[PlayMusic sharedInstanceGameBg]stopPlayback ];
    
    
    
    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"game finished" ofType:@"mp3"]]];
    
    
    NSString * nibname = @"gameFinishView";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibname = @"gameFinishViewIphone";
    }
    
    gameFinishView1  = (gameFinishView*)[[[NSBundle mainBundle] loadNibNamed:nibname owner:nil options:nil] objectAtIndex:0];
    gameFinishView1.frame = CGRectMake(((self.view.frame.size.width/2)-(gameFinishView1.frame.size.width/2)), (self.view.frame.size.height/2)-(gameFinishView1.frame.size.height/2), gameFinishView1.frame.size.width, gameFinishView1.frame.size.height);
    
    
    
    ///actual value 10
    if (gameLevelCount == 10) {
        [self.view addSubview:gameFinishView1];
        gameFinishView1.delegate = self;
        [[PlayMusic sharedInstanceGameBg]stopPlayback ];
        [gameFinishView1 loadAnimatedGo];
        
    }
    else{
        
        [self finishAnimation];
    }
    
}


/*
- (void) levelFinish
{
    NSString * nibname = @"gameFinishView";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibname = @"gameFinishViewIphone";
    }
    
    gameFinishView1  = (gameFinishView*)[[[NSBundle mainBundle] loadNibNamed:nibname owner:nil options:nil] objectAtIndex:0];
    gameFinishView1.frame = CGRectMake(((self.view.frame.size.width/2)-(gameFinishView1.frame.size.width/2)), (self.view.frame.size.height/2)-(gameFinishView1.frame.size.height/2), gameFinishView1.frame.size.width, gameFinishView1.frame.size.height);
    
    
    
    ///actual value 10
    if (gameLevelCount == 10) {
        [self.view addSubview:gameFinishView1];
        gameFinishView1.delegate = self;
        
        [gameFinishView1 loadAnimatedGo];
        
    }
    else{
        gameFinishView1.delegate = self;
        
        [gameFinishView1 loadAnimatedGo];
    }
    
}

*/
- (void)finishAnimation
{
    
    self.girlstandingAnimate.animationImages  = [NSArray arrayWithObjects:[UIImage imageNamed:@"Animation_Money_Girl1.png"], [UIImage imageNamed:@"Animation_Money_Girl2.png"],[UIImage imageNamed:@"Animation_Money_Girl3.png"],[UIImage imageNamed:@"Animation_Money_Girl4.png"], nil];
    self.girlstandingAnimate.animationDuration    = 0.8f;
    [self.girlstandingAnimate startAnimating];
    
//    x+=totalTime;
    
    [gameTime invalidate];
    gameFinishView1.delegate = nil;
    [gameFinishView1 removeFromSuperview];
    ////actual value 9
    if(gameLevelCount>9)
    {
        /*  NSInteger ti1 =x;
         NSInteger seconds1 = ti1 % 60;
         NSInteger minutes1 = (ti1 / 60) % 60;
         
         
         NSLog(@"Total time---------%@",[NSString stringWithFormat:@"%02i:%02i",minutes1 ,seconds1]);*/
//        [self dismissModalViewControllerAnimated:NO];
        
        NSString * nibname = @"CoinGameFinish";
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            
            nibname = @"CoinGameFinishIphone";
        }
        
        
        gameFinish = [[CoinGameFinish alloc] initWithNibName:nibname bundle:nil];
        gameFinish.gameTypeId = self.gameTypeId;
        /*  NSInteger ti =x;
         NSInteger seconds = ti % 60;
         NSInteger minutes = (ti / 60) % 60;
         
         
         NSLog(@"===========%d", ti);*/
        
        
        //gameFinish.finishTime = [NSString stringWithFormat:@"%02i:%02i",minutes ,seconds];
        gameFinish.finishTime = _timeTicker.text;
        gameFinish.gameType =self.gameTypeId;
        [self.navigationController pushViewController:gameFinish animated:YES];
    }
    else
    {
        
        ///[[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"coins drop" ofType:@"wav"]]];
        [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"yeah" ofType:@"mp3"]]];
        [self strartGame];
        
        [self.view setNeedsDisplay];
    }
    
}


- (IBAction)onBackButtonClicked:(id)sender {
     [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Learn Smart"
                                                    message:@"確認退出?"
                                                   delegate:self
                                          cancelButtonTitle:nil otherButtonTitles:@"YES", @"NO", nil];
    
    [alert show];
    
}

#pragma UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        //[self.navigationController popViewControllerAnimated:YES];
        /*NSArray *vcs = [self.navigationController viewControllers];
         for (UIViewController *each in vcs) {
         if ([vcs isKindOfClass:[GameAppViewController class]]) {
         [self.navigationController popToViewController:each animated:YES];
         break;
         }
         }*/
        [[PlayMusic sharedInstanceGameBg] stopPlayback];
        [self.navigationController popViewControllerAnimated:YES];
    }
}


- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}

- (void)viewDidUnload {
    [self setGirlstandingAnimate:nil];
    [super viewDidUnload];
}

#pragma plate coin label related

- (void)updatePlateCoinValue:(double)coinValue {
	NSLog(@"! MoneyGameVC: updatePlateCoinValue: %.02f", coinValue);
	plateCoinLabel.text = [NSString stringWithFormat:@"$%.02f", coinValue];
}

@end
