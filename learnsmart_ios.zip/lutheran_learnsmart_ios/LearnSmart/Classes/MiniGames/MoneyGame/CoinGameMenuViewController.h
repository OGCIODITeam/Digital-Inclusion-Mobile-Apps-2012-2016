//
//  CoinGameMenuViewController.h
//  GameApp
//
//  Created by Elbin John on 03/08/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppConfig, DeviceHelper;

@interface CoinGameMenuViewController : UIViewController {
	IBOutlet UIImageView * animatedGirlView;
	AppConfig * appConfig;
	DeviceHelper * deviceHelper;
}

@end
