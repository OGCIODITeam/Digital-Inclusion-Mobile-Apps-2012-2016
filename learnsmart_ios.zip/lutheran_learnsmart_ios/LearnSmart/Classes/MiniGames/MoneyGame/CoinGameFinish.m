//
//  CoinGameFinish.m
//  GameApp
//
//  Created by Elbin John on 03/08/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "CoinGameFinish.h"
#import "CoinGameMenuViewController.h"
#import "PlayMusic.h"

@interface CoinGameFinish ()

- (IBAction)homeclicked:(id)sender;
- (IBAction)loadNext:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *gametime;


@end

@implementation CoinGameFinish

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"level clear" ofType:@"mp3"]]];
 
    self.gametime.text = _finishTime;
    
    cheerAnimation.animationImages  = [NSArray arrayWithObjects:[UIImage imageNamed:@"cheer1.png"], [UIImage imageNamed:@"cheer2.png"], nil];
    cheerAnimation.animationDuration    = 0.8f;
    [cheerAnimation startAnimating];
    
    
    switch (self.gameTypeId) {
        case 1:
            gameFinishText.image        = [UIImage imageNamed:@"money_change_Easy.png"];
            break;
        case 2:
            gameFinishText.image        = [UIImage imageNamed:@"money_change_medium.png"];
            break;
        case 3:
            gameFinishText.image        = [UIImage imageNamed:@"money_change_difficult.png"];
            break;
//        case 4:
//            gameFinishText.image        = [UIImage imageNamed:@"Memory card.png"];
//            break;
            
        default:
            break;
    }

    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)loadNext:(id)sender {
    [[PlayMusic sharedInstanceGameBg] stopPlayback];
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
   /* if(self.gameType == 0)    {
        
        for(id tmp in self.navigationController.childViewControllers)
        {
            if(tmp && [tmp isKindOfClass:[CoinGameMenuViewController class]])
            {
                [self.navigationController popToViewController:tmp animated:YES];
            }
        }
        
    }
    else  if(self.gameType == 1)
    {*/
        [self.navigationController popToRootViewControllerAnimated:YES];
    //}
    
    
}


- (IBAction)homeclicked:(id)sender {
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    [self.navigationController popToRootViewControllerAnimated:YES];
}


/*
 - (BOOL)shouldAutorotate{
 return NO;
 }
 
 - (NSUInteger)supportedInterfaceOrientations{
 return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
 }
 
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
 return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
 }
 */

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}


 


@end
