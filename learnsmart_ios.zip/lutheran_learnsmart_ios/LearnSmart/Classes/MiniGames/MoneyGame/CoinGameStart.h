//
//  CoinGameStart.h
//  GameApp
//
//  Created by Elbin John on 03/08/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol CoinStartGameDelegate <NSObject>

- (void)continueClickedDelegate;

@end

@interface CoinGameStart : UIViewController

@property (nonatomic,assign) id <CoinStartGameDelegate> delegate;
@property (assign, nonatomic) NSInteger gameTypeId;





@end
