//
//  CoinGameMenuViewController.m
//  GameApp
//
//  Created by Elbin John on 03/08/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "CoinGameMenuViewController.h"
#import "AppConfig.h"
#import "CheckPointLoggerAgent.h"
#import "DeviceHelper.h"
#import "MoneyGameViewController.h"
#import "CoinGameStart.h"
#import "PlayMusic.h"

@interface CoinGameMenuViewController ()
{
    int selectedLevel;   
    NSInteger levelTypeId;
}

- (void)initGirlAnimation;
- (void)logCheckpoint;
- (void)startGirlAnimation;
- (void)stopGirlAnimation;

@end

@implementation CoinGameMenuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	appConfig = [AppConfig getInstance];
	deviceHelper = [DeviceHelper getInstance];
	[self initGirlAnimation];
	[self logCheckpoint];
}

- (void)viewWillAppear:(BOOL)animated {
	[self startGirlAnimation];
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
	[self stopGirlAnimation];
	[super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma girl animation
- (void)initGirlAnimation {
	NSMutableArray * animatedGirlFrames = [NSMutableArray array];
	NSString * deviceSuffix;
	
	if ([deviceHelper isiPad]) {
		deviceSuffix = @"ipad";
	} else {
		deviceSuffix = @"iphone";
	}
	
	for (int i=1; i<=appConfig.numAnimatedGirlFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", i, deviceSuffix]]];
	}
	
	for (int i=1; i<appConfig.numAnimatedGirlPauseFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", appConfig.numAnimatedGirlFrames, deviceSuffix]]];
	}
	
	animatedGirlView.animationImages = animatedGirlFrames;
	animatedGirlView.animationDuration = 1.50f;
	animatedGirlView.animationRepeatCount = INFINITY;
}

- (void)startGirlAnimation {
	[animatedGirlView startAnimating];
}

- (void)stopGirlAnimation {
	[animatedGirlView stopAnimating];
}

#pragma checkpoint logger
- (void)logCheckpoint {
	[[CheckPointLoggerAgent new] logForMiniGamePlay:appConfig.miniGameCheckpointChange];
}

#pragma game implementation
- (IBAction)levelClicked:(id)sender {
    
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    selectedLevel = [sender tag];
    
    NSString * nibName = @"CoinGameStart";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibName = @"CoinGameStartIphone";
    }
    
    CoinGameStart * coinGameStart = [[CoinGameStart alloc] initWithNibName:nibName bundle:nil];
    coinGameStart.delegate = self;
    coinGameStart.gameTypeId   = [sender tag];
    levelTypeId                 = [sender tag];
    
 
    
    [self.navigationController pushViewController:coinGameStart animated:YES];
    
}


- (void)continueClickedDelegate
{
       
    NSString * nibName = @"MoneyGameViewController";    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        
        nibName =  @"MoneyGameViewControllerIphone";
        
    }
    
    MoneyGameViewController * moneyGameViewController = [[MoneyGameViewController alloc] initWithNibName:nibName bundle:nil];
    moneyGameViewController.gameTypeId = levelTypeId;
    [self.navigationController pushViewController:moneyGameViewController animated:YES];
    
    
    
    
    
    
}

- (IBAction)homeClicked:(id)sender {
     [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    [self.navigationController popViewControllerAnimated:YES];
}



- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}





@end
