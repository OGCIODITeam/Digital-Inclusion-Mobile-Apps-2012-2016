//
//  NavigationController.h
//  GameApp
//
//  Created by Sreekanth R on 24/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationController : UINavigationController

@end
