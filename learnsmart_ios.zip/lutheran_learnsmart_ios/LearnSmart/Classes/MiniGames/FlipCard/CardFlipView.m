//
//  CardFlipView.m
//  FlipTest
//
//  Created by Elbin John on 27/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "CardFlipView.h"
#import "PlayMusic.h"

#define kTransitionDuration    0.75

@interface CardFlipView()
{
    
    
}

@property(nonatomic,assign)BOOL isFound;
@property(nonatomic,assign)BOOL isValueShown;
@property (unsafe_unretained, nonatomic) IBOutlet UIButton *selectbtn;


@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *animateImage;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *flipToview;
- (IBAction)flipClicked:(id)sender;

@end

@implementation CardFlipView

@synthesize delegate;
@synthesize itemIdNumber;
@synthesize itemImage;
@synthesize isFound;
@synthesize isValueShown;
@synthesize selectbtn;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}




- (void)flipView
{
    /*
    if(!self.isFound)
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:kTransitionDuration];
        [UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
        
        if(self.isValueShown)
        {
            
            [self.flipToview setHidden:YES];
            [self.itemImage setHidden:NO];
            
        }
        else
        {
            [self.itemImage setHidden:YES];
            [self.flipToview setHidden:NO];
            
        }
        [UIView commitAnimations];
        self.isValueShown = !self.isValueShown;
    }
    
    */
    
    self.selectbtn.userInteractionEnabled = FALSE;
      @synchronized(self)
    {
      self.isValueShown = !self.isValueShown;
    
    [UIView animateWithDuration:kTransitionDuration
                     animations:^{
                         
                         [UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];                                                 
                         if(self.isValueShown)
                         {
                             
                             [self.flipToview setHidden:YES];
                             [self.itemImage setHidden:NO];
                             
                         }
                         else
                         {
                             [self.itemImage setHidden:YES];
                             [self.flipToview setHidden:NO];
                             
                         }

                         
                     }
                     completion:^(BOOL finished){

                         
                         
                         
                         
                     }];
   
    
    
    
    }
   
    self.selectbtn.userInteractionEnabled = YES;
    
    
}



- (void)flipView:(BOOL)isVisibele
{
    /*
     if(!self.isFound)
     {
     [UIView beginAnimations:nil context:NULL];
     [UIView setAnimationDuration:kTransitionDuration];
     [UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
     
     if(self.isValueShown)
     {
     
     [self.flipToview setHidden:YES];
     [self.itemImage setHidden:NO];
     
     }
     else
     {
     [self.itemImage setHidden:YES];
     [self.flipToview setHidden:NO];
     
     }
     [UIView commitAnimations];
     self.isValueShown = !self.isValueShown;
     }
     
     */
    
    self.selectbtn.userInteractionEnabled = FALSE;
    @synchronized(self)
    {
        
        
        [UIView animateWithDuration:kTransitionDuration
                         animations:^{
                             
                             [UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
                             if(self.isValueShown)
                             {
                                 
                                 [self.flipToview setHidden:YES];
                                 [self.itemImage setHidden:NO];
                                 
                             }
                             else
                             {
                                 [self.itemImage setHidden:YES];
                                 [self.flipToview setHidden:NO];
                                 
                             }
                             
                             
                         }
                         completion:^(BOOL finished){
                             
                             
                             self.isValueShown = !self.isValueShown;
                             
                             
                         }];
        
        
        
        
    }
    self.selectbtn.userInteractionEnabled = YES;
    
    
}




- (void)setFound
{
    self.isFound = YES;

}

- (void)foundAnimation
{
    
    
    //self.animateImage.frame = CGRectMake(0,0, self.frame.size.width/2, self.frame.size.height/2);
 //   self.animateImage.center = self.center;
    [self.animateImage setAlpha:.8];
    [UIView beginAnimations:@"0" context:NULL];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:.2];
     
    self.animateImage.frame = [self bounds];// CGRectMake(0,0, self.frame.size.width, self.frame.size.height);
   // self.animateImage.center = self.center;
    [self.animateImage setAlpha:0];
    [UIView commitAnimations];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (IBAction)flipClicked:(id)sender {
    
    if(!self.isFound)
    { [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
        if(self.delegate && [self.delegate respondsToSelector:@selector(itemSelected:)])
        {
            [self.delegate itemSelected:self];
        }
        
    }
}
@end
