//
//  FlipCardStart.m
//  GameApp
//
//  Created by Sreekanth R on 27/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "FlipCardStart.h"
#import "CardMainViewController.h"
#import "PlayMusic.h"
#import "GameAppViewController.h"

@interface FlipCardStart ()

@end

@implementation FlipCardStart

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)continueCliced:(id)sender{
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    NSString * nibName = @"CardMainViewController";
     
     if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
     
     nibName =  @"CardMainViewControllerIphone";
     
     }
     
     CardMainViewController * cardMainViewController = [[CardMainViewController alloc] initWithNibName:nibName bundle:nil];
     [self.navigationController pushViewController:cardMainViewController animated:YES];

}

- (IBAction)back:(id)sender{
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];
    [self.navigationController popViewControllerAnimated:YES];
    
    
    
}

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}


@end
