//
//  CardMainViewController.m
//  FlipTest
//
//  Created by Elbin John on 27/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "CardMainViewController.h"
#import "GameFinish.h"
#import "PlayMusic.h"
#import "AppConfig.h"
#import "SoundPlayer.h"
#import "GameAppViewController.h"
#import "CocoaLumberjackConfig.h"

#define CONFIRM_EXIT_ALERT 101

#define CLICKED_CANCEL_BUTTON 0
#define CLICKED_OK_BUTTON 1

@interface CardMainViewController ()
{
    NSTimer * tmr;
    NSTimer * gameTime;
    gameFinishView* gameFinishView1;
    int gameLevelCount;
    BOOL isClosedSound;
}
@property (unsafe_unretained, nonatomic) IBOutlet UIView  * playingView;
@property (strong, nonatomic) NSMutableArray * cardFlipViewList;
@property (strong, nonatomic) NSMutableArray * selectedcardFlipViewList;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *timeTicker;
@property (strong, nonatomic) IBOutlet UIImageView *animatingImage;

- (void)dismiss;
- (IBAction)onBackButtonClicked:(id)sender;
- (void)playClickSound;
- (void)showReturnConfirmation;
@end

@implementation CardMainViewController

@synthesize playingView = _playingView;
@synthesize cardFlipViewList = _cardFlipViewList;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    isClosedSound=[[NSUserDefaults standardUserDefaults]boolForKey:@"sound"];
}

- (void)initPlayerView
{
    
//    [self animationDidStop:nil];
    _timeTicker.text = @"00:00";
    gameLevelCount ++;
    
    //[self.drawArea resetPath];
    
    [self.view addSubview:self.animatingImage];
    self.animatingImage.transform = CGAffineTransformMakeRotation(-M_PI);
    self.animatingImage.frame = CGRectMake(((self.view.frame.size.width/2)-(self.animatingImage.frame.size.width)/2),-(self.animatingImage.frame.size.width)/2, self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
    [self.animatingImage setAlpha:1];
    
    
    //self.animatingImage.transform  = CGAffineTransformRotate(self.animatingImage.transform,2);
    
    //self.animatingImage.frame = CGRectMake((self.view.frame.size.height/2)-75,(self.view.frame.size.width/2)-75, 150, 150);
    self.view.userInteractionEnabled = FALSE;
    
    //self.animatingImage.transform  = CGAffineTransformRotate(self.animatingImage.transform,M_PI/4);
    
    // CGAffineTransform t = CGAffineTransformRotate(self.animatingImage.transform, -0.78);
    //self.animatingImage.transform = t;
    
    // self.animatingImage.transform=CGAffineTransformRotate(self.animatingImage.transform, (((60*22)/7)/240));
    
    
    /*
    CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    animation.fromValue = [NSNumber numberWithFloat:-1];
    animation.toValue = [NSNumber numberWithFloat: 1];
    animation.duration = .9f;
    animation.repeatCount = 1;
    [self.animatingImage.layer addAnimation:animation forKey:@"SpinAnimation"];
    
    */
    
    [UIView animateWithDuration:0.8f
                     animations:^{
                         self.animatingImage.transform = CGAffineTransformMakeRotation(2*M_PI);
                     }];
    [UIView beginAnimations:@"1" context:NULL];
    
    
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1.5];
    //    self.animatingImage.transform=CGAffineTransformRotate(self.animatingImage.transform, (((60*22)/7)/240));
    //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
    self.animatingImage.frame =CGRectMake(((self.view.frame.size.width/2)-((self.animatingImage.frame.size.width)/2)),(self.view.frame.size.height/2)-((self.animatingImage.frame.size.height)/2), self.animatingImage.frame.size.width, self.animatingImage.frame.size.height);
    
    //CGPointMake(((self.view.frame.size.height/2)), (self.view.frame.size.width/2));
    // t = CGAffineTransformRotate(self.animatingImage.transform, 0.78);
    //self.animatingImage.transform  = CGAffineTransformRotate(self.animatingImage.transform,2);
    
    
    
    
    
    [UIView commitAnimations];
    
    
    
    
    
}

- (void)initPlayerViewPartTwo
{
    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"ready go" ofType:@"mp3"]]];
    [UIView beginAnimations:@"2" context:NULL];
    //[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1.5];
    //[UIView setAnimationTransition:( UIViewAnimationTransitionFlipFromLeft ) forView:self cache:YES];
    self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-50,self.animatingImage.frame.origin.y-50, self.animatingImage.frame.size.width+ 100, self.animatingImage.frame.size.height+100);
    [self.animatingImage setAlpha:0];
    [UIView commitAnimations];
    
}

- (void) viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [PlayMusic sharedInstanceGameBg].repeatSound = YES;
    [[PlayMusic sharedInstanceGameBg]stopPlayback];
}
- (void)setcardToplay:(int)numberOfRow :(int)numberOfColumn : (NSArray *)itemDetails
{
    
    float cardWidth;
    float cardHeight;
    
    CGSize cardSize;
    CGRect avilablearea = self.playingView.frame;
    CGRect drawCardframe;
    CardFlipView * tmpCardFlipView;
    
    
    _cardFlipViewList           = [NSMutableArray array];
    _selectedcardFlipViewList   = [NSMutableArray array];
    
    cardWidth = avilablearea.size.width/numberOfColumn;
    cardHeight = avilablearea.size.height/numberOfRow;
    cardSize = CGSizeMake(cardWidth, cardHeight);
    
    for (int i =0 ; i <numberOfColumn ; i++)
    {
        for (int j =0 ; j< numberOfRow ; j++) {
            
            drawCardframe = CGRectMake(i*cardWidth, j*cardHeight, cardSize.width, cardSize.height);
            
           /* NSArray *cards = [[NSBundle mainBundle] loadNibNamed:@"CardFlipView" owner:nil options:nil];
            if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
                for (UIView *eachView in cards) {
                    
                    if ([eachView isKindOfClass:[CardFlipView class]] && eachView.tag == 1) {
                        
                        tmpCardFlipView = (CardFlipView*)eachView;
                    }
                }
            }
            else{
                for (UIView *eachView in cards) {
                    
                    if ([eachView isKindOfClass:[CardFlipView class]] && eachView.tag == 0) {
                        
                        tmpCardFlipView = (CardFlipView*)eachView;
                    }
                }
            }*/
                        
            tmpCardFlipView = (CardFlipView*)[[[NSBundle mainBundle] loadNibNamed:@"CardFlipView" owner:nil options:nil] objectAtIndex:0];
            tmpCardFlipView.delegate = self;
            tmpCardFlipView.frame = drawCardframe;
            [self.playingView addSubview:tmpCardFlipView];
            [_cardFlipViewList addObject:tmpCardFlipView];
        }
        
        
    }
    
    int numberofRandom = (numberOfRow * numberOfColumn);
    int ar[numberofRandom],i,d,tmpswap;
    
    for(i = 0; i < numberofRandom; i++)
    {
        ar[i] = i;
    }
    for(i = 0; i < numberofRandom; i++) {
        d =  arc4random() % numberofRandom;
        tmpswap = ar[i];
        ar[i]   = ar[d];
        ar[d]   = tmpswap;
        
    }
    
    
    int countGameElement = [itemDetails count];
    int selectItem = 0;
    int iterateme = 0 ;
    int tempset = 0;
    
    for (int i =0 ; i < numberofRandom/2 ; i++) {
        
        tempset = ar[iterateme];
        UIImage * img = [UIImage imageWithContentsOfFile:[itemDetails objectAtIndex:selectItem]];
        tmpCardFlipView = [_cardFlipViewList objectAtIndex:tempset];
        tmpCardFlipView.itemIdNumber.text = [NSString stringWithFormat:@"%d",selectItem];
        tmpCardFlipView.itemId = selectItem;
        tmpCardFlipView.itemImage.image = img;
        iterateme++;
        tempset = ar[iterateme];
        tmpCardFlipView = [_cardFlipViewList objectAtIndex:tempset];
        tmpCardFlipView.itemIdNumber.text = [NSString stringWithFormat:@"%d",selectItem];
        tmpCardFlipView.itemId = selectItem;
        tmpCardFlipView.itemImage.image = img;
        iterateme++;
        selectItem++;
        selectItem = (selectItem >= countGameElement ?0:selectItem);
        
    }
    
    
}

- (void)viewDidAppear:(BOOL)animated
{
   [super viewDidAppear:YES];
}

 -(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
     [self strartGame];
   
    
}

 - (void)strartGame
{
    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Game Start or finished" ofType:@"WAV"]]];
    
    [[self.playingView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSMutableArray * ary = [NSMutableArray array];
    for (int i =0 ; i<15; i++) {
        [ary addObject:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%d",i] ofType:@"png"]];
    }
    
    [self setcardToplay:4:4:ary];
    [self initPlayerView];
    gameLevelCount = 0;
}
 
-(void)animationDidStop:(NSString *)animationId
{
//    [PlayMusic sharedInstanceGameBg].repeatSound = YES;
//    [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"bg music during the game" ofType:@"mp3"]]];

 
    
  
    
    if([animationId intValue] == 1)
    {
        
        
        
        
        [self performSelector:@selector(initPlayerViewPartTwo) withObject:nil afterDelay:1];
        
    }
    else
    {
        [self.animatingImage removeFromSuperview];
        
        
        
         
        
        self.animatingImage.frame = CGRectMake(self.animatingImage.frame.origin.x-25,self.animatingImage.frame.origin.y-25, self.animatingImage.frame.size.width- 100, self.animatingImage.frame.size.height- 100);
        
        
        
        self.view.userInteractionEnabled = TRUE;
        NSDate * date = [NSDate date];
        gameTime = [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(playerTimeGo:) userInfo:date  repeats:YES];
        
        _timeTicker.text = @"00:00";
        
        if(!isClosedSound){
            [PlayMusic sharedInstanceGameBg].repeatSound = YES;
            [[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"bg music during the game" ofType:@"mp3"]]];
        }
        
        
    }
    
    
    
    
    
}

- (void)playerTimeGo:(NSTimer *)timer;
{
    NSDate * dd=  timer.userInfo;
    NSDate * dt = [NSDate date];
    NSTimeInterval  cr = [dt timeIntervalSinceDate:dd];
    
    
    
    
    NSInteger ti = (NSInteger)cr;
    NSInteger seconds = ti % 60;
    NSInteger minutes = (ti / 60) % 60;
    //  NSInteger hours = (ti / 3600);
    //[NSString stringWithFormat:@"%02i:%02i:%02i", hours, minutes, seconds];
    
    
    /*
     if(cr>=60.00)
     cr = cr/60;
     else
     cr = cr/100;
     
     */
    
    //    if(cr>50)
    //    {
    //        cr= cr/60;
    //          cr = cr/10;
    //    }
    //    else
    //    {
    //    NSLog(@"|||||| = %02.2f",cr);
    //    cr = cr/100;
    //    }
    
    
    _timeTicker.text = [NSString stringWithFormat:@"%02i:%02i",minutes ,seconds];
}


- (void)fireTimer:(id) sender
{
    @synchronized(self)
    {
        [tmr invalidate];
        if([self.selectedcardFlipViewList count]>1)
        {
            [self resetFlippedObject];
        }
    }
    
    
}

- (void)resetFlippedObject
{
    for ( CardFlipView * tmp in self.selectedcardFlipViewList) {
        [tmp flipView];
    }
    [self.selectedcardFlipViewList removeAllObjects];
    
}

#pragma delegates
- (void)itemSelected:(id) cardFlipView
{
    [tmr invalidate];
    @synchronized(self)
    {
        [tmr invalidate];
        if(self.selectedcardFlipViewList && [self.selectedcardFlipViewList count]>0)
        {
            if([self.selectedcardFlipViewList count]>1)
            {
                CardFlipView * tmp = cardFlipView;
                [self resetFlippedObject];
                [tmp flipView];
                [self.selectedcardFlipViewList addObject:cardFlipView];
                
            }
            else
            {
                CardFlipView * tmp1 = [self.selectedcardFlipViewList objectAtIndex:0];
                CardFlipView * tmp2 = cardFlipView;
                
                if((tmp1.itemId == tmp2.itemId) && (tmp1 != tmp2))
                {
                    
                    [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"correct linked" ofType:@"mp3"]]];
                    
                    [tmp2 flipView];
                    
                    [tmp2 setFound];
                    [tmp1 setFound];
                    [self.selectedcardFlipViewList removeAllObjects];
                    
                    [self performSelector:@selector(foundAnimation:) withObject:[NSArray arrayWithObjects:tmp1,tmp2, nil] afterDelay:.76];
                }
                else
                {
                    [tmp2 flipView];
                    if ((tmp1 != tmp2)) {
                        
                        
                        [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"wrong linked" ofType:@"mp3"]]];
                        
                        [self.selectedcardFlipViewList addObject:tmp2];
                        tmr = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(fireTimer:) userInfo:nil repeats:NO];
                        
                    }
                    else
                    {
                        [self.selectedcardFlipViewList removeObject:tmp1];
                    }
                    
                }
                
            }
        }
        else
        {
            CardFlipView * tmp = cardFlipView;
            [tmp flipView];
            [self.selectedcardFlipViewList addObject:tmp];
        }
        
        
        
        if(self.cardFlipViewList && ![[self.cardFlipViewList filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"isFound = 0"]] count])
        {
            [self gameFinished];
        }
    }
    
}


- (void)gameFinished
{
    [[PlayMusic sharedInstanceGameBg]stopPlayback ];
      [[PlayMusic sharedInstance] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"game finished" ofType:@"mp3"]]];
    
    [gameTime invalidate];
    NSString * nibname = @"gameFinishView";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibname = @"gameFinishViewIphone";
    }
    
    gameFinishView1  = (gameFinishView*)[[[NSBundle mainBundle] loadNibNamed:nibname owner:nil options:nil] objectAtIndex:0];
    gameFinishView1.frame = CGRectMake(((self.view.frame.size.width/2)-(gameFinishView1.frame.size.width/2)), (self.view.frame.size.height/2)-(gameFinishView1.frame.size.height/2), gameFinishView1.frame.size.width, gameFinishView1.frame.size.height);
    [self.view addSubview:gameFinishView1];
    gameFinishView1.delegate = self;
    
    [gameFinishView1 loadAnimatedGo];
    

}

- (void)finishAnimation
{
    gameFinishView1.delegate = nil;
    [gameFinishView1 removeFromSuperview];
    
    if(gameLevelCount>=0)
    {
     
     
    
        //[[PlayMusic sharedInstanceGameBg]stopPlayback ];
    
    NSString * nibname = @"GameFinish";
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        
        nibname = @"GameFinishIphone";
    }
    
    
    GameFinish * gameFinish = [[GameFinish alloc] initWithNibName:nibname bundle:nil];
    gameFinish.finishTime = _timeTicker.text;
    gameFinish.gameType =1;
        gameFinish.gameTypeId = 4;
    // [self.navigationController popToRootViewControllerAnimated:NO];
    [self.navigationController pushViewController:gameFinish animated:YES];
        
    }
    else
    {
        [self strartGame];
    }
    
}

- (void)foundAnimation :(NSArray *)foundElements
{
    CardFlipView* found1 = [foundElements objectAtIndex:0];
    CardFlipView* found2 = [foundElements objectAtIndex:1];
    
    [found1 foundAnimation];
    [found2 foundAnimation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

- (IBAction)onBackButtonClicked:(id)sender {
	[self playClickSound];
	[self showReturnConfirmation];
}
#pragma UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	switch (alertView.tag) {
		case CONFIRM_EXIT_ALERT: {
			switch (buttonIndex) {
				case CLICKED_OK_BUTTON: {
					[self dismiss];
					break;
				}
				default: {
					break;
				}
			}
			break;
		}
		default: {
			DDLogWarn(@"! CardMainVC: unknown / unhandled alertView tag; tag=%d", alertView.tag);
			break;
		}
	}
}
- (void)viewDidUnload {
    [self setTimeTicker:nil];
    [super viewDidUnload];
}

#pragma sound effects
- (void)playClickSound {
	AppConfig * appConfig = [AppConfig getInstance];
	[[SoundPlayer getInstance] playAudio:appConfig.clickSoundRelativePath];
}

#pragma misc
- (void)dismiss {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)showReturnConfirmation {
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                    message:NSLocalizedString(@"ConfirmToExit", @"")
                                                   delegate:self
                                          cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles:NSLocalizedString(@"OK", @""), nil];
    alert.tag = CONFIRM_EXIT_ALERT;
    [alert show];
}

@end
