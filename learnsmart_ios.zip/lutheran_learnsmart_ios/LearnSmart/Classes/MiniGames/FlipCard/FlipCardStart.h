//
//  FlipCardStart.h
//  GameApp
//
//  Created by Sreekanth R on 27/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlipCardStart : UIViewController

- (IBAction)continueCliced:(id)sender;
- (IBAction)back:(id)sender;

@end
