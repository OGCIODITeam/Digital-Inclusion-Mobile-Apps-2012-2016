//
//  CardFlipView.h
//  FlipTest
//
//  Created by Elbin John on 27/06/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CardFlipViewDelegate <NSObject>

@optional

- (void)itemSelected:(id) cardFlipView;

@end

@interface CardFlipView : UIView
{
    
    
     
}

@property(nonatomic,assign)id <CardFlipViewDelegate>delegate;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel    *itemIdNumber;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *itemImage;
@property(nonatomic,assign)int  itemId;

- (void)flipView;
- (void)setFound;
- (void)foundAnimation;

@end
