//
//  GameAppViewController.m
//  GameApp
//
//  Created by Elbin John on 01/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "GameAppViewController.h"
#import "MactchTheObjectGameMenu.h"

#import "CardMainViewController.h"
#import "PlayMusic.h"
#import "FlipCardStart.h"
#import "MoneyGameViewController.h"
#import "CoinGameMenuViewController.h"
#import "AppConfig.h"
#import "BGMusicPlayer.h"
#import "DeviceHelper.h"
#import "SoundPlayer.h"

@interface GameAppViewController ()

- (void)initGirlAnimation;
- (void)playClickSound;
- (void)startGirlAnimation;
- (void)stopGirlAnimation;

@end

@implementation GameAppViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    isClosedSound=[[NSUserDefaults standardUserDefaults]boolForKey:@"sound"];
	appConfig = [AppConfig getInstance];
	bgMusicPlayer = [BGMusicPlayer getInstance];
	deviceHelper = [DeviceHelper getInstance];
	[self initGirlAnimation];
}

- (void)viewWillAppear:(BOOL)animated {
	if(!isClosedSound){[bgMusicPlayer start];}
	[self startGirlAnimation];
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
	[self stopGirlAnimation];
	if(!isClosedSound){[bgMusicPlayer stop];}
	[super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)selectGame:(id)sender {
    
    
    //[[PlayMusic sharedInstanceGameBg] playSoundForThis:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"press button" ofType:@"mp3"]]];    
}

- (BOOL)shouldAutorotate{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return YES;
    }
    else{
        return YES;
    }
}

- (NSUInteger)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskLandscape | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return ((toInterfaceOrientation == UIDeviceOrientationLandscapeRight) || (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft));
}

#pragma girl animation
- (void)initGirlAnimation {
	NSMutableArray * animatedGirlFrames = [NSMutableArray array];
	NSString * deviceSuffix;
	
	if ([deviceHelper isiPad]) {
		deviceSuffix = @"ipad";
	} else {
		deviceSuffix = @"iphone";
	}
	
	for (int i=1; i<=appConfig.numAnimatedGirlFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", i, deviceSuffix]]];
	}
	
	for (int i=1; i<appConfig.numAnimatedGirlPauseFrames; i++) {
		[animatedGirlFrames addObject:[UIImage imageNamed:[NSString stringWithFormat:@"animated_girl_%02d_%@", appConfig.numAnimatedGirlFrames, deviceSuffix]]];
	}
	
	animatedGirlView.animationImages = animatedGirlFrames;
	animatedGirlView.animationDuration = 1.50f;
	animatedGirlView.animationRepeatCount = INFINITY;
}

- (void)startGirlAnimation {
	[animatedGirlView startAnimating];
}

- (void)stopGirlAnimation {
	[animatedGirlView stopAnimating];
}

#pragma game view display handling
- (IBAction)tappedPairingGameButton:(id)sender {
	MactchTheObjectGameMenu * pairingGameVC;
	NSString * nibName = nil;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		nibName = @"MactchTheObjectGameMenu";
	} else {
		nibName = @"MactchTheObjectGameMenuIphone";
	}
	
	pairingGameVC = [[MactchTheObjectGameMenu alloc] initWithNibName:nibName bundle:nil];
	[self.navigationController pushViewController:pairingGameVC animated:YES];
}

- (IBAction)tappedMemoryCardGameButton:(id)sender {
	FlipCardStart * memoryCardGameVC;
	NSString * nibName = nil;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		nibName = @"FlipCardStartIpad";
	} else {
		nibName =  @"FlipCardStart";
	}
	
	memoryCardGameVC = [[FlipCardStart alloc] initWithNibName:nibName bundle:nil];
	[self.navigationController pushViewController:memoryCardGameVC animated:YES];
}

- (IBAction)tappedMoneyChangeGameButton:(id)sender {
	CoinGameMenuViewController * moneyChangeGameVC;
	NSString * nibName = nil;
	
	[self playClickSound];
	
	if ([deviceHelper isiPad]) {
		nibName = @"CoinGameMenuViewController";
	} else {
		nibName =  @"CoinGameMenuViewControllerIphone";
	}
	
	moneyChangeGameVC = [[CoinGameMenuViewController alloc] initWithNibName:nibName bundle:nil];
	[self.navigationController pushViewController:moneyChangeGameVC animated:YES];
}

#pragma sound effects
- (void)playClickSound {
	[[SoundPlayer getInstance] playAudio:appConfig.clickSoundRelativePath];
}

#pragma UIButton tapping handling
- (IBAction)tappedBackButton:(id)sender {
	[self playClickSound];
	[self.navigationController popToRootViewControllerAnimated:YES];
}

@end
