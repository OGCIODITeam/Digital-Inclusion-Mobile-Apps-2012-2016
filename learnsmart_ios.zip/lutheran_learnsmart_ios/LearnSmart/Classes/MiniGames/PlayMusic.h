//
//  PlayMusic.h
//  GameApp
//
//  Created by Elbin John on 02/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVAudioPlayer.h>
#import <AudioToolbox/AudioToolbox.h>

@interface PlayMusic : NSObject <AVAudioPlayerDelegate>
{
	AVAudioPlayer *soundPlayer;
	BOOL		  audioDisabled;
}

+ (PlayMusic*)sharedInstance;
+ (PlayMusic*)sharedInstanceGameBg;

@property(nonatomic, assign) BOOL audioDisabled;
@property(nonatomic, assign) BOOL repeatSound;

 
+ (void)releaseSharedAudioInstance;

- (void)setSound:(NSString *)soundFile;
- (void)playSound;
- (void)stopPlayback;
- (void)playSoundForThis:(NSURL *)sndURL;
@end
