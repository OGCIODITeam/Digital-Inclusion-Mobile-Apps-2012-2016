//
//  PlayMusic.m
//  GameApp
//
//  Created by Elbin John on 02/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import "PlayMusic.h"

@implementation PlayMusic
{

}

static PlayMusic * playMusic;
static PlayMusic * playMusicBg;

+ (PlayMusic*)sharedInstance
{
    if(!playMusic)
    {
        playMusic = [PlayMusic new];
    }
    
    return playMusic;
}

+ (PlayMusic*)sharedInstanceGameBg
{
    if(!playMusicBg)
    {
        playMusicBg = [PlayMusic new];
    }
    
    return playMusicBg;
}


@synthesize audioDisabled;

#pragma mark Class Methods
//	Purpose		:	Returns a singleton object of the class
//	Parameter		:	Nil.
//	Return type		:	void
//	Comments		:	Nil.
 

+ (void) releaseSharedAudioInstance
{
	playMusic = nil;
}

#pragma mark System Methods
- (id)init
{
	if((self = [super init]))
	{
		audioDisabled  = NO;
	}
	return self;
}

- (void)dealloc
{
	if(nil != soundPlayer)
	{
		soundPlayer = nil;
	}
 
}

#pragma mark Class Public Methods
//	Purpose		:	Sets the sound file to be played
//	Parameter		:	soundFile
//	Return type		:	void
//	Comments		:	Nil.
- (void)setSound:(NSURL *)sndURL
{
	if ( nil != soundPlayer)
	{
		soundPlayer = nil;
	}
	
	//NSURL *sndURL;
	//sndURL      = [[NSURL alloc] initFileURLWithPath: [[NSBundle mainBundle] pathForResource:soundFile ofType:@"wav"]];
	soundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:sndURL error:nil];
	
	soundPlayer.volume = 1.0f;
	
	sndURL = nil;
}


- (void)playSoundForThis:(NSURL *)sndURL
{
	if ( nil != soundPlayer)
	{
        if(soundPlayer.playing)
        {
            [soundPlayer stop];
        }
		soundPlayer = nil;
	}
	
	//NSURL *sndURL;
	//sndURL      = [[NSURL alloc] initFileURLWithPath: [[NSBundle mainBundle] pathForResource:soundFile ofType:@"wav"]];
	soundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:sndURL error:nil];
	
	soundPlayer.volume = 1.0f;
    
    [self playSound];
	
	sndURL = nil;
}





//	Purpose		:	Plays the sound file.
//	Parameter		:	Nil
//	Return type		:	void
//	Comments		:	Nil.
- (void)playSound
{
	if((soundPlayer.playing)||(YES == audioDisabled))
	{
		return;
	}
	
	[soundPlayer play];
	soundPlayer.delegate = self;
}

//	Purpose		:	Stops playback of the sound file.
//	Parameter		:	Nil
//	Return type		:	void
//	Comments		:	Nil.

- (void)stopPlayback
{
	if(soundPlayer.playing)
	{
		[soundPlayer stop];
	}
}

#pragma mark AVAudioPlayer delegate methods
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
	[soundPlayer setCurrentTime:1.0f];
    if(self.repeatSound)
	{
        [self playSound];
    }
	
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
	NSLog(@"Audio decode error");
}

/* audioPlayerBeginInterruption: is called when the audio session has been interrupted while the player was playing. The player will have been paused. */
- (void)audioPlayerBeginInterruption:(AVAudioPlayer *)player
{
	
}

/* audioPlayerEndInterruption: is called when the preferred method, audioPlayerEndInterruption:withFlags:, is not implemented. */
- (void)audioPlayerEndInterruption:(AVAudioPlayer *)player
{
	[self playSound];
}

#pragma mark C function
static void completionCallback (SystemSoundID  mySSID, void* myself)
{
	AudioServicesRemoveSystemSoundCompletion (mySSID);
}


@end
