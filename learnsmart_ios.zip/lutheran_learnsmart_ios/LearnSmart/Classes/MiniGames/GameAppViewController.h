//
//  GameAppViewController.h
//  GameApp
//
//  Created by Elbin John on 01/07/13.
//  Copyright (c) 2013 Elbin John. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppConfig, BGMusicPlayer, DeviceHelper;

@interface GameAppViewController : UIViewController {
	IBOutlet UIImageView * animatedGirlView;
	AppConfig * appConfig;
	BGMusicPlayer * bgMusicPlayer;
	DeviceHelper * deviceHelper;
    BOOL isClosedSound;
}

- (IBAction)tappedBackButton:(id)sender;
- (IBAction)tappedPairingGameButton:(id)sender;
- (IBAction)tappedMemoryCardGameButton:(id)sender;
- (IBAction)tappedMoneyChangeGameButton:(id)sender;

@end
