//
//  CacheManager.m
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "CacheManager.h"
#import <AFNetworking/AFNetworking.h>
#import <EGOCache/EGOCache.h>
#import "AboutUs.h"
#import "AppConfig.h"
#import "LoginToken.h"
#import "NewsItem.h"
#import "Training.h"
#import "TrainingDetails.h"
#import "TrainingProfile.h"
#import "TrainingCategoryScore.h"
#import "TrainingStep.h"
#import "TrainingHistory.h"
#import "CocoaLumberjackConfig.h"
#import "NSString+Basename.h"
#import <sqlite3.h>

static CacheManager * cacheManager;

@interface CacheManager()

- (void)initDB;
- (void)initLastUpdateTime;
- (NSString *)getCacheDBPath;
- (NSString *)getCacheDir;
- (NSString *)getRelativeCachePathForUrl:(NSString *)url;
- (void)removeCachedTrainingStepFilesForTrainingId:(NSInteger)trainingId;

@end

@implementation CacheManager

@synthesize currentTraining, currentTrainingStepIdx, currentTrainingSteps, trainingProfile;

- (id)init {
	self = [super init];
	if (self) {
		DDLogInfo(@"! init CacheManager");
		appConfig = [AppConfig getInstance];
		cache = [EGOCache globalCache];
		[cache setDefaultTimeoutInterval:appConfig.cacheIntervalInSec];
		
		trainingProfile = [[TrainingProfile alloc] init];
		currentTrainingStepIdx = 0;
		currentTrainingSteps = [NSMutableArray new];
		[self initDB];
		[self initLastUpdateTime];
	}
	return self;
}

+ (id)getInstance {
	@synchronized(self) {
		if (cacheManager == nil) {
			cacheManager = [CacheManager new];
		}
	}
	return cacheManager;
}

- (void)initLastUpdateTime {
	lastAboutUsUpdateTime = [NSDate distantPast];
	lastPublicTrainingUpdateTimes = [NSMutableDictionary dictionary];
	lastTrainingCategoryScoresUpdateTime = [NSDate distantPast];
	lastTrainingStepsUpdateTimes = [NSMutableDictionary dictionary];
}

#pragma override methods
- (void)setCurrentTrainingSteps:(NSMutableArray *)_currentTrainingSteps {
	@synchronized(self) {
		currentTrainingSteps = _currentTrainingSteps;
		currentTrainingStepIdx = 0;
	}
}

#pragma internal methods
- (NSString *)getCacheDBPath {
	return [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:appConfig.cacheDBName];
}

- (NSString *)getCacheDir {
	return [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
}

#pragma cache related
- (void)initDB {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS about_us (id INT, about_us TEXT, last_updated INT);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS news_items (id INT,  title TEXT, description TEXT, priority INT, last_updated INT);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS assigned_trainings (id INT, username TEXT, thumbnail TEXT, title TEXT, description TEXT, is_public INT, priority INT, last_updated INT);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS trainings (id INT, cat_id INT, thumbnail TEXT, title TEXT, description TEXT, is_public INT, priority INT, last_updated INT);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS training_category_scores (id INT, title TEXT, score DOUBLE);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS training_details (id INT, username TEXT, title TEXT, category TEXT, background TEXT, trainee_name TEXT, tutor_name TEXT, long_term_target TEXT, short_term_text TEXT, start_date TEXT, end_date TEXT);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS training_histories (training_id INT, username TEXT, comment TEXT, average_score DOUBLE, priority INT, last_updated INT);", nil, nil, nil);
		sqlite3_exec(dbConnection, "CREATE TABLE IF NOT EXISTS training_steps (id INT, training_id INT, step_type TEXT, title TEXT, picture TEXT, text TEXT, sound TEXT, url TEXT, step INT, last_updated INT);", nil, nil, nil);
		
		sqlite3_close(dbConnection);
	}
}

- (void)cacheAboutUs:(AboutUs *)aboutUs {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * deleteStatement;
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM about_us;", -1, &deleteStatement, nil) == SQLITE_OK) {
			if (sqlite3_step(deleteStatement) != SQLITE_DONE) {
				DDLogError(@"! failed to delete outdated aboutUs; error=%s", sqlite3_errmsg(dbConnection));
				sqlite3_close(dbConnection);
				return;
			}
		} else {
			DDLogError(@"! failed to delete outdated aboutUs & newsItems; error=%s", sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		sqlite3_finalize(deleteStatement);
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM news_items;", -1, &deleteStatement, nil) == SQLITE_OK) {
			if (sqlite3_step(deleteStatement) != SQLITE_DONE) {
				DDLogError(@"! failed to delete outdated newsItems; error=%s", sqlite3_errmsg(dbConnection));
				sqlite3_close(dbConnection);
				return;
			}
		} else {
			DDLogError(@"! failed to delete outdated newsItems; error=%s", sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		sqlite3_finalize(deleteStatement);
		
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO about_us(id, about_us, last_updated) VALUES(1, ?, ?)", -1, &statement, nil) == SQLITE_OK) {
			sqlite3_bind_text(statement, 1, aboutUs.aboutUsText.UTF8String, -1, SQLITE_TRANSIENT);
			sqlite3_bind_int64(statement, 2, NSTimeIntervalSince1970);
			if (sqlite3_step(statement) != SQLITE_DONE) {
				DDLogError(@"! CacheManager: failed to cache aboutUs; error=%s", sqlite3_errmsg(dbConnection));
				sqlite3_close(dbConnection);
				return;
			}
			
			sqlite3_finalize(statement);
		}
		
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO news_items (id, title, description, priority, last_updated) VALUES(?, ?, ?, ?, ?)", -1, &statement, nil) == SQLITE_OK) {
			NSInteger i = 0;
			for (NewsItem * newsItem in aboutUs.newsItems) {
				sqlite3_reset(statement);
				sqlite3_bind_int64(statement, 1, ++i);
				sqlite3_bind_text(statement, 2, newsItem.title.UTF8String, -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(statement, 3, newsItem.description.UTF8String, -1, SQLITE_TRANSIENT);
				sqlite3_bind_int(statement, 4, newsItem.priority);
				sqlite3_bind_int64(statement, 5, newsItem.lastUpdated.timeIntervalSince1970);
				
				if (sqlite3_step(statement) != SQLITE_DONE) {
					DDLogError(@"! CacheManager: failed to cache newsItem; error=%s", sqlite3_errmsg(dbConnection));
					sqlite3_close(dbConnection);
					return;
				}
			}
		}
		
		lastAboutUsUpdateTime = [NSDate new];
	} else {
		DDLogError(@"! CacheManager: failed to cache trainings");
		return;
	}
}

- (void)cacheFileAtUrl:(NSString *)url success:(void (^)(NSString * cachedPath))success failure:(void (^)(NSInteger httpErrorCode, NSString * errorMessage))failure {
	NSURLRequest * request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
	AFHTTPRequestOperation * operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
	NSString * cachedPath = [self getCachedPathForUrl:url];
	operation.outputStream = [NSOutputStream outputStreamToFileAtPath:cachedPath append:NO];
	
	[operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
		DDLogInfo(@"! cached %@ successfully; save to %@", url, cachedPath);
		success([self getRelativeCachePathForUrl:url]);
	} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
		DDLogInfo(@"! failed to load file from url=%@; error=%@", url, error.localizedDescription);
		failure(operation.response.statusCode, error.localizedDescription);
	}];
	
	[operation start];
}

- (void)cacheFilesAtUrlList:(NSArray *)urlList success:(void (^)(NSArray *))success failure:(void (^)(NSInteger, NSString *))failure {
	AFHTTPClient * httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://www.google.com/"]];
	NSMutableArray * requests = [NSMutableArray array];
	for (NSString * url in urlList) {
		AFHTTPRequestOperation * operation = [[AFHTTPRequestOperation alloc] initWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
		NSString * cachedPath = [self getCachedPathForUrl:url];
		
		operation.outputStream = [NSOutputStream outputStreamToFileAtPath:cachedPath append:NO];
		
		[operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
			DDLogInfo(@"! %@ downloaded successfully", url);
		} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
			DDLogInfo(@"! %@ download failed; error=%@", url, error.description);
		}];
		
		[requests addObject:operation];
	}

	[httpClient enqueueBatchOfHTTPRequestOperations:requests progressBlock:^(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations) {
		DDLogInfo(@"! CacheManager:cacheFilesAtUrlList: %d/%d completed", numberOfFinishedOperations, totalNumberOfOperations);
	} completionBlock:^(NSArray *operations) {
		DDLogInfo(@"! CacheManager:cacheFilesAtUrlList: operation completed");
		BOOL isSuccessful = YES;
		NSMutableArray * cachedPaths = [NSMutableArray array];
		
		for (AFHTTPRequestOperation * operation in operations) {
			if (operation.isCancelled) {
				failure(200, [NSString stringWithFormat:@"download operation cancelled"]);
				isSuccessful = NO;
				break;
			}
			[cachedPaths addObject:[self getRelativeCachePathForUrl:operation.request.URL.absoluteString]];
		}
		
		if (isSuccessful) {
			success(cachedPaths);
		} else {
			DDLogError(@"! failed but operation continue");
		}
	}];
}

- (void)cacheTrainings:(NSArray *)trainings withCategoryId:(NSInteger)catId {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * deleteStatement;
		
		NSMutableArray * cachedTrainings = [self getCachedPublicTrainingsWithCatId:catId];
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM trainings WHERE cat_id = ? AND id = ?; DELETE FROM training_steps WHERE training_id = ?", -1, &deleteStatement, nil) == SQLITE_OK) {
			for (Training * cachedTraining in cachedTrainings) {
				BOOL isExpiredCacheRecord = YES;

				/* check if training record is cached and still valid */
				for (Training * training in trainings) {
					if ([cachedTraining isEqualToTraining:training]) {
						isExpiredCacheRecord = NO;
						break;
					}
				}
				
				/* remove expired cache record */
				if (isExpiredCacheRecord) {
					sqlite3_reset(deleteStatement);
					sqlite3_bind_int(deleteStatement, 1, catId);
					sqlite3_bind_int64(deleteStatement, 2, cachedTraining.trainingId);
					sqlite3_bind_int64(deleteStatement, 3, cachedTraining.trainingId);
					if (sqlite3_step(deleteStatement) != SQLITE_DONE) {
						DDLogError(@"! failed to delete outdated training records; catId=%d; error=%s", catId, sqlite3_errmsg(dbConnection));
						sqlite3_close(dbConnection);
						return;
					}
					[self removeCachedFileForUrl:cachedTraining.thumbnail];
					[self removeCachedTrainingStepFilesForTrainingId:cachedTraining.trainingId];
				}
			}
		} else {
			DDLogError(@"! failed to delete outdated training records; catId=%d; error=%s", catId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}

		
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO trainings(id, cat_id, thumbnail, title, description, is_public, priority, last_updated) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", -1, &statement, nil) == SQLITE_OK) {
			for (Training * training in trainings) {
				BOOL isExistingTraining = NO;
				
				for (Training * cachedTraining in cachedTrainings) {
					if ([cachedTraining isEqualToTraining:training]) {
						isExistingTraining = YES;
						break;
					}
				}
				
				if (!isExistingTraining) {
					NSInteger lastUpdated = [training.lastUpdated timeIntervalSince1970];
					
					sqlite3_reset(statement);
					sqlite3_bind_int64(statement, 1, training.trainingId);
					sqlite3_bind_int(statement, 2, catId);
					sqlite3_bind_text(statement, 3, [training.thumbnail UTF8String], -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(statement, 4, [training.title UTF8String], -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(statement, 5, [training.description UTF8String], -1, SQLITE_TRANSIENT);
					sqlite3_bind_int(statement, 6, 1);
					sqlite3_bind_int(statement, 7, training.priority);
					sqlite3_bind_int64(statement, 8, lastUpdated);
					
					if (sqlite3_step(statement) != SQLITE_DONE) {
						DDLogError(@"! CacheManager: failed to cache trainings; error=%s", sqlite3_errmsg(dbConnection));
						sqlite3_close(dbConnection);
						return;
					}
				}
			}
			
			[lastPublicTrainingUpdateTimes setObject:[NSDate new] forKey:[NSNumber numberWithInteger:catId]];
		} else {
			DDLogError(@"! failed to cache trainings; catId=%d; error=%s", catId, sqlite3_errmsg(dbConnection));
			return;
		}
		
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! CacheManager: failed to cache trainings; catId=%d", catId);
		return;
	}
}

- (void)cacheTrainings:(NSArray *)trainings withLoginToken:(LoginToken *)loginToken {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * deleteStatement;
		
		NSMutableArray * cachedTrainings = [self getCachedTrainingsWithLoginToken:loginToken];
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM assigned_trainings WHERE username = ? AND id = ?; DELETE FROM training_steps WHERE training_id = ?", -1, &deleteStatement, nil) == SQLITE_OK) {
			for (Training * cachedTraining in cachedTrainings) {
				BOOL isExpiredCacheRecord = YES;
				
				/* check if training record is cached and still valid */
				for (Training * training in trainings) {
					if ([cachedTraining isEqualToTraining:training]) {
						isExpiredCacheRecord = NO;
						break;
					}
				}
				
				/* remove expired cache record */
				if (isExpiredCacheRecord) {
					sqlite3_reset(deleteStatement);
					sqlite3_bind_text(deleteStatement, 1, (const char *)loginToken.username.UTF8String, -1, SQLITE_TRANSIENT);
					sqlite3_bind_int64(deleteStatement, 2, cachedTraining.trainingId);
					sqlite3_bind_int64(deleteStatement, 3, cachedTraining.trainingId);
					if (sqlite3_step(deleteStatement) != SQLITE_DONE) {
						DDLogError(@"! failed to delete outdated training records; username=%@; error=%s", loginToken.username, sqlite3_errmsg(dbConnection));
						sqlite3_close(dbConnection);
						return;
					}
					[self removeCachedFileForUrl:cachedTraining.thumbnail];
					[self removeCachedTrainingStepFilesForTrainingId:cachedTraining.trainingId];
				}
			}
		} else {
			DDLogError(@"! failed to delete outdated training records; username=%@; error=%s", loginToken.username, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		
		
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO assigned_trainings(id, username, thumbnail, title, description, is_public, priority, last_updated) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", -1, &statement, nil) == SQLITE_OK) {
			for (Training * training in trainings) {
				BOOL isExistingTraining = NO;
				
				for (Training * cachedTraining in cachedTrainings) {
					if ([cachedTraining isEqualToTraining:training]) {
						isExistingTraining = YES;
						break;
					}
				}
				
				if (!isExistingTraining) {
					NSInteger lastUpdated = [training.lastUpdated timeIntervalSince1970];
					
					sqlite3_reset(statement);
					sqlite3_bind_int64(statement, 1, training.trainingId);
					sqlite3_bind_text(statement, 2, loginToken.username.UTF8String, -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(statement, 3, [training.thumbnail UTF8String], -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(statement, 4, [training.title UTF8String], -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(statement, 5, [training.description UTF8String], -1, SQLITE_TRANSIENT);
					sqlite3_bind_int(statement, 6, 0);
					sqlite3_bind_int(statement, 7, training.priority);
					sqlite3_bind_int64(statement, 8, lastUpdated);
					
					if (sqlite3_step(statement) != SQLITE_DONE) {
						DDLogError(@"! CacheManager: failed to cache trainings; error=%s", sqlite3_errmsg(dbConnection));
						sqlite3_close(dbConnection);
						return;
					}
				}
			}
			
		} else {
			DDLogError(@"! failed to cache trainings; username=%@; error=%s", loginToken.username, sqlite3_errmsg(dbConnection));
			return;
		}
		
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! CacheManager: failed to cache trainings; username=%@", loginToken.username);
		return;
	}
}

- (void)cacheTrainingCategoryScores:(NSArray *)scores {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * deleteStatement;
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM training_category_scores", -1, &deleteStatement, nil) == SQLITE_OK) {
			/* remove expired cache record */
			if (sqlite3_step(deleteStatement) != SQLITE_DONE) {
				DDLogError(@"! failed to delete outdated training category scores; error=%s", sqlite3_errmsg(dbConnection));
				sqlite3_close(dbConnection);
				return;
			}
		} else {
			DDLogError(@"! failed to delete outdated training category scores; error=%s", sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO training_category_scores(id, title, score) VALUES(?, ?, ?)", -1, &statement, nil) == SQLITE_OK) {
			NSInteger i = 0;
			
			for (TrainingCategoryScore * score in scores) {
				sqlite3_reset(statement);
				sqlite3_bind_int64(statement, 1, ++i);
				sqlite3_bind_text(statement, 2, score.title.UTF8String, -1, SQLITE_TRANSIENT);
				sqlite3_bind_double(statement, 3, score.score);
				
				if (sqlite3_step(statement) != SQLITE_DONE) {
					DDLogError(@"! CacheManager: failed to cache training category scores; error=%s", sqlite3_errmsg(dbConnection));
					sqlite3_close(dbConnection);
					return;
				}
			}
			
		} else {
			DDLogError(@"! failed to cache training category scores; error=%s", sqlite3_errmsg(dbConnection));
			return;
		}
		
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! failed to cache training category scores");
		return;
	}
}

- (void)cacheTrainingDetails:(TrainingDetails *)details username:(NSString *)username trainingId:(NSInteger)trainingId {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		
		if (sqlite3_exec(dbConnection, "BEGIN EXCLUSIVE TRANSACTION", 0, nil, nil) != SQLITE_OK) {
			DDLogError(@"! CacheManager: failed to begin cache training details update transaction; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
		}
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM training_details WHERE id = ? AND username = ?", -1, &statement, nil) != SQLITE_OK) {
			DDLogError(@"! CacheManager: failed to delete outdated training details; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		sqlite3_finalize(statement);
		
		if(sqlite3_prepare_v2(dbConnection, "INSERT INTO training_details (id, username, title, category, background, trainee_name, tutor_name, long_term_target, short_term_target, start_date, end_date) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);", -1, &statement, nil) != SQLITE_OK) {
			sqlite3_bind_int64(statement, 1, trainingId);
			sqlite3_bind_text(statement, 2, (const char *)username.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 3, (const char *)details.title.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 4, (const char *)details.category.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 5, (const char *)details.background.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 6, (const char *)details.traineeName.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 7, (const char *)details.tutorName.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 8, (const char *)details.longTermTarget.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 9, (const char *)details.shortTermTarget.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 10, (const char *)details.startDate.UTF8String, -1, SQLITE_STATIC);
			sqlite3_bind_text(statement, 11, (const char *)details.endDate.UTF8String, -1, SQLITE_STATIC);
			
			if (sqlite3_step(statement) != SQLITE_DONE) {
				DDLogError(@"! CacheManager: failed to cache training details; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
			}
			
			sqlite3_finalize(statement);
			sqlite3_close(dbConnection);
		} else {
			DDLogError(@"! CacheManager: failed to cache training details; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
		}
	}
}

- (void)cacheTrainingHistories:(NSArray *)histories username:(NSString *)username trainingId:(NSInteger)trainingId {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;

		if (sqlite3_exec(dbConnection, "BEGIN EXCLUSIVE TRANSACTION", 0, nil, nil) != SQLITE_OK) {
			DDLogError(@"! CacheManager: failed to begin cache training history update transaction; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
		}
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM training_histories WHERE training_id = ? AND username = ?", -1, &statement, nil) != SQLITE_OK) {
			DDLogError(@"! CacheManager: failed to delete outdated training histories; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		sqlite3_finalize(statement);
		
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO training_histories (training_id, username, comment, average_score, priority, last_updated) VALUES(?, ?, ?, ?, ?, ?);", -1, &statement, nil) == SQLITE_OK) {
			
			NSInteger i=0;
			for (TrainingHistory * history in histories) {
				sqlite3_reset(statement);
				sqlite3_bind_int64(statement, 1, trainingId);
				sqlite3_bind_text(statement, 2, (const char *)username.UTF8String, -1, SQLITE_STATIC);
				sqlite3_bind_text(statement, 3, (const char *)history.comment.UTF8String, -1, SQLITE_TRANSIENT);
				sqlite3_bind_double(statement, 4, history.averageScore);
				sqlite3_bind_int(statement, 5, ++i);
				sqlite3_bind_int64(statement, 6, history.lastUpdated.timeIntervalSince1970);
				
				if (sqlite3_step(statement) != SQLITE_DONE) {
					DDLogError(@"! CacheManager: failed to cache training history; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
					sqlite3_finalize(statement);
					sqlite3_close(dbConnection);
					return;
				}
			}
			
			sqlite3_finalize(statement);
			
			if (sqlite3_exec(dbConnection, "COMMIT TRANSACTION", 0, nil, nil) != SQLITE_OK) {
				DDLogError(@"! CacheManager: failed to commit the changes to training history cache; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
			}
		} else {
			DDLogError(@"! CacheManager: failed to cache training histories; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
		}
		
		sqlite3_close(dbConnection);
		
	} else {
		DDLogError(@"! CacheManager: failed to cache training histories");
		return;
	}
}

- (void)cacheTrainingSteps:(NSArray *)steps withTrainingId:(NSInteger)trainingId {
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * deleteStatement;
		
		if (sqlite3_prepare_v2(dbConnection, "DELETE FROM training_steps WHERE training_id = ?", -1, &deleteStatement, nil) == SQLITE_OK) {
			sqlite3_bind_int64(deleteStatement, 1, trainingId);
			if (sqlite3_step(deleteStatement) != SQLITE_DONE) {
				DDLogError(@"! failed to delete outdated training steps records; trainingId=%d; error=%s", trainingId, sqlite3_errmsg(dbConnection));
				sqlite3_close(dbConnection);
				return;
			}
			sqlite3_finalize(deleteStatement);
		} else {
			DDLogError(@"! failed to delete outdated training steps records; trainingId=%d; error=%s", trainingId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return;
		}
		
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "INSERT INTO training_steps(id, training_id, step_type, picture, text, sound, url, step, last_updated) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)", -1, &statement, nil) == SQLITE_OK) {
			for (TrainingStep * step in steps) {
				NSInteger lastUpdated = [step.lastUpdated timeIntervalSince1970];
				
				sqlite3_reset(statement);
				sqlite3_bind_int64(statement, 1, step.stepId);
				sqlite3_bind_int64(statement, 2, trainingId);
				sqlite3_bind_text(statement, 3, [step.stepType UTF8String], -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(statement, 4, [step.picture UTF8String], -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(statement, 5, [step.text UTF8String], -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(statement, 6, [step.sound UTF8String], -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(statement, 7, [step.url UTF8String], -1, SQLITE_TRANSIENT);
				sqlite3_bind_int(statement, 8, step.step);
				sqlite3_bind_int64(statement, 9, lastUpdated);
				
				if (sqlite3_step(statement) != SQLITE_DONE) {
					DDLogError(@"! CacheManager: failed to cache training steps; error=%s", sqlite3_errmsg(dbConnection));
					sqlite3_close(dbConnection);
					return;
				}
			}
			
			[lastTrainingStepsUpdateTimes setObject:[NSDate new] forKey:[NSNumber numberWithInteger:trainingId]];
		} else {
			DDLogInfo(@"! CacheManager: failed to cache training steps; trainingId=%d; error=%s", trainingId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
		}
	} else {
		DDLogError(@"! CacheManager: failed to cache training steps");
		return;
	}
}

- (NSString *)getCachedPathForUrl:(NSString *)url {
	return [[self getCacheDir] stringByAppendingPathComponent:[self getRelativeCachePathForUrl:url]];
}

- (NSString *)getFullCachePathForFile:(NSString *)path {
	return [[self getCacheDir] stringByAppendingPathComponent:path];
}

- (NSString *)getRelativeCachePathForUrl:(NSString *)url {
	return [NSString stringWithExtractingBasenameOfURL:url];
}

- (BOOL)isAboutUsCacheExpired {
	return fabs(-lastAboutUsUpdateTime.timeIntervalSinceNow) > appConfig.cacheIntervalInSec;
}

- (BOOL)isPublicTrainingCacheExpiredWithCatId:(NSInteger)catId {
	NSDate * lastPublicTrainingUpdateTime = [lastPublicTrainingUpdateTimes objectForKey:[NSNumber numberWithInteger:catId]];		
	return !lastPublicTrainingUpdateTime || fabs(-lastPublicTrainingUpdateTime.timeIntervalSinceNow) > appConfig.cacheIntervalInSec;
}

- (BOOL)isTrainingCategoryScoresCacheExpired {
	return fabs(-lastTrainingCategoryScoresUpdateTime.timeIntervalSinceNow) > appConfig.cacheIntervalInSec;
}

- (BOOL)isTrainingStepsCacheExpiredWithTrainingId:(NSInteger)trainingId {
	NSDate * lastTrainingStepsUpdateTime = [lastTrainingStepsUpdateTimes objectForKey:[NSNumber numberWithInteger:trainingId]];
	return !lastTrainingStepsUpdateTime || fabs(-lastTrainingStepsUpdateTime.timeIntervalSinceNow) > appConfig.cacheIntervalInSec;
}

- (BOOL)isURLCached:(NSString *)url {
	NSFileManager * fileManager = [NSFileManager defaultManager];
	return [fileManager fileExistsAtPath:[self getCachedPathForUrl:url]];
}

- (void)removeCachedFile:(NSString *)path {
	NSFileManager * fileManager = [NSFileManager defaultManager];
	NSString * fullPath = [self getFullCachePathForFile:path];
	[fileManager removeItemAtPath:fullPath error:nil];
}

- (void)removeCachedFileForUrl:(NSString *)url {
	NSFileManager * fileManager = [NSFileManager defaultManager];
	NSString * cachedPath = [self getCachedPathForUrl:url];
	[fileManager removeItemAtPath:cachedPath error:nil];
}

- (void)removeCachedTrainingStepFilesForTrainingId:(NSInteger)trainingId {
	NSMutableArray * trainingSteps = [self getCachedTrainingStepsWithTrainingId:trainingId];
	
	for (TrainingStep * cachedStep in trainingSteps) {
		[self removeCachedFileForUrl:cachedStep.picture];
		[self removeCachedFileForUrl:cachedStep.sound];
	}
}

#pragma cache retrieval
- (AboutUs *)getCachedAboutUs {
	AboutUs * aboutUs;
	sqlite3 * dbConnection;
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, about_us, last_updated FROM about_us", -1, &statement, nil) == SQLITE_OK) {
			aboutUs = [[AboutUs alloc] init];
			
			if (sqlite3_step(statement) == SQLITE_ROW) {
				aboutUs.aboutUsText = [NSString stringWithUTF8String:(const char*)sqlite3_column_text(statement, 1)];
			} else {
				DDLogWarn(@"! CacheManager: aboutUs is not cached; return nil");
				sqlite3_close(dbConnection);
				return nil;
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached aboutUs; error=%s", sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
		
		sqlite3_finalize(statement);
		
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, title, description, priority, last_updated FROM news_items ORDER BY priority ASC, id ASC", -1, &statement, nil) == SQLITE_OK) {
			while (sqlite3_step(statement) == SQLITE_ROW) {
				NewsItem * newsItem = [NewsItem new];
				
				newsItem.title = [NSString stringWithUTF8String:(const char*)sqlite3_column_text(statement, 1)];
				newsItem.description = [NSString stringWithUTF8String:(const char*)sqlite3_column_text(statement, 2)];
				newsItem.priority = sqlite3_column_int(statement, 3);
				newsItem.lastUpdated = [NSDate dateWithTimeIntervalSince1970:sqlite3_column_int64(statement, 4)];
				
				[aboutUs.newsItems addObject:newsItem];
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached newsItems; error=%s", sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
		
		sqlite3_close(dbConnection);
	}
	
	return aboutUs;
}

- (NSMutableArray *)getCachedPublicTrainingsWithCatId:(NSInteger)catId {
	NSMutableArray * publicTrainings = [NSMutableArray array];
	sqlite3 * dbConnection;
	
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, cat_id, thumbnail, title, description, is_public, priority, last_updated FROM trainings WHERE is_public = 1 AND cat_id = ? ORDER BY priority ASC, id ASC", -1, &statement, nil) == SQLITE_OK) {
			sqlite3_bind_int(statement, 1, catId);
			
			while (sqlite3_step(statement) == SQLITE_ROW) {
				Training * training = [Training new];
				
				training.trainingId = sqlite3_column_int64(statement, 0);
				training.thumbnail = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
				training.title = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
				training.description = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
				training.priority = sqlite3_column_int(statement, 6);
				training.lastUpdated = [NSDate dateWithTimeIntervalSince1970:sqlite3_column_int64(statement, 7)];
				
				[publicTrainings addObject:training];
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached public trainings; catId=%d; error=%s", catId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
		
		sqlite3_finalize(statement);
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! CacheManager: failed to retrieve cached public trainings; catId=%d", catId);
	}
	
	return publicTrainings;
}

- (NSMutableArray *)getCachedTrainingsWithLoginToken:(LoginToken *)loginToken {
	NSMutableArray * trainings = [NSMutableArray array];
	sqlite3 * dbConnection;
	
	if (sqlite3_open([self getCacheDBPath].UTF8String, &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, username, thumbnail, title, description, is_public, priority, last_updated FROM assigned_trainings WHERE is_public = 0 AND username = ? ORDER BY priority ASC, id ASC", -1, &statement, nil) == SQLITE_OK) {
			sqlite3_bind_text(statement, 1, loginToken.username.UTF8String, -1, SQLITE_TRANSIENT);
			
			while (sqlite3_step(statement) == SQLITE_ROW) {
				Training * training = [Training new];
				
				training.trainingId = sqlite3_column_int64(statement, 0);
				training.thumbnail = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
				training.title = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
				training.description = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
				training.priority = sqlite3_column_int(statement, 6);
				training.lastUpdated = [NSDate dateWithTimeIntervalSince1970:sqlite3_column_int64(statement, 7)];
				
				[trainings addObject:training];
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached trainings; username=%@; error=%s", loginToken.username, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
		
		sqlite3_finalize(statement);
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! CacheManager: failed to retrieve cached trainings; username=%@", loginToken.username);
	}
	
	return trainings;
}

- (NSMutableArray *)getCachedTrainingCategoryScores {
	NSMutableArray * scores = [NSMutableArray array];
	sqlite3 * dbConnection;
	
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, title, score FROM training_category_scores ORDER BY id", -1, &statement, nil) == SQLITE_OK) {
			while (sqlite3_step(statement) == SQLITE_ROW) {
				TrainingCategoryScore * score = [TrainingCategoryScore new];
				score.title = [NSString stringWithUTF8String:(const char*)sqlite3_column_text(statement, 1)];
				score.score = sqlite3_column_double(statement, 2);
				
				[scores addObject:score];
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached training category scores; error=%s", sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
	} else {
		DDLogError(@"! CacheManager: failed to retrieve cached training category scores");
	}
	
	return scores;
}

- (TrainingDetails *)getCachedTrainingDetailsWithUsername:(NSString *)username trainingId:(NSInteger)trainingId {
	TrainingDetails * details;
	sqlite3 * dbConnection;
	
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, username, title, category, background, trainee_name, tutor_name, long_term_target, short_term_target, start_date, end_date FROM training_details WHERE id = ? AND username = ?;", -1, &statement, nil) == SQLITE_OK) {
			sqlite3_bind_int64(statement, 1, trainingId);
			sqlite3_bind_text(statement, 2, (const char *)username.UTF8String, -1, SQLITE_STATIC);
			
			if (sqlite3_step(statement) == SQLITE_ROW) {
				details = [TrainingDetails new];
				
				details.title = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
				details.category = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
				details.background = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
				details.traineeName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 5)];
				details.tutorName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 6)];
				details.longTermTarget = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 7)];
				details.shortTermTarget = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 8)];
				details.startDate = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 9)];
				details.endDate = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 10)];
			} else {
				DDLogError(@"! CacheManager: failed to retrieve cached training histories; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached training histories; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
		}
	} else {
		DDLogError(@"! CacheManager: failed to retrieve cached training histories; username=%@; trainingId=%d", username, trainingId);
	}
	
	return details;
}

- (NSMutableArray *)getCachedTrainingHistoriesWithUsername:(NSString *)username trainingId:(NSInteger)trainingId {
	NSMutableArray * trainingHistories = [NSMutableArray array];
	sqlite3 * dbConnection;
	
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT training_id, comment, average_score, priority, last_updated FROM training_histories ORDER BY priority ASC", -1, &statement, nil) == SQLITE_OK) {
			sqlite3_bind_int64(statement, 1, trainingId);
			
			while (sqlite3_step(statement) == SQLITE_ROW) {
				TrainingHistory * trainingHistory = [TrainingHistory new];
				
				trainingHistory.comment = [NSString stringWithUTF8String:(const char*)sqlite3_column_text(statement, 1)];
				trainingHistory.averageScore = sqlite3_column_double(statement, 2);
				trainingHistory.lastUpdated = [NSDate dateWithTimeIntervalSince1970:sqlite3_column_int64(statement, 4)];
				
				[trainingHistories addObject:trainingHistory];
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached training histories; username=%@; trainingId=%d; error=%s", username, trainingId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
		
		sqlite3_finalize(statement);
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! CacheManager: failed to retrieve cached training histories; username=%@; trainingId=%d", username, trainingId);
	}
	
	return trainingHistories;
}

- (NSMutableArray *)getCachedTrainingStepsWithTrainingId:(NSInteger)trainingId {
	NSMutableArray * trainingSteps = [NSMutableArray array];
	sqlite3 * dbConnection;
	
	if (sqlite3_open([[self getCacheDBPath] UTF8String], &dbConnection) == SQLITE_OK) {
		sqlite3_stmt * statement;
		if (sqlite3_prepare_v2(dbConnection, "SELECT id, training_id, step_type, title, picture, text, sound, url, step, last_updated FROM training_steps WHERE training_id =? ORDER BY step ASC, id ASC", -1, &statement, nil) == SQLITE_OK) {
			sqlite3_bind_int64(statement, 1, trainingId);
			
			while (sqlite3_step(statement) == SQLITE_ROW) {
				TrainingStep * step = [TrainingStep new];
				
				step.stepId = sqlite3_column_int64(statement, 0);
				step.stepType = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
				step.picture = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
				step.text = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 5)];
				step.sound = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 6)];
				step.url = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 7)];
				step.step = sqlite3_column_int(statement, 8);
				step.lastUpdated = [NSDate dateWithTimeIntervalSince1970:sqlite3_column_int64(statement, 9)];
				
				[trainingSteps addObject:step];
			}
		} else {
			DDLogError(@"! CacheManager: failed to retrieve cached training steps; trainingId=%d; error=%s", trainingId, sqlite3_errmsg(dbConnection));
			sqlite3_close(dbConnection);
			return nil;
		}
		
		sqlite3_finalize(statement);
		sqlite3_close(dbConnection);
	} else {
		DDLogError(@"! CacheManager: failed to retrieve cached training steps; trainingId=%d", trainingId);
	}
	
	return trainingSteps;
}

- (void)removeCachedTrainingProfile {
	trainingProfile = nil;
}

#pragma misc methods
- (double)averageRating {
	double totalRatings = 0.0;
	
	for (TrainingStep * step in currentTrainingSteps) {
		totalRatings += step.rating;
	}
	
	return totalRatings / currentTrainingSteps.count;
}

- (TrainingStep *)getCurrentTrainingStep {
	return [currentTrainingSteps objectAtIndex:currentTrainingStepIdx];
}

- (BOOL)areAllTrainingStepsRated {
	BOOL allStepsAreRated = YES;
	
	for (TrainingStep * step in currentTrainingSteps) {
		if (step.rating < 1) {
			allStepsAreRated = NO;
			break;
		}
	}
	return allStepsAreRated;
}

- (BOOL)isCurrentTrainingStepRated {
	return [self getCurrentTrainingStep].rating > 0;
}

- (BOOL)isFirstStep {
	return currentTrainingStepIdx <= 0;
}

- (BOOL)isLastStep {
	return currentTrainingStepIdx >= currentTrainingSteps.count-1;
}

- (BOOL)prevStep {
	if ([self isFirstStep]) {
		return NO;
	}
	currentTrainingStepIdx--;
	return YES;
}

- (BOOL)nextStep {
	if ([self isLastStep]) {
		return NO;
	}
	currentTrainingStepIdx++;
	return YES;
}

@end
