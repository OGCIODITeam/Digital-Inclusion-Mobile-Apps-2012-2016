//
//  AccessibilitySubviewsOrderedByTag.h
//  LearnSmart
//
//  Created by Andrew Chung on 26/2/14.
//  Copyright (c) 2014 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccessibilitySubviewsOrderedByTag : UIView

@end
