//
//  CocoaLumberjackConfig.m
//  LearnSmart
//
//  Created by Jack Cheung on 1/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "CocoaLumberjackConfig.h"

@implementation CocoaLumberjackConfig

@end
