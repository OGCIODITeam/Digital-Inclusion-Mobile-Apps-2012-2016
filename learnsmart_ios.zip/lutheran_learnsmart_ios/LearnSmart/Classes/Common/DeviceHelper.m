//
//  DeviceHelper.m
//  CP-EBook
//
//  Created by Jack Cheung on 03/04/2012.
//  Copyright (c) 2012 Cloud Pillar Limited. All rights reserved.
//

#import "DeviceHelper.h"
#import "SynthesizeSingleton.h"
#import <sys/utsname.h>

@implementation DeviceHelper

SYNTHESIZE_SINGLETON_FOR_CLASS(DeviceHelper)

+ (id)getInstance {
	return [DeviceHelper sharedDeviceHelper];
}

- (id)init {
	self = [super init];
	if (self) {
		device = [UIDevice currentDevice];
	}
	return self;
}

#pragma mark - selectors
- (BOOL)isiPad {
	return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad;
}

- (BOOL)isiPhoneOriPodTouch {
	return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone;
}

- (NSString *) getDeviceType{
	struct utsname systemInfo;
    uname(&systemInfo);
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    if ([platform rangeOfString:@"iPhone"].location != NSNotFound)    return @"iPhone";
    if ([platform rangeOfString:@"iPad"].location != NSNotFound)    return @"iPad";
    if ([platform rangeOfString:@"iPod"].location != NSNotFound)    return @"iPod";
    
    return platform;
}

-(BOOL) needMirror{
    struct utsname systemInfo;
    uname(&systemInfo);
	
    return [[NSString stringWithCString:systemInfo.machine
							   encoding:NSUTF8StringEncoding] isEqualToString:@"iPad1,1" ]
	|| [[NSString stringWithCString:systemInfo.machine
						   encoding:NSUTF8StringEncoding] isEqualToString:@"iPhone3,1" ]
	|| [[NSString stringWithCString:systemInfo.machine
						   encoding:NSUTF8StringEncoding] isEqualToString:@"iPhone2,1" ];
}
@end