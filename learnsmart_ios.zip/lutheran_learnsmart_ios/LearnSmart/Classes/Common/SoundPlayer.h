//
//  SoundPlayer.h
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface SoundPlayer : NSObject {
	NSBundle * mainBundle;
	AVAudioPlayer * musicPlayer;
}

+ (id)getInstance;
- (void)playAudio:(NSString *)filename;
- (void)stop;

@end
