//
//  CacheManager.h
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AboutUs, AppConfig, EGOCache, LoginToken, Training, TrainingDetails, TrainingProfile, TrainingStep;

@interface CacheManager : NSObject {
	AppConfig * appConfig;
	EGOCache * cache;
	NSDate * lastAboutUsUpdateTime;
	NSMutableDictionary * lastPublicTrainingUpdateTimes;
	NSDate * lastTrainingCategoryScoresUpdateTime;
	NSMutableDictionary * lastTrainingStepsUpdateTimes;	// for a set of steps
}

@property (nonatomic, assign) Training * currentTraining;
@property (nonatomic, assign) NSUInteger currentTrainingStepIdx;
@property (nonatomic, strong) NSMutableArray * currentTrainingSteps;
@property (nonatomic, strong) TrainingProfile * trainingProfile;

+ (id)getInstance;
- (double)averageRating;
- (TrainingStep *)getCurrentTrainingStep;
- (BOOL)areAllTrainingStepsRated;
- (void)cacheAboutUs:(AboutUs *)aboutUs;
- (void)cacheFileAtUrl:(NSString *)url success:(void(^)(NSString * localPath))success failure:(void (^)(NSInteger httpErrorCode, NSString * errorMessage))failure;
- (void)cacheFilesAtUrlList:(NSArray *)urlList success:(void(^)(NSArray * pathList))success failure:(void(^)(NSInteger httpErrorCode, NSString * errorMessage))failure;
- (void)cacheTrainings:(NSArray *)trainings withCategoryId:(NSInteger)catId;
- (void)cacheTrainings:(NSArray *)trainings withLoginToken:(LoginToken *)loginToken;
- (void)cacheTrainingCategoryScores:(NSArray *)scores;
- (void)cacheTrainingDetails:(TrainingDetails *)details username:(NSString *)username trainingId:(NSInteger)trainingId;
- (void)cacheTrainingHistories:(NSArray *)histories username:(NSString *)username trainingId:(NSInteger)trainingId;
- (void)cacheTrainingSteps:(NSArray *)steps withTrainingId:(NSInteger)trainingId;
- (AboutUs *)getCachedAboutUs;
- (NSString *)getCachedPathForUrl:(NSString *)url;
- (NSMutableArray *)getCachedPublicTrainingsWithCatId:(NSInteger)catId;
- (NSMutableArray *)getCachedTrainingCategoryScores;
- (NSMutableArray *)getCachedTrainingsWithLoginToken:(LoginToken *)loginToken;
- (TrainingDetails *)getCachedTrainingDetailsWithUsername:(NSString *)username trainingId:(NSInteger)trainingId;
- (NSMutableArray *)getCachedTrainingHistoriesWithUsername:(NSString *)username trainingId:(NSInteger)trainingId;
- (NSMutableArray *)getCachedTrainingStepsWithTrainingId:(NSInteger)trainingId;
- (NSString *)getFullCachePathForFile:(NSString *)path;
- (BOOL)isAboutUsCacheExpired;
- (BOOL)isCurrentTrainingStepRated;
- (BOOL)isFirstStep;
- (BOOL)isLastStep;
- (BOOL)isPublicTrainingCacheExpiredWithCatId:(NSInteger)catId;
- (BOOL)isTrainingCategoryScoresCacheExpired;
- (BOOL)isTrainingStepsCacheExpiredWithTrainingId:(NSInteger)trainingId;
- (BOOL)isURLCached:(NSString *)url;
- (BOOL)prevStep;
- (BOOL)nextStep;
- (void)removeCachedFile:(NSString *)path;
- (void)removeCachedFileForUrl:(NSString *)url;
- (void)removeCachedTrainingProfile;

@end
