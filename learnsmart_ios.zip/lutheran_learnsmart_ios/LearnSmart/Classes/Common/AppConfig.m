//
//  AppConfig.m
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "AppConfig.h"

static AppConfig *appConfig = nil;
@implementation AppConfig

@synthesize aboutUsNewsColor, aboutUsNewsFontIPad, aboutUsNewsFontIPhone, aboutUsTextStyleIPad, aboutUsTextStyleIPhone, bgMusicRelativePath, cacheDBName, cacheIntervalInSec, clickSoundRelativePath, commentsTextStyleIPad, commentsTextStyleIPhone, crashReportUrl, numAnimatedGirlFrames, numAnimatedGirlPauseFrames, wsTimeoutInterval, wsUrlPrefix;
@synthesize miniGameCheckpointChange, miniGameCheckpointMatching, miniGameCheckpointMemory;

- (id)init {
	self = [super init];
	if (self) {
		aboutUsNewsColor = [UIColor colorWithRed:0.788f green:0.38f blue:.0f alpha:1.0f];	// rgb(201, 97, 00)
		aboutUsNewsFontIPad = [UIFont boldSystemFontOfSize:44.0f];
		aboutUsNewsFontIPhone = [UIFont boldSystemFontOfSize:18.0f];
		aboutUsTextStyleIPad = @"<style type=\"text/css\">body { font-size: 36px; font-weight: bold; color: rgb(201, 97,00); -webkit-user-select: none; margin-top: -3px; } .timestamp { font-size: 24px; } .articleText { font-size: 32px; } .columnHeader { color: rgb(196, 86, 43); font-size: 32px; font-weight: bold; margin-top: 0; margin-bottom: 32px; }</style>";
		aboutUsTextStyleIPhone = @"<style type=\"text/css\">body { font-size: 22px; font-weight: bold; color: rgb(201, 97,00); -webkit-user-select: none; margin-top: -3px; } .timestamp { font-size: 14px; } .articleText { font-size: 18px; } .columnHeader { color: rgb(196, 86, 43); font-size: 18px; font-weight: bold; margin-top: 0; margin-bottom: 18px; }</style>";
		bgMusicRelativePath = @"bg_music.mp3";
		cacheDBName = @"app.db";
		cacheIntervalInSec = 5;	// 5 seconds caching
		clickSoundRelativePath = @"press_button.mp3";
		commentsTextStyleIPad = @"<style type=\"text/css\">body { font-size: 44px; font-weight: bold; color: rgb(201, 97,00); }</style>";
		commentsTextStyleIPhone = @"<style type=\"text/css\">body { font-size: 18px; font-weight: bold; color: rgb(201, 97,00); }</style>";
		crashReportUrl = @"http://ws.cloudpillar.com.hk/QuincyKit/crash_v200.php";
		
		miniGameCheckpointChange = @"minigame.change";
		miniGameCheckpointMatching = @"minigame.matching";
		miniGameCheckpointMemory = @"minigame.memory";
		
		numAnimatedGirlFrames = 4;
		numAnimatedGirlPauseFrames = 4;
		wsTimeoutInterval = 12;
		wsUrlPrefix = @"http://learnsmart.cloudpillar.com.hk/ws/";
//		wsUrlPrefix = @"http://test.cloudpillar.com.hk/learnsmart/ws/";
	}
	return self;
}

+ (id)getInstance {
	@synchronized(self) {
		if (appConfig == nil) {
			appConfig = [[self alloc] init];
		}
	}
	
	return appConfig;
}

@end
