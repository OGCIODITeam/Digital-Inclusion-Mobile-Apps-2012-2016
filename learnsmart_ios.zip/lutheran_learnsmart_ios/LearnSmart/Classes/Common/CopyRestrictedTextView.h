//
//  CopyRestrictedTextView.h
//  LearnSmart
//
//  Created by Jack Cheung on 3/10/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

// This is simply the UITextView, but with text not copyable / selectable
@interface CopyRestrictedTextView : UITextView

@end
