//
//  MobileLoginSessionManager.m
//  LearnSmart
//
//  Created by Jack Cheung on 3/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "MobileLoginSessionManager.h"
#import "LoginToken.h"
#import "CocoaLumberjackConfig.h"

static MobileLoginSessionManager * loginSessionManager;

@implementation MobileLoginSessionManager

@synthesize loginToken;

- (id)init {
	self = [super init];
	if (self) {
		userDefaults = [NSUserDefaults standardUserDefaults];
		loginToken = nil;
		[self loadLoginToken];
	}
	return self;
}

- (void)loadLoginToken {
	NSData * loginTokenData = [userDefaults objectForKey:LOGIN_TOKEN_KEY];
	loginToken = [NSKeyedUnarchiver unarchiveObjectWithData:loginTokenData];
	DDLogInfo(@"! loginToken is null?%@", loginToken?@"NO":@"YES");
}

+ (id)getInstance {
	@synchronized(self) {
		if (!loginSessionManager) {
			loginSessionManager = [MobileLoginSessionManager new];
		}
	}
	return loginSessionManager;
}

- (void)setLoginToken:(LoginToken *)_loginToken {
	@synchronized(self) {
		loginToken = _loginToken;
		
		NSData * loginTokenData = [NSKeyedArchiver archivedDataWithRootObject:loginToken];
		[userDefaults setObject:loginTokenData forKey:LOGIN_TOKEN_KEY];
		[userDefaults synchronize];
	}
}

- (BOOL)isLoggedIn {
	return loginToken != nil;
}

@end
