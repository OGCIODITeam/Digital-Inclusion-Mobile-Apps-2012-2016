//
//  BGMusicPlayer.m
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "BGMusicPlayer.h"
#import "AppConfig.h"
#import "CocoaLumberjackConfig.h"

static BGMusicPlayer * musicPlayer = nil;

@implementation BGMusicPlayer

- (id)init {
	self = [super init];
	if (self) {
		AppConfig * appConfig = [AppConfig getInstance];
		NSBundle * mainBundle = [NSBundle mainBundle];
		NSError * error = nil;
		
		musicPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[mainBundle URLForResource:appConfig.bgMusicRelativePath withExtension:@""] error:&error];
		if (error != nil) {
			DDLogError(@"! failed to init bg music player; error=%@", [error localizedDescription]);
		}
	}
	return self;
}

+ (id)getInstance {
	@synchronized(self) {
		if (musicPlayer == nil) {
			musicPlayer = [BGMusicPlayer new];
		}
	}
	return musicPlayer;
}

#pragma playback control
- (void)start {
	[self stop];
	[musicPlayer play];
}

- (void)stop {
	if ([musicPlayer isPlaying]) {
		[musicPlayer stop];
	}
}

@end
