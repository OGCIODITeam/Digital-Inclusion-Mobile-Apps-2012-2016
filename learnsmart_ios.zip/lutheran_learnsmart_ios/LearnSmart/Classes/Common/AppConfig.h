//
//  AppConfig.h
//  LearnSmart
//
//  Created by Jack Cheung on 18/6/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppConfig : NSObject

@property (nonatomic, strong) UIColor *aboutUsNewsColor;
@property (nonatomic, strong) UIFont *aboutUsNewsFontIPad;
@property (nonatomic, strong) UIFont *aboutUsNewsFontIPhone;
@property (nonatomic, strong) NSString *aboutUsTextStyleIPad;
@property (nonatomic, strong) NSString *aboutUsTextStyleIPhone;
@property (nonatomic, strong) NSString *bgMusicRelativePath;
@property (nonatomic, strong) NSString *cacheDBName;
@property (nonatomic, assign) NSTimeInterval cacheIntervalInSec;
@property (nonatomic, strong) NSString *clickSoundRelativePath;
@property (nonatomic, strong) NSString *commentsTextStyleIPad;
@property (nonatomic, strong) NSString *commentsTextStyleIPhone;
@property (nonatomic, strong) NSString *crashReportUrl;
@property (nonatomic, strong) NSString *miniGameCheckpointMatching;
@property (nonatomic, strong) NSString *miniGameCheckpointMemory;
@property (nonatomic, strong) NSString *miniGameCheckpointChange;
@property (nonatomic, assign) NSInteger numAnimatedGirlFrames;
@property (nonatomic, assign) NSInteger numAnimatedGirlPauseFrames;
@property (nonatomic, assign) NSInteger wsTimeoutInterval;
@property (nonatomic, strong) NSString *wsUrlPrefix;

+ (id)getInstance;

@end
