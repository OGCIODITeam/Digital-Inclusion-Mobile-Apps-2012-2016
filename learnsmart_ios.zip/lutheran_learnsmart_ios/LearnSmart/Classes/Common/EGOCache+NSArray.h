//
//  EGOCache+NSArray.h
//  LearnSmart
//
//	Ref: https://gist.github.com/shnhrrsn/742758
//

#import "EGOCache.h"

@interface EGOCache (NSArray)

- (void)setArray:(NSArray*)array forKey:(NSString*)key;
- (void)setArray:(NSArray*)array forKey:(NSString*)key withTimeoutInterval:(NSTimeInterval)timeoutInterval;

- (NSArray*)arrayForKey:(NSString*)key;
@end