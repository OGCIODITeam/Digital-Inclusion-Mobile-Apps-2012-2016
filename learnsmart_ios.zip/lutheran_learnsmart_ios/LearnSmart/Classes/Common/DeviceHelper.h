//
//  DeviceHelper.h
//  CP-EBook
//
//  Created by Jack Cheung on 03/04/2012.
//  Copyright (c) 2012 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceHelper : NSObject {
	UIDevice * device;
}

+ (id)getInstance;
- (BOOL)isiPhoneOriPodTouch;
- (BOOL)isiPad;
-(BOOL) needMirror;
- (NSString *) getDeviceType;
@end
