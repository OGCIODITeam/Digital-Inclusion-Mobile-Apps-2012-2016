//
//  SoundPlayer.m
//  LearnSmart
//
//  Created by Jack Cheung on 5/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "SoundPlayer.h"
#import "CocoaLumberjackConfig.h"

static SoundPlayer * soundPlayer = nil;

@implementation SoundPlayer

- (id)init {
	self = [super init];
	if (self) {
		mainBundle = [NSBundle mainBundle];
	}
	return self;
}

+ (id)getInstance {
	@synchronized(self) {
		if (soundPlayer == nil) {
			soundPlayer = [SoundPlayer new];
		}
	}
	return soundPlayer;
}

- (void)playAudio:(NSString *)filename {
	NSError * error = nil;
	
	[self stop];
	
	if ([filename hasPrefix:@"/"]) {
		DDLogInfo(@"! playAudio: %@", filename);
		NSData * audioData = [NSData dataWithContentsOfFile:filename];
		musicPlayer = [[AVAudioPlayer alloc] initWithData:audioData error:&error];
	} else {
		NSURL * url = [mainBundle URLForResource:filename withExtension:@""];
		musicPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
	}
	
	
	if (error != nil) {
		DDLogError(@"! failed to init bg music player; error=%@", [error localizedDescription]);
	}
	[musicPlayer play];
}

- (void)stop {
	if ([musicPlayer isPlaying]) {
		[musicPlayer stop];
	}
}

@end
