//
//  CheckPointLoggerAgent.h
//  Lutheran Learn Smart
//
//	Modified by Jack Cheung, 2013-06-26
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckPointLoggerAgent : NSObject<NSURLConnectionDelegate, NSURLConnectionDataDelegate> {
	NSString * wsURL;
}

- (void)logForAppLaunch;
- (void)logForMiniGamePlay:(NSString *)miniGame;
- (NSString *)getCustomGeneratedDeviceUUID;

@end
