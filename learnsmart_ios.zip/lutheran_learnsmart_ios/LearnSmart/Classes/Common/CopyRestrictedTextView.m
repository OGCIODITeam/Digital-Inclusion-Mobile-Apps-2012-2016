//
//  CopyRestrictedTextView.m
//  LearnSmart
//
//  Created by Jack Cheung on 3/10/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "CopyRestrictedTextView.h"

@implementation CopyRestrictedTextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (BOOL)canBecomeFirstResponder {
    return NO;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
