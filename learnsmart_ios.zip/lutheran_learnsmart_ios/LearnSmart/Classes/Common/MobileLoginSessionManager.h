//
//  MobileLoginSessionManager.h
//  LearnSmart
//
//  Created by Jack Cheung on 3/7/13.
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LoginToken;

@interface MobileLoginSessionManager : NSObject {
	NSUserDefaults * userDefaults;
}

@property (nonatomic, strong) LoginToken * loginToken;

+ (id)getInstance;
- (BOOL)isLoggedIn;

@end
