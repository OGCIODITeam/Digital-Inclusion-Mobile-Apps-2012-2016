//
//  CheckPointLoggerAgent.m
//  Lutheran Learn Smart
//
//	Modified by Jack Cheung, 2013-06-26
//  Copyright (c) 2013 Cloud Pillar Limited. All rights reserved.
//

#import "CheckPointLoggerAgent.h"
#import "AppConfig.h"
#import <UIKit/UIDevice.h>

@implementation CheckPointLoggerAgent

- (id)init {
	self = [super init];
	if (self) {
		AppConfig * appConfig = [AppConfig getInstance];
		wsURL = [NSString stringWithFormat:@"%@checkpoints.json", appConfig.wsUrlPrefix];
	}
	return self;
}

- (void)logForAppLaunch {
	AppConfig * appConfig = [AppConfig getInstance];
    NSString *osVer = [UIDevice currentDevice].systemVersion;
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *appVer = [[mainBundle infoDictionary] valueForKey:@"CFBundleShortVersionString"];
	NSString *deviceFamily = @"ios";
    NSString *deviceModel = [[UIDevice currentDevice] model];
    NSString *type = @"appLaunch";
	NSString *generatedDeviceUUID = [self getCustomGeneratedDeviceUUID];

	NSData * param = [[NSString stringWithFormat:@"event=%@&appVer=%@&deviceFamily=%@&deviceModel=%@&osVer=%@&uuid=%@", type, appVer, deviceFamily, deviceModel, osVer, generatedDeviceUUID] dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
    NSLog(@"! logForAppLaunch url:[%@]", wsURL);
    
    NSURL *url = [NSURL URLWithString:wsURL];
    NSMutableURLRequest *logRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:appConfig.wsTimeoutInterval];
	[logRequest setHTTPMethod:@"POST"];
	[logRequest setValue:[NSString stringWithFormat:@"%d", param.length] forHTTPHeaderField:@"Content-Length"];
	[logRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[logRequest setHTTPBody:param];
	
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:logRequest delegate:self];
    if (connection) {
        [connection start];        
    } else {
        NSLog(@"! Failed to make connection to check point logger");
    }
}

- (void)logForMiniGamePlay:(NSString *)miniGame {
	AppConfig * appConfig = [AppConfig getInstance];
	NSString *osVer = [UIDevice currentDevice].systemVersion;
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *appVer = [[mainBundle infoDictionary] valueForKey:@"CFBundleShortVersionString"];
	NSString *deviceFamily = @"ios";
    NSString *deviceModel = [[UIDevice currentDevice] model];
	NSString *generatedDeviceUUID = [self getCustomGeneratedDeviceUUID];
	
	NSData * param = [[NSString stringWithFormat:@"event=%@&appVer=%@&deviceFamily=%@&deviceModel=%@&osVer=%@&uuid=%@", miniGame, appVer, deviceFamily, deviceModel, osVer, generatedDeviceUUID] dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	NSLog(@"! logForMiniGamePlay: %@", miniGame);
	
	NSURL * url = [NSURL URLWithString:wsURL];
	NSMutableURLRequest * logRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:appConfig.wsTimeoutInterval];
	[logRequest setHTTPMethod:@"POST"];
	[logRequest setValue:[NSString stringWithFormat:@"%d", param.length] forHTTPHeaderField:@"Content-Length"];
	[logRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[logRequest setHTTPBody:param];
	
	NSURLConnection * connection = [[NSURLConnection alloc] initWithRequest:logRequest delegate:self];
	if (connection) {
		[connection start];
	} else {
		NSLog(@"! Failed to make connection to check point logger");
	}
}

- (NSString *)getCustomGeneratedDeviceUUID
{
    NSString *generatedDeviceUUID;
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
	generatedDeviceUUID = (NSString *)[userDefaults objectForKey:@"CPGeneratedDeviceUUID"];
	if (generatedDeviceUUID == nil) {
        CFUUIDRef newUUIDRef = CFUUIDCreate(NULL);
        generatedDeviceUUID = (__bridge_transfer NSString *)CFUUIDCreateString(NULL, newUUIDRef);
        CFRelease(newUUIDRef);        
        [userDefaults setObject:generatedDeviceUUID forKey:@"CPGeneratedDeviceUUID"];
        [userDefaults synchronize];
    }
    return generatedDeviceUUID;
}

- (void)connection:(NSURLConnection *)connection   
  didFailWithError:(NSError *)error           
{
    NSLog(@"! NSURLConnection error: %@", error);
}

- (void)connection:(NSURLConnection *)connection     
    didReceiveData:(NSData *)data              
{
//    NSString *reply = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //NSLog(@"connectionDidFinishLoading");
}


@end
