//
//  StoryFourEcardViewController.h
//  YWCA
//
//  Created by Eric on 3/1/15.
//
//

#ifndef YWCA_StoryFourEcardViewController_h
#define YWCA_StoryFourEcardViewController_h


#import <UIKit/UIKit.h>
#import "Social/Social.h"

#define ECARD_WIDTH 1934.0
#define ECARD_HEIGHT 1426.0

@interface StoryFourEcardViewController : UIViewController<UITextFieldDelegate,UIDocumentInteractionControllerDelegate>
{
    __weak IBOutlet  UIImageView* imageViewObject1;
    __weak IBOutlet  UIImageView* imageViewObject2;
    __weak IBOutlet  UIImageView* imageViewObject3;
    //__weak IBOutlet  UIImageView*    imageViewSender;
    //__weak IBOutlet  UIImageView*    imageViewReceiver;
    
    __weak IBOutlet  UILabel*    senderlbl;
    __weak IBOutlet  UILabel*    receiverlbl;
    
    //__weak IBOutlet  UITextField* senderTF;
    //__weak IBOutlet  UITextField* receiverTF;
    UITextField* senderTF;
    UITextField* receiverTF;
    
    __weak IBOutlet  UIButton*   shareBtn;
    __weak IBOutlet  UIButton*   nextBtn;
    
    __weak IBOutlet  UIImageView* bg;
    __weak IBOutlet  UIImageView* ecardBg;
    __weak IBOutlet  UIImageView* senderImageView;
    __weak IBOutlet  UIImageView* receiverImageView;
    
    NSString* senderText;
    NSString* receiverText;
    CGPoint  obj1Pos;
    CGPoint  obj2Pos;
    CGPoint  obj3Pos;
    
    CGFloat heightOfScreen;
    CGFloat widthOfScreen;
    CGFloat reducedEcardWidth;
    CGFloat reducedEcardHeight;
}

@property(nonatomic,retain) UIDocumentInteractionController *documentationInteractionController;

-(IBAction) shareBtnPressed:(id)sender;
-(IBAction) nextBtnPressed:(id)sender;

@end


#endif
