//
//  openBookViewIpad.h
//  YWCA
//
//  Created by Marshals Chan on 12/2/15.
//
//

#import <UIKit/UIKit.h>


@interface openBookViewIpad : UIView
@property (strong, nonatomic)  UIImageView *imgComplete;
@property (strong, nonatomic)  UIImageView *imgStar1;
@property (strong, nonatomic)  UIImageView *imgStar2;
@property (strong, nonatomic)  UIImageView *imgStar3;
@property (strong, nonatomic)  UIImageView *imgStar4;
@property (strong, nonatomic)  UIImageView *imgStar5;
@property (strong, nonatomic)  UIButton *btnBook;
@property (strong, nonatomic)  UILabel *lblStageTitle;

-(void)initViewsWithState:(int)state noOfStar:(int)star completed:(BOOL)completed;
-(void)setStars:(int)mark;
-(void)setComplete:(BOOL)isComplete;
@end
