//
//  IntroductionViewController.h
//  YWCA
//
//  Created by Benny SYW on 11/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface IntroductionViewController : UIViewController
- (IBAction)back:(id)sender;
- (IBAction)bgm_on:(id)sender;
- (IBAction)bgm_off:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
@property (strong, nonatomic) IBOutlet UIImageView *bg;
@property (strong, nonatomic) IBOutlet UIButton *backbtn;
@property (weak, nonatomic) IBOutlet UIButton *bgm_on;
@property (weak, nonatomic) IBOutlet UIButton *bgm_off;
@property (weak, nonatomic) IBOutlet UIWebView *uiWebView;


@end
