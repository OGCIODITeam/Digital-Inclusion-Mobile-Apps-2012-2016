/*
 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
 */

//
//  AppDelegate.m
//  YWCA
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//

#import "AppDelegate.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"
#import "phonegap_main.h"
#import "AgreementViewController.h"

#import <Cordova/CDVPlugin.h>

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize window, viewController;
@synthesize select_stage, select_game;

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

- (id)init
{
    /** If you need to do any extra app-specific initialization, you can do it here
     *  -jm
     **/
    NSHTTPCookieStorage* cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];

    [cookieStorage setCookieAcceptPolicy:NSHTTPCookieAcceptPolicyAlways];

    int cacheSizeMemory = 8 * 1024 * 1024; // 8MB
    int cacheSizeDisk = 32 * 1024 * 1024; // 32MB
#if __has_feature(objc_arc)
        NSURLCache* sharedCache = [[NSURLCache alloc] initWithMemoryCapacity:cacheSizeMemory diskCapacity:cacheSizeDisk diskPath:@"nsurlcache"];
#else
        NSURLCache* sharedCache = [[[NSURLCache alloc] initWithMemoryCapacity:cacheSizeMemory diskCapacity:cacheSizeDisk diskPath:@"nsurlcache"] autorelease];
#endif
    [NSURLCache setSharedURLCache:sharedCache];
    
    self = [super init];
    return self;
}

#pragma mark UIApplicationDelegate implementation

/**
 * This is main kick off after the app inits, the views and Settings are setup here. (preferred - iOS4 and up)
 */
- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions
{
    CGRect screenBounds = [[UIScreen mainScreen] bounds];

#if __has_feature(objc_arc)
        self.window = [[UIWindow alloc] initWithFrame:screenBounds];
#else
        self.window = [[[UIWindow alloc] initWithFrame:screenBounds] autorelease];
#endif
    self.window.autoresizesSubviews = YES;

#if __has_feature(objc_arc)
    //init controller
        self.viewController = [[phonegap_main alloc] init];
#else
        self.viewController = [[[phonegap_main alloc] init] autorelease];
#endif

    // Set your app's start page by setting the <content src='foo.html' /> tag in config.xml.
    // If necessary, uncomment the line below to override it.
    // self.viewController.startPage = @"index.html";

    // NOTE: To customize the view's frame size (which defaults to full screen), override
    // [self.viewController viewWillAppear:] in your view controller.
    self.viewController = [[phonegap_main alloc] init];
    //self.window.rootViewController = self.viewController;
    UIStoryboard *storyboard;
    if (IS_IPAD) {
        storyboard = [UIStoryboard storyboardWithName:@"MainIpad" bundle:nil]; //MainIpad
    }else{
        storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    }
    
    NSString *check_value;
    check_value = [self getAgreeCheck];
    if([check_value isEqual:@"1"]) {
        UIViewController *rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"start"];
        self.window.rootViewController = rootViewController;
        //[[UIApplication sharedApplication].keyWindow setRootViewController:rootViewController];
        //self.window.rootViewController = [storyboard instantiateInitialViewController];
        //UIViewController *ckcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"start"];
        //[self.navigationController pushViewController:ckcontroller animated:YES];
    } else {
        self.window.rootViewController = [storyboard instantiateInitialViewController];
    }
    
    [self.window makeKeyAndVisible];
 
    if (self.settingIDToEdit != -1) {
        // Load the record with the specific ID from the database.
        //indexMusic = [self loadInfoToEdit];
        //NSLog(@"Loaging error");
    }
    [self createCopyOfDatabaseIfNeeded];
    [self createTable];
    [self insertBaseData];
    
    //Modify database
    //3 Mar
    //add r_stars_1 to r_stars_5
    for (int i=1; i<=5; i++) {
        for (int j=1; j<=4; j++) {
            BOOL added = [self addCol:nil col_name:[NSString stringWithFormat:@"r_stars_%d",j] col_type:@"int"];
            NSLog(@"added:%d",added);
            if (added == YES)
                [self updateData:nil col_name:[NSString stringWithFormat:@"r_stars_%d",j] data_id:i value:0];
        }
    }
    //引繼星星
    int org_star;
    for (int i=1; i<=5; i++) {
        for (int j=1; j<=4; j++) {
            org_star = [self getStarsInt:i game:j];
            NSLog(@"org star:%d",org_star);
            [self ultraRStars_stage:i game:j stars:org_star];
            if (org_star == 1 || org_star == 2) {
                org_star = 3;
            }
            [self ultraNStars_stage:i game:j stars:org_star];
        }
    }
    //for test, fast initial
    /*
     for (int i=1; i<=5; i++) {
     for (int j=1; j<=4; j++) {
     [self ultraNStars_stage:i game:j stars:0];
     }
     }
    */
    //add zip file size
    for (int k=1; k<=5; k++) {
        BOOL added = [self addCol:@"ywca_setting" col_name:[NSString stringWithFormat:@"stage%d_zip_size", k] col_type:@"long"];
        if (added == YES)
            [self updateData:@"ywca_setting" col_name:[NSString stringWithFormat:@"stage%d_zip_size",k] data_id:1 value:0];
    }
    //test different size
    //[self updateData:@"ywca_setting" col_name:@"stage1_zip_size" data_id:1 value:1];
    
    /*
    NSFileManager *fm = [NSFileManager defaultManager];
    NSLog(@"AppDelegate.h %@", [fm fileExistsAtPath:@"YWCA/platforms/ios/YWCA/Classes/AppDelegate.h"] ? @"exists" : @"doesn't exist");
    NSLog(@"current path: %@",[fm currentDirectoryPath]);
    */
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
    NSString *dataPath;
    
    /*
    for (int i=0; i<5; i++) {
        dataPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"/stage%d",i+1]];
        if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
            [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:nil]; //Create folder
    }
    */
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    
    return YES;
}

// this happens while we are running ( in the background, or from within our own app )
// only valid if YWCA-Info.plist specifies a protocol to handle
- (BOOL)application:(UIApplication*)application openURL:(NSURL*)url sourceApplication:(NSString*)sourceApplication annotation:(id)annotation
{
    if (!url) {
        return NO;
    }

    [self.viewController processOpenUrl:url];

    // all plugins will get the notification, and their handlers will be called
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:CDVPluginHandleOpenURLNotification object:url]];

    return YES;
}

// repost all remote and local notification using the default NSNotificationCenter so multiple plugins may respond
- (void)application:(UIApplication*)application
    didReceiveLocalNotification:(UILocalNotification*)notification
{
    // re-post ( broadcast )
    [[NSNotificationCenter defaultCenter] postNotificationName:CDVLocalNotification object:notification];
}

- (void)application:(UIApplication*)application
    didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    // re-post ( broadcast )
    NSString* token = [[[[deviceToken description]
        stringByReplacingOccurrencesOfString:@"<" withString:@""]
        stringByReplacingOccurrencesOfString:@">" withString:@""]
        stringByReplacingOccurrencesOfString:@" " withString:@""];

    [[NSNotificationCenter defaultCenter] postNotificationName:CDVRemoteNotification object:token];
}

- (void)application:(UIApplication*)application
    didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
    // re-post ( broadcast )
    [[NSNotificationCenter defaultCenter] postNotificationName:CDVRemoteNotificationError object:error];
}

- (NSUInteger)application:(UIApplication*)application supportedInterfaceOrientationsForWindow:(UIWindow*)window
{
    // iPhone doesn't support upside down by default, while the iPad does.  Override to allow all orientations always, and let the root view controller decide what's allowed (the supported orientations mask gets intersected).
    NSUInteger supportedInterfaceOrientations = (1 << UIInterfaceOrientationLandscapeLeft) | (1 << UIInterfaceOrientationLandscapeRight);

    return supportedInterfaceOrientations;
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication*)application
{
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    [self stopBgMusic];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    NSURL* murl = [[NSBundle mainBundle] URLForResource:@"main01" withExtension:@"mp3"];
    NSAssert(murl, @"URL is valid.");
    NSError* error = nil;
    self.bgmPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:murl error:&error];
    if(!self.bgmPlayer)
    {
        NSLog(@"Error creating player: %@", error);
    }
    if ([self getMusicInt] == 1) {
        self.bgmPlayer.volume = 0.5;
    }
    
    /*
    //todo:
    NSMutableArray* myArray = [NSMutableArray arrayWithContentsOfFile:[self getPath]];
    if(myArray != nil) {
        if([[myArray objectAtIndex:0]  isEqual: @"Sound"]) {
            [self.bgmPlayer prepareToPlay];
            [self.bgmPlayer play];
            self.bgmPlayer.numberOfLoops = -1;
        }
    }
    */
    NSString *indexMusic;
    indexMusic = [self getMusic];
    
    if([indexMusic isEqual: @"1"]) {
        [self playBgMusic];
    }
}

// === FMDB initialization ===

- (void)createCopyOfDatabaseIfNeeded {
    // First, test for existence.
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    // Database filename can have extension db/sqlite.
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *appDBPath = [documentsDirectory stringByAppendingPathComponent:@"ywca.db"];
    success = [fileManager fileExistsAtPath:appDBPath];
    if (success){
        return;
    }
    // The writable database does not exist, so copy the default to the appropriate location.
    NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"ywca.db"];
    //NSLog(@"DB path:%@", defaultDBPath);
    success = [fileManager copyItemAtPath:defaultDBPath toPath:appDBPath error:&error];
    if (!success) {
        NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
    }
}

- (void)createTable {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    //NSLog(@"DB path:%@", dbPath);
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    [database executeUpdate:@"create table if not exists ywca_setting(setting_id int primary key, item_music int, item_sound int, item_agreehide)"];
    [database executeUpdate:@"create table if not exists ywca_game(story_id int primary key, item_stage int, item_stars int, item_stage_stars_1 int, item_stage_stars_2 int, item_stage_stars_3 int, item_stage_stars_4 int, first_enter_1 int, first_enter_2 int, first_enter_3 int, first_enter_4 int, AR_finish int)"];
    //[database executeUpdate:@"create table if not exists ywca_game(story_id int primary key, item_stage int, item_stars int, item_stage_stars_1 int, item_stage_stars_2 int, item_stage_stars_3 int, item_stage_stars_4 int, r_stars_1 int, r_stars_2 int, r_stars_3 int, r_stars_4 int, first_enter_1 int, first_enter_2 int, first_enter_3 int, first_enter_4 int, AR_finish int)"];
    [database close];
}

- (void)insertBaseData {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    //NSString *sqlcheckgameQuery = @"SELECT count(*) FROM ywca_game";
    //NSString *sqlchecksettingQuery = @"SELECT count(*) FROM ywca_setting";
    //FMResultSet *resultsWithGame = [database executeQuery:sqlcheckgameQuery];
    //FMResultSet *resultsWithSetting = [database executeQuery:sqlchecksettingQuery];
    //NSLog(resultsWithGame,resultsWithSetting);
    
    NSString *insertsettingQuery = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_setting VALUES (%d, %d, %d, %d)", 1, 0, 1, 0];
    NSString *insertgameQuery1 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery2 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery3 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery4 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery5 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    /*
    NSString *insertgameQuery1 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery2 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery3 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery4 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    NSString *insertgameQuery5 = [NSString stringWithFormat:@"INSERT OR IGNORE INTO ywca_game VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)", 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    */
    [database executeUpdate:insertsettingQuery];
    [database executeUpdate:insertgameQuery1];
    [database executeUpdate:insertgameQuery2];
    [database executeUpdate:insertgameQuery3];
    [database executeUpdate:insertgameQuery4];
    [database executeUpdate:insertgameQuery5];
    
    [database close];
}

// === Setting Data ===

-(void)stopBgMusic{
    [self.bgmPlayer pause];
    //save playsetting to local storage(on / off)
//    NSMutableArray* myArray = [[NSMutableArray alloc]init];
//    [myArray addObject:@"Mute"];
//    [myArray writeToFile:[self getPath] atomically:YES];
}

-(void)playBgMusic{
    [self.bgmPlayer prepareToPlay];
    [self.bgmPlayer play];
    self.bgmPlayer.numberOfLoops = -1;
    //save playsetting to local storage
//    NSMutableArray* myArray = [[NSMutableArray alloc]init];
//    [myArray addObject:@"Sound"];
//    [myArray writeToFile:[self getPath] atomically:YES];
}

-(BOOL)isPlayerStop{
    
    return ![self.bgmPlayer isPlaying];
}

-(NSString*)getPath{
    NSString* path = [NSString stringWithFormat:@"%@%@",
                      [[NSBundle mainBundle] resourcePath],
                      @"bgmSetting.plist"];
    return path;
}



- (void)getAllSettingData {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int setting_id, item_music, item_sound, item_agreehide;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * from ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        setting_id = [resultsWithBaseData intForColumn:@"setting_id"];
        item_music = [resultsWithBaseData intForColumn:@"item_music"];
        item_sound = [resultsWithBaseData intForColumn:@"item_sound"];
        item_agreehide = [resultsWithBaseData intForColumn:@"item_agreehide"];
    }
    NSLog(@"setting_id==%d",setting_id);
    NSLog(@"item_music==%d",item_music);
    NSLog(@"item_sound==%d",item_sound);
    NSLog(@"item_agreehide==%d",item_agreehide);
    [database close];
}

- (NSString*)getMusic {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *music_value;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * FROM ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        music_value = [NSString stringWithFormat:@"%d",[resultsWithBaseData intForColumn:@"item_music"]];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"music_value = %@",music_value);
    }
    [database close];
    return music_value;
}

- (NSString*)getSound {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *sound_value;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * FROM ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        sound_value = [NSString stringWithFormat:@"%d",[resultsWithBaseData intForColumn:@"item_sound"]];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"sound_value = %@",sound_value);
    }
    [database close];
    return sound_value;
}

- (int)getMusicInt {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int music_value;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * FROM ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        music_value = [resultsWithBaseData intForColumn:@"item_music"];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"music_value = %@",music_value);
    }
    [database close];
    return music_value;
}

- (int)getSoundInt {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int sound_value;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * FROM ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        sound_value = [resultsWithBaseData intForColumn:@"item_sound"];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"sound_value = %@",sound_value);
    }
    [database close];
    return sound_value;
}

- (NSString*)getAgreeCheck {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *check_value;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * FROM ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        check_value = [NSString stringWithFormat:@"%d",[resultsWithBaseData intForColumn:@"item_agreehide"]];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"check_value = %@",check_value);
    }
    [database close];
    return check_value;
}

- (long)getFileSize:(int)stage {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    long file_size;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = @"SELECT * FROM ywca_setting";
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        file_size = [resultsWithBaseData longForColumn:[NSString stringWithFormat:@"stage%d_zip_size", stage]];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"music_value = %@",music_value);
    }
    [database close];
    return file_size;
}

- (void)updateSetting:(NSString*)item mode:(int)mode {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_setting SET '%@' = '%d' WHERE setting_id = 1", item, mode ];
    [database executeUpdate:updateQuery];
    [database close];
}

- (void)clearAllSetting {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *deleteQuery = @"DELETE FROM ywca_setting WHERE setting_id=1";
    [database executeUpdate:deleteQuery];
    [database close];
}


// === Game Data ===

- (NSString*)getStars:(int)stage game:(int)game {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *star, *thegame;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    thegame = [NSString stringWithFormat:@"item_stage_stars_%d", game];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d ", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        star = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:thegame]];
        
        // save your fetch data into the array, dictionaries.
        //NSLog(@"star====%@", star);
    }
    [database close];
    return star;
}

- (int)getStarsInt:(int)stage game:(int)game {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *thegame;
    int star;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    thegame = [NSString stringWithFormat:@"item_stage_stars_%d", game];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d ", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        star = [resultsWithBaseData intForColumn:thegame];
    }
    [database close];
    return star;
}

- (int)getFirstEnter:(int)stage game:(int)game {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *thegame;
    int enter;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    thegame = [NSString stringWithFormat:@"first_enter_%d", game];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d ", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        enter = [resultsWithBaseData intForColumn:thegame];
    }
    [database close];
    return enter;
}

- (NSString*)getStageStars:(int)stage {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *star;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id=%d", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        star = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stars"]];
        
        // save your fetch data into the array, dictionaries.
    }
    [database close];
    //star = @"0";
    return star;
}

- (int)getStageStarsInt:(int)stage {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int star;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id=%d", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        star = [resultsWithBaseData intForColumn:@"item_stars"];
        
        // save your fetch data into the array, dictionaries.
    }
    [database close];
    //star = @"0";
    return star;
}

- (int)getRStageStars:(int)stage {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int star;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id=%d", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        star = [resultsWithBaseData intForColumn:@"r_stars"];
        
        // save your fetch data into the array, dictionaries.
    }
    [database close];
    //star = @"0";
    return star;
}


- (int)getPass:(int)stage {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int pass;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        pass = [resultsWithBaseData intForColumn:@"item_stage"];
    }
    [database close];
    return pass;
}

- (int)getARfinish:(int)stage {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int ARfinish;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id=%d", stage];
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        ARfinish = [resultsWithBaseData intForColumn:@"AR_finish"];
        
        // save your fetch data into the array, dictionaries.
    }
    [database close];
    //star = @"0";
    return ARfinish;
}

- (void)setARfinish:(int)stage finish:(int)finish {
    int org_finish;
    org_finish = [self getARfinish:stage];
    if (org_finish < finish) {
        // Getting the database path.
        NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docsPath = [paths objectAtIndex:0];
        NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
        
        FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
        [database open];
        
        NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET AR_finish = %d WHERE story_id = %d", finish, stage ];
        [database executeUpdate:updateQuery];
        [database close];
    } else {
        NSLog(@"already finish");
    }
}

- (void)getAllGameData {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *story_id, *item_stage, *item_stars, *item_stage_stars_1, *item_stage_stars_2, *item_stage_stars_3, *item_stage_stars_4, *r_stars_1, *r_stars_2, *r_stars_3, *r_stars_4;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game"];
    NSLog(@"dbPath:%@", dbPath);
    
    // Query result
    FMResultSet *resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        story_id = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"story_id"]];
        item_stage = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stage"]];
        item_stars = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stars"]];
        item_stage_stars_1 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stage_stars_1"]];
        item_stage_stars_2 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stage_stars_2"]];
        item_stage_stars_3 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stage_stars_3"]];
        item_stage_stars_4 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"item_stage_stars_4"]];
        r_stars_1 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"r_stars_1"]];
        r_stars_2 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"r_stars_2"]];
        r_stars_3 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"r_stars_3"]];
        r_stars_4 = [NSString stringWithFormat:@"%@",[resultsWithBaseData stringForColumn:@"r_stars_4"]];
        
        // save your fetch data into the array, dictionaries.
        NSLog(@"story_id==%@",story_id);
        NSLog(@"item_stage==%@",item_stage);
        NSLog(@"item_stars==%@",item_stars);
        NSLog(@"item_stage_stars_1==%@",item_stage_stars_1);
        NSLog(@"item_stage_stars_2==%@",item_stage_stars_2);
        NSLog(@"item_stage_stars_3==%@",item_stage_stars_3);
        NSLog(@"item_stage_stars_4==%@",item_stage_stars_4);
        NSLog(@"r_stars_1==%@",r_stars_1);
        NSLog(@"r_stars_2==%@",r_stars_2);
        NSLog(@"r_stars_3==%@",r_stars_3);
        NSLog(@"r_stars_4==%@",r_stars_4);
    }
    [database close];
}

- (void)ultraEnter_stage:(int)stage game:(int)game enter:(int)enter {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET first_enter_%d = %d WHERE story_id = %d", game, enter, stage ];
    [database executeUpdate:updateQuery];
    [database close];
}

- (void)ultraStars_stage:(int)stage game:(int)game stars:(int)stars {
    
    int org_star;
    org_star = [self getStarsInt:stage game:game];
    if (org_star < stars) {
        // Getting the database path.
        NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docsPath = [paths objectAtIndex:0];
        NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
        
        FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
        [database open];
        
        NSString *updateRQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET r_stars_%d = %d WHERE story_id = %d", game, stars, stage ];
        [database executeUpdate:updateRQuery];
        
        if (stars == 1 || stars == 2) {
            stars = 3;
        }
        
        NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage_stars_%d = %d WHERE story_id = %d", game, stars, stage ];
        [database executeUpdate:updateQuery];
        [database close];
    } else {
        NSLog(@"New star is lower than the original");
    }
}

- (void)ultraNStars_stage:(int)stage game:(int)game stars:(int)stars {
    
    int org_star;
    org_star = [self getStarsInt:stage game:game];
    if (org_star < stars) {
        // Getting the database path.
        NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docsPath = [paths objectAtIndex:0];
        NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
        
        FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
        [database open];
        
//        if (stars == 1 || stars == 2) {
//            stars = 3;
//        }
        
        NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage_stars_%d = %d WHERE story_id = %d", game, stars, stage ];
        [database executeUpdate:updateQuery];
        [database close];
    } else {
        NSLog(@"New star is lower than the original");
    }
}

- (void)ultraRStars_stage:(int)stage game:(int)game stars:(int)stars {
    
    int org_star;
    org_star = [self getStarsInt:stage game:game];
//    if (org_star < stars) {
        // Getting the database path.
        NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docsPath = [paths objectAtIndex:0];
        NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
        
        FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
        [database open];
        
        NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET r_stars_%d = %d WHERE story_id = %d", game, stars, stage ];
        [database executeUpdate:updateQuery];
        [database close];
//    } else {
//        NSLog(@"New star is lower than the original");
//    }
}

- (void)ultraStarsWithoutSatety_stage:(int)stage game:(int)game stars:(int)stars {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    NSString *updateRQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET r_stars_%d = %d WHERE story_id = %d", game, stars, stage ];
    [database executeUpdate:updateRQuery];
    
    if (stars == 1 || stars == 2) {
        stars = 3;
    }
    
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage_stars_%d = %d WHERE story_id = %d", game, stars, stage ];
    [database executeUpdate:updateQuery];
    [database close];
}

- (void)ultraBeater {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage_stars_1 = %d, item_stage_stars_2 = %d, item_stage_stars_3 = %d, item_stage_stars_4 = %d, item_stage = %d", 5, 5, 5, 5, 1 ];
    
    [database executeUpdate:updateQuery];
    [database close];
}

- (void)setItem_starAndstage {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    int story_id, stars_1, stars_2, stars_3, stars_4;
    float stars_avg;
    NSString *sqlSelectQuery, *updateQuery;
    FMResultSet *resultsWithBaseData;
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    //stage 1
    story_id = 1;
    sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d", story_id];
    resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        stars_1 = [resultsWithBaseData intForColumn:@"item_stage_stars_1"];
        stars_2 = [resultsWithBaseData intForColumn:@"item_stage_stars_2"];
        stars_3 = [resultsWithBaseData intForColumn:@"item_stage_stars_3"];
        stars_4 = [resultsWithBaseData intForColumn:@"item_stage_stars_4"];
        stars_avg = (float)(stars_1 + stars_2 + stars_3 + stars_4) / 4;
    }
    if((int)stars_avg >= 3) {
        updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage = %d WHERE story_id = %d", 1, story_id];
        [database executeUpdate:updateQuery];
    }
    updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stars = %d WHERE story_id = %d", (int)stars_avg, story_id];
    [database executeUpdate:updateQuery];
    //stage 2
    story_id = 2;
    sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d", story_id];
    resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        stars_1 = [resultsWithBaseData intForColumn:@"item_stage_stars_1"];
        stars_2 = [resultsWithBaseData intForColumn:@"item_stage_stars_2"];
        stars_3 = [resultsWithBaseData intForColumn:@"item_stage_stars_3"];
        stars_4 = [resultsWithBaseData intForColumn:@"item_stage_stars_4"];
        stars_avg = (float)(stars_1 + stars_2 + stars_3 + stars_4) / 4;
    }
    if((int)stars_avg >= 3) {
        updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage = %d WHERE story_id = %d", 1, story_id];
        [database executeUpdate:updateQuery];
    }
    updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stars = %d WHERE story_id = %d", (int)stars_avg, story_id];
    [database executeUpdate:updateQuery];
    //stage 3
    story_id = 3;
    sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d", story_id];
    resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        stars_1 = [resultsWithBaseData intForColumn:@"item_stage_stars_1"];
        stars_2 = [resultsWithBaseData intForColumn:@"item_stage_stars_2"];
        stars_3 = [resultsWithBaseData intForColumn:@"item_stage_stars_3"];
        stars_4 = [resultsWithBaseData intForColumn:@"item_stage_stars_4"];
        stars_avg = (float)(stars_1 + stars_2 + stars_3 + stars_4) / 4;
    }
    if((int)stars_avg >= 3) {
        updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage = %d WHERE story_id = %d", 1, 3];
        [database executeUpdate:updateQuery];
    }
    updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stars = %d WHERE story_id = %d", (int)stars_avg, story_id];
    [database executeUpdate:updateQuery];
    //stage 4
    story_id = 4;
    sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d", story_id];
    resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        stars_1 = [resultsWithBaseData intForColumn:@"item_stage_stars_1"];
        stars_2 = [resultsWithBaseData intForColumn:@"item_stage_stars_2"];
        stars_3 = [resultsWithBaseData intForColumn:@"item_stage_stars_3"];
        stars_4 = [resultsWithBaseData intForColumn:@"item_stage_stars_4"];
        stars_avg = (float)(stars_1 + stars_2 + stars_3 + stars_4) / 4;
    }
    if((int)stars_avg >= 3) {
        updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage = %d WHERE story_id = %d", 1, story_id];
        [database executeUpdate:updateQuery];
    }
    updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stars = %d WHERE story_id = %d", (int)stars_avg, story_id];
    [database executeUpdate:updateQuery];
    //stage 5
    story_id = 5;
    sqlSelectQuery = [NSString stringWithFormat:@"SELECT * FROM ywca_game WHERE story_id = %d", story_id];
    resultsWithBaseData = [database executeQuery:sqlSelectQuery];
    while([resultsWithBaseData next]) {
        stars_1 = [resultsWithBaseData intForColumn:@"item_stage_stars_1"];
        stars_2 = [resultsWithBaseData intForColumn:@"item_stage_stars_2"];
        stars_3 = [resultsWithBaseData intForColumn:@"item_stage_stars_3"];
        stars_4 = [resultsWithBaseData intForColumn:@"item_stage_stars_4"];
        stars_avg = (float)(stars_1 + stars_2 + stars_3 + stars_4) / 4;
    }
    if((int)stars_avg >= 3) {
        updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stage = %d WHERE story_id = %d", 1, story_id];
        [database executeUpdate:updateQuery];
    }
    updateQuery = [NSString stringWithFormat:@"UPDATE ywca_game SET item_stars = %d WHERE story_id = %d", (int)stars_avg, story_id];
    [database executeUpdate:updateQuery];

    
    [database close];
}

- (void)clearRecord:(int)stage {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    NSString *deleteQuery = [NSString stringWithFormat: @"DELETE FROM ywca_game WHERE story_id=%d", stage];
    [database executeUpdate:deleteQuery];
    [database close];
}

- (BOOL)addCol:(NSString*)tbl_name col_name:(NSString*) col_name col_type:(NSString*)col_type {
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    BOOL added;
    
    if (tbl_name == nil) {
        tbl_name = @"ywca_game";
    }
    
    BOOL success;
    
    if (![database open])
    {
        NSLog(@"open failed");
        added = NO;
    }
    
    if (![database columnExists:col_name inTableWithName:[NSString stringWithFormat:@"%@", tbl_name]])
    {
        success = [database executeUpdate:[NSString stringWithFormat:@"ALTER TABLE %@ ADD COLUMN %@ %@", tbl_name, col_name, col_type]];
        NSAssert(success, @"alter table failed: %@", [database lastErrorMessage]);
        added = YES;
    } else {
        added = NO;
    }
    
    [database close];
    NSLog(added?@"added":@"not added");
    return added;
}

- (void)updateData:(NSString*)tbl_name col_name:(NSString*)col_name data_id:(int)data_id value:(long)value {
    
    // Getting the database path.
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"ywca.db"];
    NSString *id_name;
    BOOL db_error = NO;
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    if (tbl_name == nil) {
        tbl_name = @"ywca_game";
    }
    if ([tbl_name isEqualToString:@"ywca_game"]) {
        id_name = @"story_id";
    } else if ([tbl_name isEqualToString:@"ywca_setting"]) {
        id_name = @"setting_id";
    } else {
        db_error = YES;
        NSLog(@"db error occur");
    }
    
    if (db_error == NO) {
        NSString *updateQuery = [NSString stringWithFormat:@"UPDATE %@ SET %@ = %ld WHERE %@ = %d", tbl_name, col_name, value, id_name, data_id];
        [database executeUpdate:updateQuery];
    }
    [database close];

}

@end
