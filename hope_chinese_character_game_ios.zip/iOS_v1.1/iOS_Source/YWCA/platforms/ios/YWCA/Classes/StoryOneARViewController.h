//
//  ViewController.h
//  ywca
//
//  Created by Eric on 14/12/14.
//  Copyright (c) 2014 Eric. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MetaioSDK/MetaioSDKViewController.h>

#define FOLDER_PREFIX @"ARAssets/story1"
#define PATH_PREFIX @"s1_ar"
#define BLOCK_MAX_SCALE 6
#define OBJECT_1_SCALE 0.4
#define OBJECT_2_SCALE 4.0
#define OBJECT_3_SCALE 2.0

@interface StoryOneARViewController : MetaioSDKViewController
{
    metaio::IGeometry*      m_3dModel;            // pointer to the metaio man model
    metaio::IGeometry*       m_Image;            // pointer to the metaio man model
    metaio::IGeometry*       m_word;
    metaio::IGeometry*       m_block;
    
    __weak IBOutlet  UIImageView* imageViewObject1;
    __weak IBOutlet  UIImageView* imageViewObject2;
    __weak IBOutlet  UIImageView* imageViewObject3;
    
    __strong IBOutlet UIButton *btnBack;
    NSMutableArray *modelArray;
    NSMutableArray *wordArray;
    NSMutableArray *blockArray;
    
    int currentIndex;
    
    BOOL isMatchObject1;
    BOOL isMatchObject2;
    BOOL isMatchObject3;
    
    BOOL isStop;
    BOOL isWordStart;
    
    //NSString *pathPrefix;
    NSString* pathModel;
    NSString* imagePathWord;
    NSString* imagePathBlock;
    
    NSTimer*        wordTimer;
    NSTimer*        blockTimer;
    int             count;
}

@end

