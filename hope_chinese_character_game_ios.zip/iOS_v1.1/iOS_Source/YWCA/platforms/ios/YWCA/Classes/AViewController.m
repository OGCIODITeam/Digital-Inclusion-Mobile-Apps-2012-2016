//
//  AViewController.m
//  YWCA
//
//  Created by Benny SYW on 4/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//
#import "AppDelegate.h"
#import "AViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "AgreementViewController.h"
#import "StoryOneEcardViewController.h"
//#import "StoryTwoEcardViewController.h"
//#import "StoryThreeEcardViewController.h"
//#import "StoryFourEcardViewController.h"

#define IMAGE_COUNT 12

@interface AViewController () {
    NSMutableArray *images1, *images2, *images3, *images4;
    NSString *file, *file1, *file2, *file3, *file4;
    UIViewController *controller;
    int s;
    CABasicAnimation* rotationAnimation;
}

@end

@implementation AViewController

@synthesize char1, char2, char3, char4;

- (void)viewDidLoad {
    [super viewDidLoad];

    //characters' animation
    images1 = [[NSMutableArray alloc] initWithCapacity:IMAGE_COUNT];
    images2 = [[NSMutableArray alloc] initWithCapacity:IMAGE_COUNT];
    images3 = [[NSMutableArray alloc] initWithCapacity:IMAGE_COUNT];
    images4 = [[NSMutableArray alloc] initWithCapacity:IMAGE_COUNT];
    
    //file = [[NSBundle mainBundle] pathForResource:@"top_bg" ofType:@"png"];
    //self.bg.image = [UIImage imageWithContentsOfFile:file];
    self.bg.image = [UIImage imageNamed:@"top_bg"];
    //file = [[NSBundle mainBundle] pathForResource:@"logo_hope" ofType:@"png"];
    //self.gameTitle.image = [UIImage imageWithContentsOfFile:file];
    self.gameTitle.image = [UIImage imageNamed:@"logo_hope"];
    //file = [[NSBundle mainBundle] pathForResource:@"logo_ywca" ofType:@"png"];
    //self.logo.image = [UIImage imageWithContentsOfFile:file];
    self.logo.image = [UIImage imageNamed:@"logo_ywca"];
    //file = [[NSBundle mainBundle] pathForResource:@"btn_02" ofType:@"png"];
    //[self.startbtn setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.startbtn setImage:[UIImage imageNamed:@"btn_02"] forState:UIControlStateNormal];
    /*
    file = [[NSBundle mainBundle] pathForResource:@"top_char1_frame_1" ofType:@"png"];
    self.char1.image = [UIImage imageNamed:file];
    file = [[NSBundle mainBundle] pathForResource:@"top_char2_frame_1" ofType:@"png"];
    self.char2.image = [UIImage imageNamed:file];
    file = [[NSBundle mainBundle] pathForResource:@"top_char3_frame_1" ofType:@"png"];
    self.char3.image = [UIImage imageNamed:file];
    file = [[NSBundle mainBundle] pathForResource:@"top_char4_frame_1" ofType:@"png"];
    self.char4.image = [UIImage imageNamed:file];
     */
    
    for (s=0; s<IMAGE_COUNT; s++) {
        [images1 addObject:[UIImage imageNamed:[NSString stringWithFormat:@"top_char1_frame_%d.png", s]]];
        [images2 addObject:[UIImage imageNamed:[NSString stringWithFormat:@"top_char2_frame_%d.png", s]]];
        [images3 addObject:[UIImage imageNamed:[NSString stringWithFormat:@"top_char3_frame_%d.png", s]]];
        [images4 addObject:[UIImage imageNamed:[NSString stringWithFormat:@"top_char4_frame_%d.png", s]]];
        /*
        file1 = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"top_char1_frame_%d", s] ofType:@"png"];
        file2 = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"top_char2_frame_%d", s] ofType:@"png"];
        file3 = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"top_char3_frame_%d", s] ofType:@"png"];
        file4 = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"top_char4_frame_%d", s] ofType:@"png"];
         */
        /*
        [images1 addObject:[UIImage imageWithContentsOfFile:file1]];
        [images2 addObject:[UIImage imageWithContentsOfFile:file2]];
        [images3 addObject:[UIImage imageWithContentsOfFile:file3]];
        [images4 addObject:[UIImage imageWithContentsOfFile:file4]];
         */
        /*
        [images1 addObject:[UIImage imageNamed:file1]];
        [images2 addObject:[UIImage imageNamed:file2]];
        [images3 addObject:[UIImage imageNamed:file3]];
        [images4 addObject:[UIImage imageNamed:file4]];
         */
    }
    char1.animationImages = [NSArray arrayWithArray:images3];
    char2.animationImages = [NSArray arrayWithArray:images2];
    char3.animationImages = [NSArray arrayWithArray:images1];
    char4.animationImages = [NSArray arrayWithArray:images4];
    char1.animationDuration = 1;
    char2.animationDuration = 1;
    char3.animationDuration = 1;
    char4.animationDuration = 1;
    [char1 startAnimating];
    [char2 startAnimating];
    [char3 startAnimating];
    [char4 startAnimating];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated {
    //[self.view removeFromSuperview];
    /*
    self.char1.image = nil;
    self.char2.image = nil;
    self.char3.image = nil;
    self.char4.image = nil;
    self.bg.image = nil;
    self.logo.image = nil;
    self.gameTitle.image = nil;
    self.startbtn.imageView.image = nil;
    images1 = nil;
    images2 = nil;
    images3 = nil;
    images4 = nil;
    file = nil;
    file1 = nil;
    file2 = nil;
    file3 = nil;
    file4 = nil;
    controller = nil;
    rotationAnimation = nil;
     */
    [self.char1.layer removeAllAnimations];
    [self.char2.layer removeAllAnimations];
    [self.char3.layer removeAllAnimations];
    [self.char4.layer removeAllAnimations];
    self.char1 = nil;
    self.char2 = nil;
    self.char3 = nil;
    self.char4 = nil;
    self.bg = nil;
    self.logo = nil;
    self.gameTitle = nil;
    self.startbtn = nil;
    images1 = nil;
    images2 = nil;
    images3 = nil;
    images4 = nil;
    file = nil;
    file1 = nil;
    file2 = nil;
    file3 = nil;
    file4 = nil;
    controller = nil;
    rotationAnimation = nil;
}

- (void) runSpinAnimationOnView:(UIView*)view duration:(CGFloat)duration rotations:(CGFloat)rotations repeat:(float)repeat;
{
    rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat: M_PI * 2.0 /* full rotation*/ * rotations * duration ];
    rotationAnimation.duration = duration;
    rotationAnimation.cumulative = YES;
    rotationAnimation.repeatCount = repeat;
    
    [self.char1.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
    [self.char2.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
    [self.char3.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
    [self.char4.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)startBtn:(id)sender {
    controller = [self.storyboard instantiateViewControllerWithIdentifier:@"mainview"]; //StoryTwoAR mainview
    [self presentViewController:controller animated:YES completion:nil];
    //StoryTwoEcardViewController *ecardVC = [[StoryTwoEcardViewController alloc] initWithNibName:@"StoryTwoEcardView" bundle:[NSBundle mainBundle]];
    //[self presentViewController:ecardVC animated:YES completion:nil];
}
@end
