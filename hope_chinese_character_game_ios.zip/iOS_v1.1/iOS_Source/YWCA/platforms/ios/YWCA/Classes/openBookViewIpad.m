//
//  openBookViewIpad.m
//  YWCA
//
//  Created by Marshals Chan on 12/2/15.
//
//

#import "openBookViewIpad.h"
#import "UIHelper.h"

@implementation openBookViewIpad{
    NSArray* starArray;
    float targetWidth;
}

@synthesize imgComplete, imgStar1, imgStar2, imgStar3,imgStar4, imgStar5, btnBook, lblStageTitle;
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    //[self initViews:1 noOfStar:5 completed:YES];
    targetWidth = [[UIScreen mainScreen] bounds].size.width*0.35;
    return self;
}


-(void)initViewsWithState:(int)state noOfStar:(int)star completed:(BOOL)completed{
    int paddingX = targetWidth*0.2;
    int paddingY = targetWidth*0.01;
    int starW = targetWidth * 0.06;
    int starH = targetWidth * 0.06;

    
    imgStar1 = [[UIImageView alloc]initWithFrame:CGRectMake(paddingX, paddingY, starW, starH)];paddingX = paddingX + starW;
    imgStar2 = [[UIImageView alloc]initWithFrame:CGRectMake(paddingX, paddingY, starW, starH)];paddingX = paddingX + starW;
    imgStar3 = [[UIImageView alloc]initWithFrame:CGRectMake(paddingX, paddingY, starW, starH)];paddingX = paddingX + starW;
    imgStar4 = [[UIImageView alloc]initWithFrame:CGRectMake(paddingX, paddingY, starW, starH)];paddingX = paddingX + starW;
    imgStar5 = [[UIImageView alloc]initWithFrame:CGRectMake(paddingX, paddingY, starW, starH)];
    
    starArray = [[NSArray alloc]initWithObjects:imgStar1, imgStar2, imgStar3, imgStar4, imgStar5, nil];
    [self initTitle:state];
    [self setStars:star];
    [self setComplete:completed];
}

-(void)initTitle:(int)stage{
    
    float width = self.frame.size.width;
    float height = self.frame.size.height;
    float titlePaddingX = targetWidth * 0.2;
    float titlePaddingY =targetWidth * 0.07;
    
    //bg
    NSString* imgName =  [NSString stringWithFormat:@"btn_book_open_%d", stage];
    UIImage* img = [UIImage imageNamed:imgName];
    btnBook = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, width, height)];
    [btnBook setImage:img forState:UIControlStateNormal];
    [self addSubview:btnBook];
    NSLog(@"btnBook: %@", btnBook);
    
    //title
    lblStageTitle = [[UILabel alloc]initWithFrame: CGRectMake(titlePaddingX, titlePaddingY, width, 50)];
    NSString* titleName =[NSString stringWithFormat:@"titleStage%d", stage];
    NSLog(@"frame: %@", lblStageTitle);
    lblStageTitle.text = NSLocalizedString(titleName, nil);
    lblStageTitle.font = [UIFont systemFontOfSize:26];
    lblStageTitle.textColor = [UIColor whiteColor];
    [self addSubview:lblStageTitle];
}

-(void)setComplete:(BOOL)isComplete {
    float width = targetWidth*0.2;
    if(isComplete){
        UIImage* image =[UIImage imageNamed:@"main_done.png"];
        imgComplete = [[UIImageView alloc]initWithFrame: CGRectMake(0 , 0, width, width/image.size.width*image.size.height)];
        imgComplete.image = image;
        [self addSubview:imgComplete];
        
    }else{
        if(imgComplete){
            [imgComplete removeFromSuperview];
        }
    }
}

-(void)setStars:(int)mark{
    
    UIImage* imgLightStar =  [UIImage imageNamed:@"star_on.png"];
    UIImage* imgDarkStar = [UIHelper imageWithImage:[UIImage imageNamed:@"star_off.png"] scaledToSize:CGSizeMake(10, 20)];
    for(int i=0; i<starArray.count; i++){
        UIImageView * imgView =  [starArray objectAtIndex:i];
        NSLog(@"star: %@", imgView);
        if(i<mark){
            imgView.image = imgLightStar;
        }else{
            imgView.image = imgDarkStar;
        }
        [self addSubview:imgView];
    }
}

@end
