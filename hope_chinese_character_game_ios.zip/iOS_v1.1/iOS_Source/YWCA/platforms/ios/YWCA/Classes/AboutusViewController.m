//
//  AboutusViewController.m
//  YWCA
//
//  Created by Benny SYW on 10/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "AboutusViewController.h"
#import "AppDelegate.h"
#import "AgreementReadOnlyViewController.h"
//#import "GuideViewController.h"

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

@interface AboutusViewController () {
    NSString *file;
    NSURL *url;
}

@property (nonatomic, strong) AVAudioPlayer *bgmPlayer;

@end

@implementation AboutusViewController
@synthesize bgmPlayer = mBgmPlayer;
@synthesize bgm_off = mBgm_off;
@synthesize bgm_on = mBgm_on;

- (void)viewDidLoad {
    [super viewDidLoad];
    [_uiWebView setDelegate:self];
    // Do any additional setup after loading the view.
    
    //music
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSString *indexMusic;
    indexMusic = [appDelegate getMusic];
    if([indexMusic  isEqual: @"1"]) {
        [appDelegate playBgMusic];
        mBgm_off.hidden = YES;
        mBgm_on.hidden = NO;
    } else {
        mBgm_off.hidden = NO;
        mBgm_on.hidden = YES;
    }   
    
    //webview
    if (IS_IPAD) {
        url = [[NSBundle mainBundle] URLForResource:@"aboutus_iPad" withExtension:@"html"];
    } else {
        url = [[NSBundle mainBundle] URLForResource:@"aboutus" withExtension:@"html"];
    }
    self.uiWebView.backgroundColor = [UIColor clearColor];
    [self.uiWebView setOpaque:NO];
    NSURLRequest* request = [NSURLRequest requestWithURL:url];
    [_uiWebView loadRequest:request];
    self.uiWebView.scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    
}

- (void)viewDidAppear:(BOOL)animated {
    file = @"btn_bgm";
    [self.bgm_on setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_bgm_off";
    [self.bgm_off setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_back";
    [self.backbtn setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"bg_content_04";
    self.bg.image = [UIImage imageNamed:file];
}

- (void)viewDidDisappear:(BOOL)animated {
    [self.uiWebView stopLoading];
    [self.uiWebView setDelegate:nil];
    self.uiWebView = nil;
    
    self.bgm_on = nil;
    self.bgm_off = nil;
    self.backbtn = nil;
    self.bg = nil;
    self.lblTitle = nil;
    file = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



//Aboutus
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request
 navigationType:(UIWebViewNavigationType)navigationType {
    /*
    NSString* scheme = [[request URL] scheme];
    if ([@"contact" isEqual:scheme]) {
        UIViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"contact"];
        [self.navigationController pushViewController:controller animated:YES];
        return NO;
    }else if ([@"agree" isEqual:scheme]){
        UIViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"agreeview"];
        [self.navigationController pushViewController:controller animated:YES];
        
        return NO;
    }
    else {
        return YES;
    }
    */
    /*
    NSLog(@"%@", [request URL] );
    NSString* scheme = [[request URL] scheme];
    if ([@"contact" isEqual:scheme]) {
        NSLog(@"push page contact");
        //AgreementReadOnlyViewController *Acontroller=[[AgreementReadOnlyViewController alloc] initWithNibName:@"AgreementReadOnlyViewController" bundle:nil];
        //UIViewController *Acontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"contact"];
        //[self popToSpecificViewController:Acontroller];
        //[self.navigationController pushViewController:Acontroller animated:YES];
        return NO;
    }else if ([@"agree" isEqual:scheme]){
        NSLog(@"push page agree read only");
        UIViewController *Bcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"agreement"];
        [self.navigationController pushViewController:Bcontroller animated:YES];
        
        return NO;
    }
    else {
        return YES;
    }
    */
    //NSLog(@"%@", [request URL] );
    NSURL* url = [request URL];
    NSString* scheme = [url scheme];
    NSString* host = [url host];
    //NSString* path = [url path];
    //NSString* query = [url query];
    /*
    NSLog(@"url recieved: %@", url);
    NSLog(@"url scheme: %@", [url scheme]);
    NSLog(@"query string: %@", [url query]);
    NSLog(@"host: %@", [url host]);
    NSLog(@"url path: %@", [url path]);
     */
    if ([@"ywca" isEqual:scheme] && [@"contact" isEqual:host]) {
        //NSLog(@"push page contact");
        //to navigate view indepently
        UIViewController *Acontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"contact"];
        [self presentViewController:Acontroller animated:YES completion:nil];
        return NO;
    }else if ([@"ywca" isEqual:scheme] && [@"agree" isEqual:host]){
        //NSLog(@"push page agree read only");
        UIViewController *Bcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"agree"];
        [self presentViewController:Bcontroller animated:YES completion:nil];
        //[self.navigationController pushViewController:Bcontroller animated:YES];
        
        return NO;
    }
    else {
        return YES;
    }
}
/*
- (void) ReturnToSpecificViewController{
    
    for (UIViewController *controller in self.navigationController.viewControllers) {
        if ([controller isKindOfClass:[AgreementReadOnlyViewController class]]) {
            //Do not forget to import AnOldViewController.h
            
            [self.navigationController pushViewController:controller
                                                  animated:YES];
            break;
        }
    }
}


-(void)popToSpecificViewController:(UIViewController *)controller
{
    NSMutableArray *mutableVCArray = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [mutableVCArray insertObject:controller atIndex:mutableVCArray.count-1];
    [self.navigationController setViewControllers:mutableVCArray animated:NO];
    [self.navigationController popViewControllerAnimated:YES];
}
*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back:(id)sender {
}

- (IBAction)bgm_off:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate playBgMusic];
    mBgm_off.hidden = YES;
    mBgm_on.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:1];
}

- (IBAction)bgm_on:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate stopBgMusic];
    mBgm_on.hidden = YES;
    mBgm_off.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:0];
}

@end
