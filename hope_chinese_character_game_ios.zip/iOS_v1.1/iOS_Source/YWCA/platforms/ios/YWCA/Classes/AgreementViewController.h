//
//  AgreementViewController.h
//  YWCA
//
//  Created by Marshals Chan on 15/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface AgreementViewController : UIViewController<UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *uiWebView;

@property (weak, nonatomic) IBOutlet UIButton *bgm_off;
@property (weak, nonatomic) IBOutlet UIButton *bgm_on;
@property (weak, nonatomic) IBOutlet UIButton *back;

@property (weak, nonatomic) IBOutlet UIImageView *imgBg;
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;

- (IBAction)back:(id)sender;
- (IBAction)bgm_off:(id)sender;
- (IBAction)bgm_on:(id)sender;

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;

@end

