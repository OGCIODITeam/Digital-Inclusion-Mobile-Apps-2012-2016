//
//  stage2_1.m
//  YWCA
//
//  Created by Benny SYW on 21/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "Game.h"
#import "GameViewController.h"
#import "AppDelegate.h"

@interface Game () {
    NSString *wwwPath;
    int firstTime, sound, music;
    int quit_stage;
}

@end

@implementation Game

@synthesize stage;
@synthesize game;
@synthesize webView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"stage: %d, game: %d", stage, game);
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    firstTime = [appDelegate getFirstEnter:stage game:game];
    sound = [appDelegate getSoundInt];
    music = [appDelegate getMusicInt];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    //NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    
    NSLog(@"first: %d", firstTime);
    //TODO:change path
    NSString *folderName = [NSString stringWithFormat:@"%@/stage%d/game%d/index.html", documentsPath, stage, game];
    NSLog(@"folderName=%@", folderName);
    
    NSString *localURL = folderName; //[NSBundle pathForResource:@"index" ofType:@"html" inDirectory:folderName];
    NSLog(@"localURL=%@", localURL);
    /*
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:localURL]];
    //NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.kanhan.com"]];
    [webView loadRequest:urlRequest];
    */
    //NSURL *url = [NSURL fileURLWithPath:[[paths objectAtIndex:0] pathForResource:@"index" ofType:@"html" inDirectory:[NSString stringWithFormat:@"/stage%d/game%d/",stage,game]]];
    NSURL *url = [NSURL URLWithString:localURL];
    NSLog(@"url: %@",url);
    NSString *URLString = [url absoluteString];
    NSString *queryString = [NSString stringWithFormat:@"#firstTime=%d,iosSound=%d,iosMusic=%d",firstTime,sound,music];
    NSString *URLwithQueryString = [URLString stringByAppendingString: queryString];
    
    NSURL *finalURL = [NSURL URLWithString:URLwithQueryString];
    
    //finalURL = [NSURL URLWithString:@"http://www.gaplo.net/YWCA/stage1/game1"];
    [appDelegate stopBgMusic];
    NSURLRequest *request = [NSURLRequest requestWithURL:finalURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:(NSTimeInterval)10.0 ];
    
    [webView loadRequest:request];
    
    [appDelegate stopBgMusic];
}

-(void)viewDidAppear:(BOOL)animated
{
    [webView setFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)muteNativeMusic {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate stopBgMusic];
}

- (void)resetWebview {
    NSURL *blankURL = [NSURL URLWithString:@"about://blank"];
    NSURLRequest *request = [NSURLRequest requestWithURL:blankURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:(NSTimeInterval)10.0 ];
    [webView loadRequest:request];
}

- (BOOL)webView:(UIWebView *)_webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSLog(@"Loading URL :%@",request.URL.absoluteString);
    //quit
    for (int b=1; b<=5; b++) {
        if ([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:[NSString stringWithFormat:@"quits%d",b]]) {
            [webView removeFromSuperview];
            
            [self resetWebview];
            GameViewController *GameController = [self.storyboard instantiateViewControllerWithIdentifier:@"game"];
            quit_stage = b;
            GameController.quit_stage = quit_stage;
            [self presentViewController:GameController animated:YES completion:nil];
            
            return FALSE;
        }
    }
    //next game
    for (int b=1; b<=5; b++) {
        for (int s=1; s<=3; s++) {
            if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:[NSString stringWithFormat:@"s%dg%dnext",b,s]]) {
                [webView removeFromSuperview];
                [self muteNativeMusic];
                [self resetWebview];
                Game *reload = [self.storyboard instantiateViewControllerWithIdentifier:@"play"];
                reload.stage = b;
                reload.game = s+1;
                GameViewController *gameview = [self.storyboard instantiateViewControllerWithIdentifier:@"game"];
                gameview.quit_stage = b;
                gameview.quit_lose = 1;
                if ([appDelegate getStarsInt:b game:s] > 2) {
                    [self presentViewController:reload animated:YES completion:nil];
                } else {
                    [self presentViewController:gameview animated:YES completion:nil];
                }
                
                return FALSE;
            }
        }
    }
    for (int b=1; b<=5; b++) {
        NSString *AR_path;
        if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:[NSString stringWithFormat:@"story%d_game5",b]]) {
            [self resetWebview];
            [webView removeFromSuperview];
            switch (b) {
                case 1:
                    AR_path = @"StoryOneAR";
                    break;
                case 2:
                    AR_path = @"StoryTwoAR";
                    break;
                case 3:
                    AR_path = @"StoryThreeAR";
                    break;
                case 4:
                    AR_path = @"StoryFourAR";
                    break;
                case 5:
                    AR_path = @"game";
                    break;
                default:
                    AR_path = @"StoryOneAR";
                    break;
            }
            UIViewController *ARone = [self.storyboard instantiateViewControllerWithIdentifier:AR_path];
            [self presentViewController:ARone animated:YES completion:nil];
        }
    }
    //Sound
        //on
    if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:@"music_on"]) {
        [appDelegate updateSetting:@"item_music" mode:1];
        //off
    } else if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:@"music_off"]) {
        [appDelegate updateSetting:@"item_music" mode:0];
    }
    
    //Music
        //on
    if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:@"sound_on"]) {
        [appDelegate updateSetting:@"item_sound" mode:1];
        //off
    } else if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:@"sound_off"]) {
        [appDelegate updateSetting:@"item_sound" mode:0];
    }
    //First Time (before game comic)
    for (int b=1; b<=5; b++) {
        for (int s=1; s<=4; s++) {
            if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:[NSString stringWithFormat:@"s%dg%dfirstTimed",b,s]]) {
                [appDelegate ultraEnter_stage:b game:s enter:1];
            }
        }
    }
    //First Time (after game comic)
    for (int b=1; b<=5; b++) {
        for (int s=1; s<=4; s++) {
            if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:[NSString stringWithFormat:@"s%dg%dfirstTimed2",b,s]]) {
                [appDelegate ultraEnter_stage:b game:s enter:2];
            }
        }
    }
    //Stars
    for (int s=1; s<=5; s++) {
        for (int y=1; y<=4; y++) {
            for (int w=1; w<=5; w++) {
                if([request.URL.scheme isEqualToString:@"game"] && [request.URL.host isEqualToString:[NSString stringWithFormat:@"story%d_game%d_star%d",s,y,w]]) {
                    [appDelegate ultraStars_stage:s game:y stars:w];
                }
            }
        }
    }
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidStartLoad");
}


- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidFinishLoad");
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"Failed to load with error :%@",[error debugDescription]);
    
}

@end
