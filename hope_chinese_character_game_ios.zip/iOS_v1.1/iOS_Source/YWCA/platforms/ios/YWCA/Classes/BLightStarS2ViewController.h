//
//  BLightStarS2ViewController.h
//  YWCA
//
//  Created by Benny SYW on 25/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLightStarS2ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *S1;
@property (strong, nonatomic) IBOutlet UIImageView *S2;
@property (strong, nonatomic) IBOutlet UIImageView *S3;
@property (strong, nonatomic) IBOutlet UIImageView *S4;
@property (strong, nonatomic) IBOutlet UIImageView *S5;

@end
