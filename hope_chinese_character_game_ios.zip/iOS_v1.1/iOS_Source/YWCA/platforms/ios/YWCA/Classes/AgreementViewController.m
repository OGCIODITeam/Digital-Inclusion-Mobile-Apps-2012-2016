//
//  AgreementViewController.m
//  YWCA
//
//  Created by Marshals Chan on 15/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "AgreementViewController.h"
#import "AppDelegate.h"
//#import "DBManager.h"

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

@interface AgreementViewController () {
    NSString *file;
    NSURL *url;
}

@property (nonatomic, strong) AVAudioPlayer *bgmPlayer;

//@property (nonatomic, strong) DBManager *dbManager;

@end

@implementation AgreementViewController
@synthesize bgmPlayer = mBgmPlayer;
@synthesize bgm_off = mBgm_off;
@synthesize bgm_on = mBgm_on;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
//    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"ywca.sql"];
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    NSString *indexMusic;
    int music_value;
    indexMusic = [appDelegate getMusic];
    music_value = [indexMusic intValue];
    
    [_uiWebView setDelegate:self];
    
    //indexMusic = [appDelegate loadData:1];
    
    if (music_value == 1) {
        [appDelegate playBgMusic];
        mBgm_off.hidden = YES;
        mBgm_on.hidden = NO;
    } else if (music_value == 0) {
        mBgm_off.hidden = NO;
        mBgm_on.hidden = YES;
    }
    //mBgm_on.hidden = ![appDelegate isPlayerStop];
    //mBgm_off.hidden = [appDelegate isPlayerStop];
    
    /*
    if([appDelegate isPlayerStop]) {
        mBgm_off.hidden = YES;
        mBgm_on.hidden = NO;
    } else {
        mBgm_on.hidden = YES;
        mBgm_off.hidden = NO;
    }
    */
   
    //get local html file and display
    
    /*
    //Original call html
    //webview
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"aboutus" withExtension:@"html"];
    //NSString *template = [NSString stringWithContentsOfFile:[url path] encoding:NSUTF8StringEncoding error:nil];
    //NSMutableString *html = [NSMutableString stringWithString:template];
    
    //[self.uiWebView  loadHTMLString:html baseURL:[url URLByDeletingLastPathComponent]];
    self.uiWebView.backgroundColor = [UIColor clearColor];
    [self.uiWebView setOpaque:NO];
    [[self.uiWebView.subviews objectAtIndex:0] setBounces:NO];
    
    self.uiWebView.scalesPageToFit = YES;
    //self.uiWebView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    
    self.uiWebView.scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
     
     NSURLRequest* request = [NSURLRequest requestWithURL:url];
     [_uiWebView loadRequest:request];
    */
    if (IS_IPAD) {
        url = [[NSBundle mainBundle] URLForResource:@"userule_withCkbox_iPad" withExtension:@"html"];
    } else {
        url = [[NSBundle mainBundle] URLForResource:@"userule_withCkbox" withExtension:@"html"];
    }
    self.uiWebView.backgroundColor = [UIColor clearColor];
   [self.uiWebView setOpaque:NO];
    NSURLRequest* request = [NSURLRequest requestWithURL:url];
    [_uiWebView loadRequest:request];
    self.uiWebView.scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    self.back.hidden = YES;
    
//    NSString *check_value;
//    check_value = [appDelegate getAgreeCheck];
//    if([check_value isEqual:@"1"]) {
//        UIViewController *ckcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"start"];
//        [self.navigationController pushViewController:ckcontroller animated:YES];
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    file = [[NSBundle mainBundle] pathForResource:@"bg_content_01" ofType:@"png"];
    self.imgBg.image = [UIImage imageWithContentsOfFile:file];
    file = [[NSBundle mainBundle] pathForResource:@"btn_bgm" ofType:@"png"];
    [self.bgm_on setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    file = [[NSBundle mainBundle] pathForResource:@"btn_bgm_off" ofType:@"png"];
    [self.bgm_off setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    file = [[NSBundle mainBundle] pathForResource:@"btn_back" ofType:@"png"];
    [self.back setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self.uiWebView stopLoading];
    [self.uiWebView setDelegate:nil];
    self.uiWebView = nil;
    
    file = nil;
    self.lblTitle = nil;
    self.imgBg.image = nil;
    [self.bgm_on setImage:nil forState:UIControlStateNormal];
    [self.bgm_off setImage:nil forState:UIControlStateNormal];
    [self.back setImage:nil forState:UIControlStateNormal];
}

- (IBAction)back:(id)sender {
}
//mode 1=music on, 0=music off
- (IBAction)bgm_off:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate playBgMusic];
    mBgm_off.hidden = YES;
    mBgm_on.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:1];
}

- (IBAction)bgm_on:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate stopBgMusic];
    mBgm_on.hidden = YES;
    mBgm_off.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:0];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request
 navigationType:(UIWebViewNavigationType)navigationType {
    
    //NSLog(@"%@", [request URL] );
    NSURL* url = [request URL];
    NSString* scheme = [url scheme];
    NSString* host = [url host];
    if ([@"ywca" isEqual:scheme] && [@"pushagreementchecked" isEqual:host]) {
        //NSLog(@"push page checked call");
        [self saveChecked];
        //go back to first page
        //[self.navigationController popToRootViewControllerAnimated:YES];
        UIViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"start"];
        [self.navigationController pushViewController:controller animated:YES];
        return NO;
    }else if ([@"ywca" isEqual:scheme] && [@"pushagreementunchecked" isEqual:host]){
        //NSLog(@"push page un - checked call");
        UIViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"start"];
        [self.navigationController pushViewController:controller animated:YES];
        
        return NO;
    }
    else {
        return YES;
    }
}

-(void)saveChecked{
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate updateSetting:@"item_agreehide" mode:1];
}

@end