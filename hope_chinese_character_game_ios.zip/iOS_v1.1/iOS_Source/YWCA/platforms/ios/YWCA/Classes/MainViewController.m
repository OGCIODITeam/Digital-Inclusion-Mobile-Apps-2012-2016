//
//  MainViewController.m
//  YWCA
//
//  Created by Benny SYW on 4/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "MainViewController.h"
#import "AppDelegate.h"
#import "GameViewController.h"
#import "Constants.h"

@interface MainViewController () {
    NSString *appStatus, *file;
}

@property (nonatomic, strong) AVAudioPlayer *bgmPlayer;

@end


@implementation MainViewController
@synthesize bgmPlayer = mBgmPlayer;
@synthesize bgm_off = mBgm_off;
@synthesize bgm_on = mBgm_on;

- (void)viewDidLoad {
    [super viewDidLoad];
    //if music setting on
    //   musicIcon hide
    //   mute icon show
    // else
    // ;
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    NSString *indexMusic;
    int music_value;
    indexMusic = [appDelegate getMusic];
    music_value = [indexMusic intValue];
    if(music_value == 1) {
        [appDelegate playBgMusic];
        mBgm_off.hidden = YES;
        mBgm_on.hidden = NO;
    } else {
        mBgm_off.hidden = NO;
        mBgm_on.hidden = YES;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(voiceOverStatusChanged)
                                                 name:UIAccessibilityVoiceOverStatusChanged
                                               object:nil];
    
    // Do any additional setup after loading the view.
    
    //code for test
    /*
    [appDelegate ultraBeater];
    [appDelegate setARfinish:1 finish:1];
    [appDelegate setARfinish:2 finish:1];
    [appDelegate setARfinish:3 finish:1];
    [appDelegate setARfinish:4 finish:1];
    */
    
    //[appDelegate setARfinish:1 finish:1];
    //[appDelegate setARfinish:2 finish:1];
    /*
    [appDelegate ultraStars_stage:1 game:1 stars:3];
    [appDelegate ultraStars_stage:1 game:2 stars:3];
    [appDelegate ultraStars_stage:1 game:3 stars:3];
    [appDelegate ultraStars_stage:1 game:4 stars:0];
    */
    
    //[appDelegate ultraStarsWithoutSatety_stage:1 game:1 stars:3];
    //[appDelegate ultraStarsWithoutSatety_stage:1 game:2 stars:3];
    //[appDelegate ultraStarsWithoutSatety_stage:1 game:3 stars:3];
    //[appDelegate ultraStarsWithoutSatety_stage:1 game:4 stars:3];
    /*
    [appDelegate setARfinish:2 finish:1];
    
    [appDelegate ultraStarsWithoutSatety_stage:2 game:1 stars:4];
    [appDelegate ultraStarsWithoutSatety_stage:2 game:2 stars:4];
    [appDelegate ultraStarsWithoutSatety_stage:2 game:3 stars:4];
    
    [appDelegate ultraStarsWithoutSatety_stage:2 game:4 stars:4];
    
    [appDelegate ultraStarsWithoutSatety_stage:3 game:1 stars:3];
    [appDelegate ultraStarsWithoutSatety_stage:3 game:2 stars:3];
    [appDelegate ultraStarsWithoutSatety_stage:3 game:3 stars:3];
    
    [appDelegate ultraStarsWithoutSatety_stage:3 game:4 stars:3];
    
    [appDelegate ultraStarsWithoutSatety_stage:4 game:1 stars:3];
    [appDelegate ultraStarsWithoutSatety_stage:4 game:2 stars:4];
    [appDelegate ultraStarsWithoutSatety_stage:4 game:3 stars:4];
    [appDelegate ultraStarsWithoutSatety_stage:4 game:4 stars:3];
    
    [appDelegate ultraStarsWithoutSatety_stage:5 game:1 stars:5];
    [appDelegate ultraStarsWithoutSatety_stage:5 game:2 stars:2];
    [appDelegate ultraStarsWithoutSatety_stage:5 game:3 stars:5];
    [appDelegate ultraStarsWithoutSatety_stage:5 game:4 stars:2];
    */

    [appDelegate getAllGameData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    file = @"logo_hope";
    //self.gameTitle.image = [UIImage imageWithContentsOfFile:file];
    self.gameTitle.image = [UIImage imageNamed:file];
    file = @"btn_menu01";
    //[self.action01 setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.action01 setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_menu02";
    //[self.action02 setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.action02 setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_menu03";
    //[self.action03 setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.action03 setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_menu04";
    //[self.action04 setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.action04 setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_bgm";
    //[self.bgm_on setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.bgm_on setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_bgm_off";
    //[self.bgm_off setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.bgm_off setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_back";
    //[self.back setImage:[UIImage imageWithContentsOfFile:file] forState:UIControlStateNormal];
    [self.back setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"top_bg";
    //self.imgbg.image = [UIImage imageWithContentsOfFile:file];
    self.imgbg.image = [UIImage imageNamed:file];
}

- (void)viewWillDisappear:(BOOL)animated {
    /*
    self.gameTitle.image = nil;
    [self.action01 setImage:nil forState:UIControlStateNormal];
    [self.action02 setImage:nil forState:UIControlStateNormal];
    [self.action03 setImage:nil forState:UIControlStateNormal];
    [self.action04 setImage:nil forState:UIControlStateNormal];
    [self.bgm_on setImage:nil forState:UIControlStateNormal];
    [self.bgm_off setImage:nil forState:UIControlStateNormal];
    [self.back setImage:nil forState:UIControlStateNormal];
    self.imgbg.image = nil;
    self.shadow = nil;
     */
    self.gameTitle = nil;
    self.action01 = nil;
    self.action02 = nil;
    self.action03 = nil;
    self.action04 = nil;
    self.bgm_on = nil;
    self.bgm_off = nil;
    self.imgbg = nil;
    self.shadow = nil;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back:(id)sender {
    /*
    if(self.navigationController ==nil){
        NSLog(@" nav is null");
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
     */
}
//mode 0=music off, 1=music on
- (IBAction)bgm_off:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate playBgMusic];
    mBgm_off.hidden = YES;
    mBgm_on.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:1];
}

- (IBAction)bgm_on:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate stopBgMusic];
    mBgm_on.hidden = YES;
    mBgm_off.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:0];
}

- (IBAction)action01:(id)sender {
}

- (IBAction)action02:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url_youtube]];
    NSLog(@"youtube url:%@", url_youtube);
}

- (IBAction)action03:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate setItem_starAndstage];
    
    //Reachability framework
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNetworkChange:) name:kReachabilityChangedNotification object:nil];
    
    reachability = [Reachability reachabilityForInternetConnection];
    [reachability startNotifier];
    
    NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
    
    if(remoteHostStatus == NotReachable) {
        NSLog(@"no internet connection");
        //[self networkAlert:@"無網絡"];
        appStatus = @"noCon";
    }
    else if (remoteHostStatus == ReachableViaWiFi) {
        NSLog(@"Wifi connection");
        //[self networkAlert:@"正使用Wifi網絡"];
        appStatus = @"wifiCon";
    }
    else if (remoteHostStatus == ReachableViaWWAN) {
        NSLog(@"3G or 4G connection");
        //[self networkAlert:@"正使用數據網絡"];
        appStatus = @"dataCon";
    }
    
    if (UIAccessibilityIsVoiceOverRunning() == YES) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"將進入VoiceOver不支援頁面"
                                                   message: @"是否繼續?"
                                                  delegate: self
                                         cancelButtonTitle:@"否"
                                         otherButtonTitles: @"是", nil];
        [alert show];
    } else {
        [self performSegueWithIdentifier:@"toGameMain" sender:(id)sender];
        //GameViewController *gameController = [self.storyboard instantiateViewControllerWithIdentifier:@"game"];
        //[self.navigationController pushViewController:gameController animated:YES];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        NSLog(@"Cancel action");
    }
    else {
        NSLog(@"GO action");
        [self performSegueWithIdentifier:@"toGameMain" sender:nil];
        //GameViewController *gameController = [self.storyboard instantiateViewControllerWithIdentifier:@"game"];
        //[self.navigationController pushViewController:gameController animated:YES];
    }
}

- (IBAction)action04:(id)sender {
}

- (void)networkAlert:(NSString*)msg {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"網絡狀態"
                                                   message: msg
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
}

- (void) handleNetworkChange:(NSNotification *)notice
{
    
    NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
    
    if(remoteHostStatus == NotReachable) {NSLog(@"no internet connection");}
    else if (remoteHostStatus == ReachableViaWiFi) {NSLog(@"Wifi connection"); }
    else if (remoteHostStatus == ReachableViaWWAN) {NSLog(@"3G or 4G connection"); }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"toGameMain"]){
        GameViewController *controller = (GameViewController *)segue.destinationViewController;
        controller.appStatus = appStatus;
    }
}

@end
