//
//  stage2_1.h
//  YWCA
//
//  Created by Benny SYW on 21/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Cordova/CDVViewController.h>
#import <Cordova/CDVCommandDelegateImpl.h>
#import <Cordova/CDVCommandQueue.h>

@interface Game : UIViewController<UIWebViewDelegate>

@property int stage;
@property int game;

@property (strong, nonatomic) IBOutlet UIWebView *webView;

@property (nonatomic, strong, readonly) CDVViewController *pgapViewController;

@end

@interface MainCommandDelegate : CDVCommandDelegateImpl
@end

@interface MainCommandQueue : CDVCommandQueue
@end
