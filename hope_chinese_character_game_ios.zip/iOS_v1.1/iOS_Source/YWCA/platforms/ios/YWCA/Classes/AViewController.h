//
//  AViewController.h
//  YWCA
//
//  Created by Benny SYW on 4/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface AViewController : UIViewController <NSURLConnectionDataDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIImageView *gameTitle;
@property (weak, nonatomic) IBOutlet UIImageView *logo;
@property (weak, nonatomic) IBOutlet UIImageView *char1;
@property (weak, nonatomic) IBOutlet UIImageView *char2;
@property (weak, nonatomic) IBOutlet UIImageView *char3;
@property (weak, nonatomic) IBOutlet UIImageView *char4;
@property (weak, nonatomic) IBOutlet UIButton *startbtn;

@property (weak, nonatomic) IBOutlet UITextField *spor_text;
- (IBAction)startBtn:(id)sender;

@end
