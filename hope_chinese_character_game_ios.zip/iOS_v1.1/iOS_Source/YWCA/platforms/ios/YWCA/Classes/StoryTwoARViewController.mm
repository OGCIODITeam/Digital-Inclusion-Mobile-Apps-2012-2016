//
//  StoryTwoARViewController.m
//  YWCA
//
//  Created by Eric on 3/1/15.
//
//

#import "StoryTwoARViewController.h"
#import "StoryTwoEcardViewController.h"
#import "AppDelegate.h"
#define IPAD     UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

@interface StoryTwoARViewController ()

@end

@implementation StoryTwoARViewController

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if(!(IPAD))
    {
        [imageViewObject1 setFrame:CGRectMake(10, self.view.bounds.size.height - 70, 60, 60)];
        [imageViewObject2 setFrame:CGRectMake(78, self.view.bounds.size.height - 70, 60, 60)];
        [imageViewObject3 setFrame:CGRectMake(148, self.view.bounds.size.height - 70, 60, 60)];
    }
    else
    {
        [imageViewObject1 setFrame:CGRectMake(10, self.view.bounds.size.height - 140, 60*2, 60*2)];
        [imageViewObject2 setFrame:CGRectMake(138, self.view.bounds.size.height - 140, 60*2, 60*2)];
        [imageViewObject3 setFrame:CGRectMake(268, self.view.bounds.size.height - 140, 60*2, 60*2)];
    }
    
    [self testalert:nil msg:@"恭喜你！你已成功完成了「三隻小豬」的故事！現在，請準備過關卡。\n「過關卡」可在以下網頁下載：\n http://www.ywca.org.hk/files/ywca/HOPE%20AR%20card.pdf \n 按下「開始」後，請按左下角的圖示，將「過關卡」逐一置於鏡頭前，奇妙的魔法便會出現！"];
    //[self testalert:nil msg:@"恭喜你成功完成了！\n現在，請把左下角的三張過關卡，逐一放在桌上，並把相機鏡頭對著整張過關咭。你會發現一些奇妙的魔法呢！"];
    //StoryOneEcardViewController *ecardVC = [[StoryOneEcardViewController alloc] initWithNibName:@"StoryOneEcardView" bundle:[NSBundle mainBundle]];
    //[self presentViewController:ecardVC animated:YES completion:nil];
}

- (void)viewDidLoad {
    
    //imageViewObject1 =[[UIImageView alloc] initWithFrame:CGRectMake(50,50,20,20)];
    //NSString *file = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat: @"%@/%@%d_360", FOLDER_PREFIX, PATH_PREFIX, 1] ofType:@"png"];
    NSString *file = [NSString stringWithFormat: @"%@/%@%d_360", FOLDER_PREFIX, PATH_PREFIX, 1];
    imageViewObject1.image = [UIImage imageNamed:file];//@"ARAssets/story1/s1_ar1_360.png"];
    imageViewObject1.backgroundColor = [UIColor clearColor];
    imageViewObject1.opaque = NO;
    imageViewObject1.alpha = 0.2f;
    //file = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat: @"%@/%@%d_360", FOLDER_PREFIX, PATH_PREFIX, 2] ofType:@"png"];
    file = [NSString stringWithFormat: @"%@/%@%d_360", FOLDER_PREFIX, PATH_PREFIX, 2];
    imageViewObject2.image = [UIImage imageNamed:file];//@"ARAssets/story1/s1_ar2_360.png"];
    imageViewObject2.backgroundColor = [UIColor clearColor];
    imageViewObject2.opaque = NO;
    imageViewObject2.alpha = 0.2f;
    //file = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat: @"%@/%@%d_360", FOLDER_PREFIX, PATH_PREFIX, 3] ofType:@"png"];
    file = [NSString stringWithFormat: @"%@/%@%d_360", FOLDER_PREFIX, PATH_PREFIX, 3];
    imageViewObject3.image = [UIImage imageNamed:file];//@"ARAssets/story1/s1_ar3_360.png"];
    imageViewObject3.backgroundColor = [UIColor clearColor];
    imageViewObject3.tintColor = [UIColor clearColor];
    imageViewObject3.opaque = NO;
    imageViewObject3.alpha = 0.2f;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    int pos = 0;
    
    isMatchObject1 = NO;
    isMatchObject2 = NO;
    isMatchObject3 = NO;
    
    isStop = NO;
    
    modelArray = [NSMutableArray arrayWithCapacity: 3];
    wordArray = [NSMutableArray arrayWithCapacity: 3];
    blockArray = [NSMutableArray arrayWithCapacity: 3];
    
    // load our tracking configuration
    NSString* trackingDataFile = [[NSBundle mainBundle] pathForResource:@"TrackingData_MarkerlessFast"
                                                                 ofType:@"xml"
                                                            inDirectory:FOLDER_PREFIX];
    
    
    // if you want to test the 3D tracking, please uncomment the line below and comment the line above
    //NSString* trackingDataFile = [[NSBundle mainBundle] pathForResource:@"TrackingData_ML3D" ofType:@"xml" inDirectory:@"Tutorials/Tutorial4/Assets4"];
    NSLog(@"trackingDataFile = %@", trackingDataFile);
    
    if(trackingDataFile)
    {
        const char *utf8Path = [trackingDataFile UTF8String];
        NSLog(@"utf8Path=%s\n", utf8Path);
        
        bool success = m_pMetaioSDK->setTrackingConfiguration(metaio::Path::fromUTF8(utf8Path));
        if( !success)
            NSLog(@"No success loading the tracking configuration");
    }
    
    
    // load content
    
    for(;pos<3;pos++)
    {
        //if(pos == 0)
        //pathModel = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@%d", PATH_PREFIX, pos+1]
        //                                                            ofType:@"zip"
        //                                               inDirectory:FOLDER_PREFIX];
        //else
        pathModel = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@%d", PATH_PREFIX, pos+1]
                                                    ofType:@"zip"
                                               inDirectory:FOLDER_PREFIX];
        
        if(pathModel)
        {
            // if this call was successful, theLoadedModel will contain a pointer to the 3D model
            const char *utf8Path = [pathModel UTF8String];
            m_3dModel =  m_pMetaioSDK->createGeometry(metaio::Path::fromUTF8(utf8Path));
            if( m_3dModel )
            {
                NSLog(@"utf8Path of 3d model = %s", utf8Path);
                // scale it a bit up
                m_3dModel->startAnimation("Take 001", true);
                
                m_3dModel->setRotation(metaio::Rotation(metaio::Vector3d(M_PI_2, 0, M_PI)));
                //m_3dModel->setScale(metaio::Vector3d(0.2f,0.2f,0.2f));
                if(pos == 0)
                    m_3dModel->setScale(OBJECT_1_SCALE * 1.0f);
                else if(pos == 1)
                    m_3dModel->setScale(OBJECT_2_SCALE * 1.0f);
                else if(pos == 2)
                    m_3dModel->setScale(OBJECT_3_SCALE * 1.0f);
                
                m_3dModel->setTranslation(metaio::Vector3d(0.0f, -100.0f, 0.0f));
            }
            else
            {
                NSLog(@"error, could not load %@", pathModel);
            }
        }
        
        
        // loadimage
        
        imagePathWord = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@%d_2word", PATH_PREFIX, pos+1]//@"s1_ar1_2word"
                                                        ofType:@"png"
                                                   inDirectory:FOLDER_PREFIX];
        //[self loadImageGeometry:imagePathWord withPlane:m_word];
        
        if (imagePathWord)
        {
            NSLog(@"Setting new image : %@", imagePathWord);
            
            const char *utf8Path = [imagePathWord UTF8String];
            m_word = m_pMetaioSDK->createGeometryFromImage(metaio::Path::fromUTF8(utf8Path));
            if (m_word) {
                m_word->setScale(metaio::Vector3d(3.0f,3.0f,3.0f));
            }
            else NSLog(@"Error: could not load image plane");
        }
        
        
        
        imagePathBlock = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@%d_3block", PATH_PREFIX, pos+1]//@"s1_ar1_3block"
                                                         ofType:@"png"
                                                    inDirectory:FOLDER_PREFIX];
        
        //[self loadImageGeometry:imagePathBlock withPlane:m_block];
        if (imagePathBlock)
        {
            NSLog(@"Setting new image : %@", imagePathBlock);
            
            const char *utf8Path = [imagePathBlock UTF8String];
            m_block = m_pMetaioSDK->createGeometryFromImage(metaio::Path::fromUTF8(utf8Path));
            if (m_block) {
                m_block->setScale(metaio::Vector3d(3.0f,3.0f,3.0f));
            }
            else NSLog(@"Error: could not load image plane");
        }
        NSLog(@"3d model[%d] = %p ", pos,  m_3dModel);
        NSLog(@"word[%d] = %p ", pos,  m_word);
        NSLog(@"Block[%d] = %p ", pos,  m_block);
        
        m_3dModel->setCoordinateSystemID(pos+1);
        m_word->setCoordinateSystemID(pos+1);
        m_block->setCoordinateSystemID(pos+1);
        
        //m_3dModel->setVisible(false);
        //m_word->setVisible(false);
        //m_block->setVisible(false);
        
        [modelArray addObject:[NSValue valueWithPointer:m_3dModel]];
        [wordArray addObject:[NSValue valueWithPointer:m_word]];
        [blockArray addObject:[NSValue valueWithPointer:m_block]];
    }
    
    [self addBackBtn];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}


- (void)viewDidUnload
{
    // Release any retained subviews of the main view.
    [super viewDidUnload];
    [self stopTimer];
}

- (void)loadImageGeometry:(NSString *)imagePath withPlane:(metaio::IGeometry*) plane
{
    
    if (imagePath)
    {
        NSLog(@"Setting new image : %@", imagePath);
        
        const char *utf8Path = [imagePath UTF8String];
        plane = m_pMetaioSDK->createGeometryFromImage(metaio::Path::fromUTF8(utf8Path));
        if (plane) {
            plane->setScale(metaio::Vector3d(3.0f,3.0f,3.0f));
        }
        else NSLog(@"Error: could not load image plane");
    }
}

- (void)onSDKReady
{
    [super onSDKReady];
    
}

-(void)stopTimer
{
    NSLog(@"wordTimer=%@", wordTimer);
    
    if(wordTimer != nil  && [wordTimer isValid])
    {
        [wordTimer invalidate];
        wordTimer = nil;
        NSLog(@"wordTimer invalidate");
    }
    
    if(blockTimer != nil  && [blockTimer isValid])
    {
        [blockTimer invalidate];
        blockTimer = nil;
        NSLog(@"blockTimer invalidate");
    }
}

/*
 -(void)viewDidDisappear:(BOOL)animated
 {
 [modelTimer setFireDate:[NSDate distantFuture]];
 }
 
 - (void)stopCountdownTimer {
 [modelTimer invalidate];
 modelTimer = nil;
 }
 */

- (void)onTrackingEvent:(const metaio::stlcompat::Vector<metaio::TrackingValues>&)trackingValues
{
    NSLog(@"onTrackingEvent is call");
    size_t total = trackingValues.size();
    
    if (trackingValues.empty() || !trackingValues[0].isTrackingState())
    {
        NSLog(@"trackingvalue is empty or not in tracking state");
        //[wordTimer setFireDate:[NSDate distantFuture]];
        //[blockTimer setFireDate:[NSDate distantFuture]];
        [self stopTimer];
        
        isStop = YES;
    }
    else
    {
        for(size_t i = 0 ; i < total; i++)
        {
            NSLog(@"getCOS[%zu] = %d", i, trackingValues[i].coordinateSystemID);
            currentIndex = trackingValues[i].coordinateSystemID;
        }
        isStop = NO;
        
        [self startObjectAnimation:currentIndex];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 -(metaio::IGeometry*) getCurrentModel:(int)index{
 return (metaio::IGeometry*)[[modelArray objectAtIndex:index] pointerValue];
 }
 
 -(metaio::IGeometry*) getCurrentWord:(int)index{
 return (metaio::IGeometry*)[[wordArray objectAtIndex:index] pointerValue];
 }
 
 -(metaio::IGeometry*) getCurrentBlock:(int)index{
 return (metaio::IGeometry*)[[blockArray objectAtIndex:index] pointerValue];
 }
 */

- (void) startObjectAnimation:(int)index{
    NSLog(@"startObjectAnimation at %d is called", index);
    isWordStart = NO;
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        [wordTimer setFireDate:[NSDate distantFuture]];
        [blockTimer setFireDate:[NSDate distantFuture]];
        [self modelStartAnimation:index];
    }
    
}

-(void)modelStartAnimation:(int)index{
    NSLog(@"modelStartAnimation at %d is called", index);
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        int currPos = index - 1;
        metaio::IGeometry* model = (metaio::IGeometry*)[[modelArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* word = (metaio::IGeometry*)[[wordArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* block = (metaio::IGeometry*)[[blockArray objectAtIndex:currPos] pointerValue];
        model->setVisible(true);
        word->setVisible(false);
        block->setVisible(false);
        
        [self performSelector:@selector(modelStopAnimation:) withObject:[NSNumber numberWithInt:index] afterDelay:4.0];
    }
}

-(void)modelStopAnimation:(NSNumber *)numIndex{
    NSLog(@"modelStopAnimation is called");
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        int currPos = [numIndex intValue] - 1;
        metaio::IGeometry* model = (metaio::IGeometry*)[[modelArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* word = (metaio::IGeometry*)[[wordArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* block = (metaio::IGeometry*)[[blockArray objectAtIndex:currPos] pointerValue];
        model->setVisible(false);
        word->setVisible(true);
        block->setVisible(false);
        
        count = 1;
        
        NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                  numIndex, @"index",
                                  nil];
        
        [wordTimer invalidate];
        wordTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(wordStartAnimationTimer:) userInfo:userInfo repeats:YES];
        [wordTimer setFireDate:[NSDate distantPast]];
        [wordTimer fire];
        //[self wordStartAnimation:numIndex];
        [self performSelector:@selector(wordStopAnimation:) withObject:numIndex afterDelay:4.0];
    }
    
}

-(void)wordStartAnimationTimer:(NSTimer *)timer{
    NSLog(@"wordStartAnimationTimer is called");
    
    
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        isWordStart = YES;
        NSDictionary *userInfo = [timer userInfo];
        int currPos = [[userInfo objectForKey:@"index"] intValue] - 1;
        
        metaio::IGeometry* word = (metaio::IGeometry*)[[wordArray objectAtIndex:currPos] pointerValue];
        //word->setScale(metaio::Vector3d(0.25f*count,0.25f*count,0.25f*count));
        word->setScale(metaio::Vector3d(0.25f*count,0.25f*count,0.25f*count));
        NSLog(@"count=%d", count);
        if(count <= 20)
        {
            count++;
        }
    }
}

/*
 -(void)wordStartAnimation:(NSNumber *)numIndex{
 NSLog(@"wordStartAnimation is called");
 int currPos = [numIndex intValue] - 1;
 metaio::IGeometry* word = (metaio::IGeometry*)[[wordArray objectAtIndex:currPos] pointerValue];
 word->setScale(metaio::Vector3d(0.25f*count,0.25f*count,0.25f*count));
 
 NSLog(@"count=%d", count);
 if(count < 20)
 {
 count++;
 }
 }
 */

-(void)wordStopAnimation:(NSNumber *)numIndex{
    NSLog(@"wordStopAnimation is called");
    if(isStop)
    {
        [self stopTimer];
    }
    else if(isWordStart)
    {
        [wordTimer setFireDate:[NSDate distantFuture]];
        int currPos = [numIndex intValue] - 1;
        metaio::IGeometry* model = (metaio::IGeometry*)[[modelArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* word = (metaio::IGeometry*)[[wordArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* block = (metaio::IGeometry*)[[blockArray objectAtIndex:currPos] pointerValue];
        model->setVisible(false);
        word->setVisible(false);
        block->setVisible(true);
        
        block->setScale(1.0f*BLOCK_MAX_SCALE);
        //[self blockStayAnimation:numIndex];
        [self performSelector:@selector(blockStayAnimation:) withObject:numIndex afterDelay:2.0];
    }
}

-(void)blockStayAnimation:(NSNumber *)numIndex{
    NSLog(@"blockStayAnimation is called");
    count = BLOCK_MAX_SCALE;
    
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                  numIndex, @"index",
                                  nil];
        [blockTimer invalidate];
        blockTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(blockStartAnimationTimer:) userInfo:userInfo repeats:YES];
        
        [blockTimer setFireDate:[NSDate distantPast]];
        [blockTimer fire];
        
        [self performSelector:@selector(blockStopAnimation:) withObject:numIndex afterDelay:2.0];
    }
}

-(void)blockStartAnimationTimer:(NSTimer *)timer{
    NSLog(@"blockStartAnimationTimer is called");
    
    NSDictionary *userInfo = [timer userInfo];
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        int currPos = [[userInfo objectForKey:@"index"] intValue] - 1;
        
        
        metaio::IGeometry* block = (metaio::IGeometry*)[[blockArray objectAtIndex:currPos] pointerValue];
        
        if(count > 0)
        {
            //block->setScale(metaio::Vector3d(0.25f*count,0.25f*count,0.25f*count));
            for(int j=0; j<4; j++)
            {
                float fscale = 1.0f*(count-j*0.25);
                NSLog(@"fscale=%f", fscale);
                block->setScale(metaio::Vector3d(fscale,fscale,fscale));
            }
            count--;
        }
        else
        {
            block->setScale(metaio::Vector3d(0.0f,0.0f,0.0f));
        }
    }
}

/*
 -(void)blockStartAnimation:(NSNumber *)numIndex{
 NSLog(@"blockStartAnimation is called");
 NSLog(@"count=%d", count);
 
 int currPos = [numIndex intValue] - 1;
 metaio::IGeometry* block = (metaio::IGeometry*)[[blockArray objectAtIndex:currPos] pointerValue];
 
 if(count > 0)
 {
 block->setScale(metaio::Vector3d(0.5f*count,0.5f*count,0.5f*count));
 count--;
 }
 }
 */

-(void)blockStopAnimation:(NSNumber *)numIndex{
    NSLog(@"blockStopAnimation is called");
    
    if(isStop)
    {
        [self stopTimer];
    }
    else
    {
        [blockTimer setFireDate:[NSDate distantFuture]];
        
        int currPos = [numIndex intValue] - 1;
        metaio::IGeometry* model = (metaio::IGeometry*)[[modelArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* word = (metaio::IGeometry*)[[wordArray objectAtIndex:currPos] pointerValue];
        metaio::IGeometry* block = (metaio::IGeometry*)[[blockArray objectAtIndex:currPos] pointerValue];
        
        model->setVisible(false);
        word->setVisible(false);
        block->setVisible(false);
        
        if(currPos == 0 && isStop == NO)
        {
            isMatchObject1 = YES;
            imageViewObject1.alpha = 1.0f;
        }
        else if(currPos == 1 && isStop == NO)
        {
            isMatchObject2 = YES;
            imageViewObject2.alpha = 1.0f;
        }
        else if(currPos == 2 && isStop == NO)
        {
            isMatchObject3 = YES;
            imageViewObject3.alpha = 1.0f;
        }
    }
    
    if([self allObjectMatch] == YES)
    {
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        [appDelegate setARfinish:2 finish:1];
        //UIViewController *Acontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"StoryOneEcard"];
        StoryTwoEcardViewController *ecardVC = [[StoryTwoEcardViewController alloc] initWithNibName:@"StoryTwoEcardView" bundle:[NSBundle mainBundle]];
        [self presentViewController:ecardVC animated:YES completion:nil];
    }
    
}

-(BOOL)allObjectMatch
{
    return isMatchObject1 && isMatchObject2 && isMatchObject3;
}

- (void)testalert:(NSString*)title msg:(NSString*)msg {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:msg
                                                   delegate:self
                                          cancelButtonTitle:@"開始"
                                          otherButtonTitles: nil];
    [alert show];
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

- (void)addBackBtn {
    CGRect screenBound = [[UIScreen mainScreen] bounds];
    CGSize screenSize = screenBound.size;
    CGFloat screenWidth = screenSize.width;
    CGFloat screenHeight = screenSize.height;
    
    btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnBack addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [btnBack setImage:[UIImage imageNamed:@"btn_back.png"] forState:UIControlStateNormal];
    if (IS_IPAD) {
        [btnBack setFrame:CGRectMake(screenWidth - 160, 0, 160, 160)];
    } else {
        [btnBack setFrame:CGRectMake(screenWidth - 80, 0, 80, 80)];
    }
    [self.view addSubview:btnBack];
    [self.view bringSubviewToFront:btnBack];
}

- (IBAction)back:(id)sender {
    UIStoryboard *storyboard;
    if (IS_IPAD) {
        storyboard = [UIStoryboard storyboardWithName:@"MainIpad" bundle:nil]; //MainIpad
    }else{
        storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    }
    UIViewController *gameView = [storyboard instantiateViewControllerWithIdentifier:@"game"];
    [self presentViewController:gameView animated:YES completion:nil];
}

@end
