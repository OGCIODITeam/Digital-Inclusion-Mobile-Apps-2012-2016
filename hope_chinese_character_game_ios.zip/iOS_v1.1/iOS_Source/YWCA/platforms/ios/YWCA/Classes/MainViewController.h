//
//  MainViewController.h
//  YWCA
//
//  Created by Benny SYW on 4/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "Reachability.h"
Reachability* reachability;

@interface MainViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *bg;
@property (strong, nonatomic) IBOutlet UIImageView *imgbg;
@property (weak, nonatomic) IBOutlet UIImageView *gameTitle;
@property (weak, nonatomic) IBOutlet UIButton *bgm_off;
@property (weak, nonatomic) IBOutlet UIButton *bgm_on;
@property (weak, nonatomic) IBOutlet UIButton *back;
@property (weak, nonatomic) IBOutlet UIButton *action01;
@property (weak, nonatomic) IBOutlet UIButton *action02;
@property (weak, nonatomic) IBOutlet UIButton *action03;
@property (weak, nonatomic) IBOutlet UIButton *action04;
@property (strong, nonatomic) IBOutlet UIView *shadow;
- (IBAction)back:(id)sender;
- (IBAction)bgm_off:(id)sender;
- (IBAction)bgm_on:(id)sender;
- (IBAction)action01:(id)sender;
- (IBAction)action02:(id)sender;
- (IBAction)action03:(id)sender;
- (IBAction)action04:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *spor_text;

@end
