//
//  BDarkStarS1ViewController.m
//  YWCA
//
//  Created by Benny SYW on 25/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "BDarkStarS1ViewController.h"
#import "AppDelegate.h"

@interface BDarkStarS1ViewController () {
    NSString *file;
}

@end

@implementation BDarkStarS1ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    //[self readRecord:appDelegate.select_stage];
    //NSLog(@"select_stage===%d",appDelegate.select_stage);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    file = @"star_off";
    self.S1.image = [UIImage imageNamed:file];
    self.S2.image = [UIImage imageNamed:file];
    self.S3.image = [UIImage imageNamed:file];
    self.S4.image = [UIImage imageNamed:file];
    self.S5.image = [UIImage imageNamed:file];
}

- (void)viewDidDisappear:(BOOL)animated {
    file = nil;
    self.S1 = nil;
    self.S2 = nil;
    self.S3 = nil;
    self.S4 = nil;
    self.S5 = nil;
}
/*
- (void)readRecord:(int)stage {
    current_game = 1;
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    stars = [appDelegate getStars:stage game:current_game];
    star_value = [stars intValue];
    if(star_value == 5) {
        self.S5.hidden = YES;
    }
    if(star_value >= 4) {
        self.S4.hidden = YES;
    }
    if(star_value >= 3) {
        self.S3.hidden = YES;
    }
    if(star_value >= 2) {
        self.S2.hidden = YES;
    }
    if(star_value >= 1) {
        self.S1.hidden =YES;
    }
    
}
*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
