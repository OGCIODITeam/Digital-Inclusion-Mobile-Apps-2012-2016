//
//  GameViewController.m
//  YWCA
//
//  Created by Benny SYW on 11/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "GameViewController.h"
#import "AppDelegate.h"
#import "Game.h"
#import "BDarkStarS1ViewController.h"
#import "BDarkStarS2ViewController.h"
#import "BDarkStarS3ViewController.h"
#import "BDarkStarS4ViewController.h"
#import "BLightStarS1ViewController.h"
#import "BLightStarS2ViewController.h"
#import "BLightStarS3ViewController.h"
#import "BLightStarS4ViewController.h"
#import "ZipArchive.h"
#import <QuartzCore/QuartzCore.h>
#import "openBookViewIpad.h"
#import "Constants.h"
//#import "DBManager.h"

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

@interface GameViewController () {
    int booknum, stage, game, star_value, stage_stars, final_star1, final_star2, final_star3, final_star4, final_star5;
    BOOL gameExists, fileExists, fileExistsBase, zip1, zip2, zip3, zip4, zip5;
    NSString *stars, *appStatus, *unziploc;
    UIImage *BigbookC, *Bigbookop;
    int gameStar1_int, gameStar2_int, gameStar3_int, gameStar4_int, gameStarForMsg;
    int quit_stage;
    int quit_lose;
    NSString *imgFile;
    int alert_font_size, percentage_font_size;
    BOOL testSize, zip_update, update_checked, file_status, checking, first_check1;
    openBookViewIpad* bookview1, *bookview2, *bookview3, *bookview4, *bookview5;
    double size1, size2, size3, size4, size5;
    int osVersion, check_num;
    long long server_file_size;
}

@property (nonatomic, strong) AVAudioPlayer *bgmPlayer;

//@property (nonatomic, strong) DBManager *dbManager;

@property (nonatomic, strong) NSArray *arrGame;

@property (nonatomic, strong) NSArray *arrSetting;

@property (nonatomic, strong) NSString *zipName;

@property (nonatomic) NSMutableData *zipData;
@property (nonatomic) NSUInteger totalBytes;
@property (nonatomic) NSUInteger receivedBytes;

@property (nonatomic) NSURLConnection *connection;
@property (nonatomic) NSURL *url;

@end

@implementation GameViewController

@synthesize appStatus;
@synthesize bgmPlayer = mBgmPlayer;
@synthesize bgm_off = mBgm_off;
@synthesize bgm_on = mBgm_on;
@synthesize quit_stage;
@synthesize quit_lose;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //music
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSString *indexMusic, *indexSound;
    int music_value, sound_value;
    indexMusic = [appDelegate getMusic];
    indexSound = [appDelegate getSound];
    music_value = [indexMusic intValue];
    sound_value = [indexSound intValue];
    if (music_value == 1) {
        [appDelegate playBgMusic];
        mBgm_off.hidden = YES;
        mBgm_on.hidden = NO;
    } else if (music_value == 0) {
        mBgm_off.hidden = NO;
        mBgm_on.hidden = YES;
    }
    
    if (sound_value == 1) {
        self.sound_off.hidden = YES;
        self.sound_on.hidden = NO;
    } else if (sound_value == 0) {
        self.sound_off.hidden = NO;
        self.sound_on.hidden = YES;
    }
    CGAffineTransform transform;
    if (IS_IPAD) {
        transform = CGAffineTransformMakeScale(1.0f, 30.0f);
    } else {
        transform = CGAffineTransformMakeScale(1.0f, 12.0f);
    }
    self.DL_process.transform = transform;
    
    //download icon
    self.DL1.hidden = YES;
    //self.DL2.hidden = YES;
    //self.DL3.hidden = YES;
    //self.DL4.hidden = YES;
    //self.DL5.hidden = YES;
    
    [self updateRateStarWithStages];
    
    //[appDelegate getAllSettingData];
    //[appDelegate getAllGameData];
    
    //[self downloadFiles];
    
    //custom views tap events
    UITapGestureRecognizer *cstap1 =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(cs1tap:)];
    [self.customStory1.bookbtn addGestureRecognizer:cstap1];
    
    UITapGestureRecognizer *cstap2 =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(cs2tap:)];
    [self.customStory2.bookbtn addGestureRecognizer:cstap2];
    
    UITapGestureRecognizer *cstap3 =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(cs3tap:)];
    [self.customStory3.bookbtn addGestureRecognizer:cstap3];
    
    UITapGestureRecognizer *cstap4 =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(cs4tap:)];
    [self.customStory4.bookbtn addGestureRecognizer:cstap4];
    
    UITapGestureRecognizer *cstap5 =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(cs5tap:)];
    [self.customStory5.bookbtn addGestureRecognizer:cstap5];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    size1 = 34.1;
    size2 = 42.9;
    size3 = 41.9;
    size4 = 43.1;
    size5 = 55.2;

    if (IS_IPAD) {
        alert_font_size = 38;
        percentage_font_size = 45;
    } else {
        alert_font_size = 20;
        percentage_font_size = 25;
    }
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    self.shadow.hidden = YES;
    self.BigBk2C.hidden = YES;
    self.BigBk2View.hidden = YES;
    //self.Download_View.hidden = YES;
    self.Download_View.hidden = YES;
    self.DL_process.progress = 0;
    self.DL_percentage.text = @"0";
    //self.DL_percentage.textColor = [UIColor brownColor];
    [self.DL_percentage setTextAlignment:NSTextAlignmentRight];
    [self.DL_percentage setFont:[UIFont fontWithName:@"Helvetica Neue" size:percentage_font_size]];
    //TODO: get file size
    //self.DLing_text.text = [NSString stringWithFormat:@"關卡下載中 (%lu MB)",(unsigned long)self.totalBytes];
    
    // === rainbow setting ===
    
    self.btn_rainbow1.hidden = YES;
    self.btn_rainbow2.hidden = YES;
    self.btn_rainbow3.hidden = YES;
    self.btn_rainbow4.hidden = YES;
    
    // === custom views setting ===
    //view
    self.customStory1.hidden = YES;
    self.customStory2.hidden = YES;
    self.customStory3.hidden = YES;
    self.customStory4.hidden = YES;
    self.customStory5.hidden = YES;
    bookview1.hidden = YES;
    bookview2.hidden = YES;
    bookview3.hidden = YES;
    bookview4.hidden = YES;
    bookview5.hidden = YES;
    self.btn_cs1.hidden = YES;
    self.btn_cs2.hidden = YES;
    self.btn_cs3.hidden = YES;
    self.btn_cs4.hidden = YES;
    self.btn_cs5.hidden = YES;
    
    
    //marso updated
    //[self hideOpenedBooks:NO];
    
    final_star1 = [appDelegate getStarsInt:1 game:4];
    final_star2 = [appDelegate getStarsInt:2 game:4];
    final_star3 = [appDelegate getStarsInt:3 game:4];
    final_star4 = [appDelegate getStarsInt:4 game:4];
    final_star5 = [appDelegate getStarsInt:5 game:4];
    
    if (final_star1 >=1) {
        CGRect org_custom_frame;
        
        if (IS_IPAD) {
            /*
            NSLog(@"org size: %f, %f", self.customStory1.frame.size.height, self.customStory1.frame.size.width);
            org_custom_frame.size.width = 242;
            org_custom_frame.size.height = 120;
            self.customStory1.frame = org_custom_frame;
         
            org_custom_frame.size.height = self.customStory1.frame.size.height;
            org_custom_frame.size.width = self.customStory1.frame.size.width;
            org_custom_frame.size.height = org_custom_frame.size.height + 100;
            org_custom_frame.size.width = org_custom_frame.size.width + 100;
            self.customStory1.frame = org_custom_frame;
         
            NSLog(@"new size: %f, %f", self.customStory1.frame.size.height, self.customStory1.frame.size.width);
             */
        }
    
        [self.customStory1.bookview sizeToFit];
        self.customStory1.hidden = NO;
        self.btn_rainbow1.hidden = NO;
        self.DL1.hidden = YES;
        self.book1.hidden = YES;
    }
    if (final_star2 >=1) {
        self.customStory2.hidden = NO;
        self.btn_rainbow2.hidden = NO;
        self.DL2.hidden = YES;
        self.book2.hidden = YES;
    }
    if (final_star3 >=1) {
        self.customStory3.hidden = NO;
        self.btn_rainbow3.hidden = NO;
        self.DL3.hidden = YES;
        self.book3.hidden = YES;
    }
    if (final_star4 >=1) {
        self.customStory4.hidden = NO;
        self.btn_rainbow4.hidden = NO;
        self.DL4.hidden = YES;
        self.book4.hidden = YES;
    }
    if (final_star5 >=1) {
        self.customStory5.hidden = NO;
        self.DL5.hidden = YES;
        self.book5.hidden = YES;
    }
    //bookname
    self.customStory1.bookname.text = @"國王的新衣";
    self.customStory2.bookname.text = @"三隻小豬";
    self.customStory3.bookname.text = @"醜小鴨";
    self.customStory4.bookname.text = @"快樂王子";
    self.customStory5.bookname.text = @"魯賓遜漂流記";
    self.customStory1.bookname.textAlignment = NSTextAlignmentCenter;
    self.customStory2.bookname.textAlignment = NSTextAlignmentCenter;
    self.customStory3.bookname.textAlignment = NSTextAlignmentCenter;
    self.customStory4.bookname.textAlignment = NSTextAlignmentCenter;
    self.customStory5.bookname.textAlignment = NSTextAlignmentCenter;
    //bookimage
    UIImage * btnImage1 = [UIImage imageNamed:@"btn_book_open_1.png"];
    UIImage * btnImage2 = [UIImage imageNamed:@"btn_book_open_2.png"];
    UIImage * btnImage3 = [UIImage imageNamed:@"btn_book_open_3.png"];
    UIImage * btnImage4 = [UIImage imageNamed:@"btn_book_open_4.png"];
    UIImage * btnImage5 = [UIImage imageNamed:@"btn_book_open_5.png"];
    //[self.customStory5.bookbtn setFrame:CGRectMake(0,8,200,500)];
    //resize images
    CGSize newsize1 = CGSizeMake(135.0, 200.0);
    UIGraphicsBeginImageContext( newsize1 );
    [btnImage1 drawInRect:CGRectMake(0,0,newsize1.width,newsize1.height)];
    UIImage* newimg1 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGSize newsize2 = CGSizeMake(115.0, 200.0);
    UIGraphicsBeginImageContext( newsize2 );
    [btnImage2 drawInRect:CGRectMake(0,0,newsize2.width,newsize2.height)];
    UIImage* newimg2 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGSize newsize3 = CGSizeMake(95.0, 200.0);
    UIGraphicsBeginImageContext( newsize3 );
    [btnImage3 drawInRect:CGRectMake(0,0,newsize3.width,newsize3.height)];
    UIImage* newimg3 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGSize newsize4 = CGSizeMake(115.0, 200.0);
    UIGraphicsBeginImageContext( newsize4 );
    [btnImage4 drawInRect:CGRectMake(0,0,newsize4.width,newsize4.height)];
    UIImage* newimg4 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGSize newsize5 = CGSizeMake(138.0, 200.0);
    UIGraphicsBeginImageContext( newsize5 );
    [btnImage5 drawInRect:CGRectMake(0,0,newsize5.width,newsize5.height)];
    UIImage* newimg5 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    //[self.customStory5.bookbtn setFrame:CGRectMake(0, 0, 140, 200)];
    
    [self.customStory1.bookbtn setImage:newimg1 forState:UIControlStateNormal];
    [self.customStory2.bookbtn setImage:newimg2 forState:UIControlStateNormal];
    [self.customStory3.bookbtn setImage:newimg3 forState:UIControlStateNormal];
    [self.customStory4.bookbtn setImage:newimg4 forState:UIControlStateNormal];
    [self.customStory5.bookbtn setImage:newimg5 forState:UIControlStateNormal];
    //self.customStory5.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    //    CGRect frame = self.customStory5.bookbtn.frame;
    //    frame.size = CGSizeMake(1200, 200);
    //    self.customStory5.bookbtn.frame = frame;
    
    //bookstar & bookdone
    [self.customStory1 setStarsWithStage:1];
    [self.customStory2 setStarsWithStage:2];
    [self.customStory3 setStarsWithStage:3];
    [self.customStory4 setStarsWithStage:4];
    [self.customStory5 setStarsWithStage:5];
    [self.customStory1 setDoneWithStage:1];
    [self.customStory2 setDoneWithStage:2];
    [self.customStory3 setDoneWithStage:3];
    [self.customStory4 setDoneWithStage:4];
    [self.customStory5 setDoneWithStage:5];
    
    if (IS_IPAD) {
        [self initIpadStoryViews];
        [self.view bringSubviewToFront:self.shadow];
        [self.view bringSubviewToFront:self.BigBk2C];
        [self.view bringSubviewToFront:self.BigBk2View];
        [self.view bringSubviewToFront:self.Download_View];
        
        appDelegate = [[UIApplication sharedApplication] delegate];
        NSArray* array = [[NSArray alloc]initWithObjects:bookview1,bookview2, bookview3, bookview4, bookview5, nil];
        NSArray* array2 = [[NSArray alloc]initWithObjects:self.book1,self.book2, self.book3, self.book4, self.book5, nil];
        for(int i=1;i<=5;i++){
            
            int game_star = [appDelegate getStageStarsInt:i];
            [[array objectAtIndex:(i-1)] setStars:game_star];
            
            BOOL open = [appDelegate getStarsInt:i game:1]>0;
            ((openBookViewIpad*)[array objectAtIndex:(i-1)]).hidden = !open;
            ((UIButton *)[array2 objectAtIndex:(i-1)]).hidden = open;
            
            BOOL pass = [appDelegate getPass:i];
            [[array objectAtIndex:(i-1)] setComplete:pass];
        }
       
    }
    
    
    
    // === check file exist ===
    [appDelegate setItem_starAndstage];
    
    file_status = NO;
    first_check1 = YES;
    if ([self checkConnection] != 0) {
        [self checkFile:1];
    } else {
        //[self testalert:@"無網絡" msg:nil];
    }
    if ([appDelegate getFileSize:2] != 0) {
        self.DL2.hidden = YES;
    }
    if ([appDelegate getFileSize:3] != 0) {
        self.DL3.hidden = YES;
    }
    if ([appDelegate getFileSize:4] != 0) {
        self.DL4.hidden = YES;
    }
    if ([appDelegate getFileSize:5] != 0) {
        self.DL5.hidden = YES;
    }
    
    if (IS_IPAD) {
        self.customStory1.hidden = YES;
        self.customStory2.hidden = YES;
        self.customStory3.hidden = YES;
        self.customStory4.hidden = YES;
        self.customStory5.hidden = YES;
//        self.DL1.hidden = YES;
//        self.DL2.hidden = YES;
//        self.DL3.hidden = YES;
//        self.DL4.hidden = YES;
//        self.DL5.hidden = YES;
//        self.book1.hidden = YES;
//        self.book2.hidden = YES;
//        self.book3.hidden = YES;
//        self.book4.hidden = YES;
//        self.book5.hidden = YES;
        //[self initIpadStoryViews];
    }
    if (quit_stage != 0) {
        [self.view bringSubviewToFront:self.shadow];
        [self.view bringSubviewToFront:self.BigBk2C];
        [self.view bringSubviewToFront:self.BigBk2View];
        [self.view bringSubviewToFront:self.BigBk2];
        [self.view bringSubviewToFront:self.Download_View];
        
        self.BigBk2C.hidden = YES;
        self.BigBk2View.hidden = NO;
        stage = quit_stage;
        booknum = stage;
        appDelegate.select_game = quit_stage;
        [self updateGameText:quit_stage];
        [self.BigBk2.imageView setImage:nil];
        [self updateBackgroundImage:quit_stage];
        [self updateRateStarWithStages];
        NSLog(@"quit at %d",quit_stage);
    }
    quit_stage = 0;
    

    if (quit_lose == 1) {
        [self testalert:@"星星不足，不能挑戰下一關" msg:@"需要三顆星星"];
        quit_lose = 0;
    }
}

///start ipad viewer

-(void)initIpadStoryViews{
 //   NSArray* objects =  [[NSBundle mainBundle]loadNibNamed:@"openBookView_iPad" owner:self options:nil];
    float width = 0.35; //[UIHelper getScreenSize].width*0.35;
    //float height =[UIHelper getScreenSize].height*0.15;
    float hArray[5] = {413, 445, 413, 413, 391};
    float wArray[5] = {680, 570,480, 570,671};
   
    
    bookview1 =  [[openBookViewIpad alloc]initWithFrame:CGRectMake(50, 400, width*wArray[0], width*hArray[0])];
    [bookview1 initViewsWithState:1 noOfStar:1 completed:YES];
    bookview1.btnBook.tag = 1;
    [bookview1.btnBook addTarget:self action:@selector(bookIpadClick:) forControlEvents:UIControlEventTouchUpInside];
    
    bookview2 =  [[openBookViewIpad alloc]initWithFrame:CGRectMake(100, 200, width*wArray[1], width*hArray[1])];
    [bookview2 initViewsWithState:2 noOfStar:2 completed:YES];
    bookview2.btnBook.tag = 2;
    [bookview2.btnBook addTarget:self action:@selector(bookIpadClick:) forControlEvents:UIControlEventTouchUpInside];
    
    bookview3 =  [[openBookViewIpad alloc]initWithFrame:CGRectMake(300, 150, width*wArray[2], width*hArray[2])];
    [bookview3 initViewsWithState:3 noOfStar:3 completed:YES];
    bookview3.btnBook.tag = 3;
    [bookview3.btnBook addTarget:self action:@selector(bookIpadClick:) forControlEvents:UIControlEventTouchUpInside];
    
    bookview4 =  [[openBookViewIpad alloc]initWithFrame:CGRectMake(500, 150,width*wArray[3], width*hArray[3])];
    [bookview4 initViewsWithState:4 noOfStar:4 completed:YES];
    bookview4.btnBook.tag = 4;
    [bookview4.btnBook addTarget:self action:@selector(bookIpadClick:) forControlEvents:UIControlEventTouchUpInside];
    
    bookview5 =  [[openBookViewIpad alloc]initWithFrame:CGRectMake(730, 180, width*wArray[4], width*hArray[4])];
    [bookview5 initViewsWithState:5 noOfStar:5 completed:YES];
    bookview5.btnBook.tag = 5;
    [bookview5.btnBook addTarget:self action:@selector(bookIpadClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:bookview1];
    [self.view addSubview:bookview2];
    [self.view addSubview:bookview3];
    [self.view addSubview:bookview4];
    [self.view addSubview:bookview5];
    
    [self.view bringSubviewToFront:self.btn_rainbow1];
    [self.view bringSubviewToFront:self.btn_rainbow2];
    [self.view bringSubviewToFront:self.btn_rainbow3];
    [self.view bringSubviewToFront:self.btn_rainbow4];
}

-(void)hideOpenedBooks:(BOOL)isHide{
    bookview1.hidden = isHide;
    bookview2.hidden = isHide;
    bookview3.hidden = isHide;
    bookview4.hidden = isHide;
    bookview5.hidden = isHide;
}

-(void)bookIpadClick:(id)sender{
    //[self hideOpenedBooks:YES];
    [self.view bringSubviewToFront:self.shadow];
    [self.view bringSubviewToFront:self.BigBk2C];
    [self.view bringSubviewToFront:self.BigBk2View];
    [self.view bringSubviewToFront:self.Download_View];
    UIButton* btn = (UIButton*)sender;
    switch (btn.tag) {
        case 1:
            [self enterBook1];
            break;
        case 2:
            [self enterBook2];
            break;
        case 3:
            [self enterBook3];
            break;
        case 4:
            [self enterBook4];
            break;
        case 5:
            [self enterBook5];
            break;
            
        default:
            [self enterBook1];
            break;
    }
}



///end ipad viewer



- (void)viewDidAppear:(BOOL)animated {
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    //quit from webview (game)
    
    if (IS_IPAD) {
        NSArray* array = [[NSArray alloc]initWithObjects:bookview1,bookview2, bookview3, bookview4, bookview5, nil];
        NSArray* array2 = [[NSArray alloc]initWithObjects:self.book1,self.book2, self.book3, self.book4, self.book5, nil];
        for(int i=1;i<=5;i++){
            
            int game_star = [appDelegate getStageStarsInt:i];
            [[array objectAtIndex:(i-1)] setStars:game_star];
            
            BOOL open = [appDelegate getStarsInt:i game:1]>0;
            ((openBookViewIpad*)[array objectAtIndex:(i-1)]).hidden = !open;
            ((UIButton *)[array2 objectAtIndex:(i-1)]).hidden = open;
            
            BOOL pass = [appDelegate getPass:i];
            [[array objectAtIndex:(i-1)] setComplete:pass];
        }
    }/*
    if (quit_stage == 1) {
        //[self performSelectorOnMainThread:@selector(book1:) withObject:nil waitUntilDone:YES];
        [self enterBook1];
    } else if (quit_stage == 2) {
        [self enterBook2];
    } else if (quit_stage == 3) {
        [self enterBook3];
    } else if (quit_stage == 4) {
        [self enterBook4];
    } else if (quit_stage == 5) {
        [self enterBook5];
    }
    if (quit_lose == 1) {
        [self testalert:@"星星不足，不能挑戰下一關" msg:@"需要三顆星星"];
        quit_lose = 0;
    }
    NSLog(@"lose:%d",quit_lose);
    if (quit_stage != 0) {
        [self.view bringSubviewToFront:self.shadow];
        [self.view bringSubviewToFront:self.BigBk2C];
        [self.view bringSubviewToFront:self.BigBk2View];
        [self.view bringSubviewToFront:self.Download_View];
        
        self.BigBk2C.hidden = YES;
        self.BigBk2View.hidden = NO;
        stage = booknum;
        appDelegate.select_game = booknum;
        [self updateGameText:stage];
        [self updateBackgroundImage:stage];
        [self updateRateStarWithStages];
    }
    quit_stage = 0;
*/
    [self checkOSVersion];
//    if (osVersion == 8) {
//        [self.process_bg removeConstraints:self.process_bg.constraints];
/*
        [self.process_bg addConstraint:[NSLayoutConstraint constraintWithItem:self.process_bg
                                                         attribute:NSLayoutAttributeBottom
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.DL_finish
                                                         attribute:NSLayoutAttributeTop
                                                        multiplier:1.0
                                                          constant:10.0]];
*/
        /*
         CGRect newFrame;
         NSLog(@"org_process: %f, %f", self.process_bg.frame.origin.x, self.process_bg.frame.origin.y);
         newFrame = self.process_bg.frame;
         newFrame.origin.y += 50;
         //newFrame.size.height -= 50;
         self.process_bg.frame = newFrame;
         NSLog(@"new: %f, %f", newFrame.origin.x, newFrame.origin.y);
         NSLog(@"process: %f, %f", self.process_bg.frame.origin.x, self.process_bg.frame.origin.y);
        */
//    }
    //self.DL_process.layer.cornerRadius = 10;
    //self.DL_process.layer.masksToBounds = YES;
    //[self.DL_process.layer setBorderWidth:2.3];
    //[self.DL_process.layer setBorderColor:(__bridge CGColorRef)([UIColor colorWithRed:128/255 green:0 blue:255/255 alpha:1.0])];
    /*
    CAShapeLayer *layer = [CAShapeLayer layer];
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.process_bg.bounds byRoundingCorners:(UIRectCornerAllCorners) cornerRadii:CGSizeMake(20, 20.0)];
    layer.path = shadowPath.CGPath;
    self.DL_process.layer.mask = layer;
    */
    /*
    UIBezierPath *maskPath;
    maskPath = [UIBezierPath bezierPathWithRoundedRect:self.DL_process.bounds
                                     byRoundingCorners:(UIRectCornerBottomLeft | UIRectCornerBottomRight)
                                           cornerRadii:CGSizeMake(3.0, 3.0)];
    
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.DL_process.bounds;
    maskLayer.path = maskPath.CGPath;
    self.DL_process.layer.mask = maskLayer;
     */
    //[self.DL_process setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"bar_load_bg.png"]]];
    //self.DL_process.layer set
    //[self.DL_process setMaskView:self.process_bg];
}

- (void)checkFile:(int)file_num {
    testSize = YES;
    check_num = file_num;
    NSURL *checkUrl;
    switch (file_num) {
        case 1:
            checkUrl = [NSURL URLWithString:file1];
            self.zipName = @"stage1.zip";
            break;
        case 2:
            checkUrl = [NSURL URLWithString:file2];
            self.zipName = @"stage2.zip";
            break;
        case 3:
            checkUrl = [NSURL URLWithString:file3];
            self.zipName = @"stage3.zip";
            break;
        case 4:
            checkUrl = [NSURL URLWithString:file4];
            self.zipName = @"stage4.zip";
            break;
        case 5:
            checkUrl = [NSURL URLWithString:file5];
            self.zipName = @"stage5.zip";
            break;
        default:
            break;
    }
    NSURLRequest *request = [NSURLRequest requestWithURL: checkUrl];
    self.connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
    [self.connection start];

}

- (void)handleChecking:(int)checkNum {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    long current_size = [appDelegate getFileSize:checkNum];
    NSLog(@"current_size:%ld, server_size:%lld", current_size, server_file_size);
    check_num = checkNum;
    NSLog(@"check_num:%d",check_num);
    if (current_size == server_file_size && current_size != 0) {
        switch (checkNum) {
            case 1:
                //[self testalert:nil msg:@"handle one"];
                NSLog(@"zip 1 update");
                zip1 = YES;
                if (first_check1 == NO) {
                    [self handleBook1];
                }
                first_check1 = NO;
                break;
            case 2:
                NSLog(@"zip 2 update");
                zip2 = YES;
                [self handleBook2];
                break;
            case 3:
                NSLog(@"zip 3 update");
                zip3 = YES;
                [self handleBook3];
                break;
            case 4:
                NSLog(@"zip 4 update");
                zip4 = YES;
                [self handleBook4];
                break;
            case 5:
                NSLog(@"zip 5 update");
                zip5 = YES;
                [self handleBook5];
                break;
                
            default:
                break;
        }
        file_status = YES;
        NSLog(@"current_size:%ld, server_size:%lld", current_size, server_file_size);
        self.DL_percentage.text = @"0";
        self.DL_process.progress = 0;
        [self.connection cancel];
    } else {
        file_status = NO;
        NSLog(@"current_size:%ld, server_size:%lld", current_size, server_file_size);
        [self.connection cancel];
            switch (checkNum) {
                case 1:
//                    [self testalert:nil msg:@"fail one"];
                    [self Download1];
                    break;
                case 2:
//                    [self testalert:nil msg:@"fail two"];
                    [self Download2];
                    break;
                case 3:
//                    [self testalert:nil msg:@"fail three"];
                    [self Download3];
                    break;
                case 4:
//                    [self testalert:nil msg:@"fail four"];
                    [self Download4];
                    break;
                case 5:
//                    [self testalert:nil msg:@"fail five"];
                    [self Download5];
                    break;
                    
                default:
                    break;
        }
    }
}

- (BOOL)checkFileExists:(NSString *)unzipPath zipName:(NSString *)fileName {
    /*
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    //NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    NSString* unzip_path  = [NSString stringWithFormat:@"%@%@", documentsPath, unzipPath];
    //NSString* unzip_path  = [NSString stringWithFormat:@"%@%@", [[NSBundle mainBundle] bundlePath], unzipPath];
    NSString *zipPath = [documentsPath stringByAppendingPathComponent: fileName];
    NSLog(@"%@",zipPath);
    BOOL file_exist = [[NSFileManager defaultManager] fileExistsAtPath:zipPath];
     */
    /*
    
    file1 = @"http://apps.ywca.org.hk/AppDownload/stage1.zip";
    file2 = @"http://apps.ywca.org.hk/AppDownload/stage2.zip";
    file3 = @"http://apps.ywca.org.hk/AppDownload/stage3.zip";
    file4 = @"http://apps.ywca.org.hk/AppDownload/stage4.zip";
    file5 = @"http://apps.ywca.org.hk/AppDownload/stage5.zip";
    
    if ([fileName isEqualToString:@"stage1.zip"]) {
        self.url = [NSURL URLWithString:file1];
        check_num = 1;
    } else if ([fileName isEqualToString:@"stage2.zip"]) {
        self.url = [NSURL URLWithString:file2];
        check_num = 2;
    } else if ([fileName isEqualToString:@"stage3.zip"]) {
        self.url = [NSURL URLWithString:file3];
        check_num = 3;
    } else if ([fileName isEqualToString:@"stage4.zip"]) {
        self.url = [NSURL URLWithString:file4];
        check_num = 4;
    } else if ([fileName isEqualToString:@"stage5.zip"]) {
        self.url = [NSURL URLWithString:file5];
        check_num = 5;
    }
    self.zipName = fileName;
    BOOL file_exist = YES;
    zip_update = 0;
    //AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    testSize = YES;
    NSURLRequest *request = [NSURLRequest requestWithURL: self.url];
    self.connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
    [self.connection start];
    file_exist = !zip_update;
    NSLog(@"zip_update:%d",zip_update);
    NSLog(@"file_exist:%d",file_exist);
     */
    BOOL file_exist = YES;
    return file_exist;
}

- (void)viewDidDisappear:(BOOL)animated {
    //[self releaseObjects];
}

- (IBAction)back:(id)sender {
}

- (IBAction)bgm_off:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate playBgMusic];
    mBgm_off.hidden = YES;
    mBgm_on.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:1];
}

- (IBAction)bgm_on:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate stopBgMusic];
    mBgm_on.hidden = YES;
    mBgm_off.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:0];
}

- (IBAction)sound_off:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate updateSetting:@"item_sound" mode:1];
    self.sound_off.hidden = YES;
    self.sound_on.hidden = NO;
}

- (IBAction)sound_on:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate updateSetting:@"item_sound" mode:0];
    self.sound_on.hidden = YES;
    self.sound_off.hidden = NO;
}

- (IBAction)book1:(id)sender {
    NSLog(@"book1");
    [self enterBook1];
}

- (IBAction)book2:(id)sender {
    [self enterBook2];
}

- (IBAction)book3:(id)sender {
    [self enterBook3];
}

- (IBAction)book4:(id)sender {
    [self enterBook4];
}

- (IBAction)book5:(id)sender {
    [self enterBook5];
}

- (IBAction)game1:(id)sender {
    game = 1;
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.select_stage = 1;
    //NSLog(@"%d",appDelegate.select_stage);
}

- (IBAction)game2:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    game = 2;
    appDelegate.select_stage = 2;
    gameStarForMsg = [appDelegate getStarsInt:booknum game:1];
}

- (IBAction)game3:(id)sender {
    game = 3;
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.select_stage = 3;
    gameStarForMsg = [appDelegate getStarsInt:booknum game:2];
}

- (IBAction)game4:(id)sender {
    game = 4;
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.select_stage = 4;
    gameStarForMsg = [appDelegate getStarsInt:booknum game:3];
}

- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender {
    if ([identifier isEqualToString:@"Game2"] || [identifier isEqualToString:@"Game3"] || [identifier isEqualToString:@"Game4"]) {
        //NSLog(@"Segue Blocked");
        //Put your validation code here and return YES or NO as needed
        if(gameStarForMsg < 3) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"～星星不足～"
                                                            message:@"之前的關卡要取得三顆星星喔"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
            return NO;
        } else {
            return YES;
        }
    }
    
    return YES;
}

- (IBAction)BigBk2C:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    self.BigBk2C.hidden = YES;
    self.BigBk2View.hidden = NO;
    UIImage * toImage = [UIImage imageNamed:@"book_open.png"];
    [UIView transitionWithView:self.view
                      duration:0.8f
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.BigBk2 setImage:toImage forState:UIControlStateNormal];
                        [self.BigBk2 setImage:toImage forState:UIControlStateHighlighted];
                    } completion:NULL];
    stage = booknum;
    //NSLog(@"booknum===%d", booknum);
    appDelegate.select_game = booknum;
    [self updateGameText:stage];
    //[self updateStarbar:stage];
    [self updateBackgroundImage:stage];
    [self updateRateStarWithStages];
    //[self updateGameAlert:booknum];
}

- (void)updateGameText:(int)thisstage {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    gameStar1_int = [appDelegate getStarsInt:thisstage game:1];
    gameStar2_int = [appDelegate getStarsInt:thisstage game:2];
    gameStar3_int = [appDelegate getStarsInt:thisstage game:3];
    gameStar4_int = [appDelegate getStarsInt:thisstage game:4];
    
    if(gameStar4_int >= 3) {
        self.Game4_text.hidden = YES;
    } else {
        self.Game4_text.hidden = NO;
    }
    if(gameStar3_int >= 3) {
        self.Game3_text.hidden = YES;
    } else {
        self.Game3_text.hidden = NO;
    }
    if(gameStar2_int >= 3) {
        self.Game2_text.hidden = YES;
    } else {
        self.Game2_text.hidden = NO;
    }
    if(gameStar1_int >= 3) {
        self.Game1_text.hidden = YES;
    } else {
        self.Game1_text.hidden = NO;
    }
}

- (void)updateGameAlert:(int)thisstage {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    gameStar1_int = [appDelegate getStarsInt:thisstage game:1];
    gameStar2_int = [appDelegate getStarsInt:thisstage game:2];
    gameStar3_int = [appDelegate getStarsInt:thisstage game:3];
    gameStar4_int = [appDelegate getStarsInt:thisstage game:4];
    
    if(gameStar4_int < 3 && gameStar3_int < 3) {
        [self gameAlert:@"第三關要取得三顆星星喔"];
    } else {
    }
    if(gameStar3_int < 3 && gameStar2_int < 3) {
        [self gameAlert:@"第二關要取得三顆星星喔"];
    } else {
    }
    if(gameStar2_int < 3 && gameStar1_int < 3) {
        [self gameAlert:@"第一關要取得三顆星星喔"];
    } else {
    }
    if(gameStar1_int >= 3) {
    } else {
    }
}

- (void)gameAlert:(NSString*)msg {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"～星星不足～"
                                                    message:msg
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles: nil];
    [alert show];
}

- (void)updateStarbar:(int)thisstage {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    gameStar1_int = [appDelegate getStarsInt:thisstage game:1];
    gameStar2_int = [appDelegate getStarsInt:thisstage game:2];
    gameStar3_int = [appDelegate getStarsInt:thisstage game:3];
    gameStar4_int = [appDelegate getStarsInt:thisstage game:4];
    
    if(gameStar4_int < 3 && gameStar3_int < 3) {
        self.G4LightStar.hidden = YES;
        self.G4DarkStar.hidden = YES;
    } else {
        self.G4LightStar.hidden = NO;
        self.G4DarkStar.hidden = NO;
    }
    if(gameStar3_int < 3 && gameStar2_int < 3) {
        self.G3LightStar.hidden = YES;
        self.G3DarkStar.hidden = YES;
    } else {
        self.G3LightStar.hidden = NO;
        self.G3DarkStar.hidden = NO;
    }
    if(gameStar2_int < 3 && gameStar1_int < 3) {
        self.G2LightStar.hidden = YES;
        self.G2DarkStar.hidden = YES;
    } else {
        self.G2LightStar.hidden = NO;
        self.G2DarkStar.hidden = NO;
    }
    
}

- (void)updateBackgroundImage:(int)thisstage {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    gameStar1_int = [appDelegate getStarsInt:thisstage game:1];
    gameStar2_int = [appDelegate getStarsInt:thisstage game:2];
    gameStar3_int = [appDelegate getStarsInt:thisstage game:3];
    gameStar4_int = [appDelegate getStarsInt:thisstage game:4];
    
    switch (thisstage) {
        case 5:
            //NSLog(@"case===%d", thisstage);
            if(gameStar4_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s5_book_04.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
                //[self.BigBk2 setImage:Bigbookop forState:UIControlStateNormal];
            } else if (gameStar3_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s5_book_03.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar2_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s5_book_02.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar1_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s5_book_01.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else {
                Bigbookop = [UIImage imageNamed:@"book_open.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            }
            break;
        case 4:
            //NSLog(@"case===%d", thisstage);
            if(gameStar4_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s4_book_04.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar3_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s4_book_03.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar2_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s4_book_02.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar1_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s4_book_01.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else {
                Bigbookop = [UIImage imageNamed:@"book_open.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            }
            break;
        case 3:
            //NSLog(@"case===%d", thisstage);
            if(gameStar4_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s3_book_04.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar3_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s3_book_03.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar2_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s3_book_02.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar1_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s3_book_01.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else {
                Bigbookop = [UIImage imageNamed:@"book_open.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            }
            break;
        case 2:
            //NSLog(@"case===%d", thisstage);
            if(gameStar4_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"book_04.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar3_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"book_03.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar2_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"book_02.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else if (gameStar1_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"book_01.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            } else {
                Bigbookop = [UIImage imageNamed:@"book_open.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            }
            break;
        case 1:
            //NSLog(@"case===%d", thisstage);
            if(gameStar4_int >= 3) {
                // UIImage* image= [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",[NSBundle mainBundle].bundlePath,@"s1_book_04.png"]];
                Bigbookop = [UIImage imageNamed:@"s1_book_04.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
                //self.BigBk2.hidden=NO;
                //[self.view bringSubviewToFront:self.BigBk2];
                //[self.view setNeedsDisplay];
                //NSLog(@"gameStar4===%d", gameStar4_int);
            } else if (gameStar3_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s1_book_03.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
                //NSLog(@"gameStar3===%d", gameStar3_int);
            } else if (gameStar2_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s1_book_02.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
                //NSLog(@"gameStar2===%d", gameStar2_int);
            } else if (gameStar1_int >= 3) {
                Bigbookop = [UIImage imageNamed:@"s1_book_01.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
                //NSLog(@"gameStar1===%d", gameStar1_int);
            } else {
                Bigbookop = [UIImage imageNamed:@"book_open.png"];
                //[self.BigBk2.imageView setImage:Bigbookop];
            }
            break;
            
        default:
            Bigbookop = [UIImage imageNamed:@"book_open.png"];
            //[self.BigBk2.imageView setImage:Bigbookop];
            break;
    }
    [self.BigBk2 setImage:Bigbookop forState:UIControlStateNormal];
}

-(void)updateRateStarWithStages{
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    //Game 1 star
    stars = [appDelegate getStars:stage game:1];
    star_value = [stars intValue];
    [self updateStarByStage:1 andStarNo:star_value];
    //Game 2 star
    stars = [appDelegate getStars:stage game:2];
    star_value = [stars intValue];
    [self updateStarByStage:2 andStarNo:star_value];
    //Game 3 star
    stars = [appDelegate getStars:stage game:3];
    star_value = [stars intValue];
    [self updateStarByStage:3 andStarNo:star_value];
    //Game 4 star
    stars = [appDelegate getStars:stage game:4];
    star_value = [stars intValue];
    [self updateStarByStage:4 andStarNo:star_value];
}

-(void)updateStarByStage:(int)stageNo andStarNo:(int) starNo{
    int baseNo = 10*stageNo;
    
    NSArray* level1Views = [self.BigBk2View subviews];
    for (int i=0; i<level1Views.count; i++) {
        UIView* view = (UIView*)[level1Views objectAtIndex:i];
        //NSLog(@"level 1 class : %@",[view class]);
        if([view isMemberOfClass:UIView.class]){
            NSArray* level2Views = view.subviews;
            for(int j=0; j<level2Views.count; j++){
                UIView* l2view = (UIView*)[level2Views objectAtIndex:j];
                //NSLog(@"level 2 class : %@", l2view.class);
                
                if([l2view isMemberOfClass:UIView.class]){
                    NSArray* level3Views = l2view.subviews;
                    for(int k= 0;k<level3Views.count;k++){
                        UIView* l3view = (UIView*)[level3Views objectAtIndex:k];
                        //NSLog(@"level 3 class : %@", l3view.class);
                        
                        if([l3view isMemberOfClass:UIView.class]){
                            NSArray* level4Views = l3view.subviews;
                            for(int l= 0;l<level4Views.count;l++){
                                UIView* l4view = (UIView*)[level4Views objectAtIndex:l];
                                //NSLog(@"level 4 class : %@", l4view.class);
                                if([l4view isMemberOfClass:UIImageView.class]){
                                    
                                    if(l4view.tag>=baseNo && l4view.tag<=(baseNo+10)){
                                        if(l4view.tag<(baseNo+5)){
                                            if(l4view.tag<(baseNo+starNo)){
                                                l4view.hidden = false;
                                            }else{
                                                l4view.hidden = true;
                                            }
                                            
                                        }else{
                                            if(l4view.tag<(baseNo+5 +starNo)){
                                                l4view.hidden = true;
                                            }else{
                                                l4view.hidden = false;
                                            }
                                        }
                                        //NSLog(@"tag:%D, hidden%hhd",l4view.tag, l4view.hidden);
                                        
                                    }
                                    
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}



- (IBAction)BigBookClose:(id)sender {
    //marso update
    //[self hideOpenedBooks:NO];
    
    self.shadow.hidden = YES;
    self.BigBk2View.hidden = YES;
}

- (IBAction)DL1:(id)sender {
    [self enterBook1];
    //[self Download1];
}

- (IBAction)DL2:(id)sender {
    [self enterBook2];
    //[self Download2];
}

- (IBAction)DL3:(id)sender {
    [self enterBook3];
    //[self Download3];
}

- (IBAction)DL4:(id)sender {
    [self enterBook4];
    //[self Download4];
    //self.Download_View.hidden = NO;
    //self.DLing.hidden = YES;
}

- (IBAction)DL5:(id)sender {
    [self enterBook5];
    //[self Download5];
    //self.Download_View.hidden = NO;
    //self.DLing.hidden = YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"Game1"] || [segue.identifier isEqualToString:@"Game2"] || [segue.identifier isEqualToString:@"Game3"] || [segue.identifier isEqualToString:@"Game4"]) {
        Game *destViewController = segue.destinationViewController;
        destViewController.stage = stage;
        destViewController.game = game;
    }
}

- (void)downloadFiles {
    if([unziploc isEqual:nil]){
        unziploc = @"/";
    }
    NSURLRequest *request = [NSURLRequest requestWithURL: self.url];
    //    NSLog(@"url%@",self.url);
    self.connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
    //    [self.connection scheduleInRunLoop:[NSRunLoop mainRunLoop]
    //                          forMode:NSDefaultRunLoopMode];
    [self.connection start];
    //    NSLog(@"connection: %@", [self.connection debugDescription]);
    //    if (self.connection) {
    //        NSLog(@"Connection succeeded");
    //        NSLog(@"Is main thread %@", ([NSThread isMainThread] ? @"Yes" : @" NOT"));
    //    } else {
    //        NSLog(@"Connection failed");
    //    }
    //    NSLog(@"run downloads");
}
//TODO
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)urlResponse
{   //NSLog(@"run recevice");
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) urlResponse;
    NSDictionary *dict = httpResponse.allHeaderFields;
    NSString *lengthString = [dict valueForKey:@"Content-Length"];
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    NSNumber *length = [formatter numberFromString:lengthString];
    self.totalBytes = length.unsignedIntegerValue;
    
    server_file_size = [urlResponse expectedContentLength];
    
    if (server_file_size != 0 && testSize == YES) {
        NSLog(@"server_size:%lld", server_file_size);
        self.zipData = nil;
        [self handleChecking:check_num];
    }
    /*
    //NSLog(@"file size:%lld",server_file_size);
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSLog(@"check_num:%d",check_num);
    long current_size = [appDelegate getFileSize:check_num];
    if (testSize == YES) {
        if (current_size == server_file_size && current_size != 0) {
            zip_update = 0;
        } else {
            zip_update = 1;
        }
        if (check_num == 1 && zip_update == 1) {
            self.DL1.hidden = NO;
        } else if (check_num == 2 && zip_update == 1) {
            self.DL2.hidden = NO;
        } else if (check_num == 3 && zip_update == 1) {
            self.DL3.hidden = NO;
        } else if (check_num == 4 && zip_update == 1) {
            self.DL4.hidden = NO;
        } else if (check_num == 5 && zip_update == 1) {
            self.DL5.hidden = NO;
        }
        NSLog(@"current_size:%ld, server_size:%lld", current_size, server_file_size);
        testSize = NO;
        [self.connection cancel];
    }
    */
    
    if (self.totalBytes < 65536) {
        [self testalert:@"無法下載" msg:@"請聯絡開發商。"];
        self.Download_View.hidden = YES;
        self.start_DL.hidden = NO;
        self.DLing.hidden = NO;
        [self.connection cancel];
        self.DL_process.progress = 0.0;
    } else {
        self.receivedBytes = 0;
        //NSLog(@"totalBytes: %d", self.totalBytes);
        //NSLog(@"received: %d", self.receivedBytes);
        //NSLog(@"received float: %f", (float)self.receivedBytes);
        self.zipData = [[NSMutableData alloc] initWithCapacity:self.totalBytes];
        self.DL_percentage.text = @"0";
        self.DL_process.progress = 0.0;
        self.DL_cancel.hidden = NO;
        self.DL_finish.hidden = YES;
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{   //NSLog(@"run receice data");
    
    //NSLog(@"_totalBytes: %d", self.totalBytes);
    //NSLog(@"_received: %d", self.receivedBytes);
    //NSLog(@"_received float: %f", (float)self.receivedBytes);
    [self.zipData appendData:data];
    self.receivedBytes += data.length;
    
    self.DL_process.progress = (float)self.receivedBytes / self.totalBytes;
    self.DL_percentage.text = [NSString stringWithFormat:@"%@%@", [[NSNumber numberWithInteger:((float)self.receivedBytes / self.totalBytes) * 100] stringValue], @"%"];
    [self.DL_percentage setFont:[UIFont fontWithName:@"Helvetica Neue" size:percentage_font_size]];
    
    //NSLog(@"progress : %f", self.DL_process.progress);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{   //NSLog(@"run finish");
    //unziploc = @"/";
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    //NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    NSString* unzip_path  = [NSString stringWithFormat:@"%@%@", documentsPath, unziploc];
    //NSLog(@"unzip: %@",unzip_path);
    //NSString* unzip_path  = [NSString stringWithFormat:@"%@%@", [[NSBundle mainBundle] bundlePath], unziploc];
    NSString *zipPath = [documentsPath stringByAppendingPathComponent: self.zipName];
    //NSLog(@"zipPath: %@",zipPath);
    NSError *error = nil;
    [self.zipData writeToFile:zipPath options:NSDataWritingAtomic error:&error];
    NSLog(@"Write returned error: %@", [error localizedDescription]);
    
    //remove current folder
    [[NSFileManager defaultManager] removeItemAtPath:unzip_path error: &error];
    
    [self.zipData writeToFile:zipPath atomically:YES];
    // NSLog(@"%@",unzip_path);
    ZipArchive *za = [[ZipArchive alloc] init];
    if ([za UnzipOpenFile: zipPath]) {
        BOOL ret = [za UnzipFileTo: unzip_path overWrite: YES];
        if (NO == ret){} [za UnzipCloseFile];
        dispatch_async(dispatch_get_main_queue(), ^{
        });
    }
    //NSLog(@"%@",unzip_path);
    
    /*
    fileExists = [self checkFileExists:@"/" zipName:@"stage2.zip"];
    if(fileExists) {
        self.DL2.hidden = YES;
    }
    fileExists = [self checkFileExists:@"/" zipName:@"stage3.zip"];
    if(fileExists) {
        self.DL3.hidden = YES;
    }
    fileExists = [self checkFileExists:@"/" zipName:@"stage4.zip"];
    if(fileExists) {
        self.DL4.hidden = YES;
    }
    fileExists = [self checkFileExists:@"/" zipName:@"stage5.zip"];
    if(fileExists) {
        self.DL5.hidden = YES;
    }
     */
    
    //    self.DL1.hidden = YES;
    //    self.DL2.hidden = YES;z
    //    self.DL3.hidden = YES;
    //    self.DL4.hidden = YES;
    //    self.DL5.hidden = YES;
    //    gameExists = YES;
    //self.DL_process.progress = 0.0;
    self.DL_cancel.hidden = YES;
    self.DL_finish.hidden = NO;
    self.zipData = nil;
    //check file size & update database
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSError *attributesError = nil;
    NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:zipPath error:&attributesError];
    NSNumber *fileSizeNumber = [fileAttributes objectForKey:NSFileSize];
    long long fileSize = [fileSizeNumber longLongValue];
    if (check_num == 1) {
        [appDelegate updateData:@"ywca_setting" col_name:@"stage1_zip_size" data_id:1 value:fileSize];
    } else if (check_num == 2) {
        [appDelegate updateData:@"ywca_setting" col_name:@"stage2_zip_size" data_id:1 value:fileSize];
        self.DL2.hidden = YES;
    } else if (check_num == 3) {
        [appDelegate updateData:@"ywca_setting" col_name:@"stage3_zip_size" data_id:1 value:fileSize];
        self.DL3.hidden = YES;
    } else if (check_num == 4) {
        [appDelegate updateData:@"ywca_setting" col_name:@"stage4_zip_size" data_id:1 value:fileSize];
        self.DL4.hidden = YES;
    } else if (check_num == 5) {
        [appDelegate updateData:@"ywca_setting" col_name:@"stage5_zip_size" data_id:1 value:fileSize];
        self.DL5.hidden = YES;
    }
    //remove zip
    [[NSFileManager defaultManager] removeItemAtPath:zipPath error: &error];

}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"download fail");
    [self testalert:@"無法下載" msg:@"請檢查網絡連結"];
    self.Download_View.hidden = YES;
    self.start_DL.hidden = NO;
    self.DLing.hidden = NO;
    [self.connection cancel];
    self.DL_process.progress = 0.0;
    //handle error
}

- (IBAction)accept:(id)sender {
    self.start_DL.hidden = YES;
    self.DLing.hidden = NO;
    self.DL_finish.hidden = YES;
    [self downloadFiles];
}

- (IBAction)cancel:(id)sender {
    self.zipData = nil;
    self.Download_View.hidden = YES;
    self.start_DL.hidden = NO;
    self.DLing.hidden = YES;
    [self.connection cancel];
    self.DL_percentage.text = @"0";
    self.DL_process.progress = 0;
}

- (IBAction)DL_cancel:(id)sender {
    self.zipData = nil;
    self.Download_View.hidden = YES;
    self.start_DL.hidden = YES;
    self.DLing.hidden = YES;
    [self.connection cancel];
    self.DL_percentage.text = @"0";
    self.DL_process.progress = 0;
}

- (IBAction)DL_finish:(id)sender {
    self.zipData = nil;
    self.Download_View.hidden = YES;
    self.DL_percentage.text = @"0";
    self.DL_process.progress = 0;
}

- (IBAction)btn_rainbow1:(id)sender {
    UIViewController *arVC = [self.storyboard instantiateViewControllerWithIdentifier:@"StoryOneAR"];
    //UIViewController *arVC = [self.storyboard instantiateViewControllerWithIdentifier:@"StoryOneEcard"];
    [self presentViewController:arVC animated:YES completion:nil];
}

- (IBAction)btn_rainbow2:(id)sender {
    UIViewController *arVC = [self.storyboard instantiateViewControllerWithIdentifier:@"StoryTwoAR"];
    [self presentViewController:arVC animated:YES completion:nil];
}

- (IBAction)btn_rainbow3:(id)sender {
    UIViewController *arVC = [self.storyboard instantiateViewControllerWithIdentifier:@"StoryThreeAR"];
    [self presentViewController:arVC animated:YES completion:nil];
}

- (IBAction)btn_rainbow4:(id)sender {
    UIViewController *arVC = [self.storyboard instantiateViewControllerWithIdentifier:@"StoryFourAR"];
    [self presentViewController:arVC animated:YES completion:nil];
}

- (IBAction)btn_cs1:(id)sender {
    /*
     self.shadow.hidden = NO;
     self.BigBk2C.hidden = NO;
     booknum = 1;
     BigbookC = [UIImage imageNamed:@"s1_book_top.png"];
     [self.BigBk2C.imageView setImage:BigbookC];
     */
}

- (IBAction)btn_cs2:(id)sender {
    /*
     self.shadow.hidden = NO;
     self.BigBk2C.hidden = NO;
     booknum = 2;
     BigbookC = [UIImage imageNamed:@"book_top.png"];
     [self.BigBk2C.imageView setImage:BigbookC];
     */
}

- (IBAction)btn_cs3:(id)sender {
    /*
     self.shadow.hidden = NO;
     self.BigBk2C.hidden = NO;
     booknum = 3;
     BigbookC = [UIImage imageNamed:@"s3_book_top.png"];
     [self.BigBk2C.imageView setImage:BigbookC];
     */
}

- (IBAction)btn_cs4:(id)sender {
    /*
     self.shadow.hidden = NO;
     self.BigBk2C.hidden = NO;
     booknum = 4;
     BigbookC = [UIImage imageNamed:@"s4_book_top.png"];
     [self.BigBk2C.imageView setImage:BigbookC];
     */
}

- (IBAction)btn_cs5:(id)sender {
}

/*
 - (void)showbook {
 fileExists = [self checkFileExists:@"/" zipName:@"Story_02.zip"];
 AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
 int pass = [appDelegate getPass:stage];
 int finalgame_star = [appDelegate getStarsInt:stage game:4];
 if(pass == 1 && finalgame_star > 0 && fileExists == YES) {
 //    if(gameExists == YES) {
 self.shadow.hidden = NO;
 self.BigBk2C.hidden = NO;
 booknum = 2;
 //BigbookC = [UIImage imageNamed:@"book_top.png"];
 //[self.BigBk2C.imageView setImage:BigbookC];
 //self.BigBk2C.imageView.image = BigbookC;
 UIImage * toImage = [UIImage imageNamed:@"book_top.png"];
 [UIView transitionWithView:self.view
 duration:0.8f
 options:UIViewAnimationOptionTransitionCrossDissolve
 animations:^{
 [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
 [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
 } completion:NULL];
 } else if(fileExists == NO) {
 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"檔案不存在"
 message:@"請先下載關卡二"
 delegate:self
 cancelButtonTitle:@"OK"
 otherButtonTitles: nil];
 [alert show];
 } else if (fileExists == YES) {
 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
 message:@"請先破關卡一"
 delegate:self
 cancelButtonTitle:@"OK"
 otherButtonTitles: nil];
 [alert show];
 }
 }
 */

- (void)cs1tap:(UITapGestureRecognizer *)recognizer {
    [self enterBook1];
}

- (void)cs2tap:(UITapGestureRecognizer *)recognizer {
    [self enterBook2];
}

- (void)cs3tap:(UITapGestureRecognizer *)recognizer {
    [self enterBook3];
}

- (void)cs4tap:(UITapGestureRecognizer *)recognizer {
    [self enterBook4];
}

- (void)cs5tap:(UITapGestureRecognizer *)recognizer {
    [self enterBook5];
}

- (void)enterBook1 {
    //fileExists = [self checkFileExists:@"/" zipName:@"baseFiles.zip"];
    //fileExists = [self checkFileExists:@"/" zipName:@"stage1"];
    file_status = NO;
    if ([self checkConnection] != 0) {
        [self checkFile:1];
    } else {
        //[self testalert:@"無網絡" msg:@"不能檢查更新"];
        [self handleBook1];
    }
    /*
        if(zip1 == YES) {
            self.shadow.hidden = NO;
            self.BigBk2C.hidden = NO;
            booknum = 1;
            //BigbookC = [UIImage imageNamed:@"s1_book_top.png"];
            //[self.BigBk2C.imageView setImage:BigbookC];
            //self.BigBk2C.imageView.image = BigbookC;
            UIImage * toImage = [UIImage imageNamed:@"s1_book_top.png"];
            [UIView transitionWithView:self.view
                              duration:0.8f
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^{
                                [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                                [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                            } completion:NULL];
        } else {
     
//             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"遊戲檔案不存在"
//             message:@"請先下載基礎關卡"
//             delegate:self
//             cancelButtonTitle:@"OK"
//             otherButtonTitles: nil];
//             [alert show];
     
            [self testalert:nil msg:@"關卡一有更新"];
            //[self Download1];
        }
*/
}

- (void)handleBook1 {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    double file_size = [appDelegate getFileSize:1];
    if(zip1 == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 1;
        //BigbookC = [UIImage imageNamed:@"s1_book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        
        UIImage * toImage = [UIImage imageNamed:@"s1_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
        
    } else if (file_size > 1500){
        //[self testalert:nil msg:@"關卡一有更新"];
        
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 1;
        //BigbookC = [UIImage imageNamed:@"s1_book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        
        UIImage * toImage = [UIImage imageNamed:@"s1_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else {
        /*
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"遊戲檔案不存在"
         message:@"請先下載基礎關卡"
         delegate:self
         cancelButtonTitle:@"OK"
         otherButtonTitles: nil];
         [alert show];
         */
        [self testalert:@"無網絡" msg:@"不能下載新關卡"];
        //[self Download1];
    }
}

- (void)enterBook2 {
    //fileExists = [self checkFileExists:@"/" zipName:@"stage2.zip"];
    //fileExistsBase = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //fileExists = YES;
    //fileExistsBase = YES;
//    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
//    int pass = [appDelegate getPass:1];
//    int finalgame_star = [appDelegate getStarsInt:1 game:4];
//    NSLog(@"fe: %d, feb: %d",fileExists,fileExistsBase);
//    int AR = [appDelegate getARfinish:1];
    //if(pass == 1 && finalgame_star > 0 && fileExists == YES && fileExistsBase == YES && AR == 1) {
    file_status = NO;
    if ([self checkConnection] != 0) {
        [self checkFile:2];
    } else {
        //[self testalert:@"無網絡" msg:@"不能檢查更新"];
        [self handleBook2];
    }
    /*
        if(pass == 1 && finalgame_star > 0 && zip2 == YES && AR == 1) {
            //    if(gameExists == YES) {
            self.shadow.hidden = NO;
            self.BigBk2C.hidden = NO;
            booknum = 2;
            //BigbookC = [UIImage imageNamed:@"book_top.png"];
            //[self.BigBk2C.imageView setImage:BigbookC];
            //self.BigBk2C.imageView.image = BigbookC;
            UIImage * toImage = [UIImage imageNamed:@"book_top.png"];
            [UIView transitionWithView:self.view
                              duration:0.8f
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^{
                                [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                                [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                            } completion:NULL];
            //} else if(fileExists == NO && fileExistsBase == YES) {
             } else if(zip2 == NO) {
            
//             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"檔案不存在"
//             message:@"請先下載關卡二"
//             delegate:self
//             cancelButtonTitle:@"OK"
//             otherButtonTitles: nil];
//             [alert show];
             
                 [self testalert:nil msg:@"關卡二有更新"];
                 //[self Download2];
            
//        } else if ((fileExists == NO && fileExistsBase == NO) || (fileExists == YES && fileExistsBase == NO)) {
//             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"遊戲檔案不存在"
//             message:@"請先下載基礎關卡"
//             delegate:self
//             cancelButtonTitle:@"OK"
//             otherButtonTitles: nil];
//             [alert show];
//            [self Download1];
            
        } else if (zip2 == YES) {
            if (AR == 0) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                                message:@"請先完成關卡一AR"
                                                               delegate:self
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles: nil];
                [alert show];
            } else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                                message:@"請先破關卡一"
                                                               delegate:self
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles: nil];
                [alert show];
            }
        }
    }
*/
}

- (void)handleBook2 {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    double file_size = [appDelegate getFileSize:2];
    int pass = [appDelegate getPass:1];
    int finalgame_star = [appDelegate getStarsInt:1 game:4];
    NSLog(@"fe: %d, feb: %d",fileExists,fileExistsBase);
    int AR = [appDelegate getARfinish:1];
    NSLog(@"pass:%d, finalstar:%d",pass, finalgame_star);
    if(pass == 1 && finalgame_star > 0 && zip2 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 2;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
        //} else if(fileExists == NO && fileExistsBase == YES) {
    } else if (finalgame_star == 0 || AR == 0) {
        NSLog(@"pass:%d, finalstar:%d",pass, finalgame_star);
        if ([self checkConnection] == 0 && file_size < 1500) {
          [self testalert:@"無網絡" msg:@"不能下載新關卡"];
        } else if (AR == 0 && finalgame_star > 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡一AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡一"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    } else if (file_size > 1500 && finalgame_star != 0){
        //[self testalert:nil msg:@"關卡二有更新"];
        
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 2;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else {
        [self testalert:@"無網絡" msg:@"不能下載新關卡"];
    }
}

- (void)enterBook3 {
//    fileExists = [self checkFileExists:@"/" zipName:@"stage3.zip"];
//    fileExistsBase = [self checkFileExists:@"/" zipName:@"stage1.zip"];
//    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
//    int pass = [appDelegate getPass:2];
//    int finalgame_star = [appDelegate getStarsInt:2 game:4];
//    int AR = [appDelegate getARfinish:2];
    file_status = NO;
    if ([self checkConnection] != 0) {
        [self checkFile:3];
    } else {
        //[self testalert:@"無網絡" msg:@"不能檢查更新"];
        [self handleBook3];
    }
    //NSLog(@"0.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
    /*
    if(pass == 1 && finalgame_star > 0 && zip3 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 3;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s3_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else if(zip3 == NO) {
        //NSLog(@"1.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
        
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"檔案不存在"
//         message:@"請先下載關卡三"
//         delegate:self
//         cancelButtonTitle:@"OK"
//         otherButtonTitles: nil];
//         [alert show];
        
        [self testalert:nil msg:@"關卡三有更新"];
        //[self Download3];
        
//    } else if ((fileExists == NO && fileExistsBase == NO) || (fileExists == YES && fileExistsBase == NO)) {
//        //NSLog(@"2.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"遊戲檔案不存在"
//         message:@"請先下載基礎關卡"
//         delegate:self
//         cancelButtonTitle:@"OK"
//         otherButtonTitles: nil];
//         [alert show];
//        [self Download1];
        
    }else if (zip3 == YES) {
        if (AR == 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡二AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            //NSLog(@"3.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡二"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    }
     */
}

- (void)handleBook3 {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    double file_size = [appDelegate getFileSize:3];
    int pass = [appDelegate getPass:2];
    int finalgame_star = [appDelegate getStarsInt:2 game:4];
    int AR = [appDelegate getARfinish:2];
    NSLog(@"finalStar:%d, file_size:%f",finalgame_star, file_size);
    if(pass == 1 && finalgame_star > 0 && zip3 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 3;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s3_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    }else if (finalgame_star == 0 || AR == 0) {
        if ([self checkConnection] == 0  && file_size < 1500) {
            [self testalert:@"無網絡" msg:@"不能下載新關卡"];
        } else if (AR == 0 && finalgame_star > 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡二AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            //NSLog(@"3.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡二"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    } else if (file_size > 1500 && finalgame_star != 0){
        //[self testalert:nil msg:@"關卡三有更新"];
        
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 3;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s3_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else {
        [self testalert:@"無網絡" msg:@"不能下載新關卡"];
    }

}

- (void)enterBook4 {
    //fileExists = [self checkFileExists:@"/" zipName:@"stage4.zip"];
    //fileExistsBase = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //fileExists = YES; //toRemove: for not download
//     AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
//    int pass = [appDelegate getPass:3];
//    int finalgame_star = [appDelegate getStarsInt:3 game:4];
//    int AR = [appDelegate getARfinish:3];
    file_status = NO;
    if ([self checkConnection] != 0) {
        [self checkFile:4];
    } else {
        //[self testalert:@"無網絡" msg:@"不能檢查更新"];
        [self handleBook4];
    }
    //NSLog(@"0.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
    /*
    if(pass == 1 && finalgame_star > 0 && zip4 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 4;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s4_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else if(zip4 == NO) {
        
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"檔案不存在"
//         message:@"請先下載關卡四"
//         delegate:self
//         cancelButtonTitle:@"OK"
//         otherButtonTitles: nil];
//         [alert show];
        
        [self testalert:nil msg:@"關卡四有更新"];
        //[self Download4];
        
//    } else if ((fileExists == NO && fileExistsBase == NO) || (fileExists == YES && fileExistsBase == NO)) {
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"遊戲檔案不存在"
//         message:@"請先下載基礎關卡"
//         delegate:self
//         cancelButtonTitle:@"OK"
//         otherButtonTitles: nil];
//         [alert show];
//        [self Download1];
        
    }else if (zip4 == YES) {
        if (AR == 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡三AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡三"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    }
     */
}

- (void)handleBook4 {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    double file_size = [appDelegate getFileSize:4];
    int pass = [appDelegate getPass:3];
    int finalgame_star = [appDelegate getStarsInt:3 game:4];
    int AR = [appDelegate getARfinish:3];
    
    if(pass == 1 && finalgame_star > 0 && zip4 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 4;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s4_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
        
    }else if (finalgame_star == 0 || AR == 0) {
        if ([self checkConnection] == 0 && file_size < 1500) {
            [self testalert:@"無網絡" msg:@"不能下載新關卡"];
        } else if (AR == 0 && finalgame_star > 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡三AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡三"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    } else if (file_size > 1500 && finalgame_star != 0){
        //[self testalert:nil msg:@"關卡四有更新"];
        
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 4;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s4_book_top.png"];
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else {
        [self testalert:@"無網絡" msg:@"不能下載新關卡"];
    }

}

- (void)enterBook5 {
    //fileExists = [self checkFileExists:@"/" zipName:@"stage5.zip"];
    //fileExistsBase = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //fileExists = YES; //toRemove: for not download
//    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
//    int pass = [appDelegate getPass:4];
//    int finalgame_star = [appDelegate getStarsInt:4 game:4];
//    int AR = [appDelegate getARfinish:4];
    file_status = NO;
    if ([self checkConnection] != 0) {
        [self checkFile:5];
    } else {
        //[self testalert:@"無網絡" msg:@"不能檢查更新"];
        [self handleBook5];
    }
    //NSLog(@"0.fileExists: %d, fileBase: %d",fileExists,fileExistsBase);
    /*
    if(pass == 1 && finalgame_star > 0 && zip5 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 5;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s5_book_top.png"];
        
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else if(zip5 == NO) {
        
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"檔案不存在"
//         message:@"請先下載關卡五"
//         delegate:self
//         cancelButtonTitle:@"OK"
//         otherButtonTitles: nil];
//         [alert show];
        
        [self testalert:nil msg:@"關卡五有更新"];
        //[self Download5];
        
//    } else if ((fileExists == NO && fileExistsBase == NO) || (fileExists == YES && fileExistsBase == NO)) {
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"遊戲檔案不存在"
//         message:@"請先下載基礎關卡"
//         delegate:self
//         cancelButtonTitle:@"OK"
//         otherButtonTitles: nil];
//         [alert show];
//        [self Download1];
        
    }else if (zip5 == YES) {
        if (AR == 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡四AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡四"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    }
     */
    /*
     if(gameExists == YES) {
     self.shadow.hidden = NO;
     self.BigBk2C.hidden = NO;
     booknum = 5;
     //BigbookC = [UIImage imageNamed:@"top_char4.png"];
     //[self.BigBk2C.imageView setImage:BigbookC];
     UIImage * toImage = [UIImage imageNamed:@"s5_book_top"];
     [UIView transitionWithView:self.view
     duration:0.8f
     options:UIViewAnimationOptionTransitionCrossDissolve
     animations:^{
     [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
     [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
     } completion:NULL];
     } else {
     UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"請期待更新"
     message:@"～遊戲開發中～"
     delegate:self
     cancelButtonTitle:@"OK"
     otherButtonTitles: nil];
     [alert show];
     }
     */
}

- (void)handleBook5 {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    double file_size = [appDelegate getFileSize:5];
    int pass = [appDelegate getPass:4];
    int finalgame_star = [appDelegate getStarsInt:4 game:4];
    int AR = [appDelegate getARfinish:4];
    
    if(pass == 1 && finalgame_star > 0 && zip5 == YES && AR == 1) {
        //    if(gameExists == YES) {
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 5;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s5_book_top.png"];
        
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    }else if (finalgame_star == 0 || AR == 0) {
        if ([self checkConnection] == 0 && file_size < 1500) {
            [self testalert:@"無網絡" msg:@"不能下載新關卡"];
        } else if (AR == 0 && finalgame_star > 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒完成AR"
                                                            message:@"請先完成關卡四AR"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"還沒破關"
                                                            message:@"請先破關卡四"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
        }
    } else if (file_size > 1500 && finalgame_star != 0){
        //[self testalert:nil msg:@"關卡五有更新"];
        
        self.shadow.hidden = NO;
        self.BigBk2C.hidden = NO;
        booknum = 5;
        //BigbookC = [UIImage imageNamed:@"book_top.png"];
        //[self.BigBk2C.imageView setImage:BigbookC];
        //self.BigBk2C.imageView.image = BigbookC;
        UIImage * toImage = [UIImage imageNamed:@"s5_book_top.png"];
        
        [UIView transitionWithView:self.view
                          duration:0.8f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            [self.BigBk2C setImage:toImage forState:UIControlStateNormal];
                            [self.BigBk2C setImage:toImage forState:UIControlStateHighlighted];
                        } completion:NULL];
    } else {
        [self testalert:@"無網絡" msg:@"不能下載新關卡"];
    }
}

- (void)Download1 {
    testSize = NO;
    //self.zipName = @"baseFiles.zip";
    self.zipName = @"stage1.zip";
    //self.DL_percentage.text = @"0";
    //self.DL_process.progress = 0;
    //self.url = [NSURL URLWithString:@"http://downloads.kanhan.com/YWCA/AppDownload/baseFiles.ios.zip"];
    self.url = [NSURL URLWithString:file1];
    self.DL_Text1.text = [NSString stringWithFormat:@"%@%.1f%@", @"請按\"確認\"以下載基礎關卡 (估計", size1, @" MB) 下載時可能會產生流動數據費用，建議使用Wi-Fi進行下載。"];
    [self.DL_Text1 setTextAlignment:NSTextAlignmentCenter];
    [self.DL_Text1 setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
    self.DLing_text.text = [NSString stringWithFormat:@"%@%.1f%@", @"關卡下載中 (估計", size1, @" MB)"];
    [self.DLing_text setTextAlignment:NSTextAlignmentCenter];
    [self.DLing_text setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
    unziploc = @"/stage1/";
    
    NSLog(@"dl_fin: %p",self.DL_finish);
    NSLog(@"dl_can: %p",self.DL_cancel);
    NSLog(@"dl_process: %p",self.DL_process);
    NSLog(@"dl_bg: %p",self.DL_bg);
    
    if (self.DLing.hidden == NO) {
        self.DLing.hidden = YES;
    }
    else {
        NSLog(@"dling_view hide");
    }
    
    if (self.Download_View.hidden == YES) {
        //self.Download_View.alpha = 0.99;
        self.Download_View.hidden = NO;
        NSLog(@"dl_view hide");
    }
    else {
        NSLog(@"dl_view not hide");
    }
    
    //self.Download_View.hidden = NO;
    
    if (self.start_DL.hidden == YES) {
        self.start_DL.hidden = NO;
    }
    else {
        NSLog(@"stdl_view not hide");
    }
    
    
}

- (void)Download2 {
    testSize = NO;
    //fileExists = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //NSLog(@"fileExists1: %d",fileExists);
    //if (file_status == NO) {
        self.zipName = @"stage2.zip";
        //self.DL_percentage.text = @"0";
        //self.DL_process.progress = 0;
        self.url = [NSURL URLWithString:file2];
        self.DL_Text1.text = [NSString stringWithFormat:@"%@%.1f%@", @"請按\"確認\"以下載第二關 (估計", size2, @" MB) 下載時可能會產生流動數據費用， 建議使用Wi-Fi進行下載。"];
        [self.DL_Text1 setTextAlignment:NSTextAlignmentCenter];
        [self.DL_Text1 setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        self.DLing_text.text = [NSString stringWithFormat:@"%@%.1f%@", @"關卡下載中 (估計", size2, @" MB)"];
        [self.DLing_text setTextAlignment:NSTextAlignmentCenter];
        [self.DLing_text setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        unziploc = @"/stage2/";
        self.Download_View.hidden = NO;
        self.start_DL.hidden = NO;
        self.DLing.hidden = YES;
    //}
}

- (void)Download3 {
    testSize = NO;
    //fileExists = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //if (fileExists) {
        self.zipName = @"stage3.zip";
        //self.DL_percentage.text = @"0";
        //self.DL_process.progress = 0;
        self.url = [NSURL URLWithString:file3];
        self.DL_Text1.text = [NSString stringWithFormat:@"%@%.1f%@", @"請按\"確認\"以下載第三關 (估計", size3, @" MB) 下載時可能會產生流動數據費用， 建議使用Wi-Fi進行下載。"];
        [self.DL_Text1 setTextAlignment:NSTextAlignmentCenter];
        [self.DL_Text1 setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        self.DLing_text.text = [NSString stringWithFormat:@"%@%.1f%@", @"關卡下載中 (估計", size3, @" MB)"];
        [self.DLing_text setTextAlignment:NSTextAlignmentCenter];
        [self.DLing_text setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        unziploc = @"/stage3/";
        self.Download_View.hidden = NO;
        self.start_DL.hidden = NO;
        self.DLing.hidden = YES;
    //}
}

- (void)Download4 {
    testSize = NO;
    //fileExists = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //if (fileExists) {
        self.zipName = @"stage4.zip";
        //self.DL_percentage.text = @"0";
        //self.DL_process.progress = 0;
        self.url = [NSURL URLWithString:file4];
        self.DL_Text1.text = [NSString stringWithFormat:@"%@%.1f%@", @"請按\"確認\"以下載第四關 (估計", size4, @" MB) 下載時可能會產生流動數據費用， 建議使用Wi-Fi進行下載。"];
        [self.DL_Text1 setTextAlignment:NSTextAlignmentCenter];
        [self.DL_Text1 setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        self.DLing_text.text = [NSString stringWithFormat:@"%@%.1f%@", @"關卡下載中 (估計", size4, @" MB)"];
        [self.DLing_text setTextAlignment:NSTextAlignmentCenter];
        [self.DLing_text setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        unziploc = @"/stage4/";
        self.Download_View.hidden = NO;
        self.start_DL.hidden = NO;
        self.DLing.hidden = YES;
    //}
}

- (void)Download5 {
    testSize = NO;
    //fileExists = [self checkFileExists:@"/" zipName:@"stage1.zip"];
    //if (fileExists) {
        self.zipName = @"stage5.zip";
        //self.DL_percentage.text = @"0";
        //self.DL_process.progress = 0;
        self.url = [NSURL URLWithString:file5];
        self.DL_Text1.text = [NSString stringWithFormat:@"%@%.1f%@",@"請按\"確認\"以下載第五關 (估計", size5, @" MB) 下載時可能會產生流動數據費用， 建議使用Wi-Fi進行下載。" ];
        [self.DL_Text1 setTextAlignment:NSTextAlignmentCenter];
        [self.DL_Text1 setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        self.DLing_text.text = [NSString stringWithFormat:@"%@%.1f%@", @"關卡下載中 (估計",size5,@" MB)"];
        [self.DLing_text setTextAlignment:NSTextAlignmentCenter];
        [self.DLing_text setFont:[UIFont fontWithName:@"Helvetica Neue" size:alert_font_size]];
        unziploc = @"/stage5/";
        self.Download_View.hidden = NO;
        self.start_DL.hidden = NO;
        self.DLing.hidden = YES;
    //}
}

- (void)testalert:(NSString*)title msg:(NSString*)msg {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:msg
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles: nil];
    [alert show];
}

- (void)releaseObjects {
    self.bg = nil;
    self.book1 = nil;
    self.book2 = nil;
    self.book3 = nil;
    self.book4 = nil;
    self.book5 = nil;
    self.DL1 = nil;
    self.DL2 = nil;
    self.DL3 = nil;
    self.DL4 = nil;
    self.DL5 = nil;
    self.main_char = nil;
    self.customStory1 = nil;
    self.customStory2 = nil;
    self.customStory3 = nil;
    self.customStory4 = nil;
    self.customStory5 = nil;
    self.btn_rainbow1 = nil;
    self.btn_rainbow2 = nil;
    self.btn_rainbow3 = nil;
    self.btn_rainbow4 = nil;
    self.bgm_on = nil;
    self.bgm_off = nil;
    self.btn_back = nil;
    self.sound_off = nil;
    self.sound_on = nil;
    //    self.shadow = nil;
    //    self.BigBk2 = nil;
    //    self.BigBk2C = nil;
    //    self.BigBkClose = nil;
    //    self.BigBk2View = nil;
    //    self.DL_bg = nil;
    //    self.DL_cancel = nil;
    //    self.DL_finish = nil;
    //    self.accept = nil;
    //    self.cancel = nil;
    //    self.DL_percentage = nil;
    //    self.DL_process = nil;
    //    self.DL_Text1 = nil;
    //    self.DLing_bg = nil;
    //    self.DLing_text = nil;
    //    self.DLing = nil;
    //    self.Download_View = nil;
    
}

- (void)checkOSVersion {
    NSString *version = [[UIDevice currentDevice] systemVersion];
    BOOL less8 = [version floatValue] < 8.0;
    BOOL ios8 = [version floatValue] >= 8.0;
    if (less8) {
        NSLog(@"os version <= ios7");
        osVersion = 7;
    }
    else if (ios8) {
        NSLog(@"os version >= ios8");
        osVersion = 8;
    }
}

- (int)checkConnection {
    //Reachability framework
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNetworkChange:) name:kReachabilityChangedNotification object:nil];
    
    reachability = [Reachability reachabilityForInternetConnection];
    [reachability startNotifier];
    
    NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
    
    int connection = 0;
    
    if(remoteHostStatus == NotReachable) {
        NSLog(@"no internet connection");
        connection = 0;
        appStatus = @"noCon";
    }
    else if (remoteHostStatus == ReachableViaWiFi) {
        NSLog(@"Wifi connection");
        connection = 1;
        appStatus = @"wifiCon";
    }
    else if (remoteHostStatus == ReachableViaWWAN) {
        NSLog(@"3G or 4G connection");
        connection = 2;
        appStatus = @"dataCon";
    }
    
    return connection;

}

- (void) handleNetworkChange:(NSNotification *)notice
{
    
    NetworkStatus remoteHostStatus = [reachability currentReachabilityStatus];
    
    if(remoteHostStatus == NotReachable) {NSLog(@"no internet connection");}
    else if (remoteHostStatus == ReachableViaWiFi) {NSLog(@"Wifi connection"); }
    else if (remoteHostStatus == ReachableViaWWAN) {NSLog(@"3G or 4G connection"); }
}


@end
