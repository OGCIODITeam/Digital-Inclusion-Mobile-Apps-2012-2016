//
//  openBookView.m
//  YWCA
//
//  Created by Benny SYW on 11/12/14.
//
//

#import "openBookView.h"
#import "GameViewController.h"

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

int pass, finalgame_star, game_star;
NSString *file;
NSLayoutConstraint *constraint;

@implementation openBookView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if(self) {
        CGRect org_custom_frame;
        if (IS_IPAD) {
            
//            constraint = [NSLayoutConstraint constraintWithItem:self.bookview attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem: nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0f constant:242.0f];
//            
//            [self.bookview addConstraint:constraint];
//             
//            constraint = [NSLayoutConstraint constraintWithItem:self.bookview attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem: nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0f constant:145.0f];
//            
//            [self.bookview addConstraint:constraint];
            
        }
        
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self) {
        //cannit load below
        /*
        //file = [[NSBundle mainBundle] pathForResource:@"star_off" ofType:@"png"];
        file = @"star_off.png";
        self.ds1.image = [UIImage imageNamed:file];
        self.ds2.image = [UIImage imageNamed:file];
        self.ds3.image = [UIImage imageNamed:file];
        self.ds4.image = [UIImage imageNamed:file];
        self.ds5.image = [UIImage imageNamed:file];
        //file = [[NSBundle mainBundle] pathForResource:@"star_on" ofType:@"png"];
        file = @"star_on.png";
        self.ls1.image = [UIImage imageNamed:file];
        self.ls2.image = [UIImage imageNamed:file];
        self.ls3.image = [UIImage imageNamed:file];
        self.ls4.image = [UIImage imageNamed:file];
        self.ls5.image = [UIImage imageNamed:file];
        file = @"main_done.png";
        self.bookdone.image = [UIImage imageNamed:file];
        */
        //load interface file from .xib
        if (IS_IPAD) {
            CGRect newFrame;
            newFrame.size.width = 400;
            newFrame.size.height = 400;
            [self.bookbtn setFrame:newFrame];
            //self.bookview.frame = newFrame;
            NSLog(@"newFrame: %f,%f",newFrame.size.width,newFrame.size.height);
            NSLog(@"Frame: %f,%f",self.bookbtn.frame.size.width,self.bookbtn.frame.size.height);
            [[NSBundle mainBundle] loadNibNamed:@"openBookView_iPad" owner:self options:nil];
        } else {
            [[NSBundle mainBundle] loadNibNamed:@"openBookView" owner:self options:nil];
        }
        //add as a subview
        [self addSubview:self.bookview];
    }
    return self;
}

- (void)setStarsWithStage:(int)stage {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    game_star = [appDelegate getStageStarsInt:stage];
    //game_star =3;
    //dark star
    if(game_star == 5) {
        self.ds5.hidden = YES;
    }
    if(game_star >= 4) {
        self.ds4.hidden = YES;
    }
    if(game_star >= 3) {
        self.ds3.hidden = YES;
    }
    if(game_star >= 2) {
        self.ds2.hidden = YES;
    }
    if(game_star >= 1) {
        self.ds1.hidden =YES;
    }
    //light star
    if(game_star == 0 ){
        self.ls1.hidden = YES;
    }
    if(game_star <= 1 ) {
        self.ls2.hidden = YES;
    }
    if(game_star <= 2) {
        self.ls3.hidden = YES;
    }
    if(game_star <= 3) {
        self.ls4.hidden = YES;
    }
    if(game_star <= 4) {
        self.ls5.hidden = YES;
    }
    NSLog(@"setStar");
}

- (void)setDoneWithStage:(int)stage {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    pass = [appDelegate getPass:stage];
    finalgame_star = [appDelegate getStarsInt:stage game:4];
    //pass = 1;
    //finalgame_star = 1;
    if (pass == 1 && finalgame_star >=1) {
        self.bookdone.hidden = NO;
    } else {
        self.bookdone.hidden = YES;
    }
    NSLog(@"setDone");
}

- (IBAction)btn_book:(id)sender {
    //NSLog(@"xib btn click");
}

@end
