//
//  UIHelper.m
//  DBTREE
//
//  Created by Marshals Chan on 21/12/14.
//  Copyright (c) 2014 Alvis Ching. All rights reserved.
//


#import "UIHelper.h"


@implementation UIHelper

+ (CGSize)getScreenSize{
    return [[UIScreen mainScreen] bounds].size;
}


+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    //UIGraphicsBeginImageContext(newSize);
    // In next line, pass 0.0 to use the current device's pixel scaling factor (and thus account for Retina resolution).
    // Pass 1.0 to force exact pixel size.
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+ (UIImage*)imageWithUrlString:(NSString*) url{
    // Download the image
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    // Make an UIImage out of it
    return[UIImage imageWithData:imageData];
}

+ (UIImage*)localizedImage:(NSString*)imageName andType:(NSString*)type{
    return [UIImage imageWithContentsOfFile:[DataHelper getLocalizedImagePath:imageName andType:type]];
}

+ (UIImage*)imageByCombiningImage:(UIImage*)firstImage withImage:(UIImage*)secondImage {
    UIImage *image = nil;
    
    CGSize newImageSize = firstImage.size;
    CGSize secondImageSize = CGSizeMake(firstImage.size.width, roundf(firstImage.size.width/secondImage.size.width* secondImage.size.height));
    if (UIGraphicsBeginImageContextWithOptions != NULL) {
        UIGraphicsBeginImageContextWithOptions(newImageSize, NO, [[UIScreen mainScreen] scale]);
    }
    
    [firstImage drawAtPoint:CGPointMake(0,0)];
    [secondImage drawInRect:CGRectMake(0, 0, secondImageSize.width, secondImageSize.height)];
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}
@end
