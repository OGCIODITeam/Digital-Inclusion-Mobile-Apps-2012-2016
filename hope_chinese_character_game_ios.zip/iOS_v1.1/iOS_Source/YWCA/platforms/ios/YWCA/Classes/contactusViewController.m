//
//  AgreementReadOnlyViewController.m
//  YWCA
//
//  Created by Benny SYW on 17/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "contactusViewController.h"
#import "AppDelegate.h"

#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

@interface contactusViewController () {
    NSString *file;
    NSURL *url;
}


@property (nonatomic, strong) AVAudioPlayer *bgmPlayer;

@end

@implementation contactusViewController
@synthesize bgmPlayer = mBgmPlayer;
@synthesize bgm_off = mBgm_off;
@synthesize bgm_on = mBgm_on;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //music
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSString *indexMusic;
    indexMusic = [appDelegate getMusic];
    if([indexMusic  isEqual: @"1"]) {
        [appDelegate playBgMusic];
        mBgm_off.hidden = YES;
        mBgm_on.hidden = NO;
    } else {
        mBgm_off.hidden = NO;
        mBgm_on.hidden = YES;
    }
    
    //webview
    if (IS_IPAD) {
        url = [[NSBundle mainBundle] URLForResource:@"contact_iPad" withExtension:@"html"];
    } else {
        url = [[NSBundle mainBundle] URLForResource:@"contact" withExtension:@"html"];
    }
    self.uiWebView.backgroundColor = [UIColor clearColor];
    [self.uiWebView setOpaque:NO];
    NSURLRequest* request = [NSURLRequest requestWithURL:url];
    [_uiWebView loadRequest:request];
    self.uiWebView.scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
}

- (void)viewDidAppear:(BOOL)animated {
    file = @"btn_bgm";
    [self.bgm_on setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_bgm_off";
    [self.bgm_off setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"btn_back";
    [self.backbtn setImage:[UIImage imageNamed:file] forState:UIControlStateNormal];
    file = @"bg_content_02";
    self.bg.image = [UIImage imageNamed:file];
}

- (void)viewDidDisappear:(BOOL)animated {
    [self.uiWebView stopLoading];
    [self.uiWebView setDelegate:nil];
    self.uiWebView = nil;
    
    self.bgm_on = nil;
    self.bgm_off = nil;
    self.backbtn = nil;
    self.bg = nil;
    self.lblTitle = nil;
    file = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
}

- (IBAction)bgm_off:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate playBgMusic];
    mBgm_off.hidden = YES;
    mBgm_on.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:1];
}

- (IBAction)bgm_on:(id)sender {
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [appDelegate stopBgMusic];
    mBgm_on.hidden = YES;
    mBgm_off.hidden = NO;
    [appDelegate updateSetting:@"item_music" mode:0];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
