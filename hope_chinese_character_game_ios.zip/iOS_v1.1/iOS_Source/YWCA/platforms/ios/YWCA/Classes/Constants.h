//
//  Constants.h
//  YWCA
//
//  Created by Benny SYW on 4/3/15.
//
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject

extern NSString *const serverPath;

extern NSString *const file1;
extern NSString *const file2;
extern NSString *const file3;
extern NSString *const file4;
extern NSString *const file5;

extern NSString *const url_youtube;

@end
