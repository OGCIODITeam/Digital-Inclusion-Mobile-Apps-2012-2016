//
//  DataHelper.h
//  DBTREE
//
//  Created by Marshals Chan on 21/12/14.
//  Copyright (c) 2014 Alvis Ching. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataHelper : NSObject

+(NSDictionary*)getPlist:(NSString*) name;
+ (NSString *) getStringFromResource:(NSString *)key;
+ (NSBundle *) getLanguageBundle;
+ (NSString *) getLocalizedImagePath:(NSString*)imageName andType:(NSString*)type;
@end
