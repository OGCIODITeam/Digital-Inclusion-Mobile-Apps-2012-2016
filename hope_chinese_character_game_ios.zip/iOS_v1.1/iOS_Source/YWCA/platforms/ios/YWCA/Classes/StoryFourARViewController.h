//
//  StoryFourARViewController.h
//  YWCA
//
//  Created by Eric on 3/1/15.
//
//

#ifndef YWCA_StoryFourARViewController_h
#define YWCA_StoryFourARViewController_h

#import <UIKit/UIKit.h>
#import <MetaioSDK/MetaioSDKViewController.h>

#define FOLDER_PREFIX @"ARAssets/story4"
#define PATH_PREFIX @"s4_ar"
#define BLOCK_MAX_SCALE 6
#define OBJECT_1_SCALE 15.0
#define OBJECT_2_SCALE 2.5
#define OBJECT_3_SCALE 15.0

@interface StoryFourARViewController : MetaioSDKViewController
{
    metaio::IGeometry*      m_3dModel;            // pointer to the metaio man model
    metaio::IGeometry*       m_Image;            // pointer to the metaio man model
    metaio::IGeometry*       m_word;
    metaio::IGeometry*       m_block;
    
    __weak IBOutlet  UIImageView* imageViewObject1;
    __weak IBOutlet  UIImageView* imageViewObject2;
    __weak IBOutlet  UIImageView* imageViewObject3;
    
    __strong IBOutlet UIButton *btnBack;
    
    NSMutableArray *modelArray;
    NSMutableArray *wordArray;
    NSMutableArray *blockArray;
    
    int currentIndex;
    
    BOOL isMatchObject1;
    BOOL isMatchObject2;
    BOOL isMatchObject3;
    
    BOOL isStop;
    BOOL isWordStart;
    
    //NSString *pathPrefix;
    NSString* pathModel;
    NSString* imagePathWord;
    NSString* imagePathBlock;
    
    NSTimer*        wordTimer;
    NSTimer*        blockTimer;
    int             count;
}

@end

#endif
