//
//  Constants.m
//  YWCA
//
//  Created by Benny SYW on 4/3/15.
//
//

#import "Constants.h"

@implementation Constants

NSString *const serverPath = @"http://www.myhost.com/";

NSString *const file1 = @"http://www.myhost.com/stage1.zip";
NSString *const file2 = @"http://www.myhost.com/stage2.zip";
NSString *const file3 = @"http://www.myhost.com/stage3.zip";
NSString *const file4 = @"http://www.myhost.com/stage4.zip";
NSString *const file5 = @"http://www.myhost.com/stage5.zip";

NSString *const url_youtube = @"http://www.myhost.com/video.html";

@end
