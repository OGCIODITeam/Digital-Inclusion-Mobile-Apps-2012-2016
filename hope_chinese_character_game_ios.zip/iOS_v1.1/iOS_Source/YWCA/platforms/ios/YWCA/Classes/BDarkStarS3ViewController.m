//
//  BDarkStarS3ViewController.m
//  YWCA
//
//  Created by Benny SYW on 25/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import "BDarkStarS3ViewController.h"
#import "AppDelegate.h"

@interface BDarkStarS3ViewController () {
    NSString *file;
}

@end

@implementation BDarkStarS3ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    file = @"star_off";
    self.S1.image = [UIImage imageNamed:file];
    self.S2.image = [UIImage imageNamed:file];
    self.S3.image = [UIImage imageNamed:file];
    self.S4.image = [UIImage imageNamed:file];
    self.S5.image = [UIImage imageNamed:file];
}

- (void)viewDidDisappear:(BOOL)animated {
    file = nil;
    self.S1 = nil;
    self.S2 = nil;
    self.S3 = nil;
    self.S4 = nil;
    self.S5 = nil;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
