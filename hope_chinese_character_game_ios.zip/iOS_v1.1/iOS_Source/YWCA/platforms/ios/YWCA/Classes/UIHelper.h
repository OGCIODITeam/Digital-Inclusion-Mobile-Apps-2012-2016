//
//  UIHelper.h
//  DBTREE
//
//  Created by Marshals Chan on 21/12/14.
//  Copyright (c) 2014 Alvis Ching. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "DataHelper.h"

@interface UIHelper : NSObject

+ (CGSize)getScreenSize;

+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;
+ (UIImage*)imageByCombiningImage:(UIImage*)firstImage withImage:(UIImage*)secondImage;
+ (UIImage*)imageWithUrlString:(NSString*) url;
+ (UIImage*)localizedImage:(NSString*)imageName andType:(NSString*)type;

@end
