/*
 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
 */

//
//  AppDelegate.h
//  YWCA
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <Cordova/CDVViewController.h>
#import "AgreementViewController.h"

@interface AppDelegate : NSObject <UIApplicationDelegate>{}

// invoke string is passed to your app on launch, this is only valid if you
// edit YWCA-Info.plist to add a protocol
// a simple tutorial can be found here :
// http://iphonedevelopertips.com/cocoa/launching-your-own-application-via-a-custom-url-scheme.html

@property (nonatomic, strong) IBOutlet UIWindow* window;
@property (nonatomic, strong) IBOutlet CDVViewController* viewController;
//@property (nonatomic, strong) IBOutlet AgreementViewController* viewController;

@property (nonatomic, strong) AVAudioPlayer *bgmPlayer;
@property (nonatomic) int select_stage;
@property (nonatomic) int select_game;

- (void)playBgMusic;
- (void)stopBgMusic;
- (BOOL)isPlayerStop;
- (void)getAllSettingData;
- (void)getAllGameData;
- (NSString*)getMusic;
- (NSString*)getSound;
- (int)getMusicInt;
- (int)getSoundInt;
- (NSString*)getAgreeCheck;
- (long)getFileSize:(int)stage;
- (void)clearAllSetting;
- (void)clearRecord:(int)stage;
- (void)updateSetting:(NSString*)item mode:(int)mode;
- (NSString*)getStars:(int)stage game:(int)game;
- (int)getStarsInt:(int)stage game:(int)game;
- (NSString*)getStageStars:(int)stage;
- (int)getStageStarsInt:(int)stage;
- (int)getRStageStars:(int)stage;
- (int)getPass:(int)stage;
- (void)setItem_starAndstage;
- (int)getARfinish:(int)stage;
- (void)setARfinish:(int)stage finish:(int)finish;
- (void)ultraStars_stage:(int)stage game:(int)game stars:(int)stars;
- (void)ultraNStars_stage:(int)stage game:(int)game stars:(int)stars;
- (void)ultraRStars_stage:(int)stage game:(int)game stars:(int)stars;
- (void)ultraStarsWithoutSatety_stage:(int)stage game:(int)game stars:(int)stars;
- (void)ultraBeater;
- (int)getFirstEnter:(int)stage game:(int)game;
- (void)ultraEnter_stage:(int)stage game:(int)game enter:(int)enter;
- (BOOL)addCol:(NSString*)tbl_name col_name:(NSString*) col_name col_type:(NSString*)col_type;
- (void)updateData:(NSString*)tbl_name col_name:(NSString*)col_name data_id:(int)data_id value:(long)value;

@property (nonatomic) int settingIDToEdit;

@property (nonatomic, strong) NSArray *arrResults;

@end
