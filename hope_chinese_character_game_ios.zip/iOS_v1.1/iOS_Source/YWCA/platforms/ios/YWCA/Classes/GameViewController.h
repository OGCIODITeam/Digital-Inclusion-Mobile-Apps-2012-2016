//
//  GameViewController.h
//  YWCA
//
//  Created by Benny SYW on 11/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "openBookView.h"
#import "Reachability.h"
Reachability* reachability;

@interface GameViewController : UIViewController <NSURLConnectionDataDelegate>

//data from webview (game)
@property int quit_stage;
@property int quit_lose;

//general
@property (strong, nonatomic) IBOutlet UIImageView *bg;
- (IBAction)back:(id)sender;
- (IBAction)bgm_on:(id)sender;
- (IBAction)bgm_off:(id)sender;
- (IBAction)sound_on:(id)sender;
- (IBAction)sound_off:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn_back;
@property (strong, nonatomic) IBOutlet UIImageView *main_char;

@property (weak, nonatomic) IBOutlet UIButton *bgm_on;
@property (weak, nonatomic) IBOutlet UIButton *bgm_off;
@property (strong, nonatomic) IBOutlet UIButton *sound_on;
@property (strong, nonatomic) IBOutlet UIButton *sound_off;

//books
@property (strong, nonatomic) IBOutlet UIButton *book1;
@property (strong, nonatomic) IBOutlet UIButton *book2;
@property (strong, nonatomic) IBOutlet UIButton *book3;
@property (strong, nonatomic) IBOutlet UIButton *book4;
@property (strong, nonatomic) IBOutlet UIButton *book5;
- (IBAction)book1:(id)sender;
- (IBAction)book2:(id)sender;
- (IBAction)book3:(id)sender;
- (IBAction)book4:(id)sender;
- (IBAction)book5:(id)sender;

//custom views
@property (strong, nonatomic) IBOutlet openBookView *customStory1;
@property (strong, nonatomic) IBOutlet openBookView *customStory2;
@property (strong, nonatomic) IBOutlet openBookView *customStory3;
@property (strong, nonatomic) IBOutlet openBookView *customStory4;
@property (strong, nonatomic) IBOutlet openBookView *customStory5;
@property (strong, nonatomic) IBOutlet UIButton *btn_cs1;
@property (strong, nonatomic) IBOutlet UIButton *btn_cs2;
@property (strong, nonatomic) IBOutlet UIButton *btn_cs3;
@property (strong, nonatomic) IBOutlet UIButton *btn_cs4;
@property (strong, nonatomic) IBOutlet UIButton *btn_cs5;
- (IBAction)btn_cs1:(id)sender;
- (IBAction)btn_cs2:(id)sender;
- (IBAction)btn_cs3:(id)sender;
- (IBAction)btn_cs4:(id)sender;
- (IBAction)btn_cs5:(id)sender;

//rainbows
- (IBAction)btn_rainbow1:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn_rainbow1;
- (IBAction)btn_rainbow2:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn_rainbow2;
- (IBAction)btn_rainbow3:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn_rainbow3;
- (IBAction)btn_rainbow4:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn_rainbow4;


//Download icon
- (IBAction)DL1:(id)sender;
- (IBAction)DL2:(id)sender;
- (IBAction)DL3:(id)sender;
- (IBAction)DL4:(id)sender;
- (IBAction)DL5:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *DL1;
@property (strong, nonatomic) IBOutlet UIButton *DL2;
@property (strong, nonatomic) IBOutlet UIButton *DL3;
@property (strong, nonatomic) IBOutlet UIButton *DL4;
@property (strong, nonatomic) IBOutlet UIButton *DL5;

//small opened books
@property (strong, nonatomic) IBOutlet UIView *S1container;
@property (strong, nonatomic) IBOutlet UIView *S2container;
@property (strong, nonatomic) IBOutlet UIView *S3container;
@property (strong, nonatomic) IBOutlet UIView *S4container;
@property (strong, nonatomic) IBOutlet UIView *S5container;

//The Big Book
@property (strong, nonatomic) IBOutlet UIView *shadow;
@property (strong, nonatomic) IBOutlet UIButton *BigBk2C;
- (IBAction)BigBk2C:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *BigBk2View;
@property (strong, nonatomic) IBOutlet UIButton *BigBk2;
@property (strong, nonatomic) IBOutlet UIButton *BigBkClose;
- (IBAction)BigBookClose:(id)sender;
    //SubViews
        //View1
@property (strong, nonatomic) IBOutlet UITextField *Game1_text;
@property (strong, nonatomic) IBOutlet UIView *G1LightStar;
@property (strong, nonatomic) IBOutlet UIView *G1DarkStar;
- (IBAction)game1:(id)sender;
        //View2
@property (strong, nonatomic) IBOutlet UITextField *Game2_text;
@property (strong, nonatomic) IBOutlet UIView *G2LightStar;
@property (strong, nonatomic) IBOutlet UIView *G2DarkStar;
- (IBAction)game2:(id)sender;
        //View3
@property (strong, nonatomic) IBOutlet UITextField *Game3_text;
@property (strong, nonatomic) IBOutlet UIView *G3LightStar;
@property (strong, nonatomic) IBOutlet UIView *G3DarkStar;
- (IBAction)game3:(id)sender;
        //View4
@property (strong, nonatomic) IBOutlet UITextField *Game4_text;
@property (strong, nonatomic) IBOutlet UIView *G4LightStar;
@property (strong, nonatomic) IBOutlet UIView *G4DarkStar;
- (IBAction)game4:(id)sender;

//Download
@property (strong, nonatomic) IBOutlet UIView *Download_View;
@property (strong, nonatomic) IBOutlet UIImageView *DL_bg;
    //start_DL
@property (strong, nonatomic) IBOutlet UIView *start_DL;
@property (strong, nonatomic) IBOutlet UITextView *DL_Text1;
@property (strong, nonatomic) IBOutlet UIButton *accept;
@property (strong, nonatomic) IBOutlet UIButton *cancel;
- (IBAction)accept:(id)sender;
- (IBAction)cancel:(id)sender;
    //DLing
@property (strong, nonatomic) IBOutlet UIView *DLing;
@property (strong, nonatomic) IBOutlet UITextView *DLing_text;
@property (weak, nonatomic) IBOutlet UIImageView *process_bg;
@property (strong, nonatomic) IBOutlet UIProgressView *DL_process;
@property (strong, nonatomic) IBOutlet UITextView *DL_percentage;
@property (strong, nonatomic) IBOutlet UIButton *DL_cancel;
@property (strong, nonatomic) IBOutlet UIButton *DL_finish;
- (IBAction)DL_cancel:(id)sender;
- (IBAction)DL_finish:(id)sender;

@property NSString *appStatus;

@end
