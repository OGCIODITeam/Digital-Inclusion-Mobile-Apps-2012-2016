//
//  StoryThreeEcardViewController.m
//  YWCA
//
//  Created by Eric on 3/1/15.
//
//

#import "StoryThreeEcardViewController.h"
#define IS_OS_8_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define IS_4_INCH_OR_ABOVE  ([[UIScreen mainScreen] bounds].size.height == 568)?TRUE:FALSE
#define IPAD     UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
#define IS_RETINA ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)] && ([UIScreen mainScreen].scale == 2.0))
#define IS_IPAD ([[UIDevice currentDevice] respondsToSelector:@selector(userInterfaceIdiom)] && [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

@interface StoryThreeEcardViewController () {
    UIStoryboard *storyboard;
}


@end

@implementation StoryThreeEcardViewController

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

-(void)viewDidAppear:(BOOL)animated
{
    if(IPAD && IS_RETINA)
        NSLog(@"ipad retina");
    else if(IPAD && !IS_RETINA)
        NSLog(@"ipad2");
    else
        NSLog(@"iphone");
    
    if(IS_OS_8_OR_LATER)
    {
        NSLog(@"ios 8+");
        bg.contentMode = UIViewContentModeScaleAspectFill;
        [bg setFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    }
    else{
        NSLog(@"ios 7");
        bg.contentMode = UIViewContentModeScaleAspectFill;
        [bg setClipsToBounds:YES];
        [bg setFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    }
    
    if(!IPAD)
        [ecardBg setFrame:CGRectMake(0, 70, 353, 236)];
    else
        [ecardBg setFrame:CGRectMake(0, 70*2, 353*2, 236*2)];
    
    CGFloat btnPosX = ecardBg.frame.origin.x + ecardBg.frame.size.width - 15;
    CGFloat btnPosY = 0;
    if(!IPAD)
        btnPosY = ecardBg.frame.origin.y  + 180;
    else
        btnPosY = ecardBg.frame.origin.y  + 180*3;
    
    if(!IPAD)
        [shareBtn setFrame:CGRectMake(btnPosX, btnPosY, 80, 80)];
    else
        [shareBtn setFrame:CGRectMake(btnPosX, btnPosY - 70, 160, 160)];
    
    if(!IPAD && IS_OS_8_OR_LATER && IS_4_INCH_OR_ABOVE)
    {
        btnPosX = btnPosX +  120;
        [nextBtn setFrame:CGRectMake(btnPosX, btnPosY, 80, 80)];
    }
    else if(!IPAD && IS_OS_8_OR_LATER && !IS_4_INCH_OR_ABOVE)
    {
        btnPosX = btnPosX +  80;
        [nextBtn setFrame:CGRectMake(btnPosX, btnPosY, 80, 80)];
    }
    else if(!IPAD)
    {
        btnPosX = self.view.bounds.size.width - 65;
        [nextBtn setFrame:CGRectMake(btnPosX, btnPosY, 80, 80)];
    }
    else if(IPAD && IS_OS_8_OR_LATER)
    {
        btnPosX = self.view.bounds.size.width - 150;
        [nextBtn setFrame:CGRectMake(btnPosX, btnPosY - 70, 160, 160)];
    }
    else if(IPAD && !IS_OS_8_OR_LATER)
    {
        btnPosX = self.view.bounds.size.width - 150;
        [nextBtn setFrame:CGRectMake(btnPosX, btnPosY - 70, 160, 160)];
    }
    
    int widthScale = round(ECARD_WIDTH  / (widthOfScreen * 3 / 4));
    int heightScale = round(ECARD_HEIGHT / (heightOfScreen * 3 / 4));
    float mid = (widthScale + heightScale) / 2;
    reducedEcardHeight = ECARD_HEIGHT / mid;
    reducedEcardWidth =  ECARD_WIDTH / mid;
    
    CGFloat labelX = 0;
    CGFloat textFieldX = 0;
    
    
    if(!IPAD && IS_OS_8_OR_LATER && IS_4_INCH_OR_ABOVE)
    {
        textFieldX = widthOfScreen - 50 - 120;
        labelX = textFieldX - 20 - 115;
        [senderTF setFrame:CGRectMake(textFieldX, 5, 120, 30)];
        [receiverTF setFrame:CGRectMake(textFieldX, 40, 120, 30)];
        [senderImageView setFrame:CGRectMake(labelX, 5, 115, 30)];
        [receiverImageView setFrame:CGRectMake(labelX, 40, 115, 30)];
    }
    else if(!IPAD && IS_OS_8_OR_LATER && !IS_4_INCH_OR_ABOVE)
    {
        textFieldX = widthOfScreen - 50 - 120 - 40;
        labelX = textFieldX - 20 - 115;
        [senderTF setFrame:CGRectMake(textFieldX, 5, 120, 30)];
        [receiverTF setFrame:CGRectMake(textFieldX, 40, 120, 30)];
        [senderImageView setFrame:CGRectMake(labelX, 5, 115, 30)];
        [receiverImageView setFrame:CGRectMake(labelX, 40, 115, 30)];
    }
    else if(!IPAD)
    {
        textFieldX = widthOfScreen - 50 - 120 - 60;
        labelX = textFieldX - 20 - 115;
        [senderTF setFrame:CGRectMake(textFieldX, 5, 120, 30)];
        [receiverTF setFrame:CGRectMake(textFieldX, 40, 120, 30)];
        [senderImageView setFrame:CGRectMake(labelX, 5, 115, 30)];
        [receiverImageView setFrame:CGRectMake(labelX, 40, 115, 30)];
    }
    else if(IPAD)
    {
        textFieldX = widthOfScreen - 50 - 120 - 50;
        textFieldX = textFieldX * 2;
        labelX = textFieldX - 20 - 230;
        [senderTF setFont:[UIFont systemFontOfSize:24]];
        [receiverTF setFont:[UIFont systemFontOfSize:24]];
        [senderTF setFrame:CGRectMake(textFieldX, 5, 120*2, 30*2)];
        [receiverTF setFrame:CGRectMake(textFieldX, 70, 120*2, 30*2)];
        [senderImageView setFrame:CGRectMake(labelX, 5, 115*2, 30*2)];
        [receiverImageView setFrame:CGRectMake(labelX, 70, 115*2, 30*2)];
    }
    
    CGFloat ecardX = ecardBg.frame.origin.x;
    CGFloat ecardY = ecardBg.frame.origin.y;
    CGFloat ecardWidth = ecardBg.bounds.size.width;
    //float ecardHeight = ecardBg.bounds.size.height;
    if(!IPAD)
    {
        [receiverlbl setFrame:CGRectMake(ecardX + 30, ecardY + 70, ecardWidth - 60, 30)];
        [senderlbl setFrame:CGRectMake(ecardX + 30, ecardY + 80 + 120, ecardWidth - 60, 30)];
    }
    else
    {
        [receiverlbl setFrame:CGRectMake(ecardX + 60, ecardY + 150, ecardWidth - 120, 30*2)];
        [receiverlbl setFont:[UIFont systemFontOfSize:24]];
        [senderlbl setFrame:CGRectMake(ecardX + 60, ecardY + 80 + 120 + 180, ecardWidth - 120, 30*2)];
        [senderlbl setFont:[UIFont systemFontOfSize:24]];
    }
    
    if(!IPAD)
    {
        //[imageViewObject1 setFrame:CGRectMake(384, 87, 96, 58)];
        //[imageViewObject2 setFrame:CGRectMake(384, 153, 96, 49)];
        //[imageViewObject3 setFrame:CGRectMake(384, 200, 93, 61)];
        [imageViewObject1 setFrame:CGRectMake(378, 69, 96, 96)];
        [imageViewObject2 setFrame:CGRectMake(320, 158, 96, 96)];
        [imageViewObject3 setFrame:CGRectMake(392, 158, 93, 93)];
    }
    else
    {
        //[imageViewObject1 setFrame:CGRectMake(384*2, 90*2, 96*2, 58*2)];
        //[imageViewObject2 setFrame:CGRectMake(384*2, 170*2, 96*2, 60*2)];
        //[imageViewObject3 setFrame:CGRectMake(384*2, 240*2, 93*2, 61*2)];
        
        [imageViewObject1 setFrame:CGRectMake(384*2, 72*2, 96*2, 96*2)];
        [imageViewObject2 setFrame:CGRectMake(384*2, 158*2, 96*2, 96*2)];
        [imageViewObject3 setFrame:CGRectMake(384*2, 236*2, 93*2, 93*2)];
        
    }
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    heightOfScreen = self.view.frame.size.height;
    widthOfScreen = self.view.frame.size.width;
    
    
    NSLog(@"self.view.bounds.size.width=%f",self.view.bounds.size.width);
    NSLog(@"self.view.bounds.size.height=%f",self.view.bounds.size.height);
    NSLog(@"self.view.frame.size.width=%f",self.view.frame.size.width);
    NSLog(@"self.view.frame.size.height=%f",self.view.frame.size.height);
    
    //    float leftFrameWidth =
    
    [bg setImage:[UIImage imageNamed:@"ecard/top_bg.png"]];
    
    [ecardBg setImage:[UIImage imageNamed:@"ecard/ecard_content_s3_bg.png"]];
    
    UIImage *btnShareImage = [UIImage imageNamed:@"ecard/btn_share.png"];
    [shareBtn setImage:btnShareImage forState:UIControlStateNormal];
    
    UIImage *btnNextImage = [UIImage imageNamed:@"ecard/btn_go.png"];
    [nextBtn setImage:btnNextImage forState:UIControlStateNormal];
    
    [imageViewObject1 setImage:[UIImage imageNamed:@"ecard/PNG_400x400_s3_ar1.png"]];
    [imageViewObject2 setImage:[UIImage imageNamed:@"ecard/PNG_400x400_s3_ar2.png"]];
    [imageViewObject3 setImage:[UIImage imageNamed:@"ecard/PNG_400x400_s3_ar3.png"]];
    [senderImageView setImage:[UIImage imageNamed:@"ecard/sender.png"]];
    [receiverImageView setImage:[UIImage imageNamed:@"ecard/receiver.png"]];
    
    imageViewObject1.userInteractionEnabled = YES;
    imageViewObject2.userInteractionEnabled = YES;
    imageViewObject3.userInteractionEnabled = YES;
    
    imageViewObject1.contentMode = UIViewContentModeScaleToFill;
    imageViewObject2.contentMode = UIViewContentModeScaleToFill;
    imageViewObject3.contentMode = UIViewContentModeScaleToFill;
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
    
    UIPanGestureRecognizer *panGR1 =
    [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(objectDidDragged:)];
    [panGR1 setMaximumNumberOfTouches:1];
    [panGR1 setMinimumNumberOfTouches:1];
    
    UIPanGestureRecognizer *panGR2 =
    [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(objectDidDragged:)];
    [panGR2 setMaximumNumberOfTouches:1];
    [panGR2 setMinimumNumberOfTouches:1];
    
    UIPanGestureRecognizer *panGR3 =
    [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(objectDidDragged:)];
    [panGR3 setMaximumNumberOfTouches:1];
    [panGR3 setMinimumNumberOfTouches:1];
    
    [imageViewObject1 addGestureRecognizer:panGR1];
    [imageViewObject1 setTag:100];
    
    [imageViewObject2 addGestureRecognizer:panGR2];
    [imageViewObject2 setTag:101];
    
    [imageViewObject3 addGestureRecognizer:panGR3];
    [imageViewObject3 setTag:102];
    
    senderTF = [[UITextField alloc] initWithFrame:CGRectMake(0, 5, 120, 30)];
    [senderTF setTag:50];
    senderTF.delegate = self;
    senderTF.borderStyle = UITextBorderStyleRoundedRect;
    senderTF.font = [UIFont systemFontOfSize:15];
    senderTF.placeholder = @"";
    senderTF.autocorrectionType = UITextAutocorrectionTypeNo;
    senderTF.keyboardType = UIKeyboardTypeDefault;
    senderTF.layer.borderWidth = 2.0f;
    senderTF.layer.borderColor = [[UIColor blackColor] CGColor];
    senderTF.backgroundColor = [UIColor whiteColor];
    senderTF.userInteractionEnabled = YES;
    [self.view addSubview:senderTF];
    
    receiverTF = [[UITextField alloc] initWithFrame:CGRectMake(0, 40, 120, 30)];
    [receiverTF setTag:51];
    receiverTF.delegate = self;
    receiverTF.borderStyle = UITextBorderStyleRoundedRect;
    receiverTF.font = [UIFont systemFontOfSize:15];
    receiverTF.placeholder = @"";
    receiverTF.autocorrectionType = UITextAutocorrectionTypeNo;
    receiverTF.userInteractionEnabled = YES;
    receiverTF.keyboardType = UIKeyboardTypeDefault;
    receiverTF.layer.borderWidth = 2.0f;
    receiverTF.backgroundColor = [UIColor whiteColor];
    receiverTF.layer.borderColor = [[UIColor blackColor] CGColor];
    
    [self.view addSubview:receiverTF];
    
    [senderlbl setText:@""];
    [receiverlbl setText:@""];
    [senderlbl setTextAlignment:NSTextAlignmentRight];
    [receiverlbl setTextAlignment:NSTextAlignmentLeft];
    
    /*
     UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textViewTapped:)];
     [senderTF addGestureRecognizer:gestureRecognizer];
     
     UITapGestureRecognizer *gestureRecognizerRecv = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textViewTapped:)];
     [receiverTF addGestureRecognizer:gestureRecognizerRecv];
     */
    
    obj1Pos = imageViewObject1.frame.origin;
    obj2Pos = imageViewObject2.frame.origin;
    obj3Pos = imageViewObject3.frame.origin;
    
    [self testalert:nil msg:@"可將「過關」圖案拖動，以製作「個人化電子賀卡」，完成後，可透過Whatsapp或Facebook分享。"];
}

- (void)objectDidDragged:(UIPanGestureRecognizer *)sender {
    NSLog(@"objectDidDragged start");
    
    NSInteger senderTag = [sender view].tag;
    if (sender.state == UIGestureRecognizerStateChanged ||
        sender.state == UIGestureRecognizerStateEnded) {
        NSLog(@"sender.state");
        CGPoint offset = [sender translationInView:self.view];
        UIView *draggableObj = [self.view viewWithTag:senderTag];
        if(senderTag == 100)
        {
            obj1Pos = CGPointMake(draggableObj.center.x + offset.x, draggableObj.center.y + offset.y);
            [draggableObj setCenter:obj1Pos];
        }
        else if(senderTag == 101)
        {
            obj2Pos = CGPointMake(draggableObj.center.x + offset.x, draggableObj.center.y + offset.y);
            [draggableObj setCenter:obj2Pos];
        }
        else if(senderTag == 102)
        {
            obj3Pos = CGPointMake(draggableObj.center.x + offset.x, draggableObj.center.y + offset.y);
            [draggableObj setCenter:obj3Pos];
        }
        
        NSLog(@"obj1Pos.x=%f, obj1Pos.y=%f", obj1Pos.x, obj1Pos.y);
        //NSLog(@"obj2Pos.x=%f, obj2Pos.y=%f", obj2Pos.x, obj2Pos.y);
        //NSLog(@"obj3Pos.x=%f, obj3Pos.y=%f", obj3Pos.x, obj3Pos.y);
        
        //draggableObj setCenter:CGPointMake(draggableObj.center.x + offset.x, draggableObj.center.y + offset.y)];
        
        [sender setTranslation:CGPointMake(0, 0) inView:self.view];
    }
    NSLog(@"image1 posX=%f, posY=%f", imageViewObject1.frame.origin.x, imageViewObject1.frame.origin.y);
    NSLog(@"objectDidDragged end");
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
    [theTextField resignFirstResponder];
    return YES;
}


-(void) moveObject{
    NSLog(@"move OBject");
    
    UIView *draggableObj1 = [self.view viewWithTag:100];
    [draggableObj1 setCenter:obj1Pos];
    
    UIView *draggableObj2 = [self.view viewWithTag:101];
    [draggableObj2 setCenter:obj2Pos];
    
    UIView *draggableObj3 = [self.view viewWithTag:102];
    [draggableObj3 setCenter:obj3Pos];
    /*
     [imageViewObject1 setFrame:CGRectMake(obj1Pos.x, obj1Pos.y, imageViewObject1.frame.size.width, imageViewObject1.frame.size.height)];
     [imageViewObject2 setFrame:CGRectMake(obj2Pos.x, obj2Pos.y, imageViewObject2.frame.size.width, imageViewObject2.frame.size.height)];
     [imageViewObject3 setFrame:CGRectMake(obj3Pos.x, obj3Pos.y, imageViewObject3.frame.size.width, imageViewObject3.frame.size.height)];
     */
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldShouldBeginEditing");
    //textField.backgroundColor = [UIColor colorWithRed:220.0f/255.0f green:220.0f/255.0f blue:220.0f/255.0f alpha:1.0f];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldDidBeginEditing");
    //[textField resignFirstResponder];
    /*
     [UIView beginAnimations:nil context:NULL];
     [UIView setAnimationDelegate:self];
     [UIView setAnimationDuration:0.5]; // if you want to slide up the view
     CGRect rect = self.view.frame;
     rect.origin.y -= 150;
     rect.size.height += 150;
     [UIView commitAnimations];
     */
    
    //NSLog(@"image1 posX=%f, posY=%f", imageViewObject1.frame.origin.x, imageViewObject1.frame.origin.y);
    //[self moveObject];
    //NSLog(@"image1 posX=%f, posY=%f", imageViewObject1.frame.origin.x, imageViewObject1.frame.origin.y);
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    NSLog(@"textFieldShouldEndEditing");
    //textField.backgroundColor = [UIColor whiteColor];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    NSLog(@"textFieldDidEndEditing");
    NSLog(@"text=%@",textField.text);
    //NSLog(@"textfield.tag=%ld", textField.tag);
    if(textField.tag == 50)
    {
        senderText = textField.text;
        NSLog(@"senderText=%@",textField.text);
    }
    else if(textField.tag == 51)
    {
        receiverText = textField.text;
        NSLog(@"receiverText=%@",textField.text);
    }
    //[self moveObject];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIImage *)ecardCap:(CGRect)captureFrame {
    CALayer *layer;
    layer = self.view.layer;
    // whole screen size
    // UIGraphicsBeginImageContext(self.view.bounds.size);
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(ecardBg.bounds.size.width, self.view.bounds.size.height),YES,0.0f);
    
    CGContextClipToRect (UIGraphicsGetCurrentContext(),captureFrame);
    [layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *screenImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return screenImage;
}

-(IBAction) shareBtnPressed:(id)sender
{
    NSLog(@"shareBtnPressed");
    senderText = senderTF.text;
    receiverText = receiverTF.text;
    
    [senderlbl setText:senderText];
    [receiverlbl setText:receiverText];
    
    
    UIImage* screenCap = [self ecardCap:CGRectMake(0, ecardBg.frame.origin.y, ecardBg.frame.size.width, ecardBg.frame.size.height)];
    
    
    if ([self isSocialAppInstalled])
    {
        //[self shareFunc:screenCap];
        UIActionSheet *popup = [[UIActionSheet alloc] initWithTitle:@"Select Sharing option:" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:
                                @"Share on Facebook",
                                @"Share on Whatsapp/Others",
                                nil];
        popup.tag = 1;
        if(IS_OS_8_OR_LATER)
            [popup showInView:[UIApplication sharedApplication].keyWindow];
        else
        {
            UIView *landscapeView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 480, 480)];
            landscapeView.transform = CGAffineTransformMakeRotation((-1)*M_PI/2);
            landscapeView.bounds = CGRectMake(0, 0, 480, 380);
            [self.view addSubview:landscapeView];
            [popup showInView:landscapeView];
        }
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Sorry"
                                  message:@"You can't post right now, make sure your device has an internet connection and you have at least one social app account setup"
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
    
    
    
}

-(void) imageAndTextShare:(UIImage *)screenCap{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
            if (result == SLComposeViewControllerResultCancelled) {
                
                NSLog(@"Cancelled");
                
            } else
                
            {
                NSLog(@"Done");
            }
            
            [controller dismissViewControllerAnimated:YES completion:Nil];
        };
        controller.completionHandler =myBlock;
        
        //[controller setInitialText:@"「我已成功學會上下結構拆字法！」"];
        [controller setInitialText:@"我已成功學會切切切結構拆字法！"];
        [controller addImage:screenCap];
        
        [self presentViewController:controller animated:YES completion:Nil];
        
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Sorry"
                                  message:@"You can't post right now, make sure your device has an internet connection and you have at least one facebook account setup"
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}

-(void) imageShare:(UIImage *)screenCap{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,     NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"temp.png"]; //here i am fetched image path from document directory and convert it in to URL and use bellow
    
    NSData* data = UIImagePNGRepresentation(screenCap);
    [data writeToFile:getImagePath atomically:YES];
    
    NSURL *imageFileURL =[NSURL fileURLWithPath:getImagePath];
    NSLog(@"imag %@",imageFileURL);
    
    self.documentationInteractionController.delegate = self;
    self.documentationInteractionController.UTI = @"net.whatsapp.image";
    self.documentationInteractionController = [self setupControllerWithURL:imageFileURL usingDelegate:self];
    [self.documentationInteractionController presentOpenInMenuFromRect:CGRectZero inView:self.view animated:YES];
    
    
}

- (void)actionSheet:(UIActionSheet *)popup clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    UIImage* screenCap = [self ecardCap:CGRectMake(0, ecardBg.frame.origin.y, ecardBg.frame.size.width, ecardBg.frame.size.height)];
    
    switch (popup.tag) {
        case 1: {
            switch (buttonIndex) {
                case 0:
                    // Facebook
                    [self imageAndTextShare:screenCap];
                    break;
                case 1:
                    [self imageShare:screenCap];
                    break;
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}

/*
 -(UIImage *)ecardCap{
 [self moveObject];
 CGRect rect = [ecardBg bounds];
 UIGraphicsBeginImageContextWithOptions(rect.size,YES,0.0f);
 CGContextRef context = UIGraphicsGetCurrentContext();
 [ecardBg.layer renderInContext:context];
 [imageViewObject1.layer renderInContext:context];
 [imageViewObject2.layer renderInContext:context];
 [imageViewObject3.layer renderInContext:context];
 [senderlbl.layer renderInContext:context];
 UIImage *capturedImage = UIGraphicsGetImageFromCurrentImageContext();
 UIGraphicsEndImageContext();
 return capturedImage;
 }
 */


-(void)shareFunc:(UIImage *)image
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,     NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"temp.png"]; //here i am fetched image path from document directory and convert it in to URL and use bellow
    
    NSData* data = UIImagePNGRepresentation(image);
    [data writeToFile:getImagePath atomically:YES];
    
    NSURL *imageFileURL =[NSURL fileURLWithPath:getImagePath];
    NSLog(@"imag %@",imageFileURL);
    UIActivityViewController * activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[imageFileURL,@"Created by ..."] applicationActivities:NULL];
    
    
    //[activityVC setExcludedActivityTypes:@[ UIActivityTypeMail,UIActivityTypeAssignToContact, UIActivityTypeCopyToPasteboard, UIActivityTypePrint,        UIActivityTypePostToWeibo,UIActivityTypeMessage,UIActivityTypeAirDrop,UIActivityTypeSaveToCameraRoll]];
    
    //[activityVC setValue:@"My Video" forKey:@"subject"];
    
    [activityVC setCompletionHandler:^(NSString *activityType, BOOL completed) {
        //NSLog(@"completed dialog - activity: %@ - finished flag: %d", activityType, completed);
    }];
    
    [self presentViewController:activityVC animated:TRUE completion:nil];
    /*
     self.documentationInteractionController.delegate = self;
     self.documentationInteractionController.UTI = @"net.whatsapp.image";
     self.documentationInteractionController = [self setupControllerWithURL:imageFileURL usingDelegate:self];
     [self.documentationInteractionController presentOpenInMenuFromRect:CGRectZero inView:self.view animated:YES];
     */
}

-(void) imageAndTextShare3:(UIImage *)screenCap{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,     NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"temp.png"]; //here i am fetched image path from document directory and convert it in to URL and use bellow
    
    NSData* data = UIImagePNGRepresentation(screenCap);
    [data writeToFile:getImagePath atomically:YES];
    
    NSURL *imageFileURL =[NSURL fileURLWithPath:getImagePath];
    NSLog(@"imageFileURL=%@",imageFileURL);
    UIActivityViewController * activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[imageFileURL,@"「我已成功學會切切切結構拆字法！」"] applicationActivities:NULL];
    
    
    [activityVC setExcludedActivityTypes:@[ UIActivityTypeMail,UIActivityTypeAssignToContact, UIActivityTypeCopyToPasteboard, UIActivityTypePrint,        UIActivityTypePostToWeibo,UIActivityTypeMessage,UIActivityTypeAirDrop,UIActivityTypeSaveToCameraRoll]];
    
    [activityVC setValue:@"My Video" forKey:@"subject"];
    
    [activityVC setCompletionHandler:^(NSString *activityType, BOOL completed) {
        NSLog(@"completed dialog - activity: %@ - finished flag: %d", activityType, completed);
    }];
    
    [self presentViewController:activityVC animated:TRUE completion:nil];
    
}

-(void)shareFBFunc:(UIImage *)image
{
    //if([SLComposeViewController instanceMethodForSelector:@selector(isAvailableForServiceType)] != nil)
    //{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
            if (result == SLComposeViewControllerResultCancelled) {
                
                NSLog(@"Cancelled");
                
            } else
                
            {
                NSLog(@"Done");
            }
            
            [controller dismissViewControllerAnimated:YES completion:Nil];
        };
        controller.completionHandler =myBlock;
        
        [controller setInitialText:@""];
        [controller addImage:image];
        
        [self presentViewController:controller animated:YES completion:Nil];
        
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Sorry"
                                  message:@"You can't post right now, make sure your device has an internet connection and you have at least one facebook account setup"
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}

-(IBAction) nextBtnPressed:(id)sender
{
    NSLog(@"nextBtnPressed");
    //UIViewController *mainVC = [self.storyboard instantiateViewControllerWithIdentifier:@"game"];
    if (IS_IPAD) {
        storyboard = [UIStoryboard storyboardWithName:@"MainIpad" bundle:nil]; //MainIpad
    }else{
        storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    }
    UIViewController *mainVC = [storyboard instantiateViewControllerWithIdentifier:@"game"];
    [self presentViewController:mainVC animated:YES completion:nil];
}


- (UIDocumentInteractionController *) setupControllerWithURL: (NSURL*) fileURL

                                               usingDelegate: (id <UIDocumentInteractionControllerDelegate>) interactionDelegate {
    
    
    
    self.documentationInteractionController =
    
    [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    
    self.documentationInteractionController.delegate = interactionDelegate;
    
    
    
    return self.documentationInteractionController;
    
}

-(BOOL)isSocialAppInstalled{
    BOOL isWhatsAppExist = [[UIApplication sharedApplication] canOpenURL: [NSURL URLWithString:@"whatsapp://app"]];
    BOOL isFBExist = [SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook];
    return isWhatsAppExist || isFBExist;
}

- (void)testalert:(NSString*)title msg:(NSString*)msg {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:msg
                                                   delegate:self
                                          cancelButtonTitle:@"開始"
                                          otherButtonTitles: nil];
    [alert show];
}

@end

