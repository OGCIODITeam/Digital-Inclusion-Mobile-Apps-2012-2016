//
//  DataHelper.m
//  DBTREE
//
//  Created by Marshals Chan on 21/12/14.
//  Copyright (c) 2014 Alvis Ching. All rights reserved.
//

#import "DataHelper.h"

@implementation DataHelper

+(NSDictionary *)getPlist:(NSString *)name{
   return [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:name ofType:@"plist"]];
}

+ (NSString *) getStringFromResource:(NSString *)key
{
    NSString *path = [[NSBundle mainBundle] pathForResource:[[[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"] objectAtIndex:0] ofType:@"lproj"];
    NSBundle *languageBundle = [NSBundle bundleWithPath:path];
    return [languageBundle localizedStringForKey:key value:@"" table:nil];
}

+ (NSBundle *) getLanguageBundle
{
    NSString *path = [[NSBundle mainBundle] pathForResource:[[[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"] objectAtIndex:0] ofType:@"lproj"];
    return [NSBundle bundleWithPath:path];
}

+ (NSString *) getLocalizedImagePath:(NSString*)imageName andType:(NSString*)type
{
    NSLog(@"bundle path: %@", [[self getLanguageBundle] pathForResource:imageName ofType:type]);
   return [[self getLanguageBundle] pathForResource:imageName ofType:type];
}

@end
