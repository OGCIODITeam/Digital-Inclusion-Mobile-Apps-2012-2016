    //
//  openBookView.h
//  YWCA
//
//  Created by Benny SYW on 11/12/14.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface openBookView : UIView

@property (strong, nonatomic) IBOutlet UIView *bookview;
@property (strong, nonatomic) IBOutlet UIButton *bookbtn;
@property (strong, nonatomic) IBOutlet UITextField *bookname;
@property (strong, nonatomic) IBOutlet UIImageView *bookdone;

//stars
    //dark stars
@property (strong, nonatomic) IBOutlet UIImageView *ds1;
@property (strong, nonatomic) IBOutlet UIImageView *ds2;
@property (strong, nonatomic) IBOutlet UIImageView *ds3;
@property (strong, nonatomic) IBOutlet UIImageView *ds4;
@property (strong, nonatomic) IBOutlet UIImageView *ds5;
    //light stars
@property (strong, nonatomic) IBOutlet UIImageView *ls1;
@property (strong, nonatomic) IBOutlet UIImageView *ls2;
@property (strong, nonatomic) IBOutlet UIImageView *ls3;
@property (strong, nonatomic) IBOutlet UIImageView *ls4;
@property (strong, nonatomic) IBOutlet UIImageView *ls5;

- (void)setStarsWithStage:(int)stage;
- (void)setDoneWithStage:(int)stage;
- (IBAction)btn_book:(id)sender;

@end
