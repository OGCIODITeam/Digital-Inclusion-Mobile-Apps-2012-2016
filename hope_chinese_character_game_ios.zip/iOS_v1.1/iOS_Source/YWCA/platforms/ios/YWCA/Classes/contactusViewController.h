//
//  AgreementReadOnlyViewController.h
//  YWCA
//
//  Created by Benny SYW on 17/11/14.
//  Copyright (c) 2014 Kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface contactusViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *uiWebView;

@property (strong, nonatomic) IBOutlet UIImageView *bg;
@property (strong, nonatomic) IBOutlet UIButton *backbtn;
@property (weak, nonatomic) IBOutlet UIButton *bgm_off;
@property (weak, nonatomic) IBOutlet UIButton *bgm_on;
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
- (IBAction)back:(id)sender;
- (IBAction)bgm_off:(id)sender;
- (IBAction)bgm_on:(id)sender;

@end
