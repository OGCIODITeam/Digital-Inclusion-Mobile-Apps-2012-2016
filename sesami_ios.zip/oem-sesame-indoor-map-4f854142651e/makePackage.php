	<?php
//	include 'includeList.php';
	include "./share/connectDB.php";
	include "./share/sqlList.php";
	//error_reporting(0);
	
	$DBConnect = new connectDB;

	$sqlList = new sqlList;

	class MyDB extends SQLite3
	{
		function __construct()
		{

			$this->open("package/indoormap.sqlite");
		}
	}
	
	
	
	function deleteDirectory($dir) { 
		if (!file_exists($dir)) return true; 
		if (!is_dir($dir) || is_link($dir)) return unlink($dir); 
			foreach (scandir($dir) as $item) { 
				if ($item == '.' || $item == '..') continue; 
				if (!deleteDirectory($dir . "/" . $item)) { 
					chmod($dir . "/" . $item, 0777); 
					if (!deleteDirectory($dir . "/" . $item)) return false; 
				}; 
        } 
        return rmdir($dir); 
    } 
	
	function rcopy($src, $dst) {
	  if (file_exists($dst))
	  {
	  	//echo $dst;
	  	deleteDirectory($dst);
	  }
	  if (is_dir($src)) {
		mkdir($dst);
		
		$files = scandir($src);
		foreach ($files as $file)
		if ($file != "." && $file != "..") rcopy("$src/$file", "$dst/$file"); 
	  }
	  else 
	  {
	  	if (file_exists($src))
	  	{
//		  	echo $src."<br>";
	  		copy($src, $dst);
	  	}
	  }
	}
	
	function Zip($source, $destination)
	{ 
		if (!extension_loaded('zip') || !file_exists($source)) {
			return false;
		}
	
		$zip = new ZipArchive();
		if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
			return false;
		}
	
		$source = str_replace('\\', '/', realpath($source));
	
		if (is_dir($source) === true)
		{
			$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);
	
			foreach ($files as $file)
			{
				$file = str_replace('\\', '/', realpath($file));
	
				if (is_dir($file) === true)
				{
					$zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
				}
				else if (is_file($file) === true)
				{
					$zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
				}
			}
		}
		else if (is_file($source) === true)
		{
			$zip->addFromString(basename($source), file_get_contents($source));
		}
	
		return $zip->close();
	}

	
	deleteDirectory("package/");
	unlink("package.zip");
	
	
	
	mkdir("package/",0777);
	
	
	$db = new MyDB();

	$db->exec($sqlList->createIndoorMapCategories);
	$db->exec($sqlList->createIndoorMapDistricts);
	$db->exec($sqlList->createIndoorMapFloorPlanLabels);
	$db->exec($sqlList->createIndoorMapFloorPlans);
	$db->exec($sqlList->createIndoorMaps);

	
	
	
	$queryAllCategoryResult = $DBConnect->executeQueryResult($sqlList->queryAllCategory);
	while ($queryAllCategoryResultRecord = mysql_fetch_array($queryAllCategoryResult, MYSQL_BOTH)) {
			$insertIndoorMapcategoryies = str_replace("%CATEGORYID%",$queryAllCategoryResultRecord["id"],$sqlList->insertIndoorMapcategoryies);
			$insertIndoorMapcategoryies = str_replace("%NAME%",$queryAllCategoryResultRecord["name"],$insertIndoorMapcategoryies);

			$db->query($insertIndoorMapcategoryies);
	}
	
	
	$queryAllDistrictResult = $DBConnect->executeQueryResult($sqlList->queryAllDistrict);
	while ($queryAllDistrictResultRecord = mysql_fetch_array($queryAllDistrictResult, MYSQL_BOTH)) {
			$insertIndoorMapDistricts = str_replace("%DISTRICTID%",$queryAllDistrictResultRecord["id"],$sqlList->insertIndoorMapDistricts);
			$insertIndoorMapDistricts = str_replace("%NAME%",$queryAllDistrictResultRecord["name"],$insertIndoorMapDistricts);
			
			$db->query($insertIndoorMapDistricts);
	}
	
	$queryAllFloorPlanLabelsResult = $DBConnect->executeQueryResult($sqlList->queryAllFloorPlanLabels);
	while ($queryAllFloorPlanLabelsResultRecord = mysql_fetch_array($queryAllFloorPlanLabelsResult, MYSQL_BOTH)) {
			$insertIndoorAllFloorPlanLabels = str_replace("%FLOORPLANLABELID%",$queryAllFloorPlanLabelsResultRecord["id"],$sqlList->insertIndoorAllFloorPlanLabels);
			$insertIndoorAllFloorPlanLabels = str_replace("%NAME%",$queryAllFloorPlanLabelsResultRecord["name"],$insertIndoorAllFloorPlanLabels);
			$insertIndoorAllFloorPlanLabels = str_replace("%FLOORID%",$queryAllFloorPlanLabelsResultRecord["floor_id"],$insertIndoorAllFloorPlanLabels);

			$db->query($insertIndoorAllFloorPlanLabels);
	}
	
	$queryAllFloorPlanResult = $DBConnect->executeQueryResult($sqlList->queryAllFloorPlan);
	while ($queryAllFloorPlanResultRecord = mysql_fetch_array($queryAllFloorPlanResult, MYSQL_BOTH)) {
			$insertIndoorMapFloorPlans = str_replace("%FLOORPLANID%",$queryAllFloorPlanResultRecord["id"],$sqlList->insertIndoorMapFloorPlans);
			$insertIndoorMapFloorPlans = str_replace("%LABEL%",$queryAllFloorPlanResultRecord["name"],$insertIndoorMapFloorPlans);
			$insertIndoorMapFloorPlans = str_replace("%LEVEL%",($queryAllFloorPlanResultRecord["size"]+1),$insertIndoorMapFloorPlans);
			$insertIndoorMapFloorPlans = str_replace("%DATA%",str_replace("\"","",$queryAllFloorPlanResultRecord["annotation_config"]),$insertIndoorMapFloorPlans);
			$insertIndoorMapFloorPlans = str_replace("%IMAGE%",$queryAllFloorPlanResultRecord["map_path"],$insertIndoorMapFloorPlans);
			$insertIndoorMapFloorPlans = str_replace("%MAP_ID%",$queryAllFloorPlanResultRecord["map_id"],$insertIndoorMapFloorPlans);

			rcopy("maps/".$queryAllFloorPlanResultRecord["map_path"], "package/".$queryAllFloorPlanResultRecord["map_path"]);
			$db->query($insertIndoorMapFloorPlans);
	}
	
	$queryAllMapsResult = $DBConnect->executeQueryResult($sqlList->queryAllMaps);
	while ($queryAllMapsResultRecord = mysql_fetch_array($queryAllMapsResult, MYSQL_BOTH)) {
			$insertIndoorMaps = str_replace("%MAPID%",$queryAllMapsResultRecord["id"],$sqlList->insertIndoorMaps);
			$insertIndoorMaps = str_replace("%NAME%",$queryAllMapsResultRecord["name"],$insertIndoorMaps);
			$insertIndoorMaps = str_replace("%ADDRESS%",$queryAllMapsResultRecord["address"],$insertIndoorMaps);
			$insertIndoorMaps = str_replace("%CATEGORYID%",$queryAllMapsResultRecord["type_id"],$insertIndoorMaps);
			$insertIndoorMaps = str_replace("%DISTRICTID%",$queryAllMapsResultRecord["district_id"],$insertIndoorMaps);
			$insertIndoorMaps = str_replace("%STATUSID%",$queryAllMapsResultRecord["status_id"],$insertIndoorMaps);

			$db->query($insertIndoorMaps);
	}
	 Zip("package", "package.zip");
	//echo $output;
?>
