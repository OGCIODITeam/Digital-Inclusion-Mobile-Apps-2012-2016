<?php
	session_start();
    ob_start();
    
    if (!isset($_SESSION["accountID"]))
    {
    	 header( "refresh:0	;url=login.php" );
    }
?>