<?php

class sqlList 
{
	public $queryAllCategory = "select * from tbl_map_type order by name";
	public $queryAllDistrict = "select * from tbl_district order by name";

	public $queryAllMaps = "select * from tbl_maps order by name";
	public $queryFloorPlanByMapID = "select * from tbl_map_floor_plan where map_id = %MAP_ID% order by name";
	public $queryAnnotationDataByMapIDAndFloorID = "select annotation_config from tbl_map_floor_plan_annotation where map_id=%MAP_ID% and floor_id=%FLOOR_ID%";
	public $quertAllAnnotationLabelByFloorID = "select * from tbl_map_label where floor_id=%FLOOR_ID%";
}
?>
