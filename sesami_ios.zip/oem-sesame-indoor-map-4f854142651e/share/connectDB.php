<?php

class connectDB{
	protected $host = "localhost";
	protected $DBuser = "root";
	protected $DBpasswd = "123godel";
	protected $connect;
	
	
	//Constructor
	public function __construct() {
	    $this->connect = mysql_connect($this->host, $this->DBuser, $this->DBpasswd) or die('Could not connect: ' . mysql_error());
		mysql_select_db('indoor') or die('Could not select database');
		mysql_query("SET NAMES 'UTF8'");
		mysql_query("SET CHARACTER SET UTF8"); 
		mysql_query("SET CHARACTER_SET_RESULTS=UTF8'"); 
	}
	
	//Get execute Non Query Result
	public function executeQueryNonResult($query) {
		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
		$num = mysql_num_rows($result);
		if ($num==0) {
			return "available";
		} else {
			return "not available";
		}
	}
	
	//Query
	public function getNumRows($query) {
		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
		$num = mysql_num_rows($result);
		return $num;
	}
	//Insert /Update / Delete Record
	public function modifyRecord($query) {
		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
		return mysql_affected_rows();
	}
	
	//Get execute Query  Result
	public function executeQueryResult($query) {
		$result = mysql_query($query) or die('Query failed: '.mysql_error());
		return $result;
	}
	
	//Get execute Query Record
	public function executeQueryRecord($query) {
		$result = mysql_query($query) or die('Query failed: '.mysql_error());
		$tempRecord = mysql_fetch_array($result, MYSQL_BOTH);
		return $tempRecord[0];
	}
	
}
?>
