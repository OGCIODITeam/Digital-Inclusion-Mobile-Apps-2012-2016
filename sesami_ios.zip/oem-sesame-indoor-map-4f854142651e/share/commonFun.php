<?php

class commonFun {
	
	//Get Province List
	public function getProvinceComboxList($comboxName,$Province){
		$temp="<select name=\"".$comboxName."\" onChange=\"getCityList('city',this.value)\"><option value=\"0\" >----Please Select----</option>";
		for ($i=1; $i<count($Province);$i++){
			$temp = $temp."<option value=\"".$i."\">".$Province[$i-1]."</option>";	
		}
		$temp=$temp."</select>";
		return $temp;
	}
	
	//Get City List
	public function getCityComboxList($comboxName,$city) {
		$temp="<select name=\"".$comboxName."\" onChange=\"checkProvinceCity(document.all.province.value,this.value)\"><option value=\"0\">----Please Select----</option>";
		for ($i=1; $i<count($city);$i++){
			$temp = $temp."<option value=\"".$i."\">".$city[$i-1]."</option>";	
		}
		$temp=$temp."</select>";
		return $temp;
	}
	
	//Get Category
	public function getCategoryComboxList($comboxName,$lang) {
		$DBconnect = new connectDB;
		$result=$DBconnect->executeQueryResult("SELECT categoryID, categoryName FROM category WHERE categoryLang=\"".$lang."\" ORDER By categoryOrder");
		$categoryList = "<select name=\"".$comboxName."\" size=\"7\" class=\"dropdwnbox\" onChange=\"getSubCategoryList('subCategory',this.value,'".$lang."')\">";
		while ($categoryRecord = mysql_fetch_array($result, MYSQL_BOTH)) {
 		  $categoryList=$categoryList."<option value='".$categoryRecord["categoryID"]."'>".$categoryRecord["categoryName"]."</option>";
		}
		$categoryList = $categoryList."</select>";
		return $categoryList;
	}
	
	//Get Sub Category
	public function getSubCategoryComboxList($comboxName,$category,$lang) {
		$DBconnect = new connectDB;
		$result=$DBconnect->executeQueryResult("SELECT subCategoryID, subCategoryName FROM subcategory WHERE subCategoryLang=\"".$lang."\" and categoryID=".$category." ORDER By subCategoryOrder");
		$subCategoryList = "<select name=\"".$comboxName."\" size=\"7\" class=\"dropdwnbox\" onChange=\"checkActiveNextButton(this.value,'nextBtn')\">";
		while ($subCategoryRecord = mysql_fetch_array($result, MYSQL_BOTH)) {
 		  $subCategoryList=$subCategoryList."<option value='".$subCategoryRecord["subCategoryID"]."'>".$subCategoryRecord["subCategoryName"]."</option>";
		}
		$subCategoryList = $subCategoryList."</select>";
		return $subCategoryList;
	}
	
	//Get Query Result
	public function getQueryResult($table, $queryItem,$condition) {
		$DBconnect = new connectDB;
		return $DBconnect->executeQueryRecord("SELECT ".$queryItem." FROM ".$table." WHERE ".$condition);
	}

	
	//Send Email
	public function sendEmail($senderName,$senderEmail, $receiverName, $receiverEmail, $title, $body, $smtpServer, $smtpPort) {
		 //Sent Email
		ini_set("SMTP",$smtpServer); 
		ini_set("smtp_port",$smtpPort); 
		ini_set("sendmail_from",$senderEmail); 

		$s_name = $senderName;
		$s_mail = $senderEmail;
		
		$header = "From: $s_name <$s_mail>\n";    
		$header .= "Reply-To: receiverName < $receiverEmail>\n";   
		$header .= "MIME-Version: 1.0\r\n";
		$header .= "Content-Type: text/html; charset=UTF-8\r\n";
			 
		mail($receiverEmail, $title, $body,$header);
	}
}
?>