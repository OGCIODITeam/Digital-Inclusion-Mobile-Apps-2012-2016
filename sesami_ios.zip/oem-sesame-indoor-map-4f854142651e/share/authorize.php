<?php

include "./share/connectDB.php";
class authorize {
	
	protected $DBconnect;	
	
	//Constructor
	public function __construct() {
		$this->DBconnect = new connectDB;
	}
	
	//Check user exist
	public function checkUserExist($email){
		$query = "SELECT email FROM account WHERE email='".$email."'";
		echo $this->DBconnect->executeQueryNonResult($query);
	}
	
	
	
	
}
?>