This is Sesame - Indoor Map Project
-----------------------------------
1st created on 03/07/2013
