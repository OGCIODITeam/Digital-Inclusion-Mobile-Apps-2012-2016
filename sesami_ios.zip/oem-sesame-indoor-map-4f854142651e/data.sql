
/*
	Account Demo Record
*/
/*
INSERT INTO `tbl_account` SET `name`='test1', `password`=md5('123'), `email`='test1@indoor.com', `type_id`=1, create_time=now(), update_time=now();
INSERT INTO `tbl_account` SET `name`='test2', `password`=md5('123'), `email`='test2@indoor.com', `type_id`=1, create_time=now(), update_time=now();
*/
/*
	Account Type Demo Record
*/
/*
INSERT INTO `tbl_account_type_permission` SET `name`='Admin', `create_user`=1, `edit_user`=1, `delete_user`=1, `create_map`=1, `edit_map`=1, `delete_map`=1;
INSERT INTO `tbl_account_type_permission` SET `name`='Editor', `create_user`=0, `edit_user`=0, `delete_user`=0, `create_map`=0, `edit_map`=1, `delete_map`=0;
INSERT INTO `tbl_account_type_permission` SET `name`='Viewer', `create_user`=0, `edit_user`=0, `delete_user`=0, `create_map`=0, `edit_map`=0, `delete_map`=0;
*/


/*
	Map District Demo Record
*/
INSERT INTO `tbl_district` SET `name`='d1';
INSERT INTO `tbl_district` SET `name`='d2';
INSERT INTO `tbl_district` SET `name`='d3';

/*
	Map Type Demo Record
*/
INSERT INTO `tbl_map_type` SET `name`='t1';
INSERT INTO `tbl_map_type` SET `name`='t2';
INSERT INTO `tbl_map_type` SET `name`='t3';

/*
	Map Status Demo Record
*/
INSERT INTO `tbl_map_status` SET `name`='In Progress';
INSERT INTO `tbl_map_status` SET `name`='Pending Review';
INSERT INTO `tbl_map_status` SET `name`='Reviewed';
INSERT INTO `tbl_map_status` SET `name`='Published';

