<?php

class MapLabelController extends Controller
{
	private $_floorplan = null;
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			//'postOnly + delete', // we only allow deletion via POST request
			'projectContext + create index view',
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
		
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('index','view','create','update','admin','delete'),
				'expression'=>'Yii::app()->controller->isLabelUser()',
			),
		
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new MapLabel;
		$model->floor_id = $this->_floorplan->id;
		$model->type=1;
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['MapLabel']))
		{
			$model->attributes=$_POST['MapLabel'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['MapLabel']))
		{
			$model->floor_id = $_GET["fid"];
			$model->attributes=$_POST['MapLabel'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		//$dataProvider=new CActiveDataProvider('MapLabel');
		
		if (isset(Yii::app()->user->type) && Yii::app()->user->type == 1)
		{
			$dataProvider=new CActiveDataProvider('MapLabel',array(
			'pagination'=>array(
                        'pageSize'=>20,
                    ),
                    ));
		}
		else
		{
		    $dataProvider=new CActiveDataProvider('MapLabel',array(
                'criteria'=>array(
                    'condition'=>'floor_id =:floor_id and type <>0',
                    'params'=>array(':floor_id'=>$_GET["fid"]),
                    ),
                    'pagination'=>array(
                        'pageSize'=>20,
                    ),
                ));
        }
		
		$model=new MapLabel('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['MapLabel']))
			$model->attributes=$_GET['MapLabel'];
			
		$this->render('admin',array(
			'model'=>$model,
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		//$dataProvider=new CActiveDataProvider('MapLabel');
		
		if (isset(Yii::app()->user->type) && Yii::app()->user->type == 1)
		{
			$dataProvider=new CActiveDataProvider('MapLabel',array(
			'pagination'=>array(
                        'pageSize'=>20,
                    ),
                    ));
		}
		else
		{
		    $dataProvider=new CActiveDataProvider('MapLabel',array(
                'criteria'=>array(
                    'condition'=>'floor_id =:floor_id and type <>0',
                    'params'=>array(':floor_id'=>$_GET["fid"]),
                    ),
                    'pagination'=>array(
                        'pageSize'=>20,
                    ),
                ));
        }
		
		$model=new MapLabel('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['MapLabel']))
			$model->attributes=$_GET['MapLabel'];
			
		$this->render('admin',array(
			'model'=>$model,
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return MapLabel the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=MapLabel::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}
	

	/**
	 * Performs the AJAX validation.
	 * @param MapLabel $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='map-label-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	
	protected function loadFloorPlan($floorId) {
		//if the project property is null, create it based on input id
		if($this->_floorplan===null)
		{
			$this->_floorplan=MapFloorPlan::model()->findByPk($floorId);
			if($this->_floorplan===null)
			{
				throw new CHttpException(404,'The requested floor plan does not exist.');
			}
		}
		return $this->_floorplan;
	}
	
	function isLabelUser() {
		if (isset(Yii::app()->user->id) && isset($_GET["mid"]) && isset($_GET["aid"]) )
		{
			$count = MapAccount::model()->countByAttributes(array(
            'map_id'=> $_GET["mid"],
            'account_id' => Yii::app()->user->id
     	   ));
			if ($count>0 || Yii::app()->user->type == 1)
			{
				return true;
			}
		}
	
        return false;
	}
	
	public function filterProjectContext($filterChain)
	{
		//set the project identifier based on GET input request variables
		if (!((isset(Yii::app()->user->type) && Yii::app()->user->type == 1) || Yii::app()->controller->isLabelUser()))
		{
			throw new CHttpException(403,'You do not have permission to access.');
		}
		else
		{
			$this->loadFloorPlan($_GET['fid']);
		}

		$filterChain->run();
	}
}
