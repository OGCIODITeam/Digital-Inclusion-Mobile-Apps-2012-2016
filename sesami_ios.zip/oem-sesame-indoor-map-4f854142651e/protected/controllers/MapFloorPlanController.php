<?php
	
class MapFloorPlanController extends Controller
{
	private $_map = null;
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'projectContext + create index view',
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('update','admin','delete','create'),
				'expression'=>'Yii::app()->controller->isFloorPlanUser()',
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new MapFloorPlan;
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		$model->map_id = $this->_map->id;
		if(isset($_POST['MapFloorPlan']))
		{
			$rnd = rand(0,9999);
			
			$model->attributes=$_POST['MapFloorPlan'];
			
			$uploadedFile=CUploadedFile::getInstance($model,'map_path');
            $fileName = "{$rnd}-{$uploadedFile}";  // random number + file name
            $model->map_path = $fileName;
            

			if($model->save())
			{
				$uploadedFile->saveAs(Yii::app()->basePath.'/../maps/'.$fileName);
				
				include Yii::app()->basePath.'/../SimpleImage.php';
				$image = new SimpleImage();
				$image->load(Yii::app()->basePath.'/../maps/'.$model->map_path);
				if ( $model->size == 0)
				{
					$image->resize(160,160);
				}
				else
				{
					if ($model->size == 1)
					{
						$image->resize(480,480);
					}
					else
					{
						$image->resize(1440,1440);
					}
				}
				$image->save(Yii::app()->basePath.'/../maps/'.$model->map_path);
				$MapFloorPlanAnnotationModel = new MapFloorPlanAnnotation;
				$MapFloorPlanAnnotationModel->map_id=$model->map_id;
				$MapFloorPlanAnnotationModel->floor_id=$model->id;
				$MapFloorPlanAnnotationModel->save();


				$this->redirect(array('view','id'=>$model->id,'mid'=>$model->map_id));
			}
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		//$model->map_id = $this->_map->id;
		if(isset($_POST['MapFloorPlan']))
		{
			$model->attributes=$_POST['MapFloorPlan'];
			$model->map_id = $_GET["mid"];
			$uploadedFile=CUploadedFile::getInstance($model,'map_path');
 
			if($model->save())
			{
				 if(!empty($uploadedFile))  // check if uploaded file is set or not
                {
                //echo "A".$model->map_path;
                    $uploadedFile->saveAs(Yii::app()->basePath.'/../maps/'.$model->map_path);
					include Yii::app()->basePath.'/../SimpleImage.php';
					$image = new SimpleImage();
					
					$image->load(Yii::app()->basePath.'/../maps/'.$model->map_path);
					if ( $model->size == 0)
					{
						$image->resize(160,160);
					}
					else
					{
						if ($model->size == 0)
						{
							$image->resize(480,480);
						}
						else
						{
							$image->resize(1440,1440);
						}
					}
					$image->save(Yii::app()->basePath.'/../maps/'.$model->map_path);
                }
				$this->redirect(array('view','id'=>$model->id,'mid'=>$model->map_id));
			}
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$model=$this->loadModel($id);
		if (file_exists(Yii::app()->basePath.'/../maps/'.$model->map_path))
		{
			unlink(Yii::app()->basePath.'/../maps/'.$model->map_path);
		}
	
		$model->delete();
		
		MapFloorPlanAnnotation::model()->deleteAll("floor_id =".$id);

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin','mid'=>$_GET["mid"]));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		//$dataProvider=new CActiveDataProvider('MapFloorPlan');
		
		if (isset(Yii::app()->user->type) && Yii::app()->user->type == 1)
		{
			$dataProvider=new CActiveDataProvider('MapFloorPlan',array(
			'criteria'=>array(
                    'condition'=>'map_id=:map_id',
                    'params'=>array(':map_id'=>$_GET["mid"]),
                    ),
                    'pagination'=>array(
                        'pageSize'=>20,
                    ),
                     'sort'=>array(
						'defaultOrder'=>array(
							'floor_num'=>true,
						),
					),
                ));
		}
		else
		{
		    $dataProvider=new CActiveDataProvider('MapFloorPlan',array(
                'criteria'=>array(
                    'condition'=>'map_id IN (SELECT map_id FROM tbl_map_account WHERE account_id=:account_id) and map_id=:map_id',
                    'params'=>array(':account_id'=>Yii::app()->user->id, ':map_id'=>$_GET["mid"]),
                    ),
                    'pagination'=>array(
                        'pageSize'=>20,
                    ),
                     'sort'=>array(
						'defaultOrder'=>array(
							'floor_num'=>true,
						),
					),
                ));
        }
		$model=new MapFloorPlan('search');
		$model->unsetAttributes();  // clear any default values

		if(isset($_GET['MapFloorPlan']))
			$model->attributes=$_GET['MapFloorPlan'];
		$this->render('admin',array(
			'model'=>$model,
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		//$dataProvider=new CActiveDataProvider('MapFloorPlan');
		
		if (isset(Yii::app()->user->type) && Yii::app()->user->type == 1)
		{
			$dataProvider=new CActiveDataProvider('MapFloorPlan',array(
			'criteria'=>array(
                    'condition'=>'map_id=:map_id',
                    'params'=>array(':map_id'=>$_GET["mid"]),
                    ),
                    'pagination'=>array(
                        'pageSize'=>20,
                    ),
                     'sort'=>array(
						'defaultOrder'=>array(
							'floor_num'=>true,
						),
					),
                ));
		}
		else
		{
		    $dataProvider=new CActiveDataProvider('MapFloorPlan',array(
                'criteria'=>array(
                    'condition'=>'map_id IN (SELECT map_id FROM tbl_map_account WHERE account_id=:account_id) and map_id=:map_id',
                    'params'=>array(':account_id'=>Yii::app()->user->id, ':map_id'=>$_GET["mid"]),
                    ),
                    'pagination'=>array(
                        'pageSize'=>20,
                    ),
                     'sort'=>array(
						'defaultOrder'=>array(
							'floor_num'=>true,
						),
					),
                ));
        }
		$model=new MapFloorPlan('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['MapFloorPlan']))
			$model->attributes=$_GET['MapFloorPlan'];
		$this->render('admin',array(
			'model'=>$model,
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return MapFloorPlan the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=MapFloorPlan::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param MapFloorPlan $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='map-floor-plan-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	
	protected function loadMap($mapId) {
		//if the project property is null, create it based on input id
		if($this->_map===null)
		{
			$this->_map=Maps::model()->findByPk($mapId);
			if($this->_map===null)
			{
				throw new CHttpException(404,'The requested map does not exist.');
			}
		}
		return $this->_map;
	}

	
	
	function isFloorPlanUser() {
		if (isset(Yii::app()->user->id) && isset($_GET["mid"]))
		{
			$count = MapAccount::model()->countByAttributes(array(
            'map_id'=> $_GET["mid"],
            'account_id' => Yii::app()->user->id
     	   ));
			if ($count>0 || Yii::app()->user->type == 1)
			{
				return true;
			}
		}
	
        return false;
	}
	
	public function filterProjectContext($filterChain)
	{
		//set the project identifier based on GET input request variables
		if (!((isset(Yii::app()->user->type) && Yii::app()->user->type == 1) || Yii::app()->controller->isFloorPlanUser()))
		{
			throw new CHttpException(403,'You do not have permission to access.');
		}
		else
		{
			$this->loadMap($_GET['mid']);
		}

		$filterChain->run();
	}
}
