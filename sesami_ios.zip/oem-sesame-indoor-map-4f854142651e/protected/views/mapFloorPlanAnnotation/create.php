<?php
/* @var $this MapFloorPlanAnnotationController */
/* @var $model MapFloorPlanAnnotation */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','mid'=>$_GET["mid"]),
	'Map Floor Plan Annotations'=>array('index','mid'=>$_GET["mid"]),
	'Create',
);

$this->menu=array(
	array('label'=>'List MapFloorPlanAnnotation', 'url'=>array('index')),
	array('label'=>'Manage MapFloorPlanAnnotation', 'url'=>array('admin')),
);
?>

<h1>Create Map Floor Plan Shop Label ?</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>