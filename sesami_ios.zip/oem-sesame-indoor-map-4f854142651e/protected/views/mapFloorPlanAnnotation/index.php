<?php
/* @var $this MapFloorPlanAnnotationController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','mid'=>$_GET["mid"]),
	'Map Floor Plan Annotations',
);

$this->menu=array(
	array('label'=>'Create MapFloorPlanAnnotation', 'url'=>array('create')),
	array('label'=>'Manage MapFloorPlanAnnotation', 'url'=>array('admin')),
);
?>

<h1>Map Floor Plan Shop Label ?</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
