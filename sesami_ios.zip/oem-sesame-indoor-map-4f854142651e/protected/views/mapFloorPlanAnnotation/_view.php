<?php
/* @var $this MapFloorPlanAnnotationController */
/* @var $data MapFloorPlanAnnotation */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('annotation_config')); ?>:</b>
	<?php echo CHtml::encode($data->annotation_config); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('map_id')); ?>:</b>
	<?php echo CHtml::encode($data->map_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('floor_id')); ?>:</b>
	<?php echo CHtml::encode($data->floor_id); ?>
	<br />


</div>