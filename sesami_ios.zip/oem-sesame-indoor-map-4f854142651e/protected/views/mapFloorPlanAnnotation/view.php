<?php
/* @var $this MapFloorPlanAnnotationController */
/* @var $model MapFloorPlanAnnotation */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','mid'=>$_GET["mid"]),
	'Map Floor Plan Annotations'=>array('index','mid'=>$_GET["mid"]),
	$model->id,
);

$this->menu=array(
	array('label'=>'List Map Floor Plan Shop Label ?', 'url'=>array('index')),
	array('label'=>'Create Map Floor Plan Shop Label ?', 'url'=>array('create')),
	array('label'=>'Update Map Floor Plan Shop Label ?', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete Map Floor Plan Shop Label ?', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Map Floor Plan Shop Label ?', 'url'=>array('admin')),
);
?>

<h1>View Map Floor Plan Shop Label ? #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'annotation_config',
		'map_id',
		'floor_id',
	),
)); ?>
