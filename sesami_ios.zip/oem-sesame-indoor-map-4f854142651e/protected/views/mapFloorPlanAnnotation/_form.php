<?php
/* @var $this MapFloorPlanAnnotationController */
/* @var $model MapFloorPlanAnnotation */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'map-floor-plan-annotation-form',
	'enableAjaxValidation'=>false,
	
)); 

?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php //echo $form->labelEx($model,'annotation_config'); ?>
		<?php echo $form->hiddenField($model,'annotation_config',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'annotation_config'); ?>
	</div>

	

	<div class="row">
		<?php echo $form->labelEx($model,'floor_id'); ?>
		<?php echo $form->labelEx($model,$_GET['fid']); ?>
		 <?php //$this->widget('application.extensions.colorpicker.JColorPicker', array('model'=>$model, 'attribute'=>'floor_id')); ?>
		<?php echo $form->error($model,'floor_id'); ?>
	</div>
	<div class="row">
		<?php
			echo CHtml::button('Label Management', array('onclick' => 'js:document.location.href="'.Yii::app()->request->baseUrl.'/index.php?r=MapLabel/index&mid='.CHtml::encode($model->map_id).'&fid='.$_GET["fid"].'&aid='.$model->id.'"'))
		?>
	
	<div class="row">
	<div class="row">
		<?php
			$labelOption = $model->getLabelOptions(); 
		?>
		<table border=1>
			<tr>
				<td>
				<?php
					$labelRecord = $model->getLabelOptions();
					$labelArr = array();
					foreach($labelRecord as $t)
					{
						$labelArr[$t->id] = $t->attributes;
					}
					//print_r($labelArr);
				?>
				<?php echo CHtml::dropDownList('ColorCode','',  CHtml::listData($labelRecord,'id', 'name'),
				 array(
					'empty'    => 'Select Label',
					'onchange' => 'setCurrentColorCode(this.value)',
				)); ?>
				
				</td>
				<td id="colorCode" width="10"></td>
			</tr>
		</table>
	</div>
<?php

	function hex2rgb($hex) {
	   $hex = str_replace("#", "", $hex);

	   if(strlen($hex) == 3) {
		  $r = hexdec(substr($hex,0,1).substr($hex,0,1));
		  $g = hexdec(substr($hex,1,1).substr($hex,1,1));
		  $b = hexdec(substr($hex,2,1).substr($hex,2,1));
	   } else {
		  $r = hexdec(substr($hex,0,2));
		  $g = hexdec(substr($hex,2,2));
		  $b = hexdec(substr($hex,4,2));
	   }
	   $rgb = array($r, $g, $b);
	   //return implode(",", $rgb); // returns the rgb values separated by commas
	   return $rgb; // returns an array with the rgb values
	}
	echo $form->labelEx($model,"Map"); 
	//$map = Maps::model()->findByAttributes(array('id'=>$_GET["mid"]));
	//echo $map->num_level;
	$mapFloorPlan =  MapFloorPlan::model()->findByAttributes(array('id'=>$_GET["fid"]));
//	echo $mapFloorPlan->dimension_lv1." ".$mapFloorPlan->dimension_lv2." ".$mapFloorPlan->dimension_lv3;
	list($width, $height, $type, $attr) = getimagesize("./maps/".$mapFloorPlan->map_path);
	$size = $mapFloorPlan->size;
		$width = 900;
		$height=900;
       $totalColumn = 16;

        if ($size == 1)
		{
			$width = 1440;
			$height = 1440;
			$totalColumn = 16 * 3;
		}
		else
		{
			if ($size == 2)
			{
				$width = 1440;
				$height = 1440;
				$totalColumn = 16 * 3 * 3;
			}
		}
			//echo $size." ". $totalColumn;
        //$totalColumn = $dlv1*$dlv2*$dlv3;
	//$totalColumn = $mapFloorPlan->dimension_lv1 * $mapFloorPlan->dimension_lv2 * $mapFloorPlan->dimension_lv3;
	
	//$totalColumn = 16;
	//echo $totalColumn." ";
 	
 	//echo $width." ".$height;
 	//echo "<table border=\"1\" width='100%'>";
  //	echo "<tr>";
  //	echo "<td>

    if ($model->annotation_config == null || $model->annotation_config == "")
	{
		$allMapPlan = array();
	}
	else
	{
		$allMapPlan = json_decode($model->annotation_config);
	}
					
  	echo "<div style=\"width:".$width."px;height:".$height."px;position:absolute;\" >";
	echo "<table width='100%' height='100%' border=\"1\"  cellpadding=\"0\" cellspacing=\"0\">";
	for ($i=0; $i <$totalColumn; $i++)
	{
		echo "<tr>";
		for ($j=0; $j <$totalColumn; $j++)
		{
		
			if (isset($allMapPlan[$i][$j]) && $allMapPlan[$i][$j] != "")
			{
				$tempColor = hex2rgb($labelArr[$allMapPlan[$i][$j]]["color_code"]);
				
				echo "<td id='".$i."_".$j."' style=\"line-height:0;background-color: rgba(".$tempColor[0].",".$tempColor[1].",".$tempColor[2].", 0.8);\"  onMouseDown='changeBgColor(".$i.",".$j.")' title='".$labelArr[$allMapPlan[$i][$j]]["name"]."' alt='".$labelArr[$allMapPlan[$i][$j]]["name"]."' ></td>";
			}
			else
			{
				$allMapPlan[$i][$j] = "";
				echo "<td id='".$i."_".$j."' style=\"line-height:0;filter:alpha(opacity=40);\" onMouseDown='changeBgColor(".$i.",".$j.")'></td>";
			}
			
		} 
		echo "</tr>";
	}	
	echo "</table></div>";
  	echo "<div style=\"position:static\"><img src='./maps/".$mapFloorPlan->map_path."' width='".$width."' height='".$height."'></div>";
	//echo "</td></tr></table>";
?>
	</div>
	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>
<script language="javascript">
var currentLabelId = "";
var currentColorCode = "";
var currentLabelName = "";
var allMapPlan = <?php echo json_encode($allMapPlan);?>;
function setCurrentColorCode(id)
{
	
	var data = <?php echo json_encode($labelArr);?>;
	currentLabelId = id;
	currentColorCode = data[id]["color_code"];
	currentLabelName = data[id]["name"];
	document.getElementById("colorCode").style.backgroundColor="#"+currentColorCode;
	//alert(currentColorCode);
}

function changeBgColor(i,j)
{
	
	if (document.getElementById(i+"_"+j).style.backgroundColor == "" && currentLabelId!="")
	{
		tempColorRGB = hexToRgb(currentColorCode);
		document.getElementById(i+"_"+j).style.backgroundColor = "rgba("+tempColorRGB.r+","+tempColorRGB.g+","+tempColorRGB.b+", 0.8)";
		allMapPlan[i][j] = currentLabelId;
		document.getElementById(i+"_"+j).title = currentLabelName;
		document.getElementById(i+"_"+j).alt = currentLabelName;
	
	}
	else
	{
		document.getElementById(i+"_"+j).style.backgroundColor = ""; 	
		allMapPlan[i][j] = "";
		document.getElementById(i+"_"+j).title = "";
		document.getElementById(i+"_"+j).alt = "";
	
	}
	
	var jsonString = JSON.stringify(allMapPlan);
	document.getElementById("MapFloorPlanAnnotation_annotation_config").value = jsonString;
}

function clearCurrentColorCode()
{
	currentLabelId = "";
	currentColorCode = "";
}

function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}	
</script>
</div><!-- form -->