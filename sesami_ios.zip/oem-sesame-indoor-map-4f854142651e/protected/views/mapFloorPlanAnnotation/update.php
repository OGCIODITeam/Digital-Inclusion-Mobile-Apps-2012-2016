<?php
/* @var $this MapFloorPlanAnnotationController */
/* @var $model MapFloorPlanAnnotation */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','id'=>$_GET["mid"]),
	'Floor Plans' =>array('mapFloorPlan/view','id'=>$_GET["fid"],'mid'=>$_GET["mid"]),
	'Map Floor Plan Shop Label',
	'Update',
);

/*$this->menu=array(
	array('label'=>'List MapFloorPlanAnnotation', 'url'=>array('index')),
	array('label'=>'Create MapFloorPlanAnnotation', 'url'=>array('create')),
	array('label'=>'View MapFloorPlanAnnotation', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage MapFloorPlanAnnotation', 'url'=>array('admin')),
);*/
?>

<h1>Update Map Floor Plan Shop Label</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>