<?php
/* @var $this MapLabelController */
/* @var $model MapLabel */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','id'=>$_GET["mid"]),
	'Floor Plans'=>array('mapFloorPlan/view','id'=>$_GET["fid"],'mid'=>$_GET["mid"]),
	'Map Floor Plan Shop Label'=>array('mapFloorPlanAnnotation/update','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'id'=>$_GET['aid']),
	'Shop Labels'=>array('index','id'=>$model->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']),
	$model->name=>array('view','id'=>$model->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Shop Labels', 'url'=>array('create','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
	array('label'=>'View Shop Labels', 'url'=>array('view', 'id'=>$model->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
	array('label'=>'Manage Shop Labels', 'url'=>array('admin','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
);
?>

<h1>Update Shop Labels</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>