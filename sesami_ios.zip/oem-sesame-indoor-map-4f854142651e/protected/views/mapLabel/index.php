<?php
/* @var $this MapLabelController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','id'=>$_GET["mid"]),
	'Floor Plans'=>array('mapFloorPlan/view','id'=>$_GET["fid"],'mid'=>$_GET["mid"]),
	'Map Floor Plan Shop Label'=>array('mapFloorPlanAnnotation/update','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'id'=>$_GET['aid']),
	'Shop Labels',
);

$this->menu=array(
	array('label'=>'Create Shop Labels', 'url'=>array('create','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
	array('label'=>'Manage Shop Labels', 'url'=>array('admin','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
);
?>

<h1>Map Labels</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
