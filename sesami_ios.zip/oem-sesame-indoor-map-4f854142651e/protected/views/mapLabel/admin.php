<?php
/* @var $this MapLabelController */
/* @var $model MapLabel */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','id'=>$_GET["mid"]),
	'Floor Plans'=>array('mapFloorPlan/view','id'=>$_GET["mid"],'mid'=>$_GET["mid"]),
	'Map Floor Plan Shop Label'=>array('mapFloorPlanAnnotation/update','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'id'=>$_GET['aid']),
	'Shop Labels'=>array('index','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']),
	'Manage',
);

$this->menu=array(
	array('label'=>'Create Shop Labels', 'url'=>array('create','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#map-label-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Shop Labels</h1>

<p>
You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'map-label-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'name',
		'type',
		'color_code',
		array(

                        'class'=>'CButtonColumn',

                        'viewButtonUrl'=>'Yii::app()->createUrl("/mapLabel/view", array("id" => $data->id,"mid"=>$_GET[\'mid\'],"fid"=>$_GET[\'fid\'],"aid"=>$_GET[\'aid\']))',

                        'deleteButtonUrl'=>'Yii::app()->createUrl("/mapLabel/delete", array("id" => $data->id,"mid"=>$_GET[\'mid\'],"fid"=>$_GET[\'fid\'],"aid"=>$_GET[\'aid\']))',

                        'updateButtonUrl'=>'Yii::app()->createUrl("/mapLabel/update", array("id" => $data->id,"mid"=>$_GET[\'mid\'],"fid"=>$_GET[\'fid\'],"aid"=>$_GET[\'aid\']))',

                ),


	),
)); ?>
