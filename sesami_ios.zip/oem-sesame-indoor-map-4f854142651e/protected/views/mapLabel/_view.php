<?php
/* @var $this MapLabelController */
/* @var $data MapLabel */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name')); ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('type')); ?>:</b>
	<?php echo CHtml::encode($data->type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('floor_id')); ?>:</b>
	<?php echo CHtml::encode($data->getFloorNum($data->floor_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('color_code')); ?>:</b>
	<?php echo CHtml::encode($data->color_code); ?>
	<br />


</div>