<?php
/* @var $this MapLabelController */
/* @var $model MapLabel */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'map-label-form',
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'name'); ?>
		<?php echo $form->textField($model,'name',array('size'=>60,'maxlength'=>255)); ?>
		<?php echo $form->error($model,'name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'type'); ?>
		<?php echo $form->labelEx($model,1); ?>
		<?php echo $form->error($model,'type'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'color_code'); ?>
		<?php $this->widget('application.extensions.colorpicker.JColorPicker', array('model'=>$model, 'attribute'=>'color_code','htmlOptions' => array('flat' => 'true'),)); 
			
		?>
		
		<?php //echo $form->textField($model,'color_code',array('size'=>60,'maxlength'=>255)); ?>
		<?php echo $form->error($model,'color_code'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>
<script language="javascript">

function genColorCode()
{
	color = Math.floor(Math.random()*16777215).toString(16);
	while (color.length != 6)
	{
		color = Math.floor(Math.random()*16777215).toString(16);
	}
	return color;

}
if (<?php echo $model->isNewRecord; ?>)
{
	document.getElementById("MapLabel_color_code").value = genColorCode();
}
</script>
</div><!-- form -->