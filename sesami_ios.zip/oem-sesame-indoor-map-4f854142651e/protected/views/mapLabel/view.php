<?php
/* @var $this MapLabelController */
/* @var $model MapLabel */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','mid'=>$_GET["mid"]),
	'Floor Plans'=>array('mapFloorPlan/view','id'=>$_GET["fid"],'mid'=>$_GET["mid"]),
	'Map Floor Plan Shop Label'=>array('mapFloorPlanAnnotation/update','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'id'=>$_GET['aid']),
	'Shop Labels'=>array('index','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']),
	$model->name,
);

$this->menu=array(
	array('label'=>'Create Shop Labels', 'url'=>array('create','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
	array('label'=>'Update Shop Labels', 'url'=>array('update', 'id'=>$model->id,'mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
	array('label'=>'Delete Shop Labels', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Shop Labels', 'url'=>array('admin','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
);
?>

<h1>View Shop Label</h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'name',
		'type',
		'floor_id',
		'color_code',
	),
)); ?>
