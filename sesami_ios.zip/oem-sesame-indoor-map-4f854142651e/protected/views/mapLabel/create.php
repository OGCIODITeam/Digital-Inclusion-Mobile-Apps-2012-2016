<?php
/* @var $this MapLabelController */
/* @var $model MapLabel */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','id'=>$_GET["mid"]),
	'Floor Plans'=>array('mapFloorPlan/view','id'=>$_GET["fid"],'mid'=>$_GET["mid"]),
	'Map Floor Plan Shop Label'=>array('mapFloorPlanAnnotation/update','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'id'=>$_GET['aid']),
	'Shop Labels'=>array('index','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid']),
	'Create',
);

$this->menu=array(
	array('label'=>'Manage Shop Labels', 'url'=>array('admin','mid'=>$_GET["mid"],'fid'=>$_GET['fid'],'aid'=>$_GET['aid'])),
);
?>

<h1>Create Shop Labels</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>