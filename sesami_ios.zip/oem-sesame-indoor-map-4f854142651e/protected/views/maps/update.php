<?php
/* @var $this MapsController */
/* @var $model Maps */

$this->breadcrumbs=array(
	'Maps'=>array('index'),
	$model->name=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Maps', 'url'=>array('create')),
	array('label'=>'View Maps', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Maps', 'url'=>array('admin')),
);
?>

<h1>Update Maps</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>