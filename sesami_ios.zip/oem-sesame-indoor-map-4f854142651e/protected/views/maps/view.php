<?php
/* @var $this MapsController */
/* @var $model Maps */

$this->breadcrumbs=array(
	'Maps'=>array('index'),
	$model->name,
);
if (isset(Yii::app()->user->type) && Yii::app()->user->type == 1)
{
	$this->menu=array(
		array('label'=>'Create Maps', 'url'=>array('create')),
		array('label'=>'Update Maps', 'url'=>array('update', 'id'=>$model->id)),
		array('label'=>'Delete Maps', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
		array('label'=>'Manage Maps', 'url'=>array('admin')),
		array('label'=>'Manage Maps Access Control', 'url' => array('/mapAccount/index', 'mid'=>$model->id)),
		array('label'=>'Manage Floor Plan', 'url' => array('/mapFloorPlan/index', 'mid'=>$model->id)),
	);

}
else
{
	$this->menu=array(
		array('label'=>'List Maps', 'url'=>array('index')),
		array('label'=>'Manage Floor Plan', 'url' => array('/mapFloorPlan/index', 'mid'=>$model->id)),
	);

}
	
?>

<h1>View Maps</h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'name',
		'address',
		array(
			'name'=>'district_id',
			'value'=>$model->getDistrictText()
		),
		array(
			'name'=>'type_id',
			'value'=>$model->getTypeText()
		),
		array(
			'name'=>'status_id',
			'value'=>$model->getStatusText()
		),
		'version',
		'locked',
		'create_time',
		'update_time',
	),
)); ?>
