<?php
/* @var $this MapAccountController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','mid'=>$_GET["mid"]),
	'Map Access Control',
);

$this->menu=array(
	array('label'=>'Create Map Access Control', 'url'=>array('create','mid'=>$_GET["mid"])),
	array('label'=>'Manage Map Access Control', 'url'=>array('admin','mid'=>$_GET["mid"])),
);
?>

<h1>Map Access Control</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
