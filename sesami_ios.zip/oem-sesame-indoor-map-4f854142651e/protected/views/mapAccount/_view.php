<?php
/* @var $this MapAccountController */
/* @var $data MapAccount */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id,'mid'=>$_GET["mid"])); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('account_id')); ?>:</b>
	<?php echo CHtml::encode($data->getAccountText()); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('map_id')); ?>:</b>
<?php echo CHtml::encode($data->getMapText()); ?>
	<br />


</div>