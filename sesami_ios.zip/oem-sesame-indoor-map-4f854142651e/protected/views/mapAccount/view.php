<?php
/* @var $this MapAccountController */
/* @var $model MapAccount */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','mid'=>$_GET["mid"]),
	'Map Access Control'=>array('index','mid'=>$_GET["mid"]),
);

$this->menu=array(
	array('label'=>'Create Map Access Control', 'url'=>array('create','mid'=>$_GET["mid"])),
	array('label'=>'Update Map Access Control', 'url'=>array('update','id'=>$model->id,'mid'=>$_GET["mid"])),
	array('label'=>'Delete Map Access Control', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Map Access Control', 'url'=>array('admin','mid'=>$_GET["mid"])),
);
?>

<h1>View Map Access Control</h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		array(
			'name'=>'account_id',
			'value'=>$model->getAccountText()
		),
		array(
			'name'=>'map_id',
			'value'=>$model->getMapText()
		),
	),
)); ?>
