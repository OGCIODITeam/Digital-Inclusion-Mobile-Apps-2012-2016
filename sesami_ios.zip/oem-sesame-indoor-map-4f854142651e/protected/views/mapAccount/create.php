<?php
/* @var $this MapAccountController */
/* @var $model MapAccount */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','mid'=>$_GET["mid"]),
	'Map Access Control'=>array('index','id'=>$model->id,'mid'=>$_GET["mid"]),
	'Create',
);

$this->menu=array(
	array('label'=>'Manage Map Access Control', 'url'=>array('admin','mid'=>$model->map_id)),
);
?>

<h1>Create Map Access Control</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>