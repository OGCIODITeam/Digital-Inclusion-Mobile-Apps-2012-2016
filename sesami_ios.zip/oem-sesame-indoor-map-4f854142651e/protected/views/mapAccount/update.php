<?php
/* @var $this MapAccountController */
/* @var $model MapAccount */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','mid'=>$_GET["mid"]),
	'Map Access Control'=>array('index'),
	$model->id=>array('view','id'=>$model->id,'mid'=>$_GET["mid"]),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Map Access Control', 'url'=>array('create','id'=>$model->id,'mid'=>$_GET["mid"])),
	array('label'=>'View Map Access Control', 'url'=>array('view','id'=>$model->id,'mid'=>$_GET["mid"])),
	array('label'=>'Manage Map Access Control', 'url'=>array('admin','id'=>$model->id,'mid'=>$_GET["mid"])),
);
?>

<h1>Update Map Access Control</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>