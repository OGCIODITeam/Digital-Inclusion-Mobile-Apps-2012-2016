<?php
/* @var $this MapFloorPlanController */
/* @var $model MapFloorPlan */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','id'=>$_GET["mid"]),
	'Floor Plans'=>array('index','mid'=>$_GET["mid"]),
	'Create',
);

$this->menu=array(
	array('label'=>'Manage Floor Plan', 'url'=>array('admin','mid'=>$_GET["mid"])),
);
?>

<h1>Create Floor Plan</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>