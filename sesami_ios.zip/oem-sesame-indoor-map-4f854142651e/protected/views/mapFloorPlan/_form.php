<?php
/* @var $this MapFloorPlanController */
/* @var $model MapFloorPlan */
/* @var $form CActiveForm */
	
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'map-floor-plan-form',
	'enableAjaxValidation'=>false,
	'htmlOptions' => array(
        'enctype' => 'multipart/form-data',
    ),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'name'); ?>
		<?php echo $form->textField($model,'name',array('size'=>60,'maxlength'=>255)); ?>
		<?php echo $form->error($model,'name'); ?>
	</div>

	

	<div class="row">
		<?php echo $form->labelEx($model,'floor_num'); ?>
		<?php echo $form->dropDownList($model,'floor_num', $model->getFloorNumOptions()); ?>
		<?php echo $form->error($model,'floor_num'); ?>
	</div>

	<div class="row">
 		<?php echo $form->labelEx($model,'map_path'); ?>
        <?php echo CHtml::activeFileField($model, 'map_path'); ?>  
        <?php echo $form->error($model,'image'); ?>
   </div>
   <div class="row">
 		<?php echo $form->labelEx($model,'size'); ?>
        <?php
            echo $form->dropDownList($model, 'size',$model->getSizeOptions() );
        ?> 
		 <?php echo $form->error($model, 'size'); ?>
   </div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'heading'); ?>
		<?php echo $form->dropDownList($model,'heading', $model->getHeadingNumOptions()); ?>
		<?php echo $form->error($model,'heading'); ?>
	</div>
	

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->