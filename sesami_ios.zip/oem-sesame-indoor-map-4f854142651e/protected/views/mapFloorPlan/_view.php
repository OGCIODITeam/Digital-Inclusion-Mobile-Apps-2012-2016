<?php
/* @var $this MapFloorPlanController */
/* @var $data MapFloorPlan */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id,'mid'=>$_GET["mid"])); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name')); ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('map_id')); ?>:</b>
	<?php echo CHtml::encode($data->map_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('floor_num')); ?>:</b>
	<?php echo CHtml::encode($data->floor_num); ?>
	<br />
	<b><?php CHtml::encode($data->getAttributeLabel('size')); ?>:</b>
	<?php echo CHtml::encode($data->size); ?>
	<br />
	<b><?php CHtml::encode($data->getAttributeLabel('heading')); ?>:</b>
	<?php echo CHtml::encode($data->heading); ?>
	<br />


<?php /*	
	<b><?php echo "Map Image"; ?>:</b>
	<br>
	<?php echo CHtml::image('./maps/'.$data->map_path,'maps',array('width'=>100)); ?>
	<br />
*/?>		
</div>