<?php
/* @var $this MapFloorPlanController */
/* @var $model MapFloorPlan */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','id'=>$_GET["mid"]),
	'Floor Plans'=>array('index','mid'=>$_GET["mid"]),
	$model->name,
);

$this->menu=array(
	array('label'=>'Create Floor Plan', 'url'=>array('create','mid'=>$_GET["mid"])),
	array('label'=>'Update Floor Plan', 'url'=>array('update', 'id'=>$model->id,'mid'=>$_GET["mid"])),
	array('label'=>'Delete Floor Plan', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id,'mid'=>$_GET["mid"]),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Floor Plan', 'url'=>array('admin','mid'=>$_GET["mid"])),
);
?>

<h1>View Floor Plan</h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'name',
		'floor_num',
		array(
			'name'=>'size',
			'value'=>$model->getSizeTitle()
		),
		'heading',
			
		
		array(        
            'name'=>'map_path',
             'value'=> CHtml::image('./maps/'.$model->map_path,'maps',array('width'=>100)),
             'type'=>'raw',
       ),
       array('name'=>'Edit Shop Label',
			'type'=>'raw',
			'value'=> CHtml::button('Edit Shop Label', array('onclick' => 'js:document.location.href="'.Yii::app()->request->baseUrl.'/index.php?r=mapFloorPlanAnnotation/update&mid='.CHtml::encode($model->map_id).'&fid='.CHtml::encode($model->id).'&id='.$model->getMapFloorPlanAnnotationId().'	"')),
		),

	),
)); ?>
