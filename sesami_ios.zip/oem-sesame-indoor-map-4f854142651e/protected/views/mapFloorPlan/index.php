<?php
/* @var $this MapFloorPlanController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Map'=>array('maps/index','id'=>$_GET["mid"]),
	'Floor Plans',
);

$this->menu=array(
	array('label'=>'Create MapFloorPlan', 'url'=>array('create','mid'=>$_GET["mid"])),
	array('label'=>'Manage MapFloorPlan', 'url'=>array('admin','mid'=>$_GET["mid"])),
);
?>

<h1>Floor Plans</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
