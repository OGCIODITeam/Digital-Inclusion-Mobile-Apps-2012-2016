<?php
/* @var $this MapFloorPlanController */
/* @var $model MapFloorPlan */

$this->breadcrumbs=array(
	'Map'=>array('maps/view','id'=>$_GET["mid"]),
	'Floor Plans'=>array('index','mid'=>$_GET["mid"]),
	$model->name=>array('view','id'=>$model->id,'mid'=>$_GET["mid"]),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Floor Plan', 'url'=>array('create','mid'=>$_GET["mid"])),
	array('label'=>'View Floor Plan', 'url'=>array('view', 'id'=>$model->id,'mid'=>$_GET["mid"])),
	array('label'=>'Manage Floor Plan', 'url'=>array('admin','mid'=>$_GET["mid"])),
);
?>

<h1>Update Floor Plan <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>