<?php

class m130626_030509_indoor_account_type_tables extends CDbMigration
{
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
		Yii::import('application.models.*');
		Yii::import('application.models.base.*');
		
		//Account Table
		$this->createTable('tbl_account', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
			'password' => 'string NOT NULL',
			'email' => 'string NOT NULL',
			'type_id' => 'int(11) DEFAULT NULL',
			'create_time' => 'datetime DEFAULT NULL',
			'update_time' => 'datetime DEFAULT NULL',
		), 'ENGINE=InnoDB');
		
		//Account Type Permission
		$this->createTable('tbl_account_type_permission', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
			'create_user' =>  'boolean DEFAULT FALSE',
			'edit_user' =>  'boolean DEFAULT FALSE',
			'delete_user' =>  'boolean DEFAULT FALSE',
			'create_map' =>  'boolean DEFAULT FALSE',
			'edit_map' =>  'boolean DEFAULT FALSE',
			'delete_map' =>  'boolean DEFAULT FALSE',
		), 'ENGINE=InnoDB');
		
		//Add Default Data
		//Add Default AccountTypePermissionRecord Record
		$this->addAccountTypePermissionRecord(0, "Admin", 1, 1, 1, 1, 1, 1);
		$this->addAccountTypePermissionRecord(1, "Editor", 0, 0, 0, 0, 1, 0);
		$this->addAccountTypePermissionRecord(2, "Viewer", 0, 0, 0, 0, 0, 0);
		
		//foreign key relationships
		//the tbl_account.type_id is a reference to tbl_account_type_permission.id
		$this->addForeignKey("fk_account_type", "tbl_account", "type_id", "tbl_account_type_permission", "id", "NO ACTION", "NO ACTION");
	
	}
	
	public function addAccountTypePermissionRecord($id , $name, $createUserPerm, $editUserPerm, $deleteUserPerm, $createMapPerm, $editMapPerm, $deleteMapPerm) 
	{
		$AccountTypePermission = new AccountTypePermission();
		//$AccountTypePermission->id = $id;
		$AccountTypePermission->name = $name;
		$AccountTypePermission->create_user = $createUserPerm;
		$AccountTypePermission->edit_user = $editUserPerm;
		$AccountTypePermission->delete_user = $deleteUserPerm;
		$AccountTypePermission->create_map = $createMapPerm;
		$AccountTypePermission->edit_map = $editMapPerm;
		$AccountTypePermission->delete_map = $deleteMapPerm;
		$AccountTypePermission->save();
	}

	public function safeDown()
	{
		//Account Table
		$this->truncateTable('tbl_account');
		$this->dropTable('tbl_account');
		
		//Account Type Permission
		$this->truncateTable('tbl_account_type_permission');
		$this->dropTable('tbl_account_type_permission');
	}
}