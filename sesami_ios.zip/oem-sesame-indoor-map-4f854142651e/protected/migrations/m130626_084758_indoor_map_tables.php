<?php

class m130626_084758_indoor_map_tables extends CDbMigration
{
	
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
	
		Yii::import('application.models.*');
		Yii::import('application.models.base.*');
		
		//Maps Table
		$this->createTable('tbl_maps', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
			'address' => 'string NOT NULL',
			'district_id' => 'int(11) DEFAULT NULL',
			'type_id' => 'int(11) DEFAULT NULL',
			'status_id' => 'int(11) DEFAULT NULL',
			'version' => 'int(11) DEFAULT 0',
			'locked' => 'boolean DEFAULT FALSE',
			'num_level' => 'int(11) DEFAULT 0',
			'create_time' => 'datetime DEFAULT NULL',
			'update_time' => 'datetime DEFAULT NULL',
		), 'ENGINE=InnoDB');

		//Map Account Table
		$this->createtable('tbl_map_account', array(
			'id' => 'pk',
			'account_id' =>  'int(11) DEFAULT NULL',
			'map_id' =>  'int(11) DEFAULT NULL',
		), 'ENGINE=InnoDB');
		
		//District Table
		$this->createTable('tbl_district', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
		), 'ENGINE=InnoDB');
		
		//Map Type Table
		$this->createTable('tbl_map_type', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
		), 'ENGINE=InnoDB');
		
		//Map Status Table
		$this->createTable('tbl_map_status', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
		), 'ENGINE=InnoDB');
		
		//Floor Plan
		$this->createTable('tbl_map_floor_plan', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
			'map_id' => 'int(11) DEFAULT NULL',
			'floor_num' => 'int(11) DEFAULT NULL',
			'map_path' => 'string NOT NULL',
			'dimension_lv1' => 'int(11) DEFAULT NULL',
			'dimension_lv2' => 'int(11) DEFAULT NULL',
			'dimension_lv3' => 'int(11) DEFAULT NULL',
		), 'ENGINE=InnoDB');
		
		//Annotation Table
		$this->createTable('tbl_map_floor_plan_annotation', array(
			'id' => 'pk',
			'annotation_config' => 'text',
			'map_id' => 'int(11) DEFAULT NULL',
			'floor_id' => 'int(11) DEFAULT NULL',
		), 'ENGINE=InnoDB');
		
		//Label Table
		$this->createTable('tbl_map_label', array(
			'id' => 'pk',
			'name' => 'string NOT NULL',
			'type' => 'int(11) DEFAULT 0',
			'floor_id' => 'int(11) DEFAULT NULL',
			'color_code' => 'string NOT NULL',
		), 'ENGINE=InnoDB');
				
		
		//foreign key relationships
		//the tbl_maps.district_id is a reference to tbl_district.id
		$this->addForeignKey("fk_map_district", "tbl_maps", "district_id", "tbl_district", "id", "NO ACTION", "NO ACTION");
	
		//the tbl_maps.type_id is a reference to tbl_map_type.id
		$this->addForeignKey("fk_map_type", "tbl_maps", "type_id", "tbl_map_type", "id", "NO ACTION", "NO ACTION");
	
		//the tbl_maps.status_id is a reference to tbl_map_status.id
		$this->addForeignKey("fk_map_status", "tbl_maps", "status_id", "tbl_map_status", "id", "NO ACTION", "NO ACTION");
	
		//the tbl_map_account.map_id is a reference to tbl_maps.id
		$this->addForeignKey("fk_account_map", "tbl_map_account", "map_id", "tbl_maps", "id", "NO ACTION", "NO ACTION");
		
		//the tbl_map_account.map_id is a reference to tbl_maps.id
		$this->addForeignKey("fk_account_map_account", "tbl_map_account", "account_id", "tbl_account", "id", "NO ACTION", "NO ACTION");
		
		//the tbl_map_floor_plan.map_id is a reference to tbl_maps.id
		$this->addForeignKey("fk_floor_map", "tbl_map_floor_plan", "map_id", "tbl_maps", "id", "NO ACTION", "NO ACTION"); 
		
		
		//the tbl_map_floor_plan_annotation.floor_id is a reference to tbl_map_floor_plan.id
		$this->addForeignKey("fk_annotation_map", "tbl_map_floor_plan_annotation", "map_id", "tbl_maps", "id", "NO ACTION", "NO ACTION");
		
		
		//the tbl_map_floor_plan_annotation.floor_id is a reference to tbl_map_floor_plan.id
		//$this->addForeignKey("fk_annotation_floor", "tbl_map_floor_plan_annotation", "floor_id", "tbl_map_floor_plan", "id", "NO ACTION", "NO ACTION");
		
		//the tbl_map_label.annotation_id is a reference to tbl_map_floor_plan.id
		//$this->addForeignKey("fk_annotation_label", "tbl_map_label", "annotation_id", "tbl_map_floor_plan", "id", "NO ACTION", "NO ACTION");
	
		
	}
	
	public function safeDown()
	{
		//Maps Table
		$this->truncateTable('tbl_maps');
		$this->dropTable('tbl_maps');
		
		//Map Account Table
		$this->truncateTable('tbl_map_account');
		$this->dropTable('tbl_map_account');
				
		//District Table
		$this->truncateTable('tbl_district');
		$this->dropTable('tbl_district');
		
		//Map Type Table
		$this->truncateTable('tbl_map_type');
		$this->dropTable('tbl_map_type');
		
		//Map Status Table
		$this->truncateTable('tbl_map_status');
		$this->dropTable('tbl_map_status');
		
		//Floor Plan
		$this->truncateTable('tbl_map_floor_plan');
		$this->dropTable('tbl_map_floor_plan');
		
		//Annotation Table
		$this->truncateTable('tbl_map_floor_plan_annotation');
		$this->dropTable('tbl_map_floor_plan_annotation');
		
		//Label Table
		$this->truncateTable('tbl_map_label');
		$this->dropTable('tbl_map_label');
	}
	
}