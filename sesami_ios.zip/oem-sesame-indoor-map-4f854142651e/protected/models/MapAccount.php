<?php

/**
 * This is the model class for table "tbl_map_account".
 *
 * The followings are the available columns in table 'tbl_map_account':
 * @property integer $id
 * @property integer $account_id
 * @property integer $map_id
 */
class MapAccount extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return MapAccount the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_map_account';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('account_id, map_id', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, account_id, map_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'account' => array(self::BELONGS_TO, 'Account', 'account_id'),
			'map' => array(self::BELONGS_TO, 'Maps', 'map_id'),
		);
	}

	/**
	
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'account_id' => 'Account',
			'map_id' => 'Map',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('account.name',$this->account_id);
		$criteria->compare('map.name',$this->map_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
	
	/**
	* Retrieves a list of maps Account 
	* @return array an array of available maps District.
	*/
	public function getAccountOptions()
	{
	

					
		return CHtml::listData(Account::model()->findAll(array(
                        'select'=>'id, name',
                        'condition'=>'id NOT IN( SELECT account_id FROM tbl_map_account WHERE map_id = :map_id  )',
                        'params'=>array(':map_id'=>$this->map_id)
                    )),'id','name');
	}
	
	/**
	* @return string the Account text display for the current account
	*/
	public function getAccountText()
	{
		$accountNameRecord = Account::model()->findByAttributes(array('id'=>$this->account_id));
		return $accountNameRecord->name;
	}
	
	/**
	* @return string the Map text display for the current account
	*/
	public function getMapText()
	{
		$mapNameRecord = Maps::model()->findByAttributes(array('id'=>$this->map_id));
		return $mapNameRecord->name;
	}
}