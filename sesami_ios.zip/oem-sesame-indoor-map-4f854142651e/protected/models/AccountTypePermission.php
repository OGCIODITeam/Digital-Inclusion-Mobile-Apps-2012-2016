<?php

/**
 * This is the model class for table "tbl_account_type_permission".
 *
 * The followings are the available columns in table 'tbl_account_type_permission':
 * @property integer $id
 * @property integer $create_user
 * @property integer $edit_user
 * @property integer $delete_user
 * @property integer $create_map
 * @property integer $edit_map
 * @property integer $delete_map
 *
 * The followings are the available model relations:
 * @property Account[] $accounts
 */
class AccountTypePermission extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return AccountTypePermission the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_account_type_permission';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('create_user, edit_user, delete_user, create_map, edit_map, delete_map', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, create_user, edit_user, delete_user, create_map, edit_map, delete_map', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'accounts' => array(self::HAS_MANY, 'Account', 'type_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'create_user' => 'Create User',
			'edit_user' => 'Edit User',
			'delete_user' => 'Delete User',
			'create_map' => 'Create Map',
			'edit_map' => 'Edit Map',
			'delete_map' => 'Delete Map',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('create_user',$this->create_user);
		$criteria->compare('edit_user',$this->edit_user);
		$criteria->compare('delete_user',$this->delete_user);
		$criteria->compare('create_map',$this->create_map);
		$criteria->compare('edit_map',$this->edit_map);
		$criteria->compare('delete_map',$this->delete_map);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}