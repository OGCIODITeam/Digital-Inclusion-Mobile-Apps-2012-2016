<?php

/**
 * This is the model class for table "tbl_maps".
 *
 * The followings are the available columns in table 'tbl_maps':
 * @property integer $id
 * @property string $name
 * @property string $address
 * @property integer $district_id
 * @property integer $type_id
 * @property integer $status_id
 * @property integer $version
 * @property integer $locked
  * @property integer $account_id
 * @property string $create_time
 * @property string $update_time
 *
 * The followings are the available model relations:
 * @property MapFloorPlan[] $mapFloorPlans
 * @property Account $account
 */
class Maps extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Maps the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_maps';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, address, district_id, type_id, status_id', 'required'),
			array('district_id, type_id, status_id', 'numerical', 'integerOnly'=>true),
			array('name, address', 'length', 'max'=>255),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, name, address, district_id, type_id, status_id, version, locked, create_time, update_time', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'district' => array(self::BELONGS_TO, 'District', 'district_id'),
			'type' => array(self::BELONGS_TO, 'MapType', 'type_id'),
			'status' => array(self::BELONGS_TO, 'MapStatus', 'status_id'),
			'mapFloorPlans' => array(self::HAS_MANY, 'MapFloorPlan', 'map_id'),
			'mapAccount' => array(self::HAS_MANY, 'MapAccount', 'map_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'address' => 'Address',
			'district_id' => 'District',
			'type_id' => 'Type',
			'status_id' => 'Status',
			'version' => 'Version',
			'locked' => 'Locked',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('district.name',$this->district_id);
		$criteria->compare('type.name',$this->type_id);
		$criteria->compare('status.name',$this->status_id);
		$criteria->compare('version',$this->version);
		$criteria->compare('locked',$this->locked);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
	
	public function behaviors()
	{
		return array(
			'CTimestampBehavior' => array(
			'class' => 'zii.behaviors.CTimestampBehavior',
			'createAttribute' => 'create_time',
			'updateAttribute' => 'update_time',
			'setUpdateOnCreate' => true,
			),
		);
	}
	
	/**
	* Retrieves a list of maps District
	* @return array an array of available maps District.
	*/
	public function getDistrictOptions()
	{
		return CHtml::listData(District::model()->findAll(), 'id', 'name');
	}
	
	/**
	* @return string the District text display for the current account
	*/
	public function getDistrictText()
	{
		$accountTypeRecord = District::model()->findByAttributes(array('id'=>$this->district_id));
		return $accountTypeRecord->name;
	}
	
	
	/**
	* Retrieves a list of maps types
	* @return array an array of available maps types.
	*/
	public function getTypeOptions()
	{
		return CHtml::listData(MapType::model()->findAll(), 'id', 'name');
	}
	
	/**
	* @return string the Type text display for the current account
	*/
	public function getTypeText()
	{
		$accountTypeRecord = MapType::model()->findByAttributes(array('id'=>$this->type_id));
		return $accountTypeRecord->name;
	}
	
	
	/**
	* Retrieves a list of maps status
	* @return array an array of available maps status.
	*/
	public function getStatusOptions()
	{
		return CHtml::listData(MapStatus::model()->findAll(), 'id', 'name');
	}
	
	/**
	* @return string the Status text display for the current account
	*/
	public function getStatusText()
	{
		$accountTypeRecord = MapStatus::model()->findByAttributes(array('id'=>$this->status_id));
		return $accountTypeRecord->name;
	}
}