<?php

/**
 * This is the model class for table "tbl_map_floor_plan_annotation".
 *
 * The followings are the available columns in table 'tbl_map_floor_plan_annotation':
 * @property integer $id
 * @property string $annotation_config
 * @property integer $map_id
 * @property integer $floor_id
 *
 * The followings are the available model relations:
 * @property MapFloorPlan $floor
 * @property Maps $map
 * @property MapLabel[] $mapLabels
 */
class MapFloorPlanAnnotation extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return MapFloorPlanAnnotation the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_map_floor_plan_annotation';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('map_id, floor_id', 'numerical', 'integerOnly'=>true),
			array('annotation_config', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, annotation_config, map_id, floor_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'floor' => array(self::BELONGS_TO, 'MapFloorPlan', 'floor_id'),
			'map' => array(self::BELONGS_TO, 'Maps', 'map_id'),
			'mapLabels' => array(self::HAS_MANY, 'MapLabel', 'annotation_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'annotation_config' => 'Annotation Config',
			'map_id' => 'Map',
			'floor_id' => 'Floor',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('annotation_config',$this->annotation_config,true);
		$criteria->compare('map_id',$this->map_id);
		$criteria->compare('floor_id',$this->floor_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
	
	public function getLabelOptions()
	{
		return MapLabel::model()->findAll(array(
                        'select'=>'id, name, color_code',
                        'condition'=>'floor_id=:floor_id or type=0',
                        'params'=>array(':floor_id'=>$_GET["fid"])
                    ));
	}
	
	
}