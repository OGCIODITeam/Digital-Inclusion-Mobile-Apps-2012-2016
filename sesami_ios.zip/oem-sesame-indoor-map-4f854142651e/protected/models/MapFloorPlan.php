<?php

/**
 * This is the model class for table "tbl_map_floor_plan".
 *
 * The followings are the available columns in table 'tbl_map_floor_plan':
 * @property integer $id
 * @property string $name
 * @property integer $map_id
 * @property integer $floor_num
 * @property integer $dimension_lv1
 * @property integer $dimension_lv2
 * @property integer $dimension_lv3
 *
 * The followings are the available model relations:
 * @property MapFloorAnnotation[] $mapFloorAnnotations
 * @property Maps $map
 */
class MapFloorPlan extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return MapFloorPlan the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_map_floor_plan';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name,floor_num, map_path, size ,heading', 'required'),
			//array('dimension_lv2', 'checkDimension2'),
			//array('dimension_lv3', 'checkDimension3'),
			array('floor_num,heading', 'numerical', 'integerOnly'=>true),
			array('name,map_path', 'length', 'max'=>255, 'on' => 'insert,update'),
			array('map_path', 'file','types'=>'jpg, gif, png', 'allowEmpty'=>true, 'on'=>'update'), 
			array('map_path', 'file','types'=>'jpg, gif, png', 'allowEmpty'=>false, 'on'=>'insert'), 
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, name, map_id, floor_num', 'safe', 'on'=>'search'),
		);
	}
	
	public function checkDimension2($attribute_name, $params)
	{
		if ($this->map->num_level >= 2)
		{	
			if ($this->dimension_lv2 < 0)
			{
				$this->addError($attribute_name, Yii::t('MapFloorPlan', 'Dimension Lv2 must be integer and larger than 1.'));
				return false;
			}

		}

		return true;
	}
	
	public function checkDimension3($attribute_name, $params)
	{
		if ($this->dimension_lv3 <=0)
		{
			if ($this->dimension_lv3 < 0)
			{
				$this->addError($attribute_name, Yii::t('MapFloorPlan', 'Dimension Lv2 must be integer and larger than 1.'));
				return false;
			}

		}

		return true;
	}


	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			//'mapFloorAnnotations' => array(self::HAS_MANY, 'MapFloorAnnotation', 'floor_id'),
			'map' => array(self::BELONGS_TO, 'Maps', 'map_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'map_id' => 'Map',
			'floor_num' => 'Floor Num',
			'map_path' => 'Map Path',
			'size' => 'Size',
			'heading' => 'Heading',
			//'dimension_lv2' => 'Dimension Lv2',
			//'dimension_lv3' => 'Dimension Lv3',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		//$criteria->compare('id',$this->id);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('map_id',$_GET["mid"]);
		$criteria->compare('floor_num',$this->floor_num);
		$criteria->compare('heading',$this->heading);
		//$criteria->compare('dimension_lv1',$this->dimension_lv1);
		//$criteria->compare('dimension_lv2',$this->dimension_lv2);
		//$criteria->compare('dimension_lv3',$this->dimension_lv3);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			 'sort'=>array(
            'defaultOrder'=>'floor_num ASC',
        ),
		));
	}
	
	/**
	* @return string the MapFloorPlanAnnotation id  display for the current MapFloorPlan
	*/
	public function getMapFloorPlanAnnotationId()
	{
		$MapFloorPlanAnnotationRecord = MapFloorPlanAnnotation::model()->findByAttributes(array('floor_id'=>$this->id));
		return $MapFloorPlanAnnotationRecord->id;
	}
	public function getSizeOptions() {
                return array(
                        0=>'Level 1',
                        1=>'Level 2',
						2=>'Level 3',
                );
    }
	
	public function getFloorNumOptions(){
		return array('1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5', '6' => '6', '7' => '7', '8' => '8', '9' => '9', '10' => '10');
	}
	
	public function getSizeTitle()
	{
		$result = "Level ".($this->size+1);
		return $result;
	}
	
	public function getHeadingNumOptions(){
		unset($allHeading);
		for ($i=0; $i < 360; $i++)
		{
			$allHeading[$i] = $i;
		}
		return $allHeading;
	}

}