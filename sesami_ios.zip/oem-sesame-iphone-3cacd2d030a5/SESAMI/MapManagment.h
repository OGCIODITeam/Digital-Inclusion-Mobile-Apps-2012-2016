//
//  MapManagment.h
//  SESAMI
//
//  Created by ken on 10/31/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MapManagment : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet NSUserDefaults *prefs;
    __weak IBOutlet UITableView *tableViewMap;
  IBOutlet NSMutableDictionary *receivedData;
    int counter;
    int total;
    
    IBOutlet UIImageView *mask;
    IBOutlet UIActivityIndicatorView *loading;
    IBOutlet UIView *btnView;
    BOOL firstShow;
    NSString *mapList;
    IBOutlet UIButton *clearBtn;
    IBOutlet UIButton *updateBtn;
    IBOutlet UIButton *downloadMapBtn;
}

- (IBAction)clearMapBtnHandler:(id)sender;
- (IBAction)selectMapBtnHandler:(id)sender;
- (IBAction)updateMapBtnHandler:(id)sender;
@end
