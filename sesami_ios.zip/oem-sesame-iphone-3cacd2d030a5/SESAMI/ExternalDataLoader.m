//
//  ExternalDataLoader.m
//  SESAMI
//
//  Created by Daniel Lee on 17/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "ExternalDataLoader.h"
#import <Foundation/Foundation.h>
#import "OpenRiceResult.h"

@implementation ExternalDataLoader

#pragma mark NSURLConnection Delegate Methods

#define GET_ALL_CAT_SUBPART_BUILDING 0
#define GET_ALL_CAT_SUBPART_BUSSTOP 1
#define GET_ALL_CAT_SUBPART_LANDMARK 2

- (void)loadSample{
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://share.centamap.com/hkbuorg/datafeed.ashx?func=search_near_building_by_location&lat=22.294809&lng=114.172327&radius=100"]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
}

- (void)reload{
  if(!isRequesting){
    if(requestURL != nil){
      NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:requestURL]];
      NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
      [conn description];
    }
  }
}

- (void)centaMapGetNearbyBuildingFromLocation:(CLLocation *)loc radius:(int)radius{
  isRequesting = YES;
  NSString *url = [[NSString alloc] initWithFormat:@"http://share.centamap.com/hkbuorg/datafeed.ashx?func=search_near_building_by_location&lat=%f&lng=%f&radius=%d&z=3",loc.coordinate.latitude,loc.coordinate.longitude,radius];
  NSLog(@"%@", url);
  requestURL = url;
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
}

- (void)centaMapGetNearbyBusStopFromLocation:(CLLocation *)loc zoomLevel:(int)zoomLevel{
  isRequesting = YES;
  NSString *url = [[NSString alloc] initWithFormat:@"http://share.centamap.com/hkbuorg/datafeed.ashx?func=search_nearby_bus&lat=%f&lng=%f&z=%d",loc.coordinate.latitude,loc.coordinate.longitude,zoomLevel];
  requestURL = url;
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
}

- (void)centaMapGetNearbyLandmarkFromLocation:(CLLocation *)loc zoomLevel:(int)zoomLevel{
  isRequesting = YES;
  NSString *url = [[NSString alloc] initWithFormat:@"http://share.centamap.com/hkbuorg/datafeed.ashx?func=search_near_landmarks_by_location&lat=%f&lng=%f&z=%d",loc.coordinate.latitude,loc.coordinate.longitude,zoomLevel];
  requestURL = url;
  
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
  
}

- (void)centaMapGetNearbyALLFromLocation:(CLLocation *)loc radius:(int)radius zoomLevel:(int)zoomLevel{
  isGettingAllCatForNearby = YES;
  
  arrayAllCat = [[NSMutableArray alloc] init];
  
  locAll = loc;
  radiusAll = radius;
  zoomLevelAll = zoomLevel;
  partIndex = 0;
  
  [self getAllCatPart:partIndex];
}

- (void)getAllCatPart:(int)part{
  if(part==GET_ALL_CAT_SUBPART_BUILDING){
    //get building
    [self centaMapGetNearbyBuildingFromLocation:locAll radius:radiusAll];
  }
  if(part==GET_ALL_CAT_SUBPART_BUSSTOP){
    //get bus stop
    [self centaMapGetNearbyBusStopFromLocation:locAll zoomLevel:zoomLevelAll];
  }
  if(part==GET_ALL_CAT_SUBPART_LANDMARK){
    //get landmark
    [self centaMapGetNearbyLandmarkFromLocation:locAll zoomLevel:zoomLevelAll];
  }
}

- (void)centaMapSearchBuildingWithKeyword:(NSString *)keyword{
  isRequesting = YES;
  NSString *url = [[NSString alloc] initWithFormat:@"http://share.centamap.com/hkbuorg/datafeed.ashx?func=search_by_building_name&search=%@",keyword];
  url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
  requestURL = url;
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
  
}

- (void)centaMapGetBuildingByStreetName:(NSString *)streetName StreetNumber:(int)streetNumber{
  isRequesting = YES;
  NSString *url = [[NSString alloc] initWithFormat:@"http://share.centamap.com/hkbuorg/datafeed.ashx?func=search_by_street_no&street_name=%@&street_no=%d",streetName,streetNumber];
  url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
  requestURL = url;
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
}

- (void)openRiceGetNearbyRestaurantFromLocation:(CLLocation *)loc radius:(int)radius{
  isRequesting = YES;

  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onOpenRiceReturn:) name:[AppConstant getOpenRiceCallBackName] object:nil];

  OpenRiceResult * openRice = [[OpenRiceResult alloc] init];
  [openRice getResult:loc];
}


- (void)indoor_RequestCreatePackage
{
  isRequesting = YES;
  NSString *url = @"http://192.168.0.49/hkbu/makePackage.php";
  requestURL = url;
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
}

- (void)indoor_RequestDownloadPackage
{
  isRequesting = YES;
  NSString *url = @"http://192.168.0.49/hkbu/package.zip";
  requestURL = url;
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];
}

//NSURLConnection Delegates
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
  _responseData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
  [_responseData appendData:data];
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
  return nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
  if(isGettingAllCatForNearby==YES){
    isRequesting = NO;
    NSError *error = nil;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:_responseData options:NSJSONReadingMutableContainers error:nil];
    if(!json){
      [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:error];
      return;
    }
    
    for(NSObject *obj in [json objectForKey:@"Table"]){
      [arrayAllCat addObject:obj];
    }
    
    if(partIndex<2){
      partIndex++;
      [self getAllCatPart:partIndex];
    }else{
      NSMutableDictionary *dictReturn = [[NSMutableDictionary alloc] init];
      [dictReturn setValue:arrayAllCat forKey:@"Table"];
      
      [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:dictReturn];
    }
  }else{
    isRequesting = NO;
    NSError *error = nil;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:_responseData options:NSJSONReadingMutableContainers error:&error];

    if(!json){
      [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:error];
    }else{
      [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:json];
    }
  }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
  isRequesting = NO;
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:error];
}

- (void)onOpenRiceReturn:(NSNotification *)notification {
  NSError *error = nil;
  NSMutableArray *restInfo = [[NSMutableArray alloc] init];  // converted restaurant data
  NSMutableDictionary *json = [[NSMutableDictionary alloc] init];
  
  NSLog(@"Open Rice return la -----------");
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getOpenRiceCallBackName] object:nil];
  
  // Original data from Open Rice
  NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:notification.object options:NSJSONReadingMutableContainers error:&error];
  
  NSArray *restArray = [[[[[[jsonDict objectForKey:@"Root"] objectForKey:@"Data"] objectAtIndex:0] objectForKey:@"Pois"] objectAtIndex:0] objectForKey:@"Poi"];
//  NSLog(@"Name is %@", [NSString stringWithFormat:@"%@", [rest objectForKey:@"NameLang1"]]);
  NSLog(@"Size is %i", [restArray count]);
  
  if ([restArray count] > 0) {
    for (int i=0; i<[restArray count]; i++) {
      NSMutableDictionary *node = [[NSMutableDictionary alloc] init];
      
      [node setValue:[restArray[i] objectForKey:@"NameLang1"] forKey:@"displayname"];
      [node setValue:[restArray[i] objectForKey:@"AddressLang1"] forKey:@"displayaddr"];
      [node setValue:[restArray[i] objectForKey:@"MapLatitude"] forKey:@"lpt_y"];
      [node setValue:[restArray[i] objectForKey:@"MapLongitude"] forKey:@"lpt_x"];
      
      [restInfo addObject:node];
    }
//    NSLog(@"%@", restInfo);
    
    [json setValue:restInfo forKey:@"Table"];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:json];
  } else {
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getExternalDataLoaderCallBackName] object:error];
  }
}

@end
