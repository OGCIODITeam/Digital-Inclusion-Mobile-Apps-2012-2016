//
//  PositionViewController.m
//  semami
//
//  Created by Daniel Lee on 25/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "PositionViewController.h"
#import "LocationPickerViewController.h"
#import "LocationResultTableViewController.h"
#import "AppConstant.h"
#import "OEMLocation.h"
#import "ExternalDataLoader.h"
#import "LocationDetailViewController.h"

@interface PositionViewController ()
@end

@implementation PositionViewController

#define SEARCH_TYPE_WHERE_AM_I 4001
#define SEARCH_TYPE_NEARBY 4002
#define NEARBY_CATEGORY_ALL 5000
#define NEARBY_CATEGORY_BUILDING 5001
#define NEARBY_CATEGORY_BUS_STOP 5002
#define NEARBY_CATEGORY_RESTAURANT 5003
#define NEARBY_CATEGORY_LANDMARK 5004

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }

    
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self initValue];
    [self initView];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewDidUnload {
    lblTableTitle = nil;
    viewResult = nil;
    viewHowFarResult = nil;
    btnSelectStartingLocaiton = nil;
    btnSelectEndingLocation = nil;
    tableViewResult = nil;
    locationDetailViewController = nil;
    viewNearbyCategory = nil;
    btnNearbyBuilding = nil;
    btnNearbyBusStop = nil;
    btnNearbyRestaurant = nil;
    btnNearbyLandmark = nil;
    btnNearbyAll = nil;
    [refreshTimer invalidate];
    refreshTimer = nil;
    btnHowFar = nil;
    btnNearby = nil;
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated{
    [refreshTimer invalidate];
    refreshTimer = nil;
}

- (void)initValue{
    arrayTableTitleStack = [[NSMutableArray alloc] init];
    dictContentStack = [[NSMutableDictionary alloc] init];
    
    isViewTransiting = NO;
    isSearchingNearby = NO;
    isShowLocationDetail = NO;
    
    //remove all listeners
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self stopTimer];
}
- (void)initView{
    [self showHideTableBack:NO];
    [viewContentContainer addSubview:viewMainMenu];
    
    [lblTableTitle setText:[AppLabel getPositionViewTableTitleInit]];
    [btnWhereAmI setTitle:[AppLabel getLabelWhereAmI] forState:UIControlStateNormal];
    [btnHowFar setTitle:[AppLabel getLabelHowFar] forState:UIControlStateNormal];
    [btnNearby setTitle:[AppLabel getLabelWhatsNearby] forState:UIControlStateNormal];
    
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);    
}
- (void)showHideTableBack:(BOOL)isShow{
    [btnTableBack setHidden:!isShow];
}
- (void)loadSubView:(UIView *)subView toView:(UIView *)baseView withTitle:(NSString *)title{
    //stack the current title
    [arrayTableTitleStack addObject:title];
    
    //stack the current view with current title as key
    [dictContentStack setObject:[[baseView subviews] objectAtIndex:[[baseView subviews] count]-1] forKey:title];
    
    UIView *lastView = [[baseView subviews] objectAtIndex:[[baseView subviews] count]-1];
    
    //add the new subview
    CGRect frame = subView.frame;
    frame.origin.x = frame.size.width;
    frame.origin.y = 0;
    subView.frame = frame;
    [baseView addSubview:subView];
    
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        CGRect frame = subView.frame;
        frame.origin.x = 0;
        subView.frame=frame;
    } completion:^(BOOL finished){
        //remove the last current view
        [lastView removeFromSuperview];
        isViewTransiting = NO;
        
        if([subView isEqual:viewHowFarResult]){
            //UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, [lblHowFarResult text]);
            //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, lblHowFarResult);
            [lblHowFarResult becomeFirstResponder];
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
        }else{
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
        }
    }];
    
}
- (void)unLoadViewFromBaseView:(UIView *)baseView andDisplayLastView:(UIView *)lastView{
    UIView *currentView = [[baseView subviews] objectAtIndex:[[baseView subviews] count]-1];
    
    //add the last View back to baseView
    CGRect frame = lastView.frame;
    frame.origin.x = frame.size.width;
    lastView.frame=frame;
    
    [baseView addSubview:lastView];
    [baseView bringSubviewToFront:currentView];
    
    frame.origin.x=0;
    lastView.frame=frame;

    //move out the current view
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        CGRect frame = currentView.frame;
        frame.origin.x = frame.size.width;
        currentView.frame=frame;
    } completion:^(BOOL completed){
        //remove the current        
        [currentView removeFromSuperview];
        isViewTransiting = NO;
        
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    }];
    
}
//show hide location picker
- (void)showHideLocationPicker:(BOOL)isShow{
    if(lpvc == nil){
        lpvc = [[LocationPickerViewController alloc] init];
    }
    CGRect frame = lpvc.view.frame;
    
    if(isShow){
        lblTableTitle.accessibilityElementsHidden = YES;
        btnTableBack.accessibilityElementsHidden = YES;
        
        frame.origin.y=frame.size.height;
        lpvc.view.frame=frame;
        
        [self.view addSubview:lpvc.view];
        tempView = [[viewContentContainer subviews] objectAtIndex:0];
        
        [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
            CGRect frame = lpvc.view.frame;
            frame.origin.y=0;
            lpvc.view.frame=frame;
        } completion:^(BOOL completed){
            isViewTransiting = NO;
            [tempView removeFromSuperview];
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
        }];
    }else{
        lblTableTitle.accessibilityElementsHidden = NO;
        btnTableBack.accessibilityElementsHidden = NO;
        
        
        frame.origin.y=0;
        lpvc.view.frame=frame;
        
        [viewContentContainer addSubview:tempView];
        tempView = nil;
        
        [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
            CGRect frame = lpvc.view.frame;
            frame.origin.y=frame.size.height;
            lpvc.view.frame=frame;
        } completion:^(BOOL completed){
            [lpvc.view removeFromSuperview];
            isViewTransiting = NO;
            lpvc = nil;
                        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
        }];
    }
}
- (void)showHideLocationDetail:(BOOL)isShow{
    //when show result detail, stop the refresh timer
    [self stopTimer];
    
    CGRect frame = locationDetailViewController.view.frame;
    CGRect endFrame = frame;
    if(isShow){
        frame.origin.x = frame.size.width;
        endFrame.origin.x = 0;
    }else{
        frame.origin.x = 0;
        endFrame.origin.x = endFrame.size.width;
    }
    locationDetailViewController.view.frame = frame;
    
    [self loadSubView:locationDetailViewController.view toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:@"選項"];
    
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        locationDetailViewController.view.frame=endFrame;} completion:^(BOOL finished){
            if(!isShow){
                [self unLoadViewFromBaseView:viewContentContainer andDisplayLastView:[arrayTableTitleStack objectAtIndex:[arrayTableTitleStack count]-1]];
            }else{
                isShowLocationDetail = YES;
                [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
            }
        }];
}
////////////////////////////////////////////////
//button actions
//where am i 
- (IBAction)onClickWhereAmI:(id)sender{
    if(isViewTransiting)return;
    else isViewTransiting = YES;
    
    [self showHideTableBack:YES];
    
    [self loadSubView:viewWhereAmIDirection toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:[(UIButton *)sender currentTitle]];

}
- (IBAction)onClickShowAllDirections:(id)sender{
    UIButton *resultButton = (UIButton *)sender;
    
    searchType = SEARCH_TYPE_WHERE_AM_I;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    [tvcLocationResult setData:[[NSArray alloc] init]];
    [tableViewResult reloadData];
    if(externalDataLoader==nil)
        externalDataLoader = [[ExternalDataLoader alloc] init];
    [externalDataLoader centaMapGetNearbyBuildingFromLocation:[GlobalVar getCurrentLocation] radius:500];
    [self loadResultViewWithTitle:resultButton.currentTitle];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
    
    [self startTimer];
}
- (IBAction)onClickShowFrontDirections:(id)sender{
        [self loadSampleResultView];
}
- (IBAction)onClickSelectStartingLocation:(id)sender {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationForHowFarStart:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self showHideLocationPicker:YES];
}
- (IBAction)onClickSelectEndingLocation:(id)sender {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationForHowFarEnd:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self showHideLocationPicker:YES];
}

//how far
- (IBAction)onClickHowFar:(id)sender{
    if(isViewTransiting)return;
    else isViewTransiting = YES;
    [self showHideTableBack:YES];
    
    [self loadSubView:viewHowFarSelection toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:[(UIButton *)sender currentTitle]];
}
- (IBAction)onClickHowFarCalculate:(id)sender {
    if(locationStart == nil || locationEnd == nil){
        if(locationStart == nil){
            [AppFunction quickAlertWithMessage:[AppMessage errorMissingLocationStart] title:@""];
        }else{
            [AppFunction quickAlertWithMessage:[AppMessage errorMissingLocationEnd] title:@""];
        }
    }else{
        if([[locationStart getLocationInCCLocation] distanceFromLocation:[locationEnd getLocationInCCLocation]] < [AppConstant getLocationDifferentMargin]){
            [AppFunction quickAlertWithMessage:[AppMessage errorSameLocation] title:@""];
        }else{
            [self showHideTableBack:YES];
            [self loadSubView:viewHowFarResult toView:viewContentContainer withTitle:[lblTableTitle text]];
        
            double distant = [[locationStart getLocationInCCLocation] distanceFromLocation:[locationEnd getLocationInCCLocation]];
            if(distant<=99999999)
                [lblHowFarResult setText:[NSString stringWithFormat:@"%@面, %@米",[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:[locationStart getLocationInCCLocation] ToLocation:locationEnd.getLocationInCCLocation]],[AppFunction convertNumberToChineseSentance:(int)ceil(distant)]]];
            else
                [lblHowFarResult setText:[NSString stringWithFormat:@"%@",[AppMessage getTooFarAwayMSG]]];
            
        }
    }
}

//what's nearby
- (IBAction)onClickWhatIsNearby:(id)sender {
    if(isViewTransiting)return;
    else isViewTransiting = YES;
    
    //Add listenter for LocationPicker
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationForNearBy:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self showHideLocationPicker:YES];
}
- (IBAction)onClickNearbyBuilding:(id)sender {
    [self loadNearbyResultWithLocation:locationNearbyStart category:NEARBY_CATEGORY_BUILDING];
}
- (IBAction)onClickNearbyBusStop:(id)sender {
    [self loadNearbyResultWithLocation:locationNearbyStart category:NEARBY_CATEGORY_BUS_STOP];
}
- (IBAction)onClickNearbyRestaurant:(id)sender {
}
- (IBAction)onClickNearbyLandmark:(id)sender {
    [self loadNearbyResultWithLocation:locationNearbyStart category:NEARBY_CATEGORY_LANDMARK];
}
- (IBAction)onClickNearbyAll:(id)sender {
    [self loadNearbyResultWithLocation:locationNearbyStart category:NEARBY_CATEGORY_ALL];
}

///////////////////////////////////////////////
- (IBAction)onClickTableBack:(id)sender {
    UIView *currentView = [[viewContentContainer subviews] objectAtIndex:[[viewContentContainer subviews] count]-1];
    if(isSearchingNearby){
        if ([currentView isEqual:viewNearbyCategory]) {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationForNearBy:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
            [self showHideLocationPicker:YES];
            isSearchingNearby = NO;
            
        }
    }
    //stop the timer when leaving the result listing view
    if([currentView isEqual:viewResult]){
        [self stopTimer];        
    }
    //start up the timer when leaving the result detail and back to result listing view
    if([currentView isEqual:locationDetailViewController.view]){
        [self startTimer];
    }
    
    [lblTableTitle setText:[arrayTableTitleStack objectAtIndex:[arrayTableTitleStack count]-1]];
    
    [self unLoadViewFromBaseView:viewContentContainer andDisplayLastView:[dictContentStack objectForKey:[arrayTableTitleStack objectAtIndex:[arrayTableTitleStack count]-1]]];
    
    //update stacks
    [dictContentStack removeObjectForKey:[arrayTableTitleStack objectAtIndex:[arrayTableTitleStack count]-1]];
    [arrayTableTitleStack removeLastObject];
    
    if([arrayTableTitleStack count]==0){
        [self showHideTableBack:NO];
    }
    
    if(isShowLocationDetail){
        isShowLocationDetail=NO;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResultDisclosure:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        locationDetailViewController = nil;
    }else{
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];        
    }
    
}

//event handling
- (void)onSelectedLocationForHowFarStart:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self showHideLocationPicker:NO];

    if(notification.object != nil){
        locationStart = notification.object;
        //[btnSelectStartingLocaiton setTitle:[(OEMLocation *)notification.object getDisplayName] forState:UIControlStateNormal];
        [btnSelectStartingLocaiton setTitle:[NSString stringWithFormat:@"由:%@",[(OEMLocation *)notification.object getDisplayName]] forState:UIControlStateNormal];
    }
}
- (void)onSelectedLocationForHowFarEnd:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self showHideLocationPicker:NO];    
    
    if(notification.object != nil){
        locationEnd = notification.object;
        //[btnSelectEndingLocation setTitle:[(OEMLocation *)notification.object getDisplayName] forState:UIControlStateNormal];
        [btnSelectEndingLocation setTitle:[NSString stringWithFormat:@"去:%@",[(OEMLocation *)notification.object getDisplayName]] forState:UIControlStateNormal];
    }
}
- (void)onSelectedLocationForNearBy:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
    [self showHideLocationPicker:NO];

    locationNearbyStart = nil;    
    if(notification.object != nil){
        isSearchingNearby = YES;
        locationNearbyStart = (OEMLocation *)notification.object;
        [self loadNearbyCategoryView];
    }
    lpvc = nil;
}
- (void)loadNearbyCategoryView{
    [self showHideTableBack:YES];
    [self loadSubView:viewNearbyCategory toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:@"選擇搜尋類別"];
}
- (void)loadNearbyResultWithLocation:(OEMLocation *)location category:(int)catID{
    
    searchType = SEARCH_TYPE_NEARBY;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    [tvcLocationResult setData:[[NSArray alloc] init]];
    [tableViewResult reloadData];
    if(externalDataLoader==nil)
        externalDataLoader = [[ExternalDataLoader alloc] init];
    
    if(catID == NEARBY_CATEGORY_BUILDING){
        [externalDataLoader centaMapGetNearbyBuildingFromLocation:location.getLocationInCCLocation radius:500];
        [self loadResultViewWithTitle:btnNearbyBuilding.titleLabel.text];
    }
    if(catID == NEARBY_CATEGORY_LANDMARK){
        [externalDataLoader centaMapGetNearbyLandmarkFromLocation:location.getLocationInCCLocation zoomLevel:[AppConstant getDefaultZoomLevelForCentamap]];
        [self loadResultViewWithTitle:btnNearbyLandmark.titleLabel.text];
    }
    if(catID == NEARBY_CATEGORY_BUS_STOP){
        [externalDataLoader centaMapGetNearbyBusStopFromLocation:location.getLocationInCCLocation zoomLevel:[AppConstant getDefaultZoomLevelForCentamap]];
        [self loadResultViewWithTitle:btnNearbyBusStop.titleLabel.text];
    }
    if(catID == NEARBY_CATEGORY_ALL){
        [externalDataLoader centaMapGetNearbyALLFromLocation:location.getLocationInCCLocation radius:500 zoomLevel:[AppConstant getDefaultZoomLevelForCentamap]];
        [self loadResultViewWithTitle:btnNearbyAll.titleLabel.text];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
}

- (void)onClickResultDisclosure:(NSNotification *)notification{
    if(notification.object!=nil){
        if(locationDetailViewController==nil)
            locationDetailViewController = [[LocationDetailViewController alloc] initWithLocation:((OEMLocation *)notification.object)];
        //NSLog(@"id : %d",[((OEMLocation *)notification.object) getLocationID ]);
        //[self showHideLocationDetail:YES];
        [self stopTimer];
        [self loadSubView:locationDetailViewController.view toView:viewContentContainer withTitle:[lblTableTitle text]];
        [lblTableTitle setText:@"選項"];
        isShowLocationDetail = YES;
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
    }
}

- (void)onExternalDataReturn:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    if([notification.object isKindOfClass:[NSError class]]){
        tableViewResult.hidden = YES;
        [lblTableViewMessage setText:[AppMessage getServerDownMSG]];
    }else{
        NSDictionary *json = (NSDictionary *)notification.object;
        
        ;        if ([json count]==0) {
            tableViewResult.hidden = YES;
            [lblTableViewMessage setText:[AppMessage getNoResultMSG]];
            return;
        }
        
        CLLocation *cLocation = [GlobalVar getCurrentLocation];
        tableViewResult.hidden = NO;
        //notification.object saved the array of researched location
        //put create OEMLocation for all locations and push into arrayLocation
        NSMutableArray *arrayLocationForSort = [[NSMutableArray alloc] init];
        NSMutableArray *arrayLocation = [[NSMutableArray alloc] init];

        for(NSDictionary *node in (NSArray *)[json objectForKey:@"Table"]){
            CLLocation *nLocation = [[CLLocation alloc] initWithLatitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"]doubleValue]];
            OEMLocation *location;
            
            if([[node objectForKey:@"rid"] isEqual:nil] || ([node objectForKey:@"rid"]==NULL)){
                location = [[OEMLocation alloc] initWithName:[node objectForKey:@"displayname"] latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:[node objectForKey:@"displayaddr"]];
            }else{
                //is bus
                NSString *busStopDisplayName = [[NSString alloc] initWithFormat:@"%@:往%@",[node objectForKey:@"namec"],[node objectForKey:@"tnamec"]];
                location = [[OEMLocation alloc] initWithName:busStopDisplayName latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:@""];
            }

            NSArray *arrNode = [[NSArray alloc] initWithObjects:[NSNumber numberWithDouble:[nLocation distanceFromLocation:cLocation]], location, nil];
            [arrayLocationForSort addObject:arrNode];
        }

        NSArray *arrayLocationSorted = [arrayLocationForSort sortedArrayUsingComparator:^(id a, id b){
            return [[a objectAtIndex:0] compare:[b objectAtIndex:0]];
        }];
        
        if(searchType==SEARCH_TYPE_NEARBY){
            for(NSArray *node in arrayLocationSorted){
                [arrayLocation addObject:[node objectAtIndex:1]];
            }
        }else{
            for(int c=0; c<[GlobalVar getNearByBuildingDisplayTotal];c++){
                [arrayLocation addObject:[[arrayLocationSorted objectAtIndex:c] objectAtIndex:1 ]];
            }
        }
        
        //start listen to the click event and the click disclosure of the row in the result tableView
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
        //[[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResultDisclosure:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        
        if(tvcLocationResult == nil)
            tvcLocationResult = [[LocationResultTableViewController alloc] initWithData:arrayLocation];
        else
            [tvcLocationResult setData:arrayLocation];
        [tableViewResult setDataSource:tvcLocationResult];
        [tableViewResult setDelegate:tvcLocationResult];
        tvcLocationResult.tableView = tableViewResult;
        [tableViewResult reloadData];
    }
}

- (void)loadSampleResultView{
    [self showHideTableBack:YES];
    [self loadSubView:viewResult toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:@" "];
}
- (void)loadResultViewWithTitle:(NSString *)title{
    [self showHideTableBack:YES];
    [self loadSubView:viewResult toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:title];
}
- (void)reloadRequest{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    [externalDataLoader reload];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];

}

- (void)startTimer{
    if(refreshTimer == nil){
        refreshTimer = [NSTimer scheduledTimerWithTimeInterval:[GlobalVar getAlertInterval]
                                                    target:self
                                                  selector:@selector(reloadRequest)
                                                  userInfo:nil
                                                   repeats:YES];
    }
}
- (void)stopTimer{
    [refreshTimer invalidate];
    refreshTimer = nil;
}
- (IBAction)onClickTestButton:(id)sender{
    /*
    OEMLocation *currentLocation = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
    [self showHowFarViewWithLocationEnd:currentLocation];
     */
    CLLocation *locCenter = [[CLLocation alloc] initWithLatitude:22.303172 longitude:114.1277];
    CLLocation *locA = [[CLLocation alloc] initWithLatitude:22.352734 longitude:114.170651];
    //CLLocation *locB = [[CLLocation alloc] initWithLatitude:22.280321 longitude:114.22509];
    //CLLocation *locC = [[CLLocation alloc] initWithLatitude:22.250067 longitude:114.169396];
    //CLLocation *locD = [[CLLocation alloc] initWithLatitude:22.282713 longitude:114.126803];
    
    //[AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locA];
    //[AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locB];
    //[AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locC];
    //[AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locD];
    NSLog(@"%@",[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:locCenter ToLocation:locA]]);
}

//function for favorate
- (void)showHowFarViewWithLocationEnd:(OEMLocation *)locEnd{
    [self initValue];
    [self initView];

    OEMLocation *currentLocation = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
    locationStart = currentLocation;
    locationEnd = locEnd;
    [btnSelectStartingLocaiton setTitle:[locationStart getDisplayName] forState:UIControlStateNormal];
    [btnSelectEndingLocation setTitle:[locationEnd getDisplayName] forState:UIControlStateNormal];
    
    isViewTransiting = YES;
    [self showHideTableBack:YES];
    [self loadSubView:viewHowFarSelection toView:viewContentContainer withTitle:@"位置選單"];
    [lblTableTitle setText:[AppLabel getLabelHowFar]];
}
- (void)showNearbyViewWithLocation:(OEMLocation *)loc{
    [self initValue];
    [self initView];
    
    locationNearbyStart = nil;
    isSearchingNearby = YES;
    locationNearbyStart = loc;
    [self loadNearbyCategoryView];
     
}

@end
