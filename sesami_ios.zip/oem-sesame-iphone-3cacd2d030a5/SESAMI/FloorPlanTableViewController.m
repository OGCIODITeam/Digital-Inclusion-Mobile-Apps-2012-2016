//
//  LocationResultTableViewController.m
//  SESAMI
//
//  Created by Daniel Lee on 9/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "FloorPlanTableViewController.h"
#import "OEMFloorPlan.h"

@interface FloorPlanTableViewController ()

@end

@implementation FloorPlanTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(id)initWithData:(NSArray *)data{
    if((self = [super init])){
    }
    
    arrayData = data;
    isDisableDisclosureButton = YES;
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setData:(NSArray *)data{
    arrayData = data;
}
-(void)disableDisclosureButton:(BOOL)isDisable{
    isDisableDisclosureButton = isDisable;
}
#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    if(!isDisableDisclosureButton){
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    }
    // Configure the cell...
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 60;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.text = [(OEMMap *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
    cell.textLabel.backgroundColor = [UIColor clearColor];
    
    cell.accessibilityValue = @"";
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}
@end
