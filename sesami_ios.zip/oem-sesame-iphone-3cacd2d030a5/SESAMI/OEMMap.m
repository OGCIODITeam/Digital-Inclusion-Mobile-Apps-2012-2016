//
//  OEMLocation.m
//  semami
//
//  Created by Daniel Lee on 5/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "OEMMap.h"

@implementation OEMMap

@synthesize mapID = _mapID;
@synthesize displayName = _displayName;
@synthesize address = _address;
@synthesize description = _description;
@synthesize categoryID = _categoryID;
@synthesize categoryName = _categoryName;
@synthesize districtID = _districtID;

- (id)initWithMapID:(int)mapID Name:(NSString *)mapName Address:(NSString *)address Description:(NSString *)description CatID:(int)catID DisID:(int)disID
{
  if((self = [super init])){
    self.mapID = mapID;
    self.displayName = mapName;
    self.address = address;
    self.description = description;
    self.categoryID = catID;
    self.districtID = disID;
  }
  return self;
}

- (id)initWithCatID:(int)catID Name:(NSString *)catName
{
  if((self = [super init])){
    self.categoryID = catID;
    self.categoryName = catName;
  }
  return self;
}

- (void)setMapIDWithInt:(int)newID
{
  self.mapID = newID;
}

- (int)getMapID
{
  return self.mapID;
}

- (NSString *)getDisplayName
{
  return self.displayName;
}

- (NSString *)getAddress
{
  return self.address;
}

- (NSString *)getDescription
{
  return self.description;
}

- (int)getCategoryID
{
  return self.categoryID;
}

- (NSString *)getCategoryName
{
  return self.categoryName;
}

- (int)getDistrictID
{
  return self.districtID;
}

@end
