//
//  InformationViewController.h
//  SESAMI
//
//  Created by Ray.Liu on 9/18/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InformationViewController : BaseViewController <UITextViewDelegate, UIScrollViewDelegate>

@end
