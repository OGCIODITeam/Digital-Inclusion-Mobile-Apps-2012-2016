//
//  SettingViewController.m
//  SESAMI
//
//  Created by Daniel Lee on 25/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "SettingViewController.h"
#import "GlobalVar.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

#define TAG_NEARBY_BUILDING 2001
#define TAG_ALERT_INTERVAL 2002

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    tableViewNearbyBuildingOption.tag = TAG_NEARBY_BUILDING;
    tableViewAlertIntervalOption.tag = TAG_ALERT_INTERVAL;
    
    arrayNearbyBuildingItems = [[NSArray alloc] initWithObjects:@"1",@"2",@"4",@"10",@"20",@"50", nil];
    arrayAlertIntervalItems = [[NSArray alloc] initWithObjects:@"5秒",@"15秒",@"30秒",@"1分鐘",@"5分鐘",@"15分鐘", nil];
    arrayAlertIntervalItemsValue = [[NSArray alloc] initWithObjects:@"5",@"15",@"30",@"60",@"300",@"900", nil];
    
    [viewContentContainer addSubview:viewMain];
    
    [self setAutoUpdateIndoorMap:[GlobalVar getAutoUpdateIndoorMap]];

    [self showHideTableBack:NO];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {

    viewNearbyBuildingOption = nil;
    tableViewNearbyBuildingOption = nil;
    viewAlertIntervalOption = nil;
    tableViewAlertIntervalOption = nil;
    btnNearbyBuilding = nil;
    btnAlertInterval = nil;
    btnToggleAutoUpdateIndoorMap = nil;
    viewContentContainer = nil;
    viewMain = nil;
    lblTableTitle = nil;
    btnTableBack = nil;
    [super viewDidUnload];
}

/////////////////////////////////
- (void)showHideTableBack:(BOOL)isShow{
    [btnTableBack setHidden:!isShow];
}
/////////////////////////////////
- (IBAction)onClickNearbyBuilding:(id)sender {
    [tableViewNearbyBuildingOption reloadData];
    [viewContentContainer addSubview:viewNearbyBuildingOption];
    [self showHideTableBack:YES];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);    
}
- (IBAction)onClickAlertInterval:(id)sender {
    [tableViewAlertIntervalOption reloadData];
    [self showHideTableBack:YES];    
    [viewContentContainer addSubview:viewAlertIntervalOption];
    
    //tableViewAlertIntervalOption.accessibilityElementsHidden = YES;
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}
- (IBAction)onClickAutoUpdateIndoorMap:(id)sender {
    [self setAutoUpdateIndoorMap:![GlobalVar getAutoUpdateIndoorMap]];
}
- (IBAction)onClickTableBack:(id)sender {
    [self showHideTableBack:NO];
    
    [viewAlertIntervalOption removeFromSuperview];
    [viewNearbyBuildingOption removeFromSuperview];
}


//on off auto update indoor map
- (void)setAutoUpdateIndoorMap:(BOOL)isOn{
    [GlobalVar setAutoUpdateIndoorMap:isOn];
    if(isOn){
        [btnToggleAutoUpdateIndoorMap setTitle:@"已開啟自動更新室內地圖" forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_green.png"] forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_green_highlighted.png"] forState:UIControlStateHighlighted];
    }else{
        [btnToggleAutoUpdateIndoorMap setTitle:@"已關閉自動更新室內地圖" forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_red.png"] forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_red_highlighted.png"] forState:UIControlStateHighlighted];
    }
}

//tableview
#pragma uitableview delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [viewAlertIntervalOption removeFromSuperview];
    [viewNearbyBuildingOption removeFromSuperview];
    
    if(tableView.tag == TAG_NEARBY_BUILDING){
        [GlobalVar setNearByBuildingDisplayTotal:[[arrayNearbyBuildingItems objectAtIndex:indexPath.row] intValue ]];
    }
    if(tableView.tag == TAG_ALERT_INTERVAL){
        [GlobalVar setAlertInterval:[[arrayAlertIntervalItemsValue objectAtIndex:indexPath.row] intValue]];
    }
    
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

#pragma uitableview datasource
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView.tag == TAG_NEARBY_BUILDING){
        return [arrayNearbyBuildingItems count];
    }
    if(tableView.tag == TAG_ALERT_INTERVAL){
        return [arrayAlertIntervalItems count];
    }
    return 0;//[arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    //cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    
    // Configure the cell...
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 60;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    
    if(tableView.tag == TAG_NEARBY_BUILDING){
        cell.textLabel.text = [arrayNearbyBuildingItems objectAtIndex:indexPath.row];
        
        if([GlobalVar getNearByBuildingDisplayTotal] == [[arrayNearbyBuildingItems objectAtIndex:indexPath.row] intValue]){
            [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
    }
    if(tableView.tag == TAG_ALERT_INTERVAL){
        cell.textLabel.text = [arrayAlertIntervalItems objectAtIndex:indexPath.row];
        
        if([GlobalVar getAlertInterval] == [[arrayAlertIntervalItemsValue objectAtIndex:indexPath.row] intValue]){
            [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
    }
    
    return cell;
}

@end
