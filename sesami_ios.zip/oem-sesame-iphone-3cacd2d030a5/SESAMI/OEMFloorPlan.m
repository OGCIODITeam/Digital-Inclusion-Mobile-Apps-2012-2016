//
//  OEMLocation.m
//  semami
//
//  Created by Daniel Lee on 5/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "OEMFloorPlan.h"

@implementation OEMFloorPlan

@synthesize floorPlanID = _floorPlanID;
@synthesize displayName = _displayName;
@synthesize description = _description;
@synthesize level = _level;
@synthesize image = _image;
@synthesize data = _data;
@synthesize dataLabel = _dataLabel;


- (id)initWithFloorPlanID:(int)floorPlanID Name:(NSString *)floorPlanName Description:(NSString *)floorDescription Level:(int)floorPlanLevel Image:(NSString *)floorPlanImage Data:(NSString *)floorPlanData DataLabel:(NSArray *)floorPlanDataLabel
{
  if((self = [super init])){
    self.floorPlanID = floorPlanID;
    self.displayName = floorPlanName;
    self.description = floorDescription;
    self.level = floorPlanLevel;
    self.image = floorPlanImage;
    self.data = floorPlanData;
    self.dataLabel = floorPlanDataLabel;
  }
  return self;
}

- (void)setFloorPlanIDWithInt:(int)newID
{
  self.floorPlanID = newID;
}

- (int)getFloorPlanID
{
  return self.floorPlanID;
}

- (NSString *)getDisplayName
{
  return self.displayName;
}

- (NSString *)getDescription
{
  return self.description;
}

- (int)getLevel
{
  return self.level;
}

- (NSString *)getImage
{
  return self.image;
}

- (NSString *)getData
{
  return self.data;
}

- (NSArray *)getDataLabel
{
  return self.dataLabel;
}

@end
