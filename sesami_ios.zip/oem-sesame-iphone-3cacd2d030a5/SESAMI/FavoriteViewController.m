//
//  FavoriteViewController.m
//  SESAMI
//
//  Created by Daniel Lee on 9/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "FavoriteViewController.h"
#import "LocationResultTableViewController.h"
#import "LocationDetailViewController.h"
#import "OEMLocation.h"

@interface FavoriteViewController ()

@end

@implementation FavoriteViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self initData];
    [self initView];
    
}

- (void)initView{
    [self showHideTableBack:NO];

    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
    
    if(tvcLocationResult==nil)
        tvcLocationResult = [[LocationResultTableViewController alloc] initWithData:arrayFavorite];

    [tableViewFavorite setDataSource:tvcLocationResult];
    [tableViewFavorite setDelegate:tvcLocationResult];
    [viewContentContainer addSubview:viewFavorite];
    tvcLocationResult.tableView = tableViewFavorite;
    [lblTableTitle setText:@"我的最愛"];
    [tableViewFavorite reloadData];
}

- (void)initData{
    arrayFavorite = [[NSArray alloc] initWithArray:[OEMDB getAllFavoriteLocations]];
}

- (void)reloadView{
    [self initData];
    [self initView];
}

- (void)showHideTableBack:(BOOL)isShow{
    [btnTableBack setHidden:!isShow];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName ] object:nil];
    
    viewContentContainer = nil;
    btnTableBack = nil;
    lblTableTitle = nil;

    viewFavorite = nil;
    tableViewFavorite = nil;
    
    locationDetailViewController = nil;
    
    [super viewDidUnload];
}

- (void)showHideLocationDetail:(BOOL)isShow{
    [viewContentContainer addSubview:viewFavorite];
    CGRect frame = locationDetailViewController.view.frame;
    CGRect endFrame = frame;
    if(isShow){
        frame.origin.x = frame.size.width;
        endFrame.origin.x = 0;
    }else{
        frame.origin.x = 0;
        endFrame.origin.x = endFrame.size.width;
    }
    locationDetailViewController.view.frame = frame;
    [viewContentContainer addSubview:locationDetailViewController.view];
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        locationDetailViewController.view.frame=endFrame;} completion:^(BOOL finished){
            if(!isShow){
                [locationDetailViewController.view removeFromSuperview];
                locationDetailViewController = nil;
                
            }else{
                [viewFavorite removeFromSuperview];
            }
            
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);            
    }];

}

//button event
- (IBAction)onClickTableBack:(id)sender {
    [self showHideLocationDetail:NO];
    [self showHideTableBack:NO];
    [self reloadView];
}

//event handle
- (void)onClickResult:(NSNotification *)notification{
    if(notification.object!=nil){
        [self showHideTableBack:YES];
        if(locationDetailViewController==nil)
            locationDetailViewController = [[LocationDetailViewController alloc] initWithLocation:((OEMLocation *)notification.object)];
        [self showHideLocationDetail:YES];
        [lblTableTitle setText:@"選項"];
    }
}

@end
