//
//  FloorPlanViewController.m
//  SESAMI
//
//  Created by Ray.Liu on 8/20/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "FloorPlanViewController.h"
#import "OEMFloorPlan.h"
#import "AppDelegate.h"

@implementation FloorPlanViewController

@synthesize locationManager;

NSString *currentLevel3, *currentLevel2, *currentLevel1;  // what level the user is currently on, Level 1 is the lowest (most detailed) level

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
  self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
  if (self)
  {
    myFloorPlan = [self.myExtraData objectForKey:@"floorPlan"];
    
    currentLevel = myFloorPlan.level;
    btnZoomList = [[NSMutableArray alloc] init];
    lblDataLabelList = [[NSMutableArray alloc] init];
    zoomFrameList = [[NSMutableArray alloc] init];
    zoomHistory = [[NSMutableArray alloc] init];  // Richard
    
    allowZoom = YES;
    
    isNorth = NO;
    //init compass
    locationManager=[[CLLocationManager alloc] init];
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.delegate=self;
    //Start the compass updates.
      if ([[[UIDevice currentDevice]systemVersion]floatValue] >= 8.0 && [CLLocationManager authorizationStatus]!= kCLAuthorizationStatusAuthorizedWhenInUse)
      {
          [locationManager requestWhenInUseAuthorization];
      }
      else
      {
          [locationManager startUpdatingLocation];
          [locationManager startUpdatingHeading];
      }
      
      
      
  
    
    
    
    imageViewSize = 304;  // change this if use different image view size
    labelArr = [[myFloorPlan.data componentsSeparatedByString:@","] mutableCopy];
    // descArr = [IndoorDB getAllDataLabelWithFloorPlanID:myFloorPlan.floorPlanID];
    descArr = myFloorPlan.dataLabel;
  }
  return self;
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
        case kCLAuthorizationStatusNotDetermined:{
            NSLog(@"Not determined");
            [locationManager startUpdatingLocation];
            [locationManager startUpdatingHeading];
        } break;
        case kCLAuthorizationStatusDenied: {
            NSLog(@"Denied");
        } break;
        case kCLAuthorizationStatusAuthorizedWhenInUse:
        case kCLAuthorizationStatusAuthorizedAlways: {
            NSLog(@"Grant permission");
            [locationManager startUpdatingLocation];
            [locationManager startUpdatingHeading];
        }break;
        default:
            break;
    }
}

- (void)viewDidLoad
{
  [super viewDidLoad];
  
  
  AppDelegate *s = (AppDelegate *)[[UIApplication sharedApplication] delegate];
  NSString *filePath = [NSString stringWithFormat:@"%@/%@", s.documentsDir, myFloorPlan.image];
  
  [floorPlanImageView setImage:[[UIImage alloc] initWithContentsOfFile:filePath]];
  [self genDataLabel];
  [self disableAllButtonAndLabelAccessibility];
  [self setMoveButtons];
  
  if (currentLevel == 1) {
    [voiceLabel setAccessibilityValue:@"地圖第一層"];
  }
  else if (currentLevel == 2) {
    [voiceLabel setAccessibilityValue:@"地圖第二層"];
  }
  else if (currentLevel == 3) {
    [voiceLabel setAccessibilityValue:@"地圖第三層"];
  }
  
  [NSTimer scheduledTimerWithTimeInterval:2.0
                                   target:self
                                 selector:@selector(playFloorPlanLevelCompletedHandler)
                                 userInfo:nil
                                  repeats:NO];
  UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
  
  // Cannot recognize gesture when VO is ON, following code is not working
//  UISwipeGestureRecognizer *swipeRecognizer =
//  [[UISwipeGestureRecognizer alloc]
//   initWithTarget:self
//   action:@selector(handleSwipeGesture:)];
//  swipeRecognizer.direction = UISwipeGestureRecognizerDirectionDown;
//  [self.view addGestureRecognizer:swipeRecognizer];
//  
//  UISwipeGestureRecognizer *swipeRecognizer1 =
//  [[UISwipeGestureRecognizer alloc]
//   initWithTarget:self
//   action:@selector(handleSwipeGesture:)];
//  swipeRecognizer1.direction = UISwipeGestureRecognizerDirectionUp;
//  [self.view addGestureRecognizer:swipeRecognizer1];
//  
//  UISwipeGestureRecognizer *swipeRecognizer2 =
//  [[UISwipeGestureRecognizer alloc]
//   initWithTarget:self
//   action:@selector(handleSwipeGesture:)];
//  swipeRecognizer2.direction = UISwipeGestureRecognizerDirectionRight;
//  [self.view addGestureRecognizer:swipeRecognizer2];
//  
//  UISwipeGestureRecognizer *swipeRecognizer3 =
//  [[UISwipeGestureRecognizer alloc]
//   initWithTarget:self
//   action:@selector(handleSwipeGesture:)];
//  swipeRecognizer3.direction = UISwipeGestureRecognizerDirectionLeft;
//  [self.view addGestureRecognizer:swipeRecognizer3];
//  //-- end
}

// No use
-(void)handleSwipeGesture:(UISwipeGestureRecognizer *)recognizer
{
  // Seems still have a little problem in up/down
  CGRect endFrame;
  int posX, posY;
  NSMutableDictionary *tmpDict;
  
  if (currentLevel == 1) {
    return;
  } else if (currentLevel == 2) {
      if ([zoomHistory count] >=1)
      {
          tmpDict = [zoomHistory objectAtIndex:0];
          posX = [[tmpDict objectForKey:@"x"] intValue];
          posY = [[tmpDict objectForKey:@"y"] intValue];
      }
  } else if (currentLevel == 3) {
      if ([zoomHistory count] >=2)
      {
          tmpDict = [zoomHistory objectAtIndex:1];
          posX = [[tmpDict objectForKey:@"x"] intValue];
          posY = [[tmpDict objectForKey:@"y"] intValue];
      }
  }
  
  if (recognizer.direction == UISwipeGestureRecognizerDirectionLeft) {
    NSLog(@"Swipe left");
    if (posX == 3) {
      NSLog(@"Already at right edge");
      return;
    }
    posX++;
    endFrame = CGRectMake(floorPlanImageView.frame.origin.x-imageViewSize, floorPlanImageView.frame.origin.y,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
    
  };
  if (recognizer.direction == UISwipeGestureRecognizerDirectionRight) {
    NSLog(@"Swipe right");
    if (posX == 1) {
      NSLog(@"Already at left edge");
      return;
    }
    posX--;
    endFrame = CGRectMake(floorPlanImageView.frame.origin.x+imageViewSize, floorPlanImageView.frame.origin.y,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
  }
  if (recognizer.direction == UISwipeGestureRecognizerDirectionUp){
    NSLog(@"Swipe up");
    if (posY == 3) {
      NSLog(@"Already at bottom");
      return;
    }
    posY++;
    endFrame = CGRectMake(floorPlanImageView.frame.origin.x, floorPlanImageView.frame.origin.y-imageViewSize,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
    
  };
  if (recognizer.direction == UISwipeGestureRecognizerDirectionDown){
    NSLog(@"Swipe down");
    if (posY == 1) {
      NSLog(@"Already at top");
      return;
    }
    posY--;
    endFrame = CGRectMake(floorPlanImageView.frame.origin.x, floorPlanImageView.frame.origin.y+imageViewSize,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
    
  };
  
  NSMutableDictionary *tmpDict2 = [[NSMutableDictionary alloc] init];
  [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
  [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
  if (zoomHistory.count>0)
  {
    [zoomHistory removeObjectAtIndex:zoomHistory.count-1];
  }
  [zoomHistory addObject:tmpDict2];
  
  [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
    floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
      [self genDataLabel];
    }];
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = @"室內地圖";
  
  [MainNavigationController
   InitCustomNavigationWithController:self
   ShowLeft:YES LeftTitle:@""
   ShowRight:NO RightTitle:@""];
}

- (void)didReceiveMemoryWarning
{
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

- (void)genDataLabel
{
  int x1, x2, y1, y2;
  NSMutableDictionary *tmpDict, *tmpDict2;
  
  [self clearDataLabeAndButton];
//  NSLog(@"History - %@", zoomHistory);  // Richard
  
  if (currentLevel == 3)  // top level
  {
    for (int a = 0; a < btnZoomList.count; a++)
    {
      [[btnZoomList objectAtIndex:a] removeFromSuperview];
    }
    
    int row = 3;
    int col = 3;
    CGFloat x = 8.0;
    CGFloat y = 8.0;
    CGFloat width = self.view.frame.size.width / row;
    CGFloat height = self.view.frame.size.height / col;
    
    // Using the frame.size is not very reliable
    width = imageViewSize/row; height = imageViewSize/col;
    
    int currentIndex = 0;
    
    for (int i = 0; i < row; i++)
    {
      x = 8.0;
      
      for (int j = 0; j < col; j++)
      {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(x, y, width, height)];
        [btn setTitle:@" " forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont fontWithName:@"Arial" size:10.0]];
        [btn setAccessibilityTraits:UIAccessibilityTraitNone];
        [btn addTarget:self action:@selector(btnZoom_Click:) forControlEvents:UIControlEventTouchUpInside];
        
        //[btn setAccessibilityValue:[NSString stringWithFormat:@"第%@格",[AppFunction getChineseCharFromInt:currentIndex+1]]];
        /********************************************************************************/
        
        x1 = j * 48 + 1; y1 = i * 48 + 1;
        x2 = x1 + 47; y2 = y1 + 47;
        // NSLog(@"Getting (%i, %i) - (%i, %i)", x1, y1, x2, y2);
        // NSLog(@"Label String - %@", [self findLabels:x1 X2:x2 Y1:y1 Y2:y2]);
        NSString *labelString;
        labelString = [NSString stringWithFormat:@"%c 格 ", (i*3+j+65)];
        [btn setAccessibilityValue:[labelString stringByAppendingString:[self findLabels:x1 X2:x2 Y1:y1 Y2:y2]]];
        
        /********************************************************************************/
        
        [btn setBackgroundColor:[UIColor clearColor]];
        [self.view addSubview:btn];
        [btnZoomList addObject:btn];
        btn = nil;
        
        x += width;
        
        currentIndex++;
      }
      
      y += height;
    }
  }
  else if (currentLevel == 2)
  {
    for (int a = 0; a < btnZoomList.count; a++)
    {
      [[btnZoomList objectAtIndex:a] removeFromSuperview];
    }
    
    int row = 3;
    int col = 3;
    CGFloat x = 8.0;
    CGFloat y = 8.0;
    CGFloat width = self.view.frame.size.width / row;
    CGFloat height = self.view.frame.size.height / col;
    
    // Using frame.size is not very reliable
    width = imageViewSize/row; height = imageViewSize/col;
    
    int xOffset = 0;
    int yOffset = 0;
    if (myFloorPlan.level == 3) {
      tmpDict = [zoomHistory objectAtIndex:0];
      xOffset = ([[tmpDict objectForKey:@"x"] intValue] - 1) * 48;
      yOffset = ([[tmpDict objectForKey:@"y"] intValue] - 1) * 48;
    }
    
    int currentIndex = 0;
    
    for (int i = 0; i < row; i++)
    {
      x = 8.0;
      
      for (int j = 0; j < col; j++)
      {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(x, y, width, height)];
        [btn setTitle:@" " forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont fontWithName:@"Arial" size:10.0]];
        [btn setAccessibilityTraits:UIAccessibilityTraitNone];
        [btn addTarget:self action:@selector(btnZoom_Click:) forControlEvents:UIControlEventTouchUpInside];
        
        //[btn setAccessibilityValue:[NSString stringWithFormat:@"第%@格",[AppFunction getChineseCharFromInt:currentIndex+1]]];
        /********************************************************************************/
        
        x1 = j * 16 + 1 + xOffset; y1 = i * 16 + 1 + yOffset;
        x2 = x1 + 15; y2 = y1 + 15;
        // NSLog(@"Getting (%i, %i) - (%i, %i)", x1, y1, x2, y2);
        // NSLog(@"Label String - %@", [self findLabels:x1 X2:x2 Y1:y1 Y2:y2]);
        NSString *labelString;
        if (myFloorPlan.level == 3) {
          labelString = [NSString stringWithFormat:@"%c %c 格 ",
                         ([[tmpDict objectForKey:@"y"] intValue]-1)*3 + ([[tmpDict objectForKey:@"x"] intValue]-1)+65, (i*3+j+49)];
        } else {
          labelString = [NSString stringWithFormat:@"%c 格 ", (i*3+j+49)];
          NSLog(@"%@", labelString);
        }
        [btn setAccessibilityValue:[labelString stringByAppendingString:[self findLabels:x1 X2:x2 Y1:y1 Y2:y2]]];
        
        /********************************************************************************/
        
        [btn setBackgroundColor:[UIColor clearColor]];
        [self.view addSubview:btn];
        [btnZoomList addObject:btn];
        
        btn = nil;
        
        x += width;
        
        currentIndex++;
      }
      
      y += height;
    }
  }
  else if (currentLevel == 1)
  {
    /* for 16x16 grid
    int row = 16;
    int col = 16;
    */
    int row = 4;
    int col = 4;
    
    CGFloat x = 8.0;
    CGFloat y = 8.0;
    CGFloat width = self.view.frame.size.width / row;
    CGFloat height = self.view.frame.size.height / col;
    
    // User frame.size is not very reliable
    width = imageViewSize/row; height = imageViewSize/col;
    
    int xOffset = 0;
    int yOffset = 0;
    if (myFloorPlan.level == 3) {
      tmpDict = [zoomHistory objectAtIndex:0];
      xOffset = ([[tmpDict objectForKey:@"x"] intValue] - 1) * 48;
      yOffset = ([[tmpDict objectForKey:@"y"] intValue] - 1) * 48;
      tmpDict2 = [zoomHistory objectAtIndex:1];
      xOffset += ([[tmpDict2 objectForKey:@"x"] intValue] - 1) * 16;
      yOffset += ([[tmpDict2 objectForKey:@"y"] intValue] - 1) * 16;
    } else if (myFloorPlan.level == 2) {
      tmpDict2 = [zoomHistory objectAtIndex:0];
      xOffset += ([[tmpDict2 objectForKey:@"x"] intValue] - 1) * 16;
      yOffset += ([[tmpDict2 objectForKey:@"y"] intValue] - 1) * 16;
    }
    
    int currentIndex = 0;
    //NSArray *data = [AppFunction getObjectWithFloorPlanDataString:myFloorPlan.data];
    
    for (int i = 0; i < row; i++)
    {
      x = 8.0;
      
      for (int j = 0; j < col; j++)
      {
        //NSString *labelID = [data objectAtIndex:currentIndex];
        
        UILabel *label = [[UILabel alloc] init];
        [label setFrame:CGRectMake(x, y, width, height)];
        [label setText:@" "];
        [label setFont:[UIFont fontWithName:@"Arial" size:10.0f]];
        
        /* for 16x16 grid
        x1 = j + 1 + xOffset; y1 = i + 1 + yOffset;
        x2 = x1; y2 = y1;
        */
        x1 = j * 4 + 1 + xOffset; y1 = i * 4 + 1 + yOffset;
        x2 = x1 + 3; y2 = y1 + 3;

        // NSLog(@"Getting (%i, %i) - (%i, %i)", x1, y1, x2, y2);
        // NSLog(@"Label String - %@", [self findLabels:x1 X2:x2 Y1:y1 Y2:y2]);
        [label setAccessibilityValue:[self findLabels:x1 X2:x2 Y1:y1 Y2:y2]];
        
        /********************************************************************************/
        
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextAlignment:NSTextAlignmentCenter];
        [self.view addSubview:label];
        [lblDataLabelList addObject:label];
        
        label = nil;
        
        x += width;
        
        currentIndex++;
      }
      
      y += height;
    }
  }
  [self setMoveButtons];
}

- (void)btnZoom_Click:(id)sender
{
  if (!allowZoom)
  {
    return;
  }
  
  UIButton *target = (UIButton *)sender;
  
  if (currentLevel == 3)
  {
    [self disableAllButtonAndLabelAccessibility];
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(playFloorPlanLevelCompletedHandler)
                                   userInfo:nil
                                    repeats:NO];
    [voiceLabel setAccessibilityValue:@"地圖第二層"];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
    
    currentLevel3 = target.accessibilityValue;
    CGRect endFrame = CGRectMake((target.frame.origin.x-8)*-3, (target.frame.origin.y-8)*-3 ,imageViewSize*3, imageViewSize*3);
    
    NSMutableDictionary *tmpDict = [[NSMutableDictionary alloc] init];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.origin.x] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.origin.y] forKey:@"y"];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.size.width] forKey:@"w"];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.size.height] forKey:@"h"];
    [zoomFrameList addObject:tmpDict];
    
    //-- Richard
    NSMutableDictionary *tmpDict2 = [[NSMutableDictionary alloc] init];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", (int)floor((target.frame.origin.x-8)/(imageViewSize/3)+1)] forKey:@"x"];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", (int)floor((target.frame.origin.y-8)/(imageViewSize/3)+1)] forKey:@"y"];
    [zoomHistory addObject:tmpDict2];
    
    //      NSLog(@"%f, %f, %f, %f, %f, %f", target.frame.origin.x, target.frame.origin.y, endFrame.origin.x, endFrame.origin.y, endFrame.size.width, endFrame.size.height);
    //      NSLog(@"%i, %i", (int)target.frame.origin.x/(imageViewSize/3)+1, (int)target.frame.origin.y/(imageViewSize/3)+1);
    //-- end Richard
    
    allowZoom = NO;
    
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
      floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
        currentLevel = 2;
        [self genDataLabel];
        allowZoom = YES;
      }];
  }
  else if (currentLevel == 2)
  {
    [self disableAllButtonAndLabelAccessibility];
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(playFloorPlanLevelCompletedHandler)
                                   userInfo:nil
                                    repeats:NO];
    [voiceLabel setAccessibilityValue:@"地圖第一層"];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
    
    currentLevel2 = target.accessibilityValue;
    
    CGRect endFrame = CGRectMake((target.frame.origin.x-8)*-3+floorPlanImageView.frame.origin.x*3, (target.frame.origin.y-8)*-3+floorPlanImageView.frame.origin.y*3 ,floorPlanImageView.frame.size.width*3,floorPlanImageView.frame.size.height*3);
    
    NSMutableDictionary *tmpDict = [[NSMutableDictionary alloc] init];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.origin.x] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.origin.y] forKey:@"y"];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.size.width] forKey:@"w"];
    [tmpDict setValue:[NSString stringWithFormat:@"%f", floorPlanImageView.frame.size.height] forKey:@"h"];
    [zoomFrameList addObject:tmpDict];
    
    //-- Richard
    NSMutableDictionary *tmpDict2 = [[NSMutableDictionary alloc] init];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", (int)floor((target.frame.origin.x-8)/(imageViewSize/3)+1)] forKey:@"x"];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", (int)floor((target.frame.origin.y-8)/(imageViewSize/3)+1)] forKey:@"y"];
    [zoomHistory addObject:tmpDict2];
    
    //      NSLog(@"%f, %f, %f, %f, %f, %f", target.frame.origin.x, target.frame.origin.y, endFrame.origin.x, endFrame.origin.y, endFrame.size.width, endFrame.size.height);
    //      NSLog(@"%i, %i", (int)target.frame.origin.x/104+1, (int)target.frame.origin.y/(imageViewSize/3)+1);
    //-- end Richard
    
    allowZoom = NO;
    
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
      floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
        currentLevel = 1;
        [self genDataLabel];
        allowZoom = YES;
      }];
  }
//  NSLog(@"%@", zoomFrameList);
}

-(void)setMoveButtons
{
  NSMutableDictionary * tmpDict;
  int posX3, posY3, posX2, posY2;
  NSString *btnStr;
  
  [btnMoveUp setEnabled:NO];
  [btnMoveRight setEnabled:NO];
  [btnMoveDown setEnabled:NO];
  [btnMoveLeft setEnabled:NO];
  
  if (myFloorPlan.level == currentLevel)  // nothing to zoom
    return;
  
  if (myFloorPlan.level == 2) {
    tmpDict = [zoomHistory objectAtIndex:0];
    posX2 = [[tmpDict objectForKey:@"x"] intValue];
    posY2 = [[tmpDict objectForKey:@"y"] intValue];
    if (posX2 != 1) {
      [btnMoveLeft setEnabled:YES];
      [btnMoveLeft setAccessibilityLabel:
       [NSString stringWithFormat:@"去 %c 格 ", (posX2-1-1)+(posY2-1)*3+49]];
    }
    if (posX2 != 3) {
      [btnMoveRight setEnabled:YES];
      [btnMoveRight setAccessibilityLabel:
       [NSString stringWithFormat:@"去 %c 格 ", (posX2-1+1)+(posY2-1)*3+49]];
    }
    if (posY2 != 1) {
      [btnMoveUp setEnabled:YES];
      [btnMoveUp setAccessibilityLabel:
       [NSString stringWithFormat:@"去 %c 格 ", (posX2-1)+(posY2-1-1)*3+49]];
    };
    if (posY2 != 3) {
      [btnMoveDown setEnabled:YES];
      [btnMoveDown setAccessibilityLabel:
       [NSString stringWithFormat:@"去 %c 格 ", (posX2-1)+(posY2-1+1)*3+49]];
    };
  } else if (myFloorPlan.level == 3) {
    tmpDict = [zoomHistory objectAtIndex:0];
    posX3 = [[tmpDict objectForKey:@"x"] intValue];
    posY3 = [[tmpDict objectForKey:@"y"] intValue];
    if (currentLevel == 2) {
      if (posX3 != 1) {
        [btnMoveLeft setEnabled:YES];
        [btnMoveLeft setAccessibilityLabel:
         [NSString stringWithFormat:@"去 %c 格 ", (posX3-1-1)+(posY3-1)*3+65]];
      }
      if (posX3 != 3) {
        [btnMoveRight setEnabled:YES];
        [btnMoveRight setAccessibilityLabel:
         [NSString stringWithFormat:@"去 %c 格 ", (posX3-1+1)+(posY3-1)*3+65]];
      }
      if (posY3 != 1) {
        [btnMoveUp setEnabled:YES];
        [btnMoveUp setAccessibilityLabel:
         [NSString stringWithFormat:@"去 %c 格 ", (posX3-1)+(posY3-1-1)*3+65]];
      };
      if (posY3 != 3) {
        [btnMoveDown setEnabled:YES];
        [btnMoveDown setAccessibilityLabel:
         [NSString stringWithFormat:@"去 %c 格 ", (posX3-1)+(posY3-1+1)*3+65]];
      };
    } else {
      tmpDict = [zoomHistory objectAtIndex:1];
      posX2 = [[tmpDict objectForKey:@"x"] intValue];
      posY2 = [[tmpDict objectForKey:@"y"] intValue];
      
      if (posX3 != 1 || posX2 != 1) {
        [btnMoveLeft setEnabled:YES];
        if (posX2 != 1){
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1)+(posY3-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (posX2-1-1)+(posY2-1)*3+49]];
        } else {
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1-1)+(posY3-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (3-1)+(posY2-1)*3+49]];
        }
        NSLog(@"%@", btnStr);
        [btnMoveLeft setAccessibilityLabel:btnStr];
      }
      if (posX3 != 3 || posX2 != 3) {
        [btnMoveRight setEnabled:YES];
        if (posX2 != 3){
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1)+(posY3-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (posX2-1+1)+(posY2-1)*3+49]];
        } else {
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1+1)+(posY3-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (1-1)+(posY2-1)*3+49]];
        }
        NSLog(@"%@", btnStr);
        [btnMoveRight setAccessibilityLabel:btnStr];
      }
      if (posY3 != 1 || posY2 != 1) {
        [btnMoveUp setEnabled:YES];
        if (posY2 != 1){
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1)+(posY3-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (posX2-1)+(posY2-1-1)*3+49]];
        } else {
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1)+(posY3-1-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (posX2-1)+(3-1)*3+49]];
        }
        NSLog(@"%@", btnStr);
        [btnMoveUp setAccessibilityLabel:btnStr];
      };
      if (posY3 != 3 || posY2 != 3) {
        [btnMoveDown setEnabled:YES];
        if (posY2 != 3){
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1)+(posY3-1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (posX2-1)+(posY2-1+1)*3+49]];
        } else {
          btnStr = [NSString stringWithFormat:@"去 %c", (posX3-1)+(posY3-1+1)*3+65];
          btnStr = [btnStr stringByAppendingString:[NSString stringWithFormat:@" %c 格 ", (posX2-1)+(1-1)*3+49]];
        }
        NSLog(@"%@", btnStr);
        [btnMoveDown setAccessibilityLabel:btnStr];
      };
    }
  }
  
}

- (void)clearDataLabeAndButton
{
  for (int a = 0; a < btnZoomList.count; a++)
  {
    [[btnZoomList objectAtIndex:a] removeFromSuperview];
  }
  
  for (int b = 0; b < lblDataLabelList.count; b++)
  {
    [[lblDataLabelList objectAtIndex:b] removeFromSuperview];
  }
}

- (void)zoomOut
{
  if (!allowZoom)
  {
    return;
  }
  
  if (currentLevel == myFloorPlan.level)
  {
    currentLevel = 3;
  }
  else
  {
    if (currentLevel == 1)
    {
      //NSLog(@"ZOOM OUT FROM LEVEL1 TO LEVEL2");
      [voiceLabel setAccessibilityValue:@"地圖第二層"];
      UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
      
      NSMutableDictionary *lastDict = [zoomFrameList objectAtIndex:zoomFrameList.count-1];
      CGFloat x = [[lastDict objectForKey:@"x"] floatValue];
      CGFloat y = [[lastDict objectForKey:@"y"] floatValue];
      CGFloat w = [[lastDict objectForKey:@"w"] floatValue];
      CGFloat h = [[lastDict objectForKey:@"h"] floatValue];
      
      CGRect endFrame = CGRectMake(x, y ,w, h);
      allowZoom = NO;
      [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
          currentLevel = 2;
          //[UIPageViewController setCurrentFloorPlanLevel:currentLevel];
          [zoomFrameList removeObjectAtIndex:zoomFrameList.count-1];
          [self genDataLabel];
          allowZoom = YES;
        }];
      
    }
    else if (currentLevel == 2)
    {
      //NSLog(@"ZOOM OUT FROM LEVEL2 TO LEVEL3");
      [voiceLabel setAccessibilityValue:@"地圖第三層"];
      UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
      
      NSMutableDictionary *lastDict = [zoomFrameList objectAtIndex:zoomFrameList.count-1];
      CGFloat x = [[lastDict objectForKey:@"x"] floatValue];
      CGFloat y = [[lastDict objectForKey:@"y"] floatValue];
      CGFloat w = [[lastDict objectForKey:@"w"] floatValue];
      CGFloat h = [[lastDict objectForKey:@"h"] floatValue];
      
      CGRect endFrame = CGRectMake(x, y ,w, h);
      allowZoom = NO;
      [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
          currentLevel = 3;
          //[myParentViewController setCurrentFloorPlanLevel:currentLevel];
          [zoomFrameList removeObjectAtIndex:zoomFrameList.count-1];
          [self genDataLabel];
          allowZoom = YES;
        }];
    }
    [zoomHistory removeObjectAtIndex:zoomHistory.count-1];  // Richard
    
  }
}

- (void)enableAllButtonAndLabelAccessibility {
  for (int i = 0; i < btnZoomList.count; i++) {
    ((UIButton *)[btnZoomList objectAtIndex:i]).isAccessibilityElement = YES;
  }
  for (int i = 0; i < lblDataLabelList.count; i++) {
    ((UILabel *)[lblDataLabelList objectAtIndex:i]).isAccessibilityElement = YES;
  }
  
}

- (void)disableAllButtonAndLabelAccessibility {
  for (int i = 0; i < btnZoomList.count; i++) {
    ((UIButton *)[btnZoomList objectAtIndex:i]).isAccessibilityElement = NO;
  }
  for (int i = 0; i < lblDataLabelList.count; i++) {
    ((UILabel *)[lblDataLabelList objectAtIndex:i]).isAccessibilityElement = NO;
  }
}

- (void)playFloorPlanLevelCompletedHandler {
  [self enableAllButtonAndLabelAccessibility];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{
	//NSLog(@"New magnetic heading: %f", newHeading.magneticHeading);
	//NSLog(@"New true heading: %f", newHeading.trueHeading);
  
  if ([self isViewLoaded] && [self.view window] != nil) {
    if (
        (newHeading.trueHeading >= 330.0 && newHeading.trueHeading <= 360.0)
        ||
        (newHeading.trueHeading >= 0.0 && newHeading.trueHeading <= 30.0)
        ) {
      if (!isNorth) {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
        //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, @"已面向北方");
      }
      isNorth = YES;
    }
    else {
      isNorth = NO;
    }
  }
}

#pragma mark - MainNavigataion

- (void)btnNavLeft_Click:(id)sender
{
  NSLog(@"current level: %i", currentLevel);
  
  if (currentLevel == myFloorPlan.level || currentLevel == 3)
  {
    [super btnNavLeft_Click:sender];
  }
  else if (currentLevel == 2)
  {
    [self zoomOut];
  }
  else if (currentLevel == 1)
  {
    [self zoomOut];
  }
}

-(NSString*) findLabels:(int)x1 X2:(int)x2 Y1:(int)y1 Y2:(int)y2
{
  int offset;
  NSString *labelStr = @"";
  
  NSMutableDictionary *labelDict = [[NSMutableDictionary alloc] init];
  NSMutableDictionary *tmpDict = [[NSMutableDictionary alloc] init];
  
  for (int i=0; i<[descArr count]; i++) {
    tmpDict = descArr[i];
    [labelDict setValue:[tmpDict objectForKey:@"labelName"] forKey:[tmpDict objectForKey:@"labelID"]];
  }
  
  int rowLength;
  if (myFloorPlan.level == 3) {
    rowLength = 144;
  } else if (myFloorPlan.level == 2) {
    rowLength = 48;
  } else {
    rowLength = 16;
  }
  for (int i=y1; i<=y2; i++) {
    for (int j=x1; j<=x2; j++) {
      offset = (i-1)*rowLength + j - 1;
      if (![[labelArr objectAtIndex:offset] isEqualToString:@""]) {
        if ([labelDict objectForKey:[labelArr objectAtIndex:offset]]) {
          if ([labelStr rangeOfString:[labelDict objectForKey:[labelArr objectAtIndex:offset]]].location == NSNotFound)
            labelStr = [labelStr stringByAppendingString:[labelDict objectForKey:[labelArr objectAtIndex:offset]]];
        } else {
          //labelStr = [labelStr stringByAppendingString:[labelArr objectAtIndex:offset]];
        }
        labelStr = [labelStr stringByAppendingString:@" "];
      }
    }
  }
  
  return labelStr;
}

- (IBAction)moveUp:(id)sender {
  CGRect endFrame;
  int posX, posY, posX1, posY1;
  NSMutableDictionary *tmpDict, *tmpDict1, *tmpDict2;
  
  NSLog(@"Move Up");
  tmpDict = [zoomHistory objectAtIndex:([zoomHistory count]-1)];
  posX = [[tmpDict objectForKey:@"x"] intValue];
  posY = [[tmpDict objectForKey:@"y"] intValue];
  
  posY--;
  if (posY > 0) {
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory removeObjectAtIndex:zoomHistory.count-1];
    [zoomHistory addObject:tmpDict];
  } else {
    posY = 3;
    tmpDict1 = [zoomHistory objectAtIndex:0];
    posX1 = [[tmpDict1 objectForKey:@"x"] intValue];
    posY1 = [[tmpDict1 objectForKey:@"y"] intValue];
    posY1--;
    
    [zoomHistory removeAllObjects];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posX1] forKey:@"x"];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posY1] forKey:@"y"];
    [zoomHistory addObject:tmpDict1];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory addObject:tmpDict];
    
    // Move the map
    tmpDict2 = [zoomFrameList objectAtIndex:([zoomFrameList count]-1)];
    posX = [[tmpDict2 objectForKey:@"x"] intValue];
    posY = [[tmpDict2 objectForKey:@"y"] intValue] + 303;
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomFrameList removeObjectAtIndex:zoomFrameList.count-1];
    [zoomFrameList addObject:tmpDict2];
  }
  
  endFrame = CGRectMake(floorPlanImageView.frame.origin.x, floorPlanImageView.frame.origin.y+imageViewSize,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
  
  [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
    floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
      [self genDataLabel];
    }];
}

- (IBAction)moveRight:(id)sender {
  CGRect endFrame;
  int posX, posY, posX1, posY1;
  NSMutableDictionary *tmpDict, *tmpDict1, *tmpDict2;
  
  NSLog(@"Move Right");
  tmpDict = [zoomHistory objectAtIndex:([zoomHistory count]-1)];
  posX = [[tmpDict objectForKey:@"x"] intValue];
  posY = [[tmpDict objectForKey:@"y"] intValue];
  
  posX++;
  if (posX <= 3) {
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory removeObjectAtIndex:zoomHistory.count-1];
    [zoomHistory addObject:tmpDict];
  } else {
    posX = 1;
    tmpDict1 = [zoomHistory objectAtIndex:0];
    posX1 = [[tmpDict1 objectForKey:@"x"] intValue];
    posY1 = [[tmpDict1 objectForKey:@"y"] intValue];
    posX1++;
    
    [zoomHistory removeAllObjects];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posX1] forKey:@"x"];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posY1] forKey:@"y"];
    [zoomHistory addObject:tmpDict1];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory addObject:tmpDict];
    
    // Move the map
    tmpDict2 = [zoomFrameList objectAtIndex:([zoomFrameList count]-1)];
    posX = [[tmpDict2 objectForKey:@"x"] intValue] - 303;
    posY = [[tmpDict2 objectForKey:@"y"] intValue];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomFrameList removeObjectAtIndex:zoomFrameList.count-1];
    [zoomFrameList addObject:tmpDict2];
  }
  
  endFrame = CGRectMake(floorPlanImageView.frame.origin.x-imageViewSize, floorPlanImageView.frame.origin.y,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
  
  [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
    floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
      [self genDataLabel];
    }];
}

- (IBAction)moveDown:(id)sender {
  CGRect endFrame;
  int posX, posY, posX1, posY1;
  NSMutableDictionary *tmpDict, *tmpDict1, *tmpDict2;
  
  NSLog(@"Move Down");
  tmpDict = [zoomHistory objectAtIndex:([zoomHistory count]-1)];
  posX = [[tmpDict objectForKey:@"x"] intValue];
  posY = [[tmpDict objectForKey:@"y"] intValue];
  
  posY++;
  if (posY <= 3) {
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory removeObjectAtIndex:zoomHistory.count-1];
    [zoomHistory addObject:tmpDict];
  } else {
    posY = 1;
    tmpDict1 = [zoomHistory objectAtIndex:0];
    posX1 = [[tmpDict1 objectForKey:@"x"] intValue];
    posY1 = [[tmpDict1 objectForKey:@"y"] intValue];
    posY1++;
    
    [zoomHistory removeAllObjects];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posX1] forKey:@"x"];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posY1] forKey:@"y"];
    [zoomHistory addObject:tmpDict1];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory addObject:tmpDict];
    
    // Move the map
    tmpDict2 = [zoomFrameList objectAtIndex:([zoomFrameList count]-1)];
    posX = [[tmpDict2 objectForKey:@"x"] intValue];
    posY = [[tmpDict2 objectForKey:@"y"] intValue] - 303;
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomFrameList removeObjectAtIndex:zoomFrameList.count-1];
    [zoomFrameList addObject:tmpDict2];
  }
  
  
  endFrame = CGRectMake(floorPlanImageView.frame.origin.x, floorPlanImageView.frame.origin.y-imageViewSize,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
  
  [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
    floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
      [self genDataLabel];
    }];
}

- (IBAction)moveLeft:(id)sender {
  CGRect endFrame;
  int posX, posY, posX1, posY1;
  NSMutableDictionary *tmpDict, *tmpDict1, *tmpDict2;
  
  NSLog(@"Move Left");
  tmpDict = [zoomHistory objectAtIndex:([zoomHistory count]-1)];
  posX = [[tmpDict objectForKey:@"x"] intValue];
  posY = [[tmpDict objectForKey:@"y"] intValue];
  
  posX--;
  if (posX > 0) {
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory removeObjectAtIndex:zoomHistory.count-1];
    [zoomHistory addObject:tmpDict];
  } else {
    posX = 3;
    tmpDict1 = [zoomHistory objectAtIndex:0];
    posX1 = [[tmpDict1 objectForKey:@"x"] intValue];
    posY1 = [[tmpDict1 objectForKey:@"y"] intValue];
    posX1--;
    
    [zoomHistory removeAllObjects];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posX1] forKey:@"x"];
    [tmpDict1 setValue:[NSString stringWithFormat:@"%i", posY1] forKey:@"y"];
    [zoomHistory addObject:tmpDict1];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomHistory addObject:tmpDict];
    
    // Move the map
    tmpDict2 = [zoomFrameList objectAtIndex:([zoomFrameList count]-1)];
    posX = [[tmpDict2 objectForKey:@"x"] intValue] + 303;
    posY = [[tmpDict2 objectForKey:@"y"] intValue];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posX] forKey:@"x"];
    [tmpDict2 setValue:[NSString stringWithFormat:@"%i", posY] forKey:@"y"];
    [zoomFrameList removeObjectAtIndex:zoomFrameList.count-1];
    [zoomFrameList addObject:tmpDict2];
  }
  
  endFrame = CGRectMake(floorPlanImageView.frame.origin.x+imageViewSize, floorPlanImageView.frame.origin.y,floorPlanImageView.frame.size.width,floorPlanImageView.frame.size.height);
  
  [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
    floorPlanImageView.frame=endFrame;} completion:^(BOOL finished){
      [self genDataLabel];
    }];
}
- (void)viewDidUnload {
  NSLog(@"Unload FloorPlanViewController");
  
  btnMoveUp = nil;
  btnMoveRight = nil;
  btnMoveDown = nil;
  btnMoveLeft = nil;
  [locationManager stopUpdatingHeading];
  [super viewDidUnload];
}

@end
