
//
//  MapManagment.m
//  SESAMI
//
//  Created by ken on 10/31/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MapManagment.h"
#import "CustomURLConnection.h"
#import "OEMFloorPlan.h"

#include <sys/xattr.h>

@interface MapManagment ()

@end

@implementation MapManagment


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
    // Custom initialization
  }
  return self;
}

- (void)viewDidLoad
{
  [super viewDidLoad];
  
//  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
//  {
//    [tableViewMap setContentInset:UIEdgeInsetsMake(-40, tableViewMap.contentInset.left, tableViewMap.contentInset.bottom, tableViewMap.contentInset.right)];
//  }
//  if ([AppConstant getScreenHeight] == 568)
//  {
//    [btnView setFrame:CGRectMake(0, btnView.frame.origin.y+100, btnView.frame.size.width, btnView.frame.size.height)];
//  }
  [tableViewMap reloadData];
  
  prefs = [NSUserDefaults standardUserDefaults];
  
  tableViewMap.tag =   [prefs integerForKey:@"mapManagementTab"];
  firstShow = true;
  // Do any additional setup after loading the view from its nib.
  
  if ([prefs integerForKey:@"mapManagementTab"]==0)
  {
    [self downloadDB];
  }
  else
  {
    //        [loading stopAnimating];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    [mask setHidden:TRUE];
  }
}

- (void)viewWillAppear:(BOOL)animated
{
  if ([prefs integerForKey:@"mapManagementTab"]>0)
  {
    //     [prefs setInteger:([prefs integerForKey:@"mapManagementTab"]-1) forKey:@"mapManagementTab"];
  }
  tableViewMap.tag =   [prefs integerForKey:@"mapManagementTab"];
  [tableViewMap reloadData];
  self.title = @"地圖管理";
  mapList = @"";
  /*[MainNavigationController
   InitNavigationWithController:self
   ShowLeft:YES LeftTitle:@"返回"
   ShowRight:NO RightTitle:@""];*/
}

-(void) viewWillDisappear:(BOOL)animated {
  [prefs setInteger:([prefs integerForKey:@"mapManagementTab"]-1) forKey:@"mapManagementTab"];
}
- (void)btnNavLeft_Click:(id)sender
{
  //tableViewMap.tag = tableViewMap.tag -1;
  //[tableViewMap reloadData];
  [prefs setInteger:([prefs integerForKey:@"mapManagementTab"]-1) forKey:@"mapManagementTab"];
  [self.myNavigationController popViewControllerAnimated:TRUE];
  
}


- (void)didReceiveMemoryWarning
{
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

- (void) downloadDB
{
  [mask setHidden:false];
  //    [loading startAnimating];
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
  
  total =1;
  counter=0;
  receivedData = [[NSMutableDictionary alloc] init];
  NSURL *url1 = [NSURL URLWithString:@"http://sesame.hkbu.org.hk/hkbu/indoor/package/indoormap.sqlite"];
  [self startAsyncLoad:url1 tag:@"db"];
}

- (void) downloadMap:(int)map_id
{
  [mask setHidden:false];
  //    [loading startAnimating];
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
  
  NSArray *temp = [IndoorDB getAllFloorPlanWithMapID:map_id];
  total = [temp count];
  counter = 0;
  receivedData = [[NSMutableDictionary alloc] init];
  
  for (int i=0; i < [ temp count]; i++)
  {
    OEMFloorPlan *temp1 = [temp objectAtIndex:i];
    NSLog(@"%@",[NSString stringWithFormat:@"http://sesame.hkbu.org.hk/hkbu/indoor/maps/%@",[temp1 getImage]]);
    NSURL *url1 = [NSURL URLWithString:[[NSString stringWithFormat:@"http://sesame.hkbu.org.hk/hkbu/indoor/maps/%@",[temp1 getImage]]stringByAddingPercentEscapesUsingEncoding:
                                        NSUTF8StringEncoding]];
    [self startAsyncLoad:url1 tag:[temp1 getImage]];
  }
}

- (void) downloadMaps:(NSString *)mapIDList
{
  [mask setHidden:false];
  //    [loading startAnimating];
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
  
  NSArray *temp = [IndoorDB getAllFloorPlanWithMapIDs:mapIDList];
  total = [temp count];
  counter = 0;
  receivedData = [[NSMutableDictionary alloc] init];
  
  for (int i=0; i < [ temp count]; i++)
  {
    OEMFloorPlan *temp1 = [temp objectAtIndex:i];
    NSLog(@"%@",[NSString stringWithFormat:@"http://sesame.hkbu.org.hk/hkbu/indoor/maps/%@",[temp1 getImage]]);
    NSURL *url1 = [NSURL URLWithString:[[NSString stringWithFormat:@"http://sesame.hkbu.org.hk/hkbu/indoor/maps/%@",[temp1 getImage]]stringByAddingPercentEscapesUsingEncoding:
                                        NSUTF8StringEncoding]];
    [self startAsyncLoad:url1 tag:[temp1 getImage]];
  }
}

- (void) deleteMaps:(NSString *)mapIDList
{
  //[mask setHidden:false];
  //[loading startAnimating];
  
  NSArray *temp = [IndoorDB getAllFloorPlanWithMapIDs:mapIDList];
  total = [temp count];
  counter = 0;
  receivedData = [[NSMutableDictionary alloc] init];
  
  for (int i=0; i < [ temp count]; i++)
  {
    OEMFloorPlan *temp1 = [temp objectAtIndex:i];
    //NSLog(@"%@",[NSString stringWithFormat:@"http://sesame.hkbu.org.hk/hkbu/indoor/maps/%@",[temp1 getImage]]);
    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [dirPaths objectAtIndex:0];
    
    
    NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: [temp1 getImage]]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:databasePath error:NULL];
    
    
  }
}
-(void)startAsyncLoad:(NSURL*)url tag:(NSString*)tag{
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
	CustomURLConnection *connection = [[CustomURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES tag:tag btn:nil img:nil];
	
	if (connection) {
		[receivedData setObject:[NSMutableData data] forKey:connection.tag];
	}
}

- (NSMutableData*)dataForConnection:(CustomURLConnection*)connection {
	NSMutableData *data = [receivedData objectForKey:connection.tag];
	return data;
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	NSMutableData *dataForConnection = [self dataForConnection:(CustomURLConnection*)connection];
	[dataForConnection setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	NSMutableData *dataForConnection = [self dataForConnection:(CustomURLConnection*)connection];
	[dataForConnection appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	
  counter++;
	NSMutableData *dataForConnection = [self dataForConnection:(CustomURLConnection*)connection];
	
  if ([[(CustomURLConnection*)connection tag]isEqualToString:@"db"])
  {
    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [dirPaths objectAtIndex:0];
    
    
    NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"indoormap.sqlite"]];//
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:databasePath error:NULL];
    
    [dataForConnection writeToFile:databasePath atomically:YES];
    
    [IndoorDB initDB];
     [downloadMapBtn setEnabled:TRUE];
    
  }
  else
  {
    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [dirPaths objectAtIndex:0];
    
    
    NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: [(CustomURLConnection*)connection tag]]];//
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:databasePath error:NULL];
    
    [dataForConnection writeToFile:databasePath atomically:YES];
    
  }
  
  if (total == counter)
  {
    NSMutableArray *temp = [[prefs objectForKey:@"selectedMapList"]mutableCopy];
    if (temp == nil)
    {
      temp = [[NSMutableArray alloc]init];
    }
    
    BOOL addBefore = false;
    for (int i=0; i < [temp count]; i++)
    {
      NSMutableDictionary *tempRecord = [temp objectAtIndex:i];
      if ([[tempRecord objectForKey:@"mapid"] isEqualToString:[NSString stringWithFormat:@"%d",[prefs integerForKey:@"selectedMapID"]]])
      {
        addBefore = true;
      }
    }
    if (addBefore == false && ![[(CustomURLConnection*)connection tag]isEqualToString:@"db"])
    {
      NSMutableDictionary *tempRecord =  [[NSMutableDictionary alloc]init];
      [tempRecord setObject:[NSString stringWithFormat:@"%d",[prefs integerForKey:@"selectedMapID"]] forKey:@"mapid"];
      [tempRecord setObject:[prefs objectForKey:@"selectedMapName"] forKey:@"display"];
      [temp addObject:tempRecord];
      [prefs setObject:temp forKey:@"selectedMapList"];
        NSString *mapList1 =@"";
        for (int i=0; i < [[prefs objectForKey:@"selectedMapList"]count]; i++)
        {
            NSDictionary *temp = [[prefs objectForKey:@"selectedMapList"]objectAtIndex:i];
            
            if (![mapList1 isEqualToString:@""])
            {
                mapList1 = [NSString stringWithFormat:@"%@,",mapList1];
            }
            
            mapList1 = [NSString stringWithFormat:@"%@%@",mapList1,[temp objectForKey:@"mapid"]];
            
        }
        [prefs setObject:mapList1 forKey:@"mapList"];
        NSLog(@"MapList : %@",mapList1);
    }
    NSLog(@"%@",@"DOWNLOAD COMPLETE");
    [mask setHidden:TRUE];
    //        [loading stopAnimating];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, @"完成下載");
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    
    // tableViewMap.tag =0;
    firstShow = true;
    [tableViewMap reloadData];
  }
  
}





-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
  
  [self excludeFolder];
  if (tableView.tag==0)
  {
    mapList=@"";
      [clearBtn setEnabled:TRUE];
      [updateBtn setEnabled:TRUE];
      if ([[prefs objectForKey:@"selectedMapList"] count] ==0)
      {
          [clearBtn setEnabled:FALSE];
          [updateBtn setEnabled:FALSE];
      }
    /* [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:NO LeftTitle:@""
     ShowRight:NO RightTitle:@""];*/
      NSLog(@"Count: %d",[[prefs objectForKey:@"selectedMapList"] count]);
    return [[prefs objectForKey:@"selectedMapList"] count];
  }
  else
  {
    if (tableView.tag == 1)
    {
      /*[MainNavigationController
       InitNavigationWithController:self
       ShowLeft:YES LeftTitle:@"返回"
       ShowRight:NO RightTitle:@""];*/
              NSLog(@"Count: %d",[[IndoorDB getAllCategories] count]);
      return [[IndoorDB getAllCategories] count];
    }
    else
    {
      /*[MainNavigationController
       InitNavigationWithController:self
       ShowLeft:YES LeftTitle:@"返回"
       ShowRight:NO RightTitle:@""];*/
        NSLog(@"Count: %d",[[IndoorDB getAllIndoorMapsWithCatID:[prefs integerForKey:@"selectedCategoryID"]:[prefs objectForKey:@"mapList"]]count]);
      return [[IndoorDB getAllIndoorMapsWithCatID:[prefs integerForKey:@"selectedCategoryID"]:[prefs objectForKey:@"mapList"]]count];
    }
  }
	return 0;
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  
	
	
	
	NSLog(@"%d index:%d",tableView.tag,indexPath.row);
	static NSString *CellIdentifier = @"MenuCustomCell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil){
		//cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    //	cell.textLabel.text = [langMenu objectAtIndex:indexPath.row];
	}
  cell.accessoryType = UITableViewCellAccessoryNone;
  if (tableView.tag==0)
  {
      if ([[prefs objectForKey:@"selectedMapList"] count] < indexPath.row)
      {
          return cell	;
      }
    NSDictionary *temp = [[prefs objectForKey:@"selectedMapList"]objectAtIndex:indexPath.row];
    cell.textLabel.text = [temp objectForKey:@"display"];
   /* if (![mapList isEqualToString:@""])
    {
      mapList = [NSString stringWithFormat:@"%@,",mapList];
    }
    
    mapList = [NSString stringWithFormat:@"%@%@",mapList,[temp objectForKey:@"mapid"]];
    [prefs setObject:mapList forKey:@"mapList"];*/
    
    
    if (firstShow)
    {
      [prefs setBool:false forKey:[NSString stringWithFormat:@"map_%d",indexPath.row]];
    }
    
    if ([prefs boolForKey:[NSString stringWithFormat:@"map_%d",indexPath.row]])
    {
      cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
  }
  else
  {
    if (tableView.tag==1)
    {
        if ([[IndoorDB getAllCategories] count] < indexPath.row)
        {
            return cell;
        }
        OEMMap *temp =[[IndoorDB getAllCategories] objectAtIndex:indexPath.row];
        cell.textLabel.text = [temp categoryName];
      
    }
    else
    {
        
      OEMMap *temp  = [[IndoorDB getAllIndoorMapsWithCatID:[prefs integerForKey:@"selectedCategoryID"]:[prefs objectForKey:@"mapList"]]objectAtIndex:indexPath.row];
      cell.textLabel.text = [temp displayName];
    }
  }
  
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
  
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	if (tableView.tag==0)
  {
    firstShow = false;
    
    [prefs setBool:![prefs boolForKey:[NSString stringWithFormat:@"map_%d",indexPath.row]] forKey:[NSString stringWithFormat:@"map_%d",indexPath.row]];
    NSLog(@"%@ %d",[NSString stringWithFormat:@"map_%d",indexPath.row],[prefs boolForKey:[NSString stringWithFormat:@"map_%d",indexPath.row]] );
    [tableView reloadData];
    
  }
  else
  {
    if (tableView.tag==1)
    {
      OEMMap *temp =[[IndoorDB getAllCategories] objectAtIndex:indexPath.row];
      int catID = [temp categoryID];
      [prefs setInteger:catID forKey:@"selectedCategoryID"];
      [prefs setObject:[temp categoryName] forKey:@"selectedCategoryName"];
      tableView.tag=2;
      [prefs setInteger:3 forKey:@"mapManagementTab"];
      //[tableView reloadData];
      MapManagment* mapManagementViewController = [[MapManagment alloc]initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
      //}
      [self.myNavigationController pushViewController:mapManagementViewController animated:YES];
      
    }
    else
    {
      if (tableView.tag == 2)
      {
        OEMMap *temp  = [[IndoorDB getAllIndoorMapsWithCatID:[prefs integerForKey:@"selectedCategoryID"]:[prefs objectForKey:@"mapList"]]objectAtIndex:indexPath.row];
        [prefs setObject:[temp displayName] forKey:@"selectedMapName"];
        [prefs setInteger:[temp mapID] forKey:@"selectedMapID"];
        [self downloadMap:[temp mapID]];
      }
    }
  }
	
}

- (IBAction)clearMapBtnHandler:(id)sender
{
  NSString *mapIDs = @"";
  // NSLog(@"%d",[[prefs objectForKey:@"selectedMapList"] count]);
  NSMutableArray *tempArray = [[prefs objectForKey:@"selectedMapList"] mutableCopy];
  NSMutableArray *discardedItems = [NSMutableArray array];
  
  
  for (int i=0; i < [[prefs objectForKey:@"selectedMapList"] count]; i++)
  {
    //NSLog(@"%d",[prefs boolForKey:[NSString stringWithFormat:@"map_%d",i]]);
    if ([prefs boolForKey:[NSString stringWithFormat:@"map_%d",i]])
    {
      NSDictionary *temp = [[prefs objectForKey:@"selectedMapList"]objectAtIndex:i];
      if (![mapIDs isEqualToString:@""])
      {
        mapIDs = [NSString stringWithFormat:@"%@,",mapIDs];
      }
      mapIDs = [NSString stringWithFormat:@"%@%@",mapIDs,[temp objectForKey:@"mapid"] ];
      [discardedItems addObject:[tempArray objectAtIndex:i]];
      
    }
  }
  [tempArray removeObjectsInArray:discardedItems];
  [prefs setObject:tempArray forKey:@"selectedMapList"];
  
    NSString *mapList1 =@"";
    for (int i=0; i < [[prefs objectForKey:@"selectedMapList"]count]; i++)
    {
        NSDictionary *temp = [[prefs objectForKey:@"selectedMapList"]objectAtIndex:i];
        
        if (![mapList1 isEqualToString:@""])
        {
            mapList1 = [NSString stringWithFormat:@"%@,",mapList1];
        }
        
        mapList1 = [NSString stringWithFormat:@"%@%@",mapList1,[temp objectForKey:@"mapid"]];
        
    }
    [prefs setObject:mapList1 forKey:@"mapList"];
    NSLog(@"MapList : %@",mapList1);

  
  if (![mapIDs isEqualToString:@""])
  {
    [self deleteMaps:mapIDs];
    firstShow = true;
    [tableViewMap reloadData];
  }
}

- (IBAction)selectMapBtnHandler:(id)sender
{
  
  tableViewMap.tag=1;
  [prefs setInteger:2 forKey:@"mapManagementTab"];
  //[tableViewMap reloadData];
  MapManagment* mapManagementViewController = [[MapManagment alloc]initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
  //}
  [self.myNavigationController pushViewController:mapManagementViewController animated:YES];
  
}

- (IBAction)updateMapBtnHandler:(id)sender
{
  NSString *mapIDs = @"";
  for (int i=0; i < [[prefs objectForKey:@"selectedMapList"] count]; i++)
  {
    if ([prefs boolForKey:[NSString stringWithFormat:@"map_%d",i]])
    {
      NSDictionary *temp = [[prefs objectForKey:@"selectedMapList"]objectAtIndex:i];
      if (![mapIDs isEqualToString:@""])
      {
        mapIDs = [NSString stringWithFormat:@"%@,",mapIDs];
      }
      mapIDs = [NSString stringWithFormat:@"%@%@",mapIDs,[temp objectForKey:@"mapid"] ];
    }
  }
  if (![mapIDs isEqualToString:@""])
  {
    firstShow = true;
    [self downloadMaps:mapIDs];
  }
}

- (void) excludeFolder
{
  
  NSString *docsDir = [NSHomeDirectory() stringByAppendingPathComponent:  @"Documents"];
  NSFileManager *localFileManager=[[NSFileManager alloc] init];
  NSDirectoryEnumerator *dirEnum =
  [localFileManager enumeratorAtPath:docsDir];
  
  NSString *file;
  while (file = [dirEnum nextObject]) {
    NSURL *tempUrl =  [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@",docsDir,file]];
    [self addSkipBackupAttributeToItemAtURL:tempUrl];
  }
  
  
}

- (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.1) {
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    NSError *error = nil;
    BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                                  forKey: NSURLIsExcludedFromBackupKey error: &error];
    
    if(!success){
      NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
    }
    
    return success;
  }
  else {
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    const char* filePath = [[URL path] fileSystemRepresentation];
    const char* attrName = "com.apple.MobileBackup";
    u_int8_t attrValue = 1;
    int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
    return result == 0;
  }
  
}

@end
