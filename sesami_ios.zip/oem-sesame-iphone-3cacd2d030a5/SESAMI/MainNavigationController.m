//
//  MainNavigationController.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MainNavigationController.h"

@implementation MainNavigationController

@synthesize myNavigationController;
@synthesize btnMainMenu;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view addSubview:myNavigationController.view];
    //[myNavigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"tableHeaderBg-h44.jpg"] forBarMetrics:UIBarMetricsDefault];
    [self.view bringSubviewToFront:btnMainMenu];
  
//  myNavigationController.navigationBar.tintColor = [UIColor blueColor];
}

- (void)viewDidAppear:(BOOL)animated
{    
    //[myNavigationController.navigationBar setFrame:CGRectMake(myNavigationController.navigationBar.frame.origin.x, myNavigationController.navigationBar.frame.origin.y, myNavigationController.navigationBar.frame.size.width, 48)];
}

#pragma mark - MainNavigation

+ (void)InitNavigationWithController:(UIViewController *)controller ShowLeft:(BOOL)showLeft LeftTitle:(NSString *)leftTitle ShowRight:(BOOL)showRight RightTitle:(NSString *)rightTitle
{
    NSMutableDictionary *navButtonFont = [AppConstant getNavigationButtonFont];
    
    if (showLeft && ![leftTitle isEqualToString:@""])
    {
        UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [leftButton setAccessibilityLabel:@""];
        [leftButton setAccessibilityValue:@"返回"];

        [leftButton setTitle:leftTitle forState:UIControlStateNormal];
        [leftButton setTitleColor:[navButtonFont objectForKey:@"color"] forState:UIControlStateNormal];
        [leftButton setBackgroundImage:[UIImage imageNamed:@"btn_on.png"] forState:UIControlStateNormal];
        //[rightButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back_highlighted.png"] forState:UIControlStateHighlighted];
        [leftButton addTarget:controller action:@selector(btnNavLeft_Click:) forControlEvents:UIControlEventTouchUpInside];
        leftButton.frame = CGRectMake(0, 0, 51.0f, 31.0f);
        leftButton.titleLabel.font = [UIFont fontWithName:[navButtonFont objectForKey:@"family"] size:[[navButtonFont objectForKey:@"size"] floatValue]];
        
        UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
        controller.navigationItem.leftBarButtonItem = leftButtonItem;
    }
    else
    {
        controller.navigationItem.leftBarButtonItem = nil;
    }
    
    if (showRight)
    {
        UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [rightButton setTitle:rightTitle forState:UIControlStateNormal];
        [rightButton setTitleColor:[navButtonFont objectForKey:@"color"] forState:UIControlStateNormal];
        [rightButton setBackgroundImage:[UIImage imageNamed:@"btn_on.png"] forState:UIControlStateNormal];
        //[rightButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back_highlighted.png"] forState:UIControlStateHighlighted];
        [rightButton addTarget:controller action:@selector(btnNavRight_Click:) forControlEvents:UIControlEventTouchUpInside];
        rightButton.frame = CGRectMake(0, 0, 51.0f, 31.0f);
        rightButton.titleLabel.font = [UIFont fontWithName:[navButtonFont objectForKey:@"family"] size:[[navButtonFont objectForKey:@"size"] floatValue]];
        
        UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
        controller.navigationItem.rightBarButtonItem = rightButtonItem;
    }
    else
    {
        controller.navigationItem.rightBarButtonItem = nil;
    }
}

+ (void)InitCustomNavigationWithController:(UIViewController *)controller ShowLeft:(BOOL)showLeft LeftTitle:(NSString *)leftTitle ShowRight:(BOOL)showRight RightTitle:(NSString *)rightTitle
{
    NSMutableDictionary *navButtonFont = [AppConstant getNavigationButtonFont];
    
    if (showLeft)
    {
         UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
         
         [leftButton setAccessibilityLabel:@""];
         [leftButton setAccessibilityValue:@"返回上一頁"];
         [leftButton setAccessibilityTraits:UIAccessibilityTraitNone];
         
         [leftButton setTitle:leftTitle forState:UIControlStateNormal];
         [leftButton setTitleColor:[navButtonFont objectForKey:@"color"] forState:UIControlStateNormal];
         [leftButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back.png"] forState:UIControlStateNormal];
         [leftButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back_highlighted.png"] forState:UIControlStateHighlighted];
         [leftButton addTarget:controller action:@selector(btnNavLeft_Click:) forControlEvents:UIControlEventTouchUpInside];
         leftButton.frame = CGRectMake(0, 0, 51.0f, 31.0f);
         leftButton.titleLabel.font = [UIFont fontWithName:[navButtonFont objectForKey:@"family"] size:[[navButtonFont objectForKey:@"size"] floatValue]];
         
         UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
         controller.navigationItem.leftBarButtonItem = leftButtonItem;
        
        /*
         UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:controller action:@selector(btnNavLeft_Click:)];
         
         [leftButtonItem setAccessibilityLabel:@""];
         [leftButtonItem setAccessibilityValue:@"返回上一頁"];
         [leftButtonItem setAccessibilityTraits:UIAccessibilityTraitNone];
         
         //UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(alertMsg)];
         //[tapGestureRecognizer setNumberOfTapsRequired:1];
         //[backButton addGestureRecognizer:tapGestureRecognizer];
         
         //self.navigationController.interactivePopGestureRecognizer.enabled = NO;
         
         controller.navigationItem.leftBarButtonItem = leftButtonItem;
         */
        
    }
    else
    {
        controller.navigationItem.leftBarButtonItem = nil;
    }
    
    if (showRight)
    {
        rightTitle = @"WHAT?";
        
        UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [rightButton setTitle:rightTitle forState:UIControlStateNormal];
        [rightButton setTitleColor:[navButtonFont objectForKey:@"color"] forState:UIControlStateNormal];
        [rightButton setBackgroundImage:[UIImage imageNamed:@"btn_on.png"] forState:UIControlStateNormal];
        //[rightButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back_highlighted.png"] forState:UIControlStateHighlighted];
        [rightButton addTarget:controller action:@selector(btnNavRight_Click:) forControlEvents:UIControlEventTouchUpInside];
        rightButton.frame = CGRectMake(0, 0, 51.0f, 31.0f);
        rightButton.titleLabel.font = [UIFont fontWithName:[navButtonFont objectForKey:@"family"] size:[[navButtonFont objectForKey:@"size"] floatValue]];
        
        UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
        controller.navigationItem.rightBarButtonItem = rightButtonItem;
    }
    else
    {
        controller.navigationItem.rightBarButtonItem = nil;
    }
}

+ (void)InitInformationNavigationWithController:(UIViewController *)controller ShowLeft:(BOOL)showLeft LeftTitle:(NSString *)leftTitle ShowRight:(BOOL)showRight RightTitle:(NSString *)rightTitle
{
    NSMutableDictionary *navButtonFont = [AppConstant getNavigationButtonFont];
    
    if (showLeft)
    {
        UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [leftButton setAccessibilityLabel:@""];
        [leftButton setAccessibilityValue:@"返回上一頁"];
        [leftButton setAccessibilityTraits:UIAccessibilityTraitNone];
        
        [leftButton setTitle:leftTitle forState:UIControlStateNormal];
        [leftButton setTitleColor:[navButtonFont objectForKey:@"color"] forState:UIControlStateNormal];
        [leftButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back.png"] forState:UIControlStateNormal];
        [leftButton setBackgroundImage:[UIImage imageNamed:@"btn_table_back_highlighted.png"] forState:UIControlStateHighlighted];
        [leftButton addTarget:controller action:@selector(btnNavLeft_Click:) forControlEvents:UIControlEventTouchUpInside];
        leftButton.frame = CGRectMake(0, 0, 51.0f, 31.0f);
        leftButton.titleLabel.font = [UIFont fontWithName:[navButtonFont objectForKey:@"family"] size:[[navButtonFont objectForKey:@"size"] floatValue]];
        
        UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
        controller.navigationItem.leftBarButtonItem = leftButtonItem;
        
    }
    else
    {
        controller.navigationItem.leftBarButtonItem = nil;
    }
    
    if (showRight)
    {
        UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
        [rightButton setTitle:rightTitle forState:UIControlStateNormal];        [rightButton addTarget:controller action:@selector(btnNavRight_Click:) forControlEvents:UIControlEventTouchUpInside];
        
        UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
        controller.navigationItem.rightBarButtonItem = rightButtonItem;
    }
    else
    {
        controller.navigationItem.rightBarButtonItem = nil;
    }
}

@end
