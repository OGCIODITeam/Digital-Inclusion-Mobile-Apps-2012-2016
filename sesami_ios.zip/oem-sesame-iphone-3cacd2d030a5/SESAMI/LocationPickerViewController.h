//
//  LocationPickerViewController.h
//  semami
//
//  Created by Daniel Lee on 26/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTRLinesTableViewController.h"
@class LocationResultTableViewController;
@class ExternalDataLoader;
@class LocationDetailViewController;

@interface LocationPickerViewController : UIViewController{
    NSMutableArray *arrayTableTitleStack;
    NSMutableDictionary *dictContentStack;
    BOOL isViewTransiting;
    
    __weak IBOutlet UIButton *btnSelectorCurrentLocation;
    __weak IBOutlet UIButton *btnSelectorFavorite;
    __weak IBOutlet UIButton *btnSelectorMTR;
    __weak IBOutlet UIButton *btnSelectorSearch;
    
    __weak IBOutlet UILabel *lblTableTitle;
    
    MTRLinesTableViewController *tvcMTRLines;
    __weak IBOutlet UIView *viewContentContainer;
    IBOutlet UIView *viewSelector;
    
    //MTR
    IBOutlet UIView *viewMTRLines;
    __weak IBOutlet UITableView *tableViewMTRLines;
    
    //custom search
    IBOutlet UIView *viewSearchInput;
    __weak IBOutlet UITextField *txtSearchText;
    __weak IBOutlet UIButton *btnSearch;
    IBOutlet UIView *viewSearchResult;
    __weak IBOutlet UITableView *tableViewSearchResult;
    ExternalDataLoader *externalDataLoader;
    __weak IBOutlet UILabel *lblTableViewMessage;
    LocationDetailViewController *locationDetailViewController;    
    BOOL isShowLocationDetail;
    
    IBOutlet UIView *viewFavorite;
    __weak IBOutlet UITableView *tableViewFavorite;
    NSArray *arrayFavorite;    
    LocationResultTableViewController *tvcLocationResult;
    
    BOOL isShowingFavorite;
    //int displayedViewID;
}

@end
