//
//  FavoriteViewIndex.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationMenu.h"

@interface FavoriteViewIndex : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
    
    LocationMenu *locationMenu;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewFavorite;

-(void)setData:(NSArray *)data;
-(void)disableDisclosureButton:(BOOL)isDisable;

@end
