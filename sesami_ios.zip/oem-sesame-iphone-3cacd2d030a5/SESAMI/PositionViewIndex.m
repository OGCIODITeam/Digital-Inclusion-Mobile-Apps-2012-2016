//
//  PositionViewIndex.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "PositionViewIndex.h"

@implementation PositionViewIndex

- (void)viewDidLoad
{
  [super viewDidLoad];    
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = @"位置選單";
}

- (IBAction)onClickWhereAmI:(id)sender
{
  [GlobalVar setCurrentFunction:@"whereami"];
  
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  OEMLocation *currentLocation = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:@"Tab1_WhereAmI" forKey:@"mySection"];
  [extraData setValue:currentLocation forKey:@"locationStart"];
  [extraData setValue:nil forKey:@"locationEnd"];
  
  nearByMeTypePicker = [[NearByMeTypePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:nearByMeTypePicker animated:YES];
}

- (IBAction)onClickHowFar:(id)sender
{
  [GlobalVar setCurrentFunction:@"howfar"];

  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:@"Tab1_HowFar" forKey:@"mySection"];
  
  howFarCalculator = [[HowFarCalculator alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:howFarCalculator animated:YES];
}

- (IBAction)onClickNearBy:(id)sender
{
  [GlobalVar setCurrentFunction:@"nearby"];

  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationNearBy:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:@"Tab1_NearBy" forKey:@"mySection"];
  
  locationTypePicker = [[LocationTypePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:locationTypePicker animated:YES];
}

- (void)onSelectedLocationNearBy:(NSNotification *)notification
{
  if (notification.object != nil)
  {
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:@"Tab1_NearBy" forKey:@"mySection"];
    [extraData setValue:((OEMLocation *)notification.object) forKey:@"locationStart"];
    [extraData setValue:nil forKey:@"locationEnd"];
    
    nearByMeTypePicker = [[NearByMeTypePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    [self.myNavigationController pushViewController:nearByMeTypePicker animated:YES];
  }
}

@end
