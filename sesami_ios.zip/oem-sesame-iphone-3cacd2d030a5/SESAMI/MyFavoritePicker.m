//
//  MyFavoritePicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MyFavoritePicker.h"

@implementation MyFavoritePicker

@synthesize tableViewFavorite;

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"從我的最愛選擇";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

-(void)setData:(NSArray *)data
{
    arrayData = data;
}

-(void)disableDisclosureButton:(BOOL)isDisable
{
    isDisableDisclosureButton = isDisable;
}

- (void)onClickResult:(NSNotification *)notification
{
    if(notification.object!=nil){
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:notification.object];
    }
}

#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    if(!isDisableDisclosureButton){
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    }
    // Configure the cell...
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 60;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.text = [(OEMLocation *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
    cell.textLabel.backgroundColor = [UIColor clearColor];
    
    cell.accessibilityValue = [AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]];
    
    NSLog(@"YO3: %@",[AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]]);
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

@end
