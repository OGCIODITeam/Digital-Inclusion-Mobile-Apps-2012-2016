//
//  MTRLinesTableViewController.m
//  semami
//
//  Created by Daniel Lee on 27/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MTRLinesTableViewController.h"
#import "AppConstant.h"
#import "OEMLocation.h"

@interface MTRLinesTableViewController ()

@end

@implementation MTRLinesTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    //NSLog(@"ok?");
}

-(void)initData{
    arrayLines = [NSArray arrayWithObjects:@"觀塘綫",@"荃灣綫",@"港島綫",@"東涌綫",@"東鐵綫",@"將軍澳綫",@"西鐵綫",@"馬鞍山綫",@"機場快綫",@"迪士尼綫", nil];
    arrayStationSet0 = [NSArray arrayWithObjects:@"調景嶺",@"油塘",@"藍田",@"觀塘",@"牛頭角",@"九龍灣",@"彩虹",@"鑽石山",@"黃大仙",@"樂富",@"九龍塘",@"石硤尾",@"太子",@"旺角",@"油麻地", nil];
    arrayStationSet1 = [NSArray arrayWithObjects:@"荃灣",@"大窩口",@"葵興",@"葵芳",@"荔景",@"美孚",@"荔枝角",@"長沙灣",@"深水埗",@"太子",@"旺角",@"油麻地",@"佐敦",@"尖沙咀",@"金鐘",@"中環", nil];
    arrayStationSet2 = [NSArray arrayWithObjects:@"上環",@"中環",@"金鐘",@"灣仔",@"銅鑼灣",@"天后",@"炮台山",@"北角",@"鰂魚涌",@"太古",@"西灣河",@"筲箕灣",@"杏花邨",@"柴灣", nil];
    arrayStationSet3 = [NSArray arrayWithObjects:@"東涌",@"欣澳",@"青衣",@"荔景",@"南昌",@"奧運",@"九龍",@"香港", nil];
    arrayStationSet4 = [NSArray arrayWithObjects:@"落馬洲",@"羅湖",@"上水",@"粉嶺",@"太和",@"大埔墟",@"大學",@"馬場",@"火炭",@"沙田",@"大圍",@"九龍塘",@"旺角東",@"紅磡", nil];
    arrayStationSet5 = [NSArray arrayWithObjects:@"康城",@"寶琳",@"坑口",@"將軍澳",@"調景嶺",@"油塘",@"鰂魚涌",@"北角",nil];
    arrayStationSet6 = [NSArray arrayWithObjects:@"屯門",@"兆康",@"天水圍",@"朗屏",@"元朗",@"錦上路",@"荃灣西",@"美孚",@"南昌",@"柯士甸",@"尖東",@"紅磡",nil];
    arrayStationSet7 = [NSArray arrayWithObjects:@"烏溪沙",@"馬鞍山",@"恆安",@"大水坑",@"石門",@"第一城",@"沙田圍",@"車公廟",@"大圍", nil];
    arrayStationSet8 = [NSArray arrayWithObjects:@"博覽館",@"機場",@"青衣",@"九龍",@"香港",nil];
    arrayStationSet9 = [NSArray arrayWithObjects:@"欣澳",@"迪士尼",nil];
    arrayStationSets = [NSArray arrayWithObjects:arrayStationSet0,arrayStationSet1,arrayStationSet2,arrayStationSet3,arrayStationSet4,arrayStationSet5,arrayStationSet6,arrayStationSet7,arrayStationSet8,arrayStationSet9, nil];
    currentListLevel = 0;
    
    arrayCurrentList = arrayLines;
    
    //location1 = [[OEMLocation alloc] initWithName:@"油麻地" latitude:22.313841 longitude:114.170297 address:@"ABC"];
    //location2 = [[OEMLocation alloc] initWithName:@"彩虹" latitude:22.334977 longitude:114.209022 address:@"DEF"];
}



///////////////////////////////////////////////////////////////////////////
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [arrayCurrentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 50;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    if(currentListLevel<2)
        cell.textLabel.text = [NSString stringWithFormat:@"%@",[arrayCurrentList objectAtIndex:[indexPath row]]];
    else{
        //i.e. showing exits now
        cell.textLabel.text = [NSString stringWithFormat:@"%@",[(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getDisplayName]];
    }
    
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //currentListLevel++;
    if(currentListLevel==0){
        currentListLevel++;
        arrayCurrentList = (NSArray *)[arrayStationSets objectAtIndex:[indexPath row]];
        currentStationIndex = [indexPath row];
        [self.tableView reloadData];
        [self.tableView setContentOffset:CGPointZero];
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
    }else if(currentListLevel==1){
        NSArray *arrayExits = [OEMDB getMTRExitWithStationName:[arrayCurrentList objectAtIndex:indexPath.row]];
        currentListLevel++;
        arrayCurrentList = arrayExits;
        [self.tableView reloadData];
        [self.tableView setContentOffset:CGPointZero];
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
    }else {
       // NSLog(@"exit : %@ (%f, %f)",[(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getDisplayName], [(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getLatitude], [(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getLongitude]);
        [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:[arrayCurrentList objectAtIndex:[indexPath row]]];
    }
}
//////////////////////////////////////////////////////////////////////////////
-(Boolean)previousList{
    if(currentListLevel>0){
        if(currentListLevel==2)
            arrayCurrentList = (NSArray *)[arrayStationSets objectAtIndex:currentStationIndex];
        else
            arrayCurrentList = arrayLines;
        
        [self.tableView reloadData];
        [self.tableView setContentOffset:CGPointZero];
        currentListLevel--;
        return YES;
    }else{
        return NO;
    }
}
@end
