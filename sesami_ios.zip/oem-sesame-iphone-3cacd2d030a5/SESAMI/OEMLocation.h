//
//  OEMLocation.h
//  semami
//
//  Created by Daniel Lee on 5/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
@interface OEMLocation : NSObject

@property (assign) int locationID;
@property (strong) NSString *displayName;
@property (strong) NSString *foreignID;
@property (strong) NSString *source;
@property (strong) NSString *address;
@property (assign) double longitude;
@property (assign) double latitude;

- (id)initWithName:(NSString *)name clocation:(CLLocation *)clocation address:(NSString *)address;
- (id)initWithName:(NSString *)name latitude:(double)latitude longitude:(double)longitude address:(NSString *)address;
- (id)initWithID:(int)locationID name:(NSString *)name foreignID:(NSString *)foreignID source:(NSString *)source latitude:(double)latitude longitude:(double)longitude address:(NSString *)address;
- (id)initWithName:(NSString *)name foreignID:(NSString *)foreignID source:(NSString *)source latitude:(double)latitude longitude:(double)longitude address:(NSString *)address;

- (void)setLocationIDWithInt:(int)newID;
- (int) getLocationID;
- (NSString *)getDisplayName;
- (NSString *)getForeignID;
- (NSString *)getSource;
- (double) getLongitude;
- (double) getLatitude;
- (NSString *)getAddress;
- (CLLocation *)getLocationInCCLocation;
@end
