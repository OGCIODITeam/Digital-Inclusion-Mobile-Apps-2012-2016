//
//  PositionViewIndex.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NearByMeTypePicker.h"
#import "HowFarCalculator.h"
#import "LocationTypePicker.h"
#import "NearByMeResult.h"

@interface PositionViewIndex : BaseViewController
{
    __weak IBOutlet UIButton *btnWhereAmI;
    NearByMeTypePicker *nearByMeTypePicker;
    
    __weak IBOutlet UIButton *btnHowFar;
    HowFarCalculator *howFarCalculator;
    
    __weak IBOutlet UIButton *btnNearby;
    LocationTypePicker *locationTypePicker;
}

- (IBAction)onClickWhereAmI:(id)sender;
- (IBAction)onClickHowFar:(id)sender;
- (IBAction)onClickNearBy:(id)sender;

- (void)onSelectedLocationNearBy:(NSNotification *)notification;

@end
