//
//  AppFunction.h
//  SESAMI
//
//  Created by Daniel Lee on 18/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@class OEMLocation;
@interface AppFunction : NSObject


+(NSString *)convertNumberToChineseSentance:(int)number;
+(NSString *)convertNumberToChineseSentance4Digi:(int)number;
+(NSString *)getChineseCharFromInt:(int)number;
+(NSString *)getResultAccessibilityValueForLocation:(OEMLocation *)location;
+(NSString *)getResultAccessibilityValueFromLocation:(OEMLocation *)locationStart ToLocation:(OEMLocation *)locationEnd;

+(NSString *)getCompassDirectionFromLocation:(CLLocation *)fromLocation ToLocation:(CLLocation *)toLocation;
+(double)getCompassHeadingFromLocation:(CLLocation *)fromLocation ToLocation:(CLLocation *)toLocation;
+(NSString *)getChineseDirectionFromHeadingValue:(double)h;
+(void)quickAlertWithMessage:(NSString *)message title:(NSString *)title;

+(void)listDirectory:(NSString *)sPath;

+(NSArray *)getObjectWithFloorPlanDataString:(NSString *)str;

@end
