//
//  SearchingResult.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "SearchingResult.h"

@implementation SearchingResult

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
    self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
    if (self)
    {
        mySearchText = [self.myExtraData objectForKey:@"searchText"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadResult];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"搜尋結果";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

- (void)onClickResult:(NSNotification *)notification
{
    if(notification.object!=nil){
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:notification.object];
    }
}

-(void)setData:(NSArray *)data
{
    arrayData = data;
}

-(void)disableDisclosureButton:(BOOL)isDisable
{
    isDisableDisclosureButton = isDisable;
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    if(!isDisableDisclosureButton){
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    }
    // Configure the cell...
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 60;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.text = [(OEMLocation *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
    cell.textLabel.backgroundColor = [UIColor clearColor];
    
    cell.accessibilityValue = [AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]];
    
    NSLog(@"YO5: %@",[AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]]);
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)loadResult
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    if(externalDataLoader == nil)
    {
        externalDataLoader = [[ExternalDataLoader alloc] init];
    }
    [externalDataLoader centaMapSearchBuildingWithKeyword:mySearchText];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
    
    //viewSelector.accessibilityElementsHidden = YES;
}

- (void)onExternalDataReturn:(NSNotification *)notification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    
    if([notification.object isKindOfClass:[NSError class]])
    {
        [self.tableViewSearchResult setHidden:YES];
        [self.lblTableViewMessage setText:[AppMessage getServerDownMSG]];
      [self.lblTableViewMessage setHidden:NO];

    }
    else
    {
        NSDictionary *json = (NSDictionary *)notification.object;
        if ([json count]==0)
        {
            [self.tableViewSearchResult setHidden:YES];
            [self.lblTableViewMessage setText:[AppMessage getNoResultMSG]];
          [self.lblTableViewMessage setHidden:NO];

        }
        else
        {
            CLLocation *cLocation = [GlobalVar getCurrentLocation];
            [self.tableViewSearchResult setHidden:NO];
          [self.lblTableViewMessage setHidden:YES];

            //notification.object saved the array of researched location
            //put create OEMLocation for all locations and push into arrayLocation
            NSMutableArray *arrayLocationForSort = [[NSMutableArray alloc] init];
            NSMutableArray *arrayLocation = [[NSMutableArray alloc] init];
            
            for(NSDictionary *node in (NSArray *)[json objectForKey:@"Table"])
            {
                CLLocation *nLocation = [[CLLocation alloc] initWithLatitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"]doubleValue]];
                
                OEMLocation *location = [[OEMLocation alloc] initWithName:[node objectForKey:@"displayname"] latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:[node objectForKey:@"displayaddr"]];
                
                NSArray *arrNode = [[NSArray alloc] initWithObjects:[NSNumber numberWithDouble:[nLocation distanceFromLocation:cLocation]], location, nil];
                [arrayLocationForSort addObject:arrNode];
            }
            
            NSArray *arrayLocationSorted = [arrayLocationForSort sortedArrayUsingComparator:^(id a, id b){
                return [[a objectAtIndex:0] compare:[b objectAtIndex:0]];
            }];
            
            for(NSArray *node in arrayLocationSorted){
                [arrayLocation addObject:[node objectAtIndex:1]];
            }
            
            [self setData:arrayLocation];
            [self disableDisclosureButton:YES];
            [self.tableViewSearchResult reloadData];
        }
    }
}

- (void)refreshAction
{
    [self loadResult];
}

@end
