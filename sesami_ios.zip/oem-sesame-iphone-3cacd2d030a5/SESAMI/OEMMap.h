//
//  OEMLocation.h
//  semami
//
//  Created by Daniel Lee on 5/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
@interface OEMMap : NSObject

@property (assign) int mapID;
@property (strong) NSString *displayName;
@property (strong) NSString *address;
@property (strong) NSString *description;
@property (assign) int categoryID;
@property (strong) NSString *categoryName;
@property (assign) int districtID;

- (id)initWithMapID:(int)mapID Name:(NSString *)mapName Address:(NSString *)address Description:(NSString *)description CatID:(int)catID DisID:(int)disID;
- (id)initWithCatID:(int)catID Name:(NSString *)catName;

- (void)setMapIDWithInt:(int)newID;
- (int)getMapID;
- (NSString *)getDisplayName;
- (NSString *)getAddress;
- (NSString *)getDescription;
- (int)getCategoryID;
- (NSString *)getCategoryName;
- (int)getDistrictID;

@end
