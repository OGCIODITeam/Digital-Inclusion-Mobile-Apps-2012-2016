//
//  ViewController.m
//  SESAMI
//
//  Created by Daniel Lee on 8/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "ViewController.h"
#import "PositionViewController.h"
#import "InDoorMapViewController.h"
#import "FavoriteViewController.h"
#import "VirtualWalkViewController.h"
#import "SettingViewController.h"
#import "OEMDB.h"
#import "OEMLocation.h"
#import <CoreLocation/CoreLocation.h>
@interface ViewController ()

@end

@implementation ViewController
@synthesize pv,idmv,fv,sv,vwv;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onShowLoading:) name:[AppConstant getShowLoadingEventName] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onHideLoading:) name:[AppConstant getHideLoadingEventName] object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(directShowViewHowFar:) name:[AppConstant getDirectShowViewHowFarCallBackName] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(directShowViewNearby:) name:[AppConstant getDirectShowViewNearbyCallBackName] object:nil];
    
    [self getLocation];
    [self switchTab:0];
    
//    [AppFunction listDirectory:@"/var/mobile/Applications/A0A40C8B-D136-4934-BCFF-DD16132E3C61/SESAMI.app/"];
    
    //UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"Welcome");
    //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
    
    /*
    CLLocation *locCenter = [[CLLocation alloc] initWithLatitude:22.303172 longitude:114.1277];
    CLLocation *locA = [[CLLocation alloc] initWithLatitude:22.352734 longitude:114.170651];
    CLLocation *locB = [[CLLocation alloc] initWithLatitude:22.280321 longitude:114.22509];
    CLLocation *locC = [[CLLocation alloc] initWithLatitude:22.250067 longitude:114.169396];
    CLLocation *locD = [[CLLocation alloc] initWithLatitude:22.282713 longitude:114.126803];
    
    [AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locA];
    [AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locB];
    [AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locC];
    [AppFunction getCompassDirectionFromLocation:locCenter ToLocation:locD];
    */
    
}

- (void)initView{
    [self switchTab:4];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)switchTab:(int)tabIndex{

    [btnMenuPosition setSelected:NO];
    [btnMenuIndoorMap setSelected:NO];
    [btnMenuFavor setSelected:NO];
    [btnMenuWalk setSelected:NO];
    [btnMenuSetting setSelected:NO];    
    
    [pv.view removeFromSuperview];
    [idmv.view removeFromSuperview];
    [fv.view removeFromSuperview];
    [vwv.view removeFromSuperview];
    [sv.view removeFromSuperview];
    
    pv = nil;
    idmv = nil;
    fv = nil;
    vwv = nil;
    sv = nil;
    
    if(tabIndex==0){
        [btnMenuPosition setSelected:YES];
        
        if(pv == nil)
            pv = [[PositionViewController alloc] init];
        [viewRootContainer addSubview:pv.view];
    }
    if(tabIndex==1){
        [btnMenuIndoorMap setSelected:YES];
        
        if(idmv == nil)
            idmv = [[InDoorMapViewController alloc] init];
        [viewRootContainer addSubview:idmv.view];
    }
    if(tabIndex==2){
        [btnMenuFavor setSelected:YES];
        
        if(fv == nil)
            fv = [[FavoriteViewController alloc] init];
        [viewRootContainer addSubview:fv.view];
    }
    if(tabIndex==3){
        [btnMenuWalk setSelected:YES];
        
        if(vwv == nil)
            vwv = [[VirtualWalkViewController alloc] init];
        [viewRootContainer addSubview:vwv.view];
    }
    if(tabIndex==4){
        [btnMenuSetting setSelected:YES];
        
        if(sv == nil)
            sv = [[SettingViewController alloc] init];
        [viewRootContainer addSubview:sv.view];
    }

}
- (IBAction)onClickPosition:(id)sender {
    [self switchTab:0];
}

- (IBAction)onClickInDoorMap:(id)sender {
    [self switchTab:1];
}

- (IBAction)onClickFavorite:(id)sender {
    [self switchTab:2];
}
- (IBAction)onClickVirtualWalk:(id)sender{
    [self switchTab:3];
}
- (IBAction)onClickSetting:(id)sender{
    [self switchTab:4];
}

- (void)onShowLoading:(NSNotification *)notification{
    [self.view addSubview:viewLoading];
}
- (void)onHideLoading:(NSNotification *)notification{
    [viewLoading removeFromSuperview];
}
- (void)directShowViewHowFar:(NSNotification *)notification{
    [self switchTab:0];
    [pv showHowFarViewWithLocationEnd:(OEMLocation *)notification.object];
}
- (void)directShowViewNearby:(NSNotification *)notification{
    [self switchTab:0];
    [pv showNearbyViewWithLocation:(OEMLocation *)notification.object];
}
-(void) getLocation{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
    
    locationManager.headingFilter = 1;
    [locationManager startUpdatingHeading];
}
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    [GlobalVar setCurrentLocation:newLocation];
}
- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading{

	//float oldRad =  -manager.heading.trueHeading * M_PI / 180.0f;
	//float newRad =  -newHeading.trueHeading * M_PI / 180.0f;

	//NSLog(@"%f (%f) => %f (%f)", manager.heading.trueHeading, oldRad, newHeading.trueHeading, newRad);
    [GlobalVar setCurrentCompassHeading:newHeading.trueHeading];
}
@end
