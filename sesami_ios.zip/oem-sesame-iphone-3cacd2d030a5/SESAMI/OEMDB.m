//
//  OEMDB.m
//  SESAMI
//
//  Created by Daniel Lee on 9/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "OEMDB.h"
#import "OEMLocation.h"
#import "OEMMap.h"
#import "OEMFloorPlan.h"

@implementation OEMDB

const char *dbpath;
sqlite3 *hkbuDB;

+ (void)initDB{
  NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *docsDir = [dirPaths objectAtIndex:0];
  
  //NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"hkbu.db"]];
  NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"hkbu.sqlite"]];//local path
  
  NSFileManager *filemgr = [NSFileManager defaultManager];
  
  if ([filemgr fileExistsAtPath: databasePath ] == NO)
  {
    NSLog(@"hkbu.sqlite not exist");
    
    NSString *databasePathInBundle = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"hkbu.sqlite"];
    NSLog(@"inbundle : %@",databasePathInBundle);
    NSLog(@"inlocal  : %@",databasePath);
    
    NSLog(@"moving file from bundle to local");
    [filemgr copyItemAtPath:databasePathInBundle toPath:databasePath error:nil];
    
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
    }else{
      dbpath = [databasePath UTF8String];
      sqlite3_open(dbpath, &hkbuDB);
      NSLog(@"db ready");
    }
    
    /*
     dbpath = [databasePath UTF8String];
     
     if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
     {
     
     char *errMsg;
     const char *sql_stmt = "CREATE TABLE IF NOT EXISTS FAVORITES (ID INTEGER PRIMARY KEY AUTOINCREMENT, FOREIGN_ID TEXT, SOURCE TEXT, NAME TEXT, LATITUDE REAL, LONGITUDE REAL, ADDRESS TEXT)";
     if (sqlite3_exec(hkbuDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
     {
     NSLog(@"failed to create table FAVORITES");
     }
     NSLog(@"success to create table FAVORITES");
     
     } else {
     NSLog(@"failed to open/create database");
     }
     */
  }else{
		dbpath = [databasePath UTF8String];
    sqlite3_open(dbpath, &hkbuDB);
  }
}

+ (void)addSampleData{
  sqlite3_stmt    *statement;
  
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *insertSQL = [NSString stringWithFormat: @"INSERT INTO FAVORITES (ForeignId, Source, Name, Latitude, Longitude, Address) VALUES (\"%@\", \"%@\", \"%@\", \"%f\", \"%f\", \"%@\")", @"c123", @"centamap", @"華興商業中心", 22.313786,114.169064,@""];
  
  const char *insert_stmt = [insertSQL UTF8String];
  
  sqlite3_prepare_v2(hkbuDB, insert_stmt, -1, &statement, NULL);
  if (sqlite3_step(statement) == SQLITE_DONE)
  {
    NSLog(@"added sample data");
  } else {
    NSLog(@"fail to add sample data");
  }
  sqlite3_reset(statement);
  sqlite3_finalize(statement);
  //}
}
//////////////////////////////////////////////////
//favorite
//////////////////////////////////////////////////
+ (NSArray *)getAllFavoriteLocations{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM FAVORITES"];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int locationID = sqlite3_column_int(statement, 0);
      NSString *foreignID = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSString *source = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
      NSString *name = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
      double latitude =sqlite3_column_double(statement, 4);
      double longitude =sqlite3_column_double(statement, 5);
      NSString  *address = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 6)];
      
      OEMLocation *favoriteLocation = [[OEMLocation alloc] initWithID:locationID name:name foreignID:foreignID source:source latitude:latitude longitude:longitude address:address];
      [result addObject:favoriteLocation];
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (int)getIDFromOEMLocation:(OEMLocation *)location{
  int returnID=-1;
  sqlite3_stmt    *statement;
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id FROM FAVORITES where Name=\"%@\" and Latitude=\"%f\" and Longitude=\"%f\"",[location getDisplayName],[location getLatitude],[location getLongitude]];
  const char *query_stmt = [querySQL UTF8String];
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int locationID = sqlite3_column_int(statement, 0);
      returnID = locationID;
    }
    sqlite3_finalize(statement);
  }
  return returnID;
}

+ (BOOL)isFavorited:(OEMLocation *)location{
  sqlite3_stmt    *statement;
  //NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM FAVORITES where name=\"%@\"", [location getDisplayName]];
  NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM FAVORITES where Latitude=\"%f\" and Longitude=\"%f\"", [location getLatitude],[location getLongitude]];
  const char *query_stmt = [querySQL UTF8String];
  int counter = 0;
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      counter+=1;
    }
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
  }
  
  return (counter>0);
}

+ (int)addFavorite:(OEMLocation *)location{
  sqlite3_stmt    *statement;
  
  NSString *insertSQL = [NSString stringWithFormat: @"INSERT INTO FAVORITES (ForeignId, Source, Name, Latitude, Longitude, Address) VALUES (\"%@\", \"%@\", \"%@\", \"%f\", \"%f\", \"%@\")", [location getForeignID], [location getSource], [location getDisplayName], [location getLatitude],[location getLongitude], [location getAddress]];
  
  const char *insert_stmt = [insertSQL UTF8String];
  
  sqlite3_prepare_v2(hkbuDB, insert_stmt, -1, &statement,nil);
  if (sqlite3_step(statement) == SQLITE_DONE)
  {
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    return sqlite3_last_insert_rowid(hkbuDB);
  } else {
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    return -1;
  }
  
  return -1;
}

+ (BOOL)removeFavorite:(int)locationID{
  sqlite3_stmt *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *insertSQL = [NSString stringWithFormat:@"DELETE from FAVORITES where id = %d",locationID];
  const char *insert_stmt = [insertSQL UTF8String];
  
  sqlite3_prepare_v2(hkbuDB, insert_stmt, -1, &statement, NULL);
  if (sqlite3_step(statement) == SQLITE_DONE)
  {
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    return YES;
  } else {
    sqlite3_reset(statement);
    sqlite3_finalize(statement);
    return NO;
  }
  
  //}
  return NO;
}

/////////////////////////////////////////////////
//MTR
/////////////////////////////////////////////////
+ (NSArray *)getMTRExitWithStationName:(NSString *)stationName{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  
  NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM MTRStations WHERE StationName = \"%@\"",stationName];
  
  const char *query_stmt = [querySQL UTF8String];
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int locationID = -1;
      NSString *foreignID = @"";
      NSString *source = @"";
      //NSString *name = [NSString stringWithFormat:@"%@ %@  出口",stationName,[NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)]];
      NSString *name = [NSString stringWithFormat:@"%@  出口",[NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)]];
      double latitude =sqlite3_column_double(statement, 3);
      double longitude =sqlite3_column_double(statement, 4);
      NSString  *address = @"";
      
      OEMLocation *favoriteLocation = [[OEMLocation alloc] initWithID:locationID name:name foreignID:foreignID source:source latitude:latitude longitude:longitude address:address];
      [result addObject:favoriteLocation];
    }
    sqlite3_finalize(statement);
  }
  if([result count]==0)result=nil;
  
  return result;
}

/////////////////////////////////////////////////
//Indoor Map
/////////////////////////////////////////////////
+ (NSArray *)getAllIndoorMaps
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name, address, description, category_id, district_id FROM IndoorMaps"];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int mapID = sqlite3_column_int(statement, 0);
      NSString *mapName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSString *mapAddress = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
      NSString *mapDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
      int catID = sqlite3_column_int(statement, 4);
      int disID = sqlite3_column_int(statement, 5);
      
      OEMMap *map = [[OEMMap alloc] initWithMapID:mapID Name:mapName Address:mapAddress Description:mapDescription CatID:catID DisID:disID];
      [result addObject:map];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (NSArray *)getAllFloorPlanWithMapID:(int)mapID
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, label, description, level, image, data FROM IndoorMapFloorPlans WHERE parent_id = %i", mapID];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int floorPlanID = sqlite3_column_int(statement, 0);
      NSString *floorPlanName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSString *floorDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
      int floorPlanLevel = sqlite3_column_int(statement, 3);
      NSString *floorPlanImage = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
      NSString *floorPlanData = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 5)];
      
      NSArray *floorPlanDataLabel = [OEMDB getAllDataLabelWithFloorPlanID:floorPlanID];
      
      OEMFloorPlan *floorPlan = [[OEMFloorPlan alloc] initWithFloorPlanID:floorPlanID Name:floorPlanName Description:floorDescription Level:floorPlanLevel Image:floorPlanImage Data:floorPlanData DataLabel:floorPlanDataLabel];
      
      [result addObject:floorPlan];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (NSArray *)getAllDataLabelWithFloorPlanID:(int)floorPlanID
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name FROM IndoorMapFloorPlanLabels WHERE parent_id = %i", floorPlanID];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int labelID = sqlite3_column_int(statement, 0);
      NSString *labelName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSMutableDictionary *label = [[NSMutableDictionary alloc] init];
      [label setValue:[NSString stringWithFormat:@"%i",labelID] forKey:@"labelID"];
      [label setValue:labelName forKey:@"labelName"];
      
      [result addObject:label];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  NSLog(@"labels - %i %@", floorPlanID, result);
  return result;
}

+ (NSString *)getTextWithDataLabelID:(int)dataLabelID
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT name FROM IndoorMapFloorPlanLabels WHERE id = %i", dataLabelID];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      NSString *labelName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 0)];
      
      [result addObject:labelName];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return [result objectAtIndex:0];
}

@end
