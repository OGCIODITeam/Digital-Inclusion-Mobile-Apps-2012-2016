//
//  MyFavoritePicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFavoritePicker : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewFavorite;

//- (void)onClickResult:(NSNotification *)notification;
-(void)setData:(NSArray *)data;
-(void)disableDisclosureButton:(BOOL)isDisable;

@end
