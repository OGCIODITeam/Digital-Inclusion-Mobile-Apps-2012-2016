//
//  MTRLinesTableViewController.h
//  semami
//
//  Created by Daniel Lee on 27/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
@class OEMLocation;

@interface MTRLinesTableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate>{
    NSArray *arrayLines;
    NSArray *arrayStationSet0;
    NSArray *arrayStationSet1;
    NSArray *arrayStationSet2;
    NSArray *arrayStationSet3;
    NSArray *arrayStationSet4;
    NSArray *arrayStationSet5;
    NSArray *arrayStationSet6;
    NSArray *arrayStationSet7;
    NSArray *arrayStationSet8;
    NSArray *arrayStationSet9;
    NSArray *arrayStationSets;
    
    int currentListLevel;
    int currentStationIndex;
    NSArray *arrayCurrentList;
    
    OEMLocation *location1;
    OEMLocation *location2;
}

-(void)initData;
-(Boolean)previousList;
@end
