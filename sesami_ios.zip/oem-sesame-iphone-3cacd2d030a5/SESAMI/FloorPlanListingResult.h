//
//  FloorPlainListingResult.h
//  SESAMI
//
//  Created by Ray.Liu on 9/4/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FloorPlanViewController.h"

@interface FloorPlanListingResult : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
    
    FloorPlanViewController *floorPlanViewController;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewIndoor;

-(void)setData:(NSArray *)data;
-(void)disableDisclosureButton:(BOOL)isDisable;

@end
