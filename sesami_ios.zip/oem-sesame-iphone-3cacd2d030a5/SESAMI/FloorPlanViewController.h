//
//  FloorPlanViewController.h
//  SESAMI
//
//  Created by Ray.Liu on 8/20/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <AudioToolbox/AudioToolbox.h>

@class OEMFloorPlan;

@interface FloorPlanViewController : BaseViewController <CLLocationManagerDelegate>
{
  IBOutlet UILabel *voiceLabel;
  __weak IBOutlet UIButton *btnMoveUp;
  __weak IBOutlet UIButton *btnMoveRight;
  __weak IBOutlet UIButton *btnMoveDown;
  __weak IBOutlet UIButton *btnMoveLeft;
  
  OEMFloorPlan *myFloorPlan;
  IBOutlet UIImageView *floorPlanImageView;
  int currentLevel;
  
  NSMutableArray *btnZoomList;
  NSMutableArray *lblDataLabelList;
  
  NSMutableArray *zoomFrameList;
  NSMutableArray *zoomHistory;  // Richard
  
  BOOL allowZoom;
  
  CLLocationManager *locationManager;
  BOOL isNorth;
  
  int imageViewSize;
  NSArray *labelArr;
  NSArray *descArr;
}

@property (nonatomic, retain) CLLocationManager *locationManager;

- (void)genDataLabel;
- (void)btnZoom_Click:(id)sender;
- (void)clearDataLabeAndButton;
- (void)zoomOut;

- (void)enableAllButtonAndLabelAccessibility;
- (void)disableAllButtonAndLabelAccessibility;
- (void)playFloorPlanLevelCompletedHandler;

- (NSString*)findLabels:(int)x1 X2:(int)x2 Y1:(int)y1 Y2:(int)y2;

-(void)handleSwipeGesture:(UISwipeGestureRecognizer *)recognizer;;  // Richard
-(void)setMoveButtons;

- (IBAction)moveUp:(id)sender;
- (IBAction)moveRight:(id)sender;
- (IBAction)moveDown:(id)sender;
- (IBAction)moveLeft:(id)sender;

@end
