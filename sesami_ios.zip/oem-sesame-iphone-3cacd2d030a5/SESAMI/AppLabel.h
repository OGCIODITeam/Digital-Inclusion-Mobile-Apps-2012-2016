//
//  AppLabel.h
//  SESAMI
//
//  Created by Daniel Lee on 2/8/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppLabel : NSObject

+(NSString *)getPositionViewTableTitleInit;
+(NSString *)getLabelWhereAmI;
+(NSString *)getLabelHowFar;
+(NSString *)getLabelWhatsNearby;
+(NSString *)getLocationDetailButtoHowFarVO;
+(NSString *)getLocationDetailButtoNearbyVO;
+(NSString *)getLocationDetailButtonAddFavorVO;
+(NSString *)getLocationDetailButtonRemoveFavorVO;
@end
