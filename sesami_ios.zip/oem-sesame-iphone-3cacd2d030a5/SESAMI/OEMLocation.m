//
//  OEMLocation.m
//  semami
//
//  Created by Daniel Lee on 5/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "OEMLocation.h"

@implementation OEMLocation

@synthesize locationID = _locationID;
@synthesize displayName = _displayName;
@synthesize foreignID = _foreignID;
@synthesize longitude = _longitude;
@synthesize latitude = _latitude;
@synthesize source = _source;
@synthesize address = _address;

- (id)initWithName:(NSString *)name clocation:(CLLocation *)clocation address:(NSString *)address{
    if((self = [super init])){
        self.displayName = name;
        self.longitude = clocation.coordinate.longitude;
        self.latitude = clocation.coordinate.latitude;
        self.address = address;
        self.source = @"";
        self.foreignID = @"";
        self.locationID = -1;
        
    }
    return self;
}
- (id)initWithName:(NSString *)name latitude:(double)latitude longitude:(double)longitude address:(NSString *)address{
    if((self = [super init])){
        self.displayName = name;
        self.longitude = longitude;
        self.latitude = latitude;
        self.address = address;
        self.source = @"";
        self.foreignID = @"";
        self.locationID = -1;

    }
    return self;
}
- (id)initWithID:(int)locationID name:(NSString *)name foreignID:(NSString *)foreignID source:(NSString *)source latitude:(double)latitude longitude:(double)longitude address:(NSString *)address{
    if((self = [super init])){
        self.locationID = locationID;
        self.displayName = name;
        self.foreignID = foreignID;
        self.longitude = longitude;
        self.latitude = latitude;
        self.source = source;
        self.address = address;
    }
    return self;
}
- (id)initWithName:(NSString *)name foreignID:(NSString *)foreignID source:(NSString *)source latitude:(double)latitude longitude:(double)longitude address:(NSString *)address{
    if((self = [super init])){
        self.displayName = name;
        self.foreignID = foreignID;
        self.longitude = longitude;
        self.latitude = latitude;
        self.source = source;
        self.locationID = -1;
        self.address = address;
        self.address = address;        
    }
    return self;
}
- (void)setLocationIDWithInt:(int)newID{
    self.locationID = newID;
}
- (int) getLocationID{
    return self.locationID;
}
- (NSString *)getDisplayName{
    return self.displayName;
}
- (NSString *)getForeignID{
    return self.foreignID;
}
- (NSString *)getSource{
    return self.source;
}
- (double) getLongitude{
    return self.longitude;
}
- (double) getLatitude{
    return self.latitude;
}
- (NSString *)getAddress{
    return self.address;
}
- (CLLocation *)getLocationInCCLocation{
    return [[CLLocation alloc] initWithLatitude:self.latitude longitude:self.longitude];
}
@end
