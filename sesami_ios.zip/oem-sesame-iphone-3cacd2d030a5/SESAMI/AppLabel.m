//
//  AppLabel.m
//  SESAMI
//
//  Created by Daniel Lee on 2/8/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "AppLabel.h"
#define LABEL_WHERE_AM_I @"我在那裡";
#define LABEL_HOW_FAR @"有多遠";
#define LABEL_WHATS_NEARBY @"附近有什麼";
#define LABEL_POSITION_VIEW_TABLE_TITLE_INIT @"位置選單"
#define LOCATION_DETAIL_BUTTON_HOW_FAR_VO @"距離%@有多遠"
#define LOCATION_DETAIL_BUTTON_NEARBY_VO @"%@附近有什麼"
#define LOCATION_DETAIL_BUTTON_ADD_FAVOR_VO @"把%@加入我的最愛"
#define LOCATION_DETAIL_BUTTON_REMOVE_FAVOR_VO @"把%@從我的最愛中的移除"
@implementation AppLabel

+(NSString *)getPositionViewTableTitleInit{
    return LABEL_POSITION_VIEW_TABLE_TITLE_INIT;
}
+(NSString *)getLabelWhereAmI{
    return LABEL_WHERE_AM_I;
}
+(NSString *)getLabelHowFar{
    return LABEL_HOW_FAR;
}
+(NSString *)getLabelWhatsNearby{
    return LABEL_WHATS_NEARBY;
}
+(NSString *)getLocationDetailButtoHowFarVO{
    return LOCATION_DETAIL_BUTTON_HOW_FAR_VO;
}
+(NSString *)getLocationDetailButtoNearbyVO{
    return LOCATION_DETAIL_BUTTON_NEARBY_VO;
}
+(NSString *)getLocationDetailButtonAddFavorVO{
    return LOCATION_DETAIL_BUTTON_ADD_FAVOR_VO;
}
+(NSString *)getLocationDetailButtonRemoveFavorVO{
    return LOCATION_DETAIL_BUTTON_REMOVE_FAVOR_VO;
}
@end
