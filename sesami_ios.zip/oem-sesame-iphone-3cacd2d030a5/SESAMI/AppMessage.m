//
//  AppMessage.m
//  SESAMI
//
//  Created by Daniel Lee on 31/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "AppMessage.h"

#define SERVER_DOWN_MESSAGE @"伺服器沒有反應，請稍後再試";
#define NO_RESULT_MESSSAGE @"沒有搜索結果";
#define TOO_FAR_AWAY @"太遠了";
#define ERROR_SAME_LOCATION @"不能選擇同一個地方";
#define ERROR_MISSING_LOCATION_START @"選擇出發點";
#define ERROR_MISSING_LOCATION_END @"選擇目的地";
#define ERROR_EMPTY_KEYWORD @"關鍵字不能空白";
#define ERROR_EMPTY_STREET_NAME_OR_NUMBER @"請填上街名和街號";
#define ERROR_NEGATIVE_STREET_NUMBER @"街號不能是零或負數";

@implementation AppMessage

+(NSString *)getServerDownMSG{
    return SERVER_DOWN_MESSAGE;
}
+(NSString *)getNoResultMSG{
    return NO_RESULT_MESSSAGE;
}
+(NSString *)getTooFarAwayMSG{
    return TOO_FAR_AWAY;
}
+(NSString *)errorSameLocation{
    return ERROR_SAME_LOCATION;
}
+(NSString *)errorMissingLocationStart{
    return ERROR_MISSING_LOCATION_START;
}
+(NSString *)errorMissingLocationEnd{
    return ERROR_MISSING_LOCATION_END;
}
+(NSString *)errorEmptyKeyword{
    return ERROR_EMPTY_KEYWORD;
}
+(NSString *)errorEmptyStreetNameOrNumber{
    return ERROR_EMPTY_STREET_NAME_OR_NUMBER;
}
+(NSString *)errorNegativeStreetNumber{
    return ERROR_NEGATIVE_STREET_NUMBER;
}
@end
