//
//  MtrStationPicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MtrStationPicker : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *myTableView;
    NSArray *arrayCurrentList;
    NSString *parentRowText;
}

- (void)initData;

@end
