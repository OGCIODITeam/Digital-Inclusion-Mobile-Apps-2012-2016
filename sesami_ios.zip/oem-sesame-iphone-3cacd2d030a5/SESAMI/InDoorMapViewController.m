//
//  InDoorMapViewController.m
//  SESAMI
//
//  Created by Ray.Liu on 8/14/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "InDoorMapViewController.h"
#import "MapTableViewController.h"
#import "FloorPlanTableViewController.h"
#import "OEMMap.h"
#import "OEMFloorPlan.h"
#import "FloorPlanViewController.h"

@interface InDoorMapViewController ()

@end

@implementation InDoorMapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    currentSection = @"MAP";
    currentFloorPlanLevel = 0;
    
    [self initMapData];
    [self loadMapView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {    
    viewContentContainer = nil;
    btnTableBack = nil;
    lblTableTitle = nil;
    
    viewIndoor = nil;
    tableViewIndoor = nil;
    
    viewFloorPlan = nil;
    tableViewFloorPlan = nil;
    
    floorPlanViewController = nil;
    
    currentSection = nil;
    currentMap = nil;
    
    [super viewDidUnload];
}

- (void)initMapData{
    arrayIndoor = [[NSArray alloc] initWithArray:[OEMDB getAllIndoorMaps]];
}

- (void)loadMapView{
    [self showHideTableBack:NO];
    [self showHideDownloadMapButton:YES];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName ] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickMap:) name:[AppConstant getClickResultCallBackName] object:nil];
    
    if(tvcMapResult==nil)
        tvcMapResult = [[MapTableViewController alloc] initWithData:arrayIndoor];
    
    [tableViewIndoor setDataSource:tvcMapResult];
    [tableViewIndoor setDelegate:tvcMapResult];
    
    [viewContentContainer addSubview:viewIndoor];
    tvcMapResult.tableView = tableViewIndoor;
    
    [lblTableTitle setText:@"室內地圖"];
    [tableViewIndoor reloadData];
    
    [viewFloorPlan removeFromSuperview];
}

- (void)initFloorPlanDataWithMapID:(int)mapID {
    arrayFloorPlan = [[NSArray alloc] initWithArray:[OEMDB getAllFloorPlanWithMapID:mapID]];
}

- (void)loadFloorPlanView
{
    [self showHideTableBack:YES];
    [self showHideDownloadMapButton:NO];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName ] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickFloorPlan:) name:[AppConstant getClickResultCallBackName] object:nil];
    
    if(tvcFloorPlanResult==nil)
        tvcFloorPlanResult = [[FloorPlanTableViewController alloc] initWithData:arrayFloorPlan];
    
    [tableViewFloorPlan setDataSource:tvcFloorPlanResult];
    [tableViewFloorPlan setDelegate:tvcFloorPlanResult];
    
    [viewContentContainer addSubview:viewFloorPlan];
    tvcFloorPlanResult.tableView = tableViewFloorPlan;
    
    [lblTableTitle setText:currentMap.displayName];
    [tableViewFloorPlan reloadData];
    
    [viewIndoor removeFromSuperview];
}

- (void)showHideTableBack:(BOOL)isShow{
    [btnTableBack setHidden:!isShow];
}

- (void)showHideDownloadMapButton:(BOOL)isShow
{
    [btnDownloadMap setHidden:!isShow];
}

- (void)showHideFloorPlan:(BOOL)isShow{
    
    
    if (floorPlanViewController == nil)
    {
        //floorPlanViewController = [[FloorPlanViewController alloc] initWithOEMFloorPlan:currentFloorPlan ParentViewController:self];
    }
    
    [viewContentContainer addSubview:floorPlanViewController.view];
    CGRect frame = floorPlanViewController.view.frame;
    CGRect endFrame = frame;
    if(isShow){
        frame.origin.x = frame.size.width;
        endFrame.origin.x = 0;
    }else{
        frame.origin.x = 0;
        endFrame.origin.x = endFrame.size.width;
    }
    floorPlanViewController.view.frame = frame;
    [viewContentContainer addSubview:floorPlanViewController.view];
    
    
    floorPlanViewController.view.frame=endFrame;
    if(!isShow){
        [floorPlanViewController.view removeFromSuperview];
        floorPlanViewController = nil;
        [viewContentContainer addSubview:viewFloorPlan];
        [lblTableTitle setText:currentMap.displayName];
    }else{
        [viewFloorPlan removeFromSuperview];
    }
    
    //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    
    /*
     [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
     floorPlanLevel1ViewController.view.frame=endFrame;} completion:^(BOOL finished){
     if(!isShow){
     [floorPlanLevel1ViewController.view removeFromSuperview];
     floorPlanLevel1ViewController = nil;
     [viewContentContainer addSubview:viewFloorPlan];
     }else{
     [viewFloorPlan removeFromSuperview];
     }
     
     UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
     }];
     */
}

//button event
- (IBAction)onClickTableBack:(id)sender {
    
    //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    
    if ([currentSection isEqualToString:@"FLOOR_PLAN"])
    {    
        if (currentFloorPlanLevel == 0)
        {
            [self showHideTableBack:NO];
            [self showHideDownloadMapButton:YES];
            [self initMapData];
            [self loadMapView];
        }
        else if (currentFloorPlanLevel == 3)
        {
            [self showHideFloorPlan:NO];
            currentFloorPlanLevel = 0;
        }
        else if (currentFloorPlanLevel == 2)
        {
            //NSLog(@"2...");
            [floorPlanViewController zoomOut];
            
            btnTableBack.isAccessibilityElement = NO;
            [NSTimer scheduledTimerWithTimeInterval:2.0
                                             target:self
                                           selector:@selector(playFloorPlanLevelCompletedHandler)
                                           userInfo:nil
                                            repeats:NO];
            [voiceLabel setAccessibilityValue:@"地圖第三層"];
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
        }
        else if (currentFloorPlanLevel == 1)
        {
            //NSLog(@"1...");
            [floorPlanViewController zoomOut];
            
            btnTableBack.isAccessibilityElement = NO;
            [NSTimer scheduledTimerWithTimeInterval:2.0
                                             target:self
                                           selector:@selector(playFloorPlanLevelCompletedHandler)
                                           userInfo:nil
                                            repeats:NO];
            [voiceLabel setAccessibilityValue:@"地圖第二層"];
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
        }
    }
    
    //btnTableBack.isAccessibilityElement = YES;
    //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, voiceLabel);
    //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    
}

- (void)playFloorPlanLevelCompletedHandler {
    btnTableBack.isAccessibilityElement = YES;
}

//event handle
- (void)onClickMap:(NSNotification *)notification
{
    if(notification.object!=nil)
    {
        OEMMap *map = (OEMMap *)notification.object;
        
        currentSection = @"FLOOR_PLAN";
        currentMap = map;
        
        [self initFloorPlanDataWithMapID:map.mapID];
        [self loadFloorPlanView];
    }
}

- (void)onClickFloorPlan:(NSNotification *)notification
{
    if(notification.object!=nil)
    {
        OEMFloorPlan *floorPlan = (OEMFloorPlan *)notification.object;
        currentFloorPlan = floorPlan;
        
        [lblTableTitle setText:currentFloorPlan.displayName];
        
        [self showHideFloorPlan:YES];
    }
}

- (void)setCurrentFloorPlanLevel:(int)level
{
    currentFloorPlanLevel = level;
}

@end
