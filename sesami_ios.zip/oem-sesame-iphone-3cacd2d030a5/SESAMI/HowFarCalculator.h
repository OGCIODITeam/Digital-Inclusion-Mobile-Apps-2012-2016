//
//  HowFarCalculator.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationTypePicker.h"
#import "HowFarResult.h"

@interface HowFarCalculator : BaseViewController
{
    __weak IBOutlet UIButton *btnSelectStartingLocaiton;
    __weak IBOutlet UIButton *btnSelectEndingLocation;
    __weak IBOutlet UIButton *btnHowFarCalculate;
    
    OEMLocation *locationStart;
    OEMLocation *locationEnd;
    
    HowFarResult *howFarResult;
    
    LocationTypePicker *locationTypePicker;
}

@end
