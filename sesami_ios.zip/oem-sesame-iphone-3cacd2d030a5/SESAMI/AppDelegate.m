//
//  AppDelegate.m
//  SESAMI
//
//  Created by Daniel Lee on 8/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "AppDelegate.h"
#import "MainTabController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [OEMDB initDB];
    [IndoorDB initDB];
    
    self.fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    self.documentsDir = [paths objectAtIndex:0];
    //NSLog(@"%@", self.documentsDir);
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.tabController = [[MainTabController alloc] initWithNibName:@"MainTabController" bundle:nil];
    
    //NSLog(@"height: %f",self.tabController.view.frame.size.height);
    
    self.window.rootViewController = self.tabController;
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [self showStatusBar];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
}

- (void)showStatusBar
{
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

- (void)hideStatusBar
{
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

@end
