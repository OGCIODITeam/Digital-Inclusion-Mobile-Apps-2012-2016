//
//  SearchingResult.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExternalDataLoader.h"

@interface SearchingResult : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
    ExternalDataLoader *externalDataLoader;
    NSString *mySearchText;
}

@property (strong, nonatomic) IBOutlet UILabel *lblTableViewMessage;
@property (strong, nonatomic) IBOutlet UITableView *tableViewSearchResult;

- (void)setData:(NSArray *)data;
- (void)disableDisclosureButton:(BOOL)isDisable;
- (void)loadResult;
- (void)onExternalDataReturn:(NSNotification *)notification;

@end
