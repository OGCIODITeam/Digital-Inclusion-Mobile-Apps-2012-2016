//
//  VirtualWalkViewIndex.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationResultTableViewController.h"
#import "ExternalDataLoader.h"
#import "LocationDetailViewController.h"

@interface VirtualWalkViewIndex : BaseViewController
{
    __weak IBOutlet UITextField *txtStreetName;
    __weak IBOutlet UITextField *txtStreetNumber;
    __weak IBOutlet UIButton *btnStart;
    __weak IBOutlet UILabel *lblReturnedBuildingName;
    __weak IBOutlet UIButton *btnStreetNumMinus2;
    __weak IBOutlet UIButton *btnStreetNumMinus1;
    __weak IBOutlet UIButton *btnStreetNumAdd1;
    __weak IBOutlet UIButton *btnStreetNumAdd2;
    __weak IBOutlet UIButton *btnCancel;
    __weak IBOutlet UIView *viewStreetNumControllersContainer;
    __weak IBOutlet UITableView *tableViewResult;
    __weak IBOutlet UIView *viewResult;
    IBOutlet UILabel *lblErrorMessage;
    
    ExternalDataLoader *externalDataLoader;
    LocationResultTableViewController *tvcLocationResult;
  
  int callNum;
  int incrementNum;
  NSMutableArray *allLocations;

}

@end
