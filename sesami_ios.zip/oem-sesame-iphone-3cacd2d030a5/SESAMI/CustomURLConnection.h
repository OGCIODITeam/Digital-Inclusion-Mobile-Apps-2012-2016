//
//  CustomURLConnection.h
//  asycnDownload
//
//  Created by hko on 23/04/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomURLConnection : NSURLConnection {
	IBOutlet NSString *tag;
	IBOutlet UIButton *btn;
	IBOutlet UIImageView *img;
}

@property (nonatomic, retain) NSString *tag;
@property (nonatomic, retain) UIButton *btn;
@property (nonatomic, retain) UIImageView *img;
- (id)initWithRequest:(NSURLRequest *)request delegate:(id)delegate startImmediately:(BOOL)startImmediately tag:(NSString*)p_tag btn:(UIButton*)p_btn img:(UIImageView*)p_img;
 
@end