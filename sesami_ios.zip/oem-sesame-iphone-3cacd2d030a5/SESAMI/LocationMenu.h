//
//  LocationMenu.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OEMLocation.h"
#import "HowFarResult.h"

@class NearByMeTypePicker;

@interface LocationMenu : BaseViewController
{
    __weak IBOutlet UIButton *btnHowFar;
    __weak IBOutlet UIButton *btnNearby;
    __weak IBOutlet UIButton *btnFavorite;
    
    BOOL isFavorited;
    
    OEMLocation *locationStart;
    OEMLocation *locationEnd;
    
    HowFarResult *howFarResult;
    
    NearByMeTypePicker *nearByMeTypePicker;
}

- (IBAction)onClickHowFar:(id)sender;
- (IBAction)onClickNearby:(id)sender;
- (IBAction)onClickFavorite:(id)sender;

@end
