//
//  ViewController.h
//  ApiLibDemo
//
//  Created by Yuen Hang on 12/10/12.
//  Copyright (c) 2012 88DB. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ORAPIIOS.h"

@interface OpenRiceResult : NSObject

@property (nonatomic, retain) NSString *apiToken;
@property (nonatomic, retain) NSString *authToken;
@property (nonatomic, retain) CLLocation *startLocation;

-(id)init;
-(void)getResult:(CLLocation *)loc;

@end
