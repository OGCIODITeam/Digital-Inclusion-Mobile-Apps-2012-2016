//
//  ORAPIIOS.h
//  ORAPIIOS
//
//  Created by Yuen Hang on 12/10/12.
//  Copyright (c) 2012 88DB. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ORAPIObject.h"

#define kNotificationGetAPIToken @"kNotificationGetAPIToken"
#define kNotificationGetAPITokenFail @"kNotificationGetAPITokenFail"

typedef enum {
    Status_NoError          = 200,
    Status_InvalidAPIToken  = 44,
    Status_InvalidAPISig    = 46,
    Status_InvalidAppType   = 51,
    Status_InvalidAppVer    = 52,
    Status_NormalChecksum   = 304,
    Status_ServerException  = 10000,
    Status_InvalidAppId     = 99999,
} APIWebserviceResponseStatus;

typedef void (^ORAPISuccessBlock)(ORAPIObject *result);
typedef void (^ORAPIFailBlock)(NSError *error);

@interface ORAPIIOS : NSObject <NSURLConnectionDelegate, NSURLConnectionDataDelegate> {
    
    NSURLConnection *conn;
    NSMutableData *receivedData;
    ORAPISuccessBlock successblock;
    ORAPIFailBlock failblock;
    
}

+ (NSString *)calAPISig:(NSString *)url;
+ (NSString *)calAPISig:(NSString *)url withParams:(NSArray *)params;

+ (BOOL)invalidateCache;
/*
 Post kNotificationGetAPIToken with ORAPIObject object
 Post kNotificationGetAPITokenFail with NSError object (code: APIWebserviceResponseStatus)
 */
+ (void)requestAPIToken:(NSString *)domain andAppType:(NSString *)appType
              andAppVer:(NSString *)appVer andApiVer:(NSString *)apiVer andRegion:(NSString *)regionId;

- (void)requestAPIToken:(NSString *)domain andAppType:(NSString *)appType
              andAppVer:(NSString *)appVer andApiVer:(NSString *)apiVer andRegion:(NSString *)regionId
             andTimeout:(NSTimeInterval)timeout
           successBlock:(ORAPISuccessBlock)success
              failBlock:(ORAPIFailBlock)fail;

@end
