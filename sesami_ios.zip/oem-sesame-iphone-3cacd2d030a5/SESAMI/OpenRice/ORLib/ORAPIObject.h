//
//  ORAPIObject.h
//  ORAPIIOS
//
//  Created by Yuen Hang on 17/10/12.
//  Copyright (c) 2012 88DB. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ORAPIObject : NSObject

@property (nonatomic, readonly) NSString *apiToken;
@property (nonatomic, readonly) BOOL isAppCompatible;

@end
