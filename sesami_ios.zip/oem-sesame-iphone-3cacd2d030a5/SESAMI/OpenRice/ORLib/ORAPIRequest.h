//
//  ORAPIRequest.h
//  ORAPIIOS
//
//  Created by Hang on 15/4/13.
//  Copyright (c) 2013 88DB. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^ORSuccessBlock)(NSDictionary *result);
typedef void (^ORFailureBlock)(NSError *error);

@interface ORAPIRequest : NSObject <NSURLConnectionDelegate> {
    
    NSURLConnection *conn;
    
    NSMutableData *receivedData;
    
    ORSuccessBlock successBlock;
    ORFailureBlock failureBlock;
}

@property (nonatomic, retain) NSString *orapidomain;
@property (nonatomic, retain) NSString *snapapidomain;
@property (nonatomic, retain) NSString *apiToken;
@property (nonatomic, retain) NSString *authToken;

- (BOOL)requestAPI:(NSString *)method params:(NSMutableDictionary *)params
      successBlock:(ORSuccessBlock)success
         failBlock:(ORFailureBlock)fail;

@end
