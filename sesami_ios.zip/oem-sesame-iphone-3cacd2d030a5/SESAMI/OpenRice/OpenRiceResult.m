//
//  ViewController.m
//  ApiLibDemo
//
//  Created by Yuen Hang on 12/10/12.
//  Copyright (c) 2012 88DB. All rights reserved.
//

#import "OpenRiceResult.h"

#import "NSURLConnection+Blocks.h"

#import "ORAPIIOS.h"

#import "SBJson.h"

#import "ASIFormDataRequest.h"

#import "ZipArchive.h"

#define USE_BLOCK 1
#define DEBUG 1

#define SERVER @"http://iphone.api.openrice.com"

#define APPTYPE @"orbuiphoneapp"
#define APPVER @"1.0.0"
#define APIVER @"125"
#define REGION @"0"

@interface NSString (URLEncoding)
-(NSString *)urlEncodeUsingEncoding:(NSStringEncoding)encoding;
@end

@implementation NSString (URLEncoding)
-(NSString *)urlEncodeUsingEncoding:(NSStringEncoding)encoding {
	return (NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
                                                             (CFStringRef)self,
                                                             NULL,
                                                             (CFStringRef)@":/?#[]@!$ &'()*+,;=\"<>%{}|\\^~`",
                                                             //                                                               (CFStringRef)@"|!*'\"();:@&=+$,/?%#[]% ",
                                                             CFStringConvertNSStringEncodingToEncoding(encoding));
}
@end


@interface OpenRiceResult ()

@end

@implementation OpenRiceResult

@synthesize authToken;
@synthesize apiToken;
@synthesize startLocation;

- (id)init {
  NSLog(@"Calling init");
  self = [super init];
  return self;
}

- (void)receivedApiToken:(NSNotification *)notification {
  NSLog(@"Calling receivedApiToken");
  id object = [notification object];
  
  if ([object isKindOfClass:[NSError class]]) {
    [self errorHandling:object];
  } else {
    ORAPIObject *obj = (ORAPIObject *)object;
    
    [self onTokenReceived:obj];
  }
}

- (void)getResult:(CLLocation *)loc
{
  self.startLocation = loc;
  
#if defined FIX_API_TOKEN
  self.apiToken = FIX_API_TOKEN;
#endif

  if (USE_BLOCK) {
    // It is a async request, no need to put it in another thread
    ORAPIIOS *orapiRequest = [[ORAPIIOS alloc] init];
    [orapiRequest requestAPIToken:SERVER andAppType:APPTYPE andAppVer:APPVER
                        andApiVer:APIVER andRegion:REGION andTimeout:30
                     successBlock:^(ORAPIObject *result) {
                       
                       [self onTokenReceived:result];
                       
                       [orapiRequest release];
                     } failBlock:^(NSError *err) {
                       [self errorHandling:err];
                       
                       [orapiRequest release];
                     }];
  } else {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receivedApiToken:)
                                                 name:kNotificationGetAPIToken object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receivedApiToken:)
                                                 name:kNotificationGetAPITokenFail object:nil];
    [ORAPIIOS requestAPIToken:SERVER andAppType:APPTYPE andAppVer:APPVER andApiVer:APIVER andRegion:REGION];
  }
}

- (void)onTokenReceived:(ORAPIObject *)result {
  if (result.isAppCompatible) {
//    NSLog(@"Token: %@", result.apiToken);
    
    if ([self.apiToken length] == 0)
      self.apiToken = result.apiToken;
    
    // warning uncomment for testing different function
    [self getBUList:apiToken];
  }
}

- (void)errorHandling:(NSError *)err {
  switch ([err code]) {
    case Status_NoError:
      NSLog(@"Err: Status_NoError");
      break;
    case Status_InvalidAPIToken:
      NSLog(@"Err: Status_InvalidAPIToken\nPlease call get token to renew your token");  // Will not happen in get api token call
      break;
    case Status_InvalidAPISig:
      NSLog(@"Err: Status_InvalidAPISig");
      break;
    case Status_InvalidAppType:
      NSLog(@"Err: Status_InvalidAppType");
      break;
      //        case Status_InvalidAppVer:
      //            self.keyLabel.text = @"Err: Status_InvalidAppVer";
      //            NSDictionary *compat = [err userInfo];
      //            // It is assume to contain the Compatiable object for user action
      //            NSLog(@"%s:%@", __FUNCTION__, compat);
      //            break;
    case Status_NormalChecksum:
      NSLog(@"Err: Status_NormalChecksum");  // Will not happen in get api token call
      break;
    case Status_ServerException:
      NSLog(@"Err: Status_ServerException");  // Will not happen in get api token call
      break;
    default:
      NSLog(@"Error - %@", [err description]);
      break;
  }
}

#pragma mark - GET sample

- (void)getBUList:(NSString *)token {
//  CLLocation * currentLocation = [GlobalVar getCurrentLocation];
  
//  NSString *stringURL = [NSString stringWithFormat:@"%@/api/api.htm?method=or.bu.poi.getlist&api_token=%@&region_id=0&maplat=22.303168&maplng=114.171826&distance=500&is_spatial=1&per_page=20&page=1&response_type=json&app_type=%@", SERVER, token, APPTYPE];

  NSString *stringURL = [NSString stringWithFormat:@"%@/api/api.htm?method=or.bu.poi.getlist&api_token=%@&region_id=0&maplat=%f&maplng=%f&distance=500&is_spatial=1&per_page=20&page=1&response_type=json&app_type=%@", SERVER, token, startLocation.coordinate.latitude, startLocation.coordinate.longitude, APPTYPE];

  NSString *apiSig = [ORAPIIOS calAPISig:stringURL];
  
//  stringURL = [NSString stringWithFormat:@"%@/api/api.htm?method=or.bu.poi.getlist&api_token=%@&region_id=0&maplat=22.303168&maplng=114.171826&distance=500&is_spatial=1&per_page=20&page=1&response_type=json&app_type=%@", SERVER, [token urlEncodeUsingEncoding:NSUTF8StringEncoding], APPTYPE];

  stringURL = [NSString stringWithFormat:@"%@/api/api.htm?method=or.bu.poi.getlist&api_token=%@&region_id=0&maplat=%f&maplng=%f&distance=500&is_spatial=1&per_page=40&page=1&response_type=json&app_type=%@", SERVER, [token urlEncodeUsingEncoding:NSUTF8StringEncoding], startLocation.coordinate.latitude, startLocation.coordinate.longitude, APPTYPE];

  stringURL = [NSString stringWithFormat:@"%@&api_sig=%@", stringURL, apiSig];
  NSLog(@"Calling Open Rice - %@", stringURL);
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:stringURL]];
  
  [NSURLConnection asyncRequest:request success:^(NSData *data, NSURLResponse *response){
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getOpenRiceCallBackName] object:data];
    NSString *str = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    NSLog(@"Open Rice response - %@", str);

  } failure:^(NSData *data, NSError *err){
    [self errorHandling:err];
  }];
}

#pragma mark -

- (BOOL)showResult:(NSDictionary *)jsonDict {
  NSDictionary *sys = [[[jsonDict objectForKey:@"Root"] objectForKey:@"System"] objectAtIndex:0];
  NSLog(@"Not sure - %@", [NSString stringWithFormat:@"status %@: %@", [sys objectForKey:@"Status"], [sys objectForKey:@"Check"]]);
  NSLog(@"%s:%@", __FUNCTION__, jsonDict);
  return ([[sys objectForKey:@"Status"] intValue] == Status_NoError);
}

- (void)dealloc {
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  
  self.authToken = nil;
  [super dealloc];
}

@end
