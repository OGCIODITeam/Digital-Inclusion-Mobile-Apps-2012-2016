//
//  PositionViewController.h
//  semami
//
//  Created by Daniel Lee on 25/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LocationPickerViewController;
@class LocationResultTableViewController;
@class ExternalDataLoader;
@class LocationDetailViewController;

@interface PositionViewController : UIViewController{
    UIView *tempView;
    
    IBOutlet UIView *viewContentContainer;
    IBOutlet UIView *viewMainMenu;
    __weak IBOutlet UILabel *lblTableTitle;    
    IBOutlet UIButton *btnTableBack;

    IBOutlet UIButton *btnWhereAmI;
    IBOutlet UIView *viewWhereAmIDirection;
    IBOutlet UIView *viewWhereAmIResult;
    
    
    __weak IBOutlet UIButton *btnHowFar;
    IBOutlet UIView *viewHowFarSelection;
    IBOutlet UIView *viewHowFarResult;
    __weak IBOutlet UIButton *btnSelectStartingLocaiton;
    __weak IBOutlet UIButton *btnSelectEndingLocation;
    
    IBOutlet UIView *viewResult;
    __weak IBOutlet UITableView *tableViewResult;
    
    NSMutableArray *arrayTableTitleStack;
    NSMutableDictionary *dictContentStack;
    __strong LocationPickerViewController *lpvc;
    
    IBOutlet UILabel *lblTableViewMessage;
    
    //how far
    IBOutlet UILabel *lblHowFarResult;
    OEMLocation *locationStart;
    OEMLocation *locationEnd;
    
    //what's nearby
    
    __weak IBOutlet UIButton *btnNearby;
    IBOutlet UIView *viewNearbyCategory;
    __weak IBOutlet UIButton *btnNearbyBuilding;
    __weak IBOutlet UIButton *btnNearbyBusStop;
    __weak IBOutlet UIButton *btnNearbyRestaurant;
    __weak IBOutlet UIButton *btnNearbyLandmark;
    __weak IBOutlet UIButton *btnNearbyAll;
    OEMLocation *locationNearbyStart;
    
    ///
    LocationResultTableViewController *tvcLocationResult;
    ExternalDataLoader *externalDataLoader;
    LocationDetailViewController *locationDetailViewController;
    BOOL isViewTransiting;
    BOOL isSearchingNearby;
    BOOL isShowingResult;
    BOOL isShowLocationDetail;
    int searchType;
    NSTimer *refreshTimer;
}
- (void)showHowFarViewWithLocationEnd:(OEMLocation *)locEnd;
- (void)showNearbyViewWithLocation:(OEMLocation *)loc;
@end
