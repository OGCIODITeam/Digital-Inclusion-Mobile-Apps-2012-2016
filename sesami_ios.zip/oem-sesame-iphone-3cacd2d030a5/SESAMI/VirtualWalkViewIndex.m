//
//  VirtualWalkViewIndex.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "VirtualWalkViewIndex.h"

@implementation VirtualWalkViewIndex

- (void)viewDidLoad
{
  [super viewDidLoad];
  [self initView];
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = @"虛擬漫步";
}

- (void)viewDidUnload
{
  txtStreetName = nil;
  txtStreetNumber = nil;
  btnStart = nil;
  lblReturnedBuildingName = nil;
  btnStreetNumMinus2 = nil;
  btnStreetNumMinus1 = nil;
  btnStreetNumAdd1 = nil;
  btnStreetNumAdd2 = nil;
  viewStreetNumControllersContainer = nil;
  tableViewResult = nil;
  viewResult = nil;
  lblErrorMessage = nil;
  [super viewDidUnload];
}

- (void)initView
{
  [btnStreetNumAdd1 setEnabled:YES];
  [btnStreetNumAdd2 setEnabled:NO];
  [btnStreetNumMinus1 setEnabled:YES];
  [btnStreetNumMinus2 setEnabled:NO];
  
  viewStreetNumControllersContainer.accessibilityElementsHidden = NO;
  
  UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

- (IBAction)onClickStart:(id)sender
{
  //    if([txtStreetName.text isEqualToString:@""] || [txtStreetNumber.text isEqualToString:@""]){
  //        [AppFunction quickAlertWithMessage:[AppMessage errorEmptyStreetNameOrNumber] title:nil];
  //    }else{
  //      [self demo];
  //      [self startRequest];
  //    }
  [self onClickAdd1:sender];
}

- (IBAction)onClickMinus2:(id)sender
{
  if([txtStreetNumber.text intValue]<=2){
    [AppFunction quickAlertWithMessage:[AppMessage errorNegativeStreetNumber] title:nil];
  }else{
    txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]-2)];
    [self demo];
    [self startRequest];
  }
}

- (IBAction)onClickMinus1:(id)sender
{
  if([txtStreetName.text isEqualToString:@""] || [txtStreetNumber.text isEqualToString:@""]){
    [AppFunction quickAlertWithMessage:[AppMessage errorEmptyStreetNameOrNumber] title:nil];
  } else {
    callNum = 0;
    incrementNum = -2;
    allLocations = [[NSMutableArray alloc] init];
    [self startRequest];
    
    //       txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]-1)];
    //        [self demo];
  }
}

- (IBAction)onClickAdd1:(id)sender
{
  if([txtStreetName.text isEqualToString:@""] || [txtStreetNumber.text isEqualToString:@""]){
    [AppFunction quickAlertWithMessage:[AppMessage errorEmptyStreetNameOrNumber] title:nil];
  } else {
    callNum = 0;
    incrementNum = 2;
    allLocations = [[NSMutableArray alloc] init];
    
    [self startRequest];
    
    //       txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]+1)];
    //        [self demo];
  }
}

- (IBAction)onClickAdd2:(id)sender
{
  txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]+2)];
  [self demo];
  [self startRequest];
}

- (void)startRequest
{
  if ((callNum != 0) && (callNum % 5 == 0)) {
    NSString *tmpStr = [NSString stringWithFormat:@"%i 個", callNum*2];
    UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, tmpStr);
  }
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
  if(externalDataLoader==nil)
    externalDataLoader = [[ExternalDataLoader alloc] init];
  [externalDataLoader centaMapGetBuildingByStreetName:[txtStreetName text] StreetNumber:[txtStreetNumber.text intValue]];
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
}

- (void)onExternalDataReturn:(NSNotification *)notification
{
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
  
  [lblErrorMessage removeFromSuperview];
  
  if([notification.object isKindOfClass:[NSError class]]){
    tableViewResult.hidden = YES;
    [lblErrorMessage setText:[AppMessage getServerDownMSG]];
    
    [viewResult addSubview:lblErrorMessage];
  }else{
    
    NSDictionary *json = (NSDictionary *)notification.object;
    if ([json count]==0) {
      NSLog(@"json is empty");
    } else {
      CLLocation *cLocation = [GlobalVar getCurrentLocation];
      //          tableViewResult.hidden = NO;
      //notification.object saved the array of researched location
      //put create OEMLocation for all locations and push into arrayLocation
      NSMutableArray *arrayLocationForSort = [[NSMutableArray alloc] init];
      //          NSMutableArray *arrayLocation = [[NSMutableArray alloc] init];
      
      for(NSDictionary *node in (NSArray *)[json objectForKey:@"Table"]){
        CLLocation *nLocation = [[CLLocation alloc] initWithLatitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"]doubleValue]];

        // Add street number to the front
        NSString *newName = [[txtStreetNumber.text stringByAppendingString:@"號 "] stringByAppendingString:[node objectForKey:@"displayname"]];
        
        OEMLocation *location = [[OEMLocation alloc] initWithName:newName latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:[node objectForKey:@"displayaddr"]];
        
        NSArray *arrNode = [[NSArray alloc] initWithObjects:[NSNumber numberWithDouble:[nLocation distanceFromLocation:cLocation]], location, nil];
        [arrayLocationForSort addObject:arrNode];
      }
      
      NSArray *arrayLocationSorted = [arrayLocationForSort sortedArrayUsingComparator:^(id a, id b){
        return [[a objectAtIndex:0] compare:[b objectAtIndex:0]];
      }];
      
      //          for(NSArray *node in arrayLocationSorted){
      //              [arrayLocation addObject:[node objectAtIndex:1]];
      //          }
      
      for(NSArray *node in arrayLocationSorted){
        [allLocations addObject:[node objectAtIndex:1]];
      }
      
      
      //start listen to the click event and the click disclosure of the row in the result tableView
      /*
       [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
       [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
       
       [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
       [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResultDisclosure:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
       */
    }
    
    callNum += 1;
    if ((callNum <= [AppConstant getVirtualWalkCallNumber]) && ([txtStreetNumber.text intValue]+incrementNum) > 0) {
      txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]+incrementNum)];
      [self startRequest];
    } else {
      if ([allLocations count] > 0) {
        NSLog(@"Total locations found - %i", [allLocations count]);
        tableViewResult.hidden = NO;
        if(tvcLocationResult == nil)
          tvcLocationResult = [[LocationResultTableViewController alloc] initWithData:allLocations];
        else
          [tvcLocationResult setData:allLocations];
        
        [tvcLocationResult disableDisclosureButton:YES];
        [tableViewResult setDataSource:tvcLocationResult];
        [tableViewResult setDelegate:tvcLocationResult];
        tvcLocationResult.tableView = tableViewResult;
        
        [tableViewResult reloadData];
        [txtStreetName resignFirstResponder];
        [txtStreetNumber resignFirstResponder];
        
        UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, @"下載完成");
      } else {
        tableViewResult.hidden = YES;
        [viewResult addSubview:lblErrorMessage];
        [lblErrorMessage setText:[AppMessage getNoResultMSG]];
      }
    }
  }
}

- (void)demo
{
  [btnStreetNumAdd1 setEnabled:YES];
  [btnStreetNumAdd2 setEnabled:YES];
  [btnStreetNumMinus1 setEnabled:YES];
  [btnStreetNumMinus2 setEnabled:YES];
  
  viewStreetNumControllersContainer.accessibilityElementsHidden = NO;
  
  [lblReturnedBuildingName setText:@"快樂大廈"];
  [txtStreetName resignFirstResponder];
  [txtStreetNumber resignFirstResponder];
  
  UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, lblReturnedBuildingName.text);
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
  if([textField isEqual:txtStreetNumber]){
    NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    return ([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0) || [string isEqualToString:@""];
  }
  return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  [txtStreetName resignFirstResponder];
  [txtStreetNumber resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField
{
  if(theTextField==txtStreetName){
    [txtStreetNumber becomeFirstResponder];
  }
  if(theTextField==txtStreetNumber){
    [btnStart becomeFirstResponder];
    [txtStreetName resignFirstResponder];
    [txtStreetNumber resignFirstResponder];
  }
  return YES;
}

- (IBAction)onClickCancel:(id)sender {
  [btnStart becomeFirstResponder];
  [txtStreetName resignFirstResponder];
  [txtStreetNumber resignFirstResponder];
}

@end
