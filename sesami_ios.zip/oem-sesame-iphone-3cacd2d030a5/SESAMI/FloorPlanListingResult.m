//
//  FloorPlainListingResult.m
//  SESAMI
//
//  Created by Ray.Liu on 9/4/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "FloorPlanListingResult.h"

@implementation FloorPlanListingResult

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
  self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
  if (self)
  {
    //[self setData:[[NSArray alloc] initWithArray:[OEMDB getAllIndoorMaps]]];
    
    int mapID = [[self.myExtraData objectForKey:@"mapID"] intValue];
    
    NSLog(@"mapID: %i", mapID);
    
    arrayData = [[NSArray alloc] initWithArray:[IndoorDB getAllFloorPlanWithMapID:mapID]];
    [self disableDisclosureButton:YES];
  }
  return self;
}

- (void)viewDidLoad
{
  [super viewDidLoad];
//  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
//  {
//    [self.tableViewIndoor setContentInset:UIEdgeInsetsMake(-40, self.tableViewIndoor.contentInset.left, self.tableViewIndoor.contentInset.bottom, self.tableViewIndoor.contentInset.right)];
//  }
  
  [self.tableViewIndoor reloadData];
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = @"室內地圖";
  
    int mapID = [[self.myExtraData objectForKey:@"mapID"] intValue];
    
    NSLog(@"mapID: %i", mapID);
    
    arrayData = [[NSArray alloc] initWithArray:[IndoorDB getAllFloorPlanWithMapID:mapID]];
    
      [self.tableViewIndoor reloadData];
    
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:NO  LeftTitle:@""
   ShowRight:NO RightTitle:@""];
}

-(void)setData:(NSArray *)data{
  arrayData = data;
}

-(void)disableDisclosureButton:(BOOL)isDisable{
  isDisableDisclosureButton = isDisable;
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
  return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
  }
  if(!isDisableDisclosureButton){
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
  }
  // Configure the cell...
  UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
  CGRect frame = iv.frame;
  frame.origin = cell.frame.origin;
  frame.size = cell.frame.size;
  frame.size.height = 60;
  iv.frame = frame;
  cell.backgroundView = iv;
  cell.textLabel.text = [(OEMMap *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
  cell.textLabel.backgroundColor = [UIColor clearColor];
  
  cell.accessibilityValue = [(OEMMap *)[arrayData objectAtIndex:[indexPath row]] getDescription];
  
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  OEMFloorPlan *floorPlan = (OEMFloorPlan *)[arrayData objectAtIndex:[indexPath row]];
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:self.myParentViewController forKey:@"parentViewController"];
  [extraData setValue:floorPlan forKey:@"floorPlan"];
  
  floorPlanViewController = [[FloorPlanViewController alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:floorPlanViewController animated:YES];
  //  [self presentModalViewController:floorPlanViewController animated:YES];
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

@end
