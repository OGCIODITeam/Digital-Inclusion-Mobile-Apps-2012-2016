//
//  LocationTypePicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "LocationTypePicker.h"

@implementation LocationTypePicker

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //draw the control
    if ([[self getMySection] isEqualToString:@"Tab1_NearBy"])
    {
        [btnSelectorCurrentLocation setHidden:YES];
        
        CGFloat rHeight = btnSelectorCurrentLocation.frame.size.height;
        
        [btnSelectorFavorite setFrame:CGRectMake(btnSelectorFavorite.frame.origin.x, btnSelectorFavorite.frame.origin.y-rHeight, btnSelectorFavorite.frame.size.width, btnSelectorFavorite.frame.size.height)];
        
        [btnSelectorMTR setFrame:CGRectMake(btnSelectorMTR.frame.origin.x, btnSelectorMTR.frame.origin.y-rHeight, btnSelectorMTR.frame.size.width, btnSelectorMTR.frame.size.height)];
        
        [btnSelectorSearch setFrame:CGRectMake(btnSelectorSearch.frame.origin.x, btnSelectorSearch.frame.origin.y-rHeight, btnSelectorSearch.frame.size.width, btnSelectorSearch.frame.size.height)];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    if ([[self getMySection] isEqualToString:@"Tab1_NearBy"])
    {
        self.title = @"起點位置選單";
    }
    else
    {
        self.title = @"位置選單";
    }
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

- (IBAction)onClickCurrentLocation:(id)sender
{
    OEMLocation *currentLocation = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:currentLocation];
}

- (IBAction)onClickMyFavorite:(id)sender
{
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:[self getMySection] forKey:@"mySection"];
    
    myFavoritePicker = [[MyFavoritePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    arrayFavorite = [[NSArray alloc] initWithArray:[OEMDB getAllFavoriteLocations]];
    
    [myFavoritePicker setData:arrayFavorite];
    [myFavoritePicker disableDisclosureButton:YES];
    [myFavoritePicker.tableViewFavorite reloadData];
    
    [[NSNotificationCenter defaultCenter] removeObserver:myFavoritePicker name:[AppConstant getClickResultCallBackName] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:myFavoritePicker selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
    
    [self.myNavigationController pushViewController:myFavoritePicker animated:YES];
    
    //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

- (IBAction)onClickMTR:(id)sender
{
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:[self getMySection] forKey:@"mySection"];
    
    mtrLinePicker = [[MtrLinePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    [self.myNavigationController pushViewController:mtrLinePicker animated:YES];
}

- (IBAction)onClickSearch:(id)sender
{
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:[self getMySection] forKey:@"mySection"];
    
    searchingController = [[SearchingController alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
    
    [self.myNavigationController pushViewController:searchingController animated:YES];
}

@end
