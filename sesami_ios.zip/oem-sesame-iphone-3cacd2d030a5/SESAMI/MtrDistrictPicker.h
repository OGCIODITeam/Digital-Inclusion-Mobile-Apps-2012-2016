//
//  MtrDistrictPicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MtrStationPicker.h"

@interface MtrDistrictPicker : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *myTableView;
    
    NSArray *arrayStationSet0;
    NSArray *arrayStationSet1;
    NSArray *arrayStationSet2;
    NSArray *arrayStationSet3;
    NSArray *arrayStationSet4;
    NSArray *arrayStationSet5;
    NSArray *arrayStationSet6;
    NSArray *arrayStationSet7;
    NSArray *arrayStationSet8;
    NSArray *arrayStationSet9;
    NSArray *arrayStationSets;
    
    NSArray *arrayCurrentList;
    
    int parentRowIndex;
    NSString *myTitle;
    
    MtrStationPicker *mtrStationPicker;
}

- (void)initData;

@end
