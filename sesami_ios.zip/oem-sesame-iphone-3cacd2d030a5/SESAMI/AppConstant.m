//
//  AppConstant.m
//  semami
//
//  Created by Daniel Lee on 27/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "AppConstant.h"
#define ANIMATION_DURATION 0.3
#define LOCATION_PICKER_CALL_BACK_NAME @"LOCATION_PICKER_CALL_BACK"
#define CLICK_RESULT_CALL_BACK_NAME @"CLICK_RESULT_CALL_BACK";
#define CLICK_RESULT_DISCLOSURE_CALL_BACK_NAME @"CLICK_RESULT_DISCLOSURE_CALL_BACK";
#define EXTERNAL_DATA_CALL_BACK_NAME @"EXTERNAL_DATA_CALL_BACK";
#define OPENRICE_CALL_BACK_NAME @"OPENRICE_CALL_BACK";
#define SHOW_LOADING_VIEW @"SHOW_LOADING_VIEW";
#define HIDE_LOADING_VIEW @"HIDE_LOADING_VIEW";
#define DIRECT_SHOW_VIEW_HOW_FAR @"DIRECT_SHOW_VIEW_HOW_FAR";
#define DIRECT_SHOW_VIEW_NEARBY @"DIRECT_SHOW_VIEW_NEARY";
#define DEFAULT_ZOOM_LEVEL_FOR_CENTAMAP 3;
#define LOCATION_DIFFERENT_MARGIN 2.0;
#define DIRECTION_CHINESE_FRONT @"前";
#define DIRECTION_CHINESE_RIGHT @"右";
#define DIRECTION_CHINESE_LEFT @"左";
#define DIRECTION_CHINESE_BACK @"後";
#define VIRTUALWALK_CALL_NUMBER 20;

@implementation AppConstant


+(double)getAnimationDuration{
  return ANIMATION_DURATION;
}
+(NSString *)getLocationPickerCallBackFuncionName{
  return LOCATION_PICKER_CALL_BACK_NAME;
}
+(NSString *)getClickResultCallBackName{
  return CLICK_RESULT_CALL_BACK_NAME;
}
+(NSString *)getClickResultDisclosureCallBackName{
  return CLICK_RESULT_DISCLOSURE_CALL_BACK_NAME;
}
+(NSString *)getExternalDataLoaderCallBackName{
  return EXTERNAL_DATA_CALL_BACK_NAME;
}
+(NSString *)getOpenRiceCallBackName{
  return OPENRICE_CALL_BACK_NAME;
}
+(NSString *)getShowLoadingEventName{
  return SHOW_LOADING_VIEW;
}
+(NSString *)getHideLoadingEventName{
  return HIDE_LOADING_VIEW;
}
+(NSString *)getDirectShowViewHowFarCallBackName{
  return DIRECT_SHOW_VIEW_HOW_FAR;
}
+(NSString *)getDirectShowViewNearbyCallBackName{
  return DIRECT_SHOW_VIEW_NEARBY;
}

+(int)getDefaultZoomLevelForCentamap{
  return DEFAULT_ZOOM_LEVEL_FOR_CENTAMAP;
}
+(double)getLocationDifferentMargin{
  return LOCATION_DIFFERENT_MARGIN;
}

+(NSString *)getDirectionChineseFront{
  return DIRECTION_CHINESE_FRONT;
}
+(NSString *)getDirectionChineseBack{
  return DIRECTION_CHINESE_BACK;
}
+(NSString *)getDirectionChineseLeft{
  return DIRECTION_CHINESE_LEFT;
}
+(NSString *)getDirectionChineseRight{
  return DIRECTION_CHINESE_RIGHT;
}

+ (NSMutableDictionary *)getNavigationButtonFont
{
  NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
  [dict setValue:[UIColor whiteColor] forKey:@"color"];
  [dict setValue:@"14.0" forKey:@"size"];
  [dict setValue:@"Helvetica" forKey:@"family"];
  return dict;
}


+(CGFloat)getScreenWidth {
  return 320.0;
}

+(CGFloat)getScreenHeight {
  return [UIScreen mainScreen].bounds.size.height;
}

+(CGFloat)getStatusBarHeight {
  return 20;
}

+(CGRect)getMainNavigationFrame
{
  float y=20;
  
  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
  {
    if ([AppConstant getScreenHeight] == 568)
    {
      return CGRectMake(0, 20, 320, 548-49);
    }
    else
    {
      return CGRectMake(0, 40, 320, 548-49);
    }
  }
  
  if ([AppConstant getScreenHeight] == 568)
  {
    return CGRectMake(0, -20, 320, 548-49);
  }
  
  return CGRectMake(0, y, 320, 460-49);
}

+(CGRect)getTabControllerFrame
{
  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
  {
    if ([AppConstant getScreenHeight] == 568)
    {
      return CGRectMake(0, 0, 320, 548-89);
    }
    else
    {
      return CGRectMake(0, -20, 320, 548-69);
    }
  }
  
  
  if ([AppConstant getScreenHeight] == 568)
  {
    return CGRectMake(0, -20, 320, 480);
  }
  
  if ([AppConstant getScreenHeight] == 480)
  {
    return CGRectMake(0, -40, 320, 548-49);
  }
  
  return CGRectMake(0, 0, 320, 460);
}

+(CGRect)getContentViewFrame
{
  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
  {
    if ([AppConstant getScreenHeight] == 568)
    {
      return CGRectMake(0, 40, 320, 548-49-40);
    }
    else
    {
      return CGRectMake(0, 40, 320, 480-120);
    }
  }
  
  
  if ([AppConstant getScreenHeight] == 568)
  {
    return CGRectMake(0, 40, 320, 548-49-50);
  }
  if ([AppConstant getScreenHeight] == 480)
  {
    return CGRectMake(0, 40, 320, 548-49-124);
  }
  //NSLog(@"%F",[AppConstant getScreenHeight]);
  return CGRectMake(0, 40, 320, 460-49-44);
}

+(int)getVirtualWalkCallNumber{
  return VIRTUALWALK_CALL_NUMBER;
}

@end
