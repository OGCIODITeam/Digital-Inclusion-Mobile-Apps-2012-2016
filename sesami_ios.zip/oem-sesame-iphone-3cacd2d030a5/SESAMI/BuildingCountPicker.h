//
//  BuildingCountPicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuildingCountPicker : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    __weak IBOutlet UITableView *tableViewNearbyBuildingOption;
    NSArray *arrayNearbyBuildingItems;
}

@end
