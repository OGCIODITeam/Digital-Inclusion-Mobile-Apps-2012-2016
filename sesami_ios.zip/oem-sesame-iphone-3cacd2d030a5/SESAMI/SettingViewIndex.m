//
//  SettingViewIndex.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "SettingViewIndex.h"

@implementation SettingViewIndex

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setAutoUpdateIndoorMap:[GlobalVar getAutoUpdateIndoorMap]];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"設定";
    
    [MainNavigationController
     InitInformationNavigationWithController:self
     ShowLeft:NO LeftTitle:@""
     ShowRight:YES RightTitle:@"關於我們"];
}

- (IBAction)onClickNearbyBuilding:(id)sender
{
    if (buildingCountPicker == nil)
    {
        buildingCountPicker = [[BuildingCountPicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
    }
    
    [self.myNavigationController pushViewController:buildingCountPicker animated:YES];
    
    /*
    [tableViewNearbyBuildingOption reloadData];
    [viewContentContainer addSubview:viewNearbyBuildingOption];
    [self showHideTableBack:YES];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    */
}

- (IBAction)onClickAlertInterval:(id)sender
{
    if (updateIntervalPicker == nil)
    {
        updateIntervalPicker = [[UpdateIntervalPicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
    }
    
    [self.myNavigationController pushViewController:updateIntervalPicker animated:YES];
    
    /*
    [tableViewAlertIntervalOption reloadData];
    [self showHideTableBack:YES];
    [viewContentContainer addSubview:viewAlertIntervalOption];
    
    //tableViewAlertIntervalOption.accessibilityElementsHidden = YES;
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
     */
}

- (IBAction)onClickAutoUpdateIndoorMap:(id)sender
{
    [self setAutoUpdateIndoorMap:![GlobalVar getAutoUpdateIndoorMap]];
}

- (void)setAutoUpdateIndoorMap:(BOOL)isOn
{
    [GlobalVar setAutoUpdateIndoorMap:isOn];
    if(isOn){
        [btnToggleAutoUpdateIndoorMap setTitle:@"前方" forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_red.png"] forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_red_highlighted.png"] forState:UIControlStateHighlighted];
    }else{
        [btnToggleAutoUpdateIndoorMap setTitle:@"所有方向" forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_green.png"] forState:UIControlStateNormal];
        [btnToggleAutoUpdateIndoorMap setBackgroundImage:[UIImage imageNamed:@"btn_general_b_green_highlighted.png"] forState:UIControlStateHighlighted];
    }
}

- (void)btnNavRight_Click:(id)sender
{
    [self onClickAboutUs:sender];
}

- (IBAction)onClickAboutUs:(id)sender
{
    if (informationViewController == nil) {
        informationViewController = [[InformationViewController alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
    }
    
    [self.myNavigationController pushViewController:informationViewController animated:YES];
}

- (IBAction)onClickMap:(id)sender
{
   if (mapManagementViewController == nil)
   {
       mapManagementViewController = [[MapManagment alloc]initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
   }
    [self.myNavigationController pushViewController:mapManagementViewController animated:YES];

}

@end
