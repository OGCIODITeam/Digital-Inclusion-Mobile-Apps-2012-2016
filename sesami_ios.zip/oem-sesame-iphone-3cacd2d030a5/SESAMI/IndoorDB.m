//
//  IndoorDB.m
//  SESAMI
//
//  Created by Ray.Liu on 9/18/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "IndoorDB.h"
#import "OEMMap.h"
#import "OEMFloorPlan.h"

@implementation IndoorDB

const char *dbpath_indoor;
sqlite3 *hkbuDB_indoor;

+ (void)initDB{
  NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *docsDir = [dirPaths objectAtIndex:0];
  
  //NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"hkbu.db"]];
  NSString *databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"indoormap.sqlite"]];//local path
  
  NSFileManager *filemgr = [NSFileManager defaultManager];
  
  if ([filemgr fileExistsAtPath: databasePath ] == NO)
  //if (YES)
  {
    NSLog(@"indoormap.sqlite not exist");
    
    NSString *databasePathInBundle = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"indoormap.sqlite"];
    NSLog(@"inbundle : %@",databasePathInBundle);
    NSLog(@"inlocal  : %@",databasePath);
    
    NSLog(@"moving file from bundle to local");
    [filemgr copyItemAtPath:databasePathInBundle toPath:databasePath error:nil];
    
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
    }else{
      dbpath_indoor = [databasePath UTF8String];
      sqlite3_open(dbpath_indoor, &hkbuDB_indoor);
      NSLog(@"db ready");
    }
    
    /*
     dbpath = [databasePath UTF8String];
     
     if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
     {
     
     char *errMsg;
     const char *sql_stmt = "CREATE TABLE IF NOT EXISTS FAVORITES (ID INTEGER PRIMARY KEY AUTOINCREMENT, FOREIGN_ID TEXT, SOURCE TEXT, NAME TEXT, LATITUDE REAL, LONGITUDE REAL, ADDRESS TEXT)";
     if (sqlite3_exec(hkbuDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
     {
     NSLog(@"failed to create table FAVORITES");
     }
     NSLog(@"success to create table FAVORITES");
     
     } else {
     NSLog(@"failed to open/create database");
     }
     */
  }else{
		dbpath_indoor = [databasePath UTF8String];
    sqlite3_open(dbpath_indoor, &hkbuDB_indoor);
  }
}

/////////////////////////////////////////////////
//Indoor Map
/////////////////////////////////////////////////
+ (NSArray *)getAllCategories
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
//  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name FROM IndoorMapCategories"];
  NSString *querySQL = [NSString stringWithFormat:@"select b.id, b.name from IndoorMaps a, IndoorMapCategories b where a.category_id = b.id group by a.category_id"];

  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int catID = sqlite3_column_int(statement, 0);
      NSString *catName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      
      OEMMap *map = [[OEMMap alloc] initWithCatID:catID Name:catName];
      [result addObject:map];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (NSArray *)getAllCategoriesByMapList:(NSString*)mapList
{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    sqlite3_stmt    *statement;
    //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
    //{
    //  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name FROM IndoorMapCategories"];
    NSString *querySQL = [NSString stringWithFormat:@"select b.id, b.name from IndoorMaps a, IndoorMapCategories b where a.category_id = b.id and a.id in (%@) group by a.category_id",mapList];
    
    const char *query_stmt = [querySQL UTF8String];
    
    if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
    {
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            int catID = sqlite3_column_int(statement, 0);
            NSString *catName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
            
            OEMMap *map = [[OEMMap alloc] initWithCatID:catID Name:catName];
            [result addObject:map];
            
        }
        sqlite3_finalize(statement);
    }
    //}
    if([result count]==0)result=nil;
    
    return result;
}

+ (NSArray *)getAllIndoorMapsWithCatIDDownloaded:(int)catID:(NSString *)mapList
{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    sqlite3_stmt    *statement;
    //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
    //{
    NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name, address, description, category_id, district_id FROM IndoorMaps where category_id = %i and id in (%@)", catID, mapList ];
    
    const char *query_stmt = [querySQL UTF8String];
    
    if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
    {
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            int mapID = sqlite3_column_int(statement, 0);
            NSString *mapName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
            NSString *mapAddress = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
            NSString *mapDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
            int catID = sqlite3_column_int(statement, 4);
            int disID = sqlite3_column_int(statement, 5);
            
            OEMMap *map = [[OEMMap alloc] initWithMapID:mapID Name:mapName Address:mapAddress Description:mapDescription CatID:catID DisID:disID];
            [result addObject:map];
            
        }
        sqlite3_finalize(statement);
    }
    //}
    if([result count]==0)result=nil;
    
    return result;
}

+ (NSArray *)getAllIndoorMaps
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name, address, description, category_id, district_id FROM IndoorMaps"];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int mapID = sqlite3_column_int(statement, 0);
      NSString *mapName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSString *mapAddress = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
      NSString *mapDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
      int catID = sqlite3_column_int(statement, 4);
      int disID = sqlite3_column_int(statement, 5);
      
        OEMMap *map = [[OEMMap alloc] initWithMapID:mapID Name:mapName Address:mapAddress Description:mapDescription CatID:catID DisID:disID];
      [result addObject:map];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (NSArray *)getAllIndoorMapsWithCatID: (int)catID: (NSString*)mapList
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name, address, description, category_id, district_id FROM IndoorMaps where category_id = %i ", catID];
    
    if (![mapList isEqualToString:@""] && mapList != Nil)
    {
        querySQL = [NSString stringWithFormat:@"%@ and id not in(%@)",querySQL,mapList];
    }
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int mapID = sqlite3_column_int(statement, 0);
      NSString *mapName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSString *mapAddress = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
      NSString *mapDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
      int catID = sqlite3_column_int(statement, 4);
      int disID = sqlite3_column_int(statement, 5);
      
      OEMMap *map = [[OEMMap alloc] initWithMapID:mapID Name:mapName Address:mapAddress Description:mapDescription CatID:catID DisID:disID];
      [result addObject:map];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (NSArray *)getAllFloorPlanWithMapID:(int)mapID
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, label, description, level, image, data FROM IndoorMapFloorPlans WHERE parent_id = %i ", mapID];
  
  NSLog(@"%@", querySQL);
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int floorPlanID = sqlite3_column_int(statement, 0);
      NSString *floorPlanName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      NSString *floorDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
      int floorPlanLevel = sqlite3_column_int(statement, 3);
      NSString *floorPlanImage = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
      NSString *floorPlanData = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 5)];
      
      NSArray *floorPlanDataLabel = [self getAllDataLabelWithFloorPlanID:floorPlanID];
      
      OEMFloorPlan *floorPlan = [[OEMFloorPlan alloc] initWithFloorPlanID:floorPlanID Name:floorPlanName Description:floorDescription Level:floorPlanLevel Image:floorPlanImage Data:floorPlanData DataLabel:floorPlanDataLabel];
      
      [result addObject:floorPlan];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return result;
}

+ (NSArray *)getAllFloorPlanWithMapIDs:(NSString *)mapIDs
{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    sqlite3_stmt    *statement;
    //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
    //{
    NSString *querySQL = [NSString stringWithFormat:@"SELECT id, label, description, level, image, data FROM IndoorMapFloorPlans WHERE parent_id in ( %@ )", mapIDs];
    
    NSLog(@"%@", querySQL);
    
    const char *query_stmt = [querySQL UTF8String];
    
    if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
    {
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            int floorPlanID = sqlite3_column_int(statement, 0);
            NSString *floorPlanName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
            NSString *floorDescription = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
            int floorPlanLevel = sqlite3_column_int(statement, 3);
            NSString *floorPlanImage = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
            NSString *floorPlanData = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 5)];
            
            NSArray *floorPlanDataLabel = [self getAllDataLabelWithFloorPlanID:floorPlanID];
            
            OEMFloorPlan *floorPlan = [[OEMFloorPlan alloc] initWithFloorPlanID:floorPlanID Name:floorPlanName Description:floorDescription Level:floorPlanLevel Image:floorPlanImage Data:floorPlanData DataLabel:floorPlanDataLabel];
            
            [result addObject:floorPlan];
            
        }
        sqlite3_finalize(statement);
    }
    //}
    if([result count]==0)result=nil;
    
    return result;
}

+ (NSArray *)getAllDataLabelWithFloorPlanID:(int)floorPlanID
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT id, name FROM IndoorMapFloorPlanLabels WHERE parent_id = %i ", floorPlanID];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      int labelID = sqlite3_column_int(statement, 0);
      NSString *labelName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
      
      NSMutableDictionary *label = [[NSMutableDictionary alloc] init];
      [label setValue:[NSString stringWithFormat:@"%i",labelID] forKey:@"labelID"];
      [label setValue:labelName forKey:@"labelName"];
      
      [result addObject:label];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  NSLog(@"Get la %@", result);
  return result;
}

+ (NSString *)getTextWithDataLabelID:(int)dataLabelID
{
  NSMutableArray *result = [[NSMutableArray alloc] init];
  sqlite3_stmt    *statement;
  //if (sqlite3_open(dbpath, &hkbuDB) == SQLITE_OK)
  //{
  NSString *querySQL = [NSString stringWithFormat:@"SELECT name FROM IndoorMapFloorPlanLabels WHERE AND id = %i ", dataLabelID];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(hkbuDB_indoor, query_stmt, -1, &statement, NULL) == SQLITE_OK)
  {
    while (sqlite3_step(statement) == SQLITE_ROW)
    {
      NSString *labelName = [NSString stringWithUTF8String:(const char *)sqlite3_column_text(statement, 0)];
      
      [result addObject:labelName];
      
    }
    sqlite3_finalize(statement);
  }
  //}
  if([result count]==0)result=nil;
  
  return [result objectAtIndex:0];
}

@end
