//
//  LocationDetailViewController.m
//  SESAMI
//
//  Created by Daniel Lee on 12/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "LocationDetailViewController.h"
#import "OEMLocation.h"

@interface LocationDetailViewController ()

@end

@implementation LocationDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithLocation:(OEMLocation *)defaultLocation{
    
    if((self = [super init])){
        location = defaultLocation;
    }
    
    
    return self;
}
- (void)initView{
    isFavorited = [OEMDB isFavorited:location];
    if (isFavorited) {
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_remove_favor.png"] forState:UIControlStateNormal];
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_remove_favor_highligthed.png"] forState:UIControlStateHighlighted];
        btnFavorite.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtonRemoveFavorVO],location.getDisplayName];
        
        if([location getLocationID]==-1){
            [location setLocationID:[OEMDB getIDFromOEMLocation:location]];
        }
    }else{
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_add_favor.png"] forState:UIControlStateNormal];
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_add_favor_highlighted.png"] forState:UIControlStateHighlighted];
        btnFavorite.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtonAddFavorVO],location.getDisplayName];
    }

    btnHowFar.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtoHowFarVO],location.getDisplayName];
    btnNearby.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtoNearbyVO],location.getDisplayName];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    btnFavorite = nil;
    btnHowFar = nil;
    btnNearby = nil;
    [super viewDidUnload];
}
- (IBAction)onClickHowFar:(id)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getDirectShowViewHowFarCallBackName] object:location];
}

- (IBAction)onClickNearby:(id)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getDirectShowViewNearbyCallBackName] object:location];
}

- (IBAction)onClickFavorite:(id)sender {
    if(isFavorited){
        [OEMDB removeFavorite:[location getLocationID]];
    }else{
        [location setLocationIDWithInt:[OEMDB addFavorite:location]];
    }
    [self initView];
}
@end
