//
//  VirtualWalkViewController.m
//  SESAMI
//
//  Created by Daniel Lee on 6/8/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "VirtualWalkViewController.h"
#import "LocationResultTableViewController.h"
#import "ExternalDataLoader.h"

@interface VirtualWalkViewController ()

@end

@implementation VirtualWalkViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initView];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    txtStreetName = nil;
    txtStreetNumber = nil;
    btnStart = nil;
    lblReturnedBuildingName = nil;
    btnStreetNumMinus2 = nil;
    btnStreetNumMinus1 = nil;
    btnStreetNumAdd1 = nil;
    btnStreetNumAdd2 = nil;
    viewStreetNumControllersContainer = nil;
    tableViewResult = nil;
    viewResult = nil;
    lblErrorMessage = nil;
    [super viewDidUnload];
}
/////////////////////////////
- (void)initView{
    [btnStreetNumAdd1 setEnabled:NO];
    [btnStreetNumAdd2 setEnabled:NO];
    [btnStreetNumMinus1 setEnabled:NO];
    [btnStreetNumMinus2 setEnabled:NO];
    
    viewStreetNumControllersContainer.accessibilityElementsHidden = YES;
    
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);    
}
/////////////////////////////
- (IBAction)onClickStart:(id)sender {
    if([txtStreetName.text isEqualToString:@""] || [txtStreetNumber.text isEqualToString:@""]){
        [AppFunction quickAlertWithMessage:[AppMessage errorEmptyStreetNameOrNumber] title:nil];
    }else{
        [self demo];
        [self startRequest];
        //[self demo];
    }
}
- (IBAction)onClickMinus2:(id)sender {
    if([txtStreetNumber.text intValue]<=2){
        [AppFunction quickAlertWithMessage:[AppMessage errorNegativeStreetNumber] title:nil];
    }else{
        txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]-2)];
        [self demo];
        [self startRequest];
    }
}
- (IBAction)onClickMinus1:(id)sender {
    if([txtStreetNumber.text intValue]<=1){
        [AppFunction quickAlertWithMessage:[AppMessage errorNegativeStreetNumber] title:nil];
    }else{
        txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]-1)];
        [self demo];
        [self startRequest];
    }
}
- (IBAction)onClickAdd1:(id)sender {
    txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]+1)];
    [self demo];
    [self startRequest];
}
- (IBAction)onClickAdd2:(id)sender {
    txtStreetNumber.text = [NSString stringWithFormat:@"%d",([txtStreetNumber.text intValue]+2)];
    [self demo];
    [self startRequest];
}

///////////////////////////////////////////////
- (void)startRequest{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    if(externalDataLoader==nil)
        externalDataLoader = [[ExternalDataLoader alloc] init];
    [externalDataLoader centaMapGetBuildingByStreetName:[txtStreetName text] StreetNumber:[txtStreetNumber.text intValue]];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
}
- (void)onExternalDataReturn:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    [lblErrorMessage removeFromSuperview];
    
    if([notification.object isKindOfClass:[NSError class]]){
        tableViewResult.hidden = YES;
        [lblErrorMessage setText:[AppMessage getServerDownMSG]];
        
        [viewResult addSubview:lblErrorMessage];
    }else{
        NSDictionary *json = (NSDictionary *)notification.object;
        if ([json count]==0) {
            tableViewResult.hidden = YES;
            [viewResult addSubview:lblErrorMessage];
            [lblErrorMessage setText:[AppMessage getNoResultMSG]];
            return;
        }
        
        NSLog(@"json : %@",json);
        
        CLLocation *cLocation = [GlobalVar getCurrentLocation];
        tableViewResult.hidden = NO;
        //notification.object saved the array of researched location
        //put create OEMLocation for all locations and push into arrayLocation
        NSMutableArray *arrayLocationForSort = [[NSMutableArray alloc] init];
        NSMutableArray *arrayLocation = [[NSMutableArray alloc] init];
        
        for(NSDictionary *node in (NSArray *)[json objectForKey:@"Table"]){
            CLLocation *nLocation = [[CLLocation alloc] initWithLatitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"]doubleValue]];
            
            OEMLocation *location = [[OEMLocation alloc] initWithName:[node objectForKey:@"displayname"] latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:[node objectForKey:@"displayaddr"]];
            
            NSArray *arrNode = [[NSArray alloc] initWithObjects:[NSNumber numberWithDouble:[nLocation distanceFromLocation:cLocation]], location, nil];
            [arrayLocationForSort addObject:arrNode];
        }
        
        NSArray *arrayLocationSorted = [arrayLocationForSort sortedArrayUsingComparator:^(id a, id b){
            return [[a objectAtIndex:0] compare:[b objectAtIndex:0]];
        }];
        
        for(NSArray *node in arrayLocationSorted){
            [arrayLocation addObject:[node objectAtIndex:1]];
        }
        
        
        //start listen to the click event and the click disclosure of the row in the result tableView
        /*
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResultDisclosure:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        */
        
        if(tvcLocationResult == nil)
            tvcLocationResult = [[LocationResultTableViewController alloc] initWithData:arrayLocation];
        else
            [tvcLocationResult setData:arrayLocation];
        
        [tvcLocationResult disableDisclosureButton:YES];
        [tableViewResult setDataSource:tvcLocationResult];
        [tableViewResult setDelegate:tvcLocationResult];
        tvcLocationResult.tableView = tableViewResult;
        
        [tableViewResult reloadData];
    }
}
- (void)demo{
    [btnStreetNumAdd1 setEnabled:YES];
    [btnStreetNumAdd2 setEnabled:YES];
    [btnStreetNumMinus1 setEnabled:YES];
    [btnStreetNumMinus2 setEnabled:YES];
    
    viewStreetNumControllersContainer.accessibilityElementsHidden = NO;
    
    [lblReturnedBuildingName setText:@"快樂大廈"];
    [txtStreetName resignFirstResponder];
    [txtStreetNumber resignFirstResponder];
    
    UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, lblReturnedBuildingName.text);
}
/////////////////////////////
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if([textField isEqual:txtStreetNumber]){
        NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        return ([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0) || [string isEqualToString:@""];
    }
    return YES;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtStreetName resignFirstResponder];
    [txtStreetNumber resignFirstResponder];
}
- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
    if(theTextField==txtStreetName){
        [txtStreetNumber becomeFirstResponder];
    }
    if(theTextField==txtStreetNumber){
        [btnStart becomeFirstResponder];
        [txtStreetName resignFirstResponder];
        [txtStreetNumber resignFirstResponder];
    }
    return YES;
}
@end
