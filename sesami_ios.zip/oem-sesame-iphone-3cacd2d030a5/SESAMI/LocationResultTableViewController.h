//
//  LocationResultTableViewController.h
//  SESAMI
//
//  Created by Daniel Lee on 9/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationResultTableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate>{
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
}

-(id)initWithData:(NSArray *)data;
-(void)setData:(NSArray *)data;
-(void)disableDisclosureButton:(BOOL)isDisable;
@end
