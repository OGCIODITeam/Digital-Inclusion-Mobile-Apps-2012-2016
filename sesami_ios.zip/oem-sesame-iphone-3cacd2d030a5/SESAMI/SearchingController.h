//
//  SearchingController.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationResultTableViewController.h"
#import "SearchingResult.h"

@interface SearchingController : BaseViewController
{
    __weak IBOutlet UITextField *txtSearchText;
    __weak IBOutlet UIButton *btnSearch;
    
    LocationResultTableViewController *tvcLocationResult;
    
    SearchingResult *searchingResult;
}

- (IBAction)onClickStartSearch:(id)sender;

@end
