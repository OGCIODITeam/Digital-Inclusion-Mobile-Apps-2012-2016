//
//  BaseViewController.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

@synthesize myNavigationController;
@synthesize myParentViewController;
@synthesize myExtraData;

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
    self = [super initWithNibName:nil bundle:nil];
    if (self)
    {
        myNavigationController = navigationController;
        myParentViewController = controller;
        myExtraData = data;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor darkGrayColor]];
    [self initAccessiblity];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self startRefreshTimer];
    for (int i=0; i<[myNavigationController.viewControllers count];i++)
    {
        UIViewController *tempViewController = [myNavigationController.viewControllers objectAtIndex:i];
        [tempViewController.view setFrame:[AppConstant getContentViewFrame]];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self stopRefreshTimer];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (NSString *)getMySection
{
    if (self.myExtraData != nil && [self.myExtraData objectForKey:@"mySection"] != nil)
    {
        return [self.myExtraData objectForKey:@"mySection"];
    }

    return @"";
}

- (void)initAccessiblity
{
    
}

- (void)startRefreshTimer
{
    if(refreshTimer == nil)
    {
        refreshTimer = [NSTimer scheduledTimerWithTimeInterval:[GlobalVar getAlertInterval]
                                                        target:self
                                                        selector:@selector(refreshAction)
                                                        userInfo:nil
                                                        repeats:YES];
    }
}

- (void)stopRefreshTimer
{
    [refreshTimer invalidate];
    refreshTimer = nil;
}

- (void)refreshAction
{
    //NSLog(@"refresh...");
}

#pragma mark - MainNavigation

- (void)btnNavLeft_Click:(id)sender
{
    [self.view endEditing:TRUE];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)btnNavRight_Click:(id)sender
{
    [self.navigationController popToRootViewControllerAnimated:NO];
}

- (void)btnMainMenu_Click:(id)sender
{
    NSLog(@"pressing title");
}


@end
