//
//  UpdateIntervalPicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "UpdateIntervalPicker.h"

@implementation UpdateIntervalPicker

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrayAlertIntervalItems = [[NSArray alloc] initWithObjects:@"5秒",@"15秒",@"30秒",@"1分鐘",@"5分鐘",@"15分鐘", nil];
    arrayAlertIntervalItemsValue = [[NSArray alloc] initWithObjects:@"5",@"15",@"30",@"60",@"300",@"900", nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"設定";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

#pragma mark - UITableView

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [GlobalVar setAlertInterval:[[arrayAlertIntervalItemsValue objectAtIndex:indexPath.row] intValue]];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayAlertIntervalItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    //cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    
    // Configure the cell...
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 60;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    
    cell.textLabel.text = [arrayAlertIntervalItems objectAtIndex:indexPath.row];
        
    if([GlobalVar getAlertInterval] == [[arrayAlertIntervalItemsValue objectAtIndex:indexPath.row] intValue])
    {
        [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    }
    
    return cell;
}

@end
