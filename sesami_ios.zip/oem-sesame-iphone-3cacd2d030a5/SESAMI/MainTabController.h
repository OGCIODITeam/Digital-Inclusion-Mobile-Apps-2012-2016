//
//  MainTabController.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainTabViewController.h"
#import "PositionViewIndex.h"
#import "IndoorMapViewIndex.h"
#import "IndoorMapCategoryViewIndex.h"
#import "FavoriteViewIndex.h"
#import "VirtualWalkViewIndex.h"
#import "SettingViewIndex.h"

@interface MainTabController : UIViewController <UITabBarControllerDelegate, CLLocationManagerDelegate>
{
    IBOutlet UIView *viewLoading;
    
    IBOutlet UITabBarController *tabBarController;
    IBOutlet UITabBarItem *tabBarItem1;
    IBOutlet UITabBarItem *tabBarItem2;
    IBOutlet UITabBarItem *tabBarItem3;
    IBOutlet UITabBarItem *tabBarItem4;
    IBOutlet UITabBarItem *tabBarItem5;
    IBOutlet UIView *fakeTabBar;
    IBOutlet UIButton *fakeTabBarItem1;
    IBOutlet UIButton *fakeTabBarItem2;
    IBOutlet UIButton *fakeTabBarItem3;
    IBOutlet UIButton *fakeTabBarItem4;
    IBOutlet UIButton *fakeTabBarItem5;
    
    int currentTabIndex;
    
    CLLocationManager *locationManager;
}

@property (strong, nonatomic) IBOutlet MainTabViewController *tab1ViewController;
@property (strong, nonatomic) IBOutlet MainTabViewController *tab2ViewController;
@property (strong, nonatomic) IBOutlet MainTabViewController *tab3ViewController;
@property (strong, nonatomic) IBOutlet MainTabViewController *tab4ViewController;
@property (strong, nonatomic) IBOutlet MainTabViewController *tab5ViewController;

- (IBAction)fakeTabBarItem_Click:(id)sender;
- (void)setTab:(int)index;
- (void) getLocation;

@end
