//
//  LocationDetailViewController.h
//  SESAMI
//
//  Created by Daniel Lee on 12/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "ViewController.h"
@class OEMLocation;

@interface LocationDetailViewController : ViewController{
    
    __weak IBOutlet UIButton *btnHowFar;
    __weak IBOutlet UIButton *btnNearby;
    __weak IBOutlet UIButton *btnFavorite;
    
    BOOL isFavorited;
    OEMLocation *location;
}

- (id)initWithLocation:(OEMLocation *)location;

- (IBAction)onClickHowFar:(id)sender;
- (IBAction)onClickNearby:(id)sender;
- (IBAction)onClickFavorite:(id)sender;
@end
