//
//  FavoriteViewController.h
//  SESAMI
//
//  Created by Daniel Lee on 9/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LocationResultTableViewController;
@class LocationDetailViewController;

@interface FavoriteViewController : UIViewController{
    __weak IBOutlet UIView *viewContentContainer;
    __weak IBOutlet UIButton *btnTableBack;
    __weak IBOutlet UILabel *lblTableTitle;
    
    IBOutlet UIView *viewFavorite;
    __weak IBOutlet UITableView *tableViewFavorite;
    
    NSArray *arrayFavorite;
    
    LocationResultTableViewController *tvcLocationResult;
    LocationDetailViewController *locationDetailViewController;
}
- (IBAction)onClickTableBack:(id)sender;
@end
