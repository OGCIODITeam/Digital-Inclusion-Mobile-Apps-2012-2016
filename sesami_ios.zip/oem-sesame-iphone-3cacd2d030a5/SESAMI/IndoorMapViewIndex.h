//
//  IndoorMapViewIndex.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FloorPlanListingResult.h"
#import "ExternalDataLoader.h"
#import "MapManagment.h"

@interface IndoorMapViewIndex : BaseViewController <UITableViewDataSource, UITableViewDelegate, NSURLConnectionDelegate>
{
    IBOutlet NSUserDefaults *prefs;
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
    
    FloorPlanListingResult *floorPlanListingResult;
    
    ExternalDataLoader *externalDataLoader;
    
    NSString *currentCallStatus;
    MapManagment *mapManagementViewController;
    
    //download zip
	NSMutableData *responseData;
	BOOL _isCompleted;
	float _totalFileSize;
	float _receivedFileSize;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewIndoor;

-(void)setData:(NSArray *)data;
-(void)disableDisclosureButton:(BOOL)isDisable;

- (void)requestCreateZip;
- (void)requestDownloadZip;
- (void)download;
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;

@end
