//
//  NearByMeTypePicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "NearByMeTypePicker.h"

@implementation NearByMeTypePicker

#define NEARBY_CATEGORY_ALL 5000
#define NEARBY_CATEGORY_BUILDING 5001
#define NEARBY_CATEGORY_BUS_STOP 5002
#define NEARBY_CATEGORY_RESTAURANT 5003
#define NEARBY_CATEGORY_LANDMARK 5004

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
  self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
  if (self)
  {
    locationStart = (OEMLocation *)[self.myExtraData objectForKey:@"locationStart"];
    locationEnd = (OEMLocation *)[self.myExtraData objectForKey:@"locationEnd"];
  }
  return self;
}

- (void)viewDidLoad
{
  [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
  [super viewWillAppear:animated];
  
  if ([[self getMySection] isEqualToString:@"Tab1_WhereAmI"])
  {
    self.title = @"分類選單";
  }
  else if ([[self getMySection] isEqualToString:@"Tab1_NearBy"])
  {
    self.title = @"終點分類選單";
  }
  else
  {
    self.title = @"分類選單";
  }
  
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:YES LeftTitle:@""
   ShowRight:NO RightTitle:@""];
}

- (void)initAccessiblity
{
  [btnNearbyBuilding setAccessibilityLabel:@"建築物"];
  [btnNearbyBusStop setAccessibilityLabel:@"巴士站"];
  [btnNearbyRestaurant setAccessibilityLabel:@"餐廳"];
  [btnNearbyLandmark setAccessibilityLabel:@"地標"];
  [btnNearbyAll setAccessibilityLabel:@"所有"];
}

- (IBAction)onClickNearbyBuilding:(id)sender
{
  [self loadResultWithCategotyID:NEARBY_CATEGORY_BUILDING];
}

- (IBAction)onClickNearbyBusStop:(id)sender
{
  [self loadResultWithCategotyID:NEARBY_CATEGORY_BUS_STOP];
}

- (IBAction)onClickNearbyRestaurant:(id)sender
{
  [self loadResultWithCategotyID:NEARBY_CATEGORY_RESTAURANT];
}

- (IBAction)onClickNearbyLandmark:(id)sender
{
  [self loadResultWithCategotyID:NEARBY_CATEGORY_LANDMARK];
}

- (IBAction)onClickNearbyAll:(id)sender
{
  [self loadResultWithCategotyID:NEARBY_CATEGORY_ALL];
}

- (void)loadResultWithCategotyID:(int)catID
{
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] initWithDictionary:self.myExtraData];
  
  [extraData setValue:[NSString stringWithFormat:@"%i",catID] forKey:@"catID"];
  
  nearbyMeResult = [[NearByMeResult alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:nearbyMeResult animated:YES];
}

@end
