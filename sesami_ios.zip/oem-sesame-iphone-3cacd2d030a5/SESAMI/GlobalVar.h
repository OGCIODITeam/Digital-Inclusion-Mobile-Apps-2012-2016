//
//  GlobalVar.h
//  SESAMI
//
//  Created by Daniel Lee on 18/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
@interface GlobalVar : NSObject
+(void)setCurrentLocation:(CLLocation *)cl;
+(CLLocation *)getCurrentLocation;

+(void)setCurrentCompassHeading:(double)c;
+(double)getCurrentCompassHeading;

+(void)setCurrentFunction:(NSString *)func;
+(NSString *)getCurrentFunction;

//for setting
+(void)setNearByBuildingDisplayTotal:(int)n;
+(void)setAlertInterval:(int)n;
+(void)setAutoUpdateIndoorMap:(BOOL)isSet;
+(int)getNearByBuildingDisplayTotal;
+(int)getAlertInterval;
+(BOOL)getAutoUpdateIndoorMap;

+(void)setIndoorMapVersion:(NSString *)mapVersion;
+(NSString *)getIndoorMapVersion;

@end
