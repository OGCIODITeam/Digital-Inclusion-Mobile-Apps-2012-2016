//
//  LocationPickerViewController.m
//  semami
//
//  Created by Daniel Lee on 26/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "LocationPickerViewController.h"
#import "MTRLinesTableViewController.h"
#import "AppConstant.h"
#import "LocationResultTableViewController.h"
#import "ExternalDataLoader.h"
#import "LocationDetailViewController.h"

//#define VIEW_FAVORITE_ID 2001
//#define VIEW_SEARCH_INPUT_ID 2002
//#define VIEW_SEARCH_RESULT_ID 2003

//#define EVENT_NAME_NOTIFY @"LOCATION_PICKER_CALL_BACK"

@interface LocationPickerViewController ()

@end

@implementation LocationPickerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [viewContentContainer addSubview:viewSelector];
    isShowingFavorite = NO;
    isShowLocationDetail = NO;
    
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//////////////////////////
- (IBAction)onClickTableBack:(id)sender {
    if(isShowingFavorite){
        arrayFavorite = nil;
        tvcLocationResult = nil;
        [viewFavorite removeFromSuperview];
        [tvcLocationResult setData:[[NSArray alloc] init]];
        [tvcLocationResult.tableView reloadData];
        isShowingFavorite = NO;
        [self disableAccessiblityForSelectorView:NO];
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
        return;
    }
    
    if([tvcMTRLines previousList]){
        //pop out MTR subview
    }else{
        if(tvcMTRLines!=nil) {
            //pop out MTR view
            tvcMTRLines=nil;
            [viewMTRLines removeFromSuperview];
            [viewContentContainer addSubview:viewSelector];
        }else{
            if([arrayTableTitleStack count]>0){
                //pop up custom search
                [self unLoadViewFromBaseView:viewContentContainer andDisplayLastView:[dictContentStack objectForKey:[arrayTableTitleStack objectAtIndex:[arrayTableTitleStack count]-1]]];
                //update stacks
                [dictContentStack removeObjectForKey:[arrayTableTitleStack objectAtIndex:[arrayTableTitleStack count]-1]];
                [arrayTableTitleStack removeLastObject];
                
                if(isShowLocationDetail){
                    isShowLocationDetail=NO;
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResultDisclosure:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
                    locationDetailViewController = nil;
                }else{
                    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
                }
            }else{
                //pop up this view
                [self notifyCancel];
            }
        }
    }
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
}
- (void)loadSubView:(UIView *)subView toView:(UIView *)baseView withTitle:(NSString *)title{
    //stack the current title
    if(arrayTableTitleStack == nil)
        arrayTableTitleStack = [[NSMutableArray alloc] init];
    [arrayTableTitleStack addObject:title];
    
    //stack the current view with current title as key
    if(dictContentStack == nil)
        dictContentStack = [[NSMutableDictionary alloc] init];
    [dictContentStack setObject:[[baseView subviews] objectAtIndex:[[baseView subviews] count]-1] forKey:title];
    
    UIView *lastView = [[baseView subviews] objectAtIndex:[[baseView subviews] count]-1];
    
    //add the new subview
    CGRect frame = subView.frame;
    frame.origin.x = frame.size.width;
    frame.origin.y = 0;
    subView.frame = frame;
    [baseView addSubview:subView];
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        CGRect frame = subView.frame;
        frame.origin.x = 0;
        subView.frame=frame;
    } completion:^(BOOL finished){
        //remove the last current view
        [lastView removeFromSuperview];
        isViewTransiting = NO;
        NSLog(@"x");
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    }];
    
}
- (void)unLoadViewFromBaseView:(UIView *)baseView andDisplayLastView:(UIView *)lastView{
    UIView *currentView = [[baseView subviews] objectAtIndex:[[baseView subviews] count]-1];
    
    //add the last View back to baseView
    CGRect frame = lastView.frame;
    frame.origin.x = frame.size.width;
    lastView.frame=frame;
    
    [baseView addSubview:lastView];
    [baseView bringSubviewToFront:currentView];
    
    frame.origin.x=0;
    lastView.frame=frame;
    
    //move out the current view
    [UIView animateWithDuration:[AppConstant getAnimationDuration] animations:^(void){
        CGRect frame = currentView.frame;
        frame.origin.x = frame.size.width;
        currentView.frame=frame;
    } completion:^(BOOL completed){
        //remove the current
        [currentView removeFromSuperview];
        isViewTransiting = NO;
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    }];
    
}
//////////////////////////
- (IBAction)onClickCurrentLocation:(id)sender {
    OEMLocation *currentLocation = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
    [self notifySelectedLocation:currentLocation];
}
- (IBAction)onClickMyFavorite:(id)sender {
    arrayFavorite = [[NSArray alloc] initWithArray:[OEMDB getAllFavoriteLocations]];
    tvcLocationResult = [[LocationResultTableViewController alloc] initWithData:arrayFavorite];
    [tvcLocationResult disableDisclosureButton:YES];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
    [tableViewFavorite setDataSource:tvcLocationResult];
    [tableViewFavorite setDelegate:tvcLocationResult];
    [viewContentContainer addSubview:viewFavorite];
    tvcLocationResult.tableView = tableViewFavorite;
    
    //[lblTableTitle setText:@"我的最愛"];
    [tableViewFavorite reloadData];
    isShowingFavorite = YES;
    [self disableAccessiblityForSelectorView:YES];    
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

- (IBAction)onClickMTR:(id)sender {
    if(tvcMTRLines==nil)
        tvcMTRLines = [[MTRLinesTableViewController alloc] init];
    [tvcMTRLines initData];
    [tableViewMTRLines setDataSource:tvcMTRLines];
    [tableViewMTRLines setDelegate:tvcMTRLines];
    
    [viewSelector removeFromSuperview];
    [viewContentContainer addSubview:viewMTRLines];
    //[self loadSubView:viewMTRLines toView:viewContentContainer withTitle:[(UIButton *)sender titleLabel].text];
    
    tvcMTRLines.tableView = tableViewMTRLines;
    [tableViewMTRLines reloadData];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);

}
- (IBAction)onClickSearch:(id)sender {
    [self loadSubView:viewSearchInput toView:viewContentContainer withTitle:[(UIButton *)sender titleLabel].text];
}
- (IBAction)onClickStartSearch:(id)sender {
    if([txtSearchText.text isEqualToString:@""]){
        [AppFunction quickAlertWithMessage:[AppMessage errorEmptyKeyword] title:@""];
        return;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    if(externalDataLoader==nil)
        externalDataLoader = [[ExternalDataLoader alloc] init];
    [externalDataLoader centaMapSearchBuildingWithKeyword:txtSearchText.text];
    [self loadResultViewWithTitle:@"搜尋結果"];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
    viewSelector.accessibilityElementsHidden = YES;
    
}
//////////////////////////
-(void)notifySelectedLocation:(OEMLocation *)location{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:location];
}
-(void)notifyCancel{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
}
- (void)onClickResult:(NSNotification *)notification{
    if(notification.object!=nil){
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:notification.object];
    }
}
- (void)onExternalDataReturn:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
    
    if([notification.object isKindOfClass:[NSError class]]){
        tableViewSearchResult.hidden = YES;
        [lblTableViewMessage setText:[AppMessage getServerDownMSG]];
    }else{
        NSDictionary *json = (NSDictionary *)notification.object;
        if ([json count]==0) {
            tableViewSearchResult.hidden = YES;
            [lblTableViewMessage setText:[AppMessage getNoResultMSG]];
            return;
        }
        
        CLLocation *cLocation = [GlobalVar getCurrentLocation];
        tableViewSearchResult.hidden = NO;
        //notification.object saved the array of researched location
        //put create OEMLocation for all locations and push into arrayLocation
        NSMutableArray *arrayLocationForSort = [[NSMutableArray alloc] init];
        NSMutableArray *arrayLocation = [[NSMutableArray alloc] init];
        
        for(NSDictionary *node in (NSArray *)[json objectForKey:@"Table"]){
            CLLocation *nLocation = [[CLLocation alloc] initWithLatitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"]doubleValue]];
            
            OEMLocation *location = [[OEMLocation alloc] initWithName:[node objectForKey:@"displayname"] latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:[node objectForKey:@"displayaddr"]];
            
            NSArray *arrNode = [[NSArray alloc] initWithObjects:[NSNumber numberWithDouble:[nLocation distanceFromLocation:cLocation]], location, nil];
            [arrayLocationForSort addObject:arrNode];
        }
        
        NSArray *arrayLocationSorted = [arrayLocationForSort sortedArrayUsingComparator:^(id a, id b){
            return [[a objectAtIndex:0] compare:[b objectAtIndex:0]];
        }];
        
        for(NSArray *node in arrayLocationSorted){
            [arrayLocation addObject:[node objectAtIndex:1]];
        }

        
        //start listen to the click event and the click disclosure of the row in the result tableView
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResult:) name:[AppConstant getClickResultCallBackName] object:nil];
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onClickResultDisclosure:) name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
        
        if(tvcLocationResult == nil)
            tvcLocationResult = [[LocationResultTableViewController alloc] initWithData:arrayLocation];
        else
            [tvcLocationResult setData:arrayLocation];
        [tvcLocationResult disableDisclosureButton:NO];
        [tableViewSearchResult setDataSource:tvcLocationResult];
        [tableViewSearchResult setDelegate:tvcLocationResult];
        tvcLocationResult.tableView = tableViewSearchResult;
        [tableViewSearchResult reloadData];
    }
}
- (void)onClickResultDisclosure:(NSNotification *)notification{
    if(notification.object!=nil){
        if(locationDetailViewController==nil)
            locationDetailViewController = [[LocationDetailViewController alloc] initWithLocation:((OEMLocation *)notification.object)];
        //[self showHideLocationDetail:YES];
        [self loadSubView:locationDetailViewController.view toView:viewContentContainer withTitle:[lblTableTitle text]];
        [lblTableTitle setText:@"選項"];
        isShowLocationDetail = YES;
        [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultDisclosureCallBackName] object:nil];
    }
}

- (void)disableAccessiblityForSelectorView:(BOOL)isDisable{
    btnSelectorCurrentLocation.accessibilityElementsHidden = isDisable;
    btnSelectorFavorite.accessibilityElementsHidden = isDisable;
    btnSelectorMTR.accessibilityElementsHidden = isDisable;
    btnSelectorSearch.accessibilityElementsHidden = isDisable;
}
/////////////////////////
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtSearchText resignFirstResponder];
}
//////////////////////////
- (void)loadResultViewWithTitle:(NSString *)title{
    [self loadSubView:viewSearchResult toView:viewContentContainer withTitle:[lblTableTitle text]];
    [lblTableTitle setText:title];
}
//////////////////////////
- (void)viewDidUnload {
    viewContentContainer = nil;
    viewSelector = nil;
    viewMTRLines = nil;
    tableViewMTRLines = nil;
    viewFavorite = nil;
    tableViewFavorite = nil;
    viewSearchInput = nil;
    txtSearchText = nil;
    btnSearch = nil;
    viewSearchResult = nil;
    tableViewSearchResult = nil;
    lblTableTitle = nil;
    lblTableViewMessage = nil;
    btnSelectorCurrentLocation = nil;
    btnSelectorFavorite = nil;
    btnSelectorMTR = nil;
    btnSelectorSearch = nil;
    [super viewDidUnload];
}
@end
