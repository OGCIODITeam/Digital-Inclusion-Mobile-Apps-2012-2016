//
//  HowFarCalculator.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "HowFarCalculator.h"

@implementation HowFarCalculator

- (void)viewDidLoad
{
  [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = @"有多遠";
  
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:YES LeftTitle:@""
   ShowRight:NO RightTitle:@""];

  // Set default starting location to where the user currently is
  if (locationStart == nil) {
    locationStart = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
    [btnSelectStartingLocaiton setTitle:[NSString stringWithFormat:@"由:現在的地方"] forState:UIControlStateNormal];
  }
}

- (void)viewWillDisappear:(BOOL)animated
{
  [super viewWillDisappear:animated];
  //[[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
}

- (IBAction)onClickHowFarCalculate:(id)sender
{
  if(locationStart == nil || locationEnd == nil)
  {
    if(locationStart == nil){
      [AppFunction quickAlertWithMessage:[AppMessage errorMissingLocationStart] title:@""];
      return;
    }else{
      [AppFunction quickAlertWithMessage:[AppMessage errorMissingLocationEnd] title:@""];
      return;
    }
  }
  else
  {
    if([[locationStart getLocationInCCLocation] distanceFromLocation:[locationEnd getLocationInCCLocation]] < [AppConstant getLocationDifferentMargin]){
      [AppFunction quickAlertWithMessage:[AppMessage errorSameLocation] title:@""];
      return;
    }
  }
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:locationStart forKey:@"locationStart"];
  [extraData setValue:locationEnd forKey:@"locationEnd"];
  
  howFarResult = [[HowFarResult alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:howFarResult animated:YES];
}

- (IBAction)onClickSelectStartingLocation:(id)sender
{
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationForHowFarStart:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  locationTypePicker = [[LocationTypePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
  
  [self.myNavigationController pushViewController:locationTypePicker animated:YES];
}

- (IBAction)onClickSelectEndingLocation:(id)sender
{
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onSelectedLocationForHowFarEnd:) name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  locationTypePicker = [[LocationTypePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
  
  [self.myNavigationController pushViewController:locationTypePicker animated:YES];
}

- (void)onSelectedLocationForHowFarStart:(NSNotification *)notification
{
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  if(notification.object != nil)
  {
    locationStart = notification.object;
    [btnSelectStartingLocaiton setTitle:[NSString stringWithFormat:@"由:%@",[(OEMLocation *)notification.object getDisplayName]] forState:UIControlStateNormal];
    
    [self.myNavigationController popToViewController:self animated:YES];
  }
}

- (void)onSelectedLocationForHowFarEnd:(NSNotification *)notification
{
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getLocationPickerCallBackFuncionName] object:nil];
  
  if(notification.object != nil)
  {
    locationEnd = notification.object;
    [btnSelectEndingLocation setTitle:[NSString stringWithFormat:@"去:%@",[(OEMLocation *)notification.object getDisplayName]] forState:UIControlStateNormal];
    
    [self.myNavigationController popToViewController:self animated:YES];
  }
}

@end
