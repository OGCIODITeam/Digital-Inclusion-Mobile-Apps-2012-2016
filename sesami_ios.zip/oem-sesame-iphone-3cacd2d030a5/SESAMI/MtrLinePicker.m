//
//  MtrLinePicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MtrLinePicker.h"

@implementation MtrLinePicker

- (void)viewDidLoad
{
    [super viewDidLoad];
//    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
//    {
//        [myTableView setContentInset:UIEdgeInsetsMake(-40, myTableView.contentInset.left, myTableView.contentInset.bottom, myTableView.contentInset.right)];
//    }
    [self initData];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"地下鐵綫路";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

- (void)initData
{
    arrayLines = [NSArray arrayWithObjects:@"觀塘綫",@"荃灣綫",@"港島綫",@"東涌綫",@"東鐵綫",@"將軍澳綫",@"西鐵綫",@"馬鞍山綫",@"機場快綫",@"迪士尼綫", nil];
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayLines count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 50;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[arrayLines objectAtIndex:[indexPath row]]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:[NSString stringWithFormat:@"%i",[indexPath row]] forKey:@"rowIndex"];
    [extraData setValue:[arrayLines objectAtIndex:indexPath.row] forKey:@"titleName"];
    mtrDistrictPicker = [[MtrDistrictPicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    [self.myNavigationController pushViewController:mtrDistrictPicker animated:YES];
}

@end
