//
//  BuildingCountPicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "BuildingCountPicker.h"

@interface BuildingCountPicker ()

@end

@implementation BuildingCountPicker

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrayNearbyBuildingItems = [[NSArray alloc] initWithObjects:@"1",@"2",@"4",@"10",@"20",@"50", nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"設定";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

#pragma mark - UITableView

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [GlobalVar setNearByBuildingDisplayTotal:[[arrayNearbyBuildingItems objectAtIndex:indexPath.row] intValue ]];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayNearbyBuildingItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    //cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    
    // Configure the cell...
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 60;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    
    cell.textLabel.text = [arrayNearbyBuildingItems objectAtIndex:indexPath.row];
    
    if([GlobalVar getNearByBuildingDisplayTotal] == [[arrayNearbyBuildingItems objectAtIndex:indexPath.row] intValue])
    {
        [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    }

    
    return cell;
}

@end
