//
//  MtrLinePicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MtrDistrictPicker.h"

@interface MtrLinePicker : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *myTableView;
    NSArray *arrayLines;
    
    MtrDistrictPicker *mtrDistrictPicker;
}

-(void)initData;

@end
