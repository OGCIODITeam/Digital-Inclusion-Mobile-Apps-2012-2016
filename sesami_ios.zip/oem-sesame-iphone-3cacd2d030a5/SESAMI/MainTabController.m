
//
//  MainTabController.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MainTabController.h"

@implementation MainTabController

@synthesize tab1ViewController;
@synthesize tab2ViewController;
@synthesize tab3ViewController;
@synthesize tab4ViewController;
@synthesize tab5ViewController;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [fakeTabBar setHidden:YES];

    // Set the text color to black for unselected items
    UIImage *imaged = [UIImage imageNamed:@"menu-position.png"];
    if ([imaged respondsToSelector:@selector(imageWithRenderingMode:)]) {
        [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], UITextAttributeTextColor, nil]
                                                 forState:UIControlStateNormal];
    } else {
        [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, nil]
                                                 forState:UIControlStateNormal];
    }

    // To avoid rendering the unselected items as grey icons
    UITabBarItem *item0 = [tabBarController.tabBar.items objectAtIndex:0];
    UIImage *image0 = [UIImage imageNamed:@"menu-position.png"];
    if ([image0 respondsToSelector:@selector(imageWithRenderingMode:)]) {
        item0.image = [image0 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        item0.selectedImage = [UIImage imageNamed:@"menu-position.png"];
    }
    
    UITabBarItem *item1 = [tabBarController.tabBar.items objectAtIndex:1];
    UIImage *image1 = [UIImage imageNamed:@"menu-indoor.png"];
    if ([image1 respondsToSelector:@selector(imageWithRenderingMode:)]) {
        item1.image = [image1 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        item1.selectedImage = [UIImage imageNamed:@"menu-indoor.png"];
    }
    
    UITabBarItem *item2 = [tabBarController.tabBar.items objectAtIndex:2];
    UIImage *image2 = [UIImage imageNamed:@"menu-favor.png"];
    if ([image2 respondsToSelector:@selector(imageWithRenderingMode:)]) {
        item2.image = [image2 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        item2.selectedImage = [UIImage imageNamed:@"menu-favor.png"];
    }
    
    UITabBarItem *item3 = [tabBarController.tabBar.items objectAtIndex:3];
    UIImage *image3 = [UIImage imageNamed:@"menu-walk2.png"];
    if ([image3 respondsToSelector:@selector(imageWithRenderingMode:)]) {
        item3.image = [image3 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        item3.selectedImage = [UIImage imageNamed:@"menu-walk2.png"];
    }
    
    UITabBarItem *item4 = [tabBarController.tabBar.items objectAtIndex:4];
    UIImage *image4 = [UIImage imageNamed:@"menu-setting.png"];
    if ([image4 respondsToSelector:@selector(imageWithRenderingMode:)]) {
        item4.image = [image4 imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        item4.selectedImage = [UIImage imageNamed:@"menu-setting.png"];
    }
    
    [self.view addSubview:tabBarController.view];
    /*
    [tabBarController.view setFrame:CGRectMake(0,
                                               ([AppConstant getStatusBarHeight] * -1),
                                               tabBarController.view.frame.size.width,
                                               tabBarController.view.frame.size.height)];
    */
    [tabBarController.view setFrame:[AppConstant getTabControllerFrame]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onShowLoading:) name:[AppConstant getShowLoadingEventName] object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onHideLoading:) name:[AppConstant getHideLoadingEventName] object:nil];
    
    tab1ViewController.tabKey = @"tab1";
    tab2ViewController.tabKey = @"tab2";
    tab3ViewController.tabKey = @"tab3";
    tab4ViewController.tabKey = @"tab4";
    tab5ViewController.tabKey = @"tab5";
    
    [tab1ViewController setTabViewController:self];
    [tab2ViewController setTabViewController:self];
    [tab3ViewController setTabViewController:self];
    [tab4ViewController setTabViewController:self];
    [tab5ViewController setTabViewController:self];
    
    tab1ViewController.firstViewController = [[PositionViewIndex alloc] initWithNibName:nil bundle:nil];
    tab2ViewController.firstViewController = [[IndoorMapCategoryViewIndex alloc] initWithNibName:nil bundle:nil];
    //tab2ViewController.firstViewController = [[MapManagment alloc] initWithNibName:nil bundle:nil];
    tab3ViewController.firstViewController = [[FavoriteViewIndex alloc] initWithNibName:nil bundle:nil];
    tab4ViewController.firstViewController = [[VirtualWalkViewIndex alloc] initWithNibName:nil bundle:nil];
    tab5ViewController.firstViewController = [[SettingViewIndex alloc] initWithNibName:nil bundle:nil];
    
    [tab1ViewController prepareCompleteAction];
    [tab2ViewController prepareCompleteAction];
    [tab3ViewController prepareCompleteAction];
    [tab4ViewController prepareCompleteAction];
    [tab5ViewController prepareCompleteAction];
    
    
    
    /*
    [tabBarController.view
     setFrame:CGRectMake(0,
                         ([AppConstant getStatusBarHeight] * -1),
                         tabBarController.view.frame.size.width,
                         [AppConstant getScreenHeight]+20)];
    */
    //tabBarController.tabBar.hidden = YES;
    //[self.view addSubview:tabBarController.view];
    
    //[self.view bringSubviewToFront:fakeTabBar];
    //currentTabIndex = -1;
    //[self fakeTabBarItem_Click:fakeTabBarItem1];
    
    [self getLocation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - TabViewController

- (IBAction)fakeTabBarItem_Click:(id)sender
{    
    if (currentTabIndex == [sender tag] - 1)
    {
        return;
    }
    
    currentTabIndex = [sender tag] - 1;
    tabBarController.selectedIndex = currentTabIndex;
    
    [fakeTabBarItem1 setImage:[UIImage imageNamed:@"btn_menu_position.png"] forState:UIControlStateNormal];
    [fakeTabBarItem2 setImage:[UIImage imageNamed:@"btn_menu_indoor.png"] forState:UIControlStateNormal];
    [fakeTabBarItem3 setImage:[UIImage imageNamed:@"btn_menu_favor.png"] forState:UIControlStateNormal];
    [fakeTabBarItem4 setImage:[UIImage imageNamed:@"btn_menu_walk.png"] forState:UIControlStateNormal];
    [fakeTabBarItem5 setImage:[UIImage imageNamed:@"btn_menu_setting.png"] forState:UIControlStateNormal];
    
    switch (currentTabIndex)
    {
        case 0:
            [fakeTabBarItem1 setImage:[UIImage imageNamed:@"btn_menu_position_highlighted.png"] forState:UIControlStateNormal];
            break;
            
        case 1:
            [fakeTabBarItem2 setImage:[UIImage imageNamed:@"btn_menu_indoor_highlighted.png"] forState:UIControlStateNormal];
            break;
            
        case 2:
            [fakeTabBarItem3 setImage:[UIImage imageNamed:@"btn_menu_favor_highlighted.png"] forState:UIControlStateNormal];
            break;
            
        case 3:
            [fakeTabBarItem4 setImage:[UIImage imageNamed:@"btn_menu_walk_highlighted.png"] forState:UIControlStateNormal];
            break;
            
        case 4:
            [fakeTabBarItem5 setImage:[UIImage imageNamed:@"btn_menu_setting_highlighted.png"] forState:UIControlStateNormal];
            break;
    }
}

- (void)setTab:(int)index
{
    switch (index)
    {
        case 1:
            [self fakeTabBarItem_Click:fakeTabBarItem1];
            break;
            
        case 2:
            [self fakeTabBarItem_Click:fakeTabBarItem2];
            break;
            
        case 3:
            [self fakeTabBarItem_Click:fakeTabBarItem3];
            break;
            
        case 4:
            [self fakeTabBarItem_Click:fakeTabBarItem4];
            break;
            
        case 5:
            [self fakeTabBarItem_Click:fakeTabBarItem5];
            break;
    }
    
}

#pragma mark - Loading

- (void)onShowLoading:(NSNotification *)notification
{
    [self.view addSubview:viewLoading];
}

- (void)onHideLoading:(NSNotification *)notification
{
    [viewLoading removeFromSuperview];
}

#pragma mark - Location

-(void)getLocation
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    
   // [locationManager requestWhenInUseAuthorization];
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
     locationManager.headingFilter = 1;
    if ([[[UIDevice currentDevice]systemVersion]floatValue] >= 8.0 && [CLLocationManager authorizationStatus]!= kCLAuthorizationStatusAuthorizedWhenInUse)
    {
        [locationManager requestWhenInUseAuthorization];
    }
    else
    {
        [locationManager startUpdatingLocation];
        [locationManager startUpdatingHeading];
    }
    
   
    
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
        case kCLAuthorizationStatusNotDetermined:{
            NSLog(@"Not determined");
            [locationManager startUpdatingLocation];
            [locationManager startUpdatingHeading];
        } break;
        case kCLAuthorizationStatusDenied: {
            NSLog(@"Denied");
        } break;
        case kCLAuthorizationStatusAuthorizedWhenInUse:
        case kCLAuthorizationStatusAuthorizedAlways: {
            NSLog(@"Grant permission");
            [locationManager startUpdatingLocation];
            [locationManager startUpdatingHeading];
        }break;
        default:
            break;
    }
}
/*- (void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    NSLog(@"AA");
}*/
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    [GlobalVar setCurrentLocation:newLocation];
}
- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{    
//	float oldRad =  -manager.heading.trueHeading * M_PI / 180.0f;
//	float newRad =  -newHeading.trueHeading * M_PI / 180.0f;
//    
//	NSLog(@"%f (%f) => %f (%f)", manager.heading.trueHeading, oldRad, newHeading.trueHeading, newRad);
  
    [GlobalVar setCurrentCompassHeading:newHeading.trueHeading];
}

@end
