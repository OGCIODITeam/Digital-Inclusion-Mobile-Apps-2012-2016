//
//  FavoriteViewIndex.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "FavoriteViewIndex.h"

@implementation FavoriteViewIndex

@synthesize tableViewFavorite;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self)
  {
    [self setData:[[NSArray alloc] initWithArray:[OEMDB getAllFavoriteLocations]]];
    [self disableDisclosureButton:YES];
  }
  return self;
}

- (void)viewDidLoad
{
  [super viewDidLoad];
  [tableViewFavorite reloadData];
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = @"我的最愛";
  
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:NO LeftTitle:@""
   ShowRight:NO RightTitle:@""];
  
  [self setData:[[NSArray alloc] initWithArray:[OEMDB getAllFavoriteLocations]]];
  [tableViewFavorite reloadData];
}

-(void)setData:(NSArray *)data
{
  arrayData = data;
}

-(void)disableDisclosureButton:(BOOL)isDisable
{
  isDisableDisclosureButton = isDisable;
}

- (void)onClickResult:(NSNotification *)notification
{
  if(notification.object!=nil){
    [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getClickResultCallBackName] object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:notification.object];
  }
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  NSString *accessValue;
  
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
  }
  if(!isDisableDisclosureButton){
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
  }
  // Configure the cell...
  UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
  CGRect frame = iv.frame;
  frame.origin = cell.frame.origin;
  frame.size = cell.frame.size;
  frame.size.height = 60;
  iv.frame = frame;
  cell.backgroundView = iv;
  cell.textLabel.text = [(OEMLocation *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
  cell.textLabel.backgroundColor = [UIColor clearColor];

  accessValue = [NSString stringWithFormat:@"%@ %@", [(OEMLocation *)[arrayData objectAtIndex:[indexPath row]] getAddress],
                 [AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]]];
  NSLog(@"Access value - %@", accessValue);
  cell.accessibilityValue = accessValue;
  
//  cell.accessibilityValue = [AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]];
  
  NSLog(@"YO1: %@", cell.accessibilityValue);
  
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:@"Tab3_Index" forKey:@"mySection"];
  [extraData setValue:([[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""]) forKey:@"locationStart"];
  [extraData setValue:((OEMLocation *)[arrayData objectAtIndex:[indexPath row]]) forKey:@"locationEnd"];
  
  locationMenu = [[LocationMenu alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:locationMenu animated:YES];
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

@end
