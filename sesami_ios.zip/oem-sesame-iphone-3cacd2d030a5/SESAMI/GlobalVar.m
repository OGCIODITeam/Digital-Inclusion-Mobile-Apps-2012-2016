//
//  GlobalVar.m
//  SESAMI
//
//  Created by Daniel Lee on 18/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "GlobalVar.h"
#import <CoreLocation/CoreLocation.h>

@implementation GlobalVar

CLLocation *g_CurrentLocation;
double g_CurrentCompassHeading;
NSString * g_CurrentFunction;

+(void)setCurrentLocation:(CLLocation *)cl{
    g_CurrentLocation = cl;
}
+(CLLocation *)getCurrentLocation{
    return g_CurrentLocation;
}

+(void)setCurrentCompassHeading:(double)c{
    g_CurrentCompassHeading = c;
}
+(double)getCurrentCompassHeading{
    return g_CurrentCompassHeading;
}

+(void)setCurrentFunction:(NSString *)func{
  g_CurrentFunction = func;
}
+(NSString *)getCurrentFunction{
  return g_CurrentFunction;
}

//for setting
+(void)setNearByBuildingDisplayTotal:(int)n{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:n forKey:@"nearByBuildingDislayTotal"];
    [defaults synchronize];
}
+(void)setAlertInterval:(int)n{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:n forKey:@"alertInterval"];
    [defaults synchronize];
}
+(void)setAutoUpdateIndoorMap:(BOOL)isSet{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:isSet forKey:@"autoUpdateIndoorMap"];
    [defaults synchronize];
}
+(int)getNearByBuildingDisplayTotal{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if([defaults integerForKey:@"nearByBuildingDislayTotal"]==0)return 4;
    return [defaults integerForKey:@"nearByBuildingDislayTotal"];
}
+(int)getAlertInterval{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if([defaults integerForKey:@"alertInterval"]==0)return 10;
    return [defaults integerForKey:@"alertInterval"];
}
+(BOOL)getAutoUpdateIndoorMap{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults boolForKey:@"autoUpdateIndoorMap"];
}
+(void)setIndoorMapVersion:(NSString *)mapVersion{
  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
  [defaults setValue:mapVersion forKey:@"mapVersion"];
  [defaults synchronize];
}
+(NSString *)getIndoorMapVersion{
  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
  return [defaults stringForKey:@"mapVersion"];
}

@end
