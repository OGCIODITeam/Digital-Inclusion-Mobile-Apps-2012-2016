//
//  InformationViewController.m
//  SESAMI
//
//  Created by Ray.Liu on 9/18/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "InformationViewController.h"

@interface InformationViewController ()

@end

@implementation InformationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.title = @"關於我們";
}

@end
