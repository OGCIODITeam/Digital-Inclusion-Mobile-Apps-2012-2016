//
//  IndoorDB.h
//  SESAMI
//
//  Created by Ray.Liu on 9/18/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IndoorDB : NSObject

+ (void)initDB;
+ (NSArray *)getAllCategories;
+ (NSArray *)getAllIndoorMaps;
+ (NSArray *)getAllCategoriesByMapList:(NSString*)mapList;
+ (NSArray *)getAllIndoorMapsWithCatIDDownloaded :(int)catID: (NSString *)mapList;
+ (NSArray *)getAllIndoorMapsWithCatID: (int)catID: (NSString*)mapList;
+ (NSArray *)getAllFloorPlanWithMapID:(int)mapID;
+ (NSString *)getTextWithDataLabelID:(int)dataLabelID;
+ (NSArray *)getAllDataLabelWithFloorPlanID:(int)floorPlanID;
+ (NSArray *)getAllFloorPlanWithMapIDs:(NSString *)mapIDs;

@end
