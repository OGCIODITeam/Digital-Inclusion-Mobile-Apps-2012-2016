//
//  MainTabViewController.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MainTabViewController.h"

@interface MainTabViewController ()

@end

@implementation MainTabViewController

@synthesize tabKey;
@synthesize firstViewController;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    mainNavigation = [[MainNavigationController alloc] initWithNibName:@"MainNavigationController" bundle:nil];
    
    /*
    [mainNavigation.view
     setFrame:CGRectMake(0,
                         ([AppConstant getStatusBarHeight] * -1),
                         mainNavigation.view.frame.size.width,
                         mainNavigation.view.frame.size.height)];
    */
    [mainNavigation.view setFrame:[AppConstant getMainNavigationFrame]];
    //NSLog(@"%f",mainNavigation.view.frame.size.height);
    
    [self.view addSubview:mainNavigation.view];
    
    [mainNavigation.btnMainMenu addTarget:self action:@selector(btnMainMenu_Click:) forControlEvents:UIControlEventTouchUpInside];
     
}

#pragma mark - TabFirstView

- (void)prepareCompleteAction
{
    firstViewController.myNavigationController = mainNavigation.myNavigationController;
    
    [mainNavigation.myNavigationController pushViewController:firstViewController animated:NO];
    
    if ([tabKey isEqualToString:@"tab1"])
    {
        //tab1 action
    }
    else if ([tabKey isEqualToString:@"tab2"])
    {
        //tab2 action
    }
    else if ([tabKey isEqualToString:@"tab3"])
    {
        //tab3 action
    }
    else if ([tabKey isEqualToString:@"tab4"])
    {
        //tab4 action
    }
    else if ([tabKey isEqualToString:@"tab5"])
    {
        //tab5 action
    }
    else
    {
        //no action
    }
}

- (void)setTabViewController:(UIViewController *)controller
{
    tabViewController = controller;
}

@end
