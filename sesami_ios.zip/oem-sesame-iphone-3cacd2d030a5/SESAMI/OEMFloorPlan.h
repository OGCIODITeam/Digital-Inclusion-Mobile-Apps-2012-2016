//
//  OEMLocation.h
//  semami
//
//  Created by Daniel Lee on 5/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
@interface OEMFloorPlan : NSObject

@property (assign) int floorPlanID;
@property (strong) NSString *displayName;
@property (strong) NSString *description;
@property (assign) int level;
@property (strong) NSString *image;
@property (strong) NSString *data;
@property (strong) NSArray *dataLabel;

- (id)initWithFloorPlanID:(int)floorPlanID Name:(NSString *)floorPlanName Description:(NSString *)floorDescription Level:(int)floorPlanLevel Image:(NSString *)floorPlanImage Data:(NSString *)floorPlanData DataLabel:(NSArray *)floorPlanDataLabel;

- (void)setFloorPlanIDWithInt:(int)newID;
- (int)getFloorPlanID;
- (NSString *)getDisplayName;
- (NSString *)getDescription;
- (int)getLevel;
- (NSString *)getImage;
- (NSString *)getData;
- (NSArray *)getDataLabel;

@end
