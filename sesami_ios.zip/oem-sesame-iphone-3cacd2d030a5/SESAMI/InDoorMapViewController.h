//
//  InDoorMapViewController.h
//  SESAMI
//
//  Created by Ray.Liu on 8/14/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MapTableViewController;
@class FloorPlanTableViewController;
@class FloorPlanViewController;
@class OEMFloorPlan;

@interface InDoorMapViewController : UIViewController
{
    IBOutlet UILabel *voiceLabel;
    
    IBOutlet UIView *viewContentContainer;
    __weak IBOutlet UILabel *lblTableTitle;
    IBOutlet UIButton *btnTableBack;
    IBOutlet UIButton *btnDownloadMap;
    
    IBOutlet UIView *viewIndoor;
    __weak IBOutlet UITableView *tableViewIndoor;
    
    IBOutlet UIView *viewFloorPlan;
    __weak IBOutlet UITableView *tableViewFloorPlan;
    
    NSString *currentSection;
    int currentFloorPlanLevel;
    OEMMap *currentMap;
    OEMFloorPlan *currentFloorPlan;
    
    NSArray *arrayIndoor;
    NSArray *arrayFloorPlan;
    
    MapTableViewController *tvcMapResult;
    FloorPlanTableViewController *tvcFloorPlanResult;
    
    FloorPlanViewController *floorPlanViewController;
}

- (IBAction)onClickTableBack:(id)sender;

- (void)initMapData;
- (void)loadMapView;

- (void)initFloorPlanDataWithMapID:(int)mapID;
- (void)loadFloorPlanView;

- (void)showHideFloorPlan:(BOOL)isShow;

- (void)setCurrentFloorPlanLevel:(int)level;
- (void)playFloorPlanLevelCompletedHandler;

@end
