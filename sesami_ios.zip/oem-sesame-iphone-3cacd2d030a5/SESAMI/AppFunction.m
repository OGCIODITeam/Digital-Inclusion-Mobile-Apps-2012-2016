//
//  AppFunction.m
//  SESAMI
//
//  Created by Daniel Lee on 18/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "AppFunction.h"
#import "OEMLocation.h"

#define RAD_TO_DEG(r) ((r) * (180 / M_PI))
#define degreesToRadians(x) (M_PI * x / 180.0)
#define radiandsToDegrees(x) (x * 180.0 / M_PI)

@implementation AppFunction

+(NSString *)convertNumberToChineseSentance:(int)number{
  NSString *returnString;
  
  if(number>9999){
    int p1 = (int)ceil(number/10000);
    int p2 = number - p1 * 10000;
    
    returnString = [[NSString alloc] initWithFormat:@"%@萬%@",[AppFunction convertNumberToChineseSentance4Digi:p1],[AppFunction convertNumberToChineseSentance4Digi:p2]];
  }else{
    returnString = [AppFunction convertNumberToChineseSentance4Digi:number];
  }
  
  //[aString substringWithRange:NSMakeRange(13, 10)]
  if([returnString length]>1){
    if([[returnString substringWithRange:NSMakeRange(0, 2)] isEqualToString:@"一十"]){
      returnString = [returnString substringWithRange:NSMakeRange(1, [returnString length]-1)];
    }
  }
  
  return returnString;
}
+(NSString *)convertNumberToChineseSentance4Digi:(int)number{
  NSArray *arrUnit = [[NSArray alloc] initWithObjects:@"",@"十",@"百",@"千", nil];
  NSString *returnString = [[NSString alloc]init];
  
  NSString *numberString = [NSString stringWithFormat:@"%d",number];
  
  for (int i=0; i < [numberString length]; i++) {
    
    NSString *newStringPart = [AppFunction getChineseCharFromInt:[[NSString stringWithFormat:@"%c", [numberString characterAtIndex:i]] intValue]];
    
    if([returnString length]>0){
      if([[returnString substringFromIndex:(returnString.length-1)] isEqualToString:@"零"] && [newStringPart isEqualToString:@"零"]){
      }else{
        returnString = [returnString stringByAppendingString:newStringPart];
      }
    }else{
      returnString = [returnString stringByAppendingString:newStringPart];
    }
    
    if(![newStringPart isEqualToString:@"零"] ){
      returnString = [returnString stringByAppendingString:[arrUnit objectAtIndex:([numberString length]-1-i)]];
    }
    
  }
  
  if([returnString hasSuffix:@"零"])
    returnString = [returnString substringToIndex:[returnString length]-1];
  
  return returnString;
}
+(NSString *)getChineseCharFromInt:(int)number{
  if(number==1)return @"一";
  if(number==2)return @"二";
  if(number==3)return @"三";
  if(number==4)return @"四";
  if(number==5)return @"五";
  if(number==6)return @"六";
  if(number==7)return @"七";
  if(number==8)return @"八";
  if(number==9)return @"九";
  
  return @"零";
}
+(NSString *)getResultAccessibilityValueForLocation:(OEMLocation *)location{
  CLLocation *currentLocation = [GlobalVar getCurrentLocation];
  //[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:locCenter ToLocation:locA]]
  return [NSString stringWithFormat:@"%@面，距離%@米",[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:currentLocation ToLocation:location.getLocationInCCLocation]],[AppFunction convertNumberToChineseSentance:[currentLocation distanceFromLocation:location.getLocationInCCLocation]]];
}
+(NSString *)getResultAccessibilityValueFromLocation:(OEMLocation *)locationStart ToLocation:(OEMLocation *)locationEnd
{
  NSString *currentFunction = [GlobalVar getCurrentFunction];
  CLLocation *currentLocation = [locationStart getLocationInCCLocation];
  
  //[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:locCenter ToLocation:locA]]
  if ([currentFunction isEqualToString:@"whereami"]) {
    return [NSString stringWithFormat:@"%@面，距離%@米",[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:currentLocation ToLocation:locationEnd.getLocationInCCLocation]],[AppFunction convertNumberToChineseSentance:[currentLocation distanceFromLocation:locationEnd.getLocationInCCLocation]]];
  } else {
    return [NSString stringWithFormat:@"距離%@米",[AppFunction convertNumberToChineseSentance:[currentLocation distanceFromLocation:locationEnd.getLocationInCCLocation]]];
  }
}
+(NSString *)getCompassDirectionFromLocation:(CLLocation *)fromLocation ToLocation:(CLLocation *)toLocation{
  
  float fLat = degreesToRadians(fromLocation.coordinate.latitude);
  float fLng = degreesToRadians(fromLocation.coordinate.longitude);
  float tLat = degreesToRadians(toLocation.coordinate.latitude);
  float tLng = degreesToRadians(toLocation.coordinate.longitude);
  
  float degree = radiandsToDegrees(atan2(sin(tLng-fLng)*cos(tLat), cos(fLat)*sin(tLat)-sin(fLat)*cos(tLat)*cos(tLng-fLng)));
  
  double currentHeading = [GlobalVar getCurrentCompassHeading];
  if(currentHeading<0)
    currentHeading+=360;
  
  double returnHeading = 0;
  
  if (degree >= 0) {
    //return degree;
    returnHeading = degree - currentHeading;
    if(returnHeading<0)returnHeading+=360;
    NSLog(@"degree is %f (current:%f) (true:%f)",degree, currentHeading,returnHeading);
  } else {
    //return 360+degree;
    returnHeading = 360+degree - currentHeading;
    if(returnHeading<0)returnHeading+=360;
    NSLog(@"degree is %f (current:%f) (true:%f)",360+degree, currentHeading,returnHeading);
  }
  
  return @"";
}
+(double)getCompassHeadingFromLocation:(CLLocation *)fromLocation ToLocation:(CLLocation *)toLocation{
  float fLat = degreesToRadians(fromLocation.coordinate.latitude);
  float fLng = degreesToRadians(fromLocation.coordinate.longitude);
  float tLat = degreesToRadians(toLocation.coordinate.latitude);
  float tLng = degreesToRadians(toLocation.coordinate.longitude);
  
  float degree = radiandsToDegrees(atan2(sin(tLng-fLng)*cos(tLat), cos(fLat)*sin(tLat)-sin(fLat)*cos(tLat)*cos(tLng-fLng)));
  
  double currentHeading = [GlobalVar getCurrentCompassHeading];
  double returnHeading = 0;
  if(currentHeading<0)
    currentHeading+=360;
  
  //double heading;
  if (degree >= 0) {
    //return degree;
    returnHeading = degree - currentHeading;
    if(returnHeading<0)returnHeading+=360;
  } else {
    //return 360+degree;
    returnHeading = 360+degree - currentHeading;
    if(returnHeading<0)returnHeading+=360;
  }
  
  return returnHeading;
}
+(NSString *)getChineseDirectionFromHeadingValue:(double)h{
  //    NSLog(@">>%f",h);
  if(h>315 || h<=45){
    //N
    return [AppConstant getDirectionChineseFront];
  }else if(h>45 && h<135){
    //E
    return [AppConstant getDirectionChineseRight];
  }else if(h>=135 && h<225){
    //S
    return [AppConstant getDirectionChineseBack];
  }else{
    //W
    return [AppConstant getDirectionChineseLeft];
  }
}
+(void)quickAlertWithMessage:(NSString *)message title:(NSString *)title{
  UIAlertView *av = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"關閉" otherButtonTitles:nil];
  [av show];
}
+(void)listDirectory:(NSString *)sPath{
  BOOL isDir;
  NSLog(@"list directory \n%@",sPath);
  [[NSFileManager defaultManager] fileExistsAtPath:sPath isDirectory:&isDir];
  
  if(isDir)
  {
    NSArray *contentOfDirectory=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:sPath error:NULL];
    
    int contentcount = [contentOfDirectory count];
    NSLog(@"1, %d",contentcount);
    int i;
    for(i=0;i<contentcount;i++)
    {
      NSString *fileName = [contentOfDirectory objectAtIndex:i];
      NSString *path = [sPath stringByAppendingFormat:@"%@%@",@"/",fileName];
      NSLog(@"2 : %@",path);
      if([[NSFileManager defaultManager] isDeletableFileAtPath:path])
      {
        NSLog(@"\n-[FOLDER]%@",sPath);
        [self listDirectory:path];
      }
    }
  }
  else
  {
    NSString *msg=[NSString stringWithFormat:@"%@",sPath];
    NSLog(@"\n-[FILE]%@",msg);
  }
}

+(NSArray *)getObjectWithFloorPlanDataString:(NSString *)str
{
  NSMutableArray *retArr = [[NSMutableArray alloc] init];
  
  str = [str stringByReplacingOccurrencesOfString:@"[[" withString:@""];
  str = [str stringByReplacingOccurrencesOfString:@"]]" withString:@""];
  str = [str stringByReplacingOccurrencesOfString:@"\"" withString:@""];
  
  NSArray *arr = [str componentsSeparatedByString:@"],["];
  
  for (int i = 0; i < arr.count; i++)
  {
    NSString *str2 = [arr objectAtIndex:i];
    NSArray *arr2 = [str2 componentsSeparatedByString:@","];
    
    for (int j = 0; j < arr2.count; j++)
    {
      [retArr addObject:[arr2 objectAtIndex:j]];
    }
  }
  
  return retArr;
}

@end
