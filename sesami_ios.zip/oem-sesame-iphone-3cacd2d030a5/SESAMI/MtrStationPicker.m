//
//  MtrStationPicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MtrStationPicker.h"

@implementation MtrStationPicker

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
  self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
  if (self) {
    parentRowText = [self.myExtraData objectForKey:@"rowText"];
  }
  return self;
}

- (void)viewDidLoad
{
  [super viewDidLoad];
//  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
//  {
//    [myTableView setContentInset:UIEdgeInsetsMake(-40, myTableView.contentInset.left, myTableView.contentInset.bottom, myTableView.contentInset.right)];
//  }
  [self initData];
}

- (void)viewWillAppear:(BOOL)animated
{
  self.title = parentRowText;
  
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:YES LeftTitle:@""
   ShowRight:NO RightTitle:@""];
}

- (void)initData
{
  arrayCurrentList = [OEMDB getMTRExitWithStationName:parentRowText];
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  return 50;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  // Return the number of sections.
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  // Return the number of rows in the section.
  return [arrayCurrentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
  }
  
  UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
  CGRect frame = iv.frame;
  frame.origin = cell.frame.origin;
  frame.size = cell.frame.size;
  frame.size.height = 50;
  iv.frame = frame;
  cell.backgroundView = iv;
  cell.textLabel.backgroundColor = [UIColor clearColor];
  cell.textLabel.text = [NSString stringWithFormat:@"%@",[(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getDisplayName]];
  
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  OEMLocation *selectedLocation;
  selectedLocation = (OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]];
  selectedLocation.displayName = [parentRowText stringByAppendingString:selectedLocation.displayName];
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:selectedLocation];
}


@end
