//
//  OEMDB.h
//  SESAMI
//
//  Created by Daniel Lee on 9/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "OEMLocation.h"
#import "OEMMap.h"

@interface OEMDB : NSObject

+ (void)initDB;
+ (void)addSampleData;
+ (NSArray *)getAllFavoriteLocations;
+ (int)getIDFromOEMLocation:(OEMLocation *)location;
+ (BOOL)isFavorited:(OEMLocation *)location;
+ (int)addFavorite:(OEMLocation *)location;
+ (BOOL)removeFavorite:(int)locationID;
+ (NSArray *)getMTRExitWithStationName:(NSString *)stationName;
+ (NSArray *)getAllIndoorMaps;
+ (NSArray *)getAllFloorPlanWithMapID:(int)mapID;
+ (NSString *)getTextWithDataLabelID:(int)dataLabelID;
+ (NSArray *)getAllDataLabelWithFloorPlanID:(int)floorPlanID;

/*
-(id)init;
- (NSDictionary *)getAllFavoriteLocations;
*/ 
@end
