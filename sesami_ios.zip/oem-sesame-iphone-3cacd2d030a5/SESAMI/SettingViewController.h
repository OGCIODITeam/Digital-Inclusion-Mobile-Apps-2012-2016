//
//  SettingViewController.h
//  SESAMI
//
//  Created by Daniel Lee on 25/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>{
    
    
    __weak IBOutlet UILabel *lblTableTitle;
    __weak IBOutlet UIView *viewContentContainer;
    IBOutlet UIView *viewMain;
    IBOutlet UIView *viewNearbyBuildingOption;
    __weak IBOutlet UITableView *tableViewNearbyBuildingOption;
    IBOutlet UIView *viewAlertIntervalOption;
    __weak IBOutlet UITableView *tableViewAlertIntervalOption;
    
    __weak IBOutlet UIButton *btnNearbyBuilding;
    __weak IBOutlet UIButton *btnAlertInterval;
    __weak IBOutlet UIButton *btnToggleAutoUpdateIndoorMap;
    
    
    __weak IBOutlet UIButton *btnTableBack;
    NSArray *arrayNearbyBuildingItems;
    NSArray *arrayAlertIntervalItems;
    NSArray *arrayAlertIntervalItemsValue;
}
- (IBAction)onClickNearbyBuilding:(id)sender;
- (IBAction)onClickAlertInterval:(id)sender;
- (IBAction)onClickAutoUpdateIndoorMap:(id)sender;
@end
