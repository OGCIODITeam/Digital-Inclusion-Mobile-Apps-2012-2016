//
//  ViewController.h
//  SESAMI
//
//  Created by Daniel Lee on 8/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@class PositionViewController;
@class InDoorMapViewController;
@class FavoriteViewController;
@class SettingViewController;
@class VirtualWalkViewController;

@interface ViewController : UIViewController<CLLocationManagerDelegate>{
    IBOutlet UIView *viewRootContainer;
    
    PositionViewController *pv;
    InDoorMapViewController *idmv;
    FavoriteViewController *fv;
    SettingViewController *sv;
    VirtualWalkViewController *vwv;
    
    IBOutlet UIButton *btnMenuPosition;
    IBOutlet UIButton *btnMenuIndoorMap;
    IBOutlet UIButton *btnMenuFavor;
    IBOutlet UIButton *btnMenuWalk;
    IBOutlet UIButton *btnMenuSetting;
    
    IBOutlet UIView *viewLoading;
    
    CLLocationManager *locationManager;
}
- (void)initView;

@property (strong, nonatomic) PositionViewController *pv;
@property (strong, nonatomic) InDoorMapViewController *idmv;
@property (strong, nonatomic) FavoriteViewController *fv;
@property (strong, nonatomic) SettingViewController *sv;
@property (strong, nonatomic) VirtualWalkViewController *vwv;

- (IBAction)onClickPosition:(id)sender;
- (IBAction)onClickInDoorMap:(id)sender;
- (IBAction)onClickFavorite:(id)sender;
- (IBAction)onClickVirtualWalk:(id)sender;
- (IBAction)onClickSetting:(id)sender;
@end
