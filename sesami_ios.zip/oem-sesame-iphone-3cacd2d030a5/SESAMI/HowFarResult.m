//
//  HowFarResult.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "HowFarResult.h"

@implementation HowFarResult

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
    
    self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
    if (self)
    {
        locationStart = (OEMLocation *)[self.myExtraData objectForKey:@"locationStart"];
        locationEnd = (OEMLocation *)[self.myExtraData objectForKey:@"locationEnd"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadHowFar];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"距離";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, lblHowFarResult);
}

- (void)loadHowFar
{
    if(locationStart == nil || locationEnd == nil)
    {
        if(locationStart == nil)
        {
            [AppFunction quickAlertWithMessage:[AppMessage errorMissingLocationStart] title:@""];
        }
        else
        {
            [AppFunction quickAlertWithMessage:[AppMessage errorMissingLocationEnd] title:@""];
        }
    }
    else
    {
        if([[locationStart getLocationInCCLocation] distanceFromLocation:[locationEnd getLocationInCCLocation]] < [AppConstant getLocationDifferentMargin])
        {
            [AppFunction quickAlertWithMessage:[AppMessage errorSameLocation] title:@""];
        }
        else
        {
            double distant = [[locationStart getLocationInCCLocation] distanceFromLocation:[locationEnd getLocationInCCLocation]];
            if(distant<=99999999)
            {
                [lblHowFarResult setText:[NSString stringWithFormat:@"%@面, %@米",[AppFunction getChineseDirectionFromHeadingValue:[AppFunction getCompassHeadingFromLocation:[locationStart getLocationInCCLocation] ToLocation:locationEnd.getLocationInCCLocation]],[AppFunction convertNumberToChineseSentance:(int)floor(distant)]]];
            }
            else
            {
                [lblHowFarResult setText:[NSString stringWithFormat:@"%@",[AppMessage getTooFarAwayMSG]]];
            }
            //UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, @"距離");
            NSLog(@"start speaker ))))))))");
            UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, [NSString stringWithFormat:@"距離%@",lblHowFarResult.text]);
            
        }
    }
}

- (IBAction)manualRefresh:(id)sender {
  [self refreshAction];
}

- (void)refreshAction
{
  NSString * currentFunction = [GlobalVar getCurrentFunction];

  if ([currentFunction isEqualToString:@"whereami"]) {
    locationStart = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
  }

  if ([currentFunction isEqualToString:@"whereami"] || [currentFunction isEqualToString:@"howfar"]) {
    [self loadHowFar];
  }

//  if ([[self getMySection] isEqualToString:@"Tab1_WhereAmI"])
//    {
//        locationStart = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
//        [self loadHowFar];
//    }
//    else if ([[self getMySection] isEqualToString:@"Tab3_Index"])
//    {
//        locationStart = [[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""];
//        [self loadHowFar];
//    }
}

@end
