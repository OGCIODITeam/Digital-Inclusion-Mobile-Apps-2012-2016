//
//  SettingViewIndex.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BuildingCountPicker.h"
#import "UpdateIntervalPicker.h"
#import "InformationViewController.h"
#import "MapManagment.h"

@interface SettingViewIndex : BaseViewController
{
    __weak IBOutlet UIButton *btnNearbyBuilding;
    __weak IBOutlet UIButton *btnAlertInterval;
    __weak IBOutlet UIButton *btnToggleAutoUpdateIndoorMap;
    __weak IBOutlet UIButton *btnAboutUs;
    
    BuildingCountPicker *buildingCountPicker;
    UpdateIntervalPicker *updateIntervalPicker;
    InformationViewController *informationViewController;
    MapManagment *mapManagementViewController;
}

- (IBAction)onClickNearbyBuilding:(id)sender;
- (IBAction)onClickAlertInterval:(id)sender;
- (IBAction)onClickAutoUpdateIndoorMap:(id)sender;
- (IBAction)onClickAboutUs:(id)sender;
- (IBAction)onClickMap:(id)sender;
- (void)setAutoUpdateIndoorMap:(BOOL)isOn;

@end
