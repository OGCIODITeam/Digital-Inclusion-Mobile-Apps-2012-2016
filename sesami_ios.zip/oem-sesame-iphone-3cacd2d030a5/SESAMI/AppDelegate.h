//
//  AppDelegate.h
//  SESAMI
//
//  Created by Daniel Lee on 8/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainTabController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MainTabController *tabController;

@property (retain, nonatomic) NSFileManager *fileManager;
@property (retain, nonatomic) NSString *documentsDir;

- (void)showStatusBar;
- (void)hideStatusBar;

@end
