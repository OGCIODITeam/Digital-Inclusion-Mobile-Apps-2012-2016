//
//  MtrDistrictPicker.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "MtrDistrictPicker.h"

@implementation MtrDistrictPicker

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
    self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
    if (self) {
        parentRowIndex = [[self.myExtraData objectForKey:@"rowIndex"] intValue];
        myTitle = [self.myExtraData objectForKey:@"titleName"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
//    {
//        [myTableView setContentInset:UIEdgeInsetsMake(-40, myTableView.contentInset.left, myTableView.contentInset.bottom, myTableView.contentInset.right)];
//    }
    [self initData];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = myTitle;
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

- (void)initData
{
    arrayStationSet0 = [NSArray arrayWithObjects:@"調景嶺",@"油塘",@"藍田",@"觀塘",@"牛頭角",@"九龍灣",@"彩虹",@"鑽石山",@"黃大仙",@"樂富",@"九龍塘",@"石硤尾",@"太子",@"旺角",@"油麻地", nil];
    arrayStationSet1 = [NSArray arrayWithObjects:@"荃灣",@"大窩口",@"葵興",@"葵芳",@"荔景",@"美孚",@"荔枝角",@"長沙灣",@"深水埗",@"太子",@"旺角",@"油麻地",@"佐敦",@"尖沙咀",@"金鐘",@"中環", nil];
    arrayStationSet2 = [NSArray arrayWithObjects:@"上環",@"中環",@"金鐘",@"灣仔",@"銅鑼灣",@"天后",@"炮台山",@"北角",@"鰂魚涌",@"太古",@"西灣河",@"筲箕灣",@"杏花邨",@"柴灣", nil];
    arrayStationSet3 = [NSArray arrayWithObjects:@"東涌",@"欣澳",@"青衣",@"荔景",@"南昌",@"奧運",@"九龍",@"香港", nil];
    arrayStationSet4 = [NSArray arrayWithObjects:@"落馬洲",@"羅湖",@"上水",@"粉嶺",@"太和",@"大埔墟",@"大學",@"馬場",@"火炭",@"沙田",@"大圍",@"九龍塘",@"旺角東",@"紅磡", nil];
    arrayStationSet5 = [NSArray arrayWithObjects:@"康城",@"寶琳",@"坑口",@"將軍澳",@"調景嶺",@"油塘",@"鰂魚涌",@"北角",nil];
    arrayStationSet6 = [NSArray arrayWithObjects:@"屯門",@"兆康",@"天水圍",@"朗屏",@"元朗",@"錦上路",@"荃灣西",@"美孚",@"南昌",@"柯士甸",@"尖東",@"紅磡",nil];
    arrayStationSet7 = [NSArray arrayWithObjects:@"烏溪沙",@"馬鞍山",@"恆安",@"大水坑",@"石門",@"第一城",@"沙田圍",@"車公廟",@"大圍", nil];
    arrayStationSet8 = [NSArray arrayWithObjects:@"博覽館",@"機場",@"青衣",@"九龍",@"香港",nil];
    arrayStationSet9 = [NSArray arrayWithObjects:@"欣澳",@"迪士尼",nil];
    arrayStationSets = [NSArray arrayWithObjects:arrayStationSet0,arrayStationSet1,arrayStationSet2,arrayStationSet3,arrayStationSet4,arrayStationSet5,arrayStationSet6,arrayStationSet7,arrayStationSet8,arrayStationSet9, nil];
    
    arrayCurrentList = [arrayStationSets objectAtIndex:parentRowIndex];
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [arrayCurrentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
    }
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
    CGRect frame = iv.frame;
    frame.origin = cell.frame.origin;
    frame.size = cell.frame.size;
    frame.size.height = 50;
    iv.frame = frame;
    cell.backgroundView = iv;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[arrayCurrentList objectAtIndex:[indexPath row]]];

    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:[arrayCurrentList objectAtIndex:indexPath.row] forKey:@"rowText"];
    
    mtrStationPicker = [[MtrStationPicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    [self.myNavigationController pushViewController:mtrStationPicker animated:YES];
    
    /*
    //currentListLevel++;
    if(currentListLevel==0){
        currentListLevel++;
        arrayCurrentList = (NSArray *)[arrayStationSets objectAtIndex:[indexPath row]];
        currentStationIndex = [indexPath row];
        [self.tableView reloadData];
        [self.tableView setContentOffset:CGPointZero];
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
    }else if(currentListLevel==1){
        NSArray *arrayExits = [OEMDB getMTRExitWithStationName:[arrayCurrentList objectAtIndex:indexPath.row]];
        currentListLevel++;
        arrayCurrentList = arrayExits;
        [self.tableView reloadData];
        [self.tableView setContentOffset:CGPointZero];
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,nil);
    }else {
        // NSLog(@"exit : %@ (%f, %f)",[(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getDisplayName], [(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getLatitude], [(OEMLocation *)[arrayCurrentList objectAtIndex:[indexPath row]] getLongitude]);
        [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getLocationPickerCallBackFuncionName] object:[arrayCurrentList objectAtIndex:[indexPath row]]];
    }
     */
}

@end
