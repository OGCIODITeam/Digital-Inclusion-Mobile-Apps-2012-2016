//
//  LocationMenu.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "LocationMenu.h"
#import "NearByMeTypePicker.h"

@implementation LocationMenu

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
    
    self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
    if (self)
    {
        locationStart = (OEMLocation *)[self.myExtraData objectForKey:@"locationStart"];
        locationEnd = (OEMLocation *)[self.myExtraData objectForKey:@"locationEnd"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initView];
    
    //draw the control
    if ([[self getMySection] isEqualToString:@"Tab1_WhereAmI"])
    {
        [btnNearby setHidden:YES];
        [btnFavorite setFrame:CGRectMake(btnNearby.frame.origin.x, btnNearby.frame.origin.y, btnFavorite.frame.size.width, btnFavorite.frame.size.height)];
    }
    else if ([[self getMySection] isEqualToString:@"Tab1_NearBy"])
    {
        [btnNearby setHidden:YES];
        [btnFavorite setFrame:CGRectMake(btnNearby.frame.origin.x, btnNearby.frame.origin.y, btnFavorite.frame.size.width, btnFavorite.frame.size.height)];
    }
    else if ([[self getMySection] isEqualToString:@"Tab3_Index"])
    {
        [btnNearby setHidden:NO];
    }
    else if ([[self getMySection] isEqualToString:@"Tab3_NearBy"])
    {
        [btnNearby setHidden:YES];
        [btnFavorite setFrame:CGRectMake(btnNearby.frame.origin.x, btnNearby.frame.origin.y, btnFavorite.frame.size.width, btnFavorite.frame.size.height)];
    }
}              

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"選項";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
    
    //NSLog(@"section: %@", [self getMySection]);
}

- (void)initView
{
    isFavorited = [OEMDB isFavorited:locationEnd];
    if (isFavorited) {
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_remove_favor.png"] forState:UIControlStateNormal];
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_remove_favor_highligthed.png"] forState:UIControlStateHighlighted];
        btnFavorite.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtonRemoveFavorVO],locationEnd.getDisplayName];
        
        if([locationEnd getLocationID]==-1){
            [locationEnd setLocationID:[OEMDB getIDFromOEMLocation:locationEnd]];
        }
    }else{
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_add_favor.png"] forState:UIControlStateNormal];
        [btnFavorite setImage:[UIImage imageNamed:@"btn_favorite_add_favor_highlighted.png"] forState:UIControlStateHighlighted];
        btnFavorite.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtonAddFavorVO],locationEnd.getDisplayName];
    }
    
    btnHowFar.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtoHowFarVO],locationEnd.getDisplayName];
    btnNearby.accessibilityLabel = [NSString stringWithFormat:[AppLabel getLocationDetailButtoNearbyVO],locationEnd.getDisplayName];
}

- (IBAction)onClickHowFar:(id)sender
{
    howFarResult = [[HowFarResult alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:self.myExtraData];
    
    [self.myNavigationController pushViewController:howFarResult animated:YES];
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getDirectShowViewHowFarCallBackName] object:endLocation];
    
    
}

- (IBAction)onClickNearby:(id)sender
{
    //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getDirectShowViewNearbyCallBackName] object:endLocation];
    
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    if ([[self getMySection] isEqualToString:@"Tab3_Index"])
    {
        [extraData setValue:@"Tab3_NearBy" forKey:@"mySection"];
    }
    else
    {
        [extraData setValue:[self getMySection] forKey:@"mySection"];
    }
        
    [extraData setValue:locationEnd forKey:@"locationStart"];
    [extraData setValue:nil forKey:@"locationEnd"];
    
    nearByMeTypePicker = [[NearByMeTypePicker alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    [self.myNavigationController pushViewController:nearByMeTypePicker animated:YES];
}

- (IBAction)onClickFavorite:(id)sender
{
    if(isFavorited)
    {
        [OEMDB removeFavorite:[locationEnd getLocationID]];
    }
    else
    {
        [locationEnd setLocationIDWithInt:[OEMDB addFavorite:locationEnd]];
    }
    [self initView];
}

@end
