//
//  ExternalDataLoader.h
//  SESAMI
//
//  Created by Daniel Lee on 17/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ExternalDataLoader : NSObject <NSURLConnectionDelegate>
{
    NSMutableData *_responseData;
    NSString *requestURL;
    BOOL isRequesting;
    
    //For get all
    BOOL isGettingAllCatForNearby;
    CLLocation *locAll;
    int radiusAll;
    int zoomLevelAll;
    int partIndex;
    
    NSMutableArray *arrayAllCat;
}
- (void)loadSample;
- (void)reload;
- (void)centaMapGetNearbyBuildingFromLocation:(CLLocation *)loc radius:(int)radius;
- (void)centaMapGetNearbyBusStopFromLocation:(CLLocation *)loc zoomLevel:(int)zoomLevel;
- (void)centaMapGetNearbyLandmarkFromLocation:(CLLocation *)loc zoomLevel:(int)zoomLevel;
- (void)centaMapGetNearbyALLFromLocation:(CLLocation *)loc radius:(int)radius zoomLevel:(int)zoomLevel;
- (void)centaMapSearchBuildingWithKeyword:(NSString *)keyword;
- (void)centaMapGetBuildingByStreetName:(NSString *)streetName StreetNumber:(int)streetNumber;

- (void)indoor_RequestCreatePackage;
- (void)indoor_RequestDownloadPackage;

- (void)openRiceGetNearbyRestaurantFromLocation:(CLLocation *)loc radius:(int)radius;
- (void)onOpenRiceReturn:(NSNotification *)notification;

@end
