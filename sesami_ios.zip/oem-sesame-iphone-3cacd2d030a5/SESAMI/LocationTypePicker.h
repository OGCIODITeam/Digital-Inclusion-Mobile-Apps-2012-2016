//
//  LocationTypePicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationResultTableViewController.h"

#import "MyFavoritePicker.h"
#import "MtrLinePicker.h"
#import "SearchingController.h"

@interface LocationTypePicker : BaseViewController
{
    __weak IBOutlet UIButton *btnSelectorCurrentLocation;
    
    __weak IBOutlet UIButton *btnSelectorFavorite;
    MyFavoritePicker *myFavoritePicker;
    LocationResultTableViewController *tvcLocationResult;
    NSArray *arrayFavorite;
    
    __weak IBOutlet UIButton *btnSelectorMTR;
    MtrLinePicker *mtrLinePicker;
    
    __weak IBOutlet UIButton *btnSelectorSearch;
    SearchingController *searchingController;
}

- (IBAction)onClickCurrentLocation:(id)sender;
- (IBAction)onClickMyFavorite:(id)sender;
- (IBAction)onClickMTR:(id)sender;
- (IBAction)onClickSearch:(id)sender;

@end
