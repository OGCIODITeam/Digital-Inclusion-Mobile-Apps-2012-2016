//
//  NearByMeTypePicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NearByMeResult.h"

@interface NearByMeTypePicker : BaseViewController
{
    __weak IBOutlet UIButton *btnNearbyBuilding;
    __weak IBOutlet UIButton *btnNearbyBusStop;
    __weak IBOutlet UIButton *btnNearbyRestaurant;
    __weak IBOutlet UIButton *btnNearbyLandmark;
    __weak IBOutlet UIButton *btnNearbyAll;
    
    OEMLocation *locationStart;
    OEMLocation *locationEnd;

    NearByMeResult *nearbyMeResult;
}

- (void)loadResultWithCategotyID:(int)catID;

@end
