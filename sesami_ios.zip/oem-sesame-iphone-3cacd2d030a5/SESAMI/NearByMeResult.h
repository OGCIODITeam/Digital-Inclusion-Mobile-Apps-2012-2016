//
//  NearByMeResult.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationResultTableViewController.h"
#import "LocationMenu.h"
#import "ExternalDataLoader.h"

@interface NearByMeResult : BaseViewController <UITableViewDataSource, UITableViewDelegate>
{
    ExternalDataLoader *externalDataLoader;
    
    LocationMenu *locationMenu;
    NSArray *arrayData;
    BOOL isDisableDisclosureButton;
    
    OEMLocation *locationStart;
    OEMLocation *locationEnd;

    int myCatID;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewResult;
@property (strong, nonatomic) IBOutlet UILabel *lblTableViewMessage;

-(void)setData:(NSArray *)data;
-(void)disableDisclosureButton:(BOOL)isDisable;

- (void)loadNearbyResult;
- (void)onExternalDataReturn:(NSNotification *)notification;

@end
