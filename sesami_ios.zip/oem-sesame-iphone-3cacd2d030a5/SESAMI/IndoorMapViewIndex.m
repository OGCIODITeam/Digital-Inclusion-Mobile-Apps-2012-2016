	  //
//  IndoorMapViewIndex.m
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "IndoorMapViewIndex.h"
#import "OEMDB.h"
#import "IndoorDB.h"
#import "AppDelegate.h"
#import "ZipArchive.h"

#include <sys/xattr.h>

@implementation IndoorMapViewIndex

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self)
  {
      [IndoorDB initDB];
      

    [self disableDisclosureButton:YES];
  }
  return self;
}

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
  self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
  if (self)
  {
    int catID = [[self.myExtraData objectForKey:@"catID"] intValue];
      prefs = [NSUserDefaults standardUserDefaults];

    NSLog(@"catID: %i", catID);
    
      arrayData = [[NSArray alloc] initWithArray:[IndoorDB getAllIndoorMapsWithCatIDDownloaded :catID:[prefs objectForKey:@"mapList"]]];
    [self disableDisclosureButton:YES];
  }
  return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
//    {
//        [self.tableViewIndoor setContentInset:UIEdgeInsetsMake(-40, self.tableViewIndoor.contentInset.left, self.tableViewIndoor.contentInset.bottom, self.tableViewIndoor.contentInset.right)];
//    }

    
}

- (void)viewWillAppear:(BOOL)animated
{
   
  self.title = @"室內地圖";
    int catID = [[self.myExtraData objectForKey:@"catID"] intValue];
    
    NSLog(@"catID: %i", catID);
    
     arrayData = [[NSArray alloc] initWithArray:[IndoorDB getAllIndoorMapsWithCatIDDownloaded :catID:[prefs objectForKey:@"mapList"]]];
    [self disableDisclosureButton:YES];

    
  [self.tableViewIndoor reloadData];
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:NO LeftTitle:@""
   ShowRight:NO RightTitle:@"管理"];
}

-(void)setData:(NSArray *)data{
  arrayData = data;
}

-(void)disableDisclosureButton:(BOOL)isDisable{
  isDisableDisclosureButton = isDisable;
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
  return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
  }
  if(!isDisableDisclosureButton){
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
  }
  // Configure the cell...
  UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
  CGRect frame = iv.frame;
  frame.origin = cell.frame.origin;
  frame.size = cell.frame.size;
  frame.size.height = 60;
  iv.frame = frame;
  cell.backgroundView = iv;
  cell.textLabel.text = [(OEMMap *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
  cell.textLabel.backgroundColor = [UIColor clearColor];
  
  cell.accessibilityValue = [(OEMMap *)[arrayData objectAtIndex:[indexPath row]] getDescription];
  
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  NSString *mapIdStr = [NSString stringWithFormat:@"%i",((OEMMap *)[arrayData objectAtIndex:[indexPath row]]).mapID];
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  [extraData setValue:mapIdStr forKey:@"mapID"];
  
  floorPlanListingResult = [[FloorPlanListingResult alloc] initWithNavigationController:self.navigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:floorPlanListingResult animated:YES];
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

#pragma mark - MainNavigation

- (void)btnNavRight_Click:(id)sender
{
    /*
  //    [self requestCreateZip];
  UIAlertView *alert = [[UIAlertView alloc] init];
  //  [alert setTitle:@"Confirm"];
  [alert setMessage:@"下載室內地圖?"];
  [alert setDelegate:self];
  [alert addButtonWithTitle:@"確定"];
  [alert addButtonWithTitle:@"取消"];
  [alert show];*/
    //if (mapManagementViewController == nil)
    //{
    [prefs setInteger:0 forKey:@"mapManagementTab"];
        mapManagementViewController = [[MapManagment alloc]initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:nil];
    //}
    [self.myNavigationController pushViewController:mapManagementViewController animated:YES];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
  if (buttonIndex == 0)
  {
    [self requestCreateZip];
  }
}

- (void)requestCreateZip
{
  // Get the version number
  NSString * mapVersion = [GlobalVar getIndoorMapVersion];

  currentCallStatus = @"REQUEST_CREATE_ZIP";
  UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, @"開始下載，請稍候片刻");
  
  responseData = [[NSMutableData alloc] init];  // remember to clear this
  
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
  
  //  NSString *url = @"http://59.188.119.162/hkbu/indoor/makePackage.php";
   NSString *url = @"http://sesame.hkbu.org.hk/hkbu/indoor/makePackage.php";
//  NSString *url = @"http://develop-ext.oem-interactive.com/hkbu/indoor/makePackage.php";
  
  if (mapVersion) {
    url = [url stringByAppendingString:[@"?version=" stringByAppendingString:mapVersion]];
  }
  NSLog(@"URL - %@", url);
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
  NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [conn description];  // what for?
}

- (void)requestDownloadZip
{
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
  [self download];
}

- (void)download
{
  _isCompleted = NO;
  
	currentCallStatus = @"DOWNLOADING_ZIP";
  
  //	NSString* url = @"http://59.188.119.162/hkbu/indoor/package.zip";
	NSString* url = @"http://sesame.hkbu.org.hk/hkbu/indoor/package.zip";
//	NSString* url = @"http://develop-ext.oem-interactive.com/hkbu/indoor/package.zip";
	NSLog(@"downloading...");
	NSURL *myURL = [NSURL URLWithString:url];
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:myURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60];
	[[NSURLConnection alloc] initWithRequest:request delegate:self];
	NSLog(@"downloaded!");
}

- (void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
  NSLog(@"received response");
  if ([currentCallStatus isEqualToString:@"REQUEST_CREATE_ZIP"])
  {
    NSLog(@"create zip - response");
  
    // Need to check if needed to download the zip file
    responseData = [[NSMutableData alloc] init];
    NSLog(@"%lld", [response expectedContentLength]);
    if ([response expectedContentLength] > 1) {
      [self requestDownloadZip];
    } else {
      NSLog(@"No need to download");
      UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, @"已是最新版本,下載完成");
      [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
    }
  }
  else if ([currentCallStatus isEqualToString:@"DOWNLOADING_ZIP"])
  {
    responseData = [[NSMutableData alloc] init];
    _totalFileSize = (float)[response expectedContentLength];
    _receivedFileSize = 0;
  }
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
  if ([currentCallStatus isEqualToString:@"REQUEST_CREATE_ZIP"])
  {
//    NSLog(@"create zip - data");
//    [self requestDownloadZip];
  }
  else if ([currentCallStatus isEqualToString:@"DOWNLOADING_ZIP"])
  {
    _receivedFileSize += [data length];
    [responseData appendData:data];
  }
}

- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	NSLog(@"Error");
}

- (void) connectionDidFinishLoading:(NSURLConnection *)connection
{
  NSString *fileInFolder;
  NSError *error;
  
  if ([currentCallStatus isEqualToString:@"DOWNLOADING_ZIP"])
  {
    NSLog(@"Finish Download (file size : %d )",[responseData length]);
    
    AppDelegate *s = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSString *filePath = [NSString stringWithFormat:@"%@/%@.zip", s.documentsDir, @"package"];
    if ([responseData length] == 0) {
      NSLog(@"no data, no need to do anything");
      return;
    }
    NSLog(@"start writing file");
    [responseData writeToFile:filePath atomically:YES];
    NSLog(@"finished writing file");
    
    
    ZipArchive *za = [[ZipArchive alloc] init];
    NSString *unzipFile = filePath;
    
    if( [za UnzipOpenFile:unzipFile])
    {
      _isCompleted = YES;
      
      // Delete all the files in documentsDir
      NSArray *directoryContent = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:s.documentsDir error:NULL];
      for (int i = 0; i < (int)[directoryContent count]; i++)
      {
        NSString *filePath = [NSString stringWithFormat:@"%@/%@", s.documentsDir, [directoryContent objectAtIndex:i]];
        NSLog(@"Deleting %@", filePath);
        if (![[NSFileManager defaultManager] removeItemAtPath:filePath error:&error])	//Delete it
        {
          NSLog(@"Delete file error: %@", error);
        }
      }
      
      NSLog(@"start unzipping");
      BOOL ret = [za UnzipFileTo:s.documentsDir overWrite:YES];
      if(ret == NO){
        NSLog(@"unable to unzip");
      }
      [za UnzipCloseFile];
      NSLog(@"finished unzipping");
      
      // Check for presence of version file
      directoryContent = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:s.documentsDir error:NULL];
      for (int i = 0; i < (int)[directoryContent count]; i++)
      {
        fileInFolder = [directoryContent objectAtIndex:i];
        NSLog(@"File in folder - %@", fileInFolder);
        if ([fileInFolder rangeOfString:@".ver"].location != NSNotFound) {
          NSString *versionNum = [fileInFolder substringToIndex:[fileInFolder length]-4];
          NSLog(@"Version is %@", versionNum);
          [GlobalVar setIndoorMapVersion:versionNum];
        }
      }
      
      [IndoorDB initDB];
      NSLog(@"finished initing");
      
      [self setData:[[NSArray alloc] initWithArray:[IndoorDB getAllIndoorMaps]]];
      [self.tableViewIndoor reloadData];
      NSLog(@"all done");
      
      
      [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
      UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, @"下載完成");
      
    }
    else
    {
      //NSLog(@"no file to unzip");
    }
    
    [self excludeFolder];
  }
}

- (void) excludeFolder
{
  
  NSString *docsDir = [NSHomeDirectory() stringByAppendingPathComponent:  @"Documents"];
  NSFileManager *localFileManager=[[NSFileManager alloc] init];
  NSDirectoryEnumerator *dirEnum =
  [localFileManager enumeratorAtPath:docsDir];
  
  NSString *file;
  while (file = [dirEnum nextObject]) {
    NSURL *tempUrl =  [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@",docsDir,file]];
    [self addSkipBackupAttributeToItemAtURL:tempUrl];
  }
  
  
}

- (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
  if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.1) {
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    
    
    NSError *error = nil;
    
    BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                    
                                  forKey: NSURLIsExcludedFromBackupKey error: &error];
    
    if(!success){
      
      NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
      
    }
    
    return success;
  }
  else {
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    
    
    const char* filePath = [[URL path] fileSystemRepresentation];
    
    
    
    const char* attrName = "com.apple.MobileBackup";
    
    u_int8_t attrValue = 1;
    
    
    
    int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
    
    return result == 0;
  }
  
}

@end
