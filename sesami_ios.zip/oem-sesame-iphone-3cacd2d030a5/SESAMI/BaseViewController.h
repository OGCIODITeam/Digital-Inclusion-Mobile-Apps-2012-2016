//
//  BaseViewController.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainNavigationController.h"

@interface BaseViewController : UIViewController
{
    NSTimer *refreshTimer;
}

@property (strong, nonatomic) UINavigationController *myNavigationController;
@property (strong, nonatomic) UIViewController *myParentViewController;
@property (strong, nonatomic) NSMutableDictionary *myExtraData;

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data;

- (void)btnNavLeft_Click:(id)sender;
- (void)btnNavRight_Click:(id)sender;
- (void)btnMainMenu_Click:(id)sender;

- (NSString *)getMySection;

- (void)initAccessiblity;

- (void)startRefreshTimer;
- (void)stopRefreshTimer;
- (void)refreshAction;

@end
