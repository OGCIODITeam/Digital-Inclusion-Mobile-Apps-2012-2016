//
//  AppMessage.h
//  SESAMI
//
//  Created by Daniel Lee on 31/7/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppMessage : NSObject

+(NSString *)getServerDownMSG;
+(NSString *)getNoResultMSG;
+(NSString *)getTooFarAwayMSG;

+(NSString *)errorSameLocation;
+(NSString *)errorMissingLocationStart;
+(NSString *)errorMissingLocationEnd;
+(NSString *)errorEmptyKeyword;

+(NSString *)errorEmptyStreetNameOrNumber;
+(NSString *)errorNegativeStreetNumber;
@end

