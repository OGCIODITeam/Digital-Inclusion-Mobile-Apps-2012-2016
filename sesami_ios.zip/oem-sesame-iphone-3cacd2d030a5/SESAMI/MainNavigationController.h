//
//  MainNavigationController.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainNavigationController : UIViewController <UINavigationControllerDelegate>

@property (strong, nonatomic) IBOutlet UINavigationController *myNavigationController;
@property (strong, nonatomic) IBOutlet UIButton *btnMainMenu;

+ (void)InitNavigationWithController:(UIViewController *)controller ShowLeft:(BOOL)showLeft LeftTitle:(NSString *)leftTitle ShowRight:(BOOL)showRight RightTitle:(NSString *)rightTitle;

+ (void)InitCustomNavigationWithController:(UIViewController *)controller ShowLeft:(BOOL)showLeft LeftTitle:(NSString *)leftTitle ShowRight:(BOOL)showRight RightTitle:(NSString *)rightTitle;

+ (void)InitInformationNavigationWithController:(UIViewController *)controller ShowLeft:(BOOL)showLeft LeftTitle:(NSString *)leftTitle ShowRight:(BOOL)showRight RightTitle:(NSString *)rightTitle;

@end
