//
//  MainTabViewController.h
//  SESAMI
//
//  Created by Ray.Liu on 9/2/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainNavigationController.h"

@interface MainTabViewController : BaseViewController
{
    MainNavigationController *mainNavigation;
    UIViewController *tabViewController;
}

@property (strong, nonatomic) NSString *tabKey;
@property (strong, nonatomic) BaseViewController *firstViewController;

- (void)setTabViewController:(UIViewController *)controller;
- (void)prepareCompleteAction;

@end
