//
//  HowFarResult.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HowFarResult : BaseViewController
{
    IBOutlet UILabel *lblHowFarResult;
    OEMLocation *locationStart;
    OEMLocation *locationEnd;
}

- (void)loadHowFar;
- (IBAction)manualRefresh:(id)sender;

@end
