//
//  SearchingController.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "SearchingController.h"

@implementation SearchingController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"搜尋";
    
    [MainNavigationController
     InitNavigationWithController:self
     ShowLeft:YES LeftTitle:@""
     ShowRight:NO RightTitle:@""];
}

- (IBAction)onClickStartSearch:(id)sender
{
    if([txtSearchText.text isEqualToString:@""])
    {
        [AppFunction quickAlertWithMessage:[AppMessage errorEmptyKeyword] title:@""];
        return;
    }
    
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:txtSearchText.text forKey:@"searchText"];

    searchingResult = [[SearchingResult alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
   
    [self.myNavigationController pushViewController:searchingResult animated:YES];
}

@end
