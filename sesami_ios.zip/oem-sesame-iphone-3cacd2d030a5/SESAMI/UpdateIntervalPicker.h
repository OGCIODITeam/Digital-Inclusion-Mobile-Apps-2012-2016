//
//  UpdateIntervalPicker.h
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateIntervalPicker : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    __weak IBOutlet UITableView *tableViewAlertIntervalOption;
    NSArray *arrayAlertIntervalItems;
    NSArray *arrayAlertIntervalItemsValue;
}

@end
