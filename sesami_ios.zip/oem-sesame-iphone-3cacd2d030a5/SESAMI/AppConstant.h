//
//  AppConstant.h
//  semami
//
//  Created by Daniel Lee on 27/6/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppConstant : NSObject

+(double)getAnimationDuration;
+(NSString *)getLocationPickerCallBackFuncionName;
+(NSString *)getClickResultCallBackName;
+(NSString *)getClickResultDisclosureCallBackName;
+(NSString *)getExternalDataLoaderCallBackName;
+(NSString *)getOpenRiceCallBackName;
+(NSString *)getShowLoadingEventName;
+(NSString *)getHideLoadingEventName;
+(NSString *)getDirectShowViewHowFarCallBackName;
+(NSString *)getDirectShowViewNearbyCallBackName;

+(int)getDefaultZoomLevelForCentamap;
+(double)getLocationDifferentMargin;

+(NSString *)getDirectionChineseFront;
+(NSString *)getDirectionChineseBack;
+(NSString *)getDirectionChineseLeft;
+(NSString *)getDirectionChineseRight;
+ (NSMutableDictionary *)getNavigationButtonFont;
+(CGFloat)getScreenWidth;
+(CGFloat)getScreenHeight;
+(CGFloat)getStatusBarHeight;

+(CGRect)getMainNavigationFrame;
+(CGRect)getTabControllerFrame;
+(CGRect)getContentViewFrame;

+(int)getVirtualWalkCallNumber;

@end



