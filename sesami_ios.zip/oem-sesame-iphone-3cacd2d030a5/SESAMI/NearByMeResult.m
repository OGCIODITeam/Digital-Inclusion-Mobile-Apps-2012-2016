//
//  NearByMeResult.m
//  SESAMI
//
//  Created by Ray.Liu on 9/3/13.
//  Copyright (c) 2013 Daniel Lee. All rights reserved.
//

#import "NearByMeResult.h"

@implementation NearByMeResult

#define NEARBY_CATEGORY_ALL 5000
#define NEARBY_CATEGORY_BUILDING 5001
#define NEARBY_CATEGORY_BUS_STOP 5002
#define NEARBY_CATEGORY_RESTAURANT 5003
#define NEARBY_CATEGORY_LANDMARK 5004

@synthesize tableViewResult;
@synthesize lblTableViewMessage;

- (id)initWithNavigationController:(UINavigationController *)navigationController ParentViewController:(UIViewController *)controller ExtraData:(NSMutableDictionary *)data
{
  self = [super initWithNavigationController:navigationController ParentViewController:controller ExtraData:data];
  if (self)
  {
    locationStart = (OEMLocation *)[self.myExtraData objectForKey:@"locationStart"];
    locationEnd = (OEMLocation *)[self.myExtraData objectForKey:@"locationEnd"];
    myCatID = [[self.myExtraData objectForKey:@"catID"] intValue];
  }
  return self;
}

- (void)viewDidLoad
{
  [super viewDidLoad];
  [self loadNearbyResult];
}

- (void)viewWillAppear:(BOOL)animated
{
  [super viewWillAppear:animated];
  
  if(myCatID == NEARBY_CATEGORY_BUILDING){
    self.title = @"建築物";
  }
  else if(myCatID == NEARBY_CATEGORY_LANDMARK){
    self.title = @"地標";
  }
  else if(myCatID == NEARBY_CATEGORY_BUS_STOP){
    self.title = @"巴士站";
  }
  else if(myCatID == NEARBY_CATEGORY_RESTAURANT){
    self.title = @"餐廳";
  }
  else if(myCatID == NEARBY_CATEGORY_ALL){
    self.title = @"所有";
  }
  
  [MainNavigationController
   InitNavigationWithController:self
   ShowLeft:YES LeftTitle:@""
   ShowRight:NO RightTitle:@""];
}

- (void)onClickResult:(NSNotification *)notification
{
  if(notification.object!=nil)
  {
    NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
    [extraData setValue:([[OEMLocation alloc] initWithName:@"現在的地方" clocation:[GlobalVar getCurrentLocation] address:@""]) forKey:@"startLocation"];
    [extraData setValue:((OEMLocation *)notification.object) forKey:@"endLocation"];
    
    locationMenu = [[LocationMenu  alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
    
    [self.myNavigationController pushViewController:locationMenu animated:YES];
  }
}

-(void)setData:(NSArray *)data
{
  arrayData = data;
}

-(void)disableDisclosureButton:(BOOL)isDisable
{
  isDisableDisclosureButton = isDisable;
}

#pragma mark - UITableView

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
  return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  return [arrayData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
  }
  if(!isDisableDisclosureButton){
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
  }
  // Configure the cell...
  UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tableCellTypeA"]];
  CGRect frame = iv.frame;
  frame.origin = cell.frame.origin;
  frame.size = cell.frame.size;
  frame.size.height = 60;
  iv.frame = frame;
  cell.backgroundView = iv;
  cell.textLabel.text = [(OEMLocation *)[arrayData objectAtIndex:[indexPath row]] getDisplayName];
  cell.textLabel.backgroundColor = [UIColor clearColor];
  
  /*
   cell.accessibilityValue = [AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]];
   
   NSLog(@"YO: %@",[AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]]);
   */
  
  OEMLocation *locationFrom = locationStart;
  OEMLocation *locationTo = (OEMLocation *)[arrayData objectAtIndex:[indexPath row]];
  cell.accessibilityValue = [AppFunction getResultAccessibilityValueFromLocation:locationFrom ToLocation:locationTo];
//  NSLog(@"YO4: %@",[AppFunction getResultAccessibilityValueForLocation:(OEMLocation *)[arrayData objectAtIndex:[indexPath row]]]);
  NSLog(@"YO4: %@",[AppFunction getResultAccessibilityValueFromLocation:locationFrom ToLocation:locationTo]);
  
  return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
  
  NSMutableDictionary *extraData = [[NSMutableDictionary alloc] init];
  
  [extraData setValue:[self getMySection] forKey:@"mySection"];
  [extraData setValue:([[OEMLocation alloc] initWithName:@"現在的地方" clocation:[locationStart getLocationInCCLocation] address:@""]) forKey:@"locationStart"];
  [extraData setValue:((OEMLocation *)[arrayData objectAtIndex:[indexPath row]]) forKey:@"locationEnd"];
  
  locationMenu = [[LocationMenu  alloc] initWithNavigationController:self.myNavigationController ParentViewController:self ExtraData:extraData];
  
  [self.myNavigationController pushViewController:locationMenu animated:YES];
  
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
  
  //[[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getClickResultDisclosureCallBackName] object:[arrayData objectAtIndex:[indexPath row]]];
}

- (void)loadNearbyResult
{
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onExternalDataReturn:) name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
  
  if(externalDataLoader==nil)
  {
    externalDataLoader = [[ExternalDataLoader alloc] init];
  }
  
  if(myCatID == NEARBY_CATEGORY_BUILDING){
    [externalDataLoader centaMapGetNearbyBuildingFromLocation:[locationStart getLocationInCCLocation] radius:500];
  }
  if(myCatID == NEARBY_CATEGORY_LANDMARK){
    [externalDataLoader centaMapGetNearbyLandmarkFromLocation:[locationStart getLocationInCCLocation] zoomLevel:[AppConstant getDefaultZoomLevelForCentamap]];
  }
  if(myCatID == NEARBY_CATEGORY_BUS_STOP){
    [externalDataLoader centaMapGetNearbyBusStopFromLocation:[locationStart getLocationInCCLocation] zoomLevel:[AppConstant getDefaultZoomLevelForCentamap]];
  }
  if(myCatID == NEARBY_CATEGORY_RESTAURANT){
    [externalDataLoader openRiceGetNearbyRestaurantFromLocation:[locationStart getLocationInCCLocation] radius:500];
  }
  if(myCatID == NEARBY_CATEGORY_ALL){
    [externalDataLoader centaMapGetNearbyALLFromLocation:[locationStart getLocationInCCLocation] radius:500 zoomLevel:[AppConstant getDefaultZoomLevelForCentamap]];
  }
  
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getShowLoadingEventName] object:nil];
}

- (void)onExternalDataReturn:(NSNotification *)notification
{
  NSString * currentFunction = [GlobalVar getCurrentFunction];
  
  [[NSNotificationCenter defaultCenter] removeObserver:self name:[AppConstant getExternalDataLoaderCallBackName] object:nil];
  
  [[NSNotificationCenter defaultCenter] postNotificationName:[AppConstant getHideLoadingEventName] object:nil];
  
  BOOL isAllDirection = ![GlobalVar getAutoUpdateIndoorMap];  // using AutoUpdateIndoorMap as flag for whether forward or all directions
  NSLog(@"Is all direction - %hhd", isAllDirection);
  
  if([notification.object isKindOfClass:[NSError class]])
  {
    [tableViewResult setHidden:YES];
    [lblTableViewMessage setText:[AppMessage getServerDownMSG]];
    [lblTableViewMessage setHidden:NO];
  }
  else
  {
    NSDictionary *json = (NSDictionary *)notification.object;
    
    if ([json count]==0)
    {
      [tableViewResult setHidden:YES];
      [lblTableViewMessage setText:[AppMessage getNoResultMSG]];
      [lblTableViewMessage setHidden:NO];
    }
    else
    {
      
      [tableViewResult setHidden:NO];
      [lblTableViewMessage setHidden:YES];
      
      // CLLocation *cLocation = [GlobalVar getCurrentLocation];  // Should not always use the current location to calculate distance for sorting
      CLLocation *cLocation = [locationStart getLocationInCCLocation];

      //notification.object saved the array of researched location
      //put create OEMLocation for all locations and push into arrayLocation
      NSMutableArray *arrayLocationForSort = [[NSMutableArray alloc] init];
      NSMutableArray *arrayLocation = [[NSMutableArray alloc] init];
      
      for(NSDictionary *node in (NSArray *)[json objectForKey:@"Table"]){
        CLLocation *nLocation = [[CLLocation alloc] initWithLatitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"]doubleValue]];
        OEMLocation *location;
        
        if([[node objectForKey:@"rid"] isEqual:nil] || ([node objectForKey:@"rid"]==NULL))
        {
          location = [[OEMLocation alloc] initWithName:[node objectForKey:@"displayname"] latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:[node objectForKey:@"displayaddr"]];
          NSLog(@"Raw from CM - %@", location.displayName);
        }
        else
        {
          //is bus
          NSString *busStopDisplayName = [[NSString alloc] initWithFormat:@"%@:往%@",[node objectForKey:@"namec"],[node objectForKey:@"tnamec"]];
          location = [[OEMLocation alloc] initWithName:busStopDisplayName latitude:[[node objectForKey:@"lpt_y"] doubleValue] longitude:[[node objectForKey:@"lpt_x"] doubleValue] address:@""];
        }
        
        NSString *directionStr = [AppFunction getResultAccessibilityValueForLocation:location];
        NSLog(@"Direction - %@", directionStr);
        
        if (isAllDirection || ![currentFunction isEqualToString:@"whereami"] || ([directionStr rangeOfString:@"前面"].location != NSNotFound)) {
          NSArray *arrNode = [[NSArray alloc] initWithObjects:[NSNumber numberWithDouble:[nLocation distanceFromLocation:cLocation]], location, nil];
          NSLog(@"Selected - %f", [nLocation distanceFromLocation:cLocation]);
          [arrayLocationForSort addObject:arrNode];
        }
      }

      if ([arrayLocationForSort count] == 0) {
        [tableViewResult setHidden:YES];
        [lblTableViewMessage setText:[AppMessage getNoResultMSG]];
        [lblTableViewMessage setHidden:NO];
      } else {
        NSArray *arrayLocationSorted = [arrayLocationForSort sortedArrayUsingComparator:^(id a, id b){
          return [[a objectAtIndex:0] compare:[b objectAtIndex:0]];
        }];
        
//        NSLog(@"%@", arrayLocationSorted);
        if (myCatID == NEARBY_CATEGORY_BUILDING || myCatID == NEARBY_CATEGORY_RESTAURANT)
        {
          for(int c=0; (c<[GlobalVar getNearByBuildingDisplayTotal] && c<[arrayLocationSorted count]); c++)
          {
            [arrayLocation addObject:[[arrayLocationSorted objectAtIndex:c] objectAtIndex:1 ]];
            NSLog(@"Sorted - %@", ((OEMLocation *)[[arrayLocationSorted objectAtIndex:c] objectAtIndex:1 ]).displayName);
          }
        }
        else
        {
          for(NSArray *node in arrayLocationSorted)
          {
            [arrayLocation addObject:[node objectAtIndex:1]];
          }
        }
        
        [self setData:arrayLocation];
        [self disableDisclosureButton:YES];
        [tableViewResult reloadData];
      }
    }
  }
  
  //[self startRefreshTimer];
}

- (void)refreshAction
{
  NSString * currentFunction = [GlobalVar getCurrentFunction];

  if ([currentFunction isEqualToString:@"whereami"]) {
    [self loadNearbyResult];
  }
}

@end
