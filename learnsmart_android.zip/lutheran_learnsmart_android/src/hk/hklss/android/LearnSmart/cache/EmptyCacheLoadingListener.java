package hk.hklss.android.LearnSmart.cache;

import java.io.File;

public class EmptyCacheLoadingListener implements CacheLoadingListener {

	@Override
	public void onLoadingStarted(String fileUri) {
	}

	@Override
	public void onLoadingFailed(String fileUri, String reason) {
	}

	@Override
	public void onLoadingComplete(String fileUri, File loadedFile) {
	}

	@Override
	public void onLoadingCancelled(String fileUri) {
	}

}
