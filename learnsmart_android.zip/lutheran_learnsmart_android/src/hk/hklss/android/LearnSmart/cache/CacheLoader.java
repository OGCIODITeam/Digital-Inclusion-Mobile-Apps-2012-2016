package hk.hklss.android.LearnSmart.cache;

import java.util.HashMap;
import java.util.Map;

import hk.hklss.android.LearnSmart.cache.disc.DiscCache;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

public class CacheLoader {

	public static final String TAG = CacheLoader.class.getSimpleName();
	
	private Map<String, CacheLoaderConfiguration> configurationMap;
	
	private final CacheLoadingListener emptyListener = new EmptyCacheLoadingListener();
	private LoadFileTask loadFileTask;
	
	private volatile static CacheLoader instance;
	
	public static CacheLoader getInstance() {
		if (instance == null) {
			synchronized (CacheLoader.class) {
				if (instance == null) {
					instance = new CacheLoader();
				}
			}
		}
		
		return instance;
	}

	protected CacheLoader() {
	}
	
	public synchronized void init(String tag, CacheLoaderConfiguration configuration) {
		if (configuration == null) {
			throw new IllegalArgumentException("ERROR_INIT_CONFIG_WITH_NULL");
		}
		if (this.configurationMap == null) {
			this.configurationMap = new HashMap<String, CacheLoaderConfiguration>();
		}
		if (this.configurationMap.containsKey(tag)) {
			this.configurationMap.remove(tag);
		}
		this.configurationMap.put(tag, configuration);
	}

	public boolean isInited() {
		return configurationMap != null && !configurationMap.isEmpty();
	}
	
	private void checkConfiguration() {
		if (!isInited()) {
			throw new IllegalStateException("ERROR_NOT_INIT");
		}
	}
	
	private void checkConfiguration(String configTag) {
		checkConfiguration();
		if (!hasConfigurationTag(configTag)) {
			throw new IllegalStateException("ERROR_NOT_INIT");
		}
	}
	
	public void load(String configTag, String uri, Context context, CacheLoadingListener listener) {
		checkConfiguration(configTag);
		
		if (listener == null) {
			listener = emptyListener;
		}
		
		if (uri == null || uri.length() == 0) {
			listener.onLoadingStarted(uri);
			listener.onLoadingComplete(uri, null);
			return;
		}
		
		CacheLoaderConfiguration configuration = getConfiguration(configTag);

		CacheLoadingInfo fileLoadingInfo = new CacheLoadingInfo(uri, listener);
		loadFileTask = new LoadFileTask(context, configuration, fileLoadingInfo);
		loadFileTask.execute();
	}
	
	private boolean hasConfigurationTag(String configTag) {
		return configurationMap.containsKey(configTag);
	}
	
	private CacheLoaderConfiguration getConfiguration(String configTag) {
		return configurationMap.get(configTag);
	}
	
	public DiscCache getDiscCache(String configTag) {
		checkConfiguration();
		
		CacheLoaderConfiguration configuration = getConfiguration(configTag);
		
		return (configuration == null ? null : configuration.discCache);
	}
	
	public void clearDiscCache(String configTag) {
		checkConfiguration();
		
		DiscCache discCache = getDiscCache(configTag);
		
		if (discCache != null) {
			discCache.clear();
		}
	}
	
	public void pause() {
//		loadFileTask.pause();
	}

	public void resume() {
//		loadFileTask.resume();
	}

	public void stop() {
		loadFileTask.cancel(true);
	}
}
