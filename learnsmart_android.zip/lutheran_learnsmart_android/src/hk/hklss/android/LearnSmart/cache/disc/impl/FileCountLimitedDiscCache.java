package hk.hklss.android.LearnSmart.cache.disc.impl;

import hk.hklss.android.LearnSmart.cache.DefaultConfigurationFactory;
import hk.hklss.android.LearnSmart.cache.disc.LimitedDiscCache;
import hk.hklss.android.LearnSmart.cache.naming.FileNameGenerator;

import java.io.File;

public class FileCountLimitedDiscCache extends LimitedDiscCache {
	
	public FileCountLimitedDiscCache(File cacheDir, int maxFileCount) {
		this(cacheDir, DefaultConfigurationFactory.createFileNameGenerator(), maxFileCount);
	}

	public FileCountLimitedDiscCache(File cacheDir, FileNameGenerator fileNameGenerator, int maxFileCount) {
		super(cacheDir, fileNameGenerator, maxFileCount);
	}

	@Override
	protected int getSize(File file) {
		return 1;
	}
}
