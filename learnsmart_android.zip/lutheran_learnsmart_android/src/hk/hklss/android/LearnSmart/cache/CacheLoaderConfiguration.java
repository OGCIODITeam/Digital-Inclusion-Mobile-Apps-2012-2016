package hk.hklss.android.LearnSmart.cache;

import hk.hklss.android.LearnSmart.cache.disc.DiscCache;
import hk.hklss.android.LearnSmart.cache.naming.FileNameGenerator;
import android.content.Context;
import android.util.Log;

public final class CacheLoaderConfiguration {
	
	final Context context;

	final DiscCache discCache;
	final CacheLoadingOptions cacheLoadingOptions;
	final boolean showProgressDialog;
	
	private CacheLoaderConfiguration(final Builder builder) {
		context = builder.context;
		
		discCache = builder.discCache;
		cacheLoadingOptions = builder.cacheLoadingOptions;
		showProgressDialog = builder.showProgressDialog;
	}

	public static CacheLoaderConfiguration createDefault(Context context) {
		return new Builder(context).build();
	}

	public static class Builder {

		private Context context;

		private int discCacheSize = 0;
		private int discCacheFileCount = 0;
		private boolean showProgressDialog = true;

		private DiscCache discCache = null;
		private FileNameGenerator fileNameGenerator = null;
		private CacheLoadingOptions cacheLoadingOptions = null;
		
		public Builder(Context context) {
			this.context = context.getApplicationContext();
		}
		
		public Builder discCacheSize(int maxCacheSize) {
			if (maxCacheSize <= 0) 
				throw new IllegalArgumentException("maxCacheSize must be a positive number");
			if (discCache != null) 
				Log.w("", "WARNING_DISC_CACHE_ALREADY_SET");
			if (discCacheFileCount > 0) 
				Log.w("", "WARNING_OVERLAP_DISC_CACHE_FILE_COUNT");

			this.discCacheSize = maxCacheSize;
			return this;
		}

		public Builder discCacheFileCount(int maxFileCount) {
			if (maxFileCount <= 0) 
				throw new IllegalArgumentException("maxFileCount must be a positive number");
			if (discCache != null) 
				Log.w("", "WARNING_DISC_CACHE_ALREADY_SET");
			if (discCacheSize > 0) 
				Log.w("", "WARNING_OVERLAP_DISC_CACHE_SIZE");

			this.discCacheSize = 0;
			this.discCacheFileCount = maxFileCount;
			return this;
		}
		
		public Builder discCache(DiscCache discCache) {
			if (discCacheSize > 0) 
				Log.w("", "WARNING_OVERLAP_DISC_CACHE_SIZE");
			if (discCacheFileCount > 0) 
				Log.w("", "WARNING_OVERLAP_DISC_CACHE_FILE_COUNT");
			if (fileNameGenerator != null) 
				Log.w("", "WARNING_OVERLAP_DISC_CACHE_FILE_NAME_GENERATOR");

			this.discCache = discCache;
			return this;
		}

		public Builder fileNameGenerator(FileNameGenerator fileNameGenerator) {
			if (discCache != null) 
				Log.w("", "WARNING_DISC_CACHE_ALREADY_SET");

			this.fileNameGenerator = fileNameGenerator;
			return this;
		}
		
		public Builder defaultCacheLoadingOptions(CacheLoadingOptions cacheLoadingOptions) {
			this.cacheLoadingOptions = cacheLoadingOptions;
			return this;
		}
		
		public Builder showProgressDialogOnLoading(boolean isShow) {
			this.showProgressDialog = isShow;
			return this;
		}

		public CacheLoaderConfiguration build() {
			initEmptyFieldsWithDefaultValues();
			return new CacheLoaderConfiguration(this);
		}

		private void initEmptyFieldsWithDefaultValues() {
			if (discCache == null) {
				if (fileNameGenerator == null) {
					fileNameGenerator = DefaultConfigurationFactory.createFileNameGenerator();
				}
				discCache = DefaultConfigurationFactory.createDiscCache(context, fileNameGenerator, discCacheSize, discCacheFileCount);
			}
			if (cacheLoadingOptions == null) {
				cacheLoadingOptions = CacheLoadingOptions.createSimple();
			}
		}
	}
}
