package hk.hklss.android.LearnSmart.cache;

import android.net.Uri;

public class CacheLoadingInfo {
		
	final String uri;
	final CacheLoadingListener listener;

	public CacheLoadingInfo(String uri, CacheLoadingListener listener) {
		this.uri = Uri.encode(uri, "@#&=*+-_.,:!?()/~'%");
		this.listener = listener;
	}
}
