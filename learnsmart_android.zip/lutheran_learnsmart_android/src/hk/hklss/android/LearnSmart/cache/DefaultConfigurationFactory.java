package hk.hklss.android.LearnSmart.cache;

import hk.hklss.android.LearnSmart.cache.disc.DiscCache;
import hk.hklss.android.LearnSmart.cache.disc.impl.FileCountLimitedDiscCache;
import hk.hklss.android.LearnSmart.cache.disc.impl.TotalSizeLimitedDiscCache;
import hk.hklss.android.LearnSmart.cache.disc.impl.UnlimitedDiscCache;
import hk.hklss.android.LearnSmart.cache.naming.FileNameGenerator;
import hk.hklss.android.LearnSmart.cache.naming.HashCodeFileNameGenerator;
import hk.hklss.android.LearnSmart.util.StorageUtils;

import java.io.File;

import android.content.Context;

public class DefaultConfigurationFactory {

	private static final String DEFAULT_CACHE_SUBDIR = "cache";
	
	public static FileNameGenerator createFileNameGenerator() {
		return new HashCodeFileNameGenerator();
	}

	public static DiscCache createDiscCache(Context context, FileNameGenerator discCacheFileNameGenerator, int discCacheSize, int discCacheFileCount) {
		if (discCacheSize > 0) {
			File cacheDir = StorageUtils.getCacheDirectory(context, DEFAULT_CACHE_SUBDIR);
			return new TotalSizeLimitedDiscCache(cacheDir, discCacheFileNameGenerator, discCacheSize);
		} else if (discCacheFileCount > 0) {
			File cacheDir = StorageUtils.getCacheDirectory(context, DEFAULT_CACHE_SUBDIR);
			return new FileCountLimitedDiscCache(cacheDir, discCacheFileNameGenerator, discCacheFileCount);
		} else {
			File cacheDir = StorageUtils.getCacheDirectory(context);
			return new UnlimitedDiscCache(cacheDir, discCacheFileNameGenerator);
		}
	}
}
