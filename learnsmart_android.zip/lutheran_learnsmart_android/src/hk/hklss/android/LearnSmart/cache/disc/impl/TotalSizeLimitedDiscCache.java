package hk.hklss.android.LearnSmart.cache.disc.impl;

import hk.hklss.android.LearnSmart.cache.DefaultConfigurationFactory;
import hk.hklss.android.LearnSmart.cache.disc.LimitedDiscCache;
import hk.hklss.android.LearnSmart.cache.naming.FileNameGenerator;

import java.io.File;

import android.util.Log;

public class TotalSizeLimitedDiscCache extends LimitedDiscCache {

	private static final int MIN_NORMAL_CACHE_SIZE_IN_MB = 2;
	private static final int MIN_NORMAL_CACHE_SIZE = MIN_NORMAL_CACHE_SIZE_IN_MB * 1024 * 1024;

	public TotalSizeLimitedDiscCache(File cacheDir, int maxCacheSize) {
		this(cacheDir, DefaultConfigurationFactory.createFileNameGenerator(), maxCacheSize);
	}

	public TotalSizeLimitedDiscCache(File cacheDir, FileNameGenerator fileNameGenerator, int maxCacheSize) {
		super(cacheDir, fileNameGenerator, maxCacheSize);
		if (maxCacheSize < MIN_NORMAL_CACHE_SIZE) {
			Log.w("", String.format("You set too small disc cache size (less than %1$d Mb)", MIN_NORMAL_CACHE_SIZE_IN_MB));
		}
	}

	@Override
	protected int getSize(File file) {
		return (int) file.length();
	}
}
