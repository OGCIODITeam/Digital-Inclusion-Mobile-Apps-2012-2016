package hk.hklss.android.LearnSmart.cache.naming;

public interface FileNameGenerator {

	public abstract String generate(String fileUri);

}
