package hk.hklss.android.LearnSmart.cache;

public class CacheLoadingOptions {

	private final boolean cacheOnDisc;
	private final boolean shouldShowDialogOnLoading;
	private final Runnable postAction;
	
	private CacheLoadingOptions(Builder builder) {
		cacheOnDisc = builder.cacheOnDisc;
		shouldShowDialogOnLoading = builder.shouldShowDialogOnLoading;
		postAction = builder.postAction;
	}
	
	boolean showDialogOnLoading() {
		return shouldShowDialogOnLoading;
	}
	
	boolean isCacheOnDisc() {
		return cacheOnDisc;
	}
	
	Runnable getPostAction() {
		return postAction;
	}

	public static class Builder {
		
		private boolean shouldShowDialogOnLoading = false;
		private boolean cacheOnDisc = false;
		private Runnable postAction = null;
		
		public Builder showDialogOnLoading() {
			shouldShowDialogOnLoading = true;
			return this;
		}
		
		public Builder cacheOnDisc() {
			cacheOnDisc = true;
			return this;
		}
		
		public Builder postProcessor(Runnable postAction) {
			this.postAction = postAction;
			return this;
		}
		
		public CacheLoadingOptions build() {
			return new CacheLoadingOptions(this);
		}
	}
	
	public static CacheLoadingOptions createSimple() {
		return new Builder().build();
	}
}
