package hk.hklss.android.LearnSmart.cache.disc.impl;

import hk.hklss.android.LearnSmart.cache.DefaultConfigurationFactory;
import hk.hklss.android.LearnSmart.cache.disc.BaseDiscCache;
import hk.hklss.android.LearnSmart.cache.naming.FileNameGenerator;

import java.io.File;

public class UnlimitedDiscCache extends BaseDiscCache {

	public UnlimitedDiscCache(File cacheDir) {
		this(cacheDir, DefaultConfigurationFactory.createFileNameGenerator());
	}

	public UnlimitedDiscCache(File cacheDir, FileNameGenerator fileNameGenerator) {
		super(cacheDir, fileNameGenerator);
	}

	@Override
	public void put(String key, File file) {
	}
}
