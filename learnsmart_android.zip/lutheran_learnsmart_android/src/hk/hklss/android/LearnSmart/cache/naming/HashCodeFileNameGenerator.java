package hk.hklss.android.LearnSmart.cache.naming;

public class HashCodeFileNameGenerator implements FileNameGenerator {

	@Override
	public String generate(String fileUri) {
		return String.valueOf(fileUri.hashCode());
	}
	
}
