package hk.hklss.android.LearnSmart.cache;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.cache.disc.DiscCache;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

public class LoadFileTask extends AsyncTask<Void, Integer, File> {

	private static final String TAG = LoadFileTask.class.getSimpleName();
	
	protected int bufferSize = 8 * 1024; // 8KB
	protected ProgressDialog progressDialog;
	
	final CacheLoadingInfo info;
	final Context context;
	final DiscCache discCache;
	final CacheLoaderConfiguration configuration;
	
	private long targetFileSize;
	private String errorMessage = null;
	
	public LoadFileTask(Context context, CacheLoaderConfiguration configuration, CacheLoadingInfo info) {
		this.configuration = configuration;
		this.info = info;
		this.context = context;
		this.discCache = configuration.discCache;
	}
	
	@SuppressLint("NewApi")
	@Override
	protected void onPreExecute() {
		if (configuration.showProgressDialog) {
			progressDialog = new ProgressDialog(context);
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(false);
			progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			progressDialog.setMessage(context.getString(R.string.dialog_loading_message));
			
			if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
				progressDialog.setProgressNumberFormat("");
			}
			
			progressDialog.setMax(100);
			progressDialog.show();
		}
		
		info.listener.onLoadingStarted(info.uri);
		
		super.onPreExecute();
	}

	@Override
	protected File doInBackground(Void... args) {
		File targetFile = null;
		
		try {
			targetFile = discCache.get(info.uri);
			
			if (targetFile != null && targetFile.exists()) {
				targetFileSize = targetFile.length();
				publishProgress(100);
			} else {
				File cacheDir = targetFile.getParentFile();
				if (!cacheDir.exists()) {
					cacheDir.mkdirs();
				}
				
				URL url = new URL(info.uri);
				URLConnection connection = url.openConnection();
				connection.connect();
            
				targetFileSize = connection.getContentLength();

	            InputStream inStream = new BufferedInputStream(url.openStream());
	            OutputStream outStream = new FileOutputStream(targetFile);

	            byte buffer[] = new byte[bufferSize];
	            int count;
	            long downloadedSize = 0;
	            
	            while ((count = inStream.read(buffer)) != -1) {
	            	downloadedSize += count;
	                publishProgress((int) (downloadedSize * 100 / targetFileSize));
	                outStream.write(buffer, 0, count);
	                
	                if (isCancelled()) {
	                	break;
	                }
	            }
	
	            outStream.flush();
	            outStream.close();
	            inStream.close();
			}
        } catch (Exception e) {
        	Log.e(TAG, e.getMessage(), e);
        	errorMessage = e.getMessage();
        }
		
		return targetFile;
	}

	@Override
	protected void onProgressUpdate(Integer... values) {
		if (configuration.showProgressDialog && progressDialog != null) {
			progressDialog.setProgress(values[0]);
		}
		
		super.onProgressUpdate(values);
	}

	@Override
	protected void onPostExecute(File file) {
		if (file != null && file.exists()) {
			if (file.length() == targetFileSize) {
				info.listener.onLoadingComplete(info.uri, file);
			} else {
				if (errorMessage == null) {
					errorMessage = "Mismatched file size";
				}
				file.delete();
			}
		} else {
			if (errorMessage == null) {
				errorMessage = "File cannot be downloaded";
			}
		}
		
		if (errorMessage != null) {
			info.listener.onLoadingFailed(info.uri, errorMessage);
		}
		
		if (configuration.showProgressDialog && progressDialog != null) {
			progressDialog.dismiss();
		}
		
		super.onPostExecute(file);
	}
	
	@Override
	protected void onCancelled() {
		info.listener.onLoadingCancelled(info.uri);
		
		File file = discCache.get(info.uri);
		if (file != null && file.exists()) {
			file.delete();
		}
		
		if (configuration.showProgressDialog && progressDialog != null) {
			progressDialog.dismiss();
		}
		
		super.onCancelled();
	}
}