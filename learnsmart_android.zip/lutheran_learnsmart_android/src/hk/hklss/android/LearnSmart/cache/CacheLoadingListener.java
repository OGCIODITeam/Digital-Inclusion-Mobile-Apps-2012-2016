package hk.hklss.android.LearnSmart.cache;

import java.io.File;

public interface CacheLoadingListener {

	void onLoadingStarted(String fileUri);

	void onLoadingFailed(String fileUri, String reason);

	void onLoadingComplete(String fileUri, File loadedFile);

	void onLoadingCancelled(String fileUri);
	
}
