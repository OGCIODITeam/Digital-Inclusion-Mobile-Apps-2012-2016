package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.TrainingDetails;
import hk.hklss.android.LearnSmart.util.DateUtils;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class TrainingDetailsActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingDetailsActivity.class.getSimpleName();
	public static final String KEY_TRAINING_ID = "TrainingDetailsActivity.trainingId";
	
	private ImageButton backButton;
	private TextView trainingTitle;
	private TextView trainingCategoryTitle;
	private TextView trainingBackground;
	private TextView trainingProfileName;
	private TextView trainingTutorName;
	private TextView trainingStartDate;
	private TextView trainingEndDate;
	private TextView trainingLongTermTarget;
	private TextView trainingShortTermTarget;
	
	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loadingProgressDialog;
	
	private MobileLogin login;
	private TrainingDetails trainingDetails;
	private int trainingId;
	
	private Handler handler = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_details);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
		
		getData();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt(KEY_TRAINING_ID, trainingId);
		
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
		} 
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_TRAINING_ID)) {
				trainingId = bundle.getInt(KEY_TRAINING_ID);
			}
		}
	}
	
	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		trainingTitle = (TextView) findViewById(R.id.trainingTitle);
		trainingCategoryTitle = (TextView) findViewById(R.id.trainingCategoryTitle);
		trainingBackground = (TextView) findViewById(R.id.trainingBackground);
		trainingProfileName = (TextView) findViewById(R.id.trainingProfileName);
		trainingTutorName = (TextView) findViewById(R.id.trainingTutorName);
		trainingStartDate = (TextView) findViewById(R.id.trainingStartDate);
		trainingEndDate = (TextView) findViewById(R.id.trainingEndDate);
		trainingLongTermTarget = (TextView) findViewById(R.id.trainingLongTermTarget);
		trainingShortTermTarget = (TextView) findViewById(R.id.trainingShortTermTarget);
		
		backButton.setOnClickListener(this);
		
		trainingTitle.setText("");
		trainingCategoryTitle.setText("");
		trainingBackground.setText("");
		trainingProfileName.setText("");
		trainingTutorName.setText("");
		trainingStartDate.setText("");
		trainingEndDate.setText("");
		trainingLongTermTarget.setText("");
		trainingShortTermTarget.setText("");
	}
	
	private void getData() {
		showLoadingProgressMessage();
		
		login = getLogin();
		
		getTrainingDetails();
	}
	
	private MobileLogin getLogin() {
		return dataManager.getMobileLogin();
	}
	
	private void getTrainingDetails() {
		trainingDetails = dataManager.getTrainingDetails(login.getUsername(), login.getToken(), trainingId, new DataListener<TrainingDetails>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					hideLoadingProgressMessage();
				}
			}
			
			@Override
			public void onSuccess(TrainingDetails object) {
				trainingDetails = object;
				hideLoadingProgressMessage();
				showData();
			}
			
			@Override
			public void onFailure(String message) {
				hideLoadingProgressMessage();
				showData();
			}
		});
		
		showData();
	}
	
	private void showData() {
		if (trainingDetails != null) {
			trainingTitle.setText(trainingDetails.getTitle() == null ? "" : trainingDetails.getTitle());
			trainingCategoryTitle.setText(trainingDetails.getCategory() == null ? "" : trainingDetails.getCategory());
			trainingBackground.setText(trainingDetails.getBackground() == null ? "" : trainingDetails.getBackground());
			trainingProfileName.setText(trainingDetails.getTraineeName() == null ? "" : trainingDetails.getTraineeName());
			trainingTutorName.setText(trainingDetails.getTutorName() == null ? "" : trainingDetails.getTutorName());
			trainingStartDate.setText(trainingDetails.getStartDate() == null ? "" : DateUtils.formatDate("yyyy-MM-dd", trainingDetails.getStartDate()));
			trainingEndDate.setText(trainingDetails.getEndDate() == null ? "" : DateUtils.formatDate("yyyy-MM-dd", trainingDetails.getEndDate()));
			trainingLongTermTarget.setText(trainingDetails.getLongTermTarget() == null ? "" : trainingDetails.getLongTermTarget());
			trainingShortTermTarget.setText(trainingDetails.getShortTermTarget() == null ? "" : trainingDetails.getShortTermTarget());
		}
	}
	
	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(TrainingDetailsActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}
	
	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}
	
	private void back() {
		finish();
	}

}
