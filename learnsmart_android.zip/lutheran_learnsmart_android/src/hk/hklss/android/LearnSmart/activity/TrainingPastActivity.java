package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.Constants.TrainingListType;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.News;
import hk.hklss.android.LearnSmart.db.model.PastTrainingSessions;
import hk.hklss.android.LearnSmart.util.DateUtils;

import java.util.Collection;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class TrainingPastActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingPastActivity.class.getSimpleName();
	public static final String KEY_TRAINING_ID = "TrainingPastActivity.trainingId";
	
	private ImageButton backButton;
	private ListView pastRecordListView;
	private PastRecordListAdapter pastRecordListAdapter;
	
	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loadingProgressDialog;
	
	private MobileLogin login;
	private List<PastTrainingSessions> pastTrainingSessions;
	private int trainingId;
	
	private Handler handler = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_past);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
		
		getData();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt(KEY_TRAINING_ID, trainingId);
		
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
		} 
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_TRAINING_ID)) {
				trainingId = bundle.getInt(KEY_TRAINING_ID);
			}
		}
	}
	
	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		pastRecordListView = (ListView) findViewById(R.id.pastRecordList);
		
		backButton.setOnClickListener(this);
		
		pastRecordListAdapter = new PastRecordListAdapter(getApplicationContext());
		pastRecordListView.setAdapter(pastRecordListAdapter);
	}
	
	private void getData() {
		showLoadingProgressMessage();
		
		login = getLogin();
		
		getPastTrainingSessions();
	}
	
	private MobileLogin getLogin() {
		return dataManager.getMobileLogin();
	}
	
	private void getPastTrainingSessions() {
		pastTrainingSessions = dataManager.getPastTrainingSessions(login.getUsername(), login.getToken(), trainingId, new DataListener<List<PastTrainingSessions>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					hideLoadingProgressMessage();
				}
			}
			
			@Override
			public void onSuccess(List<PastTrainingSessions> object) {
				pastTrainingSessions = object;
				hideLoadingProgressMessage();
				showData();
			}
			
			@Override
			public void onFailure(String message) {
				hideLoadingProgressMessage();
				showData();
			}
		});
		
		showData();
	}
	
	private void showData() {
		if (pastTrainingSessions != null) {
			pastRecordListAdapter.clear();
			pastRecordListAdapter.addAll(pastTrainingSessions);
			pastRecordListAdapter.notifyDataSetChanged();
		}
	}
	
	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(TrainingPastActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}
	
	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}
	
	private void back() {
		finish();
	}
	
	protected class PastRecordListAdapter extends ArrayAdapter<PastTrainingSessions> {

		private final Context context;
		
		public PastRecordListAdapter(Context context) {
			super(context, R.layout.row_training_past_item);
			this.context = context;
		}
		
		public PastRecordListAdapter(Context context, List<PastTrainingSessions> items) {
			super(context, R.layout.row_training_past_item, items);
			this.context = context;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View rowView = inflater.inflate(R.layout.row_training_past_item, parent, false);
			TextView date = (TextView) rowView.findViewById(R.id.date);
			TextView content = (TextView) rowView.findViewById(R.id.content);
			
			PastTrainingSessions record = getItem(position);
			
			date.setText(DateUtils.formatDate("y-M-d H:m:s", record.getLastUpdated()));
			content.setText(record.getComment());
			
			return rowView;
		}
		

		@Override
		public boolean isEnabled(int position) {
			return false;
		}
		
		@Override
		public void addAll(Collection<? extends PastTrainingSessions> collection) {
			for (PastTrainingSessions n : collection) {
				add(n);
			}
	    }
		
		@Override
		public void addAll(PastTrainingSessions ... items) {
			for (PastTrainingSessions n : items) {
				add(n);
			}
	    }
	}
}
