package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.Constants.GameLevel;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.game.CoinsDataSet;
import hk.hklss.android.LearnSmart.game.GameHelper;
import hk.hklss.android.LearnSmart.util.MathUtils;

import java.math.BigDecimal;
import java.util.ArrayList;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class GameCoinsActivity extends Activity implements View.OnClickListener {

	private final String TAG = GameCoinsActivity.class.getSimpleName();

	public final static String KEY_GAME_LEVEL = "game_level";
	public final static String KEY_GAME_DATA = "game_data";
	public final static String KEY_CAN_PLAY = "can_play";
	public final static String KEY_IS_GAME_STARTED = "is_game_started";
	public final static String KEY_IS_GAME_END = "is_game_end";
	public final static String KEY_CURRENT_GAME_NUM = "current_game_num";
	public final static String KEY_CURRENT_COINS_TOTAL = "current_coins_total";
	public final static String KEY_TARGET_COINS_TOTAL = "target_coins_total";
	public final static String KEY_ELAPSED_TIME = "elapsed_time";

	private final int TOTAL_GAME = 10;

	private AudioManager audioManager;
	private GameLevel gameLevel;
	private ArrayList<CoinsDataSet> gameData;
	private int currentGameNum = 0;
	private float currentCoinsTotal = 0;
	private float targetCoinsTotal = 0;
	private boolean canPlay = false;
	private long elapsedTime = 0;

	private boolean isGameStarted = false;
	private boolean isGameEnd = false;

	private ImageButton backButton;
	private Chronometer timer;

	private ImageView[] coins;
	private ImageView shoppingGirl;
	private TextView targetTotalTextView;
	private TextView currentTotalTextView;
	private RelativeLayout moneyPlateContainer;
	private RelativeLayout playArea;

	private RelativeLayout gameStartAnimContainer;
	private ImageView gameStartImage;

	private RelativeLayout gameEndAnimContainer;
	private ImageView gameEndImage1, gameEndImage2, gameEndImage3, gameEndImage4, gameEndThumbImage;

	private AnimationSet gameStartAnimSet1, gameStartAnimSet2;
	private AnimationSet gameEndAnimSet1, gameEndAnimSet2, gameEndAnimSet3, gameEndAnimSet4, gameEndAnimThumbSet;
	private AnimationDrawable gameGirlAnimation;

//	private Handler handler = new Handler() {
//		@Override
//		public void handleMessage(Message msg) {
//			if (connectedTags.size() >= pairCount) {
//				audioManager.playGameYeah();
//				nextGame();
//			}
//		}
//	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_coins);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();
		initAnimation();
		initGameData();
	}

	@Override
	protected void onStart() {
		super.onStart();
		startGame();
	}

	@Override
	protected void onResume() {
		super.onResume();
		resumeGame();
	}

	@Override
	protected void onPause() {
		super.onPause();
		pauseGame();
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		initFromBundle(savedInstanceState);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);

		if (gameLevel != null) {
			outState.putInt(KEY_GAME_LEVEL, gameLevel.ordinal());
		}
		if (gameData != null) {
			outState.putParcelableArrayList(KEY_GAME_DATA, gameData);
		}

		outState.putBoolean(KEY_CAN_PLAY, canPlay);
		outState.putBoolean(KEY_IS_GAME_STARTED, isGameStarted);
		outState.putBoolean(KEY_IS_GAME_END, isGameEnd);
		outState.putInt(KEY_CURRENT_GAME_NUM, currentGameNum);
		outState.putFloat(KEY_CURRENT_COINS_TOTAL, currentCoinsTotal);
		outState.putFloat(KEY_TARGET_COINS_TOTAL, targetCoinsTotal);

		if (timer != null) {
			outState.putLong(KEY_ELAPSED_TIME, elapsedTime);
		}
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			if (canPlay) {
				audioManager.playPressButton();
			}
		}

		switch (v.getId()) {
			case R.id.backButton:
				if (canPlay) {
					back();
				}
				break;
		}
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void onCreateHoneycomb() {
		HoneycombListener listener = new HoneycombListener();

		for (ImageView coin : coins) {
			coin.setOnTouchListener(listener);
		}

		moneyPlateContainer.setOnDragListener(listener);
	}

	private void onCreateGingerbread() {
		GingerbreadListener listener = new GingerbreadListener();

		for (ImageView coin : coins) {
			coin.setOnTouchListener(listener);
		}
	}

	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_GAME_LEVEL)) {
				int ordinal = bundle.getInt(KEY_GAME_LEVEL);
				gameLevel = GameLevel.values()[ordinal];
			}
			if (bundle.containsKey(KEY_GAME_DATA)) {
				gameData = bundle.getParcelableArrayList(KEY_GAME_DATA);
			}
			if (bundle.containsKey(KEY_CAN_PLAY)) {
				canPlay = bundle.getBoolean(KEY_CAN_PLAY);
			}
			if (bundle.containsKey(KEY_IS_GAME_STARTED)) {
				isGameStarted = bundle.getBoolean(KEY_IS_GAME_STARTED);
			}
			if (bundle.containsKey(KEY_IS_GAME_END)) {
				isGameEnd = bundle.getBoolean(KEY_IS_GAME_END);
			}
			if (bundle.containsKey(KEY_CURRENT_GAME_NUM)) {
				currentGameNum = bundle.getInt(KEY_CURRENT_GAME_NUM);
			}
			if (bundle.containsKey(KEY_CURRENT_COINS_TOTAL)) {
				currentCoinsTotal = bundle.getFloat(KEY_CURRENT_COINS_TOTAL);
			}
			if (bundle.containsKey(KEY_TARGET_COINS_TOTAL)) {
				targetCoinsTotal = bundle.getFloat(KEY_TARGET_COINS_TOTAL);
			}
			if (bundle.containsKey(KEY_ELAPSED_TIME)) {
				elapsedTime = bundle.getLong(KEY_ELAPSED_TIME);
			}
		}
	}

	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}

	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);

		timer = (Chronometer) findViewById(R.id.timer);

		coins = new ImageView[] {
				(ImageView) findViewById(R.id.coinCent10),
				(ImageView) findViewById(R.id.coinCent20),
				(ImageView) findViewById(R.id.coinCent50),
				(ImageView) findViewById(R.id.coinDollar1),
				(ImageView) findViewById(R.id.coinDollar2),
				(ImageView) findViewById(R.id.coinDollar5),
				(ImageView) findViewById(R.id.coinDollar10)
			};

		shoppingGirl = (ImageView) findViewById(R.id.shoppingGirl);
		targetTotalTextView = (TextView) findViewById(R.id.targetTotalTextView);

		currentTotalTextView = (TextView) findViewById(R.id.currentTotalTextView);
		if (Constants.GameLevel.Difficult == gameLevel) {
			// Hide the value of current total coin amount on Difficult level
			currentTotalTextView.setVisibility(View.INVISIBLE);
		} else {
			currentTotalTextView.setVisibility(View.VISIBLE);
		}

		moneyPlateContainer = (RelativeLayout) findViewById(R.id.moneyPlateContainer);
		playArea = (RelativeLayout) findViewById(R.id.playArea);

		gameStartAnimContainer = (RelativeLayout) findViewById(R.id.gameStartAnimContainer);
		gameStartImage = (ImageView) findViewById(R.id.gameStartImage);

		gameEndAnimContainer = (RelativeLayout) findViewById(R.id.gameEndAnimContainer);
		gameEndImage1 = (ImageView) findViewById(R.id.gameEndImage1);
		gameEndImage2 = (ImageView) findViewById(R.id.gameEndImage2);
		gameEndImage3 = (ImageView) findViewById(R.id.gameEndImage3);
		gameEndImage4 = (ImageView) findViewById(R.id.gameEndImage4);
		gameEndThumbImage = (ImageView) findViewById(R.id.gameEndThumbImage);

		gameGirlAnimation = (AnimationDrawable) getResources().getDrawable(R.drawable.game_coins_girl_anim);
		shoppingGirl.setImageDrawable(gameGirlAnimation);
		gameGirlAnimation.setCallback(shoppingGirl);
		gameGirlAnimation.setVisible(true, true);

		if (gameGirlAnimation.isRunning()) {
			gameGirlAnimation.stop();
		}

		backButton.setOnClickListener(this);

		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
			onCreateHoneycomb();
		} else {
			onCreateGingerbread();
		}
	}

	private void initAnimation() {
		initGameStartAnimation();
		initGameEndAnimation();
	}

	private void initGameStartAnimation() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;

		Animation rotateAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.game_start_rotate);

		Animation translateAnim = new TranslateAnimation(0, 0, -screenHeight / 2, 0);
		translateAnim.setDuration(1000);

		gameStartAnimSet1 = new AnimationSet(true);
		gameStartAnimSet1.setDuration(2500);
		gameStartAnimSet1.addAnimation(rotateAnim);
		gameStartAnimSet1.addAnimation(translateAnim);
		gameStartAnimSet1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.playGameStart();
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				gameStartImage.startAnimation(gameStartAnimSet2);
			}
		});

		Animation scaleAnim = new ScaleAnimation(1, 1.5f, 1, 1.5f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		scaleAnim.setDuration(1000);
		scaleAnim.setStartOffset(1000);

		Animation fadeOutAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.game_start_fade_out);
		fadeOutAnim.setDuration(1000);
		fadeOutAnim.setStartOffset(1000);

		gameStartAnimSet2 = new AnimationSet(true);
		gameStartAnimSet2.addAnimation(scaleAnim);
		gameStartAnimSet2.addAnimation(fadeOutAnim);
		gameStartAnimSet2.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.playGameReadyGo();
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				gameStartAnimContainer.setVisibility(View.INVISIBLE);

				timer.setBase(SystemClock.elapsedRealtime());
				timer.start();

				audioManager.playGameBackground();

				canPlay = true;
				isGameStarted = true;
			}
		});
	}

	private void initGameEndAnimation() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;

		Animation translateAnim1 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim1.setDuration(500);
		translateAnim1.setStartOffset(0);

		gameEndAnimSet1 = new AnimationSet(true);
		gameEndAnimSet1.addAnimation(translateAnim1);
		gameEndAnimSet1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.stopBackgroundAudio();
				audioManager.playGameEnd();
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
			}
		});

		Animation translateAnim2 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim2.setDuration(500);
		translateAnim2.setStartOffset(400);

		gameEndAnimSet2 = new AnimationSet(true);
		gameEndAnimSet2.addAnimation(translateAnim2);

		Animation translateAnim3 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim3.setDuration(500);
		translateAnim3.setStartOffset(800);

		gameEndAnimSet3 = new AnimationSet(true);
		gameEndAnimSet3.addAnimation(translateAnim3);

		Animation translateAnim4 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim4.setDuration(500);
		translateAnim4.setStartOffset(1200);

		gameEndAnimSet4 = new AnimationSet(true);
		gameEndAnimSet4.addAnimation(translateAnim4);

		final Animation thumbScaleAnim = new ScaleAnimation(2.0f, 1.0f, 2.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		thumbScaleAnim.setDuration(500);
		thumbScaleAnim.setRepeatCount(4);
		thumbScaleAnim.setRepeatMode(Animation.REVERSE);
		thumbScaleAnim.setFillAfter(true);
		thumbScaleAnim.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				startGameLevelClearActivity();
			}
		});

		Animation thumbTranslateAnim = new TranslateAnimation(-screenWidth, 0, 0, 0);
		thumbTranslateAnim.setDuration(500);
		thumbTranslateAnim.setStartOffset(1600);
		thumbTranslateAnim.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				gameEndThumbImage.startAnimation(thumbScaleAnim);
			}
		});

		gameEndAnimThumbSet = new AnimationSet(true);
		gameEndAnimThumbSet.addAnimation(thumbTranslateAnim);
	}

	private void initGameData() {
		gameData = GameHelper.getCoinsDataSet(gameLevel, TOTAL_GAME);
		currentGameNum = 0;
		currentCoinsTotal = 0f;
	}

	private CoinsDataSet getGameData(int gameNum) {
		return gameData.get(gameNum - 1);
	}

	private void startGame() {
		if (!isGameStarted) {
			gameStartAnimContainer.setVisibility(View.VISIBLE);

			gameStartImage.startAnimation(gameStartAnimSet1);
			nextGame();
		}
	}

	private void resumeGame() {
		if (isGameStarted) {
			if (!isGameEnd) {
				initUIElements();
				initBackend();
				setGameData(currentGameNum);

				timer.setBase(elapsedTime + SystemClock.elapsedRealtime());
				timer.start();
				audioManager.playGameBackground();
			} else {
				startGameLevelClearActivity();
			}
		}
	}

	private void pauseGame() {
		timer.stop();
		elapsedTime = timer.getBase() - SystemClock.elapsedRealtime();
		audioManager.stopBackgroundAudio();
	}

	private void endGame() {
		canPlay = false;
		isGameEnd = true;

		timer.stop();
		elapsedTime = timer.getBase() - SystemClock.elapsedRealtime();

		gameEndAnimContainer.setVisibility(View.VISIBLE);

		gameEndImage1.startAnimation(gameEndAnimSet1);
		gameEndImage2.startAnimation(gameEndAnimSet2);
		gameEndImage3.startAnimation(gameEndAnimSet3);
		gameEndImage4.startAnimation(gameEndAnimSet4);
		gameEndThumbImage.startAnimation(gameEndAnimThumbSet);
	}

	private void nextGame() {
		currentGameNum++;

		if (currentGameNum <= TOTAL_GAME) {
			moneyPlateContainer.removeAllViews();

			setGameData(currentGameNum);

			setCurrentTotal(0f);
		} else {
			endGame();
		}
	}

	private void setGameData(int gameNum) {
		CoinsDataSet data = getGameData(gameNum);

		setTargetTotal(data.getValue());
	}

	private void setCurrentTotal(float value) {
		currentCoinsTotal = value;
		currentTotalTextView.setText("$ " + String.format("%.2f", value));
	}

	private void setTargetTotal(float value) {
		targetCoinsTotal = value;
		targetTotalTextView.setText("$ " + String.format("%.2f", value));
	}

	private void startGameLevelClearActivity() {
		Intent intent = new Intent(this, GameCoinsLevelClearActivity.class);
		intent.putExtra(GameCoinsLevelClearActivity.KEY_GAME_LEVEL, gameLevel.ordinal());
		intent.putExtra(GameCoinsLevelClearActivity.KEY_GAME_ELAPSED_TIME, timer.getText());

		startActivity(intent);
		finish();
	}

	private void back() {
		finish();
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	protected class HoneycombListener implements OnTouchListener, OnDragListener {

		@Override
		public boolean onDrag(View layoutview, DragEvent dragevent) {
			int action = dragevent.getAction();
			ImageView coinView = (ImageView) dragevent.getLocalState();

			switch (action) {
				case DragEvent.ACTION_DRAG_STARTED:
					if (coinView != null) {
						coinView.setVisibility(View.INVISIBLE);
					}
					break;

				case DragEvent.ACTION_DROP:
					float newX = dragevent.getX();
					float newY = dragevent.getY();
					float coinValue = 0f;

					if (coinView != null) {
						coinView.setVisibility(View.VISIBLE);

						if (coinView.getTag() != null) {
							try {
								coinValue = Float.parseFloat(coinView.getTag().toString());
							} catch (NumberFormatException e) {
							}
						}
					}

					if (coinValue <= targetCoinsTotal && coinValue > 0) {
						gameGirlAnimation.stop();

						BigDecimal currentCoinsTotalBd = new BigDecimal(Float.toString(currentCoinsTotal));
						BigDecimal coinValueBd = new BigDecimal(Float.toString(coinValue));
						float sum = currentCoinsTotalBd.add(coinValueBd).floatValue();

						if (sum <= targetCoinsTotal) {
							setCurrentTotal(sum);

							audioManager.playGameCoinDrop();

							dropCoin(coinView, newX, newY);

							if (currentCoinsTotal == targetCoinsTotal) {
								audioManager.playGameYeah();

								gameGirlAnimation.start();

								nextGame();
							}
						} else {
							audioManager.playGameWrongLinked();
						}
					}
					break;

				case DragEvent.ACTION_DRAG_ENDED:
					if (coinView != null) {
						coinView.setVisibility(View.VISIBLE);
					}
					break;

				default:
					break;
			}

			return true;
		}

		@Override
		public boolean onTouch(View view, MotionEvent event) {
			if (!canPlay) {
				return true;
			}

			switch (event.getAction()) {
				case (MotionEvent.ACTION_DOWN):
					DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
					view.startDrag(null, shadowBuilder, view, 0);

					audioManager.playPressButton();
					break;
			}

			return true;
		}

		private void dropCoin(ImageView view, float x, float y) {
			ImageView dropImage = new ImageView(GameCoinsActivity.this);
			dropImage.setImageDrawable(view.getDrawable());
			dropImage.setAdjustViewBounds(true);
			dropImage.setTag(view.getTag());

			int coinHalfWidth = view.getWidth() / 2;
			int coinHalfHeight = view.getHeight() / 2;
			float newX = MathUtils.subtract(x, coinHalfWidth);
			float newY = MathUtils.subtract(y, coinHalfHeight);

			if (x < coinHalfWidth) {
				newX = 0;
			} else if (MathUtils.add(x, view.getWidth()) > moneyPlateContainer.getMeasuredWidth()) {
				newX = MathUtils.subtract(moneyPlateContainer.getMeasuredWidth(), view.getWidth());
			}

			if (y < coinHalfHeight) {
				newY = 0;
			} else if (MathUtils.add(y, view.getHeight()) > moneyPlateContainer.getMeasuredHeight()) {
				newY = MathUtils.subtract(moneyPlateContainer.getMeasuredHeight(), view.getHeight());
			}

			dropImage.setX(newX);
			dropImage.setY(newY);

			RelativeLayout.LayoutParams newLp = new RelativeLayout.LayoutParams(view.getMeasuredWidth(), view.getMeasuredHeight());
			dropImage.setLayoutParams(newLp);

			moneyPlateContainer.addView(dropImage);
		}
	}

	public class GingerbreadListener implements OnTouchListener {

		private ImageView draggingView;
		private ImageView originalView;
		private boolean isDragging = false;

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			boolean eventConsumed = true;

			if (!canPlay) {
				return true;
			}

			int x = (int) event.getRawX();
			int y = (int) event.getRawY();

			int action = event.getAction();

			switch (action) {
				case MotionEvent.ACTION_DOWN:
					for (int i = 0; i < coins.length; i++) {
						if (v == coins[i]) {
							originalView = (ImageView) v;

							draggingView = new ImageView(GameCoinsActivity.this, null);
							draggingView.setImageDrawable(originalView.getDrawable());
							draggingView.setVisibility(View.INVISIBLE);
							playArea.addView(draggingView);

							RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(originalView.getMeasuredWidth(), originalView.getMeasuredHeight());
							params.leftMargin = x - originalView.getMeasuredWidth() / 2;
							params.topMargin = y - originalView.getMeasuredHeight() / 2;

							draggingView.setLayoutParams(params);
							draggingView.setTag(originalView.getTag());

							isDragging = true;

							audioManager.playPressButton();

							break;
						}
					}

					break;

				case MotionEvent.ACTION_UP:
					if (isDragging) {
						boolean isHit = false;
						int newX = 0, newY = 0;

						if (moneyPlateContainer != null) {
							Rect hitRect = new Rect();
							moneyPlateContainer.getHitRect(hitRect);

							int[] screenLocation = new int[2];
							moneyPlateContainer.getLocationOnScreen(screenLocation);

							int dx = screenLocation[0] - moneyPlateContainer.getLeft();
							int dy = screenLocation[1] - moneyPlateContainer.getTop();
							hitRect.offset(dx, dy);

							if (hitRect.contains(x, y)) {
								isHit = true;
								newX = x - screenLocation[0];
								newY = y - screenLocation[1];
							}
						}

						if (isHit) {
							float coinValue = 0f;

							if (draggingView != null && draggingView.getTag() != null) {
								try {
									coinValue = Float.parseFloat(draggingView.getTag().toString());
								} catch (NumberFormatException e) {
								}
							}

							if (coinValue <= targetCoinsTotal && coinValue > 0) {
								gameGirlAnimation.stop();

								float sum = MathUtils.add(currentCoinsTotal, coinValue);

								if (sum <= targetCoinsTotal) {
									setCurrentTotal(sum);

									audioManager.playGameCoinDrop();

									dropCoin(draggingView, newX, newY);

									if (currentCoinsTotal == targetCoinsTotal) {
										audioManager.playGameYeah();

										gameGirlAnimation.start();

										nextGame();
									}
								} else {
									audioManager.playGameWrongLinked();
								}
							}
						} else {
							audioManager.playGameWrongLinked();
						}

						originalView.setVisibility(View.VISIBLE);
					}

					if (draggingView != null) {
						draggingView.setVisibility(View.GONE);
						playArea.removeView(draggingView);
						draggingView = null;
					}

					isDragging = false;

					break;

				case MotionEvent.ACTION_MOVE:
					if (isDragging) {
						originalView.setVisibility(View.INVISIBLE);
						draggingView.setVisibility(View.VISIBLE);

						RelativeLayout.LayoutParams oriParams = (RelativeLayout.LayoutParams) draggingView.getLayoutParams();
						RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(oriParams.width, oriParams.height);
						params.leftMargin = x - oriParams.width / 2;
						params.topMargin = y - oriParams.height / 2;

						draggingView.setLayoutParams(params);
					}
					break;
			}

			return eventConsumed;
		}

		private void dropCoin(ImageView view, int x, int y) {
			ImageView image = new ImageView(GameCoinsActivity.this);
			image.setImageDrawable(view.getDrawable());
			image.setAdjustViewBounds(true);
			image.setTag(view.getTag().toString());

			int coinHalfWidth = view.getWidth() / 2;
			int coinHalfHeight = view.getHeight() / 2;
			float newX = MathUtils.subtract(x, coinHalfWidth);
			float newY = MathUtils.subtract(y, coinHalfHeight);

			if (x < coinHalfWidth) {
				newX = 0;
			} else if (MathUtils.add(x, view.getWidth()) > moneyPlateContainer.getMeasuredWidth()) {
				newX = MathUtils.subtract(moneyPlateContainer.getMeasuredWidth(), view.getWidth());
			}

			if (y < coinHalfHeight) {
				newY = 0;
			} else if (MathUtils.add(y, view.getHeight()) > moneyPlateContainer.getMeasuredHeight()) {
				newY = MathUtils.subtract(moneyPlateContainer.getMeasuredHeight(), view.getHeight());
			}

			RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(view.getMeasuredWidth(), view.getMeasuredHeight());
			params.leftMargin = Math.round(newX);
			params.topMargin = Math.round(newY);
			image.setLayoutParams(params);

			moneyPlateContainer.addView(image);
		}

	}
}
