package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants.GameLevel;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.game.GameHelper;
import hk.hklss.android.LearnSmart.game.PairingData;
import hk.hklss.android.LearnSmart.game.PairingDataSet;
import hk.hklss.android.LearnSmart.view.DrawLineView;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class GamePairingActivity extends Activity implements View.OnClickListener, View.OnTouchListener {

	private final String TAG = GamePairingActivity.class.getSimpleName();
	
	public final static String KEY_GAME_LEVEL = "game_level";
	public final static String KEY_GAME_DATA = "game_data";
	public final static String KEY_IS_GAME_STARTED = "is_game_started";
	public final static String KEY_IS_GAME_END = "is_game_end";
	public final static String KEY_CURRENT_GAME_NUM = "current_game_num";
	public final static String KEY_CONNECTED_TAGS = "connected_tags";
	public final static String KEY_ELAPSED_TIME = "elapsed_time";
	
	private AudioManager audioManager;
	private GameLevel gameLevel;
	private ArrayList<PairingDataSet> gameData;
	private int currentGameNum = 0;
	private int pairCount = 0;
	private ArrayList<String> connectedTags;
	private boolean canPlay = false;
	private float itemDeltaX;
	private long elapsedTime = 0;
	
	private boolean isGameStarted = false;
	private boolean isGameEnd = false;
	
	private ImageButton backButton;
	private Chronometer timer;
	
	private RelativeLayout leftItem1, leftItem2, leftItem3, leftItem4;
	private ImageView leftItemDot1, leftItemDot2, leftItemDot3, leftItemDot4;
	private ImageView leftItemDotRing1, leftItemDotRing2, leftItemDotRing3, leftItemDotRing4;
	private ImageView leftItemImage1, leftItemImage2, leftItemImage3, leftItemImage4;
	private RelativeLayout[] leftItems;
	private ImageView[] leftItemDots;
	private ImageView[] leftItemDotRings;
	private ImageView[] leftItemImages;
	
	private RelativeLayout rightItem1, rightItem2, rightItem3, rightItem4;
	private ImageView rightItemDot1, rightItemDot2, rightItemDot3, rightItemDot4;
	private ImageView rightItemDotRing1, rightItemDotRing2, rightItemDotRing3, rightItemDotRing4;
	private ImageView rightItemImage1, rightItemImage2, rightItemImage3, rightItemImage4;
	private RelativeLayout[] rightItems;
	private ImageView[] rightItemDots;
	private ImageView[] rightItemDotRings;
	private ImageView[] rightItemImages;
	
	private RelativeLayout playArea;
	private DrawLineView currentLine;
	private int currentItemIndex = -1;
	
	private RelativeLayout gameStartAnimContainer;
	private ImageView gameStartImage;
	
	private RelativeLayout gameEndAnimContainer;
	private ImageView gameEndImage1, gameEndImage2, gameEndImage3, gameEndImage4, gameEndThumbImage;
	
	private AnimationSet gameStartAnimSet1, gameStartAnimSet2;
	private AnimationSet gameEndAnimSet1, gameEndAnimSet2, gameEndAnimSet3, gameEndAnimSet4, gameEndAnimThumbSet;
	
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (connectedTags.size() >= pairCount) {
				audioManager.playGameYeah();
				nextGame();
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_pairing);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
		initAnimation();
		initGameData();
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		startGame();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		resumeGame();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		pauseGame();
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		initFromBundle(savedInstanceState);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		
		if (gameLevel != null) {
			outState.putInt(KEY_GAME_LEVEL, gameLevel.ordinal());
		}
		if (gameData != null) {
			outState.putParcelableArrayList(KEY_GAME_DATA, gameData);
		}
		
		outState.putBoolean(KEY_IS_GAME_STARTED, isGameStarted);
		outState.putBoolean(KEY_IS_GAME_END, isGameEnd);
		outState.putInt(KEY_CURRENT_GAME_NUM, currentGameNum);
		
		if (connectedTags != null) {
			outState.putStringArrayList(KEY_CONNECTED_TAGS, connectedTags);
		}
		if (timer != null) {
			outState.putLong(KEY_ELAPSED_TIME, elapsedTime);
		}
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			if (canPlay) {
				audioManager.playPressButton();
			}
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				if (canPlay) {
					back();
				}
				break;
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		boolean eventConsumed = false;
		
		if (!canPlay) {
			return true;
		}
		
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			if (currentItemIndex != -1) {
				if (currentLine != null) {
					playArea.removeView(currentLine);
					currentLine = null;
				}
				
				shrinkLeftItem(currentItemIndex);
				currentItemIndex = -1;
			}
			
			for (int i = 0; i < leftItems.length; i++) {
				if (v == leftItems[i]) {
					boolean isConnected = false;
					
					for (String connectedTag : connectedTags) {
						if (v.getTag().toString().equals(connectedTag)) {
							isConnected = true;
							break;
						}
					}
					
					if (!isConnected) {
						currentItemIndex = i;
					}
					break;
				}
			}
			
			if (currentItemIndex > -1) {
				currentLine = new DrawLineView(this, null);
				playArea.addView(currentLine);
				
				ImageView fromDot = leftItemDots[currentItemIndex];
				int[] location = new int[2];
				fromDot.getLocationOnScreen(location);
				
				float startX = location[0] + fromDot.getMeasuredWidth() / 2;
				float startY = location[1] + fromDot.getMeasuredHeight() / 2;
				
				currentLine.setLineStart(startX, startY, true);
				
				stretchLeftItem(currentItemIndex);
				
				eventConsumed = true;
			}
			
			break;
		case MotionEvent.ACTION_MOVE:
			if (currentLine != null) {
				currentLine.setLineEnd(event.getRawX(), event.getRawY());
				
				eventConsumed = true;
			}
			
			break;
		case MotionEvent.ACTION_UP:
			int x = (int) event.getRawX();
			int y = (int) event.getRawY();
			
			if (currentLine != null) {
				boolean isHit = false;
				int hitItemIndex = -1;
				
				for (int i = 0; i < rightItems.length; i++) {
					RelativeLayout rightItem = rightItems[i];
				
					if (rightItem != null) {
						Rect hitRect = new Rect();
						rightItem.getHitRect(hitRect);
					
						int[] screenLocation = new int[2];
						rightItem.getLocationOnScreen(screenLocation);
					
						int dx = screenLocation[0] - rightItem.getLeft();
						int dy = screenLocation[1] - rightItem.getTop();
						hitRect.offset(dx, dy);
					
						if (hitRect.contains(x, y)) {
							isHit = true;
							hitItemIndex = i;
							break;
						}
					}
				}
				
				if (isHit) {
					String currentTag = leftItems[currentItemIndex].getTag().toString();
					String hitTag = rightItems[hitItemIndex].getTag().toString();
					
					if (hitTag != null && currentTag != null && hitTag.equals(currentTag)) {
						ImageView hitDot = rightItemDots[hitItemIndex];
						int[] location = new int[2];
						hitDot.getLocationOnScreen(location);
						
						float endX = location[0] + hitDot.getMeasuredWidth() / 2;
						float endY = location[1] + hitDot.getMeasuredHeight() / 2;
						
						currentLine.setLineEnd(endX, endY);
						
						shrinkLeftItem(currentItemIndex);
						
						runDotConnectedAnimation(currentItemIndex, hitItemIndex);
						
						connectedTags.add(currentTag);
					} else {
						playArea.removeView(currentLine);
						currentLine = null;
						
						shrinkLeftItem(currentItemIndex);
						
						audioManager.playGameWrongLinked();
					}
				} else {
					playArea.removeView(currentLine);
					currentLine = null;
					
					shrinkLeftItem(currentItemIndex);
					
					audioManager.playGameWrongLinked();
				}
				
				currentItemIndex = -1;
				
				eventConsumed = true;
				
				handler.sendEmptyMessageDelayed(0, 500);
			}
			break;
		}
		
		return eventConsumed;
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_GAME_LEVEL)) {
				int ordinal = bundle.getInt(KEY_GAME_LEVEL);
				gameLevel = GameLevel.values()[ordinal];
			}
			if (bundle.containsKey(KEY_GAME_DATA)) {
				gameData = bundle.getParcelableArrayList(KEY_GAME_DATA);
			}
			if (bundle.containsKey(KEY_IS_GAME_STARTED)) {
				isGameStarted = bundle.getBoolean(KEY_IS_GAME_STARTED);
			}
			if (bundle.containsKey(KEY_IS_GAME_END)) {
				isGameEnd = bundle.getBoolean(KEY_IS_GAME_END);
			}
			if (bundle.containsKey(KEY_CURRENT_GAME_NUM)) {
				currentGameNum = bundle.getInt(KEY_CURRENT_GAME_NUM);
			}
			if (bundle.containsKey(KEY_CONNECTED_TAGS)) {
				connectedTags = bundle.getStringArrayList(KEY_CONNECTED_TAGS);
			}
			if (bundle.containsKey(KEY_ELAPSED_TIME)) {
				elapsedTime = bundle.getLong(KEY_ELAPSED_TIME);
			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
		pairCount = getResources().getInteger(R.integer.gamePairTotalPair);
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		
		timer = (Chronometer) findViewById(R.id.timer);
		
		leftItem1 = (RelativeLayout) findViewById(R.id.leftItem1);
		leftItem2 = (RelativeLayout) findViewById(R.id.leftItem2);
		leftItem3 = (RelativeLayout) findViewById(R.id.leftItem3);
		leftItem4 = (RelativeLayout) findViewById(R.id.leftItem4);
		leftItemDot1 = (ImageView) findViewById(R.id.leftItemDot1);
		leftItemDot2 = (ImageView) findViewById(R.id.leftItemDot2);
		leftItemDot3 = (ImageView) findViewById(R.id.leftItemDot3);
		leftItemDot4 = (ImageView) findViewById(R.id.leftItemDot4);
		leftItemDotRing1 = (ImageView) findViewById(R.id.leftItemDotRing1);
		leftItemDotRing2 = (ImageView) findViewById(R.id.leftItemDotRing2);
		leftItemDotRing3 = (ImageView) findViewById(R.id.leftItemDotRing3);
		leftItemDotRing4 = (ImageView) findViewById(R.id.leftItemDotRing4);
		leftItemImage1 = (ImageView) findViewById(R.id.leftItemImage1);
		leftItemImage2 = (ImageView) findViewById(R.id.leftItemImage2);
		leftItemImage3 = (ImageView) findViewById(R.id.leftItemImage3);
		leftItemImage4 = (ImageView) findViewById(R.id.leftItemImage4);
		leftItemDots = new ImageView[] { leftItemDot1, leftItemDot2, leftItemDot3, leftItemDot4 };
		leftItemDotRings = new ImageView[] { leftItemDotRing1, leftItemDotRing2, leftItemDotRing3, leftItemDotRing4 };
		leftItemImages = new ImageView[] { leftItemImage1, leftItemImage2, leftItemImage3, leftItemImage4 };
		leftItems = new RelativeLayout[] { leftItem1, leftItem2, leftItem3, leftItem4 };
		
		rightItem1 = (RelativeLayout) findViewById(R.id.rightItem1);
		rightItem2 = (RelativeLayout) findViewById(R.id.rightItem2);
		rightItem3 = (RelativeLayout) findViewById(R.id.rightItem3);
		rightItem4 = (RelativeLayout) findViewById(R.id.rightItem4);
		rightItemDot1 = (ImageView) findViewById(R.id.rightItemDot1);
		rightItemDot2 = (ImageView) findViewById(R.id.rightItemDot2);
		rightItemDot3 = (ImageView) findViewById(R.id.rightItemDot3);
		rightItemDot4 = (ImageView) findViewById(R.id.rightItemDot4);
		rightItemDotRing1 = (ImageView) findViewById(R.id.rightItemDotRing1);
		rightItemDotRing2 = (ImageView) findViewById(R.id.rightItemDotRing2);
		rightItemDotRing3 = (ImageView) findViewById(R.id.rightItemDotRing3);
		rightItemDotRing4 = (ImageView) findViewById(R.id.rightItemDotRing4);
		rightItemImage1 = (ImageView) findViewById(R.id.rightItemImage1);
		rightItemImage2 = (ImageView) findViewById(R.id.rightItemImage2);
		rightItemImage3 = (ImageView) findViewById(R.id.rightItemImage3);
		rightItemImage4 = (ImageView) findViewById(R.id.rightItemImage4);
		rightItemDots = new ImageView[] { rightItemDot1, rightItemDot2, rightItemDot3, rightItemDot4 };
		rightItemDotRings = new ImageView[] { rightItemDotRing1, rightItemDotRing2, rightItemDotRing3, rightItemDotRing4 };
		rightItemImages = new ImageView[] { rightItemImage1, rightItemImage2, rightItemImage3, rightItemImage4 };
		rightItems = new RelativeLayout[] { rightItem1, rightItem2, rightItem3, rightItem4 };
		
		playArea = (RelativeLayout) findViewById(R.id.playArea);
		
		gameStartAnimContainer = (RelativeLayout) findViewById(R.id.gameStartAnimContainer);
		gameStartImage = (ImageView) findViewById(R.id.gameStartImage);
		
		gameEndAnimContainer = (RelativeLayout) findViewById(R.id.gameEndAnimContainer);
		gameEndImage1 = (ImageView) findViewById(R.id.gameEndImage1);
		gameEndImage2 = (ImageView) findViewById(R.id.gameEndImage2);
		gameEndImage3 = (ImageView) findViewById(R.id.gameEndImage3);
		gameEndImage4 = (ImageView) findViewById(R.id.gameEndImage4);
		gameEndThumbImage = (ImageView) findViewById(R.id.gameEndThumbImage);
		
		backButton.setOnClickListener(this);
		
		leftItem1.setOnTouchListener(this);
		leftItem2.setOnTouchListener(this);
		leftItem3.setOnTouchListener(this);
		leftItem4.setOnTouchListener(this);
		
		itemDeltaX = leftItem1.getLayoutParams().width * 0.125f;
		
		for (int i = pairCount; i < leftItems.length; i++) {
			leftItems[i].setVisibility(View.GONE);
			rightItems[i].setVisibility(View.GONE);
		}
	}
	
	private void initAnimation() {
		initGameStartAnimation();
		initGameEndAnimation();
	}
	
	private void initGameStartAnimation() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;
		
		Animation rotateAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.game_start_rotate);
		
		Animation translateAnim = new TranslateAnimation(0, 0, -screenHeight / 2, 0);
		translateAnim.setDuration(1000);
		
		gameStartAnimSet1 = new AnimationSet(true);
		gameStartAnimSet1.setDuration(2500);
		gameStartAnimSet1.addAnimation(rotateAnim);
		gameStartAnimSet1.addAnimation(translateAnim);
		gameStartAnimSet1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.playGameStart();
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				gameStartImage.startAnimation(gameStartAnimSet2);
			}
		});
		
		Animation scaleAnim = new ScaleAnimation(1, 1.5f, 1, 1.5f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		scaleAnim.setDuration(1000);
		scaleAnim.setStartOffset(1000);
		
		Animation fadeOutAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.game_start_fade_out);
		fadeOutAnim.setDuration(1000);
		fadeOutAnim.setStartOffset(1000);
		
		gameStartAnimSet2 = new AnimationSet(true);
		gameStartAnimSet2.addAnimation(scaleAnim);
		gameStartAnimSet2.addAnimation(fadeOutAnim);
		gameStartAnimSet2.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.playGameReadyGo();
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				gameStartAnimContainer.setVisibility(View.INVISIBLE);
				
				timer.setBase(SystemClock.elapsedRealtime());
				timer.start();
				
				audioManager.playGameBackground();
				
				canPlay = true;
				isGameStarted = true;
			}
		});
	}
	
	private void initGameEndAnimation() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;
		
		Animation translateAnim1 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim1.setDuration(500);
		translateAnim1.setStartOffset(0);
		
		gameEndAnimSet1 = new AnimationSet(true);
		gameEndAnimSet1.addAnimation(translateAnim1);
		gameEndAnimSet1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.stopBackgroundAudio();
				audioManager.playGameEnd();
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
			}
		});
		
		Animation translateAnim2 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim2.setDuration(500);
		translateAnim2.setStartOffset(400);
		
		gameEndAnimSet2 = new AnimationSet(true);
		gameEndAnimSet2.addAnimation(translateAnim2);
		
		Animation translateAnim3 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim3.setDuration(500);
		translateAnim3.setStartOffset(800);
		
		gameEndAnimSet3 = new AnimationSet(true);
		gameEndAnimSet3.addAnimation(translateAnim3);
		
		Animation translateAnim4 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim4.setDuration(500);
		translateAnim4.setStartOffset(1200);
		
		gameEndAnimSet4 = new AnimationSet(true);
		gameEndAnimSet4.addAnimation(translateAnim4);
		
		final Animation thumbScaleAnim = new ScaleAnimation(2.0f, 1.0f, 2.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		thumbScaleAnim.setDuration(500);
		thumbScaleAnim.setRepeatCount(4);
		thumbScaleAnim.setRepeatMode(Animation.REVERSE);
		thumbScaleAnim.setFillAfter(true);
		thumbScaleAnim.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				startGameLevelClearActivity();
			}
		});
		
		Animation thumbTranslateAnim = new TranslateAnimation(-screenWidth, 0, 0, 0);
		thumbTranslateAnim.setDuration(500);
		thumbTranslateAnim.setStartOffset(1600);
		thumbTranslateAnim.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				gameEndThumbImage.startAnimation(thumbScaleAnim);
			}
		});
		
		gameEndAnimThumbSet = new AnimationSet(true);
		gameEndAnimThumbSet.addAnimation(thumbTranslateAnim);
	}
	
	private void runDotConnectedAnimation(final int leftItemIndex, final int rightItemIndex) {
		Animation scaleAnim = new ScaleAnimation(1.0f, 1.2f, 1.0f, 1.2f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f); 
		scaleAnim.setDuration(500);
		
		Animation fadeOutAnim = new AlphaAnimation(1.0f, 0f);
		fadeOutAnim.setDuration(500);
		fadeOutAnim.setFillAfter(true);
		
		AnimationSet leftItemAnimSet = new AnimationSet(true);
		leftItemAnimSet.addAnimation(scaleAnim);
		leftItemAnimSet.addAnimation(fadeOutAnim);
		leftItemAnimSet.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				leftItemDotRings[leftItemIndex].setVisibility(View.VISIBLE);
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				leftItemDotRings[leftItemIndex].setVisibility(View.INVISIBLE);
			}
		});
		
		AnimationSet rightItemAnimSet = new AnimationSet(true);
		rightItemAnimSet.addAnimation(scaleAnim);
		rightItemAnimSet.addAnimation(fadeOutAnim);
		rightItemAnimSet.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				rightItemDotRings[rightItemIndex].setVisibility(View.VISIBLE);
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				rightItemDotRings[rightItemIndex].setVisibility(View.INVISIBLE);
			}
		});
	
		audioManager.playGameCorrectLinked();
		leftItemDotRings[leftItemIndex].startAnimation(leftItemAnimSet);
		rightItemDotRings[rightItemIndex].startAnimation(rightItemAnimSet);
	}
	
	private void stretchLeftItem(int leftItemIndex) {
		RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) leftItems[leftItemIndex].getLayoutParams();
		lp.leftMargin = (int) (lp.leftMargin + itemDeltaX);
		leftItems[leftItemIndex].setLayoutParams(lp);
		
		if (currentLine != null) {
			currentLine.resetLineStart(currentLine.getStartX() + itemDeltaX, currentLine.getStartY());
		}
	}
	
	private void shrinkLeftItem(int leftItemIndex) {
		RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) leftItems[leftItemIndex].getLayoutParams();
		lp.leftMargin = (int) (lp.leftMargin - itemDeltaX);
		leftItems[leftItemIndex].setLayoutParams(lp);
		
		if (currentLine != null) {
			currentLine.resetLineStart(currentLine.getStartX() - itemDeltaX, currentLine.getStartY());
		}
	}
	
	private void initGameData() {
		gameData = GameHelper.getPairingDataSet(getApplicationContext(), gameLevel, pairCount);
		connectedTags = new ArrayList<String>();
	}
	
	private PairingDataSet getGameData(int gameNum) {
		return gameData.get(gameNum - 1);
	}
	
	private void startGame() {
		if (!isGameStarted) {
			gameStartAnimContainer.setVisibility(View.VISIBLE);
			
			gameStartImage.startAnimation(gameStartAnimSet1);
			nextGame();
		}
	}
	
	private void resumeGame() {
		if (isGameStarted) {
			if (!isGameEnd) {
				initUIElements();
				initBackend();
				setGameData();
				
				timer.setBase(elapsedTime + SystemClock.elapsedRealtime());
				timer.start();
				audioManager.playGameBackground();
			} else {
				startGameLevelClearActivity();
			}
		}
	}
	
	private void pauseGame() {
		timer.stop();
		elapsedTime = timer.getBase() - SystemClock.elapsedRealtime();
		audioManager.stopBackgroundAudio();
	}
	
	private void endGame() {
		canPlay = false;
		isGameEnd = true;
		
		timer.stop();
		elapsedTime = timer.getBase() - SystemClock.elapsedRealtime();
		
		gameEndAnimContainer.setVisibility(View.VISIBLE);
		
		gameEndImage1.startAnimation(gameEndAnimSet1);
		gameEndImage2.startAnimation(gameEndAnimSet2);
		gameEndImage3.startAnimation(gameEndAnimSet3);
		gameEndImage4.startAnimation(gameEndAnimSet4);
		gameEndThumbImage.startAnimation(gameEndAnimThumbSet);
	}
	
	private void nextGame() {
		currentGameNum++;
		connectedTags.clear();
		
		if (currentGameNum <= gameData.size()) {
			playArea.removeAllViews();
			
			setGameData();
		} else {
			endGame();
		}
	}
	
	private void setGameData() {
		PairingDataSet data = getGameData(currentGameNum);
		
		List<PairingData> leftList = data.getLeftSet();
		List<PairingData> rightList = data.getRightSet();
		
		for (int i = 0; i < leftList.size(); i++) {
			PairingData left = leftList.get(i);
			PairingData right = rightList.get(i);
			
			leftItemImages[i].setImageResource(getResources().getIdentifier(left.getValue(), "drawable", getPackageName()));
			leftItems[i].setTag(left.getTag());
			
			rightItemImages[i].setImageResource(getResources().getIdentifier(right.getValue(), "drawable", getPackageName()));
			rightItems[i].setTag(right.getTag());
		}
	}
	
	private void startGameLevelClearActivity() {
		Intent intent = new Intent(this, GamePairingLevelClearActivity.class);
		intent.putExtra(GamePairingLevelClearActivity.KEY_GAME_LEVEL, gameLevel);
		intent.putExtra(GamePairingLevelClearActivity.KEY_GAME_ELAPSED_TIME, timer.getText());
		
		startActivity(intent);
		finish();
	}

	private void back() {
		finish();
	}
}
