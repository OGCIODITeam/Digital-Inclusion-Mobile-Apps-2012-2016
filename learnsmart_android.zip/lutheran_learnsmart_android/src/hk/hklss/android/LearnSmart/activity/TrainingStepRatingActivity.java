package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class TrainingStepRatingActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingStepRatingActivity.class.getSimpleName();
	public static final String KEY_RATE = "TrainingStepRatingActivity.rate";
	
	private AudioManager audioManager;
	
	private ImageButton cancelButton;
	private ImageButton doneButton;
	private RadioButton[] ratingRadioButtons;	
	private int rate = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_step_rating);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
		} 
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.cancelButton:
				back();
				break;
			case R.id.doneButton:
				doneAndBack();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_RATE)) {
				rate = bundle.getInt(KEY_RATE);
			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		cancelButton = (ImageButton) findViewById(R.id.cancelButton);
		doneButton = (ImageButton) findViewById(R.id.doneButton);
		ratingRadioButtons = new RadioButton[] {
				(RadioButton) findViewById(R.id.radioStar1),
				(RadioButton) findViewById(R.id.radioStar2),
				(RadioButton) findViewById(R.id.radioStar3),
				(RadioButton) findViewById(R.id.radioStar4),
				(RadioButton) findViewById(R.id.radioStar5)
			};
		
		cancelButton.setOnClickListener(this);
		doneButton.setOnClickListener(this);
		
		for (int i = 0; i < ratingRadioButtons.length; i++) {
			ratingRadioButtons[i].setChecked(false);
			ratingRadioButtons[i].setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (isChecked) {
						for (RadioButton rb : ratingRadioButtons) {
							if (rb != buttonView) {
								rb.setChecked(false);
							}
						}
					}
				}
			});
		}
		
		if (rate > 0 && rate <= ratingRadioButtons.length) {
			ratingRadioButtons[rate - 1].setChecked(true);
		} else {
			ratingRadioButtons[0].setChecked(true);
		}
	}
	
	private void back() {
		if (rate == 0) {
			new AlertDialog.Builder(this)
				.setCancelable(false)
				.setTitle("")
		    	.setMessage(R.string.dialog_cancel_rating_message)
		    	.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
				        @Override
				        public void onClick(DialogInterface dialog, int which) {
				        	TrainingStepRatingActivity.this.finish();
				        }
			    	})
		    	.setNegativeButton(android.R.string.no, null)
		    	.show();
		} else {
			finish();
		}
	}
	
	private void doneAndBack() {
		int rating = 0;
		
		for (int i = 0; i < ratingRadioButtons.length; i++) {
			RadioButton rb = ratingRadioButtons[i];
			if (rb.isChecked()) {
				rating = i + 1;
				break;
			}
		}
		
		Intent intent = new Intent();
		intent.putExtra("rating", rating);
		setResult(Activity.RESULT_OK, intent);
		finish();
	}
}
