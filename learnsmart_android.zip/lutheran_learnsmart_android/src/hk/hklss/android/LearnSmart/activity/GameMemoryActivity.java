package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.game.GameHelper;
import hk.hklss.android.LearnSmart.game.MemoryDataSet;
import hk.hklss.android.LearnSmart.util.FlipAnimationFactory;
import hk.hklss.android.LearnSmart.util.FlipAnimationFactory.FlipDirection;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ViewFlipper;

public class GameMemoryActivity extends Activity implements View.OnClickListener {

	private final String TAG = GameMemoryActivity.class.getSimpleName();

	public final static String KEY_GAME_DATA = "game_data";
	public final static String KEY_PAIRED_TAG = "paired_tag";
	public final static String KEY_CAN_PLAY = "can_play";
	public final static String KEY_IS_GAME_STARTED = "is_game_started";
	public final static String KEY_IS_GAME_END = "is_game_end";
	public final static String KEY_FLIPPED_ITEM_INDEX = "flipped_item_index";
	public final static String KEY_ELAPSED_TIME = "elapsed_time";
	
	private final int PAIR_COUNT = 8;
	private final int CARD_COUNT = PAIR_COUNT * 2; 
	
	private AudioManager audioManager;
	private ArrayList<String> pairedTag;
	private ArrayList<MemoryDataSet> gameData;
	private boolean canPlay = false;
	private int flippedItemIndex = -1;
	private long elapsedTime = 0;
	
	private boolean isGameStarted = false;
	private boolean isGameEnd = false;
	
	private ImageButton backButton;
	private Chronometer timer;
	
	private ViewFlipper[] cards;
	
	private RelativeLayout gameStartAnimContainer;
	private ImageView gameStartImage;
	
	private RelativeLayout gameEndAnimContainer;
	private ImageView gameEndImage1, gameEndImage2, gameEndImage3, gameEndImage4, gameEndThumbImage;
	
	private AnimationSet gameStartAnimSet1, gameStartAnimSet2;
	private AnimationSet gameEndAnimSet1, gameEndAnimSet2, gameEndAnimSet3, gameEndAnimSet4, gameEndAnimThumbSet;
	
	private Handler handler = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_memory);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
		initAnimation();
		initGameData();
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		startGame();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		resumeGame();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		pauseGame();
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		initFromBundle(savedInstanceState);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		
		if (gameData != null) {
			outState.putParcelableArrayList(KEY_GAME_DATA, gameData);
		}
		if (pairedTag != null) {
			outState.putStringArrayList(KEY_PAIRED_TAG, pairedTag);
		}
		
		outState.putBoolean(KEY_CAN_PLAY, canPlay);
		outState.putBoolean(KEY_IS_GAME_STARTED, isGameStarted);
		outState.putBoolean(KEY_IS_GAME_END, isGameEnd);
		outState.putInt(KEY_FLIPPED_ITEM_INDEX, flippedItemIndex);
		
		if (timer != null) {
			outState.putLong(KEY_ELAPSED_TIME, elapsedTime);
		}
	}

	@Override
	public void onClick(View v) {
		if (!canPlay) {
			return;
		}
		
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		} else if (v instanceof ViewFlipper) {
			ViewFlipper flipper = (ViewFlipper) v;
			flipper.setEnabled(false);
			
			runFlipAnimation(flipper);
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_GAME_DATA)) {
				gameData = bundle.getParcelableArrayList(KEY_GAME_DATA);
			}
			if (bundle.containsKey(KEY_PAIRED_TAG)) {
				pairedTag = bundle.getStringArrayList(KEY_PAIRED_TAG);
			}
			if (bundle.containsKey(KEY_CAN_PLAY)) {
				canPlay = bundle.getBoolean(KEY_CAN_PLAY);
			}
			if (bundle.containsKey(KEY_IS_GAME_STARTED)) {
				isGameStarted = bundle.getBoolean(KEY_IS_GAME_STARTED);
			}
			if (bundle.containsKey(KEY_IS_GAME_END)) {
				isGameEnd = bundle.getBoolean(KEY_IS_GAME_END);
			}
			if (bundle.containsKey(KEY_FLIPPED_ITEM_INDEX)) {
				flippedItemIndex = bundle.getInt(KEY_FLIPPED_ITEM_INDEX);
			}
			if (bundle.containsKey(KEY_ELAPSED_TIME)) {
				elapsedTime = bundle.getLong(KEY_ELAPSED_TIME);
			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		
		timer = (Chronometer) findViewById(R.id.timer);
		
		cards = new ViewFlipper[] { 
				(ViewFlipper) findViewById(R.id.card1),
				(ViewFlipper) findViewById(R.id.card2),
				(ViewFlipper) findViewById(R.id.card3),
				(ViewFlipper) findViewById(R.id.card4),
				(ViewFlipper) findViewById(R.id.card5),
				(ViewFlipper) findViewById(R.id.card6),
				(ViewFlipper) findViewById(R.id.card7),
				(ViewFlipper) findViewById(R.id.card8),
				(ViewFlipper) findViewById(R.id.card9),
				(ViewFlipper) findViewById(R.id.card10),
				(ViewFlipper) findViewById(R.id.card11),
				(ViewFlipper) findViewById(R.id.card12),
				(ViewFlipper) findViewById(R.id.card13),
				(ViewFlipper) findViewById(R.id.card14),
				(ViewFlipper) findViewById(R.id.card15),
				(ViewFlipper) findViewById(R.id.card16)
			};
		
		gameStartAnimContainer = (RelativeLayout) findViewById(R.id.gameStartAnimContainer);
		gameStartImage = (ImageView) findViewById(R.id.gameStartImage);
		
		gameEndAnimContainer = (RelativeLayout) findViewById(R.id.gameEndAnimContainer);
		gameEndImage1 = (ImageView) findViewById(R.id.gameEndImage1);
		gameEndImage2 = (ImageView) findViewById(R.id.gameEndImage2);
		gameEndImage3 = (ImageView) findViewById(R.id.gameEndImage3);
		gameEndImage4 = (ImageView) findViewById(R.id.gameEndImage4);
		gameEndThumbImage = (ImageView) findViewById(R.id.gameEndThumbImage);
		
		backButton.setOnClickListener(this);
		
		for (ViewFlipper card : cards) {
			card.setOnClickListener(this);
		}
	}
	
	private void initAnimation() {
		initGameStartAnimation();
		initGameEndAnimation();
	}
	
	private void initGameStartAnimation() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;
		
		Animation rotateAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.game_start_rotate);
		
		Animation translateAnim = new TranslateAnimation(0, 0, -screenHeight / 2, 0);
		translateAnim.setDuration(1000);
		
		gameStartAnimSet1 = new AnimationSet(true);
		gameStartAnimSet1.setDuration(2500);
		gameStartAnimSet1.addAnimation(rotateAnim);
		gameStartAnimSet1.addAnimation(translateAnim);
		gameStartAnimSet1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.playGameStart();
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				gameStartImage.startAnimation(gameStartAnimSet2);
			}
		});
		
		Animation scaleAnim = new ScaleAnimation(1, 1.5f, 1, 1.5f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		scaleAnim.setDuration(1000);
		scaleAnim.setStartOffset(1000);
		
		Animation fadeOutAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.game_start_fade_out);
		fadeOutAnim.setDuration(1000);
		fadeOutAnim.setStartOffset(1000);
		
		gameStartAnimSet2 = new AnimationSet(true);
		gameStartAnimSet2.addAnimation(scaleAnim);
		gameStartAnimSet2.addAnimation(fadeOutAnim);
		gameStartAnimSet2.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.playGameReadyGo();
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				gameStartAnimContainer.setVisibility(View.INVISIBLE);
				
				timer.setBase(SystemClock.elapsedRealtime());
				timer.start();
				
				audioManager.playGameBackground();
				
				canPlay = true;
				isGameStarted = true;
			}
		});
	}
	
	private void initGameEndAnimation() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenHeight = dm.heightPixels;
		int screenWidth = dm.widthPixels;
		
		Animation translateAnim1 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim1.setDuration(500);
		translateAnim1.setStartOffset(0);
		
		gameEndAnimSet1 = new AnimationSet(true);
		gameEndAnimSet1.addAnimation(translateAnim1);
		gameEndAnimSet1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
				audioManager.stopBackgroundAudio();
				audioManager.playGameEnd();
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
			}
		});
		
		Animation translateAnim2 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim2.setDuration(500);
		translateAnim2.setStartOffset(400);
		
		gameEndAnimSet2 = new AnimationSet(true);
		gameEndAnimSet2.addAnimation(translateAnim2);
		
		Animation translateAnim3 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim3.setDuration(500);
		translateAnim3.setStartOffset(800);
		
		gameEndAnimSet3 = new AnimationSet(true);
		gameEndAnimSet3.addAnimation(translateAnim3);
		
		Animation translateAnim4 = new TranslateAnimation(-screenWidth, 0, 0, 0);
		translateAnim4.setDuration(500);
		translateAnim4.setStartOffset(1200);
		
		gameEndAnimSet4 = new AnimationSet(true);
		gameEndAnimSet4.addAnimation(translateAnim4);
		
		final Animation thumbScaleAnim = new ScaleAnimation(2.0f, 1.0f, 2.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		thumbScaleAnim.setDuration(500);
		thumbScaleAnim.setRepeatCount(4);
		thumbScaleAnim.setRepeatMode(Animation.REVERSE);
		thumbScaleAnim.setFillAfter(true);
		thumbScaleAnim.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				startGameLevelClearActivity();
			}
		});
		
		Animation thumbTranslateAnim = new TranslateAnimation(-screenWidth, 0, 0, 0);
		thumbTranslateAnim.setDuration(500);
		thumbTranslateAnim.setStartOffset(1600);
		thumbTranslateAnim.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				gameEndThumbImage.startAnimation(thumbScaleAnim);
			}
		});
		
		gameEndAnimThumbSet = new AnimationSet(true);
		gameEndAnimThumbSet.addAnimation(thumbTranslateAnim);
	}
	
	private void initGameData() {
		gameData = GameHelper.getMemoryDataSet(getApplicationContext());

		pairedTag = new ArrayList<String>();
	}
	
	private void startGame() {
		if (!isGameStarted) {
			gameStartAnimContainer.setVisibility(View.VISIBLE);
			
			gameStartImage.startAnimation(gameStartAnimSet1);
			setGameData();
		}
	}
	
	private void resumeGame() {
		if (isGameStarted) {
			if (!isGameEnd) {
				initUIElements();
				initBackend();
				setGameData();
				
				timer.setBase(elapsedTime + SystemClock.elapsedRealtime());
				timer.start();
				audioManager.playGameBackground();
			} else {
				startGameLevelClearActivity();
			}
		}
	}
	
	private void pauseGame() {
		timer.stop();
		elapsedTime = timer.getBase() - SystemClock.elapsedRealtime();
		audioManager.stopBackgroundAudio();
	}
	
	private void endGame() {
		canPlay = false;
		isGameEnd = true;
		
		timer.stop();
		elapsedTime = timer.getBase() - SystemClock.elapsedRealtime();
		
		gameEndAnimContainer.setVisibility(View.VISIBLE);
		
		gameEndImage1.startAnimation(gameEndAnimSet1);
		gameEndImage2.startAnimation(gameEndAnimSet2);
		gameEndImage3.startAnimation(gameEndAnimSet3);
		gameEndImage4.startAnimation(gameEndAnimSet4);
		gameEndThumbImage.startAnimation(gameEndAnimThumbSet);
	}
	
	private void setGameData() {
		for (int i = 0; i < gameData.size(); i++) {
			MemoryDataSet dataSet = gameData.get(i);
			ImageView cardImage = (ImageView) cards[i].getChildAt(1);
			cardImage.setImageResource(getResources().getIdentifier(dataSet.getValue(), "drawable", getPackageName()));
			cards[i].setTag(dataSet.getTag());
		}
	}
	
	private void checkPairMatched(int currentItemIndex) {
		if (flippedItemIndex == -1) {
			flippedItemIndex = currentItemIndex;
		} else {
			ViewFlipper flippedItem = cards[flippedItemIndex];
			ViewFlipper currentItem = cards[currentItemIndex];
			
			if (flippedItem.getTag().toString().equals(currentItem.getTag().toString())) {
				pairedTag.add(currentItem.toString());
				
				runMatchedPairsAnimation(flippedItem, currentItem);
				
				if (pairedTag.size() >= PAIR_COUNT) {
					endGame();
				}
			} else {
				runUnmatchedPairsAnimation(flippedItem, currentItem);
				flippedItem.setEnabled(true);
				currentItem.setEnabled(true);
			}
			
			flippedItemIndex = -1;
		}
	}
	
	private void runFlipAnimation(final ViewFlipper flipper) {
		FlipAnimationFactory.flipTransition(flipper, FlipDirection.LEFT_RIGHT, new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				for (int i = 0; i < cards.length; i++) {
					if (flipper == cards[i]) {
						final int index = i;
						checkPairMatched(index);
						break;
					}
				}
			}
		});
	}
	
	private void runMatchedPairsAnimation(final ViewFlipper flippedItem, final ViewFlipper currentItem) {
		handler.post(new Runnable() {
			@Override
			public void run() {
				flippedItem.setBackgroundColor(Color.parseColor("#88FF0000"));
				currentItem.setBackgroundColor(Color.parseColor("#88FF0000"));
			}
		});
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				flippedItem.setBackgroundColor(Color.TRANSPARENT);
				currentItem.setBackgroundColor(Color.TRANSPARENT);
			}
		}, 500);
		audioManager.playGameCorrectLinked();
	}
	
	private void runUnmatchedPairsAnimation(final ViewFlipper flippedItem, final ViewFlipper currentItem) {
		handler.post(new Runnable() {
			@Override
			public void run() {
				FlipAnimationFactory.flipTransition(flippedItem, FlipDirection.RIGHT_LEFT, null);
				FlipAnimationFactory.flipTransition(currentItem, FlipDirection.RIGHT_LEFT, null);
			}
		});
		audioManager.playGameWrongLinked();	
	}
	
	private void startGameLevelClearActivity() {
		Intent intent = new Intent(this, GameMemoryLevelClearActivity.class);
		intent.putExtra(GameMemoryLevelClearActivity.KEY_GAME_ELAPSED_TIME, timer.getText());
		startActivity(intent);
		
		finish();
	}

	private void back() {
		finish();
	}
}
