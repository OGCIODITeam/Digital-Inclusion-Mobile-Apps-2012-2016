package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants.GameLevel;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class GameCoinsLevelActivity extends Activity implements View.OnClickListener {

	private final String TAG = GameCoinsLevelActivity.class.getSimpleName();
	
	private AudioManager audioManager;
	
	private ImageButton backButton;
	private ImageButton easyLevelButton;
	private ImageButton mediumLevelButton;
	private ImageButton difficultLevelButton;
	private ImageView animGirlImageView;
	private AnimationDrawable animGirl;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_coins_level);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
			case R.id.easyLevelButton:
				startEasyGameActivity();
				break;
			case R.id.mediumLevelButton:
				startMediumGameActivity();
				break;
			case R.id.difficultLevelButton:
				startDifficultGameActivity();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
//			if (bundle.containsKey(KEY_LOGIN)) {
//				login = (MobileLogin) bundle.getParcelable(KEY_LOGIN);
//			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		easyLevelButton = (ImageButton) findViewById(R.id.easyLevelButton);
		mediumLevelButton = (ImageButton) findViewById(R.id.mediumLevelButton);
		difficultLevelButton = (ImageButton) findViewById(R.id.difficultLevelButton);
		animGirlImageView = (ImageView) findViewById(R.id.animGirlImageView);
		
		animGirl = (AnimationDrawable) getResources().getDrawable(R.drawable.girl_anim);
		animGirlImageView.setImageDrawable(animGirl);
		animGirlImageView.post(new Runnable() {
		    @Override
		    public void run() {
		    	if (!animGirl.isRunning()) {
		    		animGirl.start();
		    	}
		    }
		});
		
		backButton.setOnClickListener(this);
		easyLevelButton.setOnClickListener(this);
		mediumLevelButton.setOnClickListener(this);
		difficultLevelButton.setOnClickListener(this);
	}
	
	private void startEasyGameActivity() {
		Intent intent = new Intent(this, GameCoinsRuleActivity.class);
		intent.putExtra(GameCoinsRuleActivity.KEY_GAME_LEVEL, GameLevel.Easy.ordinal());
		startActivity(intent);
		finish();
	}
	
	private void startMediumGameActivity() {
		Intent intent = new Intent(this, GameCoinsRuleActivity.class);
		intent.putExtra(GameCoinsRuleActivity.KEY_GAME_LEVEL, GameLevel.Medium.ordinal());
		startActivity(intent);
		finish();
	}
	
	private void startDifficultGameActivity() {
		Intent intent = new Intent(this, GameCoinsRuleActivity.class);
		intent.putExtra(GameCoinsRuleActivity.KEY_GAME_LEVEL, GameLevel.Difficult.ordinal());
		startActivity(intent);
		finish();
	}

	private void back() {
		finish();
	}
}
