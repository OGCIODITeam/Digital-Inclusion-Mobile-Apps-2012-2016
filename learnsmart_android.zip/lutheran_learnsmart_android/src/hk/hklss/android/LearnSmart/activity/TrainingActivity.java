package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.Trainings;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;

public class TrainingActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingActivity.class.getSimpleName();
	public static final String KEY_TRAININGID = "TrainingActivity.trainingId";
	
	private ImageButton backButton;
	private ImageButton profileButton;
	private ImageButton startButton;
	private ImageButton pastRecordButton;
	private ImageButton detailsButton;
	private TextView trainingTitle;
	private TextView trainingText;
	private TextView noPhotoText;
	private ImageView trainingImage;
	
	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loadingProgressDialog;
	private int trainingId;
	private Trainings training;
	private MobileLogin login;
	
	private Handler handler = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
		
		login = getLogin();
		if (login != null) {
			profileButton.setVisibility(View.VISIBLE);
			pastRecordButton.setVisibility(View.VISIBLE);
			detailsButton.setVisibility(View.VISIBLE);
		}
		
		getTraining();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt(KEY_TRAININGID, trainingId);
		
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
		} 
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
			case R.id.profileButton:
				startProfileActivity();
				break;
			case R.id.startButton:
				startTrainingStepActivity();
				break;
			case R.id.pastRecordButton:
				startTrainingPastActivity();
				break;
			case R.id.detailsButton:
				startTrainingDetailsActivity();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_TRAININGID)) {
				trainingId = bundle.getInt(KEY_TRAININGID);
			}
		}
	}
	
	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		profileButton = (ImageButton) findViewById(R.id.profileButton);
		startButton = (ImageButton) findViewById(R.id.startButton);
		pastRecordButton = (ImageButton) findViewById(R.id.pastRecordButton);
		detailsButton = (ImageButton) findViewById(R.id.detailsButton);
		trainingTitle = (TextView) findViewById(R.id.trainingTitle);
		trainingText = (TextView) findViewById(R.id.trainingText);
		noPhotoText = (TextView) findViewById(R.id.noPhotoText);
		trainingImage = (ImageView) findViewById(R.id.trainingImage);
		
		backButton.setOnClickListener(this);
		profileButton.setOnClickListener(this);
		startButton.setOnClickListener(this);
		pastRecordButton.setOnClickListener(this);
		detailsButton.setOnClickListener(this);
		
		trainingTitle.setText("");
		trainingText.setText("");
		trainingImage.setImageBitmap(null);
		profileButton.setVisibility(View.INVISIBLE);
		pastRecordButton.setVisibility(View.INVISIBLE);
		detailsButton.setVisibility(View.INVISIBLE);
		noPhotoText.setVisibility(View.VISIBLE);
	}
	
	private MobileLogin getLogin() {
		return dataManager.getMobileLogin();
	}
	
	private void getTraining() {
		showLoadingProgressMessage();
		
		Trainings data = dataManager.getTraining(trainingId);
		
		showData(data);
	}
	
	private void showData(Trainings data) {
		this.training = data;
		
		noPhotoText.setVisibility(View.VISIBLE);
		
		trainingTitle.setText(data.getTitle());
		trainingText.setText(data.getDescription());
		
		if (data.getThumbnail() != null && !data.getThumbnail().equals("")) {
			ImageLoader.getInstance().displayImage(data.getThumbnail(), trainingImage, new ImageLoadingListener() {
				@Override
				public void onLoadingStarted(String imageUri, View view) {
				}
				
				@Override
				public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
					hideLoadingProgressMessage();
				}
				
				@Override
				public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
					hideLoadingProgressMessage();
					noPhotoText.setVisibility(View.INVISIBLE);
				}
				
				@Override
				public void onLoadingCancelled(String imageUri, View view) {
					hideLoadingProgressMessage();
				}
			});
		}	
	}
	
	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(TrainingActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}
	
	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}
	
	private void startProfileActivity() {
		Intent intent = new Intent(this, ProfileActivity.class);
		startActivity(intent);
	}
	
	private void startTrainingStepActivity() {
		Intent intent = new Intent(this, TrainingStepActivity.class);
		intent.putExtra(TrainingStepActivity.KEY_TRAINING, training);
		intent.putExtra(TrainingStepActivity.KEY_TRAININGID, trainingId);
		startActivity(intent);
	}
	
	private void startTrainingDetailsActivity() {
		Intent intent = new Intent(this, TrainingDetailsActivity.class);
		intent.putExtra(TrainingDetailsActivity.KEY_TRAINING_ID, trainingId);
		startActivity(intent);
	}
	
	private void startTrainingPastActivity() {
		Intent intent = new Intent(this, TrainingPastActivity.class);
		intent.putExtra(TrainingPastActivity.KEY_TRAINING_ID, trainingId);
		startActivity(intent);
	}
	
	private void back() {
		finish();
	}
}
