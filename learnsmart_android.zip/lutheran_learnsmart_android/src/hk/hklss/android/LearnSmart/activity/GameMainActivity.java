package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class GameMainActivity extends Activity implements View.OnClickListener {

	private final String TAG = GameMainActivity.class.getSimpleName();
	
	private AudioManager audioManager;
	
	private ImageButton homeButton;
	private ImageButton pairingGameButton;
	private ImageButton memoryGameButton;
	private ImageButton coinsGameButton;
	private ImageView animGirlImageView;
	private AnimationDrawable animGirl;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_main);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		audioManager.playMainBackground();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		audioManager.stopBackgroundAudio();
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.homeButton:
				back();
				break;
			case R.id.pairingGameButton:
				startGamePairingActivity();
				break;
			case R.id.memoryGameButton:
				startGameMemoryActivity();
				break;
			case R.id.coinsGameButton:
				startGameCoinsActivity();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
//			if (bundle.containsKey(KEY_LOGIN)) {
//				login = (MobileLogin) bundle.getParcelable(KEY_LOGIN);
//			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		homeButton = (ImageButton) findViewById(R.id.homeButton);
		pairingGameButton = (ImageButton) findViewById(R.id.pairingGameButton);
		memoryGameButton = (ImageButton) findViewById(R.id.memoryGameButton);
		coinsGameButton = (ImageButton) findViewById(R.id.coinsGameButton);
		animGirlImageView = (ImageView) findViewById(R.id.animGirlImageView);
		
		animGirl = (AnimationDrawable) getResources().getDrawable(R.drawable.girl_anim);
		animGirlImageView.setImageDrawable(animGirl);
		animGirlImageView.post(new Runnable() {
		    @Override
		    public void run() {
		    	if (!animGirl.isRunning()) {
		    		animGirl.start();
		    	}
		    }
		});
		
		homeButton.setOnClickListener(this);
		pairingGameButton.setOnClickListener(this);
		memoryGameButton.setOnClickListener(this);
		coinsGameButton.setOnClickListener(this);
	}
	
	private void startGamePairingActivity() {
		Intent intent = new Intent(this, GamePairingLevelActivity.class);
		startActivity(intent);
	}
	
	private void startGameMemoryActivity() {
		Intent intent = new Intent(this, GameMemoryRuleActivity.class);
		startActivity(intent);
	}
	
	private void startGameCoinsActivity() {
		Intent intent = new Intent(this, GameCoinsLevelActivity.class);
		startActivity(intent);
	}

	private void back() {
		finish();
	}
}
