package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.util.MiscUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class LoginActivity extends Activity implements View.OnClickListener {

	private final String TAG = LoginActivity.class.getSimpleName();
	private final String KEY_LOGIN = "LoginActivity.login";
	
	private ImageButton okButton;
	private ImageButton forgetPasswordButton;
	private ImageButton homeButton;
	private ImageButton logoutButton;
	private EditText usernameEditView;
	private EditText passwordEditView;
	private LinearLayout loginContainer;
	private RelativeLayout logoutContainer;
	
	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loginProgressDialog;
	private ProgressDialog resetPasswordProgressDialog;
	private MobileLogin login;
	
	private Handler handler = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		if (login != null) {
			outState.putParcelable(KEY_LOGIN, login);
		}
		
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
		} 
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.okButton:
				login();
				break;
			case R.id.forgetPasswordButton:
				resetPassword();
				break;
			case R.id.homeButton:
				back(false);
				break;
			case R.id.logoutButton:
				logout();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
		}
	}
	
	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
		login = dataManager.getMobileLogin();
	}
	
	private void initUIElements() {
		okButton = (ImageButton) findViewById(R.id.okButton);
		forgetPasswordButton = (ImageButton) findViewById(R.id.forgetPasswordButton);
		homeButton = (ImageButton) findViewById(R.id.homeButton);
		logoutButton = (ImageButton) findViewById(R.id.logoutButton);
		usernameEditView = (EditText) findViewById(R.id.usernameEditView);
		passwordEditView = (EditText) findViewById(R.id.passwordEditView);
		loginContainer = (LinearLayout) findViewById(R.id.loginContainer);
		logoutContainer = (RelativeLayout) findViewById(R.id.logoutContainer);
		
		okButton.setOnClickListener(this);
		forgetPasswordButton.setOnClickListener(this);
		homeButton.setOnClickListener(this);
		logoutButton.setOnClickListener(this);
		
		passwordEditView.setOnEditorActionListener(new OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_GO) {
                    login();
                    return true;
                }
				return false;
			}
		});
		
		findViewById(R.id.loginView).setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (!(v instanceof EditText)) {
					MiscUtils.hideSoftKeybord(LoginActivity.this);
				}
				return true;
			}
		});
		
		if (login == null) {
			loginContainer.setVisibility(View.VISIBLE);
			logoutContainer.setVisibility(View.GONE);
		} else {
			loginContainer.setVisibility(View.GONE);
			logoutContainer.setVisibility(View.VISIBLE);
		}
	}
	
	private void login() {
		String username = usernameEditView.getText().toString();
		String password = passwordEditView.getText().toString();
		
		if (username == null || username.equals("") || password == null || password.equals("")) {
			showInvalidUsernamePasswordMessage();
			return;
		}
		
		showLoginProgressMessage();
		
		dataManager.postMobileLogin(username, password, new DataListener<MobileLogin>() {
			@Override
			public void onUpdate(boolean isUpdating) {
			}
			
			@Override
			public void onSuccess(MobileLogin object) {
				hideLoginProgressMessage();
				
				back(true);
				
				showLoginSuccessMessage(object.getUsername());
				usernameEditView.setText("");
				passwordEditView.setText("");
			}
			
			@Override
			public void onFailure(String message) {
				hideLoginProgressMessage();
				showLoginFailedMessage();
				usernameEditView.requestFocus();
				usernameEditView.selectAll();
			}
		});
	}
	
	private void logout() {
		dataManager.logout();
		
		this.login = null;
		
		loginContainer.setVisibility(View.VISIBLE);
		logoutContainer.setVisibility(View.GONE);
	}
	
	private void resetPassword() {
		String username = usernameEditView.getText().toString();
		
		if (username == null || username.equals("")) {
			showInvalidUsernameMessage();
			return;
		}
		
		showResetPasswordProgressMessage();
		
		dataManager.postMobileResetPassword(username, new DataListener<Boolean>() {
			@Override
			public void onUpdate(boolean isUpdating) {
			}
			
			@Override
			public void onSuccess(Boolean object) {
				hideResetPasswordProgressMessage();
				showResetPasswordMessage();
				usernameEditView.setText("");
				passwordEditView.setText("");
			}
			
			@Override
			public void onFailure(String message) {
				hideResetPasswordProgressMessage();
				showInvalidUsernameMessage();
				usernameEditView.requestFocus();
				usernameEditView.selectAll();
			}
		});
	}
	
	private void showInvalidUsernameMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog dialog = new AlertDialog.Builder(LoginActivity.this)
					.setTitle("")
					.setMessage(R.string.dialog_invalid_username_message)
					.setPositiveButton(android.R.string.ok, new OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
							usernameEditView.requestFocus();
							usernameEditView.selectAll();
						}
					})
					.show();
			}
		});
	}
	
	private void showInvalidUsernamePasswordMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog dialog = new AlertDialog.Builder(LoginActivity.this)
					.setTitle("")
					.setMessage(R.string.dialog_invalid_username_password_message)
					.setPositiveButton(android.R.string.ok, new OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
							usernameEditView.requestFocus();
							usernameEditView.selectAll();
						}
					})
					.show();
			}
		});
	}
	
	private void showResetPasswordMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog dialog = new AlertDialog.Builder(LoginActivity.this)
					.setTitle("")
					.setMessage(R.string.dialog_reset_password_message)
					.setPositiveButton(android.R.string.ok, new OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					})
					.show();
			}
		});
	}
	
	private void showLoginFailedMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog dialog = new AlertDialog.Builder(LoginActivity.this)
					.setTitle("")
					.setMessage(R.string.dialog_login_failed_message)
					.setPositiveButton(android.R.string.ok, new OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					})
					.show();
			}
		});
	}
	
	private void showLoginSuccessMessage(final String username) {
		handler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(LoginActivity.this, getString(R.string.dialog_login_success_message, username), Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	private void showResetPasswordProgressMessage() {
		hideResetPasswordProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (resetPasswordProgressDialog != null && resetPasswordProgressDialog.isShowing()) {
					resetPasswordProgressDialog.dismiss();
					resetPasswordProgressDialog = null;
				}
				
				resetPasswordProgressDialog = ProgressDialog.show(LoginActivity.this, "", "");
			}
		});
	}
	
	private void showLoginProgressMessage() {
		hideLoginProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loginProgressDialog != null && loginProgressDialog.isShowing()) {
					loginProgressDialog.dismiss();
					loginProgressDialog = null;
				}
				loginProgressDialog = ProgressDialog.show(LoginActivity.this, "", getString(R.string.dialog_login_progress_message));
			}
		});
	}
	
	private void hideResetPasswordProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (resetPasswordProgressDialog != null && resetPasswordProgressDialog.isShowing()) {
					resetPasswordProgressDialog.dismiss();
					resetPasswordProgressDialog = null;
				}
			}
		});
	}
	
	private void hideLoginProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loginProgressDialog != null && loginProgressDialog.isShowing()) {
					loginProgressDialog.dismiss();
					loginProgressDialog = null;
				}
			}
		});
	}
	
	private void back(boolean isSuccess) {
		if (isSuccess) {
			setResult(Activity.RESULT_OK);
		}
		finish();
	}
}
