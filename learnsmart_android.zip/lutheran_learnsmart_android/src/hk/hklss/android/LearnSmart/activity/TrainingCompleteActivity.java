package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.db.model.TrainingCategories;
import hk.hklss.android.LearnSmart.db.model.Trainings;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class TrainingCompleteActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingCompleteActivity.class.getSimpleName();
	public static final String KEY_RATINGS = "TrainingCommentActivity.ratings";
	public static final String KEY_TRAINING = "TrainingCompleteActivity.training";
	public static final String KEY_TRAINING_CATEGORY = "TrainingCompleteActivity.trainingCategory";

	private AudioManager audioManager;

	private int[] ratings;
	private Trainings training;
	private TrainingCategories trainingCategory;

	private ImageButton continueButton;
	private TextView categoryTitle;
	private TextView categoryTitleShadow;
	private TextView trainingTitle;
	private TextView dialogText;
	private ImageView activityTitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_complete);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putParcelable(KEY_TRAINING, training);
		outState.putParcelable(KEY_TRAINING_CATEGORY, trainingCategory);
		outState.putIntArray(KEY_RATINGS, ratings);

		super.onSaveInstanceState(outState);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK) {
	    	return false;
	    }

	    return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}

		switch (v.getId()) {
			case R.id.continueButton:
				back();
				break;
		}
	}

	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_RATINGS)) {
				ratings = bundle.getIntArray(KEY_RATINGS);
			}
			if (bundle.containsKey(KEY_TRAINING)) {
				training = bundle.getParcelable(KEY_TRAINING);
			}
			if (bundle.containsKey(KEY_TRAINING_CATEGORY)) {
				trainingCategory = bundle.getParcelable(KEY_TRAINING_CATEGORY);
			}
		}
	}

	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}

	private void initUIElements() {
		continueButton = (ImageButton) findViewById(R.id.continueButton);
		dialogText = (TextView) findViewById(R.id.dialogText);
		categoryTitle = (TextView) findViewById(R.id.categoryTitle);
		categoryTitleShadow = (TextView) findViewById(R.id.categoryTitleShadow);
		trainingTitle = (TextView) findViewById(R.id.trainingTitle);
		activityTitle = (ImageView) findViewById(R.id.activityTitle);

		continueButton.setOnClickListener(this);

		if (trainingCategory == null) {
//			categoryTitle.setVisibility(View.INVISIBLE);
//			categoryTitleShadow.setVisibility(View.INVISIBLE);
//			activityTitle.setVisibility(View.VISIBLE);
		} else {
//			categoryTitle.setVisibility(View.VISIBLE);
//			categoryTitleShadow.setVisibility(View.VISIBLE);
//			activityTitle.setVisibility(View.INVISIBLE);

			categoryTitle.setText(trainingCategory.getTitle());
			categoryTitleShadow.setText(trainingCategory.getTitle());
		}

		trainingTitle.setText(training.getTitle());

		if (ratings != null) {
			double averageRating = getAverageRating();
			int roundedAvgRating = (int) averageRating;
		    String formattedAverageRating = String.format("%.2f", averageRating);

		    if (roundedAvgRating <= 2) {
		    	dialogText.setText(getString(R.string.training_complete_dialog_rating_below_2, formattedAverageRating));
		    } else if (roundedAvgRating <= 4) {
	    		dialogText.setText(getString(R.string.training_complete_dialog_rating_below_4, formattedAverageRating));
		    } else {
		    	dialogText.setText(getString(R.string.training_complete_dialog_rating_below_5, formattedAverageRating));
		    }
	    } else {
	    	dialogText.setText(getString(R.string.training_complete_dialog_text));
	    }
	}

	private double getAverageRating() {
		if (ratings != null && ratings.length > 0) {
			int sum = 0;
			for (int i : ratings) {
				sum += i;
			}
			return (double) sum / ratings.length;
		}

		return 0;
	}

	private void startTrainingListActivity() {
		finish();
	}

	private void back() {
		finish();
	}
}
