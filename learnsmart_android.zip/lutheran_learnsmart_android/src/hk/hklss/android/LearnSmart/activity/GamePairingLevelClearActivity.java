package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants.GameLevel;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class GamePairingLevelClearActivity extends Activity implements View.OnClickListener {

	private final String TAG = GamePairingLevelClearActivity.class.getSimpleName();
	
	public final static String KEY_GAME_LEVEL = "game_level";
	public final static String KEY_GAME_ELAPSED_TIME = "game_elapsed_time";
	
	private AudioManager audioManager;
	
	private ImageButton homeButton, continueGameButton;
	private TextView elapsedTime;
	private ImageView cheerGirl;
	private ImageView gameClearText;
	private AnimationDrawable girlAnim;
	
	private GameLevel gameLevel;
	private String elapsedTimeString;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_pairing_level_clear);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		audioManager.playGameLevelClear();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.homeButton:
				startGameMainActivity();
				break;
			case R.id.continueGameButton:
				startGamePairingLevelActivity();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_GAME_LEVEL)) {
				int ordinal = bundle.getInt(KEY_GAME_LEVEL);
				gameLevel = GameLevel.values()[ordinal];
			}
			if (bundle.containsKey(KEY_GAME_ELAPSED_TIME)) {
				elapsedTimeString = bundle.getString(KEY_GAME_ELAPSED_TIME);
			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		homeButton = (ImageButton) findViewById(R.id.homeButton);
		continueGameButton = (ImageButton) findViewById(R.id.continueGameButton);
		elapsedTime = (TextView) findViewById(R.id.elapsedTime);
		cheerGirl = (ImageView) findViewById(R.id.cheerGirl);
		gameClearText = (ImageView) findViewById(R.id.gameClearText);
		
		homeButton.setOnClickListener(this);
		continueGameButton.setOnClickListener(this);
		
		elapsedTime.setText(elapsedTimeString);
	
		switch (gameLevel) {
		case Easy:
			gameClearText.setImageResource(R.drawable.game_pairing_end_text_easy);
			break;
		case Medium:
			gameClearText.setImageResource(R.drawable.game_pairing_end_text_medium);
			break;
		case Difficult:
			gameClearText.setImageResource(R.drawable.game_pairing_end_text_difficult);
			break;
		}
		
		girlAnim = (AnimationDrawable) getResources().getDrawable(R.drawable.game_end_girl_cheer_anim);
		cheerGirl.setImageDrawable(girlAnim);
		cheerGirl.post(new Runnable() {
		    @Override
		    public void run() {
		    	if (!girlAnim.isRunning()) {
		    		girlAnim.start();
		    	}
		    }
		});
	}
	
	private void startGamePairingLevelActivity() {
		Intent intent = new Intent(this, GamePairingLevelActivity.class);
		startActivity(intent);
		finish();
	}
	
	private void startGameMainActivity() {
		Intent intent = new Intent(this, GameMainActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(intent);
		finish();
	}

	private void back() {
		finish();
	}
}
