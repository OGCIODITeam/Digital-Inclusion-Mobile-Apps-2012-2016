package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants.GameLevel;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class GamePairingRuleActivity extends Activity implements View.OnClickListener {

	private final String TAG = GamePairingRuleActivity.class.getSimpleName();
	
	public final static String KEY_GAME_LEVEL = "game_level"; 
	
	private AudioManager audioManager;
	
	private ImageButton backButton, startGameButton;
	private GameLevel gameLevel;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game_pairing_rule);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
			case R.id.startGameButton:
				startStartGameActivity();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_GAME_LEVEL)) {
				int ordinal = bundle.getInt(KEY_GAME_LEVEL);
				gameLevel = GameLevel.values()[ordinal];
			}
		}
	}
	
	private void initBackend() {
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		startGameButton = (ImageButton) findViewById(R.id.startGameButton);
		
		backButton.setOnClickListener(this);
		startGameButton.setOnClickListener(this);
	}
	
	private void startStartGameActivity() {
		Intent intent = new Intent(this, GamePairingActivity.class);
		intent.putExtra(GamePairingActivity.KEY_GAME_LEVEL, gameLevel.ordinal());
		startActivity(intent);
		
		finish();
	}

	private void back() {
		finish();
	}
}
