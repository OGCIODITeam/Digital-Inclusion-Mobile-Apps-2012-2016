package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.TrainingCategories;
import hk.hklss.android.LearnSmart.db.model.Trainings;
import hk.hklss.android.LearnSmart.util.MiscUtils;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class TrainingCommentActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingCommentActivity.class.getSimpleName();
	public static final String KEY_RATINGS = "TrainingCommentActivity.ratings";
	public static final String KEY_TRAINING = "TrainingCommentActivity.training";
	public static final String KEY_TRAINING_CATEGORY = "TrainingCommentActivity.trainingCategory";
	
	private ImageButton skipButton;
	private ImageButton doneButton;
	private EditText commentText; 
	private TextView categoryTitle;
	private TextView categoryTitleShadow;
	private TextView trainingTitle;
	private ImageView activityTitle;
	private ProgressDialog loadingProgressDialog;
	
	private DataManager dataManager;
	private AudioManager audioManager;
	
	private int[] ratings;
	private Trainings training;
	private TrainingCategories trainingCategory;
	
	private Handler handler = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_comment);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putIntArray(KEY_RATINGS, ratings);
		outState.putParcelable(KEY_TRAINING, training);
		outState.putParcelable(KEY_TRAINING_CATEGORY, trainingCategory);
		
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
		} 
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK) {
	    	showSkipCommentMessage();
	    	return true;
	    }
	    
	    return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.doneButton:
				postCommentRatings();
				break;
			case R.id.skipButton:
				showSkipCommentMessage();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_RATINGS)) {
				ratings = bundle.getIntArray(KEY_RATINGS);
			}
			if (bundle.containsKey(KEY_TRAINING)) {
				training = bundle.getParcelable(KEY_TRAINING);
			}
			if (bundle.containsKey(KEY_TRAINING_CATEGORY)) {
				trainingCategory = bundle.getParcelable(KEY_TRAINING_CATEGORY);
			}
		}
	}
	
	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		doneButton = (ImageButton) findViewById(R.id.doneButton);
		skipButton = (ImageButton) findViewById(R.id.skipButton);
		commentText = (EditText) findViewById(R.id.commentText);
		categoryTitle = (TextView) findViewById(R.id.categoryTitle);
		categoryTitleShadow = (TextView) findViewById(R.id.categoryTitleShadow);
		trainingTitle = (TextView) findViewById(R.id.trainingTitle);
		activityTitle = (ImageView) findViewById(R.id.activityTitle);
		
		doneButton.setOnClickListener(this);
		skipButton.setOnClickListener(this);
		
		findViewById(R.id.trainingCommentLayout).setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (!(v instanceof EditText)) {
					MiscUtils.hideSoftKeybord(TrainingCommentActivity.this);
				}
				return true;
			}
		});
		
		if (trainingCategory == null) {
//			categoryTitle.setVisibility(View.INVISIBLE);
//			categoryTitleShadow.setVisibility(View.INVISIBLE);
//			activityTitle.setVisibility(View.VISIBLE);
		} else {
//			categoryTitle.setVisibility(View.VISIBLE);
//			categoryTitleShadow.setVisibility(View.VISIBLE);
//			activityTitle.setVisibility(View.INVISIBLE);
			
			categoryTitle.setText(trainingCategory.getTitle());
			categoryTitleShadow.setText(trainingCategory.getTitle());
		}
		
		trainingTitle.setText(training.getTitle());
	}
	
	private MobileLogin getLogin() {
		return dataManager.getMobileLogin();
	}
	
	private void postCommentRatings() {
		showLoadingProgressMessage();
		
		MobileLogin login = getLogin();
		
		dataManager.postTrainingSessions(login.getUsername(), login.getToken(), training.getId(), commentText.getText().toString(), intArrayToString(ratings), new DataListener<Boolean>() {
			@Override
			public void onSuccess(Boolean object) {
				hideLoadingProgressMessage();
				
				if (object) {
					startTrainingCompleteActivity();
				} else {
					showPostCommentRatingsErrorMessage();
				}
			}

			@Override
			public void onFailure(String message) {
				Log.d(TAG, message);
				hideLoadingProgressMessage();
				showPostCommentRatingsErrorMessage();
			}

			@Override
			public void onUpdate(boolean isUpdating) {
			}
		});
	}
	
	private String intArrayToString(int[] intArray) {
		String s = "";
		
		for (int i : intArray) {
			if (!s.equals("")) {
				s += ";";
			}
			s += i;
		}
		
		return s;
	}
	
	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(TrainingCommentActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}
	
	private void showPostCommentRatingsErrorMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				new AlertDialog.Builder(TrainingCommentActivity.this)
					.setCancelable(false)
					.setTitle("")
			    	.setMessage(R.string.dialog_submit_comment_ratings_error_message)
			    	.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
					        @Override
					        public void onClick(DialogInterface dialog, int which) {
					        	postCommentRatings();
					        }
				    	})
			    	.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
					        @Override
					        public void onClick(DialogInterface dialog, int which) {
					        	dialog.dismiss();
					        }
				    	})
			    	.show();
			}
		});
	}
		
	private void showSkipCommentMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				new AlertDialog.Builder(TrainingCommentActivity.this)
					.setCancelable(false)
					.setTitle("")
			    	.setMessage(R.string.dialog_skip_comment_message)
			    	.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
					        @Override
					        public void onClick(DialogInterface dialog, int which) {
					        	startTrainingCompleteActivity();
					        }
				    	})
			    	.setNegativeButton(android.R.string.no, null)
			    	.show();
			}
		});
	}
	
	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}
	
	private void startTrainingCompleteActivity() {
		Intent intent = new Intent(this, TrainingCompleteActivity.class);
		intent.putExtra(TrainingCompleteActivity.KEY_RATINGS, ratings);
		intent.putExtra(TrainingCompleteActivity.KEY_TRAINING, training);
		intent.putExtra(TrainingCompleteActivity.KEY_TRAINING_CATEGORY, trainingCategory);
		startActivity(intent);
		
		finish();
	}
	
	private void back() {
		finish();
	}
}
