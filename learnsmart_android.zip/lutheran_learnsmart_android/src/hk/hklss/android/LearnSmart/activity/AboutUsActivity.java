package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.News;

import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class AboutUsActivity extends Activity implements View.OnClickListener {

	private final String TAG = AboutUsActivity.class.getSimpleName();
//	private final String KEY_LOGIN = "AboutUsActivity.login";

	private ImageButton homeButton;
	private WebView aboutUsWebView;
//	private AccessibleWebView aboutUsWebView;
	private TextView newsTextView;

	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loadingProgressDialog;

	private Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_aboutus);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();

		getAboutUs();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
		}
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}

		switch (v.getId()) {
			case R.id.homeButton:
				back();
				break;
		}
	}

	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
		}
	}

	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}

	private void initUIElements() {
		homeButton = (ImageButton) findViewById(R.id.homeButton);
		aboutUsWebView = (WebView) findViewById(R.id.aboutUsWebView);
//		aboutUsWebView = (AccessibleWebView) findViewById(R.id.aboutUsWebView);
		newsTextView = (TextView) findViewById(R.id.newsTextView);

		homeButton.setOnClickListener(this);
	}

	private void getAboutUs() {
		showLoadingProgressMessage();

		String aboutUs = dataManager.getAboutUs(new DataListener<String>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					getNews();
				}
			}

			@Override
			public void onSuccess(String html) {
				showAboutUs(html);

				getNews();
			}

			@Override
			public void onFailure(String message) {
				getNews();
			}
		});

		showAboutUs(aboutUs);
	}

	private void getNews() {
		List<News> news = dataManager.getNews(new DataListener<List<News>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					hideLoadingProgressMessage();
				}
			}

			@Override
			public void onSuccess(List<News> object) {
				showData(object);
				hideLoadingProgressMessage();
			}

			@Override
			public void onFailure(String message) {
				hideLoadingProgressMessage();
			}
		});

		showData(news);
	}

	private void showAboutUs(String html) {
		if (android.os.Build.VERSION.SDK_INT <= android.os.Build.VERSION_CODES.GINGERBREAD_MR1) {
			html = html.replace("%cSSPath%", "file:///android_asset/about_us_phone_gingerbread.css");
		} else {
			int screenLayout = getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK;

			switch (screenLayout) {
			case Configuration.SCREENLAYOUT_SIZE_LARGE:
			case Configuration.SCREENLAYOUT_SIZE_XLARGE:
				html = html.replace("%cSSPath%", "file:///android_asset/about_us_tablet.css");
				break;
			default:
				html = html.replace("%cSSPath%", "file:///android_asset/about_us_phone.css");
				break;
			}
		}

		aboutUsWebView.loadDataWithBaseURL("", html, "text/html", "utf-8", "");
		aboutUsWebView.setBackgroundColor(0x00000000);
		aboutUsWebView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);

		WebSettings webSettings = aboutUsWebView.getSettings();
		webSettings.setJavaScriptEnabled(true);

		aboutUsWebView.addJavascriptInterface(new AboutUsWebViewInterface(), "HTMLOUT");
		aboutUsWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageFinished(WebView view, String url) {
				view.loadUrl("javascript:window.HTMLOUT.processHtml('<html>' + document.getElementsByTagName('html')[0].innerHTML + '</html>');");
			}
		});
	}

	private void showData(List<News> newsList) {
		// we concate the news in such way so that TalkBack app can read and speak
		// whole news at once.
		String html = "";
		for (News news : newsList) {
			html += "<h3>" + news.getTitle() + "</h3>";
			html += "<span>" + news.getDescription() + "</span><br />";
		}

		newsTextView.setText(Html.fromHtml(html));
	}

	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();

		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(AboutUsActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}

	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}

	private void back() {
		finish();
	}

	class AboutUsWebViewInterface {
		@JavascriptInterface
	    public void processHtml(String html) {
			if (html != null) {
				aboutUsWebView.setContentDescription(Html.fromHtml(html).toString());
			}
	    }
	}
}
