package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.Audio;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.cache.CacheLoader;
import hk.hklss.android.LearnSmart.cache.CacheLoadingListener;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.TrainingCategories;
import hk.hklss.android.LearnSmart.db.model.TrainingSteps;
import hk.hklss.android.LearnSmart.db.model.Trainings;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;

public class TrainingStepActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingStepActivity.class.getSimpleName();
	public static final String KEY_TRAINING = "TrainingStepActivity.training";
	public static final String KEY_TRAININGID = "TrainingStepActivity.trainingId";
	public static final String KEY_TRAININGSTEPS = "TrainingStepActivity.trainingSteps";

	private ImageButton backButton;
	private ImageButton ratingButton;
	private ImageButton speakerButton;
	private ImageButton previousButton;
	private ImageButton nextButton;
	private TextView categoryTitle;
	private TextView categoryTitleShadow;
	private TextView trainingTitle;
	private TextView stepText;
	private TextView noStepImageText;
	private ImageView stepImage;
	private ImageView activityTitle;
	private ProgressDialog loadingProgressDialog;

	private DataManager dataManager;
	private AudioManager audioManager;
	private CacheLoader cacheLoader;

	private MobileLogin login;
	private Trainings training;
	private TrainingCategories trainingCategory;
	private List<TrainingSteps> trainingSteps;
	private int trainingId;
	private int currentStepIndex = 0;
	private TrainingSteps currentTrainingStep;
	private int[] ratings;
	private boolean hasShownNotYetRatedMessage = false;
	private Audio currentAudio;

	private Handler handler = new Handler();
	private Handler downloadHandler = new Handler() {
		private int total = 0;
		private int current = 0;
		private boolean startCheck = false;

		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 1) {
				total++;
			} else if (msg.what == 2) {
				current++;
			} else if (msg.what == 3) {
				startCheck = true;
			}

			if (startCheck) {
				if (current == total) {
					if (trainingSteps == null || trainingSteps.isEmpty()) {
						hideLoadingProgressMessage();
						showNoTrainingStepMessage();
						back();
					} else {
						showStepData(currentStepIndex);
						hideLoadingProgressMessage();
					}
				}
			}
		}

	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_step);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();

		getData();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		if (currentAudio != null) {
			currentAudio.stop();
			currentAudio = null;
		}
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt(KEY_TRAININGID, trainingId);
		outState.putParcelable(KEY_TRAINING, training);
		outState.putParcelableArray(KEY_TRAININGSTEPS, trainingSteps.toArray(new TrainingSteps[0]));

		super.onSaveInstanceState(outState);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
			case Constants.REQUEST_CODE_RATING:
				if (resultCode == Activity.RESULT_OK) {
					ratings[currentStepIndex] = data.getIntExtra("rating", 0);

//					if (hasShownNotYetRatedMessage) {
//						hasShownNotYetRatedMessage = false;
//					}
				}
		}
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}

		switch (v.getId()) {
			case R.id.backButton:
				showExitTrainingMessage();
				break;
			case R.id.ratingButton:
				startTrainingStepRatingActivity();
				break;
			case R.id.speakerButton:
				playStepSound();
				break;
			case R.id.previousButton:
				previousStep();
				break;
			case R.id.nextButton:
				if (login != null && login.isTrainer() && !hasShownNotYetRatedMessage && ratings[currentStepIndex] == 0) {
					showNotYetRatedMessage();
				} else {
					nextStep();
				}

				break;
		}
	}

	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_TRAININGID)) {
				trainingId = bundle.getInt(KEY_TRAININGID);
			}
			if (bundle.containsKey(KEY_TRAINING)) {
				training = bundle.getParcelable(KEY_TRAINING);
			}
			if (bundle.containsKey(KEY_TRAININGSTEPS)) {
				Parcelable[] a = bundle.getParcelableArray(KEY_TRAININGSTEPS);
				TrainingSteps[] b = Arrays.copyOf(a, a.length, TrainingSteps[].class);
				trainingSteps = Arrays.asList(b);
			}
		}
	}

	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
		cacheLoader = CacheLoader.getInstance();
	}

	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		ratingButton = (ImageButton) findViewById(R.id.ratingButton);
		speakerButton = (ImageButton) findViewById(R.id.speakerButton);
		previousButton = (ImageButton) findViewById(R.id.previousButton);
		nextButton = (ImageButton) findViewById(R.id.nextButton);
		categoryTitle = (TextView) findViewById(R.id.categoryTitle);
		categoryTitleShadow = (TextView) findViewById(R.id.categoryTitleShadow);
		trainingTitle = (TextView) findViewById(R.id.trainingTitle);
		stepText = (TextView) findViewById(R.id.stepText);
		stepText.setMovementMethod(new ScrollingMovementMethod());
		noStepImageText = (TextView) findViewById(R.id.noStepImageText);
		stepImage = (ImageView) findViewById(R.id.stepImage);
		activityTitle = (ImageView) findViewById(R.id.activityTitle);

		backButton.setOnClickListener(this);
		ratingButton.setOnClickListener(this);
		speakerButton.setOnClickListener(this);
		previousButton.setOnClickListener(this);
		nextButton.setOnClickListener(this);

		resetUIElements();
	}

	private void resetUIElements() {
		categoryTitle.setText("");
		categoryTitleShadow.setText("");
		trainingTitle.setText("");
		stepText.setText("");
		noStepImageText.setVisibility(View.VISIBLE);
		stepImage.setImageBitmap(null);
	}

	private void getData() {
		showLoadingProgressMessage();

		login = dataManager.getMobileLogin();

		if (login == null || !login.isTrainer()) {
			ratingButton.setVisibility(View.INVISIBLE);
		}

		if (training == null) {
			training = getTraining(trainingId);
		}

		trainingCategory = getTrainingCategory(training.getTrainingCategoryId());
		trainingSteps = getTrainingSteps(training.getId());
		ratings = new int[trainingSteps.size()];

		showTrainingData();
	}

	private Trainings getTraining(int tid) {
		return dataManager.getTraining(tid);
	}

	private TrainingCategories getTrainingCategory(int catid) {
		return dataManager.getTrainingCategory(catid);
	}

	private List<TrainingSteps> getTrainingSteps(int tid) {
		return dataManager.getTrainingSteps(tid, new DataListener<List<TrainingSteps>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					getDataResources();
				}
			}

			@Override
			public void onSuccess(List<TrainingSteps> object) {
				trainingSteps = object;
				ratings = new int[object.size()];
				getDataResources();
			}

			@Override
			public void onFailure(String message) {
				getDataResources();
			}
		});
	}

	private void getDataResources() {
		if (trainingSteps != null) {
			for (TrainingSteps step : trainingSteps) {
				if (step.getPicture() != null && !step.getPicture().equals("")) {
					ImageLoader.getInstance().loadImage(step.getPicture(), new ImageLoadingListener() {
						@Override
						public void onLoadingStarted(String imageUri, View view) {
							downloadHandler.sendEmptyMessage(1);
						}

						@Override
						public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
							downloadHandler.sendEmptyMessage(2);
						}

						@Override
						public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
							downloadHandler.sendEmptyMessage(2);
						}

						@Override
						public void onLoadingCancelled(String imageUri, View view) {
							downloadHandler.sendEmptyMessage(2);
						}
					});
				}

				if (step.getSound() != null && !step.getSound().equals("")) {
					cacheLoader.load(Constants.CACHE_TYPE_AUDIO, step.getSound(), getApplicationContext(), new CacheLoadingListener() {
						@Override
						public void onLoadingStarted(String fileUri) {
							downloadHandler.sendEmptyMessage(1);
						}

						@Override
						public void onLoadingFailed(String fileUri, String reason) {
							downloadHandler.sendEmptyMessage(2);
						}

						@Override
						public void onLoadingComplete(String fileUri, File loadedFile) {
							downloadHandler.sendEmptyMessage(2);
						}

						@Override
						public void onLoadingCancelled(String fileUri) {
							downloadHandler.sendEmptyMessage(2);
						}
					});
				}
			}
		}

		downloadHandler.sendEmptyMessage(3);
	}

	private void showTrainingData() {
		if (trainingCategory == null) {
//			categoryTitle.setVisibility(View.INVISIBLE);
//			categoryTitleShadow.setVisibility(View.INVISIBLE);
//			activityTitle.setVisibility(View.VISIBLE);
		} else {
//			categoryTitle.setVisibility(View.VISIBLE);
//			categoryTitleShadow.setVisibility(View.VISIBLE);
//			activityTitle.setVisibility(View.INVISIBLE);

			categoryTitle.setText(trainingCategory.getTitle());
			categoryTitleShadow.setText(trainingCategory.getTitle());
		}

		trainingTitle.setText(training.getTitle());
	}

	private void showStepData(int stepIndex) {
		currentTrainingStep = trainingSteps.get(stepIndex);

		noStepImageText.setVisibility(View.VISIBLE);

		stepText.setText(String.format("%02d", stepIndex + 1) + ". " + (currentTrainingStep.getText() == null ? "" : currentTrainingStep.getText()));
		stepText.scrollTo(0, 0); // reset initial visible (scroll-)position

		if (currentTrainingStep.getPicture() != null && !currentTrainingStep.getPicture().equals("")) {
			ImageLoader.getInstance().displayImage(currentTrainingStep.getPicture(), stepImage, new ImageLoadingListener() {
				@Override
				public void onLoadingStarted(String imageUri, View view) {
				}

				@Override
				public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
				}

				@Override
				public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
					noStepImageText.setVisibility(View.INVISIBLE);
				}

				@Override
				public void onLoadingCancelled(String imageUri, View view) {
				}
			});
		}

		if (currentTrainingStep.getSound() == null || currentTrainingStep.getSound().equals("")) {
			speakerButton.setAlpha(100);
		} else {
			speakerButton.setAlpha(255);
		}

		if (currentStepIndex == 0) {
			previousButton.setAlpha(100);
		} else {
			previousButton.setAlpha(255);
		}

		playStepSound();
	}

	private void nextStep() {
		if (currentAudio != null) {
			currentAudio.stop();
			currentAudio = null;
		}

		if (currentStepIndex < trainingSteps.size() - 1) {
			currentStepIndex++;
			showStepData(currentStepIndex);
		} else {
			if (login == null || !checkRatings()) {
				startTrainingCompleteActivity();
			} else {
				startTrainingCommentActivity();
			}
		}
	}

	private void previousStep() {
		if (currentAudio != null) {
			currentAudio.stop();
			currentAudio = null;
		}

		if (currentStepIndex > 0) {
			currentStepIndex--;
			showStepData(currentStepIndex);
		} else {
//			showFirstStepMessage();
		}
	}

	private boolean checkRatings() {
		boolean isValid = true;

		for (int rating : ratings) {
			if (rating == 0) {
				isValid = false;
				break;
			}
		}

		return isValid;
	}

	private void playStepSound() {
		if (currentAudio != null) {
			currentAudio.stop();
			currentAudio = null;
		}

		if (currentTrainingStep.getSound() != null && !currentTrainingStep.getSound().equals("")) {
			cacheLoader.load(Constants.CACHE_TYPE_AUDIO, currentTrainingStep.getSound(), getApplicationContext(), new CacheLoadingListener() {
				@Override
				public void onLoadingStarted(String fileUri) {
				}

				@Override
				public void onLoadingFailed(String fileUri, String reason) {
				}

				@Override
				public void onLoadingComplete(String fileUri, File loadedFile) {
					currentAudio = audioManager.play(loadedFile);
				}

				@Override
				public void onLoadingCancelled(String fileUri) {
				}
			});
		}
	}

	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();

		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(TrainingStepActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}

	private void showFirstStepMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(TrainingStepActivity.this, R.string.dialog_first_step_message, Toast.LENGTH_SHORT).show();
			}
		});
	}

	private void showNoTrainingStepMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(TrainingStepActivity.this, R.string.dialog_no_training_step_message, Toast.LENGTH_SHORT).show();
			}
		});
	}

	private void showNotYetRatedMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				new AlertDialog.Builder(TrainingStepActivity.this)
					.setCancelable(false)
					.setTitle("")
			    	.setMessage(R.string.dialog_not_yet_rated_message)
			    	.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
					        @Override
					        public void onClick(DialogInterface dialog, int which) {
					        	hasShownNotYetRatedMessage = true;
					        	nextStep();
					        }
				    	})
			    	.setNegativeButton(android.R.string.no, null)
			    	.show();
			}
		});
	}

	private void showExitTrainingMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				new AlertDialog.Builder(TrainingStepActivity.this)
					.setCancelable(false)
					.setTitle("")
			    	.setMessage(R.string.dialog_exit_training_message)
			    	.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
					        @Override
					        public void onClick(DialogInterface dialog, int which) {
					        	back();
					        }
				    	})
			    	.setNegativeButton(android.R.string.no, null)
			    	.show();
			}
		});
	}

	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}

	private void startTrainingCommentActivity() {
		Intent intent = new Intent(this, TrainingCommentActivity.class);
		intent.putExtra(TrainingCommentActivity.KEY_RATINGS, ratings);
		intent.putExtra(TrainingCommentActivity.KEY_TRAINING, training);
		intent.putExtra(TrainingCommentActivity.KEY_TRAINING_CATEGORY, trainingCategory);
		startActivity(intent);

		finish();
	}

	private void startTrainingCompleteActivity() {
		Intent intent = new Intent(this, TrainingCompleteActivity.class);
		intent.putExtra(TrainingCompleteActivity.KEY_TRAINING, training);
		intent.putExtra(TrainingCompleteActivity.KEY_TRAINING_CATEGORY, trainingCategory);
		startActivity(intent);

		finish();
	}

	private void startTrainingStepRatingActivity() {
		Intent intent = new Intent(this, TrainingStepRatingActivity.class);
		intent.putExtra(TrainingStepRatingActivity.KEY_RATE, ratings[currentStepIndex]);
		startActivityForResult(intent, Constants.REQUEST_CODE_RATING);
	}

	private void back() {
		finish();
	}
}
