package hk.hklss.android.LearnSmart.activity;

import hk.com.cloudpillar.android.widget.wheel.AbstractWheelTextAdapter;
import hk.com.cloudpillar.android.widget.wheel.OnWheelChangedListener;
import hk.com.cloudpillar.android.widget.wheel.OnWheelClickedListener;
import hk.com.cloudpillar.android.widget.wheel.OnWheelScrollListener;
import hk.com.cloudpillar.android.widget.wheel.WheelView;
import hk.hklss.android.LearnSmart.Constants.TrainingListType;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.TrainingCategories;
import hk.hklss.android.LearnSmart.db.model.Trainings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class TrainingListingActivity extends Activity implements View.OnClickListener {

	private final String TAG = TrainingListingActivity.class.getSimpleName();
	public static final String KEY_LIST_TYPE = "TrainingListingActivity.listType";
	public static final String KEY_LOGIN = "TrainingListingActivity.login";
	public static final String KEY_CATEGORYID = "TrainingListingActivity.categoryId";
	public static final String KEY_CATEGORYNAME = "TrainingListingActivity.categoryName";

	private ImageButton backButton;
	private ImageButton profileButton;
	private ImageButton enterButton;
	private ImageView avatarImage;
	private TextView categoryTitle;
	private WheelView trainingWheel;
	private TrainingWheelAdapter trainingWheelAdapter;
	private AnimationDrawable animGirl;

	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loadingProgressDialog;
	private TrainingListType listType;
	private int categoryId;
	private String categoryName;
	private MobileLogin login;

	private Handler handler = new Handler();

	private int blankBackgrounds[] =
        new int[] {
    		R.drawable.training_item_01,
    		R.drawable.training_item_02,
    		R.drawable.training_item_03,
    		R.drawable.training_item_04,
    		R.drawable.training_item_05,
    		R.drawable.training_item_06,
//    		R.drawable.training_item_07,
//    		R.drawable.training_item_08
    	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_training_listing);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();

		if (listType == null) {
			throw new IllegalArgumentException();
		}

		switch (listType) {
			case Category:
				getTrainingCategories();
				break;
			case TrainingByCategory:
				categoryTitle.setText(categoryName);
				getTrainingsByCategory(categoryId);
				break;
			case TrainingByUser:
				profileButton.setVisibility(View.VISIBLE);

				if (login != null) {
					getTrainingsByUser(login.getUsername(), login.getToken());
				}
				break;
		}
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putSerializable(KEY_LIST_TYPE, listType);
		outState.putInt(KEY_CATEGORYID, categoryId);
		outState.putString(KEY_CATEGORYNAME, categoryName);
		outState.putParcelable(KEY_LOGIN, login);

		super.onSaveInstanceState(outState);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
		}
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}

		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
			case R.id.profileButton:
				startProfileActivity();
				break;
			case R.id.enterButton:
				TrainingWheelItem item = trainingWheelAdapter.getItem(trainingWheel.getCurrentItem());
				if (item != null) {
					if (listType == TrainingListType.Category) {
						startTrainingListingActivity(item.id, item.title);
					} else {
						startTrainingActivity(item.id);
					}
				}

				break;
		}
	}

	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_LIST_TYPE)) {
				listType = (TrainingListType) bundle.getSerializable(KEY_LIST_TYPE);
			}
			if (bundle.containsKey(KEY_CATEGORYID)) {
				categoryId = bundle.getInt(KEY_CATEGORYID);
			}
			if (bundle.containsKey(KEY_CATEGORYNAME)) {
				categoryName = bundle.getString(KEY_CATEGORYNAME);
			}
			if (bundle.containsKey(KEY_LOGIN)) {
				login = (MobileLogin) bundle.getParcelable(KEY_LOGIN);
			}
		}
	}

	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}

	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		profileButton = (ImageButton) findViewById(R.id.profileButton);
		enterButton = (ImageButton) findViewById(R.id.enterButton);
		categoryTitle = (TextView) findViewById(R.id.categoryTitle);
		avatarImage = (ImageView) findViewById(R.id.avatarImage);

		animGirl = (AnimationDrawable) getResources().getDrawable(R.drawable.girl_anim);
		avatarImage.setImageDrawable(animGirl);
		avatarImage.post(new Runnable() {
		    @Override
		    public void run() {
		    	if (!animGirl.isRunning()) {
		    		animGirl.start();
		    	}
		    }
		});

		backButton.setOnClickListener(this);
		profileButton.setOnClickListener(this);
		enterButton.setOnClickListener(this);

		categoryTitle.setText("");
		profileButton.setVisibility(View.INVISIBLE);

		trainingWheelAdapter = new TrainingWheelAdapter(this);

//		trainingWheelAdapter.setBackgroundResources(blankBackgrounds);

		trainingWheel = (WheelView) findViewById(R.id.trainingListView);
		trainingWheel.setViewAdapter(trainingWheelAdapter);
        trainingWheel.setVisibleItems(5);
        trainingWheel.setCurrentItem(0);
        trainingWheel.setWheelItemId(R.id.titleContainer);
        trainingWheel.setApplyScale(true);
        trainingWheel.setScale(1.0f, 0.7f);
        trainingWheel.setApplyAlpha(true);
        trainingWheel.setAlpha(1.0f, 0.1f);

        trainingWheel.addChangingListener(new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				audioManager.playScrolling();
				
				TrainingWheelItem item =  trainingWheelAdapter.getItem(newValue);
				wheel.setContentDescription(item.title);
//				item.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED);
			}
		});

        trainingWheel.addScrollingListener( new OnWheelScrollListener() {
            public void onScrollingStarted(WheelView wheel) {

            }
            public void onScrollingFinished(WheelView wheel) {
            }
        });
	}

	private HashMap<String, Integer> getCategoryMap() {
		HashMap<String, Integer> categoryMap = new HashMap<String, Integer>();

		categoryMap.put(getString(R.string.category1), R.drawable.training_cat_01);
		categoryMap.put(getString(R.string.category2), R.drawable.training_cat_02);
		categoryMap.put(getString(R.string.category3), R.drawable.training_cat_03);
		categoryMap.put(getString(R.string.category4), R.drawable.training_cat_04);
		categoryMap.put(getString(R.string.category5), R.drawable.training_cat_05);
		categoryMap.put(getString(R.string.category6), R.drawable.training_cat_06);
		categoryMap.put(getString(R.string.category7), R.drawable.training_cat_07);
		categoryMap.put(getString(R.string.category8), R.drawable.training_cat_08);

		return categoryMap;
	}

	private void getTrainingCategories() {
		showLoadingProgressMessage();

		List<TrainingCategories> trainingCategories = dataManager.getTrainingCategories(new DataListener<List<TrainingCategories>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					hideLoadingProgressMessage();
				}
			}

			@Override
			public void onSuccess(List<TrainingCategories> object) {
				showCategoryData(object);
				hideLoadingProgressMessage();
			}

			@Override
			public void onFailure(String message) {
				hideLoadingProgressMessage();
			}
		});

		showCategoryData(trainingCategories);
	}

	private void getTrainingsByCategory(int categoryId) {
		showLoadingProgressMessage();

		List<Trainings> trainings = dataManager.getTrainingsByCategory(categoryId, new DataListener<List<Trainings>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					hideLoadingProgressMessage();
				}
			}

			@Override
			public void onSuccess(List<Trainings> object) {
				showTrainingData(object);
				hideLoadingProgressMessage();
			}

			@Override
			public void onFailure(String message) {
				hideLoadingProgressMessage();
			}
		});

		showTrainingData(trainings);
	}

	private void getTrainingsByUser(String username, String token) {
		showLoadingProgressMessage();

		dataManager.getTrainingCategories(new DataListener<List<TrainingCategories>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
			}

			@Override
			public void onSuccess(List<TrainingCategories> object) {
			}

			@Override
			public void onFailure(String message) {
			}
		});

		List<Trainings> trainings = dataManager.getTrainingsByMobileLogin(username, token, new DataListener<List<Trainings>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					hideLoadingProgressMessage();
				}
			}

			@Override
			public void onSuccess(List<Trainings> object) {
				showTrainingData(object);
				hideLoadingProgressMessage();
			}

			@Override
			public void onFailure(String message) {
				hideLoadingProgressMessage();
			}
		});

		showTrainingData(trainings);
	}

	private void showCategoryData(List<TrainingCategories> categories) {
		TrainingWheelItem[] items = new TrainingWheelItem[categories.size()];
		HashMap<String, Integer> categoryMap = getCategoryMap();

		for (int i = 0; i < categories.size(); i++) {
			TrainingCategories data = categories.get(i);
			String title = data.getTitle();

			items[i] = new TrainingWheelItem();
			items[i].id = data.getId();
			items[i].title = title;

			if (categoryMap.containsKey(title)) {
				items[i].backgroundResId = categoryMap.get(title);
				items[i].showTitle = false;
			} else {
				items[i].backgroundResId = blankBackgrounds[0];
			}
		}

		showData(items);
	}

	private void showTrainingData(List<Trainings> trainings) {
		TrainingWheelItem[] items = new TrainingWheelItem[trainings.size()];

		for (int i = 0; i < trainings.size(); i++) {
			Trainings data = trainings.get(i);

			items[i] = new TrainingWheelItem();
			items[i].id = data.getId();
			items[i].title = data.getTitle();
			items[i].backgroundResId = blankBackgrounds[i % blankBackgrounds.length];
		}

		showData(items);
	}

	private void showData(TrainingWheelItem[] items) {
		trainingWheelAdapter = new TrainingWheelAdapter(this);
		trainingWheelAdapter.addAll(items);

		trainingWheel.setViewAdapter(trainingWheelAdapter);
		trainingWheel.setCurrentItem(0);
	}

	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();

		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(TrainingListingActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}

	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}

	private void startProfileActivity() {
		Intent intent = new Intent(this, ProfileActivity.class);
		startActivity(intent);
	}

	private void startTrainingListingActivity(int catId, String catTitle) {
		Intent intent = new Intent(this, TrainingListingActivity.class);
		intent.putExtra(KEY_LIST_TYPE, TrainingListType.TrainingByCategory);
		intent.putExtra(KEY_CATEGORYID, catId);
		intent.putExtra(KEY_CATEGORYNAME, catTitle);
		startActivity(intent);
	}

	private void startTrainingActivity(int tid) {
		Intent intent = new Intent(this, TrainingActivity.class);
		intent.putExtra(TrainingActivity.KEY_TRAININGID, tid);
		startActivity(intent);
	}

	private void back() {
		finish();
	}

	public class TrainingWheelItem {

		public int id = 0;
		public String title = "";
		public int backgroundResId = 0;
		public boolean showTitle = true;

		public TrainingWheelItem() {
		}

	}

	public class TrainingWheelAdapter extends AbstractWheelTextAdapter {

		private List<TrainingWheelItem> items;

		public TrainingWheelAdapter(Context context) {
			this(context, new ArrayList<TrainingWheelItem>(0));
        }

        public TrainingWheelAdapter(Context context, List<TrainingWheelItem> items) {
        	super(context, R.layout.row_training_item, R.id.title);

//        	this.backgroundResources = new int[0];
        	this.items = items;
        }

        @Override
        public View getItem(int position, View cachedView, ViewGroup parent) {
        	View view = super.getItem(position, cachedView, parent);

        	TextView title = (TextView) view.findViewById(R.id.title);
        	title.setBackgroundResource(items.get(position).backgroundResId);
        	
        	view.setContentDescription(items.get(position).title);
//        	if (backgroundResources.length > 0) {
//        		title.setBackgroundResource(backgroundResources[position % backgroundResources.length]);
//        	}

        	return view;
        }

        @Override
        public int getItemsCount() {
            return this.items.size();
        }

        @Override
        protected CharSequence getItemText(int index) {
        	TrainingWheelItem item = getItem(index);
        	if (item != null) {
        		return item.showTitle ? item.title : "";
        	}

//        	if (item instanceof TrainingCategories) {
//        		return ((TrainingCategories) item).getTitle();
//			} else if (item instanceof Trainings) {
//				return ((Trainings) item).getTitle();
//			}

            return "";
        }

        public void clear() {
        	if (this.items != null) {
        		this.items.clear();
        	}
        }

		public void addAll(TrainingWheelItem[] items) {
			for (TrainingWheelItem item : items) {
				addItem(item);
			}
			
        	if (items.length > 0) {
        		trainingWheel.setContentDescription(items[0].title);
        	}
		}

        public void addItem(TrainingWheelItem item) {
        	this.items.add(item);
        }

        public TrainingWheelItem getItem(int index) {
        	if (index < this.items.size()) {
        		return this.items.get(index);
        	}
        	return null;
        }

//        public void setBackgroundResources(int[] resources) {
//        	this.backgroundResources = resources;
//        }

        public void notifyDataChanged() {
        	this.notifyDataChangedEvent();
        	
        	TrainingWheelItem item = getItem(0);
        	if (item != null) {
        		trainingWheel.setContentDescription(item.title);
        	}
        }
    }

}
