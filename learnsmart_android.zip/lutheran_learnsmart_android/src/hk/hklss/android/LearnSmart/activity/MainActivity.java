package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.Constants.TrainingListType;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.util.DialogHelper;
import hk.hklss.android.LearnSmart.util.MiscUtils;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {

	private final String TAG = MainActivity.class.getSimpleName();
	private final String KEY_LOGIN = "MainActivity.login";

	private DataManager dataManager;
	private AudioManager audioManager;
	private MobileLogin login;

	private ImageButton loginButton;
	private ImageButton aboutUsButton;
	private ImageButton miniGameButton;
	private ImageButton trainingButton;
	private ImageButton toggleBGMButton; // Toggle Background Music Button
	private ProgressDialog loginProgressDialog;
	private ImageView animGirlImageView;
	private AnimationDrawable animGirl;

	private Handler handler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);

		initBackend();
		initUIElements();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		super.onResume();
		audioManager.playMainBackground();
	}

	@Override
	protected void onPause() {
		super.onPause();
		audioManager.stopBackgroundAudio();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		if (login != null) {
			outState.putParcelable(KEY_LOGIN, login);
		}

		super.onSaveInstanceState(outState);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
			case Constants.REQUEST_CODE_LOGIN:
				login = getLogin();
				break;
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK) {
	    	DialogHelper.getInstance().showExitDialog(this);
	    	return true;
	    }

	    return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}

		switch (v.getId()) {
			case R.id.loginButton:
				startLoginActivity();
				break;
			case R.id.aboutUsButton:
				startAboutUsActivity();
				break;
			case R.id.miniGameButton:
				startMiniGameActivity();
				break;
			case R.id.trainingButton:
				startTrainingListingActivity();
				break;
			case R.id.toggleBGMButton:
				toggleBackgroundMusic();
				break;
		}
	}

	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
			if (bundle.containsKey(KEY_LOGIN)) {
				login = (MobileLogin) bundle.getParcelable(KEY_LOGIN);
			}
		}
	}

	private void initBackend() {
		audioManager = AudioManager.getInstance();
		dataManager = DataManager.getInstance();

		if (login == null) {
			login = getLogin();
		}

		if (login != null) {
//			if (!validateLogin(login)) {
				verifyLogin();
//			}
		}
	}

	private void initUIElements() {
		loginButton = (ImageButton) findViewById(R.id.loginButton);
		aboutUsButton = (ImageButton) findViewById(R.id.aboutUsButton);
		miniGameButton = (ImageButton) findViewById(R.id.miniGameButton);
		trainingButton = (ImageButton) findViewById(R.id.trainingButton);
		toggleBGMButton = (ImageButton) findViewById(R.id.toggleBGMButton);
		animGirlImageView = (ImageView) findViewById(R.id.animGirlImageView);

		animGirl = (AnimationDrawable) getResources().getDrawable(R.drawable.girl_anim);
		animGirlImageView.setImageDrawable(animGirl);
		animGirlImageView.post(new Runnable() {
		    @Override
		    public void run() {
		    	if (!animGirl.isRunning()) {
		    		animGirl.start();
		    	}
		    }
		});

		loginButton.setOnClickListener(this);
		aboutUsButton.setOnClickListener(this);
		miniGameButton.setOnClickListener(this);
		trainingButton.setOnClickListener(this);
		toggleBGMButton.setOnClickListener(this);
		updateToggleBGMButtonImage();
	}

	private MobileLogin getLogin() {
		return dataManager.getMobileLogin();
	}

	private boolean validateLogin(MobileLogin login) {
		boolean isValid = false;

		if (login != null && login.getToken() != null && login.getUsername() != null) {
			if (MiscUtils.isTokenValid(login.getTokenExpiryDate())) {
				isValid = true;
			}
		}

		return isValid;
	}

	private void verifyLogin() {
		showLoginProgressMessage();

		dataManager.postMobileLoginVerify(login.getUsername(), login.getToken(), new DataListener<MobileLogin>() {
			@Override
			public void onUpdate(boolean isUpdating) {
			}

			@Override
			public void onSuccess(MobileLogin object) {
				login = object;
				hideLoginProgressMessage();
				showLoginSuccessMessage();
			}

			@Override
			public void onFailure(String message) {
				dataManager.logout();
				login = null;
				hideLoginProgressMessage();
				showInvalidLoginTokenMessage();
			}
		});
	}

	private void showLoginSuccessMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this, getString(R.string.dialog_login_success_message, login.getUsername()), Toast.LENGTH_SHORT).show();
			}
		});
	}

	private void showLoginProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loginProgressDialog != null && loginProgressDialog.isShowing()) {
					loginProgressDialog.dismiss();
					loginProgressDialog = null;
				}

				loginProgressDialog = ProgressDialog.show(MainActivity.this, "", getString(R.string.dialog_login_progress_message));
			}
		});
	}

	private void showInvalidLoginTokenMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this, getString(R.string.dialog_invalid_login_token_message), Toast.LENGTH_SHORT).show();
			}
		});
	}

	private void hideLoginProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loginProgressDialog != null && loginProgressDialog.isShowing()) {
					loginProgressDialog.dismiss();
					loginProgressDialog = null;
				}
			}
		});
	}

	private void startLoginActivity() {
		Intent intent = new Intent(this, LoginActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivityForResult(intent, Constants.REQUEST_CODE_LOGIN);
	}

	private void startAboutUsActivity() {
		Intent intent = new Intent(this, AboutUsActivity.class);
		startActivity(intent);
	}

	private void startMiniGameActivity() {
		Intent intent = new Intent(this, GameMainActivity.class);
		startActivity(intent);
	}

	private void startTrainingListingActivity() {
		Intent intent = new Intent(this, TrainingListingActivity.class);

		if (login == null) {
			intent.putExtra(TrainingListingActivity.KEY_LIST_TYPE, TrainingListType.Category);
		} else {
			intent.putExtra(TrainingListingActivity.KEY_LIST_TYPE, TrainingListType.TrainingByUser);
			intent.putExtra(TrainingListingActivity.KEY_LOGIN, this.login);
		}

		startActivity(intent);
	}

	private void toggleBackgroundMusic() {
		if (audioManager.isBackgroundMusicEnabled()) {
			audioManager.disableBackgroundMusic();
			audioManager.stopBackgroundAudio();
		} else {
			audioManager.enableBackgroundMusic();
			audioManager.playMainBackground();
		}
		updateToggleBGMButtonImage();
	}

	/**
	 * Set the image resource of the button based on whether BGM is enabled
	 */
	private void updateToggleBGMButtonImage() {
		if (audioManager.isBackgroundMusicEnabled()) {
			toggleBGMButton.setImageResource(R.drawable.speaker_button);
		} else {
			toggleBGMButton.setImageResource(R.drawable.speaker_mute);
		}
	}
}
