package hk.hklss.android.LearnSmart.activity;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.R;
import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.data.DataListener;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.model.HallOfFame;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.TrainingCategoryScores;
import hk.hklss.android.LearnSmart.db.model.UserProfile;
import hk.hklss.android.LearnSmart.util.GraphicUtils;

import java.io.File;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;

public class ProfileActivity extends Activity implements View.OnClickListener {

	private final String TAG = ProfileActivity.class.getSimpleName();
//	private final String KEY_LOGIN = "ProfileActivity.login";
	
	private ImageButton backButton;
	private ImageButton changeProfileImageButton;
	private ImageView profileImage;
	private WebView profileChartWebView;
	private RelativeLayout hallOfFamesContainer;
	private ImageView traineeMark;
	private RelativeLayout profileChartContainer;
	private LinearLayout middleContainer;
	private TextView noPhotoText1;
	private TextView noPhotoText2;
	
	private DataManager dataManager;
	private AudioManager audioManager;
	private ProgressDialog loadingProgressDialog;
	private ProgressDialog updatingProgressDialog;
	
	private MobileLogin login;
	private UserProfile userProfile;
	private List<TrainingCategoryScores> categoryScores;
	private List<HallOfFame> hallOfFames;
	
	private Handler handler = new Handler();
	
	private Handler dataHandler = new Handler() {
		private int total = 0;
		private int current = 0;
		private boolean startCheck = false;
		
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 1) {
				total++;
			} else if (msg.what == 2) {
				current++;
			} else if (msg.what == 3) {
				startCheck = true;
			} else if (msg.what == 4) {
				hideLoadingProgressMessage();
			}
			
			if (startCheck) {
				if (current == total) {
					showData();
					startCheck = false;
				}
			}
		}
		
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);

		initFromBundle(getIntent().getExtras());
		initFromBundle(savedInstanceState);
		
		initBackend();
		initUIElements();
		
		getData();
	}

	@Override
	protected void onStart() {
		super.onStart();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}
	
	@Override 
	public void onActivityResult(int requestCode, int resultCode, Intent data) {     
		super.onActivityResult(requestCode, resultCode, data); 
		
		switch (requestCode) {
			case Constants.REQUEST_CODE_PICK_IMAGE:
				if (resultCode == RESULT_OK) {  
					Uri selectedImage = data.getData();
			        String[] filePathColumn = { MediaStore.Images.Media.DATA };
			 
			        Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
			        cursor.moveToFirst();
			 
			        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			        String picturePath = cursor.getString(columnIndex);
			        cursor.close();
					
		            updateProfileImage(picturePath);
		        }
				break;
		} 
	}

	@Override
	public void onClick(View v) {
		if (v instanceof Button || v instanceof ImageButton) {
			audioManager.playPressButton();
		}
		
		switch (v.getId()) {
			case R.id.backButton:
				back();
				break;
			case R.id.changeProfileImageButton:
				startImagePickerIntent();
				break;
		}
	}
	
	private void initFromBundle(Bundle bundle) {
		if (bundle != null) {
		}
	}
	
	private void initBackend() {
		dataManager = DataManager.getInstance();
		audioManager = AudioManager.getInstance();
	}
	
	private void initUIElements() {
		backButton = (ImageButton) findViewById(R.id.backButton);
		changeProfileImageButton = (ImageButton) findViewById(R.id.changeProfileImageButton);
		profileImage = (ImageView) findViewById(R.id.profileImage);
		profileChartWebView = (WebView) findViewById(R.id.profileChartWebView);
		hallOfFamesContainer = (RelativeLayout) findViewById(R.id.hallOfFamesContainer);
		traineeMark = (ImageView) findViewById(R.id.traineeMark);
		profileChartContainer = (RelativeLayout) findViewById(R.id.profileChartContainer);
		middleContainer = (LinearLayout) findViewById(R.id.middleContainer);
		noPhotoText1 = (TextView) findViewById(R.id.noPhotoText1);
		noPhotoText2 = (TextView) findViewById(R.id.noPhotoText2);
		
		backButton.setOnClickListener(this);
		changeProfileImageButton.setOnClickListener(this);
		
		profileImage.setImageDrawable(null);
		traineeMark.setVisibility(View.INVISIBLE);
		noPhotoText1.setVisibility(View.VISIBLE);
		noPhotoText2.setVisibility(View.INVISIBLE);
	}
	
	private void getData() {
		showLoadingProgressMessage();
		
		login = getLogin();
		
		getCategoryScores();
		
		getMobileUserProfile();
		
		getHallOfFames();
		
		dataHandler.sendEmptyMessage(3);
	}
	
	private MobileLogin getLogin() {
		return dataManager.getMobileLogin();
	}
	
	private void getCategoryScores() {
		dataHandler.sendEmptyMessage(1);
		
		categoryScores = dataManager.getTrainingCategoryScores(login.getUsername(), login.getToken(), new DataListener<List<TrainingCategoryScores>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					dataHandler.sendEmptyMessage(2);
				}
			}
			
			@Override
			public void onSuccess(List<TrainingCategoryScores> object) {
				categoryScores = object;
				dataHandler.sendEmptyMessage(2);
			}
			
			@Override
			public void onFailure(String message) {
				dataHandler.sendEmptyMessage(2);
			}
		});
	}

	private void getMobileUserProfile() {
		dataHandler.sendEmptyMessage(1);
		
		userProfile = dataManager.getUserProfile(login.getUsername(), login.getToken(), new DataListener<UserProfile>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					dataHandler.sendEmptyMessage(2);
				}
			}
			
			@Override
			public void onSuccess(UserProfile object) {
				userProfile = object;
				dataHandler.sendEmptyMessage(2);
			}
			
			@Override
			public void onFailure(String message) {
				dataHandler.sendEmptyMessage(2);
			}
		});
	}
	
	private void getHallOfFames() {
		dataHandler.sendEmptyMessage(1);
		
		hallOfFames = dataManager.getHallOfFames(login.getUsername(), login.getToken(), new DataListener<List<HallOfFame>>() {
			@Override
			public void onUpdate(boolean isUpdating) {
				if (!isUpdating) {
					dataHandler.sendEmptyMessage(2);
				}
			}
			
			@Override
			public void onSuccess(List<HallOfFame> object) {
				hallOfFames = object;
				dataHandler.sendEmptyMessage(2);
			}
			
			@Override
			public void onFailure(String message) {
				dataHandler.sendEmptyMessage(2);
			}
		});
	}
	
	private void updateProfileImage(String imagePath) {
		showUpdatingProgressMessage();
		
		try {
			File file = new File(imagePath);
			
			dataManager.postUserProfileUpdate(login.getUsername(), login.getToken(), file, new DataListener<Boolean>() {
				@Override
				public void onUpdate(boolean isUpdating) {
				}
				
				@Override
				public void onSuccess(Boolean object) {
					hideUpdatingProgressMessage();
					showProfileUpdateSuccessMessage();
					getData();
				}
				
				@Override
				public void onFailure(String message) {
					hideUpdatingProgressMessage();
					showProfileUpdateErrorMessage();
				}
			});
		} catch(Exception e) {
			
		}
	}
	
	private void showData() {
		showProfileImage();
		showProfileChart();
		showHallOfFames();
	}
	
	private void showProfileImage() {
		noPhotoText1.setVisibility(View.VISIBLE);
		
		if (userProfile != null && userProfile.getProfilePhoto() != null && !userProfile.getProfilePhoto().equals("")) {
			ImageLoader.getInstance().displayImage(userProfile.getProfilePhoto(), profileImage, new ImageLoadingListener() {
				@Override
				public void onLoadingStarted(String imageUri, View view) {
				}
				
				@Override
				public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
					dataHandler.sendEmptyMessage(4);
				}
				
				@Override
				public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
					dataHandler.sendEmptyMessage(4);
					noPhotoText1.setVisibility(View.INVISIBLE);
				}
				
				@Override
				public void onLoadingCancelled(String imageUri, View view) {
					dataHandler.sendEmptyMessage(4);
				}
			});
		}
	}
	
	private void showProfileChart() {
		profileChartWebView.getSettings().setJavaScriptEnabled(true);
		profileChartWebView.setBackgroundColor(0x00000000);
		profileChartWebView.setHorizontalScrollBarEnabled(false);
		profileChartWebView.setVerticalScrollBarEnabled(false);
		profileChartWebView.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					//profileChartWebView.reload();
					return true;
				case MotionEvent.ACTION_MOVE:
					return true;
				}
				
				return false;
			}
		});
		
		profileChartWebView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageFinished(WebView view, String url) {
				view.loadUrl(String.format("javascript:setCanvasSize(%d, %d)", 
						GraphicUtils.convertPixelsToDpInt(view.getWidth(), ProfileActivity.this), 
						GraphicUtils.convertPixelsToDpInt(view.getHeight(), ProfileActivity.this)
					));
				
				if (categoryScores != null) {
					for (TrainingCategoryScores s : categoryScores) {
						view.loadUrl(String.format("javascript:addStrength('%s', %f)", s.getTitle(), s.getScore()));
					}
				}
				
				view.loadUrl("javascript:finalize()");
			}
			
			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				Log.e(TAG, "failed to load url: " + failingUrl);
				Log.e(TAG, "error code:" + errorCode + "  description: " + description);
				
				profileChartWebView.reload();
				
				super.onReceivedError(view, errorCode, description, failingUrl);
			}
		});
		
		profileChartWebView.loadUrl("file:///android_asset/RadarChart/chart.html");
		
		String contentDescription = "";
		if (categoryScores != null) {
			for (TrainingCategoryScores s : categoryScores) {
				contentDescription += getString(R.string.profile_chart_content_description_format, s.getTitle(), String.format("%.1f", s.getScore()));
			}
		}
		profileChartWebView.setContentDescription(contentDescription);
	}
	
	private void showHallOfFames() {
		if (hallOfFames == null) {
			return;
		}
		
		int maxWidth = hallOfFamesContainer.getWidth();
		int maxHeight = hallOfFamesContainer.getHeight();
		int mePosY = (int)Math.round(maxHeight * Constants.HOF_ME_POSY_FACTOR);
		int buddyPosY = (int)Math.round(maxHeight * Constants.HOF_BUDDY_POSY_FACTOR);
		
		int buddyHeight = (int) Math.round(maxHeight * Constants.HOF_BUDDY_HEIGHT_FACTOR);
		int meHeight = (int) Math.round(maxHeight * Constants.HOF_ME_HEIGHT_FACTOR);
		
		Drawable meBgDrawable = traineeMark.getBackground();
		int meWidth = (int) ((double)meBgDrawable.getIntrinsicWidth() / meBgDrawable.getIntrinsicHeight() * meHeight);
		
		for (int i = 0; i < hallOfFames.size(); i++) {
			HallOfFame hallOfFame = hallOfFames.get(i);
			
			int markPosX = (int) ((float)maxWidth / 100 * hallOfFame.getRank() - meWidth);
			
			if (hallOfFame.isMe()) {
				int oriPaddingTop = traineeMark.getPaddingTop();
				int oriPaddingBottom = traineeMark.getPaddingBottom();
				int oriPaddingLeft = traineeMark.getPaddingLeft();
				int oriPaddingRight = traineeMark.getPaddingRight();
				int oriWidth = traineeMark.getWidth();
				int oriHeight = traineeMark.getHeight();
				
				noPhotoText2.setVisibility(View.VISIBLE);
				if (userProfile.getProfilePhoto() != null && !userProfile.getProfilePhoto().equals("")) {
					ImageLoader.getInstance().displayImage(userProfile.getProfilePhoto(), traineeMark, new ImageLoadingListener() {
						@Override
						public void onLoadingStarted(String imageUri, View view) {
						}
						
						@Override
						public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
						}
						
						@Override
						public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
							noPhotoText2.setVisibility(View.INVISIBLE);
						}
						
						@Override
						public void onLoadingCancelled(String imageUri, View view) {
						}
					});
				}
				
				RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) traineeMark.getLayoutParams();
				lp.width = meWidth;
				lp.height = meHeight;
				lp.setMargins(markPosX, 0, 0, mePosY);
				lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
				
				int newPaddingLeft = Math.round((float) oriPaddingLeft / oriWidth * meWidth);
				int newPaddingTop = Math.round((float) oriPaddingTop / oriHeight * meHeight);
				int newPaddingRight = Math.round((float) oriPaddingRight / oriWidth * meWidth);
				int newPaddingBottom = Math.round((float) oriPaddingBottom / oriHeight * meHeight);
				
				traineeMark.setPadding(newPaddingLeft, newPaddingTop, newPaddingRight, newPaddingBottom);
				traineeMark.setVisibility(View.VISIBLE);
			} else {
				ImageView buddyMark = new ImageView(getApplicationContext());
				hallOfFamesContainer.addView(buddyMark);
				
				buddyMark.setScaleType(ScaleType.FIT_END);
				buddyMark.setAdjustViewBounds(true);
				
				switch (i%3) {
					case 0:
						buddyMark.setImageResource(R.drawable.buddy_1);
						break;
					case 1:
						buddyMark.setImageResource(R.drawable.buddy_2);
						break;
					case 2:
						buddyMark.setImageResource(R.drawable.buddy_3);
						break;
				}
				
				Drawable buddyDrawable = buddyMark.getDrawable();
				int buddyWidth = (int) ((double)buddyDrawable.getIntrinsicWidth() / buddyDrawable.getIntrinsicHeight() * buddyHeight); 
				
				RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) buddyMark.getLayoutParams();
				lp.width = buddyWidth;
				lp.height = buddyHeight;
				lp.setMargins(markPosX, 0, 0, buddyPosY);
				lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
			}		
		}
		
		traineeMark.bringToFront();
		
		RelativeLayout.LayoutParams middleLp = (RelativeLayout.LayoutParams) middleContainer.getLayoutParams();
		middleLp.bottomMargin = (int)Math.round(maxHeight * Constants.HOF_PROFILE_CHART_MARGIN_BOTTOM_FACTOR);
	}
	
	private void showLoadingProgressMessage() {
		hideLoadingProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
				loadingProgressDialog = ProgressDialog.show(ProfileActivity.this, "", getString(R.string.dialog_loading_message));
			}
		});
	}
	
	private void showUpdatingProgressMessage() {
		hideUpdatingProgressMessage();
		
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (updatingProgressDialog != null && updatingProgressDialog.isShowing()) {
					updatingProgressDialog.dismiss();
					updatingProgressDialog = null;
				}
				updatingProgressDialog = ProgressDialog.show(ProfileActivity.this, "", getString(R.string.dialog_updating_message));
			}
		});
	}
	
	private void showProfileUpdateSuccessMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(ProfileActivity.this, R.string.dialog_profile_update_success_message, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	private void showProfileUpdateErrorMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				new AlertDialog.Builder(ProfileActivity.this)
					.setCancelable(false)
					.setTitle("")
			    	.setMessage(R.string.dialog_profile_update_error_message)
			    	.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
					        @Override
					        public void onClick(DialogInterface dialog, int which) {
					        	dialog.dismiss();
					        }
				    	})
			    	.show();
			}
		});
	}
	
	private void hideLoadingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (loadingProgressDialog != null && loadingProgressDialog.isShowing()) {
					loadingProgressDialog.dismiss();
					loadingProgressDialog = null;
				}
			}
		});
	}
	
	private void hideUpdatingProgressMessage() {
		handler.post(new Runnable() {
			@Override
			public void run() {
				if (updatingProgressDialog != null && updatingProgressDialog.isShowing()) {
					updatingProgressDialog.dismiss();
					updatingProgressDialog = null;
				}
			}
		});
	}
	
	private void startImagePickerIntent() {
		Intent imagePickerIntent = new Intent(Intent.ACTION_PICK);
		imagePickerIntent.setType("image/*");
        startActivityForResult(imagePickerIntent, Constants.REQUEST_CODE_PICK_IMAGE);
	}
	
	private void back() {
		finish();
	}
}
