package hk.hklss.android.LearnSmart.config;

import hk.com.cloudpillar.android.common.preference.PreferenceHelper;
import android.content.Context;

public class ConfigLoader {

	private static final String TAG = ConfigLoader.class.getSimpleName();
	private static ConfigLoader configLoader = null;
	
	private PreferenceHelper prefHelper = null;
	
	private AppSettings appSettings = null;
	
	private ConfigLoader() {
	}
	
	public synchronized static ConfigLoader getInstance() {
		if (configLoader == null) {
			configLoader = new ConfigLoader();
		}
		
		return configLoader;
	}
	
	public void init(Context context, String initConfigFolder) {
		prefHelper = PreferenceHelper.getInstance(context);
		loadAll();
		
		if (appSettings == null || !appSettings.isInitialized()) {
			prefHelper.importFromAssets(initConfigFolder);
			loadAll();
		}
		
		appSettings.initEmptyFieldsWithDefaultValues();
		
		saveAppSettings();
	}
	
	public void checkSettings() throws InvalidValueException {
		appSettings.checkSettings();
	}
	
	private void loadAll() {
		appSettings = prefHelper.read(AppSettings.class);
	}
	
	public void reload() {
		loadAll();
	}
	
	public void saveAppSettings() {
		prefHelper.save(AppSettings.class, appSettings);
	}
	
	public AppSettings getAppSettings() {
		return appSettings;
	}

	public void setAppSettings(AppSettings appSettings) {
		this.appSettings = appSettings;
	}
}
