package hk.hklss.android.LearnSmart.config;

import java.text.ParseException;
import java.util.Date;

import hk.com.cloudpillar.android.common.preference.Preference;
import hk.com.cloudpillar.android.common.preference.PreferenceBase;
import hk.hklss.android.LearnSmart.util.DateUtils;

@Preference("AppSettings")
public class AppSettings extends PreferenceBase {

	private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	private static final int DEFAULT_URL_CONNECT_TIMEOUT = 30000; // milliseconds
	private static final int DEFAULT_URL_READ_TIMEOUT = 30000; // milliseconds
	private static final String DEFAULT_CACHE_FOLDER_IMAGE = "image";
	private static final String DEFAULT_CACHE_FOLDER_DOCUMENT = "doc";
	private static final String DEFAULT_CACHE_FOLDER_AUDIO = "audio";
	private static final String DEFAULT_CACHE_FOLDER_THEME = "theme";
	
	private int projectId;
	private String wsBaseUrl;
	
	private String generalDateFormat;
	private String jsonDateFormat;
	private int urlConnectTimeout;
	private int urlReadTimeout;
	private String imageCacheFolder;
	private String audioCacheFolder;
	private String documentCacheFolder;
	private String themeCacheFolder;
	private boolean initialized;
	
	public AppSettings() {
	}
	
	public void initEmptyFieldsWithDefaultValues() {
		if (generalDateFormat == null || generalDateFormat.equals("")) {
			generalDateFormat = DEFAULT_DATE_FORMAT;
		}
		if (jsonDateFormat == null || jsonDateFormat.equals("")) {
			jsonDateFormat = DEFAULT_DATE_FORMAT;
		}
		if (urlConnectTimeout <= 0) {
			urlConnectTimeout = DEFAULT_URL_CONNECT_TIMEOUT;
		}
		if (urlReadTimeout <= 0) {
			urlReadTimeout = DEFAULT_URL_READ_TIMEOUT;
		}
		if (imageCacheFolder == null || imageCacheFolder.equals("")) {
			imageCacheFolder = DEFAULT_CACHE_FOLDER_IMAGE;
		}
		if (audioCacheFolder == null || audioCacheFolder.equals("")) {
			audioCacheFolder = DEFAULT_CACHE_FOLDER_AUDIO;
		}
		if (documentCacheFolder == null || documentCacheFolder.equals("")) {
			documentCacheFolder = DEFAULT_CACHE_FOLDER_DOCUMENT;
		}
		if (getThemeCacheFolder() == null || getThemeCacheFolder().equals("")) {
			setThemeCacheFolder(DEFAULT_CACHE_FOLDER_THEME);
		}
	}
	
	public void checkSettings() throws InvalidValueException {
		if (projectId <= 0) {
			throw new InvalidValueException("projectId", projectId);
		}
		if (wsBaseUrl == null || wsBaseUrl.equals("")) {
			throw new InvalidValueException("wsBaseUrl", wsBaseUrl);
		}
	}
	
	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getJsonDateFormat() {
		return jsonDateFormat;
	}

	public void setJsonDateFormat(String jsonDateFormat) {
		this.jsonDateFormat = jsonDateFormat;
	}

	public String getGeneralDateFormat() {
		return generalDateFormat;
	}

	public void setGeneralDateFormat(String generalDateFormat) {
		this.generalDateFormat = generalDateFormat;
	}

	public String getWSBaseUrl() {
		return wsBaseUrl;
	}

	public void setWSBaseUrl(String wsBaseUrl) {
		wsBaseUrl = wsBaseUrl.trim();
		this.wsBaseUrl = wsBaseUrl.endsWith("/") ? wsBaseUrl : wsBaseUrl + "/";
	}

	public int getUrlConnectTimeout() {
		return urlConnectTimeout;
	}

	public void setUrlConnectTimeout(int urlConnectTimeout) {
		this.urlConnectTimeout = urlConnectTimeout;
	}

	public int getUrlReadTimeout() {
		return urlReadTimeout;
	}

	public void setUrlReadTimeout(int urlReadTimeout) {
		this.urlReadTimeout = urlReadTimeout;
	}
	
	public String getImageCacheFolder() {
		return imageCacheFolder;
	}

	public void setImageCacheFolder(String imageCacheFolder) {
		this.imageCacheFolder = imageCacheFolder;
	}

	public String getAudioCacheFolder() {
		return audioCacheFolder;
	}

	public void setAudioCacheFolder(String audioCacheFolder) {
		this.audioCacheFolder = audioCacheFolder;
	}

	public String getDocumentCacheFolder() {
		return documentCacheFolder;
	}

	public void setDocumentCacheFolder(String documentCacheFolder) {
		this.documentCacheFolder = documentCacheFolder;
	}

	public String getThemeCacheFolder() {
		return themeCacheFolder;
	}

	public void setThemeCacheFolder(String themeCacheFolder) {
		this.themeCacheFolder = themeCacheFolder;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}
}