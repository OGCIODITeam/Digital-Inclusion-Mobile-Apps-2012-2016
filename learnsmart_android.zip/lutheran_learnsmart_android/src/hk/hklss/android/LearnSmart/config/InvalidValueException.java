package hk.hklss.android.LearnSmart.config;

public class InvalidValueException extends Exception {

	private static final long serialVersionUID = -7293039626737601639L;

	private String messageFormat = "Invalid value assigned for field '%s' with value '%s'";
	
	private String fieldName;
	private String fieldValue;
	
	public InvalidValueException(String fieldName, Object fieldValue) {
		super();
		
		this.fieldName = (fieldName == null ? "null" : fieldName);
		this.fieldValue = (fieldValue == null ? "null" : String.valueOf(fieldValue));
	}
	
	@Override
	public String toString() {
		return String.format(messageFormat, fieldName, fieldValue);
	}

	@Override
	public String getMessage() {
		return String.format(messageFormat, fieldName, fieldValue);
	}
}
