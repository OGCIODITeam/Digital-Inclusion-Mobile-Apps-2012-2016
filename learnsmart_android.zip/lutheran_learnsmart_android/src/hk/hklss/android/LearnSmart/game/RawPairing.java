package hk.hklss.android.LearnSmart.game;

import org.simpleframework.xml.Attribute;

public class RawPairing {
	
	@Attribute
	private String key;
	
	@Attribute
	private String value;
    
    public String getKey() {
		return key;
	}
    
    public String getValue() {
		return value;
	}
	
}