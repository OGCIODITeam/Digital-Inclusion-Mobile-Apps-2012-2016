package hk.hklss.android.LearnSmart.game;

import android.os.Parcel;
import android.os.Parcelable;

public class MemoryDataSet implements Parcelable {
	
	private String tag;
	
	private String value;
	
	public MemoryDataSet() {
	}
	
	public MemoryDataSet(String tag, String value) {
		this.tag = tag;
		this.value = value;
	}
	
	public MemoryDataSet(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(tag);
		dest.writeString(value);
	}
	
	private void readFromParcel(Parcel in) {
		tag = in.readString();
		value = in.readString();
	}

	public String getTag() {
		return tag;
	}
	
	public String getValue() {
		return value;
	}

	public static final Parcelable.Creator<MemoryDataSet> CREATOR = new Parcelable.Creator<MemoryDataSet>() {  
	    
        public MemoryDataSet createFromParcel(Parcel in) {  
            return new MemoryDataSet(in);  
        }  
   
        public MemoryDataSet[] newArray(int size) {  
            return new MemoryDataSet[size];
        }
        
    };
}