package hk.hklss.android.LearnSmart.game;

import android.os.Parcel;
import android.os.Parcelable;

public class CoinsDataSet implements Parcelable {
	
	private float value;
	
	public CoinsDataSet() {
	}
	
	public CoinsDataSet(float value) {
		this.value = value;
	}
	
	public CoinsDataSet(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeFloat(value);
	}
	
	private void readFromParcel(Parcel in) {
		value = in.readFloat();
	}

	public float getValue() {
		return value;
	}
	
	public void setValue(float value) {
		this.value = value;
	}

	public static final Parcelable.Creator<CoinsDataSet> CREATOR = new Parcelable.Creator<CoinsDataSet>() {  
	    
        public CoinsDataSet createFromParcel(Parcel in) {  
            return new CoinsDataSet(in);  
        }  
   
        public CoinsDataSet[] newArray(int size) {  
            return new CoinsDataSet[size];
        }
        
    };
}