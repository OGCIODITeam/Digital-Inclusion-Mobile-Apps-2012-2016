package hk.hklss.android.LearnSmart.game;

import org.simpleframework.xml.Attribute;

public class RawMemoryItem {
	
	@Attribute
	private String value;
    
    public String getValue() {
		return value;
	}
	
}