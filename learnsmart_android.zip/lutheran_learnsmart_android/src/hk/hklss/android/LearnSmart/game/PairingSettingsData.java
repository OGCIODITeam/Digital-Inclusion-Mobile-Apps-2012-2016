package hk.hklss.android.LearnSmart.game;

import org.simpleframework.xml.Attribute;

public class PairingSettingsData {
	
	@Attribute
	private int num;
	
	@Attribute
	private int pairGroupId;
	
	@Attribute
	private boolean valueAsKey;
	
	public int getNum() {
		return num;
	}
	
	public int getPairGroupId() {
		return pairGroupId;
	}
	
	public boolean useValueAsKey() {
		return valueAsKey;
	}
}