package hk.hklss.android.LearnSmart.game;

import android.os.Parcel;
import android.os.Parcelable;

public class PairingData implements Parcelable {
	
	private String tag;
	
	private String value;
	
	public PairingData(String tag, String value) {
		this.tag = tag;
		this.value = value;
	}
	
	public PairingData(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(tag);
		dest.writeString(value);
	}
	
	private void readFromParcel(Parcel in) {
		tag = in.readString();
		value = in.readString();
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static final Parcelable.Creator<PairingData> CREATOR = new Parcelable.Creator<PairingData>() {  
	    
        public PairingData createFromParcel(Parcel in) {  
            return new PairingData(in);  
        }  
   
        public PairingData[] newArray(int size) {  
            return new PairingData[size];
        }
        
    };
}