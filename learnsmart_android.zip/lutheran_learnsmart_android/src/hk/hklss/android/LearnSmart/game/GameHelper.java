package hk.hklss.android.LearnSmart.game;

import hk.hklss.android.LearnSmart.Constants.GameLevel;
import hk.hklss.android.LearnSmart.R;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

public class GameHelper {
	
	private static final String TAG = GameHelper.class.getSimpleName();

	public static final int resPairMap = R.raw.game_data_pairing_map;
	public static final int resPairEasy = R.raw.game_data_pairing_easy;
	public static final int resPairMedium = R.raw.game_data_pairing_medium;
	public static final int resPairDifficult = R.raw.game_data_pairing_difficult;
	public static final int resMemoryItems = R.raw.game_data_memory_items;
	
	public static ArrayList<PairingDataSet> getPairingDataSet(Context context, GameLevel level, int pairPerGame) {
		RawPairingMap rawPairMap = getRawPairingMap(context);
		RawPairingGroups rawPairGroups = rawPairMap.getPairs(level);
		
		PairingSettings rawPairDataSet = getPairingSettings(context, level);
		
		ArrayList<PairingDataSet> pairingDataList = new ArrayList<PairingDataSet>();
		
		for (PairingSettingsData rawGameData : rawPairDataSet.getGameData()) {
			PairingDataSet pairingData = new PairingDataSet();
			
			RawPairingGroup rawPairGroup = rawPairGroups.getGroup(rawGameData.getPairGroupId());
			
			List<RawPairing> rawPairs = rawPairGroup.shuffleData();
					
			for (int i = 0; i < pairPerGame; i++) {
				RawPairing rawPair = rawPairs.get(i);
				
				if (rawGameData.useValueAsKey()) {
					pairingData.add(String.valueOf(i + 1), rawPair.getValue(), rawPair.getKey());
				} else {
					pairingData.add(String.valueOf(i + 1), rawPair.getKey(), rawPair.getValue());
				}
			}
			
			pairingData.shuffleData();
			
			pairingDataList.add(pairingData);
		}
		
		return pairingDataList;
	}
	
	public static ArrayList<MemoryDataSet> getMemoryDataSet(Context context) {
		ArrayList<MemoryDataSet> memoryDataList = new ArrayList<MemoryDataSet>();
		List<RawMemoryItem> rawItems = getRawMemoryItems(context).getItems();
		
		for (int i = 0; i < rawItems.size(); i++) {
			RawMemoryItem rawItem = rawItems.get(i);
			MemoryDataSet dataSet = new MemoryDataSet(String.valueOf(i + 1), rawItem.getValue());
			memoryDataList.add(dataSet);
			memoryDataList.add(dataSet);
		}
		
		Collections.shuffle(memoryDataList, new Random());
		
		return memoryDataList;
	}
	
	public static ArrayList<CoinsDataSet> getCoinsDataSet(GameLevel level, int gameTotal) {
		ArrayList<CoinsDataSet> coinsDataList = new ArrayList<CoinsDataSet>();
		Random random = new Random();
		
		for (int i = 0; i < gameTotal; i++) {
			CoinsDataSet data = new CoinsDataSet();
			
			switch (level) {
			case Easy:
				data.setValue(random.nextInt(9) + 1);
				break;
			case Medium:
				data.setValue(random.nextInt(40) + 10);
				break;
			case Difficult:
				int rand = random.nextInt(900) + 100;
				data.setValue(rand / 10f);
				break;
			}
			
			coinsDataList.add(data);
		}
		
		return coinsDataList;
	}
	
	protected static PairingSettings getPairingSettings(Context context, GameLevel level) {
		PairingSettings set = null;
		int res = resPairEasy;
		
		switch (level) {
		case Easy:
			res = resPairEasy;
			break;
		case Medium:
			res = resPairMedium;
			break;
		case Difficult:
			res = resPairDifficult;
			break;
		}
		
		try {
			InputStream is = context.getResources().openRawResource(res);
			Serializer serializer = new Persister();
			set = serializer.read(PairingSettings.class, is);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		}
		
		return set;
	}
	
	protected static RawPairingMap getRawPairingMap(Context context) {
		RawPairingMap map = null;
		
		try {
			InputStream is = context.getResources().openRawResource(resPairMap);
			Serializer serializer = new Persister();
			map = serializer.read(RawPairingMap.class, is);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		}
		
		return map;
	}
	
	protected static RawMemoryItems getRawMemoryItems(Context context) {
		RawMemoryItems items = null;
		
		try {
			InputStream is = context.getResources().openRawResource(resMemoryItems);
			Serializer serializer = new Persister();
			items = serializer.read(RawMemoryItems.class, is);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		}
		
		return items;
	}
}
