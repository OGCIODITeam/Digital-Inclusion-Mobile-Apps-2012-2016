package hk.hklss.android.LearnSmart.game;

import java.util.List;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

@Root
public class PairingSettings {
	
	@ElementList(inline = true)
	private List<PairingSettingsData> gameData;

	@Attribute
	private int level;
	
	public List<PairingSettingsData> getGameData() {
		return gameData;
	}
	
	public int getLevel() {
		return level;
	}
}