package hk.hklss.android.LearnSmart.game;

import java.util.List;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

@Root
public class RawMemoryItems {
	
	@ElementList(inline = true)
	private List<RawMemoryItem> items;
	
	public List<RawMemoryItem> getItems() {
		return items;
	}
}