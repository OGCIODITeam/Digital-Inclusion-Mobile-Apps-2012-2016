package hk.hklss.android.LearnSmart.game;

import java.util.Collections;
import java.util.List;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;

public class RawPairingGroup {
	
	@Attribute
	private int id;

    @ElementList(inline = true)
    private List<RawPairing> pairs;
    
    public int getId() {
		return id;
	}
    
    public List<RawPairing> getPairs() {
		return pairs;
	}
	
    public List<RawPairing> shuffleData() {
    	if (pairs != null) {
    		Collections.shuffle(pairs);
    	}
    	
    	return pairs;
    }
}