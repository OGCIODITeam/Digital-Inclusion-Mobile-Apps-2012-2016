package hk.hklss.android.LearnSmart.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import android.os.Parcel;
import android.os.Parcelable;

public class PairingDataSet implements Parcelable {
	
	private List<PairingData> leftSet;
	
	private List<PairingData> rightSet;
	
	public PairingDataSet() {
		leftSet = new ArrayList<PairingData>();
		rightSet = new ArrayList<PairingData>();
	}
	
	public PairingDataSet(Parcel in) {
		leftSet = new ArrayList<PairingData>();
		rightSet = new ArrayList<PairingData>();
		
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeParcelableArray(leftSet.toArray(new PairingData[0]), flags);
		dest.writeParcelableArray(rightSet.toArray(new PairingData[0]), flags);
	}
	
	private void readFromParcel(Parcel in) {
		Parcelable[] p1 = in.readParcelableArray(PairingData.class.getClassLoader());
		
		for (Parcelable p : p1) {
			leftSet.add((PairingData) p); 
		}
		
		Parcelable[] p2 = in.readParcelableArray(PairingData.class.getClassLoader());
		
		for (Parcelable p : p2) {
			rightSet.add((PairingData) p); 
		}
	}

	public List<PairingData> getLeftSet() {
		return leftSet;
	}

	public List<PairingData> getRightSet() {
		return rightSet;
	}
	
	public void add(String tag, String leftValue, String rightValue) {
		leftSet.add(new PairingData(tag, leftValue));
		rightSet.add(new PairingData(tag, rightValue));
	}
	
    public void shuffleData() {
//    	if (leftSet != null) {
//    		Collections.shuffle(leftSet, new Random(System.currentTimeMillis()));
//    	}
    	
    	if (rightSet != null) {
    		Collections.shuffle(rightSet, new Random());
    	}
    }

	public static final Parcelable.Creator<PairingDataSet> CREATOR = new Parcelable.Creator<PairingDataSet>() {  
	    
        public PairingDataSet createFromParcel(Parcel in) {  
            return new PairingDataSet(in);  
        }  
   
        public PairingDataSet[] newArray(int size) {  
            return new PairingDataSet[size];
        }
        
    };
}