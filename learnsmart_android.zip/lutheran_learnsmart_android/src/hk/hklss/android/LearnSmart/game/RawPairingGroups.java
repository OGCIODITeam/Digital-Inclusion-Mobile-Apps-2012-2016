package hk.hklss.android.LearnSmart.game;

import java.util.List;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;

public class RawPairingGroups {
	
	@ElementList(inline = true)
	private List<RawPairingGroup> groups;
	
	@Attribute
	private int level;
	
	public List<RawPairingGroup> getGroups() {
		return groups;
	}
	
	public int getLevel() {
		return level;
	}
	
	public RawPairingGroup getGroup(int id) {
		for (RawPairingGroup group : groups) {
			if (group.getId() == id) {
				return group;
			}
		}
		
		return null;
	}
}
