package hk.hklss.android.LearnSmart.game;

import hk.hklss.android.LearnSmart.Constants.GameLevel;

import java.util.List;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

@Root
public class RawPairingMap {
	
	@ElementList(inline = true)
	private List<RawPairingGroups> maps;
	
	public List<RawPairingGroups> getMaps() {
		return maps;
	}
	
	public RawPairingGroups getPairs(GameLevel level) {
		for (RawPairingGroups group : maps) {
			if (group.getLevel() == level.ordinal()) {
				return group;
			}
		}
		
		return null;
	}
}