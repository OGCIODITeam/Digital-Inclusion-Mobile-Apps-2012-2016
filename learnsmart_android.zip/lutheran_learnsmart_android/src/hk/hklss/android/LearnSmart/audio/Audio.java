package hk.hklss.android.LearnSmart.audio;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;

import android.content.Context;
import android.content.res.*;
import android.media.*;
import android.util.Log;

public class Audio implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {
	
	private static final String TAG = Audio.class.getName();
//	protected static Audio audio = null;
	
	private Context context;
	private MediaPlayer mediaPlayer;
	private boolean repeat = false;
	
	private String lastPlayedFileName = null;
	private File lastPlayedFile = null;
	
	protected Audio(Context context) {
		this.context = context;
		init();
	}
	
	private void init() {
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setOnCompletionListener(this);
		mediaPlayer.setOnErrorListener(this);
	}
	
//	public static Audio newInstance(Context context) {
//		synchronized(Audio.class) {
//			if (audio == null) {
//				audio = new Audio(context);
//			}
//		}
//		
//		return audio;
//	}
	
	private void resetLastPlayed() {
		lastPlayedFileName = null;
		lastPlayedFile = null;
	}
	
	public void playAudioWithFileName(String audioFileName, boolean repeat) throws IOException {
		setRepeat(repeat);
		
		if (mediaPlayer == null) {
			init();
		}
		
		AssetFileDescriptor assetFileDescriptor = context.getAssets().openFd(audioFileName);
		
		if (mediaPlayer.isPlaying()) {
			mediaPlayer.stop();
		}
		mediaPlayer.reset();
		mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
		mediaPlayer.prepare();
		mediaPlayer.start();
		
		assetFileDescriptor.close();
		
		resetLastPlayed();
		this.lastPlayedFileName = audioFileName;
	}
	
	public void playAudioWithFileName(String audioFileName) throws IOException {
		playAudioWithFileName(audioFileName, false);
	}
	
	public void playAudioWithFile(File audioFile, boolean repeat) throws IOException {
		setRepeat(repeat);
		
		if (mediaPlayer == null) {
			init();
		}
		
		if (mediaPlayer.isPlaying()) {
			mediaPlayer.stop();
		}
		mediaPlayer.reset();
		mediaPlayer.setDataSource(audioFile.getAbsolutePath());
		mediaPlayer.prepare();
		mediaPlayer.start();
		
		resetLastPlayed();
		this.lastPlayedFile = audioFile;
	}
	
	public void playAudioWithFile(File audioFile) throws IOException {
		playAudioWithFile(audioFile, false);
	}
	
	public void stop() {
		if (mediaPlayer == null) {
			return;
		}
		
		if (mediaPlayer.isPlaying()) {
			mediaPlayer.stop();
		}
		
		if (!repeat) {
			mediaPlayer.release();
			mediaPlayer = null;
		}
	}
	
	public void pause() {
		if (mediaPlayer == null) {
			return;
		}
		if (mediaPlayer.isPlaying()) {
			mediaPlayer.pause();
		}
	}
	
	public void resume() {
		if (mediaPlayer == null || mediaPlayer.isPlaying()) {
			return;
		}
		
		try {
			mediaPlayer.start();
		} catch (Exception e) {
			replay();
		}
	}
	
	public void replay() {
		if (mediaPlayer == null) {
			return;
		}
		
		if (lastPlayedFileName != null && !lastPlayedFileName.equals("")) {
			try {
				playAudioWithFileName(lastPlayedFileName);
			} catch (IOException e) {
				Log.e(TAG, "unable to replay file: " + lastPlayedFileName, e);
			}
		} else if (lastPlayedFile != null) {
			try {
				playAudioWithFile(lastPlayedFile);
			} catch (IOException e) {
				Log.e(TAG, "unable to replay file: " + lastPlayedFile.getAbsolutePath(), e);
			}
		}
	}
	
	public void setRepeat(boolean repeat) {
		this.repeat = repeat;
	}
	
	/* MediaPlayer event listener */
	public void onCompletion(MediaPlayer mp) {
		Log.d(TAG, "! audio playback completed");
		
		if (repeat) {
			mp.start();
		} else {
			mp.stop();
			mp.release();
			mediaPlayer = null;
			resetLastPlayed();
		}
	}
	
	public boolean onError(MediaPlayer mp, int what, int extra) {
		Log.e(TAG, "! failed to play audio");
		mp.stop();
		return false;
	}

	public String getLastPlayedFileName() {
		return lastPlayedFileName;
	}

	public File getLastPlayedFile() {
		return lastPlayedFile;
	}
	
}
