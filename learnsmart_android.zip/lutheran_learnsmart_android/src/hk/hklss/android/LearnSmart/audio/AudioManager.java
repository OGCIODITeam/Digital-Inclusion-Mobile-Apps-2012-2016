package hk.hklss.android.LearnSmart.audio;

import java.io.File;
import java.io.IOException;

import android.content.Context;
import android.util.Log;

public class AudioManager {

	private final String TAG = "AudioManager";
	private static AudioManager instance = null;
	private Context context;

	private Audio backgroundAudio;

	private String resMainBackground = "bg_music.mp3";
	private String resScrolling = "scrolling.mp3";
	private String resPressButton = "press_button.mp3";
	private String resGameBackground = "game_background.mp3";
	private String resGameStart = "game_start.wav";
	private String resGameReadyGo = "game_ready_go.mp3";
	private String resGameEnd = "game_end.mp3";
	private String resGameLevelClear = "game_level_clear.mp3";
	private String resGameYeah = "game_yeah.mp3";
	private String resGameCoinDrop = "game_coin_drop.wav";
	private String resGameCorrectLinked = "game_correct_linked.mp3";
	private String resGameWrongLinked = "game_wrong_linked.mp3";

	/**
	 * Whether background music is enabled.
	 * You can specify the default setting here:
	 */
	private boolean bgmEnabled = false;

	public static AudioManager getInstance() {
		if (instance == null) {
			instance = new AudioManager();
		}

		return instance;
	}

	protected AudioManager() {
	}

	public void init(Context context) {
		this.context = context;
	}

	public Audio play(String audioFileName) {
		return play(audioFileName, false);
	}

	public Audio play(String audioFileName, boolean repeat) {
		Audio audio = new Audio(context);

		try {
			audio.playAudioWithFileName(audioFileName, repeat);
		} catch (IOException e) {
			Log.e(TAG, "error on playing sound: " + audioFileName, e);
		}

		return audio;
	}

	public Audio play(File audioFile) {
		return play(audioFile, false);
	}

	public Audio play(File audioFile, boolean repeat) {
		Audio audio = new Audio(context);

		try {
			audio.playAudioWithFile(audioFile, repeat);
		} catch (IOException e) {
			Log.e(TAG, "error on playing sound: " + audioFile.getPath(), e);
		}

		return audio;
	}

	/**
	 * @return whether background music is currently enabled (playing)
	 */
	public boolean isBackgroundMusicEnabled() {
		return bgmEnabled;
	}

	/**
	 * Turn on the flag on background music. But caller should still manually call
	 * playMainBackground() or playGameBackground() to play the background music.
	 */
	public void enableBackgroundMusic() {
		bgmEnabled = true;
	}

	/**
	 * Turn off the flag on background music. But caller should still manually call
	 * stopBackgroundAudio() or stop the background music.
	 */
	public void disableBackgroundMusic() {
		bgmEnabled = false;
	}

	public void playMainBackground() {
		if (bgmEnabled)
			playBackgroundAudio(resMainBackground);
	}

	public void playGameBackground() {
		if (bgmEnabled)
			playBackgroundAudio(resGameBackground);
	}

	public void playScrolling() {
		play(resScrolling);
	}

	public void playPressButton() {
		play(resPressButton);
	}

	public void playGameStart() {
		play(resGameStart);
	}

	public void playGameReadyGo() {
		play(resGameReadyGo);
	}

	public void playGameEnd() {
		play(resGameEnd);
	}

	public void playGameLevelClear() {
		play(resGameLevelClear);
	}

	public void playGameYeah() {
		play(resGameYeah);
	}

	public void playGameCoinDrop() {
		play(resGameCoinDrop);
	}

	public void playGameCorrectLinked() {
		play(resGameCorrectLinked);
	}

	public void playGameWrongLinked() {
		play(resGameWrongLinked);
	}

	protected void playBackgroundAudio(String res) {
		try {
			if (backgroundAudio == null) {
				backgroundAudio = play(res, true);
			} else if (!backgroundAudio.getLastPlayedFileName().equals(res)) {
				backgroundAudio.playAudioWithFileName(res, true);
			} else {
				backgroundAudio.resume();
			}
		} catch (IOException e) {
			Log.e(TAG, "error on playing background audio", e);
		}
	}

	public void stopBackgroundAudio() {
		if (backgroundAudio != null) {
			backgroundAudio.pause();
		}
	}
}
