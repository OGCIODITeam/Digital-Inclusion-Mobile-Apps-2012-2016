package hk.hklss.android.LearnSmart.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.webkit.HttpAuthHandler;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class AccessibleWebView extends WebView {

	private String html;
	
	public AccessibleWebView(Context context) {
		super(context);
		init(context);
	}

	public AccessibleWebView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}
	
	public AccessibleWebView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}
	
	private void init(Context context) {
		getSettings().setJavaScriptEnabled(true);
		addJavascriptInterface(new LoadListener(), "HTMLOUT");
		setWebViewClient(new WebViewClient());
		setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
//				sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED);
			}
		});
	}
	
	@Override
	public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent event) {
		if (!TextUtils.isEmpty(html)) {
	        event.getText().add(html);
	        event.setEnabled(true);
	    }
	    
	    return super.dispatchPopulateAccessibilityEvent(event);
	}

	@Override
	public void setWebViewClient(final WebViewClient client) {
		super.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageFinished(WebView view, String url) {
				view.loadUrl("javascript:window.HTMLOUT.processHtml('<html>' + document.getElementsByTagName('html')[0].innerHTML + '</html>');");
				client.onPageFinished(view, url);
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				return client.shouldOverrideUrlLoading(view, url);
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				client.onPageStarted(view, url, favicon);
			}

			@Override
			public void onLoadResource(WebView view, String url) {
				client.onLoadResource(view, url);
			}

			@Override
			public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
				return client.shouldInterceptRequest(view, url);
			}

			@Override
			public void onTooManyRedirects(WebView view, Message cancelMsg, Message continueMsg) {
				client.onTooManyRedirects(view, cancelMsg, continueMsg);
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				client.onReceivedError(view, errorCode, description, failingUrl);
			}

			@Override
			public void onFormResubmission(WebView view, Message dontResend, Message resend) {
				client.onFormResubmission(view, dontResend, resend);
			}

			@Override
			public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
				client.doUpdateVisitedHistory(view, url, isReload);
			}

			@Override
			public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
				client.onReceivedSslError(view, handler, error);
			}

			@Override
			public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
				client.onReceivedHttpAuthRequest(view, handler, host, realm);
			}

			@Override
			public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
				return client.shouldOverrideKeyEvent(view, event);
			}

			@Override
			public void onUnhandledKeyEvent(WebView view, KeyEvent event) {
				client.onUnhandledKeyEvent(view, event);
			}

			@Override
			public void onScaleChanged(WebView view, float oldScale, float newScale) {
				client.onScaleChanged(view, oldScale, newScale);
			}

			@Override
			public void onReceivedLoginRequest(WebView view, String realm, String account, String args) {
				client.onReceivedLoginRequest(view, realm, account, args);
			}
			
		});
	}
	
	public class LoadListener {
		@JavascriptInterface
	    public void processHtml(String html) {
	        Log.d("result", html);
	        AccessibleWebView.this.html = html;
	    }
	}
}
