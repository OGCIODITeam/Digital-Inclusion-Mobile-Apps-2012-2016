package hk.hklss.android.LearnSmart.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class DrawLineView extends View {

	private float startX, startY, endX, endY;
	private Paint paint = new Paint();

	public DrawLineView(Context context, AttributeSet attrs) {
		super(context, attrs);

//		paint.setAntiAlias(true);
		paint.setStrokeWidth(5f);
//		paint.setColor(Color.BLACK);
//		paint.setStyle(Paint.Style.STROKE);
//		paint.setStrokeJoin(Paint.Join.ROUND);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.drawLine(startX, startY, endX, endY, paint);
	}

	public void setLineStart(float startX, float startY, boolean setEnd) {
		this.startX = startX;
		this.startY = startY;
		
		if (setEnd) {
			this.endX = startX;
			this.endY = startY;
		}
		
		invalidate();
	}
	
	public void resetLineStart(float startX, float startY) {
		this.startX = startX;
		this.startY = startY;
		invalidate();
	}

	public void setLineEnd(float endX, float endY) {
		this.endX = endX;
		this.endY = endY;
		invalidate();
	}

	public float getStartX() {
		return startX;
	}

	public float getStartY() {
		return startY;
	}

	public float getEndX() {
		return endX;
	}

	public float getEndY() {
		return endY;
	}
}
