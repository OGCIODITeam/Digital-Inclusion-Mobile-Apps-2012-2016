package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;

public class MobileLoginResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public boolean authenticated;
		public String token;
		public Date tokenExpiryDate;
		public boolean isTrainer;
		
	}
	
}
