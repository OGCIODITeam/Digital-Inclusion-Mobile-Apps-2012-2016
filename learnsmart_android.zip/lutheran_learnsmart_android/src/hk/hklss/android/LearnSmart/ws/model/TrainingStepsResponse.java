package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class TrainingStepsResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public int trainingId;
		public List<TrainingStep> trainingSteps;
		
		public static class TrainingStep {
			
			public int id;
			public String stepType;
			public String picture;
			public String text;
			public String sound;
			public String url;
			public int step;
			public Date lastUpdated;
			
		}
		
	}
	
}
