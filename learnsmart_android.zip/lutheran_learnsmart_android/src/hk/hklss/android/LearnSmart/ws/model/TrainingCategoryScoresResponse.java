package hk.hklss.android.LearnSmart.ws.model;

import java.util.List;

public class TrainingCategoryScoresResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public List<Score> scores;
		
		public static class Score {
			
			public String title;
			public double score;
			
		}
		
	}
	
}
