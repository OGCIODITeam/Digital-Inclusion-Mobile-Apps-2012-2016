package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;

public class MobileProfileResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public String organization;
		public String fullName;
		public String email;
		public String role;
		public String profilePhoto;
		public Date lastUpdated;
		
	}
	
}
