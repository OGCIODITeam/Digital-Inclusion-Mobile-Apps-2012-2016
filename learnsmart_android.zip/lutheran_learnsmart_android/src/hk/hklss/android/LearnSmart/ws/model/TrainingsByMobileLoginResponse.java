package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class TrainingsByMobileLoginResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public List<Training> trainings;
		
		public static class Training {
			
			public int id;
			public String thumbnail;
			public String title;
			public String description;
			public int priority;
			public boolean finished;
			public Date lastUpdated;
			
		}
		
	}
	
}
