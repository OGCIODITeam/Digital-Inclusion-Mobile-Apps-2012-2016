package hk.hklss.android.LearnSmart.ws.model;

import java.io.File;
import java.lang.reflect.Field;
import java.net.MalformedURLException;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.UrlResource;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import android.net.Uri;
import android.util.Log;

public class BaseRequest {

	public MultiValueMap<String, Object> toMap() {
		MultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();
		
		for (Field field : getClass().getFields()) {
			try {
				if (field.getType().equals(File.class)) {
					File f = (File) field.get(this);
					org.springframework.core.io.FileSystemResource urlr = new org.springframework.core.io.FileSystemResource(f);
					map.add(String.format("data[%s]", field.getName()), urlr);
				} else {
					map.add(field.getName(), field.get(this));
				}
			} catch (IllegalArgumentException e) {
				Log.e("BaseRequest", e.getMessage(), e);
			} catch (IllegalAccessException e) {
				Log.e("BaseRequest", e.getMessage(), e);
			}
		}
		
		return map;
	}
	
}
