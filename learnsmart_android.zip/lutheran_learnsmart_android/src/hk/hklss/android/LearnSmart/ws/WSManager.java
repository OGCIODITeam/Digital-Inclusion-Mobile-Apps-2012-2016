package hk.hklss.android.LearnSmart.ws;

import java.util.List;

import hk.hklss.android.LearnSmart.data.DataConverter;
import hk.hklss.android.LearnSmart.ws.WSHandler;
import hk.hklss.android.LearnSmart.ws.WSUpdateHandler;
import hk.hklss.android.LearnSmart.config.ConfigLoader;
import hk.hklss.android.LearnSmart.db.DatabaseManager;
import hk.hklss.android.LearnSmart.db.model.WebService;
import hk.hklss.android.LearnSmart.ws.model.*;

import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;

public class WSManager {

	public static final String STATUS_OK = "ok"; 
	public static final String STATUS_FAILED = "failed";
	
	public static final int ERROR_CODE_NO_ERROR = 0;
	public static final int ERROR_CODE_INPUT_ERROR = 300;
	public static final int ERROR_CODE_INVALID_SUBSCRIBER = 301;
	public static final int ERROR_CODE_RECORD_NOT_FOUND = 302;
	public static final int ERROR_CODE_PERMISSION_ERROR = 400;
	public static final int ERROR_CODE_INTERNAL_SERVER_ERROR = 500;
	public static final int ERROR_CODE_DB_CONNECT_ERROR = 501;
	public static final int ERROR_CODE_EXCEPTION_CAUGHT_ERROR = -1;
	
	private static WSManager instance = null;
	
	private WSManager() {
		
	}
	
	public static WSManager getInstance() {
		if (instance == null) {
			instance = new WSManager();
		}
		
		return instance;
	}
	
	private String getUrl(Class<?> type) {
		String url = "";
		String className = type.getSimpleName();
		WebService webService = DatabaseManager.getInstance().getWebServiceByName(className);
		
		if (webService != null && webService.getUrl() != null) {
			String server = ConfigLoader.getInstance().getAppSettings().getWSBaseUrl();
			url = server + webService.getUrl();
		}
		
		return url;
	}
	
	private <T extends BaseResponse> void getData(Class<T> responseType, final WSHandler<T> handler, Object... urlParams) {
		String url = getUrl(responseType);
		
		if (url == null || url.equals("")) {
			return;
		}
		
		url = String.format(url, urlParams);
		
		GetDataTask<T> task = new GetDataTask<T>(responseType, url, new TaskHandler<T>() {
			@Override
			public void onSuccess(ResponseEntity<T> result) {
				processData(result, handler);
			}

			@Override
			public void onFailure(String message) {
				handler.onFailure(message, null);
			}
		});
		task.execute();
	}
	
	private <T extends BaseResponse> void postData(MultiValueMap<String, Object> request, Class<T> responseType, final WSHandler<T> handler, Object... urlParams) {
		String url = getUrl(responseType);
		
		if (url == null || url.equals("")) {
			throw new IllegalArgumentException();
		}
		
		url = String.format(url, urlParams);
		
		PostDataTask<T> task = new PostDataTask<T>(request, responseType, url, new TaskHandler<T>() {
			@Override
			public void onSuccess(ResponseEntity<T> result) {
				processData(result, handler);
			}

			@Override
			public void onFailure(String message) {
				handler.onFailure(message, null);
			}
		});
		task.execute();
	}
	
	private <T extends BaseResponse> void postMultiPartData(MultiValueMap<String, Object> request, Class<T> responseType, final WSHandler<T> handler, Object... urlParams) {
		String url = getUrl(responseType);
		
		if (url == null || url.equals("")) {
			throw new IllegalArgumentException();
		}
		
		url = String.format(url, urlParams);
		
		PostDataTask<T> task = new PostDataTask<T>(request, responseType, url, new TaskHandler<T>() {
			@Override
			public void onSuccess(ResponseEntity<T> result) {
				processData(result, handler);
			}

			@Override
			public void onFailure(String message) {
				handler.onFailure(message, null);
			}
		});
		task.setMultiPart(true);
		task.execute();
	}
	
	private <T extends BaseResponse> void processData(ResponseEntity<T> result, WSHandler<T> handler) {
		if (result != null && result.hasBody()) {
			T resultBody = result.getBody();
			
			if (resultBody.status.equals(WSManager.STATUS_OK)) {
				handler.onSuccess(resultBody);
			} else if (resultBody.status.equals(WSManager.STATUS_FAILED)) {
				handler.onFailure(resultBody.reason, resultBody);
			} else {
				handler.onFailure("Invalid result", resultBody);
			}
		} else {
			handler.onFailure("Empty result", null);
		}
	}
	
	public void getTrainingCategories(final WSUpdateHandler handler) {
		getData(TrainingCategoriesResponse.class, new WSHandler<TrainingCategoriesResponse>() {
				@Override
				public void onSuccess(TrainingCategoriesResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, TrainingCategoriesResponse result) {
					handler.onFailure(message);
				}
			}
		);
	}
	
	public void getTrainingsByCategory(int categoryId, final WSUpdateHandler handler) {
		getData(TrainingsByCategoryResponse.class, new WSHandler<TrainingsByCategoryResponse>() {
				@Override
				public void onSuccess(TrainingsByCategoryResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, TrainingsByCategoryResponse result) {
					handler.onFailure(message);
				}
			}, 
			categoryId
		);
	}
	
	public void getTrainingsByMobileLogin(String username, String token, final WSUpdateHandler handler) {
		getData(TrainingsByMobileLoginResponse.class, new WSHandler<TrainingsByMobileLoginResponse>() {
				@Override
				public void onSuccess(TrainingsByMobileLoginResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, TrainingsByMobileLoginResponse result) {
					handler.onFailure(message);
				}
			}, 
			username,
			token
		);
	}
	
	public void getTrainingDetails(String username, String token, int trainingId, final WSUpdateHandler handler) {
		getData(TrainingDetailsResponse.class, new WSHandler<TrainingDetailsResponse>() {
				@Override
				public void onSuccess(TrainingDetailsResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, TrainingDetailsResponse result) {
					handler.onFailure(message);
				}
			}, 
			username,
			token,
			trainingId
		);
	}
	
	public void getTrainingSteps(int trainingId, final WSUpdateHandler handler) {
		getData(TrainingStepsResponse.class, new WSHandler<TrainingStepsResponse>() {
				@Override
				public void onSuccess(TrainingStepsResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, TrainingStepsResponse result) {
					handler.onFailure(message);
				}
			},
			trainingId
		);
	}
	
	public void getMobileProfile(String username, String token, final WSUpdateHandler handler) {
		getData(MobileProfileResponse.class, new WSHandler<MobileProfileResponse>() {
				@Override
				public void onSuccess(MobileProfileResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, MobileProfileResponse result) {
					handler.onFailure(message);
				}
			},
			username,
			token
		);
	}
	
	public void getNewsAndAboutUs(final WSUpdateHandler handler) {
		getData(NewsAndAboutUsResponse.class, new WSHandler<NewsAndAboutUsResponse>() {
				@Override
				public void onSuccess(NewsAndAboutUsResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, NewsAndAboutUsResponse result) {
					handler.onFailure(message);
				}
			}
		);
	}
	
	public void getTrainingCategoryScores(String username, String token, final WSUpdateHandler handler) {
		getData(TrainingCategoryScoresResponse.class, new WSHandler<TrainingCategoryScoresResponse>() {
				@Override
				public void onSuccess(TrainingCategoryScoresResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, TrainingCategoryScoresResponse result) {
					handler.onFailure(message);
				}
			},
			username,
			token
		);
	}
	
	public void getHallOfFame(String username, String token, final WSUpdateHandler handler) {
		getData(HallOfFameResponse.class, new WSHandler<HallOfFameResponse>() {
				@Override
				public void onSuccess(HallOfFameResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, HallOfFameResponse result) {
					handler.onFailure(message);
				}
			},
			username,
			token
		);
	}
	
	public void getPastTrainingSessions(String username, String token, int trainingId, final WSUpdateHandler handler) {
		getData(PastTrainingSessionsResponse.class, new WSHandler<PastTrainingSessionsResponse>() {
				@Override
				public void onSuccess(PastTrainingSessionsResponse result) {
					handler.onSuccess(result);
				}
	
				@Override
				public void onFailure(String message, PastTrainingSessionsResponse result) {
					handler.onFailure(message);
				}
			},
			username,
			token,
			trainingId
		);
	}
	
	public void postCheckpoints(CheckpointsRequest request, final WSUpdateHandler handler) {
		postData(request.toMap(), CheckpointsResponse.class, new WSHandler<CheckpointsResponse>() {
			@Override
			public void onSuccess(CheckpointsResponse result) {
				handler.onSuccess(result);
			}

			@Override
			public void onFailure(String message, CheckpointsResponse result) {
				handler.onFailure(message);
			}
		});
	}
	
	public void postMobileLogin(MobileLoginRequest request, final WSUpdateHandler handler) {
		postData(request.toMap(), MobileLoginResponse.class, new WSHandler<MobileLoginResponse>() {
			@Override
			public void onSuccess(MobileLoginResponse result) {
				handler.onSuccess(result);
			}

			@Override
			public void onFailure(String message, MobileLoginResponse result) {
				handler.onFailure(message);
			}
		});
	}
	
	public void postMobileLoginVerify(MobileLoginVerifyRequest request, final WSUpdateHandler handler) {
		postData(request.toMap(), MobileLoginVerifyResponse.class, new WSHandler<MobileLoginVerifyResponse>() {
			@Override
			public void onSuccess(MobileLoginVerifyResponse result) {
				handler.onSuccess(result);
			}

			@Override
			public void onFailure(String message, MobileLoginVerifyResponse result) {
				handler.onFailure(message);
			}
		});
	}
	
	public void postMobileResetPassword(MobileResetPasswordRequest request, final WSUpdateHandler handler) {
		postData(request.toMap(), MobileResetPasswordResponse.class, new WSHandler<MobileResetPasswordResponse>() {
			@Override
			public void onSuccess(MobileResetPasswordResponse result) {
				handler.onSuccess(result);
			}

			@Override
			public void onFailure(String message, MobileResetPasswordResponse result) {
				handler.onFailure(message);
			}
		});
	}
	
	public void postMobileProfileUpdate(MobileProfileUpdateRequest request, final WSUpdateHandler handler) {
		postMultiPartData(request.toMap(), MobileProfileUpdateResponse.class, new WSHandler<MobileProfileUpdateResponse>() {
			@Override
			public void onSuccess(MobileProfileUpdateResponse result) {
				handler.onSuccess(result);
			}

			@Override
			public void onFailure(String message, MobileProfileUpdateResponse result) {
				handler.onFailure(message);
			}
		});
	}
	
	public void postTrainingSession(TrainingSessionRequest request, final WSUpdateHandler handler) {
		postData(request.toMap(), TrainingSessionResponse.class, new WSHandler<TrainingSessionResponse>() {
			@Override
			public void onSuccess(TrainingSessionResponse result) {
				handler.onSuccess(result);
			}

			@Override
			public void onFailure(String message, TrainingSessionResponse result) {
				handler.onFailure(message);
			}
		});
	}
}
