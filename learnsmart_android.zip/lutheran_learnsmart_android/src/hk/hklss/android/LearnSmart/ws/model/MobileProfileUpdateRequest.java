package hk.hklss.android.LearnSmart.ws.model;

import java.io.File;

import android.net.Uri;

public class MobileProfileUpdateRequest extends BaseRequest {

	public String username;
	public String token;
	public File profilePhoto;
	
}
