package hk.hklss.android.LearnSmart.ws;

import hk.hklss.android.LearnSmart.util.RestHelper;
import hk.hklss.android.LearnSmart.ws.model.BaseResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import android.os.AsyncTask;
import android.util.Log;

public class GetDataTask<T extends BaseResponse> extends AsyncTask<Void, Void, ResponseEntity<T>> {

	private static final String TAG = GetDataTask.class.getSimpleName();
	
	private Class<T> responseType;
	private String url;
	private Object[] uriVariables = new Object[0];
	private TaskHandler<T> handler = null;
	private Exception exceptionCaught = null;
	
	public GetDataTask(Class<T> responseType, String url, TaskHandler<T> handler, Object... uriVariables) {
		super();

		this.responseType = responseType;
		this.url = url;
		this.uriVariables = uriVariables;
		this.handler = handler;
	}

	@Override
	protected ResponseEntity<T> doInBackground(Void... params) {
		try {
			RestTemplate restTemplate = RestHelper.getRestTemplate();
			restTemplate.getMessageConverters().add(RestHelper.getGsonHttpMessageConverter());
			
			ResponseEntity<T> response = restTemplate.getForEntity(url, responseType, uriVariables);

			return response;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			this.exceptionCaught = e;
		}

		return null;
	}

	@Override
	protected void onPostExecute(ResponseEntity<T> result) {
		if (handler != null) {
			if (result != null) {
				switch (result.getStatusCode()) {
					case ACCEPTED:
					case OK:
						handler.onSuccess(result);
						break;
					default:
						handler.onFailure("Error result with status code " + result.getStatusCode().value() + " " + result.getStatusCode().name());
						break;
				}
			} else {
				if (exceptionCaught != null) {
					handler.onFailure(exceptionCaught.getMessage());
				} else {
					handler.onFailure("Empty result");
				}
			}
		}
	}
}