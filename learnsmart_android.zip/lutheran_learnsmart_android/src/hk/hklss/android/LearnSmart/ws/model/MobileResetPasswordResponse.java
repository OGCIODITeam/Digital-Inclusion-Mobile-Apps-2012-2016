package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;

public class MobileResetPasswordResponse extends BaseResponse {

}
