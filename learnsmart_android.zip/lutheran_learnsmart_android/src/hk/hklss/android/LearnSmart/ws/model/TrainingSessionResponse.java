package hk.hklss.android.LearnSmart.ws.model;

public class TrainingSessionResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public int sessionId;
		public double averageScore;
		
	}
	
}
