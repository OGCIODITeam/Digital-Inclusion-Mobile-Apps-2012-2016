package hk.hklss.android.LearnSmart.ws;

import hk.hklss.android.LearnSmart.ws.model.BaseResponse;

public interface WSHandler<T extends BaseResponse> {
	
	void onSuccess(T result);
	
	void onFailure(String message, T result);

}
