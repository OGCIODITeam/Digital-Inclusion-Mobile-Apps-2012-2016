package hk.hklss.android.LearnSmart.ws;

public interface WSUpdateHandler {
	
	void onSuccess(Object response);
	void onFailure(String reason);

}
