package hk.hklss.android.LearnSmart.ws;

import java.net.MalformedURLException;

import hk.hklss.android.LearnSmart.util.RestHelper;
import hk.hklss.android.LearnSmart.ws.model.BaseResponse;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import android.os.AsyncTask;
import android.util.Log;

public class PostDataTask<T extends BaseResponse> extends AsyncTask<Void, Void, ResponseEntity<T>> {

	private static final String TAG = PostDataTask.class.getSimpleName();
	
	private MultiValueMap<String, Object> request;
	private Class<T> responseType;
	private String url;
	private boolean useMultiPart = false;
	private Object[] uriVariables = new Object[0];
	private TaskHandler<T> handler = null;
	private Exception exceptionCaught = null;
	
	public PostDataTask(MultiValueMap<String, Object> request, Class<T> responseType, String url, TaskHandler<T> handler, Object... uriVariables) {
		super();

		this.request = request;
		this.responseType = responseType;
		this.url = url;
		this.uriVariables = uriVariables;
		this.handler = handler;
	}
	
	public void setMultiPart(boolean useMultiPart) {
		this.useMultiPart = useMultiPart;
	}
	
	@Override
	protected void onPreExecute() {
	}

	@Override
	protected ResponseEntity<T> doInBackground(Void... params) {
		try {
			HttpHeaders requestHeaders = new HttpHeaders();
			
			if (useMultiPart) {
				requestHeaders.add("Content-Type", "multipart/form-data");
				requestHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
			}
			
			RestTemplate restTemplate = RestHelper.getRestTemplate();
			restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
			restTemplate.getMessageConverters().add(RestHelper.getGsonHttpMessageConverter());
			
			HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<MultiValueMap<String, Object>>(request, requestHeaders);
			
			ResponseEntity<T> response = restTemplate.postForEntity(url, requestEntity, responseType, uriVariables);

			return response;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			this.exceptionCaught = e;
		}

		return null;
	}

	@Override
	protected void onPostExecute(ResponseEntity<T> result) {
		if (handler != null) {
			if (result != null) {
				handler.onSuccess(result);
			} else {
				if (exceptionCaught != null) {
					handler.onFailure(exceptionCaught.getMessage());
				} else {
					handler.onFailure("Empty result");
				}
			}
		}
	}

}
