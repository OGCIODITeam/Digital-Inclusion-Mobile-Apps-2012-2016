package hk.hklss.android.LearnSmart.ws.model;

public class MobileLoginVerifyRequest extends BaseRequest {

	public String username;
	public String token;
	
}
