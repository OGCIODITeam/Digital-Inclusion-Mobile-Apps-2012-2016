package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class TrainingCategoriesResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public List<Category> cats;
		
		public static class Category {
			
			public int id;
			public String title;
			public int priority;
			public Date lastUpdated;
			
		}
		
	}
	
}
