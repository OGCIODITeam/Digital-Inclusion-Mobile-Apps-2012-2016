package hk.hklss.android.LearnSmart.ws;

import hk.hklss.android.LearnSmart.ws.model.BaseResponse;

import org.springframework.http.ResponseEntity;

public interface TaskHandler<T extends BaseResponse> {
		
	void onSuccess(ResponseEntity<T> result);
	
	void onFailure(String message);

}
