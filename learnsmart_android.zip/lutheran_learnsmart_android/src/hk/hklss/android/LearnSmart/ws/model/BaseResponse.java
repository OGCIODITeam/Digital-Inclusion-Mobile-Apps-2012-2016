package hk.hklss.android.LearnSmart.ws.model;

public class BaseResponse {

	public String status;
	
	public int errorCode;
	
	public String reason;
	
}
