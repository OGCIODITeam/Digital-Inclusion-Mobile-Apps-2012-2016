package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class HallOfFameResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public List<HallOfFame> hallOfFames;
		
		public static class HallOfFame {
			
			public int rank;
			public boolean me;
			public double score;
			
		}
		
	}
	
}
