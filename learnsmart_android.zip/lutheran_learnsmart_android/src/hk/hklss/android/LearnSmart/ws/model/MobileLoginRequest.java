package hk.hklss.android.LearnSmart.ws.model;

public class MobileLoginRequest extends BaseRequest {

	public String username;
	public String password;
	
}
