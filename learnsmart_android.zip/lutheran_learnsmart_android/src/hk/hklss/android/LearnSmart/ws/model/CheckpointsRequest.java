package hk.hklss.android.LearnSmart.ws.model;

public class CheckpointsRequest extends BaseRequest {

	public String event;
	public String appVer;
	public String deviceFamily;
	public String deviceModel;
	public String osVer;
	public String uuid;
	
}
