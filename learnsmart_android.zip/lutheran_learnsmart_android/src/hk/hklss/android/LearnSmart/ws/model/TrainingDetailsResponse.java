package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class TrainingDetailsResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public Training training;
		
		public static class Training {
			
			public String title;
			public String category;
			public String background;
			public String traineeName;
			public String tutorName;
			public String longTermTarget;
			public String shortTermTarget;
			public Date startDate;
			public Date endDate;
			
		}
		
	}
	
}
