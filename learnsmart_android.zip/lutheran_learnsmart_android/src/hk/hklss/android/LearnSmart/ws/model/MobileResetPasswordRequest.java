package hk.hklss.android.LearnSmart.ws.model;

public class MobileResetPasswordRequest extends BaseRequest {

	public String username;
	
}
