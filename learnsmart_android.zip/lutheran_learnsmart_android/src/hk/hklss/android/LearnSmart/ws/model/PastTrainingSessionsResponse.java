package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class PastTrainingSessionsResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public List<TrainingSession> trainingSessions;
		
		public static class TrainingSession {
			
			public String comment;
			public double averageScore;
			public Date lastUpdated;
			
		}
		
	}
	
}
