package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;
import java.util.List;

public class NewsAndAboutUsResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public String aboutUs;
		public List<News> news;
		
		public static class News {
			
			public String title;
			public String description;
			public int priority;
			public Date lastUpdated;
			
		}
		
	}
	
}
