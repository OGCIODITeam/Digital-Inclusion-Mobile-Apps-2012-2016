package hk.hklss.android.LearnSmart.ws.model;

public class CheckpointsResponse extends BaseResponse {

}
