package hk.hklss.android.LearnSmart.ws.model;

public class TrainingSessionRequest extends BaseRequest {

	public String username;
	public String token;
	public String trainingId;
	public String comment;
	public String stepScores;
	
}
