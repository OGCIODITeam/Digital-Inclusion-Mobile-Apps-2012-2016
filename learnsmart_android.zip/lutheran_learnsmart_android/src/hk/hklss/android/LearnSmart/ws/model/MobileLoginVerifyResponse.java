package hk.hklss.android.LearnSmart.ws.model;

import java.util.Date;

public class MobileLoginVerifyResponse extends BaseResponse {

	public Result result;
	
	public static class Result {
		
		public boolean isValid;
		public boolean isTrainer;
		public Date tokenExpiryDate;
		
	}
	
}
