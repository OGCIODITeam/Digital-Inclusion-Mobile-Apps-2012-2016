package hk.hklss.android.LearnSmart;

import hk.hklss.android.LearnSmart.ws.model.*;

public class Constants {

	public static final String CACHE_TYPE_AUDIO = "audio";
	
	public static final String WEBSERVICE_CHECKPOINTS = CheckpointsResponse.class.getSimpleName();
	public static final String WEBSERVICE_HALL_OF_FAME = HallOfFameResponse.class.getSimpleName();
	public static final String WEBSERVICE_MOBILE_LOGIN = MobileLoginResponse.class.getSimpleName();
	public static final String WEBSERVICE_MOBILE_LOGIN_VERIFY = MobileLoginVerifyResponse.class.getSimpleName();
	public static final String WEBSERVICE_MOBILE_PROFILE = MobileProfileResponse.class.getSimpleName();
	public static final String WEBSERVICE_MOBILE_PROFILE_UPDATE = MobileProfileUpdateResponse.class.getSimpleName();
	public static final String WEBSERVICE_MOBILE_RESET_PASSWORD = MobileResetPasswordResponse.class.getSimpleName();
	public static final String WEBSERVICE_NEWS_AND_ABOUTUS = NewsAndAboutUsResponse.class.getSimpleName();
	public static final String WEBSERVICE_PAST_TRAINING_SESSIONS = PastTrainingSessionsResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_CATEGORIES = TrainingCategoriesResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_CATEGORY_SCORES = TrainingCategoryScoresResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_DETAILS = TrainingDetailsResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_BY_CATEGORY = TrainingsByCategoryResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_BY_MOBILE_LOGIN = TrainingsByMobileLoginResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_SESSION = TrainingSessionResponse.class.getSimpleName();
	public static final String WEBSERVICE_TRAINING_STEPS = TrainingStepsResponse.class.getSimpleName();
	
	public static final String DEVICE_FAMILY = "android";
	
	public static final String CHECKPOINT_EVENT_APPLAUNCH = "appLaunch";
	public static final String CHECKPOINT_EVENT_MINIGAME_MATCHING = "minigame.matching";
	public static final String CHECKPOINT_EVENT_MINIGAME_MEMORY = "minigame.memory";
	public static final String CHECKPOINT_EVENT_MINIGAME_CHANGE = "minigame.change";
	public static final String CHECKPOINT_EVENT_TRAINING = "training";
	public static final String CHECKPOINT_EVENT_LOGIN = "login";
	
	public static final String GENERAL_DATA_KEY_ABOUTUS = "aboutus";
	
	public static final int REQUEST_CODE_LOGIN = 1;
	public static final int REQUEST_CODE_RATING = 2;
	public static final int REQUEST_CODE_PICK_IMAGE = 3;
	
	public static final String[] CHECKPOINT_EVENTS = new String[] { 
		CHECKPOINT_EVENT_APPLAUNCH, 
		CHECKPOINT_EVENT_MINIGAME_MATCHING, 
		CHECKPOINT_EVENT_MINIGAME_MEMORY, 
		CHECKPOINT_EVENT_MINIGAME_CHANGE, 
		CHECKPOINT_EVENT_TRAINING, 
		CHECKPOINT_EVENT_LOGIN
	};
	
	public static final String[] WEBSERVICES = new String[] {
		WEBSERVICE_CHECKPOINTS, 
		WEBSERVICE_HALL_OF_FAME,
		WEBSERVICE_MOBILE_LOGIN,
		WEBSERVICE_MOBILE_LOGIN_VERIFY,
		WEBSERVICE_MOBILE_PROFILE,
		WEBSERVICE_MOBILE_PROFILE_UPDATE,
		WEBSERVICE_MOBILE_RESET_PASSWORD,
		WEBSERVICE_NEWS_AND_ABOUTUS,
		WEBSERVICE_PAST_TRAINING_SESSIONS,
		WEBSERVICE_TRAINING_CATEGORIES,
		WEBSERVICE_TRAINING_CATEGORY_SCORES,
		WEBSERVICE_TRAINING_DETAILS,
		WEBSERVICE_TRAINING_BY_CATEGORY,
		WEBSERVICE_TRAINING_BY_MOBILE_LOGIN,
		WEBSERVICE_TRAINING_SESSION,
		WEBSERVICE_TRAINING_STEPS
	};
	
	public static float HOF_ME_POSY_FACTOR = 0.11f;
	public static float HOF_ME_HEIGHT_FACTOR = 0.4f;
	public static float HOF_BUDDY_POSY_FACTOR = 0.085f;
	public static float HOF_BUDDY_HEIGHT_FACTOR = 0.3f;
	public static float HOF_PROFILE_CHART_MARGIN_BOTTOM_FACTOR = -0.4f;
	
	public static enum TrainingListType {
		Category, TrainingByCategory, TrainingByUser
	}
	
	public static enum GameLevel {
		Easy, Medium, Difficult
	}
}

