package hk.hklss.android.LearnSmart;

import hk.hklss.android.LearnSmart.audio.AudioManager;
import hk.hklss.android.LearnSmart.cache.CacheLoader;
import hk.hklss.android.LearnSmart.cache.CacheLoaderConfiguration;
import hk.hklss.android.LearnSmart.cache.CacheLoadingOptions;
import hk.hklss.android.LearnSmart.data.DataManager;
import hk.hklss.android.LearnSmart.db.DatabaseManager;
import hk.hklss.android.LearnSmart.util.DateUtils;
import hk.hklss.android.LearnSmart.util.DialogHelper;
import hk.hklss.android.LearnSmart.util.GsonLoader;
import hk.hklss.android.LearnSmart.util.StorageUtils;
import hk.hklss.android.LearnSmart.config.AppSettings;
import hk.hklss.android.LearnSmart.config.ConfigLoader;
import hk.hklss.android.LearnSmart.config.InvalidValueException;

import java.io.File;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.util.Date;

import android.app.Application;
import android.graphics.Bitmap;
import android.util.Log;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

public class MainApplication extends Application {

	private static final String TAG = MainApplication.class.getSimpleName();
	private static final String INITIAL_CONFIG_FOLDER = "init_config";
	public static final boolean DEBUG = true;
	
	private boolean hasError = false;
	private Exception errorException = null;
	private String errorMessage = null;
	
	private AppSettings appSettings;
	
	@Override
	public void onCreate() {
		boolean isValid = true;
		
		super.onCreate();
		
		isValid = isValid && initConfigLoader();
		isValid = isValid && initCacheLoader();
		isValid = isValid && initImageLoader();
		isValid = isValid && initGsonLoader();
		isValid = isValid && initDataManager();
		isValid = isValid && initDialogHelper();
		isValid = isValid && initAudioManager();
	}
	
	private boolean initConfigLoader() {
		boolean isValid = false;
		
		try {
			ConfigLoader configLoader = ConfigLoader.getInstance();
			configLoader.init(this, INITIAL_CONFIG_FOLDER);
			configLoader.checkSettings();
			
			appSettings = configLoader.getAppSettings();
			
			isValid = true;
		} catch (InvalidValueException e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private boolean initCacheLoader() {
		boolean isValid = false;
		
		try {
			CacheLoadingOptions options = new CacheLoadingOptions.Builder()
				.showDialogOnLoading()
	//			.postProcessor(null)
		        .cacheOnDisc()
		        .build();
			
			CacheLoader cacheLoader = CacheLoader.getInstance();
			
			File audioCacheDir = StorageUtils.getCacheDirectory(getApplicationContext(), appSettings.getAudioCacheFolder());
			CacheLoaderConfiguration audioConfig = new CacheLoaderConfiguration.Builder(getApplicationContext())
				.defaultCacheLoadingOptions(options)
				.discCache(new hk.hklss.android.LearnSmart.cache.disc.impl.UnlimitedDiscCache(audioCacheDir))
				.showProgressDialogOnLoading(false)
				.build();
			cacheLoader.init(Constants.CACHE_TYPE_AUDIO, audioConfig);
			
			isValid = true;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private boolean initImageLoader() {
		boolean isValid = false;
		
		try {
			File cacheDir = StorageUtils.getCacheDirectory(getApplicationContext(), appSettings.getImageCacheFolder());
		
			DisplayImageOptions options = new DisplayImageOptions.Builder()
//		        .showStubImage(R.anim.loading_image)
//		        .showImageForEmptyUri(R.drawable.ic_empty)
//		        .showImageOnFail(R.drawable.ic_empty)
		        .resetViewBeforeLoading()
		        .cacheInMemory()
		        .cacheOnDisc()
		        .bitmapConfig(Bitmap.Config.RGB_565)
		        .build();
			
			ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
				.defaultDisplayImageOptions(options)
				.discCache(new UnlimitedDiscCache(cacheDir))
				.build();
			
			ImageLoader.getInstance().init(config);
			
			isValid = true;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private boolean initGsonLoader() {
		boolean isValid = false;
		
		try {
			final String dateFormat = ConfigLoader.getInstance().getAppSettings().getJsonDateFormat();
			
			GsonBuilder gsonBuilder = new GsonBuilder();
			gsonBuilder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
		        @Override
		        public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
		                throws JsonParseException {
		            try {
		            	return DateUtils.parseDate(dateFormat, json.getAsString());
		            } catch (ParseException e1) {
		            	try {
		            		return DateUtils.parseDate("yyyy-MM-dd", json.getAsString());
		            	} catch (Exception e2) {
		            		return null;
		            	}
		            }
		        }
		    });
			
			gsonBuilder.registerTypeAdapter(Date.class, new JsonSerializer<Date>() {
		        @Override
				public JsonElement serialize(Date data, Type typeOfT, JsonSerializationContext context) {
					return new JsonPrimitive(DateUtils.formatDate(dateFormat, data));
				}
		    });
			
			GsonLoader.getInstance().init(gsonBuilder);
			
			isValid = true;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private boolean initDataManager() {
		boolean isValid = false;
		
		try {
			if (DEBUG) {
				// for debug use, delete and create database on every launch
	//			getApplicationContext().deleteDatabase(DatabaseHelper.DATABASE_NAME);
			}
	
			DatabaseManager.getInstance().init(getApplicationContext());
	
			DataManager.getInstance().init(getApplicationContext());
			
			isValid = true;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private boolean initDialogHelper() {
		boolean isValid = false;
		
		try {
			DialogHelper.getInstance().init(getApplicationContext());
			
			isValid = true;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private boolean initAudioManager() {
		boolean isValid = false;
		
		try {
			AudioManager.getInstance().init(getApplicationContext());
			
			isValid = true;
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
			setError(e.getMessage(), e);
		}
		
		return isValid;
	}
	
	private void setError(String message, Exception ex) {
		this.hasError = true;
		this.errorMessage = message;
		this.errorException = ex;
	}

	public boolean isHasError() {
		return hasError;
	}

	public Exception getErrorException() {
		return errorException;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
}