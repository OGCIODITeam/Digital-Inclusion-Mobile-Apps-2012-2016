package hk.hklss.android.LearnSmart.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.db.model.*;
import hk.hklss.android.LearnSmart.ws.model.*;

public class DataConverter {

	public static List<HallOfFame> toHallOfFameList(HallOfFameResponse data) {
		List<HallOfFame> results = new ArrayList<HallOfFame>();
		
		for (HallOfFameResponse.Result.HallOfFame row : data.result.hallOfFames) {
			HallOfFame result = new HallOfFame();
			
			result.setRank(row.rank);
			result.setMe(row.me);
			result.setScore(row.score);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static MobileLogin toMobileLogin(MobileLoginResponse data, String username) {
		MobileLogin result = new MobileLogin();
		
		result.setUsername(username);
		result.setToken(data.result.token);
		result.setTokenExpiryDate(data.result.tokenExpiryDate);
		result.setTrainer(data.result.isTrainer);
		
		return result;
	}
	
	public static MobileLogin toMobileLogin(MobileLoginVerifyResponse data, String username, String token) {
		MobileLogin result = new MobileLogin();
		
		result.setUsername(username);
		result.setToken(token);
		result.setTokenExpiryDate(data.result.tokenExpiryDate);
		result.setTrainer(data.result.isTrainer);
		
		return result;
	}
	
	public static UserProfile toUserProfile(MobileProfileResponse data, String username) {
		UserProfile result = new UserProfile();
		
		result.setUsername(username);
		result.setFullName(data.result.fullName);
		result.setOrganization(data.result.organization);
		result.setRole(data.result.role);
		result.setProfilePhoto(data.result.profilePhoto);
		result.setEmail(data.result.email);
		result.setLastUpdated(data.result.lastUpdated);
		
		return result;
	}
	
	public static List<News> toNewsList(NewsAndAboutUsResponse data) {
		List<News> results = new ArrayList<News>();
		
		for (NewsAndAboutUsResponse.Result.News row : data.result.news) {
			News result = new News();
			
			result.setTitle(row.title);
			result.setDescription(row.description);
			result.setPriority(row.priority);
			result.setLastUpdated(row.lastUpdated);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static GeneralData toGeneralData(NewsAndAboutUsResponse data) {
		GeneralData result = new GeneralData();

		result.setKey(Constants.GENERAL_DATA_KEY_ABOUTUS);
		result.setValue(data.result.aboutUs);
		
		return result;
	}
	
	public static List<PastTrainingSessions> toPastTrainingSessionsList(PastTrainingSessionsResponse data, int trainingId) {
		List<PastTrainingSessions> results = new ArrayList<PastTrainingSessions>();
		
		for (PastTrainingSessionsResponse.Result.TrainingSession row : data.result.trainingSessions) {
			PastTrainingSessions result = new PastTrainingSessions();
			
			result.setTrainingId(trainingId);
			result.setAverageScore(row.averageScore);
			result.setComment(row.comment);
			result.setLastUpdated(row.lastUpdated);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static List<TrainingCategories> toTrainingCategoriesList(TrainingCategoriesResponse data) {
		List<TrainingCategories> results = new ArrayList<TrainingCategories>();
		
		for (TrainingCategoriesResponse.Result.Category row : data.result.cats) {
			TrainingCategories result = new TrainingCategories();
			
			result.setId(row.id);
			result.setTitle(row.title);
			result.setPriority(row.priority);
			result.setLastUpdated(row.lastUpdated);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static List<TrainingCategoryScores> toTrainingCategoryScoresList(TrainingCategoryScoresResponse data, String username) {
		List<TrainingCategoryScores> results = new ArrayList<TrainingCategoryScores>();
		
		for (TrainingCategoryScoresResponse.Result.Score row : data.result.scores) {
			TrainingCategoryScores result = new TrainingCategoryScores();
			
			result.setUsername(username);
			result.setTitle(row.title);
			result.setScore(row.score);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static TrainingDetails toTrainingDetails(TrainingDetailsResponse data, int trainingId) {
		TrainingDetails result = new TrainingDetails();
		
		result.setTrainingId(trainingId);
		result.setTitle(data.result.training.title);
		result.setBackground(data.result.training.background);
		result.setCategory(data.result.training.category);
		result.setTraineeName(data.result.training.traineeName);
		result.setTutorName(data.result.training.tutorName);
		result.setStartDate(data.result.training.startDate);
		result.setEndDate(data.result.training.endDate);
		result.setLongTermTarget(data.result.training.longTermTarget);
		result.setShortTermTarget(data.result.training.shortTermTarget);
		
		return result;
	}
	
	public static List<Trainings> toTrainingsList(TrainingsByCategoryResponse data, int trainingCategoryId) {
		List<Trainings> results = new ArrayList<Trainings>();
		
		for (TrainingsByCategoryResponse.Result.Training row : data.result.trainings) {
			Trainings result = new Trainings();
			
			result.setId(row.id);
			result.setUsername("");
			result.setTrainingCategoryId(trainingCategoryId);
			result.setTitle(row.title);
			result.setDescription(row.description);
			result.setThumbnail(row.thumbnail);
			result.setPriority(row.priority);
			result.setFinished(false);
			result.setLastUpdated(row.lastUpdated);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static List<Trainings> toTrainingsList(TrainingsByMobileLoginResponse data, String username) {
		List<Trainings> results = new ArrayList<Trainings>();
		
		for (TrainingsByMobileLoginResponse.Result.Training row : data.result.trainings) {
			Trainings result = new Trainings();
			
			result.setId(row.id);
			result.setUsername(username);
			result.setTrainingCategoryId(0);
			result.setTitle(row.title);
			result.setDescription(row.description);
			result.setThumbnail(row.thumbnail);
			result.setPriority(row.priority);
			result.setFinished(row.finished);
			result.setLastUpdated(row.lastUpdated);
			
			results.add(result);
		}
		
		return results;
	}
	
	public static List<TrainingSteps> toTrainingStepsList(TrainingStepsResponse data) {
		List<TrainingSteps> results = new ArrayList<TrainingSteps>();
		
		for (TrainingStepsResponse.Result.TrainingStep row : data.result.trainingSteps) {
			TrainingSteps result = new TrainingSteps();
			
			result.setId(row.id);
			result.setTrainingId(data.result.trainingId);
			result.setStepType(row.stepType);
			result.setStep(row.step);
			result.setText(row.text);
			result.setPicture(row.picture);
			result.setSound(row.sound);
			result.setUrl(row.url);
			
			results.add(result);
		}
		
		return results;
	}
	
	
}
