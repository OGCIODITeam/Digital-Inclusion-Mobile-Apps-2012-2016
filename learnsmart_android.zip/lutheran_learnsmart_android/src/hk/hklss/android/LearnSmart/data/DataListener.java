package hk.hklss.android.LearnSmart.data;

public interface DataListener<T> {
	
	void onSuccess(T object);
	void onFailure(String message);
	void onUpdate(boolean isUpdating);
}
