package hk.hklss.android.LearnSmart.data;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.db.DatabaseManager;
import hk.hklss.android.LearnSmart.db.model.*;
import hk.hklss.android.LearnSmart.util.MiscUtils;
import hk.hklss.android.LearnSmart.ws.WSManager;
import hk.hklss.android.LearnSmart.ws.WSUpdateHandler;
import hk.hklss.android.LearnSmart.ws.model.CheckpointsRequest;
import hk.hklss.android.LearnSmart.ws.model.HallOfFameResponse;
import hk.hklss.android.LearnSmart.ws.model.MobileLoginRequest;
import hk.hklss.android.LearnSmart.ws.model.MobileLoginResponse;
import hk.hklss.android.LearnSmart.ws.model.MobileLoginVerifyRequest;
import hk.hklss.android.LearnSmart.ws.model.MobileLoginVerifyResponse;
import hk.hklss.android.LearnSmart.ws.model.MobileProfileResponse;
import hk.hklss.android.LearnSmart.ws.model.MobileProfileUpdateRequest;
import hk.hklss.android.LearnSmart.ws.model.MobileProfileUpdateResponse;
import hk.hklss.android.LearnSmart.ws.model.MobileResetPasswordRequest;
import hk.hklss.android.LearnSmart.ws.model.MobileResetPasswordResponse;
import hk.hklss.android.LearnSmart.ws.model.NewsAndAboutUsResponse;
import hk.hklss.android.LearnSmart.ws.model.PastTrainingSessionsResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingCategoriesResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingCategoryScoresResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingDetailsResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingSessionRequest;
import hk.hklss.android.LearnSmart.ws.model.TrainingSessionResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingStepsResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingsByCategoryResponse;
import hk.hklss.android.LearnSmart.ws.model.TrainingsByMobileLoginResponse;

import java.io.File;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;

public class DataManager {

	private static final String TAG = DataManager.class.getSimpleName();
	
	private static DataManager instance;

	protected DatabaseManager dbManager;
	protected Context context;
	
	private DataManager() {
	}
	
	public static DataManager getInstance() {
		if (instance == null) {
			synchronized (DataManager.class) {
				if (instance == null) {
					instance = new DataManager();
				}
			}
		}
		
		return instance;
	}
	
	public void init(Context context) {
		this.context = context;
		this.dbManager = DatabaseManager.getInstance();
	}
	
	protected boolean isNetworkAvailable() {
		ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = cm.getActiveNetworkInfo();
		
		return (networkInfo != null && networkInfo.isConnected());
	}
	
	public void postCheckpoint(String event, final DataListener<Boolean> handler) {
		CheckpointsRequest request = new CheckpointsRequest();
		request.event = event;
		request.appVer = MiscUtils.getAppVersion(context);
		request.deviceFamily = Constants.DEVICE_FAMILY;
		request.deviceModel = android.os.Build.MODEL;
		request.osVer = android.os.Build.VERSION.RELEASE;
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().postCheckpoints(request, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					handler.onSuccess(true);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
		} else {
			handler.onFailure("network error");
		}
	}
	
	public void postMobileLogin(final String username, String password, final DataListener<MobileLogin> handler) {
		MobileLoginRequest request = new MobileLoginRequest();
		request.username = username;
		request.password = password;
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().postMobileLogin(request, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					MobileLoginResponse response = (MobileLoginResponse)responseObject;
					MobileLogin newData = DataConverter.toMobileLogin(response, username);
					
					if (response.result.authenticated) {
						dbManager.deleteMobileLogin();
						dbManager.addMobileLogin(newData);
					}
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
		} else {
			handler.onFailure("network error");
		}
	}
	
	public void postMobileLoginVerify(final String username, final String token, final DataListener<MobileLogin> handler) {
		MobileLoginVerifyRequest request = new MobileLoginVerifyRequest();
		request.username = username;
		request.token = token;
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().postMobileLoginVerify(request, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					MobileLoginVerifyResponse response = (MobileLoginVerifyResponse)responseObject;
					MobileLogin newData = DataConverter.toMobileLogin(response, username, token);
					dbManager.deleteMobileLogin();
					
					if (response.result.isValid) {
						dbManager.addMobileLogin(newData);
						handler.onSuccess(newData);
					} else {
						handler.onFailure(response.reason);
					}
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
		} else {
			handler.onFailure("network error");
		}
	}
	
	public void postTrainingSessions(final String username, final String token, final int trainingId, final String comment, final String stepScores, final DataListener<Boolean> handler) {
		TrainingSessionRequest request = new TrainingSessionRequest();
		request.username = username;
		request.token = token;
		request.trainingId = String.valueOf(trainingId);
		request.comment = comment;
		request.stepScores = stepScores;
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().postTrainingSession(request, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					handler.onSuccess(true);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
		} else {
			handler.onFailure("network error");
		}
	}
	
	public void postUserProfileUpdate(final String username, final String token, final File profilePhoto, final DataListener<Boolean> handler) {
		MobileProfileUpdateRequest request = new MobileProfileUpdateRequest();
		request.username = username;
		request.token = token;
		request.profilePhoto = profilePhoto;
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().postMobileProfileUpdate(request, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					handler.onSuccess(true);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
		} else {
			handler.onFailure("network error");
		}
	}
	
	public void postMobileResetPassword(final String username, final DataListener<Boolean> handler) {
		MobileResetPasswordRequest request = new MobileResetPasswordRequest();
		request.username = username;
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().postMobileResetPassword(request, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					handler.onSuccess(true);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
		} else {
			handler.onFailure("network error");
		}
	}
	
	public String getAboutUs(final DataListener<String> handler) {
		GeneralData generalData = dbManager.getGeneralData(Constants.GENERAL_DATA_KEY_ABOUTUS); 
		String data = (generalData == null ? "" : generalData.getValue());
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getNewsAndAboutUs(new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					NewsAndAboutUsResponse response = (NewsAndAboutUsResponse)responseObject;
					
					GeneralData newData = DataConverter.toGeneralData(response);
					dbManager.deleteGeneralData(Constants.GENERAL_DATA_KEY_ABOUTUS);
					dbManager.addGeneralData(newData);
					
					List<News> newsList = DataConverter.toNewsList(response);
					dbManager.deleteNews();
					dbManager.addNews(newsList);
					
					handler.onSuccess(newData == null ? "" : newData.getValue());
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public MobileLogin getMobileLogin() {
		return dbManager.getMobileLogin();
	}
	
	public List<HallOfFame> getHallOfFames(String username, String token, final DataListener<List<HallOfFame>> handler) {
		List<HallOfFame> data = dbManager.getHallOfFames();
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getHallOfFame(username, token, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					HallOfFameResponse response = (HallOfFameResponse)responseObject;
					
					List<HallOfFame> newData = DataConverter.toHallOfFameList(response);
					dbManager.deleteHallOfFames();
					dbManager.addHallOfFames(newData);

					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public List<News> getNews(final DataListener<List<News>> handler) {
		 List<News> data = dbManager.getNews();
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getNewsAndAboutUs(new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					NewsAndAboutUsResponse response = (NewsAndAboutUsResponse)responseObject;
					
					List<News> newData = DataConverter.toNewsList(response);
					dbManager.deleteNews();
					dbManager.addNews(newData);
					
					GeneralData aboutus = DataConverter.toGeneralData(response);
					dbManager.deleteGeneralData(Constants.GENERAL_DATA_KEY_ABOUTUS);
					dbManager.addGeneralData(aboutus);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public List<PastTrainingSessions> getPastTrainingSessions(final String username, final String token, final int trainingId, final DataListener<List<PastTrainingSessions>> handler) {
		 List<PastTrainingSessions> data = dbManager.getPastTrainingSessionsByTrainingId(trainingId);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getPastTrainingSessions(username, token, trainingId, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object responseObject) {
					PastTrainingSessionsResponse response = (PastTrainingSessionsResponse)responseObject;
					
					List<PastTrainingSessions> newData = DataConverter.toPastTrainingSessionsList(response, trainingId);
					dbManager.deletePastTrainingSessionsByTrainingId(trainingId);
					dbManager.addPastTrainingSessions(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public Trainings getTraining(int trainingId) {
		return dbManager.getTraining(trainingId);
	}
	
	public TrainingCategories getTrainingCategory(int trainingCategoryId) {
		return dbManager.getTrainingCategory(trainingCategoryId);
	}
	
	public List<TrainingCategories> getTrainingCategories(final DataListener<List<TrainingCategories>> handler) {
		List<TrainingCategories> data = dbManager.getTrainingCategories();
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getTrainingCategories(new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					List<TrainingCategories> newData = DataConverter.toTrainingCategoriesList((TrainingCategoriesResponse)response);
					dbManager.deleteTrainingCategories();
					dbManager.addTrainingCategories(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public List<TrainingCategoryScores> getTrainingCategoryScores(final String username, final String token, final DataListener<List<TrainingCategoryScores>> handler) {
		List<TrainingCategoryScores> data = dbManager.getTrainingCategoryScores(username);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getTrainingCategoryScores(username, token, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					List<TrainingCategoryScores> newData = DataConverter.toTrainingCategoryScoresList((TrainingCategoryScoresResponse)response, username);
					dbManager.deleteTrainingCategoryScores(username);
					dbManager.addTrainingCategoryScores(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public TrainingDetails getTrainingDetails(String username, String token, final int trainingId, final DataListener<TrainingDetails> handler) {
		TrainingDetails data = dbManager.getTrainingDetails(trainingId);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getTrainingDetails(username, token, trainingId, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					TrainingDetails newData = DataConverter.toTrainingDetails((TrainingDetailsResponse)response, trainingId);
					dbManager.deleteTrainingDetails(trainingId);
					dbManager.addTrainingDetails(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public List<Trainings> getTrainingsByCategory(final int categoryId, final DataListener<List<Trainings>> handler) {
		List<Trainings> data = dbManager.getTrainingsByCategory(categoryId);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getTrainingsByCategory(categoryId, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					List<Trainings> newData = DataConverter.toTrainingsList((TrainingsByCategoryResponse)response, categoryId);
					dbManager.deleteTrainingsByCategory(categoryId);
					dbManager.addTrainings(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public List<Trainings> getTrainingsByMobileLogin(final String username, final String token, final DataListener<List<Trainings>> handler) {
		List<Trainings> data = dbManager.getTrainingsByUsername(username);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getTrainingsByMobileLogin(username, token, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					List<Trainings> newData = DataConverter.toTrainingsList((TrainingsByMobileLoginResponse)response, username);
					dbManager.deleteTrainingsByMobileLogin(username);
					dbManager.addTrainings(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public List<TrainingSteps> getTrainingSteps(final int trainingId, final DataListener<List<TrainingSteps>> handler) {
		List<TrainingSteps> data = dbManager.getTrainingStepsByTrainingId(trainingId);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getTrainingSteps(trainingId, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					List<TrainingSteps> newData = DataConverter.toTrainingStepsList((TrainingStepsResponse)response);
					dbManager.deleteTrainingStepsByTrainingId(trainingId);
					dbManager.addTrainingSteps(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public UserProfile getUserProfile(final String username, String token, final DataListener<UserProfile> handler) {
		UserProfile data = dbManager.getUserProfile(username);
		
		if (isNetworkAvailable()) {
			WSManager.getInstance().getMobileProfile(username, token, new WSUpdateHandler() {
				@Override
				public void onSuccess(Object response) {
					UserProfile newData = DataConverter.toUserProfile((MobileProfileResponse)response, username);
					dbManager.deleteUserProfile();
					dbManager.addUserProfile(newData);
					
					handler.onSuccess(newData);
				}

				@Override
				public void onFailure(String reason) {
					handler.onFailure(reason);
				}
			});
			handler.onUpdate(true);
		} else {
			handler.onFailure("network error");
		}
		
		return data;
	}
	
	public void logout() {
		dbManager.deleteMobileLogin();
	}
}
