package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class TrainingDetails implements Parcelable {

	@DatabaseField(id = true)
	private int trainingId;
	
	@DatabaseField
	private String title;
	
	@DatabaseField
	private String category;

	@DatabaseField
	private String background;

	@DatabaseField
	private String traineeName;

	@DatabaseField
	private String tutorName;

	@DatabaseField
	private String longTermTarget;

	@DatabaseField
	private String shortTermTarget;

	@DatabaseField
	private Date startDate;

	@DatabaseField
	private Date endDate;
	
	public TrainingDetails() {
	}
	
	public TrainingDetails(int trainingId, String title, String category, String background, String traineeName, String tutorName, String longTermTarget, String shortTermTarget, Date startDate, Date endDate) {
		this.trainingId = trainingId;
		this.title = title;
		this.category = category;
		this.background = background;
		this.traineeName = traineeName;
		this.tutorName = tutorName;
		this.longTermTarget = longTermTarget;
		this.shortTermTarget = shortTermTarget;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	
	public TrainingDetails(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(trainingId);
		dest.writeString(title);
		dest.writeString(category);
		dest.writeString(background);
		dest.writeString(traineeName);
		dest.writeString(tutorName);
		dest.writeString(longTermTarget);
		dest.writeString(shortTermTarget);
		dest.writeSerializable(startDate);
		dest.writeSerializable(endDate);
	}
	
	private void readFromParcel(Parcel in) {
		trainingId = in.readInt();
		title = in.readString();
		category = in.readString();
		background = in.readString();
		traineeName = in.readString();
		tutorName = in.readString();
		longTermTarget = in.readString();
		shortTermTarget = in.readString();
		startDate = (Date) in.readSerializable();
		endDate = (Date) in.readSerializable();
	}

	public int getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTutorName() {
		return tutorName;
	}

	public void setTutorName(String tutorName) {
		this.tutorName = tutorName;
	}

	public String getLongTermTarget() {
		return longTermTarget;
	}

	public void setLongTermTarget(String longTermTarget) {
		this.longTermTarget = longTermTarget;
	}

	public String getShortTermTarget() {
		return shortTermTarget;
	}

	public void setShortTermTarget(String shortTermTarget) {
		this.shortTermTarget = shortTermTarget;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public static final Parcelable.Creator<TrainingDetails> CREATOR = new Parcelable.Creator<TrainingDetails>() {  
	    
        public TrainingDetails createFromParcel(Parcel in) {  
            return new TrainingDetails(in);  
        }  
   
        public TrainingDetails[] newArray(int size) {  
            return new TrainingDetails[size];
        }
        
    };
}
