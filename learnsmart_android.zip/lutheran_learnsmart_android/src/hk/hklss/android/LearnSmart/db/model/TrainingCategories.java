package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class TrainingCategories implements Parcelable {

	@DatabaseField(id = true)
	private int id;
	
	@DatabaseField
	private String title;
	
	@DatabaseField
	private int priority;
	
	@DatabaseField
	private Date lastUpdated;
	
	public TrainingCategories() {
	}
	
	public TrainingCategories(int id, String title, int priority, Date lastUpdated) {
		this.id = id;
		this.title = title;
		this.priority = priority;
		this.lastUpdated = lastUpdated;
	}
	
	public TrainingCategories(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(title);
		dest.writeInt(priority);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		title = in.readString();
		priority = in.readInt();
		lastUpdated = (Date) in.readSerializable();
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public static final Parcelable.Creator<TrainingCategories> CREATOR = new Parcelable.Creator<TrainingCategories>() {  
	    
        public TrainingCategories createFromParcel(Parcel in) {  
            return new TrainingCategories(in);  
        }  
   
        public TrainingCategories[] newArray(int size) {  
            return new TrainingCategories[size];
        }
        
    };
}
