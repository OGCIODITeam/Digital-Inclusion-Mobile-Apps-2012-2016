package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class TrainingSteps implements Parcelable {
	
	@DatabaseField(id = true)
	private int id;
	
	@DatabaseField
	private int trainingId;
	
	@DatabaseField
	private String stepType;
	
	@DatabaseField
	private String picture;
	
	@DatabaseField
	private String text;
	
	@DatabaseField
	private String sound;
	
	@DatabaseField
	private String url;
	
	@DatabaseField
	private int step;
	
	@DatabaseField
	private Date lastUpdated;
	
	public TrainingSteps() {
	}
	
	public TrainingSteps(int id, int trainingId, String stepType, String picture, String text, String sound, String url, int step, Date lastUpdated) {
		this.id = id;
		this.trainingId = trainingId;
		this.stepType = stepType;
		this.picture = picture;
		this.text = text;
		this.sound = sound;
		this.url = url;
		this.step = step;
		this.lastUpdated = lastUpdated;
	}
	
	public TrainingSteps(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeInt(trainingId);
		dest.writeString(stepType);
		dest.writeString(picture);
		dest.writeString(text);
		dest.writeString(sound);
		dest.writeString(url);
		dest.writeInt(step);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		trainingId = in.readInt();
		stepType = in.readString();
		picture = in.readString();
		text = in.readString();
		sound = in.readString();
		url = in.readString();
		step = in.readInt();
		lastUpdated = (Date) in.readSerializable();
	}

	public static final Parcelable.Creator<TrainingSteps> CREATOR = new Parcelable.Creator<TrainingSteps>() {  
	    
        public TrainingSteps createFromParcel(Parcel in) {  
            return new TrainingSteps(in);  
        }  
   
        public TrainingSteps[] newArray(int size) {  
            return new TrainingSteps[size];
        }
        
    };
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	public String getStepType() {
		return stepType;
	}

	public void setStepType(String stepType) {
		this.stepType = stepType;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getSound() {
		return sound;
	}

	public void setSound(String sound) {
		this.sound = sound;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getStep() {
		return step;
	}

	public void setStep(int step) {
		this.step = step;
	}
}
