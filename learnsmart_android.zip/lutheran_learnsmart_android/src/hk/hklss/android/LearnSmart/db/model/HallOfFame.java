package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class HallOfFame implements Parcelable {
	
	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField
	private int rank;
	
	@DatabaseField
	private boolean me;
	
	@DatabaseField
	private double score;
	
	public HallOfFame() {
	}
	
	public HallOfFame(int rank, boolean me, double score) {
		this.rank = rank;
		this.me = me;
		this.score = score;
	}
	
	public HallOfFame(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeInt(rank);
		dest.writeByte((byte) (me ? 1 : 0));
		dest.writeDouble(score);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		rank = in.readInt();
		me = (in.readByte() == 1);
		score = in.readDouble();
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public boolean isMe() {
		return me;
	}

	public void setMe(boolean me) {
		this.me = me;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public static final Parcelable.Creator<HallOfFame> CREATOR = new Parcelable.Creator<HallOfFame>() {  
	    
        public HallOfFame createFromParcel(Parcel in) {  
            return new HallOfFame(in);  
        }  
   
        public HallOfFame[] newArray(int size) {  
            return new HallOfFame[size];
        }
        
    };
}
