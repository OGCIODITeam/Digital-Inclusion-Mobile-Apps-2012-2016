package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class WebService implements Parcelable {

	@DatabaseField
	private String name;
	
	@DatabaseField
	private String url;
	
	@DatabaseField
	private Date lastUpdated;
	
	public WebService() {
	}
	
	public WebService(String name, String url) {
		this.name = name;
		this.url = url;
		this.lastUpdated = new Date();
	}
	
	public WebService(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(name);
		dest.writeString(url);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		name = in.readString();
		url = in.readString();
		lastUpdated = (Date) in.readSerializable();
	}
	
	public static final Parcelable.Creator<WebService> CREATOR = new Parcelable.Creator<WebService>() {  
	    
        public WebService createFromParcel(Parcel in) {  
            return new WebService(in);  
        }  
   
        public WebService[] newArray(int size) {  
            return new WebService[size];
        }
        
    };  

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
}
