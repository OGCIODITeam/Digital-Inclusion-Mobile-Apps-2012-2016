package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class PastTrainingSessions implements Parcelable {

	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField
	private int trainingId;
	
	@DatabaseField
	private String comment;
	
	@DatabaseField
	private double averageScore;
	
	@DatabaseField
	private Date lastUpdated;
	
	public PastTrainingSessions() {
	}
	
	public PastTrainingSessions(int trainingId, String comment, double averageScore, Date lastUpdated) {
		this.trainingId = trainingId;
		this.comment = comment;
		this.averageScore = averageScore;
		this.lastUpdated = lastUpdated;
	}
	
	public PastTrainingSessions(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(trainingId);
		dest.writeString(comment);
		dest.writeDouble(averageScore);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		trainingId = in.readInt();
		comment = in.readString();
		averageScore = in.readDouble();
		lastUpdated = (Date) in.readSerializable();
	}

	public int getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public double getAverageScore() {
		return averageScore;
	}

	public void setAverageScore(double averageScore) {
		this.averageScore = averageScore;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public static final Parcelable.Creator<PastTrainingSessions> CREATOR = new Parcelable.Creator<PastTrainingSessions>() {  
	    
        public PastTrainingSessions createFromParcel(Parcel in) {  
            return new PastTrainingSessions(in);  
        }  
   
        public PastTrainingSessions[] newArray(int size) {  
            return new PastTrainingSessions[size];
        }
        
    };
}
