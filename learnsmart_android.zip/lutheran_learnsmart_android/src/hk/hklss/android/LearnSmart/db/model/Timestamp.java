package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class Timestamp implements Parcelable {

	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField
	private int serviceId;
	
	@DatabaseField
	private String name;
	
	@DatabaseField(dataType = DataType.DATE_STRING, format = "yyyy-MM-dd HH:mm:ss")
	private Date lastUpdated;
	
	public Timestamp() {
	}

	public Timestamp(/*int serviceId,*/ String name, Date lastUpdated) {
//		this.serviceId = serviceId;
		this.name = name;
		this.lastUpdated = lastUpdated;
	}
	
	public Timestamp(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeInt(serviceId);
		dest.writeString(name);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		serviceId = in.readInt();
		name = in.readString();
		lastUpdated = (Date) in.readSerializable();
	}
	
	public static final Parcelable.Creator<Timestamp> CREATOR = new Parcelable.Creator<Timestamp>() {  
	    
        public Timestamp createFromParcel(Parcel in) {  
            return new Timestamp(in);  
        }  
   
        public Timestamp[] newArray(int size) {  
            return new Timestamp[size];
        }
        
    };  

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
}
