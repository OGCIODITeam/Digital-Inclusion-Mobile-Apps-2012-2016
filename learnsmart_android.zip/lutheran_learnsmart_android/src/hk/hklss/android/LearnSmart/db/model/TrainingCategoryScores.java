package hk.hklss.android.LearnSmart.db.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class TrainingCategoryScores implements Parcelable {

	@DatabaseField(id = true)
	private String username;
	
	@DatabaseField
	private String title;
	
	@DatabaseField
	private double score;
	
	public TrainingCategoryScores() {
	}
	
	public TrainingCategoryScores(String username, String title, Double score) {
		this.username = username;
		this.title = title;
		this.score = score;
	}
	
	public TrainingCategoryScores(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(username);
		dest.writeString(title);
		dest.writeDouble(score);
	}
	
	private void readFromParcel(Parcel in) {
		username = in.readString();
		title = in.readString();
		score = in.readDouble();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public static final Parcelable.Creator<TrainingCategoryScores> CREATOR = new Parcelable.Creator<TrainingCategoryScores>() {  
	    
        public TrainingCategoryScores createFromParcel(Parcel in) {  
            return new TrainingCategoryScores(in);  
        }  
   
        public TrainingCategoryScores[] newArray(int size) {  
            return new TrainingCategoryScores[size];
        }
        
    };
}
