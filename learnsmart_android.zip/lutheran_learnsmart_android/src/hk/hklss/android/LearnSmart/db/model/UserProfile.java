package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class UserProfile implements Parcelable {
	
	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField(uniqueIndex = true)
	private String username;
	
	@DatabaseField
	private String organization;
	
	@DatabaseField
	private String fullName;
	
	@DatabaseField
	private String email;
	
	@DatabaseField
	private String role;
	
	@DatabaseField
	private String profilePhoto;
	
	@DatabaseField
	private Date lastUpdated;
	
	public UserProfile() {
	}
	
	public UserProfile(String username, String organization, String fullName, String email, String role, String profilePhoto, Date lastUpdated) {
		this.username = username;
		this.organization = organization;
		this.fullName = fullName;
		this.email = email;
		this.role = role;
		this.profilePhoto = profilePhoto;
		this.lastUpdated = lastUpdated;
	}
	
	public UserProfile(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(username);
		dest.writeString(organization);
		dest.writeString(fullName);
		dest.writeString(email);
		dest.writeString(role);
		dest.writeString(profilePhoto);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		username = in.readString();
		organization = in.readString();
		fullName = in.readString();
		email = in.readString();
		role = in.readString();
		profilePhoto = in.readString();
		lastUpdated = (Date) in.readSerializable();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getProfilePhoto() {
		return profilePhoto;
	}

	public void setProfilePhoto(String profilePhoto) {
		this.profilePhoto = profilePhoto;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public static final Parcelable.Creator<UserProfile> CREATOR = new Parcelable.Creator<UserProfile>() {  
	    
        public UserProfile createFromParcel(Parcel in) {  
            return new UserProfile(in);  
        }  
   
        public UserProfile[] newArray(int size) {  
            return new UserProfile[size];
        }
        
    };
}
