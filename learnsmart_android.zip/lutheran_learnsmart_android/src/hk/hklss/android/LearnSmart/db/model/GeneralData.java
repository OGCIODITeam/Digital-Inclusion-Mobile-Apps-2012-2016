package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class GeneralData implements Parcelable {
	
	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField(uniqueIndex = true)
	private String key;
	
	@DatabaseField
	private String value;
	
	public GeneralData() {
	}
	
	public GeneralData(String key, String value) {
		this.key = key;
		this.value = value;
	}
	
	public GeneralData(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(key);
		dest.writeString(value);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		key = in.readString();
		value = in.readString();
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static final Parcelable.Creator<GeneralData> CREATOR = new Parcelable.Creator<GeneralData>() {  
	    
        public GeneralData createFromParcel(Parcel in) {  
            return new GeneralData(in);  
        }  
   
        public GeneralData[] newArray(int size) {  
            return new GeneralData[size];
        }
        
    };
}
