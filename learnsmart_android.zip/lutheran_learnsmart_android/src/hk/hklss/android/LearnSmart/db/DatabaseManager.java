package hk.hklss.android.LearnSmart.db;

import hk.hklss.android.LearnSmart.db.model.*;

import java.sql.SQLException;
import java.util.List;

import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;

import android.content.Context;
import android.util.Log;

public class DatabaseManager {

	private static final String TAG = DatabaseManager.class.getSimpleName();
	
    static private DatabaseManager instance;
    
    private DatabaseHelper helper;

    public static DatabaseManager getInstance() {
    	if (null == instance) {
            instance = new DatabaseManager();
        }
    	
    	return instance;
    }

    private DatabaseManager() {
    }
    
    public void init(Context ctx) {
    	helper = new DatabaseHelper(ctx);
    }

    private DatabaseHelper getHelper() {
        return helper;
    }
    
    public void clearAll() {
    	getHelper().clearGeneralData();
    	getHelper().clearHallOfFame();
    	getHelper().clearMobileLogin();
    	getHelper().clearNews();
    	getHelper().clearPastTrainingSessions();
    	getHelper().clearTimestamp();
    	getHelper().clearTrainingCategories();
    	getHelper().clearTrainingCategoryScores();
    	getHelper().clearTrainingDetails();
    	getHelper().clearTrainings();
    	getHelper().clearTrainingSteps();
    	getHelper().clearUserProfile();
    	getHelper().clearWebService();
    }
    
    public void addGeneralData(GeneralData data) {
    	try {
    		getHelper().getGeneralDataDao().createOrUpdate(data);
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addHallOfFames(List<HallOfFame> data) {
    	try {
    		for (HallOfFame row : data) {
    			getHelper().getHallOfFameDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addMobileLogin(MobileLogin data) {
    	try {
    		MobileLogin oldData = getMobileLogin();
    		
    		if (oldData != null) {
    			data.setId(oldData.getId());
    		}
    		
    		getHelper().getMobileLoginDao().createOrUpdate(data);
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addNews(List<News> data) {
    	try {
    		for (News row : data) {
    			getHelper().getNewsDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addPastTrainingSessions(List<PastTrainingSessions> data) {
    	try {
    		for (PastTrainingSessions row : data) {
    			getHelper().getPastTrainingSessionsDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addTrainingCategories(List<TrainingCategories> data) {
    	try {
    		for (TrainingCategories row : data) {
    			getHelper().getTrainingCategoriesDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addTrainingCategoryScores(List<TrainingCategoryScores> data) {
    	try {
    		for (TrainingCategoryScores row : data) {
    			getHelper().getTrainingCategoryScoresDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addTrainingDetails(TrainingDetails data) {
    	try {
    		getHelper().getTrainingDetailsDao().createOrUpdate(data);
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addTrainings(List<Trainings> data) {
    	try {
    		for (Trainings row : data) {
    			getHelper().getTrainingsDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addTrainingSteps(List<TrainingSteps> data) {
    	try {
    		for (TrainingSteps row : data) {
    			getHelper().getTrainingStepsDao().createOrUpdate(row);
    		}
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void addUserProfile(UserProfile data) {
    	try {
    		UserProfile oldData = getUserProfile(data.getUsername());
    		
    		if (oldData != null) {
    			data.setId(oldData.getId());
    		}
    		
    		getHelper().getUserProfileDao().createOrUpdate(data);
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void deleteGeneralData(String key) {
    	try {
    		DeleteBuilder<GeneralData, Integer> db = getHelper().getGeneralDataDao().deleteBuilder();
    		db.where().eq("key", key);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void deleteHallOfFames() {
    	try {
    		DeleteBuilder<HallOfFame, Integer> db = getHelper().getHallOfFameDao().deleteBuilder();
    		//db.where().isNotNull("id");
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void deleteMobileLogin() {
    	try {
    		DeleteBuilder<MobileLogin, Integer> db = getHelper().getMobileLoginDao().deleteBuilder();
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void deleteNews() {
    	try {
    		DeleteBuilder<News, Integer> db = getHelper().getNewsDao().deleteBuilder();
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deletePastTrainingSessionsByTrainingId(int trainingId) {
    	try {
    		DeleteBuilder<PastTrainingSessions, Integer> db = getHelper().getPastTrainingSessionsDao().deleteBuilder();
    		db.where().eq("trainingId", trainingId);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainingCategories() {
    	try {
    		DeleteBuilder<TrainingCategories, Integer> db = getHelper().getTrainingCategoriesDao().deleteBuilder();
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainingCategoryScores(String username) {
    	try {
    		DeleteBuilder<TrainingCategoryScores, Integer> db = getHelper().getTrainingCategoryScoresDao().deleteBuilder();
    		db.where().eq("username", username);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainingDetails(int trainingId) {
    	try {
    		DeleteBuilder<TrainingDetails, Integer> db = getHelper().getTrainingDetailsDao().deleteBuilder();
    		db.where().eq("trainingId", trainingId);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainings(int id) {
    	try {
    		DeleteBuilder<Trainings, Integer> db = getHelper().getTrainingsDao().deleteBuilder();
    		db.where().eq("id", id);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainingsByCategory(int categoryId) {
    	try {
    		DeleteBuilder<Trainings, Integer> db = getHelper().getTrainingsDao().deleteBuilder();
    		db.where().eq("trainingCategoryId", categoryId);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainingsByMobileLogin(String username) {
    	try {
    		DeleteBuilder<Trainings, Integer> db = getHelper().getTrainingsDao().deleteBuilder();
    		db.where().eq("username", username);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }

    public void deleteTrainingStepsByTrainingId(int trainingId) {
    	try {
    		DeleteBuilder<TrainingSteps, Integer> db = getHelper().getTrainingStepsDao().deleteBuilder();
    		db.where().eq("trainingId", trainingId);
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }
    
    public void deleteUserProfile() {
    	try {
    		DeleteBuilder<UserProfile, Integer> db = getHelper().getUserProfileDao().deleteBuilder();
    		db.delete();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    }
  
    public GeneralData getGeneralData(String key) {
    	GeneralData data = null;
    	
    	try {
    		QueryBuilder<GeneralData, Integer> qb = getHelper().getGeneralDataDao().queryBuilder();
    		data = qb.queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    	
    	return data;
    }
    
    public List<HallOfFame> getHallOfFames() {
    	List<HallOfFame> data = null;
    	
    	try {
    		data = getHelper().getHallOfFameDao().queryForAll();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    	
    	return data;
    }
    
    public MobileLogin getMobileLogin() {
    	MobileLogin data = null;
    	
    	try {
    		QueryBuilder<MobileLogin, Integer> qb = getHelper().getMobileLoginDao().queryBuilder();
    		data = qb.queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    	
    	return data;
    }
    
    public List<News> getNews() {
    	List<News> data = null;
    	
    	try {
    		QueryBuilder<News, Integer> qb = getHelper().getNewsDao().queryBuilder();
    		data = qb
    				.orderBy("priority", true)
        			.orderBy("lastUpdated", true)
        			.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    	
    	return data;
    }
    
    public List<PastTrainingSessions> getPastTrainingSessionsByTrainingId(int trainingId) {
    	List<PastTrainingSessions> data = null;
    	
        try {
        	data = getHelper().getPastTrainingSessionsDao().queryBuilder()
        			.where()
        			.eq("trainingId", trainingId)
        			.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public Trainings getTraining(int trainingId) {
    	Trainings data = null;
    	
        try {
        	data = getHelper().getTrainingsDao().queryBuilder()
        			.where().eq("id", trainingId)
        			.queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public List<TrainingCategories> getTrainingCategories() {
    	List<TrainingCategories> data = null;
    	
        try {
        	QueryBuilder<TrainingCategories, Integer> qb =  getHelper().getTrainingCategoriesDao().queryBuilder();
        	qb
        		.orderBy("priority", true)
        		.orderBy("title", true);
        	data = qb.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public TrainingCategories getTrainingCategory(int id) {
    	TrainingCategories data = null;
    	
        try {
        	QueryBuilder<TrainingCategories, Integer> qb =  getHelper().getTrainingCategoriesDao().queryBuilder();
        	qb.where().eq("id", id);
        	data = qb.queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public List<TrainingCategoryScores> getTrainingCategoryScores(String username) {
    	List<TrainingCategoryScores> data = null;
    	
        try {
        	data = getHelper().getTrainingCategoryScoresDao().queryBuilder()
        			.where().eq("username", username)
        			.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public TrainingDetails getTrainingDetails(int trainingId) {
    	TrainingDetails data = null;
    	
        try {
        	data = getHelper().getTrainingDetailsDao().queryBuilder()
        			.where().eq("trainingId", trainingId)
        			.queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public List<Trainings> getTrainingsByUsername(String username) {
    	List<Trainings> data = null;
    	
        try {
        	QueryBuilder<Trainings, Integer> qb = getHelper().getTrainingsDao().queryBuilder();
        	qb.where().eq("username", username);
        	qb.orderBy("priority", true).orderBy("title", true);
        	data = qb.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public List<Trainings> getTrainingsByCategory(int categoryId) {
    	List<Trainings> data = null;
    	
        try {
        	QueryBuilder<Trainings, Integer> qb = getHelper().getTrainingsDao().queryBuilder();
        	qb.where().eq("trainingCategoryId", categoryId);
        	qb.orderBy("priority", true).orderBy("title", true);
        	data = qb.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public List<TrainingSteps> getTrainingStepsByTrainingId(int trainingId) {
    	List<TrainingSteps> data = null;
    	
        try {
        	QueryBuilder<TrainingSteps, Integer> qb = getHelper().getTrainingStepsDao().queryBuilder();
        	qb.where().eq("trainingId", trainingId);
        	qb.orderBy("step", true);
        	data = qb.query();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
    
    public UserProfile getUserProfile(String username) {
    	UserProfile data = null;
    	
    	try {
    		QueryBuilder<UserProfile, Integer> qb = getHelper().getUserProfileDao().queryBuilder();
    		qb.where().eq("username", username);
    		data = qb.queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
    	
    	return data;
    }
    
    public WebService getWebServiceByName(String name) {
    	WebService data = null;
    	
        try {
        	data = getHelper().getWebServiceDao().queryBuilder().where().eq("name", name).queryForFirst();
        } catch (SQLException e) {
        	Log.e(TAG, e.getMessage(), e);
        }
        
        return data;
    }
}