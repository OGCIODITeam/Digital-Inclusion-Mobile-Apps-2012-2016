package hk.hklss.android.LearnSmart.db;

import hk.hklss.android.LearnSmart.Constants;
import hk.hklss.android.LearnSmart.db.model.GeneralData;
import hk.hklss.android.LearnSmart.db.model.HallOfFame;
import hk.hklss.android.LearnSmart.db.model.MobileLogin;
import hk.hklss.android.LearnSmart.db.model.News;
import hk.hklss.android.LearnSmart.db.model.PastTrainingSessions;
import hk.hklss.android.LearnSmart.db.model.Timestamp;
import hk.hklss.android.LearnSmart.db.model.TrainingCategories;
import hk.hklss.android.LearnSmart.db.model.TrainingCategoryScores;
import hk.hklss.android.LearnSmart.db.model.TrainingDetails;
import hk.hklss.android.LearnSmart.db.model.TrainingSteps;
import hk.hklss.android.LearnSmart.db.model.Trainings;
import hk.hklss.android.LearnSmart.db.model.UserProfile;
import hk.hklss.android.LearnSmart.db.model.WebService;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

public class DatabaseHelper extends OrmLiteSqliteOpenHelper {

	private static final String TAG = DatabaseHelper.class.getSimpleName();
	public static final String DATABASE_NAME = "cache.db";

	private static final int DATABASE_VERSION = 1;

	private Dao<GeneralData, Integer> generalDataDao = null;
	private Dao<HallOfFame, Integer> hallOfFameDao = null;
	private Dao<MobileLogin, Integer> mobileLoginDao = null;
	private Dao<News, Integer> newsDao = null;
	private Dao<PastTrainingSessions, Integer> pastTrainingSessionsDao = null;
	private Dao<Timestamp, Integer> timestampDao = null;
	private Dao<TrainingCategories, Integer> trainingCategoriesDao = null;
	private Dao<TrainingCategoryScores, Integer> trainingCategoryScoresDao = null;
	private Dao<TrainingDetails, Integer> trainingDetailsDao = null;
	private Dao<Trainings, Integer> trainingsDao = null;
	private Dao<TrainingSteps, Integer> trainingStepsDao = null;
	private Dao<UserProfile, Integer> userProfileDao = null;
	private Dao<WebService, Integer> webserviceDao = null;
	
	public DatabaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	@Override
	public void onOpen(SQLiteDatabase db) {
		super.onOpen(db);
	}

	@Override
	public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
		try {
			TableUtils.createTable(connectionSource, GeneralData.class);
			TableUtils.createTable(connectionSource, HallOfFame.class);
			TableUtils.createTable(connectionSource, MobileLogin.class);
			TableUtils.createTable(connectionSource, News.class);
			TableUtils.createTable(connectionSource, PastTrainingSessions.class);
			TableUtils.createTable(connectionSource, Timestamp.class);
			TableUtils.createTable(connectionSource, TrainingCategories.class);
			TableUtils.createTable(connectionSource, TrainingCategoryScores.class);
			TableUtils.createTable(connectionSource, TrainingDetails.class);
			TableUtils.createTable(connectionSource, Trainings.class);
			TableUtils.createTable(connectionSource, TrainingSteps.class);
			TableUtils.createTable(connectionSource, UserProfile.class);
			TableUtils.createTable(connectionSource, WebService.class);
			
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_CHECKPOINTS, "checkpoints.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_HALL_OF_FAME, "hallOfFames.json?username=%s&token=%s"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_MOBILE_LOGIN, "login.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_MOBILE_LOGIN_VERIFY, "verifyLogin.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_MOBILE_PROFILE, "mobileUserProfile.json?username=%s&token=%s"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_MOBILE_PROFILE_UPDATE, "updateMobileUserProfile.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_MOBILE_RESET_PASSWORD, "forgetPassword.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_NEWS_AND_ABOUTUS, "aboutus.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_PAST_TRAINING_SESSIONS, "pastTrainingSessions.json?username=%s&token=%s&tid=%s"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_CATEGORIES, "trainingCats.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_CATEGORY_SCORES, "categoryScores.json?username=%s&token=%s"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_DETAILS, "trainingDetails.json?username=%s&token=%s&tid=%s"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_BY_CATEGORY, "trainings/%s.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_BY_MOBILE_LOGIN, "trainings.json?username=%s&token=%s"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_SESSION, "trainingSession.json"));
			getWebServiceDao().create(new WebService(Constants.WEBSERVICE_TRAINING_STEPS, "trainingSteps/%s.json"));
		} catch (SQLException e) {
			Log.e(TAG, "Can't create database", e);
			throw new RuntimeException(e);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, ConnectionSource connectionSource, int oldVersion, int newVersion) {
		try {
			List<String> allSql = new ArrayList<String>();
			
			switch (oldVersion) {
				case 1:
					// allSql.add("alter table AdData add column `new_col` VARCHAR");
			}
			
			for (String sql : allSql) {
				db.execSQL(sql);
			}
		} catch (SQLException e) {
			Log.e(TAG, "exception during onUpgrade", e);
			throw new RuntimeException(e);
		}
	}
	
	@Override
	public void close() {
		super.close();

		generalDataDao = null;
		hallOfFameDao = null;
		mobileLoginDao = null;
		newsDao = null;
		pastTrainingSessionsDao = null;
		timestampDao = null;
		trainingCategoriesDao = null;
		trainingCategoryScoresDao = null;
		trainingDetailsDao = null;
		trainingsDao = null;
		trainingStepsDao = null;
		userProfileDao = null;
		webserviceDao = null;
	}
	
	public void clearGeneralData() {
		try {
			TableUtils.clearTable(connectionSource, GeneralData.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearHallOfFame() {
		try {
			TableUtils.clearTable(connectionSource, HallOfFame.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearMobileLogin() {
		try {
			TableUtils.clearTable(connectionSource, MobileLogin.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearNews() {
		try {
			TableUtils.clearTable(connectionSource, News.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearPastTrainingSessions() {
		try {
			TableUtils.clearTable(connectionSource, PastTrainingSessions.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearTimestamp() {
		try {
			TableUtils.clearTable(connectionSource, Timestamp.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearTrainingCategories() {
		try {
			TableUtils.clearTable(connectionSource, TrainingCategories.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearTrainingCategoryScores() {
		try {
			TableUtils.clearTable(connectionSource, TrainingCategoryScores.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearTrainingDetails() {
		try {
			TableUtils.clearTable(connectionSource, TrainingDetails.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearTrainings() {
		try {
			TableUtils.clearTable(connectionSource, Trainings.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearTrainingSteps() {
		try {
			TableUtils.clearTable(connectionSource, TrainingSteps.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearUserProfile() {
		try {
			TableUtils.clearTable(connectionSource, UserProfile.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}
	
	public void clearWebService() {
		try {
			TableUtils.clearTable(connectionSource, WebService.class);
		} catch (java.sql.SQLException e) {
			Log.e(TAG, e.getMessage(), e);
		}
	}

	public Dao<GeneralData, Integer> getGeneralDataDao() {
		if (null == generalDataDao) {
			try {
				generalDataDao = getDao(GeneralData.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return generalDataDao;
	}

	public Dao<HallOfFame, Integer> getHallOfFameDao() {
		if (null == hallOfFameDao) {
			try {
				hallOfFameDao = getDao(HallOfFame.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return hallOfFameDao;
	}

	public Dao<MobileLogin, Integer> getMobileLoginDao() {
		if (null == mobileLoginDao) {
			try {
				mobileLoginDao = getDao(MobileLogin.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return mobileLoginDao;
	}

	public Dao<News, Integer> getNewsDao() {
		if (null == newsDao) {
			try {
				newsDao = getDao(News.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return newsDao;
	}

	public Dao<PastTrainingSessions, Integer> getPastTrainingSessionsDao() {
		if (null == pastTrainingSessionsDao) {
			try {
				pastTrainingSessionsDao = getDao(PastTrainingSessions.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return pastTrainingSessionsDao;
	}

	public Dao<Timestamp, Integer> getTimestampDao() {
		if (null == timestampDao) {
			try {
				timestampDao = getDao(Timestamp.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return timestampDao;
	}

	public Dao<TrainingCategories, Integer> getTrainingCategoriesDao() {
		if (null == trainingCategoriesDao) {
			try {
				trainingCategoriesDao = getDao(TrainingCategories.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return trainingCategoriesDao;
	}

	public Dao<TrainingCategoryScores, Integer> getTrainingCategoryScoresDao() {
		if (null == trainingCategoryScoresDao) {
			try {
				trainingCategoryScoresDao = getDao(TrainingCategoryScores.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return trainingCategoryScoresDao;
	}

	public Dao<TrainingDetails, Integer> getTrainingDetailsDao() {
		if (null == trainingDetailsDao) {
			try {
				trainingDetailsDao = getDao(TrainingDetails.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return trainingDetailsDao;
	}

	public Dao<Trainings, Integer> getTrainingsDao() {
		if (null == trainingsDao) {
			try {
				trainingsDao = getDao(Trainings.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return trainingsDao;
	}

	public Dao<TrainingSteps, Integer> getTrainingStepsDao() {
		if (null == trainingStepsDao) {
			try {
				trainingStepsDao = getDao(TrainingSteps.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return trainingStepsDao;
	}

	public Dao<UserProfile, Integer> getUserProfileDao() {
		if (null == userProfileDao) {
			try {
				userProfileDao = getDao(UserProfile.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return userProfileDao;
	}

	public Dao<WebService, Integer> getWebServiceDao() {
		if (null == webserviceDao) {
			try {
				webserviceDao = getDao(WebService.class);
			} catch (java.sql.SQLException e) {
				Log.e(TAG, e.getMessage(), e);
			}
		}
		return webserviceDao;
	}
}