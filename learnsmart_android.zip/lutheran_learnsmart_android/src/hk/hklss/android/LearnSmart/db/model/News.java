package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class News implements Parcelable {
	
	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField
	private String title;
	
	@DatabaseField
	private String description;
	
	@DatabaseField
	private int priority;
	
	@DatabaseField
	private Date lastUpdated;
	
	public News() {
	}
	
	public News(String title, String description, int priority, Date lastUpdated) {
		this.title = title;
		this.description = description;
		this.priority = priority;
		this.lastUpdated = lastUpdated;
	}
	
	public News(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(title);
		dest.writeString(description);
		dest.writeInt(priority);
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		title = in.readString();
		description = in.readString();
		priority = in.readInt();
		lastUpdated = (Date) in.readSerializable();
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public static final Parcelable.Creator<News> CREATOR = new Parcelable.Creator<News>() {  
	    
        public News createFromParcel(Parcel in) {  
            return new News(in);  
        }  
   
        public News[] newArray(int size) {  
            return new News[size];
        }
        
    };
}
