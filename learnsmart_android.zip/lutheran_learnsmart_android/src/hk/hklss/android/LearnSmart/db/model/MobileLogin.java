package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class MobileLogin implements Parcelable {
	
	@DatabaseField(generatedId = true)
	private int id;
	
	@DatabaseField(uniqueIndex = true)
	private String username;
	
	@DatabaseField
	private String token;
	
	@DatabaseField
	private Date tokenExpiryDate;
	
	@DatabaseField
	private boolean isTrainer;
	
	public MobileLogin() {
	}
	
	public MobileLogin(String username, String token, Date tokenExpiryDate, boolean isTrainer) {
		this.username = username;
		this.token = token;
		this.tokenExpiryDate = tokenExpiryDate;
		this.isTrainer = isTrainer;
	}
	
	public MobileLogin(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(username);
		dest.writeString(token);
		dest.writeSerializable(tokenExpiryDate);
		dest.writeByte((byte) (isTrainer ? 1 : 0));
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		username = in.readString();
		token = in.readString();
		tokenExpiryDate = (Date) in.readSerializable();
		isTrainer = (in.readByte() == 1);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Date getTokenExpiryDate() {
		return tokenExpiryDate;
	}

	public void setTokenExpiryDate(Date tokenExpiryDate) {
		this.tokenExpiryDate = tokenExpiryDate;
	}

	public boolean isTrainer() {
		return isTrainer;
	}

	public void setTrainer(boolean isTrainer) {
		this.isTrainer = isTrainer;
	}

	public static final Parcelable.Creator<MobileLogin> CREATOR = new Parcelable.Creator<MobileLogin>() {  
	    
        public MobileLogin createFromParcel(Parcel in) {  
            return new MobileLogin(in);  
        }  
   
        public MobileLogin[] newArray(int size) {  
            return new MobileLogin[size];
        }
        
    };
}
