package hk.hklss.android.LearnSmart.db.model;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class Trainings implements Parcelable {

	@DatabaseField(id = true)
	private int id;
	
	@DatabaseField
	private String username;
	
	@DatabaseField
	private int trainingCategoryId;	
	
	@DatabaseField
	private String thumbnail;
	
	@DatabaseField
	private String title;
	
	@DatabaseField
	private String description;
	
	@DatabaseField
	private int priority;
	
	@DatabaseField
	private boolean finished;
	
	@DatabaseField
	private Date lastUpdated;
	
	public Trainings() {
	}
	
	public Trainings(int id, String username, int trainingCategoryId, String thumbnail, String title, String description, int priority, boolean finished, Date lastUpdated) {
		this.id = id;
		this.username = username;
		this.trainingCategoryId = trainingCategoryId;
		this.thumbnail = thumbnail;
		this.title = title;
		this.description = description;
		this.priority = priority;
		this.finished = finished;
		this.lastUpdated = lastUpdated;
	}
	
	public Trainings(Parcel in) {
		readFromParcel(in);
	}
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(username);
		dest.writeInt(trainingCategoryId);
		dest.writeString(thumbnail);
		dest.writeString(title);
		dest.writeString(description);
		dest.writeInt(priority);
		dest.writeByte((byte) (finished ? 1: 0));
		dest.writeSerializable(lastUpdated);
	}
	
	private void readFromParcel(Parcel in) {
		id = in.readInt();
		username = in.readString();
		trainingCategoryId = in.readInt();
		thumbnail = in.readString();
		title = in.readString();
		description = in.readString();
		priority = in.readInt();
		finished = (in.readByte() == 1);
		lastUpdated = (Date) in.readSerializable();
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getTrainingCategoryId() {
		return trainingCategoryId;
	}

	public void setTrainingCategoryId(int trainingCategoryId) {
		this.trainingCategoryId = trainingCategoryId;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public static final Parcelable.Creator<Trainings> CREATOR = new Parcelable.Creator<Trainings>() {  
	    
        public Trainings createFromParcel(Parcel in) {  
            return new Trainings(in);  
        }  
   
        public Trainings[] newArray(int size) {  
            return new Trainings[size];
        }
        
    };
}
