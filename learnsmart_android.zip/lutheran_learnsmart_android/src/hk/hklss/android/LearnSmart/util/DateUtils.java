package hk.hklss.android.LearnSmart.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

	public static Date addMilliseconds(Date date, int ms)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MILLISECOND, ms);
        return cal.getTime();
    }
	
	public static Date parseDate(String format, String value) throws ParseException {
		Date d = new SimpleDateFormat(format).parse(value);
		
		return d;
	}
	
	public static String formatDate(String format, Date value) {
		String dateString = value.toString();
		dateString = new SimpleDateFormat(format).format(value);
		return dateString;
	}
	
	public static String formatTime(String format, long milliseconds) {
	    return new SimpleDateFormat(format).format(new Date(milliseconds));
	}
}
