package hk.hklss.android.LearnSmart.util;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.text.Html;
import android.text.util.Linkify;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;

public class UIHelper {
	
	public static String DEFAULT_TEXT_COLOR = "#FFFFFF";
	public static String DEFAULT_BACKGROUND_COLOR = "";

	public static void setTextView(String value, TextView tv, ViewGroup container, boolean useLinkify, boolean useUnderline) {
		if (value != null && !value.equals("")) {
			if (useUnderline) {
				tv.setText(Html.fromHtml("<a href=\"#\">" + value + "</a>"));
			} else {
				tv.setText(value);
			}
			
			if (useLinkify) {
				Linkify.addLinks(tv, Linkify.ALL);
			}
		} else {
			if (container != null) {
				container.setVisibility(View.GONE);
			} else {
				tv.setVisibility(View.GONE);
			}
		}
	}
	
	public static void setImageView(String url, ImageView iv) {
		setImageView(url, iv, null);
	}
	
	public static void setImageView(String url, ImageView iv, final ImageLoadingListener listener) {
		if (url != null && !url.equals("")) {
			ImageLoader.getInstance().displayImage(url, iv, listener);
		} else {
			iv.setVisibility(View.GONE);
		}
	}
	
	@SuppressLint("NewApi")
	public static void setWebView(String html, WebView wv, ViewGroup container, String textColor) {
		if (html != null && !html.equals("")) {
			String colorHtml = "<style>body{margin:0;padding:0;color:" + textColor + ";}</style>" + html;
			
			wv.loadDataWithBaseURL("", colorHtml, "text/html", "utf-8", "");
			
			wv.setBackgroundColor(0x00000000);
			wv.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
//			wv.getSettings().setPluginState(PluginState.ON);
//			wv.getSettings().setJavaScriptEnabled(true);
			wv.getSettings().setAllowFileAccess(true);
			
			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
				wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
			}
			
		} else {
			if (container != null) {
				container.setVisibility(View.GONE);
			} else {
				wv.setVisibility(View.GONE);
			}
		}
	}
	
//	public static String getThemedHtml(String originalHtml, String color, String backgroundColor) {
//		String themedHtml = "";
//		String code_style = "<style>body{margin:0;padding:0;color:%s;background-color:%s;}</style>";
//		String code_html_prefix = "<!DOCTYPE html><html><head>%s</head><body>";
//		String code_html_suffix = "</body></html>";
//		
//		if (originalHtml.contains("<head>")) {
//			String styledHtml = originalHtml.replace("<head>", "<head>" + code_style);
//			themedHtml = String.format(
//					styledHtml, 
//					color, 
//					backgroundColor
//				);
//		} else {
//			String styledHtml = String.format(code_html_prefix, code_style);
//			themedHtml = String.format(
//					styledHtml, 
//					color, 
//					backgroundColor
//				);
//			themedHtml += originalHtml + code_html_suffix;
//		}
//		
//		return themedHtml;
//	}
	
    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();

        if (listAdapter == null) {
            return;
        }

        int desiredWidth = MeasureSpec.makeMeasureSpec(listView.getWidth(), MeasureSpec.AT_MOST);
        
        int totalHeight = 0;
        
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(desiredWidth, 0);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }
    
    public static int getActionBarTitleId() {
    	int id = 0;
    	
        try {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB) {
                id = Class.forName("com.actionbarsherlock.R$id").getField("abs__action_bar_title").getInt(null);
            } else {
                id = Class.forName("com.android.internal.R$id").getField("action_bar_title").getInt(null);
            }
        }
        catch (Exception e) {
        }
    	
    	return id;
    }
    
    public static int getActionBarSubtitleId() {
    	int id = 0;
    	
        try {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB) {
                id = Class.forName("com.actionbarsherlock.R$id").getField("abs__action_bar_subtitle").getInt(null);
            } else {
            	id = Class.forName("com.android.internal.R$id").getField("action_bar_subtitle").getInt(null);
            }
        }
        catch (Exception e) {
        }
    	
    	return id;
    }
}