package hk.hklss.android.LearnSmart.util;

import java.math.BigDecimal;

public class MathUtils {

	public static float add(float... values) {
		BigDecimal bdResult = new BigDecimal(0);
		
		for (float value : values) {
			BigDecimal bdValue = new BigDecimal(value);
			bdResult = bdResult.add(bdValue);
		}
		
		return bdResult.floatValue();
	}
	
	public static float subtract(float... values) {
		BigDecimal bdResult = new BigDecimal(0);
		
		if (values.length > 0) {
			bdResult = bdResult.add(new BigDecimal(values[0]));
		}
		
		for (int i = 1; i < values.length; i++) {
			BigDecimal bdValue = new BigDecimal(values[i]);
			bdResult = bdResult.subtract(bdValue);
		}
		
		return bdResult.floatValue();
	}
}
