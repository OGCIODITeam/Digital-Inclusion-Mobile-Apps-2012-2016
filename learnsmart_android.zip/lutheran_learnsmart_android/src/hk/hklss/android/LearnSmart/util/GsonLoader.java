package hk.hklss.android.LearnSmart.util;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class GsonLoader {
	
	private static final String TAG = GsonLoader.class.getSimpleName();
	
 	private static GsonLoader gsonLoader;
 	private Gson gson;
	
	private GsonLoader() {
		gson = new Gson();
	}
	
	public synchronized static GsonLoader getInstance() {
		if (gsonLoader == null) {
			gsonLoader = new GsonLoader();
		}
		
		return gsonLoader;
	}
	
	public Gson getGson() {
		return this.gson;
	}
	
	public void init(GsonBuilder gsonBuilder) {
		this.gson = gsonBuilder.create();
	}
}
