package hk.hklss.android.LearnSmart.util;

import hk.hklss.android.LearnSmart.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.Toast;

public class DialogHelper {

	private static DialogHelper dialogHelper;
	private Context context;
	
	protected DialogHelper() {
	}
	
	public static DialogHelper getInstance() {
		if (dialogHelper == null) {
			dialogHelper = new DialogHelper();
		}
		
		return dialogHelper;
	}
	
	public void init(Context context) {
		this.context = context.getApplicationContext();
	}
	
//	public AlertDialog showExitDialog() {
//		return showExitDialog(TabStackManager.getInstance().getActivity());
//	}
	
	public AlertDialog showExitDialog(final Activity activity) {
	    AlertDialog.Builder exitDialog = new AlertDialog.Builder(activity);
	    exitDialog.setCancelable(false);
	    exitDialog.setTitle(R.string.dialog_exit_title);
	    exitDialog.setMessage(R.string.dialog_exit_message);
	    exitDialog.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
	        @Override
	        public void onClick(DialogInterface dialog, int which) {
	        	activity.finish();
	        }
	    });
	    exitDialog.setNegativeButton(android.R.string.no, null);
	    
	    return exitDialog.show();
	}
	
//	public ProgressDialog showLoadingDialog() {
//		return showLoadingDialog(TabStackManager.getInstance().getActivity());
//	}
	
//	public ProgressDialog showLoadingDialog(final Activity activity) {
//		ProgressDialog loadingDialog = new ProgressDialog(activity);
//	    
//		loadingDialog.setCancelable(false);
//	    loadingDialog.setTitle(R.string.dialog_loading_title);
//	    loadingDialog.setMessage(context.getString(R.string.dialog_loading_message));
//	    loadingDialog.show();
//	    
//	    return loadingDialog;
//	}
//	
//	public AlertDialog showOkDialog(String title, String message, DialogHandler handler) {
//		return showOkDialog(title, message, TabStackManager.getInstance().getActivity(), handler);
//	}
//	
//	public AlertDialog showOkDialog(String title, String message, final Activity activity, final DialogHandler handler) {
//		AlertDialog.Builder okDialog = new AlertDialog.Builder(activity);
//		okDialog.setCancelable(false);
//	    okDialog.setTitle(title);
//	    okDialog.setMessage(message);
//	    okDialog.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
//	        @Override
//	        public void onClick(DialogInterface dialog, int which) {
//	        	if (handler != null) {
//	        		handler.onClick();
//	        	}
//	        }
//	    });
//	    
//	    return okDialog.show();
//	}
	
//	public AlertDialog showLoadFileDialog(String message, DialogHandler handler) {
//		return showLoadFileDialog(message, TabStackManager.getInstance().getActivity(), handler);
//	}
//	
//	public AlertDialog showLoadFileDialog(String message, final Activity activity, final DialogHandler handler) {
//		ProgressDialog.Builder loadFileDialog = new ProgressDialog.Builder(activity);
//		downloadDialog.setCancelable(false);
//		downloadDialog.setTitle(title);
//		downloadDialog.setMessage(message);
//		downloadDialog.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
//	        @Override
//	        public void onClick(DialogInterface dialog, int which) {
//	        	if (handler != null) {
//	        		handler.onClick();
//	        	}
//	        }
//	    });
//	    
//	    return okDialog.show();
//	}
	
	
//	public void showNetworkErrorDialog() {
//		showNetworkErrorDialog(TabStackManager.getInstance().getActivity());
//	}
//	
//	public void showNetworkErrorDialog(final Activity activity) {
//		Toast.makeText(activity, context.getString(R.string.dialog_network_conntection_error_message), Toast.LENGTH_SHORT).show();
//	}
	
	public static interface DialogHandler {
		void onClick();
	}
}

