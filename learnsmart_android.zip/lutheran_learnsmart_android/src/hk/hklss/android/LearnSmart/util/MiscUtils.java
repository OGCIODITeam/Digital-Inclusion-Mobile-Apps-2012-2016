package hk.hklss.android.LearnSmart.util;

import java.lang.reflect.Field;
import java.util.Date;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

public class MiscUtils {

	private final static String TAG = MiscUtils.class.getSimpleName(); 
	
	public static Object getFieldValue(Class<?> type, Object object, String fieldName) {
		Object value = null;
		
		try {
			Field field = type.getDeclaredField(fieldName);
			field.setAccessible(true);
			value = field.get(object);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage(), e);
		}
		return value;
	}
	
	public static int getFieldIntValue(Class<?> type, Object object, String fieldName) {
		Object value = getFieldValue(type, object, fieldName);
		
		return Integer.getInteger((String)value, 0);
	}
	
	public static String getAppVersion(Context context) {
		String ver = "";
		
		try {
			PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			ver = pInfo.versionName;
		} catch (NameNotFoundException e) {
			Log.e(TAG, e.getMessage(), e);
		}
		
		return ver;
	}
	
	public static boolean isTokenValid(Date tokenExpiryDate) {
		if (tokenExpiryDate.after(new Date())) {
			return true;
		}
		
		return false;
	}
	
	public static void hideSoftKeybord(Activity activity) {
		InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
	    inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
	}
}
