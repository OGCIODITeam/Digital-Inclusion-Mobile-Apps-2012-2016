package hk.hklss.android.LearnSmart.util;

import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

public class RestHelper {

	public static RestTemplate getRestTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());	// force fallback to use HTTPClient instead of default HttpURLConnection 
		
		return restTemplate;
	}
	
	public static GsonHttpMessageConverter getGsonHttpMessageConverter() {
		GsonHttpMessageConverter gsonConverter = new GsonHttpMessageConverter();
		gsonConverter.setGson(GsonLoader.getInstance().getGson());
		return gsonConverter;
	}
}
