package hk.hklss.android.LearnSmart.util;

import java.io.File;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

public class GraphicUtils {
	
	private static final String TAG = GraphicUtils.class.getSimpleName();

	public static Bitmap getBitmap(String bmpFilePath) {
		return BitmapFactory.decodeFile(bmpFilePath);
	}
	
	public static Bitmap getBitmap(File bmpFile) {
		return BitmapFactory.decodeFile(bmpFile.getAbsolutePath());
	}
	
	public static BitmapDrawable getBitmapDrawable(Context context, String filePath) {
		return new BitmapDrawable(context.getResources(), filePath);
	}
	
	public static BitmapDrawable getBitmapDrawable(Context context, File file) {
		return new BitmapDrawable(context.getResources(), file.getAbsolutePath());
	}
    
    public static Bitmap getMaximumScaledBitmap(Bitmap source, Context context) {
    	WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		int displayWidth = display.getWidth();
		int displayHeight = display.getHeight();
    	
    	int oriWidth = source.getWidth();
		int oriHeight = source.getHeight();
    	
		int newWidth, tempWidth = 0;
		int newHeight, tempHeight = 0;
		
		tempWidth = displayWidth;
		tempHeight = tempWidth * oriHeight / oriWidth;
		
		if (tempHeight > displayHeight) {
			tempHeight = displayHeight;
			tempWidth = tempHeight * oriWidth / oriHeight;
		}
		
		newWidth = tempWidth;
		newHeight = tempHeight;
		
		float scaleRate = (float) newWidth / oriWidth;
		
		Matrix matrix = new Matrix();
    	matrix.postScale(scaleRate, scaleRate);
    	
    	return Bitmap.createBitmap(source, 0, 0, oriWidth, oriHeight, matrix, true);
    }
	
	public static int getColorInt(String colorString, int defaultColor) {
		int color = defaultColor;
		
		try {
			color = Color.parseColor(colorString);
		} catch (Exception ex) {
			Log.w(TAG, "Unable to parse color with string: " + colorString);
			color = defaultColor;
		}
		
		return color;
	}
	
	public static ColorDrawable getColorDrawable(int color) {
		return new ColorDrawable(color);
	}
    
    public static float convertDpToPixel(float dp, Context context){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * (metrics.densityDpi / 160f);
        return px;
    }
    
    public static float convertPixelsToDp(float px, Context context){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / (metrics.densityDpi / 160f);
        return dp;
    }
    
    public static int convertDpToPixelInt(float dp, Context context){
        return Math.round(convertDpToPixel(dp, context));
    }
    
    public static int convertPixelsToDpInt(float px, Context context){
        return Math.round(convertPixelsToDp(px, context));
    }
}
