//
//  DrumGameViewController.h
//  DSKid
//
//  Created by Piu on 12/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface DrumGameViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *score;
@property (strong, nonatomic) IBOutlet UILabel *timer;

@property (strong, nonatomic) NSTimer *counter;
@property (strong, nonatomic) NSDate *baseDate;
@property (strong, nonatomic) IBOutlet UIImageView *count1;
@property (strong, nonatomic) IBOutlet UIImageView *count2;
@property (strong, nonatomic) IBOutlet UIImageView *count3;

@property (strong, nonatomic) IBOutlet UIImageView *drummer;
@property (nonatomic) int hitDrumAnimationFrame;

@property (nonatomic) int scoreInt;

@property (strong, nonatomic) AVAudioPlayer *drumSound;
@property (nonatomic) bool canHitDrum;


- (IBAction)backTapped:(id)sender;

@end
