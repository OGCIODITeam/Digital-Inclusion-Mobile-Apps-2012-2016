//
//  ViewController.m
//  DSKid
//
//  Created by Piu on 3/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize mainViewController,splashViewController;


-(BOOL)prefersStatusBarHidden{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        mainViewController = [[MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil];
    }
    else{
        mainViewController = [[MainViewController alloc] initWithNibName:@"MainViewControlleriPhone" bundle:nil];

    }
    
    mainViewController.view.frame = self.view.frame;
    
    [self.view addSubview:mainViewController.view];
    
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        splashViewController = [[SplashViewController alloc] initWithNibName:@"SplashViewController" bundle:nil];
    }
    else{
        splashViewController = [[SplashViewController alloc] initWithNibName:@"SplashViewControlleriPhone" bundle:nil];

    }
    splashViewController.view.frame = self.view.frame;

    [self.view addSubview:splashViewController.view];
    
    [UIView animateWithDuration:0.5 delay:4 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        splashViewController.view.alpha=0;

    }
                     completion:^(BOOL finished){
                         [splashViewController.view removeFromSuperview];
                     }];

    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
