//
//  WebContentViewController.h
//  DSKid
//
//  Created by Piu on 7/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EventManager.h"

@protocol WebContentViewControllerDelegate <NSObject>

- (void) closeWebContentView;

@end

@interface WebContentViewController : UIViewController<UIWebViewDelegate,WebContentViewControllerDelegate>{
    id <WebContentViewControllerDelegate> delegate;
}

@property (strong, nonatomic) id <WebContentViewControllerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIWebView *webContentView;
@property (strong, nonatomic) NSString *currentSection;
@property (strong, nonatomic) NSString *URL;

@property (nonatomic, strong) EventManager *eventManager;
@property (nonatomic, strong) NSString *calendarIdentifier;




- (void) closeWebContentView;


@end
