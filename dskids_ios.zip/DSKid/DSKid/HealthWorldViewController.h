//
//  HealthWorldViewController.h
//  DSKid
//
//  Created by Piu on 6/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GameStartViewController.h"
#import "RewardViewController.h"


@protocol HealthWorldViewControllerDelegate <NSObject>

- (bool) soundPlaying;

- (IBAction)speakerTapped:(id)sender;


- (void) stopMainBGM;
- (void) resumeMainBGM;

@end


@interface HealthWorldViewController : UIViewController<GameStartViewControllerDelegate,RewardViewControllerDelegate>{
    id <HealthWorldViewControllerDelegate> delegate;
}
@property (strong, nonatomic) NSString *language;

@property (strong, nonatomic) id <HealthWorldViewControllerDelegate> delegate;


@property (strong, nonatomic) IBOutlet UIView *oceanPosterView;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStars;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar1;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar2;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar3;
@property (strong, nonatomic) IBOutlet UIView *skyPosterView;
@property (strong, nonatomic) IBOutlet UIImageView *skyStars;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar1;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar2;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar3;
@property (strong, nonatomic) IBOutlet UIView *forrestPosterView;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStars;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStar1;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStar2;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStar3;



@property (strong, nonatomic) IBOutlet UIView *oceanPosterViewx;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStarsx;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar1x;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar2x;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar3x;
@property (strong, nonatomic) IBOutlet UIView *skyPosterViewx;
@property (strong, nonatomic) IBOutlet UIImageView *skyStarsx;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar1x;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar2x;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar3x;





@property (strong, nonatomic) IBOutlet UIView *topBar;
@property (strong, nonatomic) IBOutlet UIImageView *backgroundImage;
@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;
@property (strong, nonatomic) IBOutlet UIImageView *poster1;
@property (strong, nonatomic) IBOutlet UIImageView *poster2;
@property (strong, nonatomic) IBOutlet UIImageView *poster3;
@property (strong, nonatomic) IBOutlet UIImageView *poster4;
@property (strong, nonatomic) IBOutlet UIImageView *poster5;

@property (strong, nonatomic) IBOutlet UIScrollView *mainScrollView;
@property (strong, nonatomic) IBOutlet UIView *scrollContentView;
@property (strong, nonatomic) IBOutlet UIButton *btnLeft;
@property (strong, nonatomic) IBOutlet UIButton *btnRight;

@property (strong, nonatomic) GameStartViewController *gameStartViewController;


@property (strong, nonatomic) RewardViewController *rewardViewController;


- (IBAction)oceanTapped:(id)sender;
- (IBAction)skyTapped:(id)sender;
- (IBAction)forrestTapped:(id)sender;
- (IBAction)oceanXTapped:(id)sender;
- (IBAction)skyXTapped:(id)sender;

- (IBAction)starTapped:(id)sender;
- (IBAction)leftTapped:(id)sender;
- (IBAction)rightTapped:(id)sender;
- (IBAction)backTapped:(id)sender;

- (IBAction)rewardTapped:(id)sender;


//- (IBAction)smartTapped:(id)sender;

- (IBAction)speakerTapped:(id)sender;



- (void) stopMainBGM;

- (void) goBack;

@end


