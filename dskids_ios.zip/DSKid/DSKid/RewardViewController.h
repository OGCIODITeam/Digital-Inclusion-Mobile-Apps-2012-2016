//
//  RewardViewController.h
//  DSKid
//
//  Created by Piu on 7/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>



@protocol RewardViewControllerDelegate <NSObject>


- (IBAction)speakerTapped:(id)sender;

- (void) stopMainBGM;

- (void) goBack;

- (void) resumeMainBGM;

@end


@interface RewardViewController : UIViewController{
    id <RewardViewControllerDelegate> delegate;
}

@property (strong, nonatomic)  id <RewardViewControllerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;

@property (strong, nonatomic) IBOutlet UIView *topBar;


@property (strong, nonatomic) NSString *language;

@property (strong, nonatomic) IBOutlet UIView *rewardPanel;
@property (strong, nonatomic) IBOutlet UILabel *rewardCateory;

@property (strong, nonatomic) IBOutlet UIButton *reward1;
@property (strong, nonatomic) IBOutlet UIButton *reward2;
@property (strong, nonatomic) IBOutlet UIButton *reward3;
@property (strong, nonatomic) IBOutlet UIButton *reward4;
@property (strong, nonatomic) IBOutlet UIButton *reward5;
@property (strong, nonatomic) IBOutlet UIButton *reward6;
@property (strong, nonatomic) IBOutlet UIButton *reward7;
@property (strong, nonatomic) IBOutlet UIButton *reward8;
@property (strong, nonatomic) IBOutlet UIButton *reward9;
@property (strong, nonatomic) IBOutlet UIButton *reward10;
@property (strong, nonatomic) IBOutlet UIButton *reward11;
@property (strong, nonatomic) IBOutlet UIButton *reward12;

@property (strong, nonatomic) IBOutlet UIView *rewardInfo;
@property (strong, nonatomic) IBOutlet UIImageView *rewardInfoImage;
@property (strong, nonatomic) IBOutlet UILabel *rewardName;
@property (strong, nonatomic) IBOutlet UITextView *rewardDesc;

@property (strong, nonatomic) NSMutableArray *rewardButtonArray;
@property (nonatomic) int currentPage;

@property (strong, nonatomic) AVAudioPlayer *voiceOver;


- (IBAction)rewardTapped:(id)sender;

- (IBAction)catLeftTapped:(id)sender;
- (IBAction)catRightTapped:(id)sender;
- (IBAction)pageLeftTapped:(id)sender;
- (IBAction)pageRightTapped:(id)sender;


- (IBAction)speakerTapped:(id)sender;
- (IBAction)backTapped:(id)sender;
- (IBAction)homeTapped:(id)sender;


@end
