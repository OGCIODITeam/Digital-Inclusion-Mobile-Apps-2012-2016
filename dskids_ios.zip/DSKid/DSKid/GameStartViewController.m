//
//  GameStartViewController.m
//  DSKid
//
//  Created by Piu on 20/1/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import "GameStartViewController.h"

@interface GameStartViewController ()

@end

@implementation GameStartViewController

@synthesize language,topBarImageView,delegate,currentGame,currentLevel;
@synthesize oceanGameViewController,skyGameViewController,forrestGameViewController;

@synthesize btnStart,btnTutorial,topBar,tutorialView,tutorialCaption,tutorialImageView,currentTutorialPage,tutorialPageNo,healthGameViewController;

@synthesize voiceOver;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
 
    [delegate stopMainBGM];
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];
        
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:@"game_header_s1_p1.png"]];
        
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:@"game_header_s0_p1.png"]];
        
    }
    
    [btnStart setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@start.png",language]] forState:UIControlStateNormal];

      [btnTutorial setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@tutorial.png",language]] forState:UIControlStateNormal];
    
    
    [btnTutorial setTransform:CGAffineTransformMakeScale(0.2, 0.2)];
    btnTutorial.alpha=0;
    
    [btnStart setTransform:CGAffineTransformMakeScale(0.2, 0.2)];
    btnStart.alpha=0;

    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [btnTutorial setTransform:CGAffineTransformMakeScale(1, 1)];
        btnTutorial.alpha=1;
        
        [btnStart setTransform:CGAffineTransformMakeScale(1, 1)];
        btnStart.alpha=1;
        
        
    }
                     completion:^(BOOL finished){

                     }];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)speakerTapped:(id)sender {
    

    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:@"game_header_s0_p1.png"]];

    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:@"game_header_s1_p1.png"]];
        
    }


    [delegate speakerTapped:nil];

    
}

- (IBAction)backTapped:(id)sender {

    [voiceOver stop];
    [delegate resumeMainBGM];

    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        self.view.alpha=0;
    }
                     completion:^(BOOL finished){
                         [self.view removeFromSuperview];
                     }];

}

- (IBAction)homeTapped:(id)sender {
    [voiceOver stop];

    [delegate goBack];
}

- (IBAction)startTapped:(id)sender {
    [voiceOver stop];

    [delegate stopMainBGM];

    if([currentGame isEqualToString:@"game1_s1"]){
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        oceanGameViewController = [[OceanGameViewController alloc] initWithNibName:@"OceanGameViewController" bundle:nil];
        }
        else{
            oceanGameViewController = [[OceanGameViewController alloc] initWithNibName:@"OceanGameViewControlleriPhone" bundle:nil];

        }
        oceanGameViewController.delegate=self;
        oceanGameViewController.currentLevel=currentLevel;
        
        oceanGameViewController.view.frame = self.view.frame;
        [self.view addSubview:oceanGameViewController.view];
        
        [oceanGameViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        oceanGameViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [oceanGameViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            oceanGameViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                         }];
    }
    
    else if([currentGame isEqualToString:@"game1_s2"]){
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        skyGameViewController = [[SkyGameViewController alloc] initWithNibName:@"SkyGameViewController" bundle:nil];
        }
        else{
            skyGameViewController = [[SkyGameViewController alloc] initWithNibName:@"SkyGameViewControlleriPhone" bundle:nil];
        }
        
        skyGameViewController.delegate=self;
        skyGameViewController.currentLevel=currentLevel;
        
        skyGameViewController.view.frame=self.view.frame;
        [self.view addSubview:skyGameViewController.view];
        
        [skyGameViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        skyGameViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [skyGameViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            skyGameViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];
    }
    
    else if([currentGame isEqualToString:@"game1_s3"]){
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        forrestGameViewController = [[ForrestGameViewController alloc] initWithNibName:@"ForrestGameViewController" bundle:nil];
        }
        else{
            forrestGameViewController = [[ForrestGameViewController alloc] initWithNibName:@"ForrestGameViewControlleriPhone" bundle:nil];

        }
        forrestGameViewController.delegate=self;
        forrestGameViewController.currentLevel=currentLevel;
        
        forrestGameViewController.view.frame = self.view.frame;
        [self.view addSubview:forrestGameViewController.view];
        
        [forrestGameViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        forrestGameViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [forrestGameViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            forrestGameViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];
    }
    else{
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        healthGameViewController = [[HealthGameViewController alloc] initWithNibName:@"HealthGameViewController" bundle:nil];
        }
        else{
            healthGameViewController = [[HealthGameViewController alloc] initWithNibName:@"HealthGameViewControlleriPhone" bundle:nil];
        }
        healthGameViewController.delegate=self;
        healthGameViewController.currentGame=currentGame;
        healthGameViewController.currentLevel=currentLevel;
        
        healthGameViewController.view.frame = self.view.frame;
        [self.view addSubview:healthGameViewController.view];
        
        [healthGameViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        healthGameViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [healthGameViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            healthGameViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];

        
    }
}

- (IBAction)tutorialTapped:(id)sender {
    
    currentTutorialPage=1;
    [tutorialImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@%@_ti%i.png",language,currentGame,currentTutorialPage]]];
    [tutorialCaption setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@%@_ts%i.png",language,currentGame,currentTutorialPage]]];

    
    NSError *error;
    voiceOver = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@%@_ts%i_s.mp3", [[NSBundle mainBundle] resourcePath], language,currentGame,currentTutorialPage]] error:&error];
    voiceOver.delegate=self;

    [voiceOver play];
    
    
    
    [self.view insertSubview:tutorialView belowSubview:topBar];
    tutorialView.frame=self.view.frame;
    
    tutorialView.alpha=0;
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [btnTutorial setTransform:CGAffineTransformMakeScale(0.2, 0.2)];
        btnTutorial.alpha=0;
        
        [btnStart setTransform:CGAffineTransformMakeScale(0.2, 0.2)];
        btnStart.alpha=0;
        
        tutorialView.alpha=1;

    }
                     completion:^(BOOL finished){
                         
                     }];

}

- (void) hideTutorial{
    [voiceOver stop];
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [btnTutorial setTransform:CGAffineTransformMakeScale(1, 1)];
        btnTutorial.alpha=1;
        
        [btnStart setTransform:CGAffineTransformMakeScale(1, 1)];
        btnStart.alpha=1;
        
        tutorialView.alpha=0;
        
    }
                     completion:^(BOOL finished){
                         [tutorialView removeFromSuperview];
                         currentTutorialPage=1;
                     }];
    
}

- (void) changePage{
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [tutorialCaption setTransform:CGAffineTransformMakeTranslation(0, tutorialCaption.frame.size.height)];
        tutorialImageView.alpha=0;
    }
                     completion:^(BOOL finished){
                         [tutorialImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@%@_ti%i.png",language,currentGame,currentTutorialPage]]];
                         [tutorialCaption setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@%@_ts%i.png",language,currentGame,currentTutorialPage]]];

                         
                         [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                             [tutorialCaption setTransform:CGAffineTransformMakeTranslation(0, 0)];
                             tutorialImageView.alpha=1;
                             
                         }
                                          completion:^(BOOL finished){
                                              
                                              NSError *error;
                                              voiceOver = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@%@_ts%i_s.mp3", [[NSBundle mainBundle] resourcePath], language,currentGame,currentTutorialPage]] error:&error];
                                              voiceOver.delegate=self;
                                              [voiceOver play];
                                              
                                          }];
                     }];
    

}

- (IBAction)leftTapped:(id)sender {
    if (currentTutorialPage==1){
        [self hideTutorial];
    }
    else{
        currentTutorialPage--;
        [self changePage];
      
    }
}

- (IBAction)rightTapped:(id)sender {
    if (currentTutorialPage==tutorialPageNo){
        [self hideTutorial];
    }
    else{
        currentTutorialPage++;
        [self changePage];
        
    }

}

- (IBAction)playPauseTapped:(id)sender {
    
    if (tutorialView.alpha==1){
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];
    
    
    NSString *voString;
    if (voiceOver.isPlaying){
        voString = @"0";
        [voiceOver stop];
    }
    else{
        voString = @"1";
        [voiceOver play];
    }
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"game_header_s1_p%@.png",voString]]];
        
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"game_header_s0_p%@.png",voString]]];
        
    }
    }
    else{
        [self tutorialTapped:nil];
    }

}

- (void) goBack{
    [voiceOver stop];

    [self backTapped:nil];
}

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    [self rightTapped:nil];
}

@end
