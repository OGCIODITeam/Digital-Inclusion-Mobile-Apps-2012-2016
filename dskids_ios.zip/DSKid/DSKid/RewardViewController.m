//
//  RewardViewController.m
//  DSKid
//
//  Created by Piu on 7/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import "RewardViewController.h"

@interface RewardViewController ()

@end

@implementation RewardViewController

@synthesize delegate,topBar,topBarImageView,language,rewardPanel,rewardCateory,reward1,reward2,reward3,reward4,reward5,reward6,reward7,reward8,reward9,reward10,reward11,reward12,rewardInfo,rewardInfoImage,rewardName,rewardDesc,rewardButtonArray,currentPage;

@synthesize voiceOver;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    rewardInfo.alpha=0;
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];
    
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@reward_header_s1.png",language]]];
        
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@reward_header_s0.png",language]]];
        
    }

    
    
    currentPage=0;
    
    rewardButtonArray = [[NSMutableArray alloc] initWithObjects:reward1,reward2,reward3,reward4,reward5,reward6,reward7,reward8,reward9,reward10,reward11,reward12, nil];

    [self refreshRewards];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) refreshRewards{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

    
    if ([language isEqualToString:@"TC"]){
        if (currentPage==0 || currentPage==1){
            rewardCateory.text = @"海洋世界";
        }
        else if (currentPage==2 || currentPage==3){
            rewardCateory.text = @"天空之城";
        }
        else if (currentPage==4 || currentPage==5){
            rewardCateory.text = @"森林樂園";
        }
    }
    else if ([language isEqualToString:@"SC"]){
        if (currentPage==0 || currentPage==1){
            rewardCateory.text = @"海洋世界";
        }
        else if (currentPage==2 || currentPage==3){
            rewardCateory.text = @"天空之城";
        }
        else if (currentPage==4 || currentPage==5){
            rewardCateory.text = @"森林乐园";
        }
    }
    else if ([language isEqualToString:@"EN"]){
        if (currentPage==0 || currentPage==1){
            rewardCateory.text = @"Ocean";
        }
        else if (currentPage==2 || currentPage==3){
            rewardCateory.text = @"Sky";
        }
        else if (currentPage==4 || currentPage==5){
            rewardCateory.text = @"Jungle";
        }
    }
    
    
    
    for (int i=0;i<12;i++){
        UIButton *btn = [rewardButtonArray objectAtIndex:i];
        if ([[prefs objectForKey:[NSString stringWithFormat:@"award%i", (12*currentPage) + i + 1]] isEqualToString:@"1"]){
            [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"animal%i.png",(12*currentPage) + i + 1]] forState:UIControlStateNormal];
        }
        else{
            [btn setImage:[UIImage imageNamed:@"reward_q.png"] forState:UIControlStateNormal];
        }
    }
}


- (IBAction)rewardTapped:(id)sender {
    
    UIButton *btn = sender;
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    if ([[prefs objectForKey:[NSString stringWithFormat:@"award%li", (12*currentPage) + btn.tag + 1]] isEqualToString:@"1"]){
        
        [rewardInfoImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"reward%li.png",(12*currentPage) + btn.tag + 1]]];
        
        [rewardDesc setContentOffset:CGPointZero animated:NO];

        
        
        NSString *filePath = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@Award",language] ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:filePath];
        
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        
        rewardName.text = [[[[json objectForKey:@"resources"] objectForKey:@"string"] objectAtIndex:(12*currentPage) + btn.tag] objectForKey:@"#text"];
        
        rewardDesc.text = [[[[json objectForKey:@"resources"] objectForKey:@"string"] objectAtIndex:(12*currentPage) + btn.tag + 72] objectForKey:@"#text"];
        
        
        
        if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){

            NSError *error;
            voiceOver = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%li_%@.mp3", [[NSBundle mainBundle] resourcePath], (12*currentPage) + btn.tag + 1, [language lowercaseString]]] error:&error];
            [voiceOver play];
        }
        
        rewardInfo.alpha=1;
    }
    else{
        rewardInfo.alpha=0;
    }
}

- (IBAction)catLeftTapped:(id)sender {
    if (currentPage==0){
        currentPage=4;
    }
    else if (currentPage==1){
        currentPage=4;
    }
    else if (currentPage==2){
        currentPage=0;
    }
    else if (currentPage==3){
        currentPage=0;
    }
    else if (currentPage==4){
        currentPage=2;
    }
    else if (currentPage==5){
        currentPage=2;
    }
   
    [self refreshRewards];
}

- (IBAction)catRightTapped:(id)sender {
    if (currentPage==0){
        currentPage=2;
    }
    else if (currentPage==1){
        currentPage=2;
    }
    else if (currentPage==2){
        currentPage=4;
    }
    else if (currentPage==3){
        currentPage=4;
    }
    else if (currentPage==4){
        currentPage=0;
    }
    else if (currentPage==5){
        currentPage=0;
    }

    [self refreshRewards];

}

- (IBAction)pageLeftTapped:(id)sender {
    currentPage--;
    if (currentPage==-1){
        currentPage=5;
    }
    [self refreshRewards];
    
}

- (IBAction)pageRightTapped:(id)sender {
    currentPage++;
    if (currentPage==6){
        currentPage=0;
    }
    [self refreshRewards];

}



- (IBAction)backTapped:(id)sender {
    
    [delegate resumeMainBGM];
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        self.view.alpha=0;
    }
                     completion:^(BOOL finished){
                         [self.view removeFromSuperview];
                     }];
    
}

- (IBAction)homeTapped:(id)sender {
    [delegate goBack];
}

- (IBAction)speakerTapped:(id)sender {
    
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@reward_header_s0.png",language]]];
        
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@reward_header_s1.png",language]]];
        
    }
    
    
    [delegate speakerTapped:nil];
    
    
}
@end
