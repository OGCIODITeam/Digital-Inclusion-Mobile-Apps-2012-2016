//
//  SplashViewController.h
//  DSKid
//
//  Created by Piu on 20/1/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashViewController : UIViewController

@end
