    //
//  DraggableImage.m
//  AIACalculator
//
//  Created by Piu on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DraggableImage.h"

@implementation DraggableImage


@synthesize initLocation,inited,imageID,delegate;

CGPoint startLocation;
CGRect frame;



- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event {
	
	if (inited==0){
		initLocation.x=self.frame.origin.x;
		initLocation.y=self.frame.origin.y;
		inited=1;

	}
	
    [delegate itemTouched:self withID:imageID];
    
	// Retrieve the touch point
	CGPoint pt = [[touches anyObject] locationInView:self];
	startLocation = pt;
	[[self superview] bringSubviewToFront:self];
    
    
   
}
- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event {
	
	// Move relative to the original touch point
	CGPoint pt = [[touches anyObject] locationInView:self];
	frame = [self frame];
	frame.origin.x += pt.x - startLocation.x;
	frame.origin.y += pt.y - startLocation.y;
    //frame.size.width = 200;
    //frame.size.height = 200;
	[self setFrame:frame];
    [delegate itemDragged:self withID:imageID withEvent:event];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent*)event {
    NSLog(@"imageoid %i",imageID);
    [delegate itemDragFinish:self withID:imageID];

}

@end
