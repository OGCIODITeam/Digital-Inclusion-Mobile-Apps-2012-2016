//
//  DrumGameViewController.m
//  DSKid
//
//  Created by Piu on 12/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import "DrumGameViewController.h"

@interface DrumGameViewController ()

@end

@implementation DrumGameViewController

@synthesize score,scoreInt,timer;
@synthesize counter,baseDate;
@synthesize count1,count2,count3,drummer,hitDrumAnimationFrame,drumSound,canHitDrum;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    scoreInt=0;
    score.text=@"0";
    canHitDrum=NO;
    
    count1.alpha=0;
    count2.alpha=0;
    drummer.alpha=0;
    
    hitDrumAnimationFrame=1;
    
    
    [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [count3 setTransform:CGAffineTransformMakeScale(3, 3)];
        count3.alpha=0;
    }
                     completion:^(BOOL finished){
                         count2.alpha=1;
                         [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                             [count2 setTransform:CGAffineTransformMakeScale(3, 3)];
                             count2.alpha=0;
                         }
                                          completion:^(BOOL finished){
                                              count1.alpha=1;
                                              [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                                  [count1 setTransform:CGAffineTransformMakeScale(3, 3)];
                                                  count1.alpha=0;
                                              }
                                                               completion:^(BOOL finished){
                                                                   [self countdown];
                                                                   canHitDrum=YES;

                                                               }];

                                          }];

                     }];
    
    
    
    [UIView animateWithDuration:1 delay:2.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        drummer.alpha=1;
    }
                     completion:^(BOOL finished){
                     }];

    
    NSError *err;
    NSString *path = [NSString stringWithFormat:@"%@%@",[[NSBundle mainBundle] resourcePath], @"/drum.mp3"];
    NSURL *filePath = [NSURL fileURLWithPath:path isDirectory:NO];
    drumSound = [[AVAudioPlayer alloc] initWithContentsOfURL:filePath error:&err];
  
}

- (BOOL)canBecomeFirstResponder {
    return YES;
}

- (void)viewDidAppear:(BOOL)animated {
    [self becomeFirstResponder];
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if (motion == UIEventSubtypeMotionShake){
        if (canHitDrum){

            canHitDrum=NO;
            [self hitDrum];
        }
    }
}

- (void) hitDrum{
    hitDrumAnimationFrame++;
    if (hitDrumAnimationFrame==4){
        hitDrumAnimationFrame=1;
        canHitDrum=YES;
        
    }
    
    [drummer setImage:[UIImage imageNamed:[NSString stringWithFormat:@"drum%i.png",hitDrumAnimationFrame]]];

    if (hitDrumAnimationFrame>1){
        [self performSelector:@selector(hitDrum) withObject:nil afterDelay:0.3];
    }
    
    if (hitDrumAnimationFrame==3){
        [drumSound play];
        scoreInt+=10;
        score.text=[NSString stringWithFormat:@"%i",scoreInt];

    }
    
}


- (void) countdown{
    
    NSTimeInterval remainingSec = [baseDate timeIntervalSinceNow];
    if (!counter || remainingSec <= 0) {
        [counter invalidate];
        // getting time from database
        baseDate = [NSDate dateWithTimeIntervalSinceNow:180.0];
        remainingSec = [baseDate timeIntervalSinceNow];
        counter = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self
                                                 selector:@selector(countdown)
                                                 userInfo:nil
                                                  repeats:YES];
    }
    
    NSInteger hours = remainingSec / 3600;
    NSInteger remainder = ((NSInteger)remainingSec)% 3600;
    NSInteger minutes = remainder / 60;
    NSInteger seconds = remainder % 60;
    
    timer.text = [NSString stringWithFormat:@"%2ld:%02ld", (long)minutes, (long)seconds];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)backTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        self.view.alpha=0;
    }
                     completion:^(BOOL finished){
                         [self.view removeFromSuperview];
                     }];
}

@end
