//
//  DraggableImage.h
//  AIACalculator
//
//  Created by Piu on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DraggableImageDelegate <NSObject>

-(void)itemTouched:(id)sender withID:(int)imageID;
- (void) itemDragged:(id)sender withID:(int)imageID withEvent:(UIEvent *) event;
- (void)itemDragFinish:(id)sender withID:(int)imageID;


@end

@interface DraggableImage : UIImageView {
	CGPoint initLocation;
	int inited;
    
    int imageID;
    
    id <DraggableImageDelegate> delegate;

}

@property(nonatomic) CGPoint initLocation;
@property(nonatomic) int inited;
@property(nonatomic) int imageID;

@property(nonatomic)  id <DraggableImageDelegate> delegate;



@end
