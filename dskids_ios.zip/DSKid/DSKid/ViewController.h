//
//  ViewController.h
//  DSKid
//
//  Created by Piu on 3/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "SplashViewController.h"

@interface ViewController : UIViewController

@property (strong,nonatomic) MainViewController *mainViewController;
@property (strong, nonatomic) SplashViewController *splashViewController;


@end

