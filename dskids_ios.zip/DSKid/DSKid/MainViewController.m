//
//  MainViewController.m
//  DSKid
//
//  Created by Piu on 3/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import "MainViewController.h"
#import <Social/Social.h>

@interface MainViewController ()

@end

@implementation MainViewController

@synthesize smartWorldViewController,audioPlayer,topBarImageView;
@synthesize menu1,menu2,menu3,menu4;
@synthesize healthWorldViewController;
@synthesize webContentViewController,nc,serverToken;


@synthesize language;

@synthesize migrationBG1,migrationBG2,migrationBG3,migrationBG4,migrationView,migrationView1,migrationView2,migrationView3,migrationView4,migrationPassword;

@synthesize btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11,btn12,btn13;
@synthesize migrationView2Btn1,migrationView3Btn1;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];
    
    [self setButtonTitle];
    
    NSError *error;

    audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"bmg.mp3"]] error:&error];
    
    audioPlayer.numberOfLoops = -1;

    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [audioPlayer play];
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s1.png",language]]];


    }
    else{
        [audioPlayer stop];
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s0.png",language]]];


    }
    
    [prefs synchronize];
    
    for (int i=0;i<60;i++){
        NSLog(@"award %@ %i", [prefs objectForKey:[NSString stringWithFormat:@"award%i",i+1]], i);
    }

    
    [menu1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn1.png",language]] forState:UIControlStateNormal];
    [menu2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn2.png",language]] forState:UIControlStateNormal];
    [menu3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn3.png",language]] forState:UIControlStateNormal];
    [menu4 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn4.png",language]] forState:UIControlStateNormal];
    
    
    NSLog(@"XXXX %@",[prefs objectForKey:@"healthSetting"]);
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void)setButtonTitle {
    if ([language isEqualToString:@"EN"]){
        [btn1 setTitle:@"data migration" forState:UIControlStateNormal];
        [btn2 setTitle:@"setting" forState:UIControlStateNormal];
        [btn3 setTitle:@"disclaimer" forState:UIControlStateNormal];
        [btn4 setTitle:@"contact us" forState:UIControlStateNormal];
        [btn5 setTitle:@"繁體" forState:UIControlStateNormal];
        [btn6 setTitle:@"簡體" forState:UIControlStateNormal];
        [btn7 setTitle:@"English" forState:UIControlStateNormal];
        [btn8 setTitle:@"enable or disable sound" forState:UIControlStateNormal];
        [btn9 setTitle:@"smartness world" forState:UIControlStateNormal];
        [btn10 setTitle:@"fitness world" forState:UIControlStateNormal];
        [btn11 setTitle:@"my health record" forState:UIControlStateNormal];
        [btn12 setTitle:@"ds stories" forState:UIControlStateNormal];
        [btn13 setTitle:@"facebook share" forState:UIControlStateNormal];
        
        [migrationView2Btn1 setTitle:@"OK" forState:UIControlStateNormal];
        [migrationView3Btn1 setTitle:@"Enter" forState:UIControlStateNormal];


        
    }
    if ([language isEqualToString:@"TC"]){
        [btn1 setTitle:@"資料轉移" forState:UIControlStateNormal];
        [btn2 setTitle:@"設定" forState:UIControlStateNormal];
        [btn3 setTitle:@"條款聲明" forState:UIControlStateNormal];
        [btn4 setTitle:@"聯絡我們" forState:UIControlStateNormal];
        [btn5 setTitle:@"繁體" forState:UIControlStateNormal];
        [btn6 setTitle:@"簡體" forState:UIControlStateNormal];
        [btn7 setTitle:@"English" forState:UIControlStateNormal];
        [btn8 setTitle:@"開啟或關閉聲音" forState:UIControlStateNormal];
        [btn9 setTitle:@"至叻天地" forState:UIControlStateNormal];
        [btn10 setTitle:@"至fit天地" forState:UIControlStateNormal];
        [btn11 setTitle:@"我的健康卡" forState:UIControlStateNormal];
        [btn12 setTitle:@"唐寶寶故事" forState:UIControlStateNormal];
        [btn13 setTitle:@"facebook share" forState:UIControlStateNormal];
        


        [migrationView2Btn1 setTitle:@"明白了" forState:UIControlStateNormal];
        [migrationView3Btn1 setTitle:@"輸入" forState:UIControlStateNormal];

    }
    if ([language isEqualToString:@"SC"]){
        [btn1 setTitle:@"資料轉移" forState:UIControlStateNormal];
        [btn2 setTitle:@"設定" forState:UIControlStateNormal];
        [btn3 setTitle:@"條款聲明" forState:UIControlStateNormal];
        [btn4 setTitle:@"聯絡我們" forState:UIControlStateNormal];
        [btn5 setTitle:@"繁體" forState:UIControlStateNormal];
        [btn6 setTitle:@"簡體" forState:UIControlStateNormal];
        [btn7 setTitle:@"English" forState:UIControlStateNormal];
        [btn8 setTitle:@"開啟或關閉聲音" forState:UIControlStateNormal];
        [btn9 setTitle:@"聰明天地" forState:UIControlStateNormal];
        [btn10 setTitle:@"健康天地" forState:UIControlStateNormal];
        [btn11 setTitle:@"我的健康卡" forState:UIControlStateNormal];
        [btn12 setTitle:@"唐寶寶故事" forState:UIControlStateNormal];
        [btn13 setTitle:@"facebook share" forState:UIControlStateNormal];
        
        
        [migrationView2Btn1 setTitle:@"明白了" forState:UIControlStateNormal];
        [migrationView3Btn1 setTitle:@"輸入" forState:UIControlStateNormal];

    }

}

- (IBAction)speakerTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

    if (audioPlayer.playing){
        [topBarImageView setImage:[UIImage imageNamed:@"home_header_s0.png"]];
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s0.png",language]]];
        [audioPlayer stop];
        [prefs setObject:@"no" forKey:@"sound"];

    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:@"home_header_s1.png"]];
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s1.png",language]]];
        [audioPlayer play];
        [prefs setObject:@"yes" forKey:@"sound"];

    }
    
    [prefs synchronize];

}

- (IBAction)smartTapped:(id)sender {
    
    if (UIAccessibilityIsVoiceOverRunning()){
        if ([language isEqualToString:@"TC"]){
            
            UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"將進入 VoiceOver 不支援頁面"
                                                              message:@"是否繼續?"
                                                             delegate:self
                                                    cancelButtonTitle:@"否"
                                                    otherButtonTitles:@"是", nil];
            myAlert.tag=1;
            
            [myAlert show];
        }
        else if ([language isEqualToString:@"SC"]){
            
            UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"将进入 VoiceOver 不支援页面"
                                                              message:@"是否继续?"
                                                             delegate:self
                                                    cancelButtonTitle:@"否"
                                                    otherButtonTitles:@"是", nil];
            myAlert.tag=1;
            
            [myAlert show];
        }
        else  if ([language isEqualToString:@"EN"]){
            
            UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"This page does not support VoiceOver."
                                                              message:@"To be continue?"
                                                             delegate:self
                                                    cancelButtonTitle:@"No"
                                                    otherButtonTitles:@"Yes", nil];
            myAlert.tag=1;
            
            [myAlert show];
        }
    }
    else{
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            smartWorldViewController = [[SmartWorldViewController alloc] initWithNibName:@"SmartWorldViewController" bundle:nil];
        }
        else{
            smartWorldViewController = [[SmartWorldViewController alloc] initWithNibName:@"SmartWorldViewControlleriPhone" bundle:nil];
        }
        smartWorldViewController.delegate=self;
        
        smartWorldViewController.view.frame = self.view.frame;
        
        [self.view addSubview:smartWorldViewController.view];
        
        [smartWorldViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        smartWorldViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [smartWorldViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            smartWorldViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];

        
    }
}

- (IBAction)healthTapped:(id)sender {
    
    if (UIAccessibilityIsVoiceOverRunning()){

        if ([language isEqualToString:@"TC"]){
            
            UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"將進入 VoiceOver 不支援頁面"
                                                              message:@"是否繼續?"
                                                             delegate:self
                                                    cancelButtonTitle:@"否"
                                                    otherButtonTitles:@"是", nil];
            myAlert.tag=2;
            
            [myAlert show];
        }
        else if ([language isEqualToString:@"SC"]){
            
            UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"将进入 VoiceOver 不支援页面"
                                                              message:@"是否继续?"
                                                             delegate:self
                                                    cancelButtonTitle:@"否"
                                                    otherButtonTitles:@"是", nil];
            myAlert.tag=2;
            
            [myAlert show];
        }
        else  if ([language isEqualToString:@"EN"]){
            
            UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"This page does not support VoiceOver."
                                                              message:@"To be continue?"
                                                             delegate:self
                                                    cancelButtonTitle:@"No"
                                                    otherButtonTitles:@"Yes", nil];
            myAlert.tag=2;
            
            [myAlert show];
        }
    }
    else{
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            healthWorldViewController = [[HealthWorldViewController alloc] initWithNibName:@"HealthWorldViewController" bundle:nil];
        }
        else{
            healthWorldViewController = [[HealthWorldViewController alloc] initWithNibName:@"HealthWorldViewControlleriPhone" bundle:nil];
            
        }
        healthWorldViewController.delegate=self;
        
        healthWorldViewController.view.frame = self.view.frame;
        [self.view addSubview:healthWorldViewController.view];
        
        [healthWorldViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        healthWorldViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [healthWorldViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            healthWorldViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];

        
    }


}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1){
    if (alertView.tag==1){
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            smartWorldViewController = [[SmartWorldViewController alloc] initWithNibName:@"SmartWorldViewController" bundle:nil];
        }
        else{
            smartWorldViewController = [[SmartWorldViewController alloc] initWithNibName:@"SmartWorldViewControlleriPhone" bundle:nil];
        }
        smartWorldViewController.delegate=self;
        
        smartWorldViewController.view.frame = self.view.frame;
        
        [self.view addSubview:smartWorldViewController.view];
        
        [smartWorldViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        smartWorldViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [smartWorldViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            smartWorldViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];
        

        
    }
    else{
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            healthWorldViewController = [[HealthWorldViewController alloc] initWithNibName:@"HealthWorldViewController" bundle:nil];
        }
        else{
            healthWorldViewController = [[HealthWorldViewController alloc] initWithNibName:@"HealthWorldViewControlleriPhone" bundle:nil];
            
        }
        healthWorldViewController.delegate=self;
        
        healthWorldViewController.view.frame = self.view.frame;
        [self.view addSubview:healthWorldViewController.view];
        
        [healthWorldViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        healthWorldViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [healthWorldViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            healthWorldViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];

    }
    }
}

- (IBAction)TCTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = @"TC";
    [prefs setObject:language forKey:@"language"];
    [prefs synchronize];
    
    [menu1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn1.png",language]] forState:UIControlStateNormal];
    [menu2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn2.png",language]] forState:UIControlStateNormal];
    [menu3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn3.png",language]] forState:UIControlStateNormal];
    [menu4 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn4.png",language]] forState:UIControlStateNormal];


    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s1.png",language]]];
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s0.png",language]]];
    }
    
    [self setButtonTitle];


}

- (IBAction)SCTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = @"SC";
    [prefs setObject:language forKey:@"language"];
    [prefs synchronize];
    
    [menu1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn1.png",language]] forState:UIControlStateNormal];
    [menu2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn2.png",language]] forState:UIControlStateNormal];
    [menu3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn3.png",language]] forState:UIControlStateNormal];
    [menu4 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn4.png",language]] forState:UIControlStateNormal];
    
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s1.png",language]]];
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s0.png",language]]];
    }
    
    [self setButtonTitle];

}

- (IBAction)ENTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = @"EN";
    [prefs setObject:language forKey:@"language"];
    [prefs synchronize];
    
    [menu1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn1.png",language]] forState:UIControlStateNormal];
    [menu2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn2.png",language]] forState:UIControlStateNormal];
    [menu3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn3.png",language]] forState:UIControlStateNormal];
    [menu4 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_btn4.png",language]] forState:UIControlStateNormal];
    
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s1.png",language]]];
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@home_header_s0.png",language]]];
    }
    
    [self setButtonTitle];

}

- (bool) soundPlaying{
    return audioPlayer.playing;
}

- (void) stopMainBGM{
    [audioPlayer stop];
}

- (void) resumeMainBGM{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [audioPlayer play];
    }
    
}

- (IBAction)migrationTapped:(id)sender {
    
    [self.view addSubview:migrationView];
    migrationView.frame = self.view.frame;
    migrationView.alpha=0;
    
    migrationView1.alpha=1;
    migrationView2.alpha=0;
    migrationView3.alpha=0;
    migrationView4.alpha=0;

    
    [migrationBG1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@Data1.png",language]]];
    [migrationBG2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@Data2.png",language]]];
    [migrationBG3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@Data3.png",language]]];
    [migrationBG4 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@Data4.png",language]]];

    serverToken.text=@"";
    migrationPassword.text=@"";
    
     [migrationView setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [migrationView setTransform:CGAffineTransformMakeScale(1, 1)];
        migrationView.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];
}

- (IBAction)settingsTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *fontSize = [prefs objectForKey:@"fontSize"];
    
    
    NSString *version = [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey];
    NSString *breakTime = [prefs objectForKey:@"breakTime"];
    NSString *soundEffect = [prefs objectForKey:@"soundEffect"];
    NSString *vibrate = [prefs objectForKey:@"vibrate"];


    
    NSString *path = [[NSBundle mainBundle]
                      pathForResource:[NSString stringWithFormat:@"setting_%@",[language lowercaseString]]
                      ofType:@"html"];
    NSURL *nsurl = [NSURL fileURLWithPath:path];
    NSString *theAbsoluteURLString = [nsurl absoluteString];
    
    NSString *queryString = [NSString stringWithFormat:@"?font=%@&version=%@&break=%@&sound=%@&vibrate=%@",fontSize,version,breakTime,soundEffect,vibrate];
    NSString *URL = [theAbsoluteURLString stringByAppendingString: queryString];

    
 
    
    webContentViewController = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
    webContentViewController.URL = URL;
    webContentViewController.delegate=self;
    
    nc = [[UINavigationController alloc] initWithRootViewController:webContentViewController];
    nc.navigationBarHidden=YES;
    [self.view addSubview:nc.view];
    nc.view.frame = self.view.frame;
    
    nc.view.alpha=0;
    [nc.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    nc.view.alpha=0;
    
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [nc.view setTransform:CGAffineTransformMakeScale(1, 1)];
        nc.view.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];

}

- (IBAction)TandCTapped:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.hk-dsa.org.hk/disclaimer/"]];

}

- (IBAction)contactTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *fontSize = [prefs objectForKey:@"fontSize"];
    
    
    
    NSString *path = [[NSBundle mainBundle]
                      pathForResource:[NSString stringWithFormat:@"contact_%@",[language lowercaseString]]
                      ofType:@"html"];
    NSURL *nsurl = [NSURL fileURLWithPath:path];
    NSString *theAbsoluteURLString = [nsurl absoluteString];
    NSString *queryString = [NSString stringWithFormat:@"?font=%@",fontSize];
    NSString *URL = [theAbsoluteURLString stringByAppendingString: queryString];
    
    webContentViewController = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
    webContentViewController.URL = URL;
    webContentViewController.delegate=self;
    
    nc = [[UINavigationController alloc] initWithRootViewController:webContentViewController];
    nc.navigationBarHidden=YES;
    [self.view addSubview:nc.view];
    nc.view.frame = self.view.frame;
    
    nc.view.alpha=0;
    [nc.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    nc.view.alpha=0;
    
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [nc.view setTransform:CGAffineTransformMakeScale(1, 1)];
        nc.view.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];

}

- (IBAction)cardTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *fontSize = [prefs objectForKey:@"fontSize"];
    
    
    NSString *path = [[NSBundle mainBundle]
                      pathForResource:[NSString stringWithFormat:@"health_%@",[language lowercaseString]]
                      ofType:@"html"];
    NSURL *nsurl = [NSURL fileURLWithPath:path];
    NSString *theAbsoluteURLString = [nsurl absoluteString];
    NSString *queryString = [NSString stringWithFormat:@"?font=%@",fontSize];
    NSString *URL = [theAbsoluteURLString stringByAppendingString: queryString];

    
    
    webContentViewController = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
    webContentViewController.URL = URL;
    webContentViewController.delegate=self;

    
    nc = [[UINavigationController alloc] initWithRootViewController:webContentViewController];
    nc.navigationBarHidden=YES;
    [self.view addSubview:nc.view];
    nc.view.frame = self.view.frame;
    
    nc.view.alpha=0;
    [nc.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    nc.view.alpha=0;
    
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [nc.view setTransform:CGAffineTransformMakeScale(1, 1)];
        nc.view.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];
}

- (IBAction)storyTapped:(id)sender {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *fontSize = [prefs objectForKey:@"fontSize"];
    
    
    NSString *path = [[NSBundle mainBundle]
                      pathForResource:[NSString stringWithFormat:@"story_%@",[language lowercaseString]]
                      ofType:@"html"];
    NSURL *nsurl = [NSURL fileURLWithPath:path];
    NSString *theAbsoluteURLString = [nsurl absoluteString];
    NSString *queryString = [NSString stringWithFormat:@"?font=%@",fontSize];
    NSString *URL = [theAbsoluteURLString stringByAppendingString: queryString];

    
    webContentViewController = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
    webContentViewController.URL = URL;
    webContentViewController.delegate=self;

    
    nc = [[UINavigationController alloc] initWithRootViewController:webContentViewController];
    nc.navigationBarHidden=YES;
    [self.view addSubview:nc.view];
    nc.view.frame = self.view.frame;
    
    nc.view.alpha=0;
    [nc.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    nc.view.alpha=0;
    
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [nc.view setTransform:CGAffineTransformMakeScale(1, 1)];
        nc.view.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];
}

- (IBAction)FBTapped:(id)sender {
    /*SLComposeViewController *fbVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    if ([language isEqualToString:@"TC"]) {
        [fbVC setInitialText:@"誠意推介：一個除了唐氏綜合症朋友外，一般小朋友都會鐘意的遊戲，快些下載及分享！\n\nhttps://itunes.apple.com/hk/app/至fit至叻唐寶寶-smart-fit-ds-kids/id1206876207?mt=8"];

    }
    else if ([language isEqualToString:@"SC"]) {

        [fbVC setInitialText:@"诚意推介：一个除了唐氏综合症朋友外，一般小朋友都会钟意的游戏，快些下载及分享！\n\nhttps://itunes.apple.com/hk/app/至fit至叻唐寶寶-smart-fit-ds-kids/id1206876207?mt=8"];
    }
    else if ([language isEqualToString:@"EN"]) {
        
        [fbVC setInitialText:@"Highly Recommended: an App which is suitable for people with Down Syndrome and others kids. Let's download and share!\n\nhttps://itunes.apple.com/hk/app/至fit至叻唐寶寶-smart-fit-ds-kids/id1206876207?mt=8"];
    }*/
    
    
    SLComposeViewController *fbVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    if ([language isEqualToString:@"TC"]) {
        [fbVC setInitialText:@"誠意推介：一個除了唐氏綜合症朋友外，一般小朋友都會鐘意的遊戲，快些下載及分享！"];
        [fbVC addURL:[NSURL URLWithString:@"https://appsto.re/jp/VG37hb.i"]];
        
    }
    else if ([language isEqualToString:@"SC"]) {
        
        [fbVC setInitialText:@"诚意推介：一个除了唐氏综合症朋友外，一般小朋友都会钟意的游戏，快些下载及分享！\n\nhttps://itunes.apple.com/hk/app/至fit至叻唐寶寶-smart-fit-ds-kids/id1206876207?mt=8"];
        [fbVC addURL:[NSURL URLWithString:@"https://appsto.re/jp/VG37hb.i"]];

    }
    else if ([language isEqualToString:@"EN"]) {
        
        [fbVC setInitialText:@"Highly Recommended: an App which is suitable for people with Down Syndrome and others kids. Let's download and share!"];
        [fbVC addURL:[NSURL URLWithString:@"https://appsto.re/jp/VG37hb.i"]];

    }
    

    
    [self presentViewController:fbVC animated:YES completion:nil];
}

- (IBAction)migrationBGTapped:(id)sender {
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [migrationView setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        migrationView.alpha=0;
    }
                     completion:^(BOOL finished){
                         
                         [migrationView setTransform:CGAffineTransformMakeScale(1, 1)];

                         [migrationView removeFromSuperview];
                     }];
}

- (IBAction)migration1ATapped:(id)sender {
    
    
    
    
    NSLog(@"check server");

    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

    NSString *animal=@"";
    
    for (int i=0;i<72;i++){
        if ([[prefs objectForKey:[NSString stringWithFormat:@"award%i", i + 1]] isEqualToString:@"1"]){
            animal=[animal stringByAppendingString:@"1"];
        }
        else{
            animal=[animal stringByAppendingString:@"0"];
        }
        if (i<71){
            animal=[animal stringByAppendingString:@","];
        }
    }
    
    NSString *gameStar=@"";
    
    if ([[prefs objectForKey:@"game1_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game1_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game1_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game2_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game2_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game2_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game3_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game3_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game3_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game4_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game4_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game4_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game5_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game5_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game5_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game6_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game6_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game6_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game7_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game7_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game7_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }

    if ([[prefs objectForKey:@"game8_1"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game8_2"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1,"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0,"];
    }
    
    if ([[prefs objectForKey:@"game8_3"] isEqualToString:@"1"]){
        gameStar=[gameStar stringByAppendingString:@"1"];
    }
    else{
        gameStar=[gameStar stringByAppendingString:@"0"];
    }




    NSString *URL = [NSString stringWithFormat:@"http://pro-grammer.com/p/HKDSA/web/miup?gameStar=%@&animal=%@&healthSetting=%@&healthRecord=%@",gameStar,animal,[prefs objectForKey:@"healthSetting"],[prefs objectForKey:@"healthRecord"]];

    

    
    NSLog(URL);
    
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:URL]];
    
    [request setHTTPMethod:@"GET"];
    
    
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response,NSData *data,NSError *connectionError) {
        
        if (data!=nil) {
            
            
            NSError* error;
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
            
            serverToken.text = [dict objectForKey:@"token"];
            
        }
        
        
        else{
            
        }
        
        
        
    }];
    
    

    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        migrationView1.alpha=0;
        migrationView2.alpha=1;

    }
                     completion:^(BOOL finished){
                         
                     }];
}

- (IBAction)migration1BTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        migrationView1.alpha=0;
        migrationView3.alpha=1;
        
    }
                     completion:^(BOOL finished){
                         
                     }];
}

- (IBAction)migration2Tapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        migrationView1.alpha=1;
        migrationView2.alpha=0;
        
    }
                     completion:^(BOOL finished){
                         
                     }];
}

- (IBAction)migration3Tapped:(id)sender {
    
    
    NSString *URL = [NSString stringWithFormat:@"http://pro-grammer.com/p/HKDSA/web/midl?token=%@",migrationPassword.text];
    
    
    
    NSLog(URL);
    
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:URL]];
    
    [request setHTTPMethod:@"GET"];
    
    
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response,NSData *data,NSError *connectionError) {
        
        if (data!=nil) {
            
            NSLog(@"%@",[NSString stringWithFormat:@"%@",data]);

            
            if ([[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] rangeOfString:@"err"].location == NSNotFound){
                
                
                NSError* error;
                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                
                NSLog([NSString stringWithFormat:@"%@",dict]);

                
                NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                
                NSArray *animal = [[dict objectForKey:@"animal"] componentsSeparatedByString:@","];
                
                for(int i=0;i<animal.count;i++){
                    [prefs setObject:[animal objectAtIndex:i] forKey:[NSString stringWithFormat:@"award%i",i+1]];
                }
                
                NSArray *gameStar = [[dict objectForKey:@"gameStar"] componentsSeparatedByString:@","];
                
                if (gameStar.count==24){
                    
                    [prefs setObject:[gameStar objectAtIndex:0] forKey:@"game1_1"];
                    [prefs setObject:[gameStar objectAtIndex:1] forKey:@"game1_2"];
                    [prefs setObject:[gameStar objectAtIndex:2] forKey:@"game1_3"];
                    [prefs setObject:[gameStar objectAtIndex:3] forKey:@"game2_1"];
                    [prefs setObject:[gameStar objectAtIndex:4] forKey:@"game2_2"];
                    [prefs setObject:[gameStar objectAtIndex:5] forKey:@"game2_3"];
                    [prefs setObject:[gameStar objectAtIndex:6] forKey:@"game3_1"];
                    [prefs setObject:[gameStar objectAtIndex:7] forKey:@"game3_2"];
                    [prefs setObject:[gameStar objectAtIndex:8] forKey:@"game3_3"];
                    [prefs setObject:[gameStar objectAtIndex:9] forKey:@"game4_1"];
                    [prefs setObject:[gameStar objectAtIndex:10] forKey:@"game4_2"];
                    [prefs setObject:[gameStar objectAtIndex:11] forKey:@"game4_3"];
                    [prefs setObject:[gameStar objectAtIndex:12] forKey:@"game5_1"];
                    [prefs setObject:[gameStar objectAtIndex:13] forKey:@"game5_2"];
                    [prefs setObject:[gameStar objectAtIndex:14] forKey:@"game5_3"];
                    [prefs setObject:[gameStar objectAtIndex:15] forKey:@"game6_1"];
                    [prefs setObject:[gameStar objectAtIndex:16] forKey:@"game6_2"];
                    [prefs setObject:[gameStar objectAtIndex:17] forKey:@"game6_3"];
                    [prefs setObject:[gameStar objectAtIndex:18] forKey:@"game7_1"];
                    [prefs setObject:[gameStar objectAtIndex:19] forKey:@"game7_2"];
                    [prefs setObject:[gameStar objectAtIndex:20] forKey:@"game7_3"];
                    [prefs setObject:[gameStar objectAtIndex:21] forKey:@"game8_1"];
                    [prefs setObject:[gameStar objectAtIndex:22] forKey:@"game8_2"];
                    [prefs setObject:[gameStar objectAtIndex:23] forKey:@"game8_3"];
                    
                }
                
                
                NSString *healthRecord = [NSString stringWithFormat:@"%@", [dict objectForKey:@"healthRecord"]];
                
                NSString *healthSetting = [NSString stringWithFormat:@"%@", [dict objectForKey:@"healthSetting"]];
                
                healthRecord = [healthRecord stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
                healthSetting = [healthSetting stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];

             
                NSLog(@"record %@", healthRecord);
                NSLog(@"setting %@", healthSetting);

                
                [prefs setObject:healthRecord forKey:@"healthRecord"];
                
                
                
                [prefs setObject:healthSetting forKey:@"healthSetting"];
                
                [prefs synchronize];
                
                
                [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                    migrationView3.alpha=0;
                    migrationView4.alpha=1;
                    
                }
                                 completion:^(BOOL finished){
                                     
                                 }];


            }
            else{
                
                if ([language isEqualToString:@"TC"]){
                    
                    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"轉移失敗"
                                                                      message:@"請檢查密碼是否正確"
                                                                     delegate:nil
                                                            cancelButtonTitle:@"OK"
                                                            otherButtonTitles:nil];

                    [myAlert show];
                }
                else if ([language isEqualToString:@"SC"]){
                    
                    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"转移失败"
                                                                      message:@"请检查密码是否正确"
                                                                     delegate:nil
                                                            cancelButtonTitle:@"OK"
                                                            otherButtonTitles:nil];
                    [myAlert show];
                }
                else  if ([language isEqualToString:@"EN"]){
                    
                    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Migration Failed"
                                                                      message:@"Please check if the entered password is correct"
                                                                     delegate:nil
                                                            cancelButtonTitle:@"OK"
                                                            otherButtonTitles:nil];
                    [myAlert show];
                }

                
            }
            
        }
        
        
        else{
            
        }
        
        
        
    }];
    

    
}





- (IBAction)migration3BGTapped:(id)sender {
    [migrationPassword resignFirstResponder];
}

- (void) closeWebContentView{
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [nc.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        nc.view.alpha=0;
    }
                     completion:^(BOOL finished){
                         
                         [nc.view removeFromSuperview];
                     }];

}


            

@end


