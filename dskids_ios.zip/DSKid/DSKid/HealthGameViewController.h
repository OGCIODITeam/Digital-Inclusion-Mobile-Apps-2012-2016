//
//  HealthGameViewController.h
//  DSKid
//
//  Created by Piu on 7/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@protocol HealthGameViewControllerDelegate <NSObject>

- (void) goBack;
- (IBAction)speakerTapped:(id)sender;

@end


@interface HealthGameViewController : UIViewController{
    id <HealthGameViewControllerDelegate> delegate;
}

@property (strong, nonatomic) id <HealthGameViewControllerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UILabel *score;
@property (strong, nonatomic) IBOutlet UILabel *timer;

@property (strong, nonatomic) IBOutlet UIImageView *BGImage;

@property (strong, nonatomic) IBOutlet UIImageView *count1;
@property (strong, nonatomic) IBOutlet UIImageView *count2;
@property (strong, nonatomic) IBOutlet UIImageView *count3;

@property (strong, nonatomic) IBOutlet UIImageView *sprite;


@property (strong, nonatomic) IBOutlet UIView *topBar;
@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;
@property (strong, nonatomic) NSTimer *counter;
@property (strong, nonatomic) NSDate *baseDate;

@property (strong, nonatomic) IBOutlet UIView *resultView;
@property (strong, nonatomic) IBOutlet UIImageView *resultImageView;
@property (strong, nonatomic) IBOutlet UIImageView *resultStar1;
@property (strong, nonatomic) IBOutlet UIImageView *resultStar2;
@property (strong, nonatomic) IBOutlet UIImageView *resultStar3;
@property (strong, nonatomic) IBOutlet UILabel *resultScore;
@property (strong, nonatomic) IBOutlet UIImageView *resultBGImage;


@property (nonatomic) int currentLevel;
@property (nonatomic, strong) NSString *currentGame;

@property (nonatomic) bool readyToShake;
@property (nonatomic) bool vibrate;
@property (nonatomic) bool playSoundEffect;

@property (strong, nonatomic) AVAudioPlayer *BGM;
@property (strong, nonatomic) AVAudioPlayer *soundEffect1;
@property (strong, nonatomic) AVAudioPlayer *resultMusic;


@property (strong, nonatomic) NSString *language;

@property (nonatomic) int scoreInt;



- (IBAction)backTapped:(id)sender;
- (IBAction)speakerTapped:(id)sender;

- (IBAction)replayTapped:(id)sender;
- (IBAction)nextLevelTapped:(id)sender;
- (IBAction)FBTapped:(id)sender;

@end
