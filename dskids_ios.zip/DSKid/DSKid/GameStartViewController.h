//
//  GameStartViewController.h
//  DSKid
//
//  Created by Piu on 20/1/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


#import "OceanGameViewController.h"
#import "SkyGameViewController.h"
#import "ForrestGameViewController.h"
#import "HealthGameViewController.h"



@protocol GameStartViewControllerDelegate <NSObject>


- (IBAction)speakerTapped:(id)sender;

- (void) stopMainBGM;

- (void) goBack;

- (void) resumeMainBGM;

@end

@interface GameStartViewController : UIViewController<OceanGameViewControllerDelegate,SkyGameViewControllerDelegate,ForrestGameViewControllerDelegate,HealthGameViewControllerDelegate,AVAudioPlayerDelegate>{
    id <GameStartViewControllerDelegate> delegate;
}

@property (strong, nonatomic)  id <GameStartViewControllerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;

@property (strong, nonatomic) NSString *language;

@property (strong, nonatomic) NSString *currentGame;
@property (nonatomic) int currentLevel;
@property (nonatomic) int tutorialPageNo;
@property (nonatomic) int currentTutorialPage;


@property (strong, nonatomic) OceanGameViewController *oceanGameViewController;
@property (strong, nonatomic) SkyGameViewController *skyGameViewController;
@property (strong, nonatomic) ForrestGameViewController *forrestGameViewController;
@property (strong, nonatomic) HealthGameViewController *healthGameViewController;


@property (strong, nonatomic) IBOutlet UIButton *btnStart;
@property (strong, nonatomic) IBOutlet UIButton *btnTutorial;
@property (strong, nonatomic) IBOutlet UIView *tutorialView;
@property (strong, nonatomic) IBOutlet UIImageView *tutorialImageView;
@property (strong, nonatomic) IBOutlet UIImageView *tutorialCaption;
@property (strong, nonatomic) IBOutlet UIView *topBar;


@property (strong, nonatomic) AVAudioPlayer *voiceOver;


- (IBAction)speakerTapped:(id)sender;
- (IBAction)backTapped:(id)sender;
- (IBAction)homeTapped:(id)sender;
- (IBAction)startTapped:(id)sender;
- (IBAction)tutorialTapped:(id)sender;
- (IBAction)leftTapped:(id)sender;
- (IBAction)rightTapped:(id)sender;

- (IBAction)playPauseTapped:(id)sender;



- (void) goBack;

@end
