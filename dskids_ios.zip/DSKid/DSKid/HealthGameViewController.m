//
//  HealthGameViewController.m
//  DSKid
//
//  Created by Piu on 7/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import "HealthGameViewController.h"
#import <Social/Social.h>


@interface HealthGameViewController ()

@end

@implementation HealthGameViewController

@synthesize delegate,score,timer,BGM,BGImage,count1,count2,count3,sprite,topBar,topBarImageView,counter,baseDate,resultView,resultImageView,resultMusic,resultScore,resultStar1,resultStar2,resultStar3,resultBGImage,currentGame,currentLevel,soundEffect1,language,scoreInt,readyToShake,vibrate,playSoundEffect;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    readyToShake=NO;
    
    sprite.alpha=0;

    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];
    NSError *error;
    
    BGM = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"game2.mp3"]] error:&error];
    
    BGM.numberOfLoops = -1;
    
    
    
    soundEffect1 = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.mp3", [[NSBundle mainBundle] resourcePath], currentGame]] error:&error];
    
    
    resultMusic = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"finish.mp3"]] error:&error];
    
    
    if ([[prefs objectForKey:@"vibrate"] isEqualToString:@"1"]){
        vibrate=YES;
    }
    else{
        vibrate=NO;
    }
    
    if ([[prefs objectForKey:@"soundEffect"] isEqualToString:@"1"]){
        playSoundEffect=YES;
    }
    else{
        playSoundEffect=NO;
    }

    
    
    NSString *soundString;
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [BGM play];
        soundString=@"1";
    }
    else{
        [BGM stop];
        soundString=@"0";
    }
    
    
    
    NSString *playString=@"0";
    
    NSString *sectionString;
    if ([currentGame isEqualToString:@"game2_s1"]){
        sectionString=@"1";
    }
    else if ([currentGame isEqualToString:@"game2_s2"]){
        sectionString=@"2";
    }
    else if ([currentGame isEqualToString:@"game2_s3"]){
        sectionString=@"3";
    }
    else if ([currentGame isEqualToString:@"game2_s4"]){
        sectionString=@"4";
    }
    else if ([currentGame isEqualToString:@"game2_s5"]){
        sectionString=@"5";
    }
    
    
    [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@section%@_l%i_s%@_p%@.png",language, sectionString, currentLevel,soundString,playString]]];
    
    
    
    
    [sprite setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_a1.png",currentGame]]];
    [BGImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_bg.png",currentGame]]];
    
    [resultBGImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_bg.png",currentGame]]];
    [count1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_c1.png",currentGame]]];
    [count2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_c2.png",currentGame]]];
    [count3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_c3.png",currentGame]]];


    
    
    
    
    scoreInt=0;
    score.text=@"0";
    
    count1.alpha=0;
    count2.alpha=0;

    [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [count3 setTransform:CGAffineTransformMakeScale(3, 3)];
        count3.alpha=0;
    }
                     completion:^(BOOL finished){
                         count2.alpha=1;
                         [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                             [count2 setTransform:CGAffineTransformMakeScale(3, 3)];
                             count2.alpha=0;
                         }
                                          completion:^(BOOL finished){
                                              count1.alpha=1;
                                              [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                                  [count1 setTransform:CGAffineTransformMakeScale(3, 3)];
                                                  count1.alpha=0;
                                              }
                                                               completion:^(BOOL finished){
                                                                   [self countdown];
                                                                   readyToShake=YES;
                                                                   
                                                               }];
                                              
                                          }];
                         
                     }];
    
    
    [self.view bringSubviewToFront:topBar];
    
    
    [UIView animateWithDuration:1 delay:2.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        sprite.alpha=1;
    }
                     completion:^(BOOL finished){
                     }];
    
    


    
}



- (BOOL)canBecomeFirstResponder {
    return YES;
}

- (void)viewDidAppear:(BOOL)animated {
    [self becomeFirstResponder];
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if (motion == UIEventSubtypeMotionShake){
        if (readyToShake){
            [soundEffect1 stop];
            soundEffect1.currentTime=0;
            
            if (playSoundEffect){
                [soundEffect1 play];
            }
            
            AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
            
            scoreInt+=10;
            score.text=[NSString stringWithFormat:@"%i",scoreInt];
            
            [self performSelector:@selector(animateSprite1) withObject:nil afterDelay:0];

        }
    }
}

- (void) animateSprite1{
    [sprite setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_a2.png",currentGame]]];
    [self performSelector:@selector(animateSprite2) withObject:nil afterDelay:0.4];
}

- (void) animateSprite2{
    [sprite setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_a1.png",currentGame]]];
    
}

- (void) countdown{
    
    
    NSTimeInterval remainingSec = [baseDate timeIntervalSinceNow];
    
    float timeLimit = 0.0;
    if (currentLevel==1){
        timeLimit=30.0;
    }
    else if (currentLevel==2){
        timeLimit=45.0;
    }
    else if (currentLevel==3){
        timeLimit=60.0;
    }

    
    if (!counter) {
        [counter invalidate];
        // getting time from database
        baseDate = [NSDate dateWithTimeIntervalSinceNow:timeLimit];
        remainingSec = [baseDate timeIntervalSinceNow];
        counter = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self
                                                 selector:@selector(countdown)
                                                 userInfo:nil
                                                  repeats:YES];
    }
    
    if ( remainingSec <= 0){
        [BGM stop];
        [counter invalidate];
        counter=nil;
        readyToShake=NO;

        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){

            [resultMusic play];
            
        }
        
        
        resultView.frame=self.view.frame;

        [self.view addSubview:resultView];
        [resultView setTransform:CGAffineTransformMakeTranslation(0, self.view.frame.size.height)];
        
        resultStar1.alpha=0;
        resultStar2.alpha=0;
        resultStar3.alpha=0;
        
        
        [resultStar1 setTransform:CGAffineTransformMakeScale(3, 3)];
        [resultStar2 setTransform:CGAffineTransformMakeScale(3, 3)];
        [resultStar3 setTransform:CGAffineTransformMakeScale(3, 3)];
        
        
        [resultImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game2finish.png",language]]];
        
        if ([language isEqualToString:@"EN"]){
            resultScore.text = [NSString stringWithFormat:@"Score: %i",scoreInt];
        }
        else if ([language isEqualToString:@"TC"]){
            resultScore.text = [NSString stringWithFormat:@"總得分: %i",scoreInt];
        }
        else if ([language isEqualToString:@"SC"]){
            resultScore.text = [NSString stringWithFormat:@"总得分: %i",scoreInt];
        }
        
        
        NSString *sectionString;
        if ([currentGame isEqualToString:@"game2_s1"]){
            sectionString=@"4";
        }
        else if ([currentGame isEqualToString:@"game2_s2"]){
            sectionString=@"5";
        }
        else if ([currentGame isEqualToString:@"game2_s3"]){
            sectionString=@"6";
        }
        else if ([currentGame isEqualToString:@"game2_s4"]){
            sectionString=@"7";
        }
        else if ([currentGame isEqualToString:@"game2_s5"]){
            sectionString=@"8";
        }
        
        [prefs setObject:@"1" forKey:[NSString stringWithFormat:@"game%@_%i", sectionString, currentLevel]];
        
        
        
        [prefs synchronize];
        
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [resultView setTransform:CGAffineTransformMakeTranslation(0, 0)];
            
        }
                         completion:^(BOOL finished){
                             
                             if (currentLevel>=1){
                                 [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                     resultStar1.alpha=1;
                                     [resultStar1 setTransform:CGAffineTransformMakeScale(1, 1)];
                                     
                                 }
                                                  completion:^(BOOL finished){
                                                      
                                                      
                                                  }];
                             }
                             
                             if (currentLevel>=2){
                                 [UIView animateWithDuration:0.4 delay:0.3 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                     resultStar2.alpha=1;
                                     [resultStar2 setTransform:CGAffineTransformMakeScale(1, 1)];
                                     
                                 }
                                                  completion:^(BOOL finished){
                                                      
                                                  }];
                             }
                             
                             if (currentLevel==3){
                                 [UIView animateWithDuration:0.4 delay:0.6 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                     resultStar3.alpha=1;
                                     [resultStar3 setTransform:CGAffineTransformMakeScale(1, 1)];
                                     
                                 }
                                                  completion:^(BOOL finished){
                                                      
                                                      
                                                  }];
                             }
                             
                             [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                 resultStar1.alpha=1;
                                 [resultStar1 setTransform:CGAffineTransformMakeScale(1, 1)];
                                 
                             }
                                              completion:^(BOOL finished){
                                                  
                                                  
                                              }];
                             
                         }];
        
        
        
        
        
    }
    
    else{
        
        NSInteger hours = remainingSec / 3600;
        NSInteger remainder = ((NSInteger)remainingSec)% 3600;
        NSInteger minutes = remainder / 60;
        NSInteger seconds = remainder % 60;
        
        if (seconds<0) {
            seconds=0;
        }
        
        timer.text = [NSString stringWithFormat:@"%2ld:%02ld", (long)minutes, (long)seconds];
        
        
    }

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)speakerTapped:(id)sender {
    
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    NSString *soundString;
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [BGM stop];
        [prefs setObject:@"no" forKey:@"sound"];
        soundString=@"0";
        
    }
    else{
        [BGM play];
        [prefs setObject:@"yes" forKey:@"sound"];
        soundString=@"1";
        
    }
    
    NSString *playString=@"0";
    
    NSString *sectionString;
    if ([currentGame isEqualToString:@"game2_s1"]){
        sectionString=@"1";
    }
    else if ([currentGame isEqualToString:@"game2_s2"]){
        sectionString=@"2";
    }
    else if ([currentGame isEqualToString:@"game2_s3"]){
        sectionString=@"3";
    }
    else if ([currentGame isEqualToString:@"game2_s4"]){
        sectionString=@"4";
    }
    else if ([currentGame isEqualToString:@"game2_s5"]){
        sectionString=@"5";
    }
    
    
    [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@section%@_l%i_s%@_p%@.png",language, sectionString, currentLevel,soundString,playString]]];
    
    
}

- (IBAction)replayTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [resultView setTransform:CGAffineTransformMakeTranslation(0, self.view.frame.size.height)];
        
    }
                     completion:^(BOOL finished){
                         [resultView setTransform:CGAffineTransformMakeTranslation(0, 0)];

                         [resultView removeFromSuperview];
                         
                         
                         
                         NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                         if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
                             [BGM play];
                         }
                         
                         
                         
                         
                         scoreInt=0;
                         score.text=@"0";
                         
                         readyToShake=YES;

                         
                         [self countdown];

                     }];
    
    
}

- (IBAction)nextLevelTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [resultView setTransform:CGAffineTransformMakeTranslation(0, self.view.frame.size.height)];
        
    }
                     completion:^(BOOL finished){
                         
                         if (currentLevel==1){
                             currentLevel=2;
                         }
                         else if (currentLevel==2){
                             currentLevel=3;
                         }
                         else if (currentLevel==3){
                             currentLevel=1;
                         }
                         
                         
                         
                         
                         [resultView setTransform:CGAffineTransformMakeTranslation(0, 0)];

                         
                         
                         [resultView removeFromSuperview];
                         
                         NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                         if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
                             [BGM play];
                         }
                         
                         
                         NSString *soundString;
                         if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
                             [BGM play];
                             soundString=@"1";
                         }
                         else{
                             [BGM stop];
                             soundString=@"0";
                         }
                         
                         NSString *playString=@"0";
                         
                         
                         NSString *sectionString;
                         if ([currentGame isEqualToString:@"game2_s1"]){
                             sectionString=@"1";
                         }
                         else if ([currentGame isEqualToString:@"game2_s2"]){
                             sectionString=@"2";
                         }
                         else if ([currentGame isEqualToString:@"game2_s3"]){
                             sectionString=@"3";
                         }
                         else if ([currentGame isEqualToString:@"game2_s4"]){
                             sectionString=@"4";
                         }
                         else if ([currentGame isEqualToString:@"game2_s5"]){
                             sectionString=@"5";
                         }

                         
                         scoreInt=0;
                         score.text=@"0";
                         readyToShake=YES;
                         
                         
                         
                         [self countdown];

                         
                         
                     }];
}

- (IBAction)FBTapped:(id)sender {
    SLComposeViewController *fbVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    
    if ([language isEqualToString:@"TC"]) {
        [fbVC setInitialText:[NSString stringWithFormat:@"恭喜您！總得分：%i\n大家快些加入挑戰吧！",scoreInt]];
    }
    else if ([language isEqualToString:@"SC"]) {
        
        [fbVC setInitialText:[NSString stringWithFormat:@"恭喜您！总得分：%i\n大家快些加入挑战吧！",scoreInt]];
    }
    else if ([language isEqualToString:@"EN"]) {
        
        [fbVC setInitialText:[NSString stringWithFormat:@"Congratulations! Total Score: %i\nLet's join the game and make challenge together!",scoreInt]];
    }
    
    [fbVC addURL:[NSURL URLWithString:@"https://appsto.re/jp/VG37hb.i"]];
    
    
    
    [self presentViewController:fbVC animated:YES completion:nil];
}

- (IBAction)backTapped:(id)sender {
    
    [BGM stop];
    [counter invalidate];
    counter=nil;
    
    
    
    [delegate goBack];
    
}

@end
