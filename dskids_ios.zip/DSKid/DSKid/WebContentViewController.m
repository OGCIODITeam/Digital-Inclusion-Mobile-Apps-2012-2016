//
//  WebContentViewController.m
//  DSKid
//
//  Created by Piu on 7/2/2017.
//  Copyright © 2017 Piu. All rights reserved.
//

#import "WebContentViewController.h"
#import <Social/Social.h>


@interface WebContentViewController ()

@end

@implementation WebContentViewController
@synthesize webContentView,currentSection,URL,delegate,eventManager,calendarIdentifier;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [webContentView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:URL]]];
    
    
    eventManager = [[EventManager alloc] init];
    
    
    
    [self performSelector:@selector(requestAccessToEvents) withObject:nil afterDelay:0.4];

}


- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    NSLog(request.URL.absoluteString);
    
    
   /*UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"2"
                                                      message:[request.URL.absoluteString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    
    [myAlert show];*/

    
    if ([request.URL.absoluteString rangeOfString:@"app://home"].location!=NSNotFound){
        
        [delegate closeWebContentView];
        
        return NO;
    }
    else if ([request.URL.absoluteString rangeOfString:@"app://back"].location!=NSNotFound){
        [self.navigationController popViewControllerAnimated:YES];

        return NO;
    }
    else if ([request.URL.absoluteString rangeOfString:@"app://web="].location!=NSNotFound){

        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"web="];
        
        if (arr.count>=2){
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[arr objectAtIndex:1]]];

        }
        
        
        return NO;
    }
    else if ([request.URL.absoluteString rangeOfString:@"app://font="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"font="];
        
        if (arr.count>=2){
            NSString *fontSize = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:fontSize forKey:@"fontSize"];
            [prefs synchronize];
        }
        
        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://sound="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"sound="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:value forKey:@"soundEffect"];
            [prefs synchronize];
        }
        
        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://vibrate="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"vibrate="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:value forKey:@"vibrate"];
            [prefs synchronize];
        }
        
        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://break="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"break="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:value forKey:@"breakTime"];
            [prefs synchronize];
        }
        
        
        return NO;
    }
    
    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthService"].location!=NSNotFound){
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *fontSize = [prefs objectForKey:@"fontSize"];
        NSString *language = [prefs objectForKey:@"language"];
        
        NSString *path = [[NSBundle mainBundle]
                          pathForResource:[NSString stringWithFormat:@"health_service_%@",[language lowercaseString]]
                          ofType:@"html"];
        NSURL *nsurl = [NSURL fileURLWithPath:path];
        NSString *theAbsoluteURLString = [nsurl absoluteString];
        NSString *queryString = [NSString stringWithFormat:@"?font=%@",fontSize];
        NSString *URL1 = [theAbsoluteURLString stringByAppendingString: queryString];
        
        
        WebContentViewController *wc = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
        wc.URL = URL1;
        wc.delegate=self;
        
        [self.navigationController pushViewController:wc animated:YES];
        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthGrowth"].location!=NSNotFound){
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *fontSize = [prefs objectForKey:@"fontSize"];
        NSString *language = [prefs objectForKey:@"language"];
        
        NSString *path = [[NSBundle mainBundle]
                          pathForResource:[NSString stringWithFormat:@"health_growth_%@",[language lowercaseString]]
                          ofType:@"html"];
        NSURL *nsurl = [NSURL fileURLWithPath:path];
        NSString *theAbsoluteURLString = [nsurl absoluteString];
        NSString *queryString = [NSString stringWithFormat:@"?font=%@&data=%@&healthRecord=%@",fontSize,[prefs objectForKey:@"healthSetting"],[prefs objectForKey:@"healthRecord"]];
        NSString *URL1 = [theAbsoluteURLString stringByAppendingString: queryString];
        
        
        WebContentViewController *wc = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
        wc.URL = URL1;
        wc.delegate=self;
        
        [self.navigationController pushViewController:wc animated:YES];
        
        return NO;
    }

    else if ([request.URL.absoluteString rangeOfString:@"app://healthSetting"].location!=NSNotFound){
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *fontSize = [prefs objectForKey:@"fontSize"];
        NSString *language = [prefs objectForKey:@"language"];
        
        NSString *path = [[NSBundle mainBundle]
                          pathForResource:[NSString stringWithFormat:@"health_setting_%@",[language lowercaseString]]
                          ofType:@"html"];
        NSURL *nsurl = [NSURL fileURLWithPath:path];
        NSString *theAbsoluteURLString = [nsurl absoluteString];
        NSString *queryString = [NSString stringWithFormat:@"?font=%@&data=%@",fontSize,[prefs objectForKey:@"healthSetting"]];
        NSString *URL1 = [theAbsoluteURLString stringByAppendingString: queryString];

        
        NSLog(@"setting %@",[prefs objectForKey:@"healtSetting"]);
        
        WebContentViewController *wc = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
        wc.URL = URL1;
        wc.delegate=self;
        
        [self.navigationController pushViewController:wc animated:YES];
        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthSave="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"healthSave="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:value forKey:@"healthSetting"];
            [prefs synchronize];
        }
        
        [self.navigationController popViewControllerAnimated:YES];

        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthCal"].location!=NSNotFound){
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *fontSize = [prefs objectForKey:@"fontSize"];
        NSString *language = [prefs objectForKey:@"language"];
        
        NSString *path = [[NSBundle mainBundle]
                          pathForResource:[NSString stringWithFormat:@"health_cal_%@",[language lowercaseString]]
                          ofType:@"html"];
        NSURL *nsurl = [NSURL fileURLWithPath:path];
        NSString *theAbsoluteURLString = [nsurl absoluteString];
        NSString *queryString = [NSString stringWithFormat:@"?font=%@",fontSize];
        NSString *URL1 = [theAbsoluteURLString stringByAppendingString: queryString];
        
                
        WebContentViewController *wc = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
        wc.URL = URL1;
        wc.delegate=self;
        
        [self.navigationController pushViewController:wc animated:YES];
        
        return NO;
    }
    
    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthRecordSave="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"healthRecordSave="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:value forKey:@"healthRecord"];
            [prefs synchronize];
            
            
            
            
            NSString *fontSize = [prefs objectForKey:@"fontSize"];
            NSString *language = [prefs objectForKey:@"language"];
            
            NSString *path = [[NSBundle mainBundle]
                              pathForResource:[NSString stringWithFormat:@"health_growth_record_%@",[language lowercaseString]]
                              ofType:@"html"];
            NSURL *nsurl = [NSURL fileURLWithPath:path];
            NSString *theAbsoluteURLString = [nsurl absoluteString];
            NSString *queryString = [NSString stringWithFormat:@"?font=%@&healthRecord=%@",fontSize,[prefs objectForKey:@"healthRecord"]];
            NSString *URL1 = [theAbsoluteURLString stringByAppendingString: queryString];
            
            
            WebContentViewController *wc = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
            wc.URL = URL1;
            wc.delegate=self;
            
            [self.navigationController pushViewController:wc animated:YES];
            
            
        }
        
        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthRecordUpdate="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"healthRecordUpdate="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:value forKey:@"healthRecord"];
            [prefs synchronize];
            
            
            [self.navigationController popViewControllerAnimated:YES];
        }
        
        
        return NO;
    }

    
    else if ([request.URL.absoluteString rangeOfString:@"app://healthRecord"].location!=NSNotFound){
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *fontSize = [prefs objectForKey:@"fontSize"];
        NSString *language = [prefs objectForKey:@"language"];
        
        NSString *path = [[NSBundle mainBundle]
                          pathForResource:[NSString stringWithFormat:@"health_growth_record_%@",[language lowercaseString]]
                          ofType:@"html"];
        NSURL *nsurl = [NSURL fileURLWithPath:path];
        NSString *theAbsoluteURLString = [nsurl absoluteString];
        NSString *queryString = [NSString stringWithFormat:@"?font=%@&healthRecord=%@",fontSize,[prefs objectForKey:@"healthRecord"]];
        NSString *URL1 = [theAbsoluteURLString stringByAppendingString: queryString];
        
        
        WebContentViewController *wc = [[WebContentViewController alloc] initWithNibName:@"WebContentViewController" bundle:nil];
        wc.URL = URL1;
        wc.delegate=self;
        
        [self.navigationController pushViewController:wc animated:YES];

        
        return NO;
    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://sharestory"].location!=NSNotFound){
        
        

        
        NSString *url = [[NSString alloc] initWithString:request.URL.absoluteString];
        
        NSString *decodedURL = [url stringByRemovingPercentEncoding];
        


        
        
        
        NSArray *arr = [decodedURL componentsSeparatedByString:@"sharestory="];
        
      

        
        if (arr.count>=2){

            //value = [value stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            //value = [value stringByReplacingOccurrencesOfString:@"http//" withString:@"http://"];
            //value = [value stringByReplacingOccurrencesOfString:@"https//" withString:@"https://"];
            
            
            

         
            

            SLComposeViewController *fbVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
            //[fbVC addURL:[NSURL URLWithString:[arr objectAtIndex:1]]];
            [fbVC setInitialText:[arr objectAtIndex:1]];

            [self presentViewController:fbVC animated:YES completion:nil];

        }

    }
    
    else if ([request.URL.absoluteString rangeOfString:@"app://calendarSet="].location!=NSNotFound){
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"calendarSet="];
        
        if (arr.count>=2){
           
            NSString *value = [arr objectAtIndex:1];
            //[self createSystemCalendar];
            
            
            
            // Create a new event object.
            EKEvent *event = [EKEvent eventWithEventStore:eventManager.eventStore];
            
            // Set the event title.
            
            value = [value stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            NSArray *arr = [value componentsSeparatedByString:@"_SPACE_"];
            
            event.title = arr[0];
            event.notes = arr[1];
            
            
            
            
            
            
            
            
            // Set its calendar.
            
            
            event.calendar = [eventManager.eventStore defaultCalendarForNewEvents];
            
            
            
            
            
            
            // Set the start and end dates to the event.
            event.startDate = [NSDate date];
            event.endDate =  [[NSDate date] dateByAddingTimeInterval:60*60];
            

            
            // Specify the recurrence frequency and interval values based on the respective selected option.
            EKRecurrenceFrequency frequency;
            NSInteger interval;
            switch (1) {
                case 1:
                    frequency = EKRecurrenceFrequencyDaily;
                    interval = 1;
                    break;
                case 2:
                    frequency = EKRecurrenceFrequencyDaily;
                    interval = 3;
                case 3:
                    frequency = EKRecurrenceFrequencyWeekly;
                    interval = 1;
                case 4:
                    frequency = EKRecurrenceFrequencyWeekly;
                    interval = 2;
                case 5:
                    frequency = EKRecurrenceFrequencyMonthly;
                    interval = 1;
                case 6:
                    frequency = EKRecurrenceFrequencyMonthly;
                    interval = 6;
                case 7:
                    frequency = EKRecurrenceFrequencyYearly;
                    interval = 1;
                    
                default:
                    interval = 0;
                    frequency = EKRecurrenceFrequencyDaily;
                    break;
            }
            
            
            frequency = EKRecurrenceFrequencyWeekly;
            interval = 0;
            
            
            // Create a rule and assign it to the reminder object if the interval is greater than 0.
            if (interval > 0) {
                //EKRecurrenceEnd *recurrenceEnd = [EKRecurrenceEnd recurrenceEndWithEndDate:event.endDate];
                
                EKRecurrenceEnd *recurrenceEnd = [EKRecurrenceEnd recurrenceEndWithEndDate:[NSDate dateWithTimeIntervalSinceNow:15*24*3600]];
                
                EKRecurrenceRule *rule = [[EKRecurrenceRule alloc] initRecurrenceWithFrequency:frequency interval:interval end:recurrenceEnd];
                event.recurrenceRules = @[rule];
            }
            else{
                event.recurrenceRules = nil;
            }
            
            
            // Save and commit the event.
            NSError *error;
            
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

            NSString *language = [prefs objectForKey:@"language"];
            
            if ([eventManager.eventStore saveEvent:event span:EKSpanFutureEvents commit:YES error:&error]) {
                NSLog(@"Success");
                
                UIAlertView *myAlert;
                
                if ([language isEqualToString:@"EN"]){
                    myAlert = [[UIAlertView alloc] initWithTitle:@"Health Check Reminder Added to Calendar"
                                                         message:[NSString stringWithFormat:@"You may go Calendar of iOS to change the time of '%@' and add reminder.",event.title]
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                               otherButtonTitles:nil];

                    
                }
                else if ([language isEqualToString:@"TC"]){

                    myAlert = [[UIAlertView alloc] initWithTitle:@"已把檢查通知加入日曆"
                                                                  message:[NSString stringWithFormat:@"您可以到iOS系統的日曆調整「%@」項目的時間及加入通知。",event.title]
                                                                 delegate:self
                                                        cancelButtonTitle:@"知道了"
                                                        otherButtonTitles:nil];
                
                }
                else if ([language isEqualToString:@"SC"]){
                    
                    myAlert = [[UIAlertView alloc] initWithTitle:@"已把检查通知加入日历"
                                                         message:[NSString stringWithFormat:@"您可以到iOS系统的日历调整“%@”项目的时间及加入通知。",event.title]
                                                        delegate:self
                                               cancelButtonTitle:@"知道了"
                                               otherButtonTitles:nil];
                    
                }
                
                
                [myAlert show];
                
            }
            else{
                NSLog(@"EE");
                // An error occurred, so log the error description.
                NSLog(@"%@", [error localizedDescription]);
                
                UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                  message:[error localizedDescription]
                                                                 delegate:self
                                                        cancelButtonTitle:@"OK"
                                                        otherButtonTitles:nil];
                
                [myAlert show];

            }


      

        }
        
        
        return NO;
    }
    
    
    else if ([request.URL.absoluteString rangeOfString:@"app://location"].location!=NSNotFound){
        
        NSLog(request.URL.absoluteString);
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        NSString *language = [prefs objectForKey:@"language"];
        
        
        NSArray *arr = [request.URL.absoluteString componentsSeparatedByString:@"location="];
        
        if (arr.count>=2){
            NSString *value = [arr objectAtIndex:1];
            
         
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://maps.apple.com/?q=%@",value]]];
            
            

        }
        
        
        return NO;
    }





    
    return YES;
}




-(void)createCalendar{
    
    // Create a new calendar.
    EKCalendar *calendar = [EKCalendar calendarForEntityType:EKEntityTypeEvent
                                                  eventStore:eventManager.eventStore];
    
    // Set the calendar title.
    calendar.title = @"TEST CAL";
    
    // Find the proper source type value.
    for (int i=0; i<eventManager.eventStore.sources.count; i++) {
        EKSource *source = (EKSource *)[eventManager.eventStore.sources objectAtIndex:i];
        EKSourceType currentSourceType = source.sourceType;
        
        if (currentSourceType == EKSourceTypeLocal) {
            calendar.source = source;
            break;
        }
    }
    
    
    
    
    
    // Save and commit the calendar.
    NSError *error;
    [eventManager.eventStore saveCalendar:calendar commit:YES error:&error];
    
    // If no error occurs then turn the editing mode off, store the new calendar identifier and reload the calendars.
    if (error == nil) {
        NSLog(@"Success");
        
        [eventManager saveCustomCalendarIdentifier:calendar.calendarIdentifier];
        
        NSLog(@"CID %@",calendar.calendarIdentifier);
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        [prefs setObject:calendar.calendarIdentifier forKey:@"calendarID"];
        [prefs synchronize];
        
    }
    else{
        // Display the error description to the debugger.
        NSLog(@"%@", [error localizedDescription]);
    }
}

#pragma mark - Private method implementation

-(void)requestAccessToEvents{
    [eventManager.eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        if (error == nil) {
            // Store the returned granted value.
            eventManager.eventsAccessGranted = granted;
            
            
            /*NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
             
             if ([prefs objectForKey:@"calendarID"]==nil){
             [self createCalendar];
             }*/
            
        }
        else{
            // In case of error, just log its description to the debugger.
            NSLog(@"%@", [error localizedDescription]);
        }
    }];
}



-(void)createSystemCalendar{
    
    [eventManager.eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        NSLog(@"111111");
        if (error == nil) {
            // Store the returned granted value.
            eventManager.eventsAccessGranted = granted;
            
            NSLog(@"CAL");
            
            
            
            EKCalendar *calendar = [EKCalendar calendarForEntityType:EKEntityTypeEvent
                                                          eventStore:eventManager.eventStore];
            
            calendar.title = @"DS Kids";
            
            for (int i=0; i<eventManager.eventStore.sources.count; i++) {
                EKSource *source = (EKSource *)[eventManager.eventStore.sources objectAtIndex:i];
                EKSourceType currentSourceType = source.sourceType;
                
                if (currentSourceType == EKSourceTypeCalDAV && [source.title isEqualToString:@"iCloud"]) {
                    calendar.source = source;
                    break;
                }
            }
            
            if (calendar.source  == nil)
            {
                for (EKSource *source in eventManager.eventStore.sources)
                {
                    if (source.sourceType == EKSourceTypeLocal)
                    {
                        calendar.source = source;
                        break;
                    }
                }
            }
            
            NSLog(@"CID %@",calendar.calendarIdentifier);
            calendarIdentifier = calendar.calendarIdentifier;
            
            NSError *error;
            [eventManager.eventStore saveCalendar:calendar commit:YES error:&error];
            //[eventManager saveCustomCalendarIdentifier:calendar.calendarIdentifier];
            
            
            [self saveSystemEvent];
            
        }
        else{
            // In case of error, just log its description to the debugger.
            NSLog(@"create error %@", [error localizedDescription]);
        }
    }];
    
    
    NSLog(@"222222");
    
}

- (void)saveSystemEvent {
    
    
    
    
    
    // Create a new event object.
    EKEvent *event = [EKEvent eventWithEventStore:eventManager.eventStore];
    
    
    
    
    
    if([eventManager.eventStore respondsToSelector:@selector(requestAccessToEntityType:completion:)]) {
        // >= iOS 6
        
        [eventManager.eventStore requestAccessToEntityType:EKEntityTypeEvent
                                                completion:^(BOOL granted, NSError *error) {
                                                    
                                                    // may return on background thread
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if (granted) {
                                                            // continue
                                                            
                                                            
                                                            
                                                            
                                                            //event.title = eventTitle.text;
                                                            //event.notes = remarks.text;
                                                            
                                                            // Set its calendar.
                                                            event.calendar = [eventManager.eventStore calendarWithIdentifier:calendarIdentifier];
                                                            // event.calendar = [eventManager.eventStore defaultCalendarForNewEvents];
                                                            
                                                            
                                                            // Set the start and end dates to the event.
                                                            event.startDate = [NSDate date];
                                                            event.endDate = [NSDate date];
                                                            
                                                            
                                                            /*
                                                             // Specify the recurrence frequency and interval values based on the respective selected option.
                                                             EKRecurrenceFrequency frequency;
                                                             NSInteger interval;
                                                             switch (self.indexOfSelectedRepeatOption) {
                                                             case 1:
                                                             frequency = EKRecurrenceFrequencyDaily;
                                                             interval = 1;
                                                             break;
                                                             case 2:
                                                             frequency = EKRecurrenceFrequencyDaily;
                                                             interval = 3;
                                                             case 3:
                                                             frequency = EKRecurrenceFrequencyWeekly;
                                                             interval = 1;
                                                             case 4:
                                                             frequency = EKRecurrenceFrequencyWeekly;
                                                             interval = 2;
                                                             case 5:
                                                             frequency = EKRecurrenceFrequencyMonthly;
                                                             interval = 1;
                                                             case 6:
                                                             frequency = EKRecurrenceFrequencyMonthly;
                                                             interval = 6;
                                                             case 7:
                                                             frequency = EKRecurrenceFrequencyYearly;
                                                             interval = 1;
                                                             
                                                             default:
                                                             interval = 0;
                                                             frequency = EKRecurrenceFrequencyDaily;
                                                             break;
                                                             }
                                                             
                                                             // Create a rule and assign it to the reminder object if the interval is greater than 0.
                                                             if (interval > 0) {
                                                             EKRecurrenceEnd *recurrenceEnd = [EKRecurrenceEnd recurrenceEndWithEndDate:event.endDate];
                                                             EKRecurrenceRule *rule = [[EKRecurrenceRule alloc] initRecurrenceWithFrequency:frequency interval:interval end:recurrenceEnd];
                                                             event.recurrenceRules = @[rule];
                                                             }
                                                             else{
                                                             event.recurrenceRules = nil;
                                                             }
                                                             */
                                                            
                                                            event.recurrenceRules = nil;
                                                            
                                                            
                                                            // Save and commit the event.
                                                            NSError *error;
                                                            if ([eventManager.eventStore saveEvent:event span:EKSpanThisEvent  commit:YES error:&error]) {
                                                            }
                                                            else{
                                                                NSLog(@"System Calendar Event add error");
                                                                NSLog(@"%@", [error localizedDescription]);
                                                                
                                                            }
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                        } else {
                                                            // display error
                                                            NSLog(@"ERROR");
                                                        }
                                                    });
                                                }];
    } else {
        // < iOS 6
        
        // continue
    }
    
    
    
    
    
}


- (void) closeWebContentView{
    [delegate closeWebContentView];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
