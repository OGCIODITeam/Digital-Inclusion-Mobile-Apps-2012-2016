function storyLoad(url){
  $("#storyloading").show();
  $("#storyloading").css('top',($(".header").outerHeight()+$(".bar").outerHeight())+'px');
  $.get(url,function(d){
    if(d && d.html){
      console.log(d.html);
      $("#article").html(d.html);
      $("[data-storyload]").click(function(e){
        e.preventDefault();
        storyLoad($(this).attr("data-storyload"));
        return false;
      });
    } else {
      $("#article").html('<div class="internet-error">Error</div>');
    }
    $("#storyloading").hide();
  },'json');
}
function _app(s){
  location.href="app://"+s;
  //console.log("app://"+s);
}
function _request(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
function fontSet(s){
  $(".fontselected").removeClass("fontselected");
  s=""+s;
  if(s.toLowerCase()=="m"){
    $("body").addClass("font-m").removeClass("font-l");
    $(".font2m").addClass("fontselected");
  } else if(s.toLowerCase()=="l"){
    $("body").addClass("font-l").removeClass("font-m");
    $(".font2l").addClass("fontselected");
  } else {
    $("body").removeClass("font-m").removeClass("font-l");
    $(".font2s").addClass("fontselected");
  }
}

fontSet(_request("font"));


$(".app2address").click(function(){
  _app("location="+encodeURIComponent($(this).text().trim().replace(new RegExp("地址:", "g"),"").replace(new RegExp("地址:", "g"),"").replace(new RegExp("Address:", "g"),"").trim()));
});
$(".app2tel").click(function(){
  location.href="tel:"+$(this).text().trim().replace(new RegExp("電話:", "g"),"").replace(new RegExp("电话:", "g"),"").replace(new RegExp("Tel:", "g"),"").trim();
});
$(".app2web").click(function(){
  _app("web="+$(this).text().trim().replace(new RegExp("網頁:", "g"),"").replace(new RegExp("网页:", "g"),"").replace(new RegExp("網址:", "g"),"").replace(new RegExp("网址:", "g"),"").replace(new RegExp("Website:", "g"),"").trim());
});
$(".app2mail").click(function(){
  location.href="mailto:"+$(this).text().trim().replace(new RegExp("電郵地址:", "g"),"").replace(new RegExp("电邮地址:", "g"),"").replace(new RegExp("電郵:", "g"),"").replace(new RegExp("电邮:", "g"),"").replace(new RegExp("Email:", "g"),"").trim();
});
$(".app2back").click(function(){
  _app("back");
});
$(".app2home").click(function(){
  _app("home");
});
$(".font2s").click(function(){
  fontSet("s");
  _app("font=s");
});
$(".font2m").click(function(){
  fontSet("m");
  _app("font=m");
});
$(".font2l").click(function(){
  fontSet("l");
  _app("font=l");
});
