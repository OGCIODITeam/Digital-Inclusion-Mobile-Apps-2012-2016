//
//  OceanGameViewController.h
//  DSKid
//
//  Created by Piu on 4/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@protocol OceanGameViewControllerDelegate <NSObject>

- (void) goBack;
- (IBAction)speakerTapped:(id)sender;

@end

@interface OceanGameViewController : UIViewController{
    id <OceanGameViewControllerDelegate> delegate;
}

@property (strong, nonatomic) id <OceanGameViewControllerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIImageView *imageInBorder;
@property (strong, nonatomic) IBOutlet UIButton *object1;
@property (strong, nonatomic) IBOutlet UIButton *object2;
@property (strong, nonatomic) IBOutlet UIButton *object3;
@property (strong, nonatomic) IBOutlet UIButton *object4;
@property (strong, nonatomic) IBOutlet UIButton *object5;
@property (strong, nonatomic) IBOutlet UIButton *object6;

@property (strong, nonatomic) NSMutableArray *objectList;
@property (strong, nonatomic) NSMutableArray *imagePool;
@property (strong, nonatomic) NSMutableArray *objectOnScreen;
@property (strong, nonatomic) IBOutlet UILabel *score;
@property (strong, nonatomic) IBOutlet UILabel *timer;

@property (strong, nonatomic) IBOutlet UIView *topBar;
@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;
@property (strong, nonatomic) IBOutlet UIView *objectDummyView;
@property (strong, nonatomic) NSTimer *counter;
@property (strong, nonatomic) NSDate *baseDate;
@property (nonatomic) int objectDuration;
@property (nonatomic) int targetIndex;

@property (strong, nonatomic) IBOutlet UIView *resultView;
@property (strong, nonatomic) IBOutlet UIImageView *resultImageView;
@property (strong, nonatomic) IBOutlet UIImageView *resultStar1;
@property (strong, nonatomic) IBOutlet UIImageView *resultStar2;
@property (strong, nonatomic) IBOutlet UIImageView *resultStar3;
@property (strong, nonatomic) IBOutlet UILabel *resultScore;
@property (strong, nonatomic) IBOutlet UIImageView *resultAwardImageView;

@property (nonatomic) CGPoint object1Center;
@property (nonatomic) CGPoint object2Center;
@property (nonatomic) CGPoint object3Center;
@property (nonatomic) CGPoint object4Center;
@property (nonatomic) CGPoint object5Center;
@property (nonatomic) CGPoint object6Center;


@property (nonatomic) int currentLevel;

@property (strong, nonatomic) AVAudioPlayer *BGM;
@property (strong, nonatomic) AVAudioPlayer *soundEffect1;
@property (strong, nonatomic) AVAudioPlayer *resultMusic;

@property (nonatomic) bool playSoundEffect;


@property (strong, nonatomic) NSString *language;

@property (nonatomic) int scoreInt;

@property (nonatomic) bool moveObjects;

- (IBAction)objectTapped:(id)sender;
- (IBAction)backTapped:(id)sender;
- (IBAction)speakerTapped:(id)sender;

- (IBAction)replayTapped:(id)sender;
- (IBAction)nextLevelTapped:(id)sender;
- (IBAction)FBTapped:(id)sender;

@end

