//
//  SmartWorldViewController.h
//  DSKid
//
//  Created by Piu on 4/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OceanGameViewController.h"
#import "SkyGameViewController.h"
#import "DrumGameViewController.h"


#import "GameStartViewController.h"
#import "RewardViewController.h"


@protocol SmartWorldViewControllerDelegate <NSObject>

- (bool) soundPlaying;

- (IBAction)speakerTapped:(id)sender;


- (void) stopMainBGM;
- (void) resumeMainBGM;

@end


@interface SmartWorldViewController : UIViewController<GameStartViewControllerDelegate,RewardViewControllerDelegate>{
    id <SmartWorldViewControllerDelegate> delegate;
}
@property (strong, nonatomic) NSString *language;

@property (strong, nonatomic) id <SmartWorldViewControllerDelegate> delegate;


@property (strong, nonatomic) IBOutlet UIView *oceanPosterView;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStars;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar1;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar2;
@property (strong, nonatomic) IBOutlet UIImageView *oceanStar3;
@property (strong, nonatomic) IBOutlet UIView *skyPosterView;
@property (strong, nonatomic) IBOutlet UIImageView *skyStars;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar1;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar2;
@property (strong, nonatomic) IBOutlet UIImageView *skyStar3;
@property (strong, nonatomic) IBOutlet UIView *forrestPosterView;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStars;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStar1;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStar2;
@property (strong, nonatomic) IBOutlet UIImageView *forrestStar3;
@property (strong, nonatomic) IBOutlet UIView *topBar;
@property (strong, nonatomic) IBOutlet UIImageView *backgroundImage;
@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;
@property (strong, nonatomic) IBOutlet UIImageView *poster1;
@property (strong, nonatomic) IBOutlet UIImageView *poster2;
@property (strong, nonatomic) IBOutlet UIImageView *poster3;


@property (strong, nonatomic) GameStartViewController *gameStartViewController;
@property (strong, nonatomic) RewardViewController *rewardViewController;



@property (strong, nonatomic) OceanGameViewController *oceanGameViewController;
@property (strong, nonatomic) SkyGameViewController *skyGameViewController;
@property (strong, nonatomic) DrumGameViewController *drumGameViewController;

- (IBAction)oceanTapped:(id)sender;
- (IBAction)skyTapped:(id)sender;
- (IBAction)forrestTapped:(id)sender;
- (IBAction)rewardTapped:(id)sender;

- (IBAction)starTapped:(id)sender;
- (IBAction)backTapped:(id)sender;


//- (IBAction)smartTapped:(id)sender;

- (IBAction)speakerTapped:(id)sender;

- (void) goBack;


- (void) stopMainBGM;


@end
