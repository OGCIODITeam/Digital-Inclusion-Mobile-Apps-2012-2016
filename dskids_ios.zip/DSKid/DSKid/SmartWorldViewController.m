//
//  SmartWorldViewController.m
//  DSKid
//
//  Created by Piu on 4/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import "SmartWorldViewController.h"

@interface SmartWorldViewController ()

@end

@implementation SmartWorldViewController
@synthesize oceanPosterView,oceanStar1,oceanStar2,oceanStar3,oceanStars;
@synthesize skyPosterView,skyStar1,skyStar2,skyStar3,skyStars;
@synthesize forrestPosterView,forrestStar1,forrestStar2,forrestStar3,forrestStars;

@synthesize topBar,backgroundImage,topBarImageView;

@synthesize oceanGameViewController,skyGameViewController,drumGameViewController,delegate,rewardViewController;

@synthesize gameStartViewController;

@synthesize language;

@synthesize poster1,poster2,poster3;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];

    
    
    if ([delegate soundPlaying]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_header_s1.png",language]]];
    }
    else{
         [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_header_s0.png",language]]];

    }
    
    
    [poster1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn1.png",language]]];
    [poster2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn2.png",language]]];
    [poster3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn3.png",language]]];
    

    
    oceanStars.alpha=0;
    oceanStar1.alpha=0;
    oceanStar2.alpha=0;
    oceanStar3.alpha=0;
    
    skyStars.alpha=0;
    skyStar1.alpha=0;
    skyStar2.alpha=0;
    skyStar3.alpha=0;
    
    forrestStars.alpha=0;
    forrestStar1.alpha=0;
    forrestStar2.alpha=0;
    forrestStar3.alpha=0;
    
    
    oceanPosterView.alpha=0;
    skyPosterView.alpha=0;
    forrestPosterView.alpha=0;
    
    
    
    
    
    [oceanPosterView setTransform:CGAffineTransformMakeTranslation(-200, -200)];
    [oceanPosterView setTransform:CGAffineTransformMakeScale(0.5, 0.5)];
    [UIView animateWithDuration:1 delay:0.3 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        oceanPosterView.alpha=1;
        [oceanPosterView setTransform:CGAffineTransformMakeTranslation(0, 0)];
        [oceanPosterView setTransform:CGAffineTransformMakeScale(1, 1)];

    }
                     completion:^(BOOL finished){
                         
                     }];
    

    [UIView animateWithDuration:1 delay:0.8 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        oceanStars.alpha=1;
        
        if ([[prefs objectForKey:@"game1_1"] isEqualToString:@"1"]){
            oceanStar1.alpha=1;
        }
        if ([[prefs objectForKey:@"game1_2"] isEqualToString:@"1"]){
            oceanStar2.alpha=1;
        }
        if ([[prefs objectForKey:@"game1_3"] isEqualToString:@"1"]){
            oceanStar3.alpha=1;
        }
        



    }
                     completion:^(BOOL finished){
                         
                     }];

    
    
    [skyPosterView setTransform:CGAffineTransformMakeTranslation(0, 200)];
    [skyPosterView setTransform:CGAffineTransformMakeScale(0.5, 0.5)];
    [UIView animateWithDuration:1 delay:0.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        skyPosterView.alpha=1;
        [skyPosterView setTransform:CGAffineTransformMakeTranslation(0, 0)];
        [skyPosterView setTransform:CGAffineTransformMakeScale(1, 1)];
        
    }
                     completion:^(BOOL finished){
                         
                     }];
    
    
    [UIView animateWithDuration:1 delay:1 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        skyStars.alpha=1;
        
        
        if ([[prefs objectForKey:@"game2_1"] isEqualToString:@"1"]){
            skyStar1.alpha=1;
        }
        if ([[prefs objectForKey:@"game2_2"] isEqualToString:@"1"]){
            skyStar2.alpha=1;
        }
        if ([[prefs objectForKey:@"game2_3"] isEqualToString:@"1"]){
            skyStar3.alpha=1;
        }

        
    }
                     completion:^(BOOL finished){
                         
                     }];

    
    
    [forrestPosterView setTransform:CGAffineTransformMakeTranslation(200, 200)];
    [forrestPosterView setTransform:CGAffineTransformMakeScale(0.5, 0.5)];
    [UIView animateWithDuration:1 delay:0.7 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        forrestPosterView.alpha=1;
        [forrestPosterView setTransform:CGAffineTransformMakeTranslation(0, 0)];
        [forrestPosterView setTransform:CGAffineTransformMakeScale(1, 1)];
        
    }
                     completion:^(BOOL finished){
                         
                     }];


    [UIView animateWithDuration:1 delay:1.2 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        forrestStars.alpha=1;
        
        if ([[prefs objectForKey:@"game3_1"] isEqualToString:@"1"]){
            forrestStar1.alpha=1;
        }
        if ([[prefs objectForKey:@"game3_2"] isEqualToString:@"1"]){
            forrestStar2.alpha=1;
        }
        if ([[prefs objectForKey:@"game3_3"] isEqualToString:@"1"]){
            forrestStar3.alpha=1;
        }

    }
                     completion:^(BOOL finished){
                         
                     }];

    
    
    [topBar setTransform:CGAffineTransformMakeTranslation(0, -topBar.frame.size.height)];
    [UIView animateWithDuration:0.8 delay:1 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [topBar setTransform:CGAffineTransformMakeTranslation(0, 0)];

        
    }
                     completion:^(BOOL finished){
                         
                     }];
    
    
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)oceanTapped:(id)sender {
    [poster1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn1_on.png",language]]];
    [poster2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn2.png",language]]];
    [poster3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn3.png",language]]];


    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        backgroundImage.alpha=0;
        [backgroundImage setTransform:CGAffineTransformMakeScale(1.2, 1.2)];
    }
                     completion:^(BOOL finished){
                         [backgroundImage setImage:[UIImage imageNamed:@"oceanLanding.jpg"]];
                         
                         [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                             backgroundImage.alpha=0.7;
                             [backgroundImage setTransform:CGAffineTransformMakeScale(1, 1)];
                             
                         }
                                          completion:^(BOOL finished){
                                              
                                          }];
                     }];

}

- (IBAction)skyTapped:(id)sender {
    [poster1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn1.png",language]]];
    [poster2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn2_on.png",language]]];
    [poster3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn3.png",language]]];
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        backgroundImage.alpha=0;
        [backgroundImage setTransform:CGAffineTransformMakeScale(1.2, 1.2)];
    }
                     completion:^(BOOL finished){
                         [backgroundImage setImage:[UIImage imageNamed:@"skyLanding.jpg"]];
                         
                         [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                             backgroundImage.alpha=0.7;
                             [backgroundImage setTransform:CGAffineTransformMakeScale(1, 1)];
                             
                         }
                                          completion:^(BOOL finished){
                                              
                                          }];
                     }];
}

- (IBAction)forrestTapped:(id)sender {
    [poster1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn1.png",language]]];
    [poster2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn2.png",language]]];
    [poster3 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_btn3_on.png",language]]];
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        backgroundImage.alpha=0;
        [backgroundImage setTransform:CGAffineTransformMakeScale(1.2, 1.2)];
    }
                     completion:^(BOOL finished){
                         [backgroundImage setImage:[UIImage imageNamed:@"forrestLanding.jpg"]];
                         
                         [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                             backgroundImage.alpha=0.7;
                             [backgroundImage setTransform:CGAffineTransformMakeScale(1, 1)];
                             
                         }
                                          completion:^(BOOL finished){
                                              
                                          }];
                     }];
}

- (IBAction)rewardTapped:(id)sender {
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){

        rewardViewController = [[RewardViewController alloc] initWithNibName:@"RewardViewController" bundle:nil];
    }
    else{
        rewardViewController = [[RewardViewController alloc] initWithNibName:@"RewardViewControlleriPhone" bundle:nil];

    }
    
    rewardViewController.delegate=self;

    [self.view addSubview:rewardViewController.view];
    rewardViewController.view.frame = self.view.frame;
    
    [rewardViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    rewardViewController.view.alpha=0;
    
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [rewardViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
        rewardViewController.view.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];
    

}

- (IBAction)starTapped:(id)sender {
    
    UIButton *btn = sender;
    
    if (btn.tag>=1 && btn.tag<=3){
    /*oceanGameViewController = [[OceanGameViewController alloc] initWithNibName:@"OceanGameViewController" bundle:nil];
    [self.view addSubview:oceanGameViewController.view];
    
    [oceanGameViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
    oceanGameViewController.view.alpha=0;
    
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [oceanGameViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
        oceanGameViewController.view.alpha=1;
    }
                     completion:^(BOOL finished){
                         
                     }];*/
        
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            gameStartViewController = [[GameStartViewController alloc] initWithNibName:@"GameStartViewController" bundle:nil];
        }
        else{
            gameStartViewController = [[GameStartViewController alloc] initWithNibName:@"GameStartViewControlleriPhone" bundle:nil];
            
        }
        gameStartViewController.delegate=self;
        gameStartViewController.currentGame=@"game1_s1";
        gameStartViewController.tutorialPageNo=3;
        gameStartViewController.currentLevel=(int)btn.tag;
        
        
        
        gameStartViewController.view.frame = self.view.frame;
        [self.view addSubview:gameStartViewController.view];
        

        
        [gameStartViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        gameStartViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [gameStartViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            gameStartViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];
        
    }
    
    else if (btn.tag>=4 && btn.tag<=6){
        
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            gameStartViewController = [[GameStartViewController alloc] initWithNibName:@"GameStartViewController" bundle:nil];
        }
        else{
            gameStartViewController = [[GameStartViewController alloc] initWithNibName:@"GameStartViewControlleriPhone" bundle:nil];
            
        }
        
        gameStartViewController.delegate=self;
        gameStartViewController.currentGame=@"game1_s2";
        gameStartViewController.tutorialPageNo=4;
        gameStartViewController.currentLevel=(int)btn.tag-3;
        
        
        gameStartViewController.view.frame = self.view.frame;
        [self.view addSubview:gameStartViewController.view];
        
        
        [gameStartViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        gameStartViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [gameStartViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            gameStartViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];

        
    }
    
    
    else if (btn.tag>=7 && btn.tag<=9){
        
        if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
            
            gameStartViewController = [[GameStartViewController alloc] initWithNibName:@"GameStartViewController" bundle:nil];
        }
        else{
            gameStartViewController = [[GameStartViewController alloc] initWithNibName:@"GameStartViewControlleriPhone" bundle:nil];
            
        }
        gameStartViewController.delegate=self;
        gameStartViewController.currentGame=@"game1_s3";
        gameStartViewController.tutorialPageNo=5;
        gameStartViewController.currentLevel=(int)btn.tag-6;
        
        
        gameStartViewController.view.frame = self.view.frame;
        [self.view addSubview:gameStartViewController.view];
        
        
        [gameStartViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        gameStartViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [gameStartViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            gameStartViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];
        
        
    }
    
    
    /*else if (btn.tag==3){
        
        drumGameViewController = [[DrumGameViewController alloc] initWithNibName:@"DrumGameViewController" bundle:nil];
        [self.view addSubview:drumGameViewController.view];
        
        [drumGameViewController.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        drumGameViewController.view.alpha=0;
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [drumGameViewController.view setTransform:CGAffineTransformMakeScale(1, 1)];
            drumGameViewController.view.alpha=1;
        }
                         completion:^(BOOL finished){
                             
                         }];
    }*/

}

- (IBAction)backTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        self.view.alpha=0;
    }
                     completion:^(BOOL finished){
                         [self.view removeFromSuperview];
                     }];

}

- (IBAction)speakerTapped:(id)sender {
    [delegate speakerTapped:nil];
    
    if ([delegate soundPlaying]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_header_s1.png",language]]];
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_header_s0.png",language]]];
        
    }

}
- (void) stopMainBGM{
    [delegate stopMainBGM];
}

- (void) resumeMainBGM{
    if ([delegate soundPlaying]){
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_header_s1.png",language]]];
    }
    else{
        [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1_header_s0.png",language]]];
        
    }

    [delegate resumeMainBGM];
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];

    
    if ([[prefs objectForKey:@"game1_1"] isEqualToString:@"1"]){
        oceanStar1.alpha=1;
    }
    if ([[prefs objectForKey:@"game1_2"] isEqualToString:@"1"]){
        oceanStar2.alpha=1;
    }
    if ([[prefs objectForKey:@"game1_3"] isEqualToString:@"1"]){
        oceanStar3.alpha=1;
    }
    
    if ([[prefs objectForKey:@"game2_1"] isEqualToString:@"1"]){
        skyStar1.alpha=1;
    }
    if ([[prefs objectForKey:@"game2_2"] isEqualToString:@"1"]){
        skyStar2.alpha=1;
    }
    if ([[prefs objectForKey:@"game2_3"] isEqualToString:@"1"]){
        skyStar3.alpha=1;
    }
    
    if ([[prefs objectForKey:@"game3_1"] isEqualToString:@"1"]){
        forrestStar1.alpha=1;
    }
    if ([[prefs objectForKey:@"game3_2"] isEqualToString:@"1"]){
        forrestStar2.alpha=1;
    }
    if ([[prefs objectForKey:@"game3_3"] isEqualToString:@"1"]){
        forrestStar3.alpha=1;
    }



}

- (void) goBack{
    [delegate resumeMainBGM];
    [self backTapped:nil];
}

@end
