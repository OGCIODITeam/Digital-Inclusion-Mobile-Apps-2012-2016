//
//  OceanGameViewController.m
//  DSKid
//
//  Created by Piu on 4/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import "OceanGameViewController.h"
#import <Social/Social.h>

@interface OceanGameViewController ()

@end

@implementation OceanGameViewController
@synthesize imageInBorder,object1,object2,object3,object4,object5,object6,objectList,objectOnScreen,imagePool,objectDuration,topBar,topBarImageView;
@synthesize score,scoreInt,timer;
@synthesize counter,baseDate,objectDummyView,targetIndex;

@synthesize object1Center,object2Center,object3Center,object4Center,object5Center,object6Center,currentLevel;

@synthesize BGM,soundEffect1,language,delegate,resultMusic;

@synthesize resultView,resultScore,resultStar1,resultStar2,resultStar3,resultImageView,resultAwardImageView,moveObjects;

@synthesize playSoundEffect;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    

    
    scoreInt=0;
    score.text=@"0";
    moveObjects=NO;
    
    
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    language = [prefs objectForKey:@"language"];
    NSError *error;
    
    BGM = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"game1.mp3"]] error:&error];
    
    BGM.numberOfLoops = -1;
    
    
    soundEffect1 = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"score.mp3"]] error:&error];
    
    resultMusic = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"finish.mp3"]] error:&error];
    
    
    if ([[prefs objectForKey:@"soundEffect"] isEqualToString:@"1"]){
        playSoundEffect=YES;
    }
    else{
        playSoundEffect=NO;
    }

    
    
    NSString *soundString;
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [BGM play];
        soundString=@"1";
    }
    else{
        [BGM stop];
        soundString=@"0";
    }
    
    NSString *playString=@"0";


    [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@section1_l%i_s%@_p%@.png",language,currentLevel,soundString,playString]]];
    
    
    
    objectList = [[NSMutableArray alloc] initWithObjects:object1,object2,object3,object4,object5,object6, nil];

    
    imagePool = [[NSMutableArray alloc] init];
    for (int i=1;i<=24;i++){
        [imagePool addObject:[NSString stringWithFormat:@"animal%i",i]];
    }
    
    objectDuration=0;
    
    
    objectOnScreen = [[NSMutableArray alloc] init];

    [self refreshObjects];
    
    [self countdown];
    
    
    if (currentLevel==3){
        moveObjects=YES;

        [self animationLoop:@"1" finished:[NSNumber numberWithInt:1000] context:nil];
    }
}

-(void)animationLoop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
    
    
    if (moveObjects){
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.8];
    // remove:
    //  [UIView setAnimationRepeatCount:1000];
    //  [UIView setAnimationRepeatAutoreverses:YES];
    
    CGFloat x = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.width/10);
    CGFloat y = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.height/2);
    
    CGPoint squarePostion = CGPointMake(object1Center.x + x, object1Center.y + y);
    object1.center = squarePostion;
    
    
    
    x = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.width/1);
    y = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.height/2);
    squarePostion = CGPointMake(object2Center.x + x, object2Center.y + y);
    object2.center = squarePostion;

    x = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.width/1);
    y = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.height/2);
    squarePostion = CGPointMake(object3Center.x + x, object3Center.y + y);
    object3.center = squarePostion;
    
    x = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.width/1);
    y = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.height/2);
    squarePostion = CGPointMake(object4Center.x + x, object4Center.y + y);
    object4.center = squarePostion;
    
    x = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.width/2);
    y = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.height/10);
    squarePostion = CGPointMake(object5Center.x + x, object5Center.y + y);
    object5.center = squarePostion;
    
    x = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.width/2);
    y = (CGFloat) (arc4random() % (int) objectDummyView.frame.size.height/2);
    squarePostion = CGPointMake(object6Center.x + x, object6Center.y + y);
    object6.center = squarePostion;
    
    
    
    // add:
    [UIView setAnimationDelegate:self]; // as suggested by @Carl Veazey in a comment
    [UIView setAnimationDidStopSelector:@selector(animationLoop:finished:context:)];
    
    [UIView commitAnimations];
    }
}


- (void) countdown{

    NSTimeInterval remainingSec = [baseDate timeIntervalSinceNow];
    
    float timeLimit = 0.0;
    if (currentLevel==1){
        timeLimit=60.0;
    }
    else if (currentLevel==2){
        timeLimit=90.0;
    }
    else if (currentLevel==3){
        timeLimit=120.0;
    }

    
    NSLog(@"%f",round(remainingSec));
    
    if (!counter) {
        [counter invalidate];
        // getting time from database
        baseDate = [NSDate dateWithTimeIntervalSinceNow:timeLimit];
        remainingSec = [baseDate timeIntervalSinceNow];
        counter = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self
                                               selector:@selector(countdown)
                                               userInfo:nil
                                                repeats:YES];
    }
    
    if ( remainingSec <= 0){
        objectDuration=0;
        [BGM stop];
        [counter invalidate];
        counter=nil;
        
        
        for (int i = 0; i<objectOnScreen.count; i++){
            UIView *object = [objectOnScreen objectAtIndex:i];
            [object removeFromSuperview];
        }

        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
            [resultMusic play];
        }
        

        resultView.frame=self.view.frame;
        [self.view addSubview:resultView];
        [resultView setTransform:CGAffineTransformMakeTranslation(0, self.view.frame.size.height)];
        
        resultStar1.alpha=0;
        resultStar2.alpha=0;
        resultStar3.alpha=0;
        
        resultAwardImageView.alpha=0;
        
        [resultStar1 setTransform:CGAffineTransformMakeScale(3, 3)];
        [resultStar2 setTransform:CGAffineTransformMakeScale(3, 3)];
        [resultStar3 setTransform:CGAffineTransformMakeScale(3, 3)];
        
        [resultAwardImageView setTransform:CGAffineTransformMakeScale(5, 5)];
        
        [resultImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@game1finish.png",language]]];
        
        if ([language isEqualToString:@"EN"]){
            resultScore.text = [NSString stringWithFormat:@"Score: %i",scoreInt];
        }
        else if ([language isEqualToString:@"TC"]){
            resultScore.text = [NSString stringWithFormat:@"總得分: %i",scoreInt];
        }
        else if ([language isEqualToString:@"SC"]){
            resultScore.text = [NSString stringWithFormat:@"总得分: %i",scoreInt];
        }
        
        
        
        int randomIndex = arc4random() % imagePool.count;
        [resultAwardImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[imagePool objectAtIndex:randomIndex]]]];
        [prefs setObject:@"1" forKey:[NSString stringWithFormat:@"award%i",randomIndex+1]];
        
        
        [prefs setObject:@"1" forKey:[NSString stringWithFormat:@"game1_%i",currentLevel]];
        
        
        
        [prefs synchronize];
        
        
        
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            [resultView setTransform:CGAffineTransformMakeTranslation(0, 0)];

        }
                         completion:^(BOOL finished){
                             
                             if (currentLevel>=1){
                                 [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                     resultStar1.alpha=1;
                                     [resultStar1 setTransform:CGAffineTransformMakeScale(1, 1)];

                                 }
                                                  completion:^(BOOL finished){
                                                      [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                                          resultAwardImageView.alpha=1;
                                                          [resultAwardImageView setTransform:CGAffineTransformMakeScale(1, 1)];
                                                          
                                                      }
                                                                       completion:^(BOOL finished){
                                                                           
                                                                           
                                                                       }];
                                                      
                                                  }];
                             }
                             
                             if (currentLevel>=2){
                                 [UIView animateWithDuration:0.4 delay:0.3 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                     resultStar2.alpha=1;
                                     [resultStar2 setTransform:CGAffineTransformMakeScale(1, 1)];
                                     
                                 }
                                                  completion:^(BOOL finished){
                                                      [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                                          resultAwardImageView.alpha=1;
                                                          [resultAwardImageView setTransform:CGAffineTransformMakeScale(1, 1)];
                                                          
                                                      }
                                                                       completion:^(BOOL finished){
                                                                           
                                                                           
                                                                       }];

                                                      
                                                  }];
                             }
                             
                             if (currentLevel==3){
                                 [UIView animateWithDuration:0.4 delay:0.6 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                     resultStar3.alpha=1;
                                     [resultStar3 setTransform:CGAffineTransformMakeScale(1, 1)];
                                     
                                 }
                                                  completion:^(BOOL finished){
                                                      [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                                          resultAwardImageView.alpha=1;
                                                          [resultAwardImageView setTransform:CGAffineTransformMakeScale(1, 1)];
                                                          
                                                      }
                                                                       completion:^(BOOL finished){
                                                                           
                                                                           
                                                                       }];

                                                      
                                                  }];
                             }
                             
                             [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                 resultStar1.alpha=1;
                                 [resultStar1 setTransform:CGAffineTransformMakeScale(1, 1)];
                                 
                             }
                                              completion:^(BOOL finished){
                                                  
                                                  
                                              }];

                         }];

        
        
        
        for (int i = 0; i<objectOnScreen.count; i++){
            UIView *object = [objectOnScreen objectAtIndex:i];
            [object removeFromSuperview];
            
        }
        [objectOnScreen removeAllObjects];

        
        
    }
    
    else{
    
    NSInteger hours = remainingSec / 3600;
    NSInteger remainder = ((NSInteger)remainingSec)% 3600;
    NSInteger minutes = remainder / 60;
    NSInteger seconds = remainder % 60;
    
    if (seconds<0) {
        seconds=0;
    }
    
    timer.text = [NSString stringWithFormat:@"%2ld:%02ld", (long)minutes, (long)seconds];
    
    
    objectDuration++;
    
    if (objectDuration==10){
        [self refreshObjects];
    }
    }
}

- (void) refreshObjects{
    objectDuration=0;

    
    for (int i = 0; i<objectOnScreen.count; i++){
        UIView *object = [objectOnScreen objectAtIndex:i];
        [object removeFromSuperview];
        
    }
    [objectOnScreen removeAllObjects];
    

    NSArray *arr = [self randomlySelectItemsFrom:imagePool withNumberOfItems:5];
    
    
    
    for (int i=0;i<5;i++){
        UIButton *btn = [objectList objectAtIndex:i];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[arr objectAtIndex:i]] ] forState:UIControlStateNormal];
        [objectOnScreen addObject:btn];
    }
    
    
    targetIndex = arc4random() % objectOnScreen.count;
    
    
    if (currentLevel>=2){
        
        
        
        NSString *imageName = [arr objectAtIndex:targetIndex];

        UIButton *btn = [objectList objectAtIndex:(targetIndex+1)%objectOnScreen.count];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@a.png",imageName]] forState:UIControlStateNormal];

        btn = [objectList objectAtIndex:(targetIndex+2)%objectOnScreen.count];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@b.png",imageName]] forState:UIControlStateNormal];

        
        int indexShift = arc4random() % 2;

        targetIndex =  (targetIndex + indexShift) % objectOnScreen.count;
        
    }

    
    
    //objectOnScreen = [self randomlySelectItemsFrom:objectList withNumberOfItems:5];
    
    for (int i = 0; i<objectOnScreen.count; i++){
        int x = (arc4random() % (int)round(self.view.frame.size.width/objectOnScreen.count - objectDummyView.frame.size.width)) + i*(self.view.frame.size.width/objectOnScreen.count);
        
        
        int y;
        
        if (i<objectOnScreen.count-1){
            y = (arc4random() % (int)round(self.view.frame.size.height - topBar.frame.size.height - objectDummyView.frame.size.height)) + topBar.frame.size.height;
        }
        else{
            y = (arc4random() % (int)round(self.view.frame.size.height - imageInBorder.frame.size.height - imageInBorder.frame.origin.y - objectDummyView.frame.size.height)) + imageInBorder.frame.size.height + imageInBorder.frame.origin.y;
        }
        
        


        

        UIView *object = [objectOnScreen objectAtIndex:i];
        [self.view addSubview:object];
        object.frame = CGRectMake(x, y, objectDummyView.frame.size.width, objectDummyView.frame.size.height);
        
        
        
        
        if (i==0){
            object1Center = object.center;
        }
        else if (i==1){
            object2Center = object.center;
        }
        else if (i==2){
            object3Center = object.center;
        }
        else if (i==3){
            object4Center = object.center;
        }
        else if (i==4){
            object5Center = object.center;
        }
        else if (i==5){
            object6Center = object.center;
        }
        
        
        object.alpha=0;
        [object setTransform:CGAffineTransformMakeScale(0.3, 0.3)];
        
        [UIView animateWithDuration:0.3 delay:i*0.1 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            object.alpha=1;
            [object setTransform:CGAffineTransformMakeScale(1.2, 1.2)];

        }
                         completion:^(BOOL finished){
                             [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                 [object setTransform:CGAffineTransformMakeScale(1, 1)];
                                 
                             }
                                              completion:^(BOOL finished){
                                                  
                                              }];

                         }];
    }
    
    
    
    UIButton *btn = [objectOnScreen objectAtIndex:targetIndex];
    
    UIImage *image = [btn imageForState:UIControlStateNormal];
    [imageInBorder setImage:image];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSMutableArray*) randomlySelectItemsFrom:(NSMutableArray*) itemList withNumberOfItems:(int)numberOfItems{
    NSMutableArray *selectedItems;
    selectedItems = [[NSMutableArray alloc] init];
    
    while (selectedItems.count!=numberOfItems){
        int selectedPosition = (arc4random() % itemList.count) ;
        
        bool found = NO;
        for (int i=0;i<selectedItems.count;i++){
            if ([selectedItems objectAtIndex:i] == [itemList objectAtIndex:selectedPosition]){
                found=YES;
                break;
            }
        }
        if (!found){
            [selectedItems addObject:[itemList objectAtIndex:selectedPosition]];
        }
        
    }
    
    
    return selectedItems;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)objectTapped:(id)sender {
    if (sender == [objectOnScreen objectAtIndex:targetIndex]){
        NSLog(@"HIT");
        
        
        if (playSoundEffect){
            [soundEffect1 play];
        }
        
        [imageInBorder setImage:nil];

        scoreInt+=10;
        score.text=[NSString stringWithFormat:@"%i",scoreInt];
        

        
        UIView *object = [objectOnScreen objectAtIndex:targetIndex];
        
        
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            object.alpha=0;
            [object setTransform:CGAffineTransformMakeScale(0.2, 0.2)];
            
        }
                         completion:^(BOOL finished){
                             [object setTransform:CGAffineTransformMakeScale(1, 1)];
                             [object removeFromSuperview];
                             
                             [self refreshObjects];

                         }];
        
        
    
    }
    
}


- (IBAction)speakerTapped:(id)sender {
    
    
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    NSString *soundString;
    if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
        [BGM stop];
        [prefs setObject:@"no" forKey:@"sound"];
        soundString=@"0";

    }
    else{
        [BGM play];
        [prefs setObject:@"yes" forKey:@"sound"];
        soundString=@"1";

    }
    
    NSString *playString=@"0";
    
    
    [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@section1_l%i_s%@_p%@.png",language,currentLevel,soundString,playString]]];
    
    
}

- (IBAction)replayTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [resultView setTransform:CGAffineTransformMakeTranslation(0, self.view.frame.size.height)];

    }
                     completion:^(BOOL finished){
                         [resultView setTransform:CGAffineTransformMakeTranslation(0, 0)];

                         [resultView removeFromSuperview];

                         
                         
                         NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                        if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
                             [BGM play];
                         }


                         
                         
                         scoreInt=0;
                         score.text=@"0";
                         
                         
                         objectDuration=0;
                         
                         objectOnScreen = [[NSMutableArray alloc] init];
                         
                         [self refreshObjects];
                         
                         [self countdown];
                         
                         
                                             }];
    

}

- (IBAction)nextLevelTapped:(id)sender {
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [resultView setTransform:CGAffineTransformMakeTranslation(0, self.view.frame.size.height)];
        
    }
                     completion:^(BOOL finished){
                         
                         if (currentLevel==1){
                             currentLevel=2;
                         }
                         else if (currentLevel==2){
                             currentLevel=3;
                         }
                         else if (currentLevel==3){
                             currentLevel=1;
                         }
                         
                         
                         
                         
                       
                         [resultView setTransform:CGAffineTransformMakeTranslation(0, 0)];

                         
                         [resultView removeFromSuperview];
                         
                         NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                         if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
                             [BGM play];
                         }

                         
                         NSString *soundString;
                         if ([[prefs objectForKey:@"sound"] isEqualToString:@"yes"]){
                             [BGM play];
                             soundString=@"1";
                         }
                         else{
                             [BGM stop];
                             soundString=@"0";
                         }
                         
                         NSString *playString=@"0";
                         
                         
                         [topBarImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@section1_l%i_s%@_p%@.png",language,currentLevel,soundString,playString]]];
                         
                         scoreInt=0;
                         score.text=@"0";
                         
                         
                         objectDuration=0;
                         
                         objectOnScreen = [[NSMutableArray alloc] init];
                         
                         [self refreshObjects];
                         
                         [self countdown];
                         
                         
                         if (currentLevel==3){
                             moveObjects=YES;
                             [self animationLoop:@"1" finished:[NSNumber numberWithInt:1000] context:nil];
                         }
                         else{
                             moveObjects=NO;
                         }
                         
                         
                         
                     }];
}

- (IBAction)FBTapped:(id)sender {
    //SLComposeViewController *fbVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    SLComposeViewController *fbVC = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];

    if ([language isEqualToString:@"TC"]) {
        [fbVC setInitialText:[NSString stringWithFormat:@"恭喜您！總得分：%i\n大家快些加入挑戰吧！",scoreInt]];
    }
    else if ([language isEqualToString:@"SC"]) {
        
        [fbVC setInitialText:[NSString stringWithFormat:@"恭喜您！总得分：%i\n大家快些加入挑战吧！",scoreInt]];
    }
    else if ([language isEqualToString:@"EN"]) {
        
        [fbVC setInitialText:[NSString stringWithFormat:@"Congratulations! Total Score: %i\nLet's join the game and make challenge together!",scoreInt]];
    }
    
    [fbVC addURL:[NSURL URLWithString:@"https://appsto.re/jp/VG37hb.i"]];

    
    
    [self presentViewController:fbVC animated:YES completion:nil];

    
}

- (IBAction)backTapped:(id)sender {
    
    objectDuration=0;
    [BGM stop];
    [counter invalidate];
    counter=nil;
    

    
    [delegate goBack];
   
    /*
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view setTransform:CGAffineTransformMakeScale(1.5, 1.5)];
        self.view.alpha=0;
    }
                     completion:^(BOOL finished){
                         [self.view removeFromSuperview];
                     }];*/
}
@end
