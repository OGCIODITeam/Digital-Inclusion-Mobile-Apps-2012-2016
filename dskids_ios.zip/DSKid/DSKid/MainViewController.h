//
//  MainViewController.h
//  DSKid
//
//  Created by Piu on 3/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "SmartWorldViewController.h"
#import "HealthWorldViewController.h"
#import "WebContentViewController.h"


@interface MainViewController : UIViewController<SmartWorldViewControllerDelegate,HealthWorldViewControllerDelegate,WebContentViewControllerDelegate,UIAlertViewDelegate>

@property (strong, nonatomic) IBOutlet UIImageView *topBarImageView;

@property (strong, nonatomic) SmartWorldViewController *smartWorldViewController;
@property (strong, nonatomic) HealthWorldViewController *healthWorldViewController;

@property (strong, nonatomic) UINavigationController *nc;
@property (strong, nonatomic) WebContentViewController *webContentViewController;

@property (strong, nonatomic) AVAudioPlayer *audioPlayer;


@property (strong, nonatomic) NSString *language;
@property (strong, nonatomic) IBOutlet UIButton *menu1;
@property (strong, nonatomic) IBOutlet UIButton *menu2;
@property (strong, nonatomic) IBOutlet UIButton *menu3;
@property (strong, nonatomic) IBOutlet UIButton *menu4;
@property (strong, nonatomic) IBOutlet UIView *migrationView;
@property (strong, nonatomic) IBOutlet UIView *migrationView1;
@property (strong, nonatomic) IBOutlet UIImageView *migrationBG1;
@property (strong, nonatomic) IBOutlet UIView *migrationView2;
@property (strong, nonatomic) IBOutlet UIImageView *migrationBG2;
@property (strong, nonatomic) IBOutlet UIView *migrationView3;
@property (strong, nonatomic) IBOutlet UIImageView *migrationBG3;
@property (strong, nonatomic) IBOutlet UIView *migrationView4;
@property (strong, nonatomic) IBOutlet UIImageView *migrationBG4;
@property (strong, nonatomic) IBOutlet UITextField *migrationPassword;
@property (strong, nonatomic) IBOutlet UILabel *serverToken;
@property (strong, nonatomic) IBOutlet UIButton *btn1;
@property (strong, nonatomic) IBOutlet UIButton *btn2;
@property (strong, nonatomic) IBOutlet UIButton *btn3;
@property (strong, nonatomic) IBOutlet UIButton *btn4;
@property (strong, nonatomic) IBOutlet UIButton *btn5;
@property (strong, nonatomic) IBOutlet UIButton *btn6;
@property (strong, nonatomic) IBOutlet UIButton *btn7;
@property (strong, nonatomic) IBOutlet UIButton *btn8;
@property (strong, nonatomic) IBOutlet UIButton *btn9;
@property (strong, nonatomic) IBOutlet UIButton *btn10;
@property (strong, nonatomic) IBOutlet UIButton *btn11;
@property (strong, nonatomic) IBOutlet UIButton *btn12;
@property (strong, nonatomic) IBOutlet UIButton *btn13;
@property (strong, nonatomic) IBOutlet UIButton *migrationView2Btn1;
@property (strong, nonatomic) IBOutlet UIButton *migrationView3Btn1;

- (IBAction)speakerTapped:(id)sender;
- (IBAction)smartTapped:(id)sender;
- (IBAction)healthTapped:(id)sender;


- (IBAction)TCTapped:(id)sender;
- (IBAction)SCTapped:(id)sender;
- (IBAction)ENTapped:(id)sender;

- (bool) soundPlaying;


- (void) stopMainBGM;
- (void) resumeMainBGM;

- (IBAction)migrationTapped:(id)sender;
- (IBAction)settingsTapped:(id)sender;
- (IBAction)TandCTapped:(id)sender;
- (IBAction)contactTapped:(id)sender;
- (IBAction)cardTapped:(id)sender;
- (IBAction)storyTapped:(id)sender;
- (IBAction)FBTapped:(id)sender;

- (IBAction)migrationBGTapped:(id)sender;
- (IBAction)migration1ATapped:(id)sender;
- (IBAction)migration1BTapped:(id)sender;
- (IBAction)migration2Tapped:(id)sender;
- (IBAction)migration3Tapped:(id)sender;
- (IBAction)migration3BGTapped:(id)sender;


- (void) closeWebContentView;
@end
