//
//  AppDelegate.h
//  DSKid
//
//  Created by Piu on 3/10/2016.
//  Copyright © 2016 Piu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

