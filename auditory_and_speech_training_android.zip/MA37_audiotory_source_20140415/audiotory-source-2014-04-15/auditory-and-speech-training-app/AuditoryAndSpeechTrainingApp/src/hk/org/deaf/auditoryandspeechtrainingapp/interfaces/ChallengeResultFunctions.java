package hk.org.deaf.auditoryandspeechtrainingapp.interfaces;

public interface ChallengeResultFunctions {

	public void setResultCompleted(boolean result);

	public void setUserId(int userId);

	public void setId(String id);

}
