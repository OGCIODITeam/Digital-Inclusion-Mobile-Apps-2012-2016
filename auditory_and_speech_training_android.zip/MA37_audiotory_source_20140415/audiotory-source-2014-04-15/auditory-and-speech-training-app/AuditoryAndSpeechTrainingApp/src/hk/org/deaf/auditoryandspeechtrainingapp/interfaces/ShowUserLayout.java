package hk.org.deaf.auditoryandspeechtrainingapp.interfaces;

public interface ShowUserLayout {
	void displayUserLoggedInUis();
	void displayUserNotYetLoggedInUis();
}
