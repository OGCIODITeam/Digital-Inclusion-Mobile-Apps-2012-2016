package hk.com.playmore.syncframework.util;

public interface RunnableArgument {
	public void run(String object);
}
