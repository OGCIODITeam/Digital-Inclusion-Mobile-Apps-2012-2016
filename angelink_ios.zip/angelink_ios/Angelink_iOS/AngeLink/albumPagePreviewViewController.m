//
//  albumPagePreviewViewController.m
//  AngeLink
//
//  Created by kanhan on 22/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "albumPagePreviewViewController.h"
#import "albumPageObj.h"

@interface albumPagePreviewViewController ()
@end

@implementation albumPagePreviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = self.headerTitle;
    header.delegate = self;
    [self.view addSubview:header];
    // Do any additional setup after loading the view.
    self.ic_main.delegate = self;
    self.ic_main.dataSource = self;
    self.ic_main.type = iCarouselTypeLinear;
    self.ic_main.pagingEnabled = YES;
    [self.ic_main setBackgroundColor:[UIColor clearColor]];
    [self setViewUI];
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.6_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.6_2"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"觀看上一頁內容";
    NSString *str2 = @"觀看下一頁內容";
    [aryString addObject:str1];
    [aryString addObject:str2];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_prev.isAccessibilityElement = true;
    self.btn_prev.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_prev.accessibilityLabel = @"上一頁";
    
    self.btn_next.isAccessibilityElement = true;
    self.btn_next.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_next.accessibilityLabel = @"下一頁";
}

-(void) setViewUI{
    self.pageNo = 0;
    fontManager *font = [[fontManager alloc] init];
    self.btn_next.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_next setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_next setTitle:@"下一頁" forState:UIControlStateNormal];
    self.btn_prev.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_prev setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_prev setTitle:@"上一頁" forState:UIControlStateNormal];
    [self.btn_prev setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_next setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}

-(IBAction)pressBtnPrev:(id)sender{
    int check = self.pageNo -1 ;
    if(check <= 0){
        self.pageNo = 0;
    }
    else{
        self.pageNo--;
    }
    self.ic_main.currentItemIndex = self.pageNo;
}

-(IBAction)pressBtnNext:(id)sender{
    int check = self.pageNo +1 ;
    if(check <= [self.aryData count]-1){
        self.pageNo++;
    }
    else{
        self.pageNo = (int)[self.aryData count]-1;
    }
    self.ic_main.currentItemIndex = self.pageNo;
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return [self.aryData count];
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    switch (option)
    {
        case iCarouselOptionWrap:
        {
            return NO;
        }
            //        case iCarouselOptionVisibleItems:
            //        {
            //            return 3;
            //        }
        default:
        {
            return value;
        }
    }
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    //create new view if no view is available for recycling
    view = nil;
    if (view == nil)
    {
        UIView *cView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.ic_main.frame.size.width, self.ic_main.frame.size.height)];
        UIScrollView *sv_view = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.ic_main.frame.size.width, self.ic_main.frame.size.height)];
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, sv_view.frame.size.width, sv_view.frame.size.height)];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        [sv_view addSubview:imageView];
        sv_view.scrollEnabled = YES;
        sv_view.minimumZoomScale=1.0;
        sv_view.maximumZoomScale=4.0;
        [sv_view setContentSize:CGSizeMake(320, 1700)];
        [imageView setUserInteractionEnabled:YES];
        albumPageObj *obj = (albumPageObj*)[self.aryData objectAtIndex:index];
        if(![obj.videoPath isEqualToString:@""]){
            NSString *str = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,obj.videoThumb];
            //            NSURL *url = [NSURL URLWithString:str];
            //            imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
            [imageView setImageWithURL:[NSURL URLWithString:str]];
        }
        else{
            NSString *str = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,obj.displayImage];
            //            NSURL *url = [NSURL URLWithString:str];
            //            imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
            [imageView setImageWithURL:[NSURL URLWithString:str]];
        }
        [cView addSubview:imageView];
        view = cView;
    }
    
    //show placeholder
    //    ((FXImageView *)view).processedImage = [UIImage imageNamed:@"placeholder.png"];
    //
    //    //set image
    //    ((FXImageView *)view).image = _images[index];
    
    return view;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    UIView *view = carousel.currentItemView;
    [view setBackgroundColor:[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0]];
    self.pageNo = index;
}

- (void)carouselDidScroll:(iCarousel *)carousel{
    UIView *view = carousel.currentItemView;
    [view setBackgroundColor:[UIColor clearColor]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
