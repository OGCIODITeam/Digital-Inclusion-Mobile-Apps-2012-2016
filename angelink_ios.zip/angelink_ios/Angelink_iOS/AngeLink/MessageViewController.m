//
//  MessageViewController.m
//  AngeLink
//
//  Created by kanhan on 22/5/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "MessageViewController.h"
#import "UIImage+addition.h"
#import "stickerViewController.h"
#import "AppDelegate.h"
#import "fdActTableViewCell.h"
#import "fdActViewController.h"
#define kDefaultToolbarHeight 60
#define PLACEHOLDER @"有甚麼想説？"
@interface MessageViewController ()

@end

@implementation MessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addSticker:) name:@"addSticker" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(noticeChangeKeyboard:) name:UIKeyboardWillChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTextToSpeech:) name:@"TextToSpeech" object:nil];
    self.navigationController.navigationBar.hidden = NO;
    [self popupAnimation:self.v_popup isOpen:NO];
    [self clearView];
    self.functionToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, [[utilityManager alloc] getScreenSize].size.height - kDefaultToolbarHeight - self.navigationController.navigationBar.frame.size.height, [[utilityManager alloc] getScreenSize].size.width, kDefaultToolbarHeight)];
    [self.functionToolbar setBackgroundColor:[UIColor lightGrayColor]];
    [self.view addSubview:self.functionToolbar];
    
    UIBarButtonItem *sendToFBButton = [[UIBarButtonItem alloc]
                                       initWithTitle:@"發佈"
                                       style:UIBarButtonItemStylePlain
                                       target:self
                                       action:@selector(sendToFB:)];
    sendToFBButton.isAccessibilityElement = true;
    sendToFBButton.accessibilityTraits = UIAccessibilityTraitNone;
    sendToFBButton.accessibilityLabel = @"發佈";
    
    if(self.obj != nil){
        [sendToFBButton setTitle:@"回覆"];
        sendToFBButton.isAccessibilityElement = true;
        sendToFBButton.accessibilityTraits = UIAccessibilityTraitNone;
        sendToFBButton.accessibilityLabel = @"回覆";
    }
    UIBarButtonItem *BackButton = [[UIBarButtonItem alloc]
                                   initWithTitle:@"返回"
                                   style:UIBarButtonItemStylePlain
                                   target:self
                                   action:@selector(BackFunc:)];
    
    
    BackButton.isAccessibilityElement = true;
    BackButton.accessibilityTraits = UIAccessibilityTraitNone;
    BackButton.accessibilityLabel = @"返回";

    [self.navigationItem setHidesBackButton:YES];
    self.navigationItem.rightBarButtonItem = sendToFBButton;
    self.navigationItem.leftBarButtonItem = BackButton;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:[UIImage imageNamed:@"btn_fb_pic"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(pressBtnPopup:) forControlEvents:UIControlEventTouchDown];
    button.frame = CGRectMake(0, 0, 60, 60);
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 setImage:[UIImage imageNamed:@"btn_fb_emo"] forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(pressBtnSticker:) forControlEvents:UIControlEventTouchDown];
    button1.frame = CGRectMake(0, 0, 60, 60);
    UIBarButtonItem *barButtonItem1 = [[UIBarButtonItem alloc] initWithCustomView:button1];
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    NSArray *buttons = [NSArray arrayWithObjects: flexibleSpace, barButtonItem, barButtonItem1, nil];
    [self.functionToolbar setItems:buttons animated:NO];
    
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setBackgroundColor:[UIColor colorWithRed:190.0/255.0 green:193.0/255.0 blue:201.0/255.0 alpha:1.0]];
    [[UINavigationBar appearance] setTranslucent:NO];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithRed:131.0/255.0f green:82.0/255.0f blue:25.0/255.0f alpha:1.0]}];
    [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:72.0/255.0f green:94.0/255.0f blue:152.0/255.0f alpha:1.0]];
    
    CALayer *bottomBorder = [CALayer layer];
    bottomBorder.frame = CGRectMake(0.0f, self.tv_message.frame.size.height - 1, self.tv_message.frame.size.width, 1.0f);
    bottomBorder.backgroundColor = [UIColor blackColor].CGColor;
    [self.tv_message.layer addSublayer:bottomBorder];
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    
    if(self.userInfo != nil){
        [self.iv_userPic sd_setImageWithURL:[NSURL URLWithString:self.userInfo.picture]];
    }
    if(self.obj != nil){
        AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
        [app showLoading];
        NSLog(@"self.obj.comments:%@",self.obj.comments);
        NSMutableArray *ary = [self.obj.comments objectForKey:@"data"];
        for(int i = 0;i<[ary count];i++){
            fbObject *fbobj = [[fbObject alloc] initWithDict:[ary objectAtIndex:i]];
            [self.aryData addObject:fbobj];
        }
        [self.tv_post reloadData];
        [app hideLoading];
    }
    else{
        self.tv_post.hidden = YES;
    }
    CGRect frame1 = self.v_warm.frame;
    frame1.origin.y = [[utilityManager alloc] getScreenSize].size.height - kDefaultToolbarHeight - frame1.size.height;
    self.v_warm.frame = frame1;
}

-(IBAction)pressBtnTextToSpeech:(id)sender{
    UIButton *btn = (UIButton*)sender;
    self.selBtn = btn;
    
    NSString *str = @"";
    fbObject *obj = [self.aryData objectAtIndex:btn.tag];
    if(obj.FBdescription != nil){
        str = [obj.FBdescription stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    else{
        if(obj.name != nil){
            str = [obj.name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        else if(obj.message != nil){
            str = [obj.message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
    }
    
    [[utilityManager alloc] TextToSpeech:str];
    NSMutableArray *imageArray = [NSMutableArray new];
    
    for (int i = 1; i < 5; i ++) {
        [imageArray addObject:[UIImage imageNamed:[NSString stringWithFormat:@"btn_spk_stop%d.png",i]]];
    }
    [self.selBtn.imageView setAnimationImages:[imageArray copy]];
    [self.selBtn.imageView setAnimationDuration:1.0];
    [self.selBtn.imageView startAnimating];
    [self.selBtn removeTarget:nil
                       action:NULL
             forControlEvents:UIControlEventAllEvents];
}

-(void) stopTextToSpeech:(NSNotification *)inNotification {
    [self.selBtn.imageView stopAnimating];
    [self.selBtn.imageView setAnimationImages:nil];
    [self.selBtn setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [self.selBtn addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
}


-(void) popupAnimation:(UIView*) popupView isOpen:(BOOL)isOpen{
    [UIView animateWithDuration:0.2
                          delay:0.4
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         if(isOpen){
                             popupView.hidden = NO;
                             popupView.frame = CGRectMake(0, [[utilityManager alloc] getScreenSize].size.height - popupView.frame.size.height - self.navigationController.navigationBar.frame.size.height, self.view.frame.size.width, self.view.frame.size.height);
                         }
                         else{
                             
                             popupView.frame = CGRectMake(0,
                                                          [[utilityManager alloc] getScreenSize].size.height, popupView.frame.size.width,
                                                          popupView.frame.size.height);
                         }
                     }
                     completion:^(BOOL finished){
                         //                         popupView.hidden = YES;
                         
                     }];
}

-(IBAction)pressBtnImgClose:(id)sender{
    self.v_img.hidden = YES;
    self.iv_image.image = nil;
}

-(IBAction)pressBtnCam:(id)sender{
    [self.view endEditing:YES];
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnLib:(id)sender{
    [self.view endEditing:YES];
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnPopup:(id)sender{
    [self.view endEditing:YES];
    [self popupAnimation:self.v_popup isOpen:YES];
}

-(IBAction)pressBtnClose:(id)sender{
    [self.view endEditing:YES];
    [self popupAnimation:self.v_popup isOpen:NO];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    self.originalImage = [UIImage fixrotation:[info objectForKey:UIImagePickerControllerOriginalImage]];
    [self dismissViewControllerAnimated:YES completion:nil];
    self.iv_image.image = self.originalImage;
    self.v_img.hidden = NO;
    [self popupAnimation:self.v_popup isOpen:NO];
}

-(IBAction)pressBtnSticker:(id)sender{
    [self.view endEditing:YES];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"stickerViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void) addSticker:(NSNotification *)inNotification {
    self.originalImage = [inNotification object];
    if(self.originalImage != nil){
        self.iv_image.image = self.originalImage;
        self.v_img.hidden = NO;
    }
}

-(void) clearView{
    self.v_img.hidden = YES;
    self.iv_image.image = nil;
    [self.iv_image setContentMode:UIViewContentModeScaleAspectFit];
    self.tv_message.text = @"";
    self.tv_message.font = [[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Contact"]];
    self.tv_message.text = PLACEHOLDER;
    self.tv_message.textColor = [UIColor lightGrayColor];
    self.tv_message.delegate = self;
    [self popupAnimation:self.v_popup isOpen:NO];
}

- (BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    self.tv_message.text = @"";
    self.tv_message.textColor = [UIColor blackColor];
    return YES;
}

-(void) textViewDidChange:(UITextView *)textView
{
    
    if(self.tv_message.text.length == 0){
        self.tv_message.textColor = [UIColor lightGrayColor];
        self.tv_message.text = @"有甚麼想説？";
        [self.tv_message resignFirstResponder];
    }
}

-(IBAction)sendToFB:(id)sender{
    [self.view endEditing:YES];
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    NSString *str = ([self.tv_message.text isEqualToString:PLACEHOLDER])?@"":self.tv_message.text;
    NSData *data = nil;
    if(self.originalImage != nil){
        data = [UIImage convertImageToLowJPEG:self.originalImage];
    }
    if(self.obj != nil){
        [[connectionManager alloc] sendTextNImageCommentToPostID:self.obj.id message:str imageData:[UIImage convertImageToLowJPEG:self.originalImage] Controller:self completionHandler:^(bool success, NSDictionary *dict) {
            if(success){
                [self clearView];
                fbObject *fbObj = [[fbObject alloc] initWithDict:dict];
                [self.aryData addObject:fbObj];
                [self.tv_post reloadData];
            }
            [app hideLoading];
        }];
    }
    else{
        [[connectionManager alloc] sendTextNImageToFB:str imageData:data Controller:self completionHandler:^(bool success, NSDictionary *dict) {
            if(success){
                [self.navigationController dismissViewControllerAnimated:YES completion:^{
                    [self clearView];
                    fdActViewController *vc = (fdActViewController*)self.preView;
                    [vc flashData];
                }];
            }
            [app hideLoading];
        }];
    }
}

-(IBAction)BackFunc:(id)sender{
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        if(self.obj != nil){
            fdActViewController *vc = (fdActViewController*)self.preView;
            [vc flashData];
        }
    }];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    /* No longer listen for keyboard */
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
}
#pragma mark -
#pragma mark Notifications

- (void)keyboardWillShow:(NSNotification *)notification
{
    /* Move the toolbar to above the keyboard */
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    CGRect frame = self.functionToolbar.frame;
    CGRect frame1 = self.v_warm.frame;
    NSDictionary *userInfo = [notification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
        frame.origin.y = self.view.frame.size.height - frame.size.height - keyboardRect.size.height;
        frame1.origin.y = frame.origin.y - frame1.size.height;
    }
    self.functionToolbar.frame = frame;
    self.v_warm.frame = frame1;
    [UIView commitAnimations];
    keyboardIsVisible = YES;
}

-(void) noticeChangeKeyboard:(NSNotification *)inNotification {
    /* Move the toolbar to above the keyboard */
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    CGRect frame = self.functionToolbar.frame;
    CGRect frame1 = self.v_warm.frame;
    NSDictionary *userInfo = [inNotification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
        frame.origin.y = self.view.frame.size.height - frame.size.height - keyboardRect.size.height;
        frame1.origin.y = frame.origin.y - frame1.size.height;
    }
    self.functionToolbar.frame = frame;
    self.v_warm.frame = frame1;
    [UIView commitAnimations];
    keyboardIsVisible = YES;
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    /* Move the toolbar back to bottom of the screen */
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    CGRect frame = self.functionToolbar.frame;
    CGRect frame1 = self.v_warm.frame;
    if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
        frame.origin.y = self.view.frame.size.height - frame.size.height;
        frame1.origin.y = frame.origin.y - frame1.size.height;
    }
    else {
        frame.origin.y = self.view.frame.size.width - frame.size.height;
        frame1.origin.y = frame.origin.y - frame1.size.height;
    }
    self.functionToolbar.frame = frame;
    self.v_warm.frame = frame1;
    [UIView commitAnimations];
    keyboardIsVisible = NO;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.aryData count];    //count number of row from counting array hear cataGorry is An Array
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"fdActTableViewCell";
    fontManager *font = [[fontManager alloc] init];
    fdActTableViewCell* cell = (fdActTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    cell = nil;
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    }
    cell.translatesAutoresizingMaskIntoConstraints = NO;
    fbObject *obj = [self.aryData objectAtIndex:indexPath.row];
    for(UIView *subview in [cell.v_body subviews]) {
        [subview removeFromSuperview];
    }
    float orgY = 0.0;
    float space = 5.0;
    float orgX = 0.0;
    cell.lbl_username.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.btn_TextToSpeak = [UIButton buttonWithType:UIButtonTypeCustom];
    cell.btn_TextToSpeak.frame = CGRectMake(self.tv_post.frame.size.width - 43 - 10, orgY, 43, 43);
    [cell.btn_TextToSpeak setTag:indexPath.row];
    [cell.btn_TextToSpeak setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [cell.btn_TextToSpeak addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];

    cell.btn_TextToSpeak.isAccessibilityElement = true;
    cell.btn_TextToSpeak.accessibilityTraits = UIAccessibilityTraitNone;
    cell.btn_TextToSpeak.accessibilityLabel = @"文字轉語音";

    [cell.btn_TextToSpeak setTag:indexPath.row];
    [cell.btn_TextToSpeak addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.lbl_username = [[UILabel alloc] initWithFrame:CGRectMake(orgX, orgY, cell.btn_TextToSpeak.frame.origin.x - orgX - space, 43)];
    cell.lbl_username.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    NSString *str = [[obj.created_time stringByReplacingOccurrencesOfString:@"T" withString:@" "] stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    NSDateFormatter* gmtDf = [[NSDateFormatter alloc] init];
    [gmtDf setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    [gmtDf setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate* gmtDate = [gmtDf dateFromString:str];
    
    cell.lbl_username.text = [NSString stringWithFormat:@"%@\n%@",[obj.from objectForKey:@"name"],[[utilityManager alloc] NSDateToNSString:gmtDate DateFormat:DISPLAYDATEFORMATTER]];
    
    cell.lbl_username.isAccessibilityElement = true;
    cell.lbl_username.accessibilityTraits = UIAccessibilityTraitNone;
    cell.lbl_username.accessibilityLabel = cell.lbl_username.text;

    [self setColorForText:[obj.from objectForKey:@"name"] orgString:cell.lbl_username.text object:cell.lbl_username withColor:[UIColor blackColor]];
    cell.lbl_username.lineBreakMode = LINE_BREAK_WORD_WRAP;
    cell.lbl_username.numberOfLines = 2;
    
    orgX = 0.0;
    orgY += cell.lbl_username.frame.size.height;
    orgY += space;
    
    if(obj.FBdescription != nil || obj.message != nil || obj.name != nil){
        cell.tv_description = [[UITextView alloc] initWithFrame:CGRectMake(orgX, orgY, self.tv_post.frame.size.width - 10, 60)];
        cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.tv_description.editable = NO;
        cell.tv_description.selectable = NO;
        cell.tv_description.textContainerInset = UIEdgeInsetsZero;
        cell.tv_description.contentInset = UIEdgeInsetsMake(0.0f,
                                                            0.0f,
                                                            0.0f,
                                                            0.0f);
        if(obj.FBdescription != nil){
            cell.tv_description.text = [obj.FBdescription stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        else if(obj.message != nil){
            cell.tv_description.text = [obj.message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        else if(obj.name != nil){
            cell.tv_description.text = [obj.name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        cell.tv_description.translatesAutoresizingMaskIntoConstraints = NO;
        
        cell.tv_description.isAccessibilityElement = true;
        cell.tv_description.accessibilityTraits = UIAccessibilityTraitNone;
        cell.tv_description.accessibilityLabel = cell.tv_description.text;
        
        CGRect frame = cell.tv_description.frame;
        frame.size.height = [[utilityManager alloc] getUITextViewHeight:cell.tv_description];
        cell.tv_description.frame = frame;
        cell.tv_description.textColor = [UIColor blackColor];
        cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.tv_description.scrollEnabled = NO;
        cell.tv_description.frame = CGRectMake(cell.tv_description.frame.origin.x, orgY, cell.tv_description.frame.size.width, cell.tv_description.frame.size.height);
        [cell.v_body addSubview:cell.tv_description];
        orgY += cell.tv_description.frame.size.height;
        orgY += space;
    }
    NSLog(@"obj:%@",[obj toDict]);
    if(obj.attachment != nil){
        NSLog(@"obj.attactment:%@",obj.attachment);
        cell.iv_postImg = [[UIImageView alloc] initWithFrame:CGRectMake(orgX, orgY, 310, 310)];
        [cell.iv_postImg sd_setImageWithURL:[NSURL URLWithString:[[[obj.attachment objectForKey:@"media"] objectForKey:@"image"] objectForKey:@"src"]] placeholderImage:[UIImage imageNamed:@"IMG_bk_dairy"]];
        cell.iv_postImg.center = CGPointMake((self.tv_post.frame.size.width - 10)/2, cell.iv_postImg.center.y);
        [cell.iv_postImg setContentMode:UIViewContentModeScaleAspectFit];
        [cell.v_body addSubview:cell.iv_postImg];
        
        cell.iv_postImg.isAccessibilityElement = true;
        cell.iv_postImg.accessibilityTraits = UIAccessibilityTraitNone;
        cell.iv_postImg.accessibilityLabel = @"圖片";

        orgY += cell.iv_postImg.frame.size.height;
        orgY += space;
    }
    
    [cell.v_body addSubview:cell.iv_user];
    [cell.v_body addSubview:cell.btn_TextToSpeak];
    [cell.v_body addSubview:cell.lbl_username];
    [cell.v_body addSubview:cell.btn_fb_like];
    
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}

-(void)setColorForText:(NSString*) textToFind orgString:(NSString*) orgStr object:(UILabel*)obj withColor:(UIColor*) color
{
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:obj.text];
    NSRange range = [orgStr rangeOfString:textToFind options:NSCaseInsensitiveSearch];
    if (range.location != NSNotFound) {
        [text addAttribute:NSFontAttributeName value:[[fontManager alloc] getBoldsize:[[fontManager alloc] getSettingFont:@"Contact"]] range:range];
        [text addAttribute:NSForegroundColorAttributeName value:color range:range];
    }
    obj.attributedText = text;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *simpleTableIdentifier = @"fdActTableViewCell";
    fontManager *font = [[fontManager alloc] init];
    fdActTableViewCell* cell = (fdActTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    cell = nil;
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    }
    cell.translatesAutoresizingMaskIntoConstraints = NO;
    float space = 5;
    float orgY = 0.0;
    fbObject *obj = [self.aryData objectAtIndex:indexPath.row];
    orgY += 43;
    orgY += space;
    cell.tv_description = [[UITextView alloc] initWithFrame:CGRectMake(0, orgY, cell.v_body.frame.size.width, 80)];
    cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.tv_description.textContainerInset = UIEdgeInsetsZero;
    cell.tv_description.contentInset = UIEdgeInsetsMake(0.0f,
                                                        0.0f,
                                                        0.0f,
                                                        0.0f);
    if(obj.message != nil){
        cell.tv_description.text = [obj.message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [cell.tv_description setHidden:NO];
    }
    else if(obj.name != nil){
        cell.tv_description.text = [obj.name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [cell.tv_description setHidden:NO];
    }
    else{
        [cell.tv_description setHidden:YES];
    }
    if(!cell.tv_description.hidden){
        cell.tv_description.translatesAutoresizingMaskIntoConstraints = NO;
        CGRect frame = cell.tv_description.frame;
        frame.size.height = [[utilityManager alloc] getUITextViewHeight:cell.tv_description];
        cell.tv_description.frame = frame;
        cell.tv_description.textColor = [UIColor blackColor];
        cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.tv_description.scrollEnabled = NO;
        cell.tv_description.frame = CGRectMake(cell.tv_description.frame.origin.x, orgY, cell.tv_description.frame.size.width, cell.tv_description.frame.size.height);
        orgY += cell.tv_description.frame.size.height;
        orgY += space;
    }
    
    if(obj.attachment != nil){
        orgY += 310;
        orgY += space;
    }
    orgY += space;
    return orgY;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
