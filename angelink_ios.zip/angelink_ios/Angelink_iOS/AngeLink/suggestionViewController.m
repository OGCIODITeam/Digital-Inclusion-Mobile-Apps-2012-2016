//
//  suggestionViewController.m
//  AngeLink
//
//  Created by kanhan on 21/12/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "suggestionViewController.h"

@interface suggestionViewController ()

@end

@implementation suggestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = false;
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    
    header.lbl_pageTittle.text = @"改善建議";
    header.delegate = self;
    [self.view addSubview:header];
//    self.lbl_Username.text = [[utilityManager alloc] getUserDefaultstoString:@"username"];
    [self setViewUI];
    // Do any additional setup after loading the view.
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

-(void)setViewUI{
    float orgY = 5.0;
    float space = 5.0;
    fontManager *font = [[fontManager alloc] init];
    self.btn_send.titleLabel.font = self.btn_cancel.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    self.lbl_Username.font = self.tv_message.font = self.tf_email.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    
    NSString *str = self.lbl_Username.text;
    self.lbl_Username.text = [NSString stringWithFormat:@"%@\n姓名:%@",str,[[utilityManager alloc] getUserDefaultstoString:@"username"]];
    self.lbl_Username.frame = CGRectMake(self.lbl_Username.frame.origin.x, orgY, self.lbl_Username.frame.size.width, self.lbl_Username.frame.size.height);
//    [self.lbl_Username setContentOffset: CGPointMake(0, 0) animated:NO];
    CGRect frame = self.lbl_Username.frame;
    frame.size.height = self.lbl_Username.contentSize.height;
    self.lbl_Username.frame = frame;
    [self.lbl_Username setContentOffset: CGPointMake(0, 0) animated:NO];
    self.lbl_Username.scrollEnabled = NO;
    
    orgY += self.lbl_Username.frame.size.height;
    orgY += space;
    self.tf_email.layer.cornerRadius=8.0f;
    self.tf_email.layer.masksToBounds=YES;
    self.tf_email.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_email.layer.borderWidth= 3.0f;
    [self.tf_email setPlaceholder:@"請輸入電郵地址"];
    self.tf_email.delegate = self;
    self.tf_email.frame = CGRectMake(self.tf_email.frame.origin.x, orgY, self.tf_email.frame.size.width, self.tf_email.frame.size.height);
    
    orgY += self.tf_email.frame.size.height;
    orgY += space;
    
    self.tv_message.layer.cornerRadius=8.0f;
    self.tv_message.layer.masksToBounds=YES;
    self.tv_message.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tv_message.layer.borderWidth= 3.0f;
    self.tv_message.frame = CGRectMake(self.tv_message.frame.origin.x, orgY, self.tv_message.frame.size.width, self.tv_message.frame.size.height);
    orgY += self.tv_message.frame.size.height;
    orgY += space;

    [self.btn_send setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_send setTitle:@"確定" forState:UIControlStateNormal];
    self.btn_send.frame = CGRectMake(self.btn_send.frame.origin.x, orgY, self.btn_send.frame.size.width, self.btn_send.frame.size.height);

    [self.btn_cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_cancel setTitle:@"取消" forState:UIControlStateNormal];
    self.btn_cancel.frame = CGRectMake(self.btn_cancel.frame.origin.x, orgY, self.btn_cancel.frame.size.width, self.btn_cancel.frame.size.height);
    orgY += self.btn_cancel.frame.size.height;
    orgY += space;
    
    self.sv_main.contentSize = CGSizeMake(self.sv_main.frame.size.width, orgY);
    
    
    [self.btn_cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_send setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void)pressBtnback:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)pressBtninfo:(id)sender{
    NSLog(@"press btn info");
}

-(IBAction)pressBtnCancel:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];   
}

-(IBAction)pressBtnSend:(id)sender{
    NSString *str = [NSString stringWithFormat:@"電郵地址:%@\n%@",self.tf_email.text,self.tv_message.text];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id",str,@"description", nil];
    [[connectionManager alloc] postRequest:INSERT_FEEDBACK parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
       [self.navigationController popViewControllerAnimated:YES];   
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
