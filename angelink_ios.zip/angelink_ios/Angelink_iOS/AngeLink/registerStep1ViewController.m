//
//  registerStep1ViewController.m
//  AngeLink
//
//  Created by kanhan on 14/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "registerStep1ViewController.h"
#import "registerStep2ViewController.h"



@interface registerStep1ViewController ()

@end

@implementation registerStep1ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden = YES;
    self.automaticallyAdjustsScrollViewInsets = false;
    self.tv_msg.font = [[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Contact"]];
    self.lbl_title.font = [[fontManager alloc] getBoldsize:[[fontManager alloc] getSettingFont:@"Title"]];
    self.tv_msg.scrollEnabled = NO;
    [self.tv_msg setContentOffset: CGPointMake(0, 0) animated:NO];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.tv_msg.scrollEnabled = YES;
    [self.tv_msg setContentOffset: CGPointMake(0, 0) animated:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_title.font = self.btn_agree.titleLabel.font = self.tv_msg.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    [self.tv_msg setContentOffset: CGPointMake(0, 0) animated:NO];
    [self.btn_agree setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnAgree:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep2ViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}


@end
