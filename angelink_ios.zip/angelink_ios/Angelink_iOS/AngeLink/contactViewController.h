//
//  contactViewController.h
//  AngeLink
//
//  Created by kanhan on 21/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"

@interface contactViewController : UIViewController<headerBarViewDelegate,UIWebViewDelegate,UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *wv_main;
@property (nonatomic, retain) UIAlertView *alertDel;

@property (nonatomic, retain) NSString *catType;
@end
