//
//  popupAngelViewController.m
//  AngeLink
//
//  Created by kanhan on 27/1/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "popupAngelViewController.h"

@interface popupAngelViewController ()

@end

@implementation popupAngelViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void) createUIview:(NSString*) title setMessage:(NSString*) message setImage:(NSString*) Path{
    fontManager *font = [[fontManager alloc] init];
    float orgY = 5.0;
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, orgY, self.v_body.frame.size.width, self.v_body.frame.size.height)];
    
    UILabel *lbl_notificationTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, orgY, view.frame.size.width, 50)];
    lbl_notificationTitle.font = [font getBoldsize:[font getSettingFont:@"Title"]];
    lbl_notificationTitle.text = title;
    lbl_notificationTitle.textAlignment = ALIGN_CENTER;
    [view addSubview:lbl_notificationTitle];
    orgY += lbl_notificationTitle.frame.size.height;
    orgY += 5.0;
    
    UIImageView *iv_notification = [[UIImageView alloc] initWithFrame:CGRectMake(0, orgY, 291, 146)];
    [iv_notification sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,Path]] placeholderImage:nil];
    iv_notification.center = CGPointMake(view.frame.size.width/2, iv_notification.center.y);
    [view addSubview:iv_notification];
    orgY += iv_notification.frame.size.height;
    orgY += 5.0;
    
    UITextView *tv_notification = [[UITextView alloc] initWithFrame:CGRectMake(0, orgY, lbl_notificationTitle.frame.size.width, 200)];
    tv_notification.text = message;
    tv_notification.font = [font getBoldsize:[font getSettingFont:@"Title"]];
    [[utilityManager alloc] textViewDidChange:tv_notification];
    [view addSubview:tv_notification];
    orgY += tv_notification.frame.size.height;
    orgY += 5.0;
    
    view.frame = CGRectMake(0, 0, view.frame.size.width, orgY);
    view.center = CGPointMake(self.v_body.frame.size.width/2, self.v_body.frame.size.height/2);
    [view setBackgroundColor:[UIColor whiteColor]];
    [self.v_body addSubview:view];
    
    view.layer.cornerRadius=8.0;
    view.layer.masksToBounds=YES;
    view.layer.borderWidth= 2.0f;
    view.layer.borderColor = [[UIColor clearColor] CGColor];
    
    self.btn_close.frame = CGRectMake(0, self.v_body.frame.origin.y + self.v_body.frame.size.height + 5.0, self.btn_close.frame.size.width, self.btn_close.frame.size.height);
    
    self.btn_close.center = CGPointMake(self.v_body.center.x, self.btn_close.center.y);
}

-(IBAction)pressBtnClose:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{}];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
