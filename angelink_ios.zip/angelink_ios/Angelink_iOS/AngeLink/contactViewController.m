//
//  contactViewController.m
//  AngeLink
//
//  Created by kanhan on 21/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "contactViewController.h"

@interface contactViewController ()

@end

@implementation contactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = self.catType;
    header.delegate = self;
    [self.view addSubview:header];
        
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.wv_main.scrollView.bounces = NO;
    self.wv_main.scrollView.scrollEnabled = NO;
    self.wv_main.hidden = NO;
    self.wv_main.delegate = self;
    NSString *page;
    if([self.catType isEqualToString:@"關於愛、連繫"]){
        page = @"about";
    }
    else if([self.catType isEqualToString:@"條款細則"]){
        page = @"tnc";
    }
    else if([self.catType isEqualToString:@"關於我們"]){
        page = @"aboutus";
    }
    else{
        page = @"";
    }
        NSString *filePath=[[NSBundle mainBundle]pathForResource:page ofType:@"html" inDirectory:nil];
    NSString *htmlstring=[NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    [self.wv_main loadHTMLString:htmlstring baseURL:[[NSBundle mainBundle] bundleURL]];
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtninfo:(id)sender{
    NSLog(@"press btn info");
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    
}

- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType{
        if ([[[request URL] absoluteString] hasPrefix:@"del:"]) {
            // Call the given selector
            self.alertDel = [[UIAlertView alloc] initWithTitle:@"警告" message:@"刪除你的帳戶將﹕\n永久刪除你的帳戶資訊與個人頭像\n將你在AngeLINK 的資料從資料庫中永久移除\n此動作將不能復原" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
            [self.alertDel show];
        }
   return YES;
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(alertView == self.alertDel){
        if (buttonIndex == 0)
        {
            
        }
        else{
            utilityManager *utility = [[utilityManager alloc] init];
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[utility getUserDefaultstoString:@"phoneAreaCode"],@"phoneAreaCode",[utility getUserDefaultstoString:@"phone"],@"phone",[utility getUserDefaultstoString:@"deviceToken"],@"deviceToken", nil];
            [[connectionManager alloc] postRequest:REMOVE_USER_INFO parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
                if(status)
                {
                    dbManager *db = [[dbManager alloc] init];
                    [db deleteSQL:@"tbl_album"];
                    [db deleteSQL:@"tbl_album_page"];
                    [db deleteSQL:@"tbl_default_answer"];
                    [db deleteSQL:@"tbl_offline_album"];
                    [db deleteSQL:@"tbl_offline_album_page"];
                    [db deleteSQL:@"tbl_relation"];
                    [db deleteSQL:@"tbl_userLocation"];
                    [db deleteSQL:@"tbl_userProfile"];
                    NSDictionary *dictInfo = [[NSDictionary alloc] initWithObjectsAndKeys:
                                              @"",@"memberID",
                                              @"",@"user_id",
                                              @"",@"name",
                                              @"",@"phone",
                                              @"",@"phoneAreaCode",
                                              @"",@"birthday",
                                              @"",@"lunarBirthday",
                                              @"",@"facebookID",
                                              @"",@"friendList",
                                              @"",@"backupPath",
                                              @"",@"imageName",
                                              @"",@"memberID",
                                              @"",@"register",
                                              nil];
                    [[utilityManager alloc] removeUserDefaults:dictInfo];
                    [[dbManager alloc] deleteSQL:@"tbl_userProfile"];
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                             bundle: nil];
                    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"introViewController"];
                    [[self navigationController] initWithRootViewController:vc];
                }
            }];

        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
