//
//  addPageVideoViewController.h
//  AngeLink
//
//  Created by kanhan on 1/12/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface addPageVideoViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,headerBarViewDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *btn_selVideo;
@property (weak, nonatomic) IBOutlet UIButton *btn_play;
@property (weak, nonatomic) IBOutlet UIButton *btn_saveNquit;
@property (weak, nonatomic) IBOutlet UIButton *btn_saveNpage;
@property (weak, nonatomic) IBOutlet UIImageView *iv_videoThumb;

@property (nonatomic, retain) NSString *headerTitle;
@property (nonatomic, strong) NSObject *record,*pageRecord;
@property (nonatomic, retain) NSMutableArray *mediaArray;

@property (nonatomic, retain) infoView *info;

@end
