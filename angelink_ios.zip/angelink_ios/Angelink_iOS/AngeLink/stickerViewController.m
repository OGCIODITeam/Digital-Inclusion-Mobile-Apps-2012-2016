//
//  stickerViewController.m
//  AngeLink
//
//  Created by kanhan on 19/5/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "stickerViewController.h"
#import "stickerCollectionViewCell.h"
#import "MessageViewController.h"

@interface stickerViewController ()

@end

@implementation stickerViewController
static NSString * const albumCollectionViewCellKind = @"stickerCollectionViewCell";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    // Do any additional setup after loading the view.
//    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
//    header.lbl_pageTittle.text = @"添加貼紙";
//    header.delegate = self;
//    [self.view addSubview:header];
    
    UIBarButtonItem *BackButton = [[UIBarButtonItem alloc]
                                   initWithTitle:@"關閉"
                                   style:UIBarButtonItemStylePlain
                                   target:self
                                   action:@selector(BackFunc:)];
    [self.navigationItem setHidesBackButton:YES];
    self.navigationItem.leftBarButtonItem = BackButton;
    
    
    [self.cv_main registerNib:[UINib nibWithNibName:albumCollectionViewCellKind bundle:nil] forCellWithReuseIdentifier:albumCollectionViewCellKind];
    [self.cv_main setBackgroundColor:[UIColor clearColor]];
    self.cv_main.delegate = self;
    self.cv_main.dataSource = self;
    
    // Do any additional setup after loading the view.
    if(self.aryData == nil)
    {
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    [self.aryData addObject:[UIImage imageNamed:@"sk01_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk02_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk03_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk04_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk05_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk06_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk07_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk08_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk09_s"]];
    [self.aryData addObject:[UIImage imageNamed:@"sk10_s"]];
    if(self.aryDataL == nil)
    {
        self.aryDataL = [NSMutableArray new];
    }
    else{
        [self.aryDataL removeAllObjects];
    }
    [self.aryDataL addObject:[UIImage imageNamed:@"sk01"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk02"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk03"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk04"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk05"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk06"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk07"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk08"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk09"]];
    [self.aryDataL addObject:[UIImage imageNamed:@"sk10"]];
    [self.cv_main reloadData];
}

-(IBAction)BackFunc:(id)sender{
   [self.navigationController popViewControllerAnimated:YES];
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.aryData count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    fontManager *font = [[fontManager alloc] init];
    stickerCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:albumCollectionViewCellKind
                                                                                forIndexPath:indexPath];
    cell.iv_sticker.image = [self.aryData objectAtIndex:indexPath.row];
//    [cell.iv_sticker setBackgroundColor:[UIColor whiteColor]];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width / 2 - 20, self.view.frame.size.width / 2 - 20);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath  {
//    [self dismissViewControllerAnimated:YES completion:^{
//        if([self.pre_view isKindOfClass:[MessageViewController class]]){
//            MessageViewController *temp = (MessageViewController*) self.pre_view;
//            [temp sendStickerFunction: [self.aryDataL objectAtIndex:indexPath.row]];
//        }
//    }];
    
    NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:[self.aryDataL objectAtIndex:indexPath.row],@"obj", nil];
    [[NSNotificationCenter defaultCenter] postNotificationName: @"addSticker" object:[self.aryDataL objectAtIndex:indexPath.row] userInfo:userInfo];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
