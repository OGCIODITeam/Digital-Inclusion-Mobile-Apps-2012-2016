//
//  stickerViewController.h
//  AngeLink
//
//  Created by kanhan on 19/5/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
@interface stickerViewController : UIViewController<headerBarViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *cv_main;
@property (nonatomic, retain) NSMutableArray *aryData,*aryDataL;
@property (nonatomic, retain) UIViewController *pre_view;
@end
