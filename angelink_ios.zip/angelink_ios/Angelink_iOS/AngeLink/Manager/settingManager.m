//
//  settingManager.m
//  masguru
//
//  Created by jacky on 16/4/15.
//
//

#import "settingManager.h"

@implementation settingManager
#pragma mark app lifecycle
+ (id)defaultManager {
    static settingManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
    });
    return defaultManager;
}

-(void) setUserLang:(NSString*)Lang{
    NSUserDefaults *user_default = [NSUserDefaults standardUserDefaults];
    if([Lang isEqualToString:@"zh"]){
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"zh" forKey:@"displayLang"];
        [user_default setValue:@"zh-Hant" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    if([Lang isEqualToString:@"cn"]){
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"cn" forKey:@"displayLang"];
        [user_default setValue:@"zh-Hans" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    if([Lang isEqualToString:@"en"]){
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"en" forKey:@"displayLang"];
        [user_default setValue:@"en" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    [[BundleLocalization sharedInstance] setLanguage:[user_default objectForKey:@"lang"]];
    [user_default setObject:[NSArray arrayWithObject:[user_default objectForKey:@"lang"]] forKey:@"Applanguage"];
    [user_default synchronize];
}

-(void) setDefaultLang{
    NSUserDefaults *user_default = [NSUserDefaults standardUserDefaults];
    NSString *temp = [[NSLocale preferredLanguages] objectAtIndex:0];
    NSString *language = [temp substringToIndex:2];
    if([temp isEqualToString:@"zh-Hant"]){
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"tw" forKey:@"displayLang"];
        [user_default setValue:@"zh-Hant" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    else if([temp isEqualToString:@"zh-Hans"]){
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"cn" forKey:@"displayLang"];
        [user_default setValue:@"zh-Hans" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    else if([language isEqualToString:@"en"]){
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"en" forKey:@"displayLang"];
        [user_default setValue:@"en" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    else{
        NSDictionary *lang = [NSDictionary dictionaryWithObject:@"en" forKey:@"displayLang"];
        [user_default setValue:@"en" forKey:@"lang"];
        [[utilityManager alloc] saveValuetoUserDefaults:lang];
    }
    [[BundleLocalization sharedInstance] setLanguage:[user_default objectForKey:@"lang"]];
    [user_default setObject:[NSArray arrayWithObject:[user_default objectForKey:@"lang"]] forKey:@"Applanguage"];
    [user_default synchronize];
}

-(float) getRedColorOfFrameObject:(NSString*)obj{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *BGColor = [dictColor objectForKey:obj];
    return [[BGColor objectForKey:@"Red"] floatValue];
}

-(float) getGreenColorOfFrameObject:(NSString*)obj{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *BGColor = [dictColor objectForKey:obj];
    return [[BGColor objectForKey:@"Green"] floatValue];
}

-(float) getBlueColorOfFrameObject:(NSString*)obj{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *BGColor = [dictColor objectForKey:obj];
    return [[BGColor objectForKey:@"Blue"] floatValue];
}

-(float) getBorderWidth{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    return [[dictColor objectForKey:@"Border width"] floatValue];
}

-(float) getRadiusSize{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    return [[dictColor objectForKey:@"Radius size"] floatValue];
}

-(float) getBodyFontSize{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *dict = [dictColor objectForKey:@"Font Size"];
    return [[dict objectForKey:@"Body Font size"] floatValue];
}

-(float) getTitleFontSize{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *dict = [dictColor objectForKey:@"Font Size"];
    return [[dict objectForKey:@"Title Font size"] floatValue];
}

-(float) getDetailFontSize{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *dict = [dictColor objectForKey:@"Font Size"];
    return [[dict objectForKey:@"Detail Font size"] floatValue];
}

-(float) getUserFontSize{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *dict = [dictColor objectForKey:@"Font Size"];
    return [[dict objectForKey:@"User Font size"] floatValue];
}

-(NSString*) getCompanyName{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [pageSetting objectForKey:@"Company Name"];
}

-(NSString*) getCompanyLogo{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [pageSetting objectForKey:@"Company Logo"];
}

-(NSString*) getWelcomeMessage{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [[pageSetting objectForKey:@"Welcome Message"] objectForKey:[[utilityManager alloc] getUserDefaultstoString:@"displayLang"]];
}

-(UIImage*) getCompanyNavLogo{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSString *str = [pageSetting objectForKey:@"Company Nav Logo"];
    if (![str isEqualToString:@""]) {
        return [UIImage imageNamed:str];
    }
    else{
        return [[utilityManager alloc] imageFromColor:[UIColor colorWithRed: [self getRedColorOfFrameObject:@"Nav Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Nav Color"]/255 blue:[self getBlueColorOfFrameObject:@"Nav Color"]/255 alpha:1.0]];
    }
    return nil;
}

-(NSString*) getCompanyID{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [pageSetting objectForKey:@"Company ID"];
}

-(NSString*) getCompanyUsername{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [pageSetting objectForKey:@"Company Username"];
}

-(NSString*) getCompanyPassword{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [pageSetting objectForKey:@"Company Password"];
}

-(NSString*) getContactEmail{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    return [pageSetting objectForKey:@"Contact Email"];
}

-(UIColor *) getBGColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"BG Color"]/ 255 green:[self getGreenColorOfFrameObject:@"BG Color"]/255 blue:[self getBlueColorOfFrameObject:@"BG Color"]/255 alpha:1.0];
}
-(UIColor *) getTabColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Tab Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Tab Color"]/255 blue:[self getBlueColorOfFrameObject:@"Tab Color"]/255 alpha:1.0];
}
-(UIColor *) getTabSelectedColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Tab Selected Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Tab Selected Color"]/255 blue:[self getBlueColorOfFrameObject:@"Tab Selected Color"]/255 alpha:1.0];
}

-(UIColor *) getNavColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Nav Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Nav Color"]/255 blue:[self getBlueColorOfFrameObject:@"Nav Color"]/255 alpha:1.0];
}

-(UIColor *) getNavTextColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Nav Text Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Nav Text Color"]/255 blue:[self getBlueColorOfFrameObject:@"Nav Text Color"]/255 alpha:1.0];
}

-(UIColor *) getTitleTextColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Title Text Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Title Text Color"]/255 blue:[self getBlueColorOfFrameObject:@"Title Text Color"]/255 alpha:1.0];
}

-(UIColor *) getDetailTextColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Detail Text Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Detail Text Color"]/255 blue:[self getBlueColorOfFrameObject:@"Detail Text Color"]/255 alpha:1.0];
}

-(UIColor *) getUserTextColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Username Text Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Username Text Color"]/255 blue:[self getBlueColorOfFrameObject:@"Username Text Color"]/255 alpha:1.0];
}


-(UIColor *) getBorderColor{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *BtnDict = [dictColor objectForKey:@"Border Color"];
    return [UIColor colorWithRed:[[BtnDict objectForKey:@"Red"] floatValue]/255.0 green:[[BtnDict objectForKey:@"Green"] floatValue]/255.0 blue:[[BtnDict objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0];
}

-(UIColor *) getPageColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Page Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Page Color"]/255 blue:[self getBlueColorOfFrameObject:@"Page Color"]/255 alpha:1.0];
}

-(UIColor *) getCurrentPageColor{
    return [UIColor colorWithRed: [self getRedColorOfFrameObject:@"Current Page Color"]/ 255 green:[self getGreenColorOfFrameObject:@"Current Page Color"]/255 blue:[self getBlueColorOfFrameObject:@"Current Page Color"]/255 alpha:1.0];
}

-(UIColor *) getBadgeColor{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *BtnDict = [dictColor objectForKey:@"Badge Color"];
    return [UIColor colorWithRed:[[BtnDict objectForKey:@"Red"] floatValue]/255.0 green:[[BtnDict objectForKey:@"Green"] floatValue]/255.0 blue:[[BtnDict objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0];
}

-(BOOL) getButtonShadow{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    return [dictColor objectForKey:@"Button shadow"];
}

-(UIButton *) setMainButton:(UIButton*) btn objectName:(NSString*) obj{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Object Setting"];
    NSDictionary *BtnDict = [dictColor objectForKey:obj];
    [btn setImage:[UIImage imageNamed:[[BtnDict objectForKey:@"icon"] objectForKey:[[utilityManager alloc] getUserDefaultstoString:@"displayLang"]]] forState:UIControlStateNormal];
    [btn setBackgroundColor:[UIColor colorWithRed:[[[BtnDict objectForKey:@"Color"] objectForKey:@"Red"] floatValue]/255.0 green:[[[BtnDict objectForKey:@"Color"] objectForKey:@"Green"] floatValue]/255.0 blue:[[[BtnDict objectForKey:@"Color"] objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0]];
    return btn;
}

-(UIView *) setMainDashboard:(UIView*) view objectName:(NSString*) obj{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Object Setting"];
    NSDictionary *BtnDict = [dictColor objectForKey:obj];
    NSDictionary *BorderDict = [BtnDict objectForKey:@"Border"];
    if (![[[BtnDict objectForKey:@"BG Image"] objectForKey:[[utilityManager alloc] getUserDefaultstoString:@"displayLang"]] isEqualToString:@""]) {
        for (UIView *subview in [view subviews]){
            if([subview isKindOfClass:[UIImageView class]]){
                if(subview.frame.size.width == view.frame.size.width && subview.frame.size.height == view.frame.size.height){
                    
                    ((UIImageView*)subview).image = [UIImage imageNamed:[[BtnDict objectForKey:@"BG Image"] objectForKey:[[utilityManager alloc] getUserDefaultstoString:@"displayLang"]]];
                    float alpha = [[BtnDict objectForKey:@"Image Alpha"] floatValue];
                    [(UIImageView*)subview setAlpha:alpha];
                    
                }
            }
        }
    }
    else{
        [view setBackgroundColor:[UIColor colorWithRed:[[[BtnDict objectForKey:@"Color"] objectForKey:@"Red"] floatValue]/255.0 green:[[[BtnDict objectForKey:@"Color"] objectForKey:@"Green"] floatValue]/255.0 blue:[[[BtnDict objectForKey:@"Color"] objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0]];
    }
    view.layer.cornerRadius = [[BorderDict objectForKey:@"Radius"] floatValue];
    view.layer.masksToBounds = NO;
    view.layer.borderWidth = [[BorderDict objectForKey:@"width"] floatValue];
    view.layer.borderColor = [[UIColor colorWithRed:[[[BorderDict objectForKey:@"Color"] objectForKey:@"Red"] floatValue]/255.0 green:[[[BorderDict objectForKey:@"Color"] objectForKey:@"Green"] floatValue]/255.0 blue:[[[BorderDict objectForKey:@"Color"] objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0] CGColor];
    return view;
}

-(UIColor *) getDashboardBorderColor{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Object Setting"];
    NSDictionary *BtnDict = [dictColor objectForKey:@"Dashboard"];
    NSDictionary *BorderDict = [BtnDict objectForKey:@"Border"];
    return [UIColor colorWithRed:[[[BorderDict objectForKey:@"Color"] objectForKey:@"Red"] floatValue]/255.0 green:[[[BorderDict objectForKey:@"Color"] objectForKey:@"Green"] floatValue]/255.0 blue:[[[BorderDict objectForKey:@"Color"] objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0];
}

-(UIButton *) setCommonButton:(UIButton*) btn{
    NSDictionary *pageSetting = [[utilityManager alloc] readCustomPlist];
    NSDictionary *dictColor = [pageSetting objectForKey:@"Global Setting"];
    NSDictionary *BtnDict = [dictColor objectForKey:@"Common Btn"];
    NSDictionary *BtnColor = [BtnDict objectForKey:@"BG Color"];
    [btn setBackgroundColor:[UIColor colorWithRed:[[BtnColor objectForKey:@"Red"] floatValue]/255.0 green:[[BtnColor objectForKey:@"Green"] floatValue]/255.0 blue:[[BtnColor objectForKey:@"Blue"] floatValue]/255.0 alpha:1.0]];
    if([[BtnDict objectForKey:@"Shadow"] boolValue]){
        [[utilityManager alloc] setShadow:btn];
    }
    if([[BtnDict objectForKey:@"Border"] boolValue]){
        [[utilityManager alloc] setBorder:btn];
    }
    return btn;
}

-(void) setFontSize:(NSString *) value{
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:value,@"FontSize", nil];
    [[utilityManager alloc] saveValuetoUserDefaults:dict];    
}

-(NSString*) getFontSize{
    if([[utilityManager alloc] getUserDefaultstoString:@"FontSize"] != nil){
        return [[utilityManager alloc] getUserDefaultstoString:@"FontSize"];
    }
    return @"Large";
}
@end
