//
//  apiManager.m
//
//  Created by jacky on 14/4/15.
//
//

#import "apiManager.h"
//#define USING_STATIC_API

#ifdef USING_STATIC_API
#define CARLIST @"carlist.php"
#define AREA @"area.php"
#else
#define CARLIST @"carlist.php"
#define AREA @"area.php"
#endif

@implementation apiManager

#pragma mark public
#pragma mark app lifecycle
+ (id)defaultManager {
    static apiManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
        
    });    
    return defaultManager;
}

-(NSString*) getServerHost{
    return [NSString stringWithFormat:@"%@",SERVER_HOST];
}

-(NSString*) switchAPIservice:(NSString*)service{
    if ([service isEqualToString:TokenValidation]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,TokenValidationService];
    }
    if ([service isEqualToString:MemberLogin]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,MemberLoginService];
    }
    if ([service isEqualToString:GetVerifyCode]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,GetVerifyCodeService];
    }
    if ([service isEqualToString:PhoneNoCountry]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,PhoneNoCountryService];
    }
    if ([service isEqualToString:Gender]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,GenderService];
    }
    if ([service isEqualToString:AgeGroup]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,AgeGroupService];
    }
    if ([service isEqualToString:Registration]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,RegistrationService];
    }
    if ([service isEqualToString:UserProfile]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,UserProfileService];
    }
    if ([service isEqualToString:ChangePassword]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,ChangePasswordService];
    }
    if ([service isEqualToString:StoreList]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,StoreListService];
    }
    if ([service isEqualToString:StoreDetails]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,StoreDetailsService];
    }
    if ([service isEqualToString:EventList]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,EventListService];
    }
    if ([service isEqualToString:EventDetails]) {
        return [NSString stringWithFormat:@"%@%@",SERVER_HOST,EventDetailsService];
    }
    return @"";
}

-(AFJSONRequestSerializer*)switchHeaderType:(NSString*)headerType request:(AFJSONRequestSerializer*) requestSerializer{
    if ([headerType isEqualToString:TokenValidation]) {
        return requestSerializer;
    }
    if ([headerType isEqualToString:MemberLogin]) {
       return requestSerializer;
    }
    if ([headerType isEqualToString:GetVerifyCode]) {
        return requestSerializer;
    }
    if ([headerType isEqualToString:PhoneNoCountry]) {
      return requestSerializer;
    }
    if ([headerType isEqualToString:Gender]) {
      return requestSerializer;
    }
    if ([headerType isEqualToString:AgeGroup]) {
       return requestSerializer;
    }
    if ([headerType isEqualToString:Registration]) {
       return requestSerializer;
    }
    if ([headerType isEqualToString:UserProfile]) {
       return requestSerializer;
    }
    if ([headerType isEqualToString:ChangePassword]) {
      return requestSerializer;
    }
    if ([headerType isEqualToString:StoreList]) {
      return requestSerializer;
    }
    if ([headerType isEqualToString:StoreDetails]) {
      return requestSerializer;
    }
    if ([headerType isEqualToString:EventList]) {
      return requestSerializer;
    }
    if ([headerType isEqualToString:EventDetails]) {
        return requestSerializer;
    }
    return requestSerializer;
}

-(AFJSONRequestSerializer*)setDeviceToken:(AFJSONRequestSerializer*) requestSerializer{
    requestSerializer = [AFJSONRequestSerializer serializer];
    [requestSerializer setValue:@"DOLOGIN" forHTTPHeaderField:@"action"];
    [requestSerializer setValue:[[utilityManager alloc] getUserDefaultstoString:@"comid"] forHTTPHeaderField:@"compid"];
    [requestSerializer setValue:nil forHTTPHeaderField:@"modgroup"];
    [requestSerializer setValue:@"userlogin" forHTTPHeaderField:@"module"];
    [requestSerializer setValue:@"xmlUserLogin" forHTTPHeaderField:@"query"];
    [requestSerializer setValue:@"json" forHTTPHeaderField:@"returnformat"];
    [requestSerializer setValue:[[settingManager alloc] getCompanyUsername] forHTTPHeaderField:@"username"];
    [requestSerializer setValue:[[settingManager alloc] getCompanyPassword] forHTTPHeaderField:@"password"];
    [requestSerializer setValue:@"username" forHTTPHeaderField:@"type"];
    return requestSerializer;
}

@end
