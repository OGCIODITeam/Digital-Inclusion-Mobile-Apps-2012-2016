//
//  dbManager.h
//  CoachnVan
//
//  Created by Jacky Chan on 29/6/15.
//  Copyright (c) 2015 jacky chan. All rights reserved.
//

#import "common.h"

@interface dbManager : NSObject
@property (nonatomic,retain) FMDatabaseQueue* localDb;

+(dbManager *) defaultManager;

//SQLite function
-(BOOL) insertSQL:(NSString*)tablename tKey:(NSString*)key tValue:(NSString*)value;
-(BOOL) updateSQL:(NSString*)tablename tCol:(NSString*)col tWhere:(NSString*)where;
-(BOOL) deleteSQL:(NSString*)tablename;
-(NSMutableArray*) selectSQL:(NSString*)tablename where:(NSString*)whereStr option:(NSString*)optionStr;

-(NSMutableArray*) customSQL:(NSString*) query;


@end
