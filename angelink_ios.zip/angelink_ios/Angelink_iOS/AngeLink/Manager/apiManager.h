//
//  apiManager.h
//
//  Created by jacky on 14/4/15.
//
//

#import "common.h"

#define TokenValidation @"TokenValidation"
#define MemberLogin @"MemberLogin"
#define GetVerifyCode @"GetVerifyCode"
#define PhoneNoCountry @"PhoneNoCountry"
#define Gender @"Gender"
#define AgeGroup @"AgeGroup"
#define Registration @"Registration"
#define UserProfile @"UserProfile"
#define ChangePassword @"ChangePassword"
#define StoreList @"StoreList"
#define StoreDetails @"StoreDetails"
#define EventList @"EventList"
#define EventDetails @"EventDetails"

#define TokenValidationService @"TokenValidation.api"
#define MemberLoginService @"MemberLogin.api"
#define GetVerifyCodeService @"GetVerifyCode.api"
#define PhoneNoCountryService @"loadData.do?iddCodeList"
#define GenderService @"Gender.api"
#define AgeGroupService @"AgeGroup.api"
#define RegistrationService @"Registration.api"
#define UserProfileService @"UserProfile.api"
#define ChangePasswordService @"ChangePassword.api"
#define StoreListService @"StoreList.api"
#define StoreDetailsService @"StoreDetails.api"
#define EventListService @"EventList.api"
#define EventDetailsService @"EventDetails.api"

#define STATICPAGELINK @"http://192.168.162.85/cnv/index.html#/"
#define STATICPRICELINK @"home"

@interface apiManager : NSObject
+(apiManager *) defaultManager;
-(AFJSONRequestSerializer*)switchHeaderType:(NSString*)headerType request:(AFJSONRequestSerializer*) requestSerializer;
-(NSString*) switchAPIservice:(NSString*)service;
-(NSString*) getServerHost;

//-(NSString*) contactusLink;
@end
