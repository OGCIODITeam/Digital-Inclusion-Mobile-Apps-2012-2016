//
//  settingManager.h
//  masguru
//
//  Created by jacky on 16/4/15.
//
//

#import "common.h"

@interface settingManager : NSObject
+(settingManager *) defaultManager;
-(void) setUserLang:(NSString*)Lang;
-(void) setDefaultLang;
-(void) setFontSize:(NSString *) value;
-(NSString *) getFontSize;
-(float) getRedColorOfFrameObject:(NSString*)obj;
-(float) getGreenColorOfFrameObject:(NSString*)obj;
-(float) getBlueColorOfFrameObject:(NSString*)obj;
-(float) getBorderWidth;
-(float) getRadiusSize;
-(float) getBodyFontSize;
-(float) getTitleFontSize;
-(float) getDetailFontSize;
-(float) getUserFontSize;

-(NSString*) getCompanyName;
-(NSString*) getCompanyUsername;
-(NSString*) getCompanyPassword;
-(NSString*) getCompanyLogo;
-(NSString*) getContactEmail;
-(NSString*) getWelcomeMessage;
-(UIImage*) getCompanyNavLogo;
-(NSString*) getCompanyID;
-(UIColor *) getBGColor;
-(UIColor *) getTabColor;
-(UIColor *) getTabSelectedColor;
-(UIColor *) getNavColor;
-(UIColor *) getNavTextColor;
-(UIColor *) getTitleTextColor;
-(UIColor *) getDetailTextColor;
-(UIColor *) getBorderColor;
-(UIColor *) getPageColor;
-(UIColor *) getCurrentPageColor;
-(UIColor *) getBadgeColor;
-(UIColor *) getDashboardBorderColor;
-(UIColor *) getUserTextColor;

-(UIButton *) setMainButton:(UIButton*) btn objectName:(NSString*) obj;
-(UIView *) setMainDashboard:(UIView*) view objectName:(NSString*) obj;
-(UIButton *) setCommonButton:(UIButton*) btn;
-(BOOL) getButtonShadow;
@end
