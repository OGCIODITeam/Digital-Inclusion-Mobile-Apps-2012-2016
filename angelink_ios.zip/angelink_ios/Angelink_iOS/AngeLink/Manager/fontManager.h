//
//  fontManager.h
//  CoachnVan_iOS
//
//  Created by Jacky Chan on 15/6/15.
//  Copyright (c) 2015 jacky chan. All rights reserved.
//

#import "common.h"

@interface fontManager : NSObject
+(fontManager *) defaultManager;

-(UIFont*)getMSJHsize:(float)size;
-(UIFont*)getMSJHBoldsize:(float)size;
-(UIFont*)getMyriadProBoldsize:(float)size;
-(UIFont*)getMyriadProRegularsize:(float)size;
-(UIFont*)getMyriadProSemiboldsize:(float)size;
-(UIFont*)getDFHei_Md_HK_BFsize:(float)size;
-(UIFont*)getDFHei_Md_HKP_BFsize:(float)size;
-(UIFont*)getADOBEHEITISTDsize:(float)size;

-(UIFont*)getGoogleIconsize:(float)size;

-(UIFont*)getRegularsize:(float)size;
-(UIFont*)getBoldsize:(float)size;
-(UIFont*)getSemiBoldsize:(float)size;
-(UIFont*)getWeathersize:(float)size;

-(UIFont*)getUserFont;
-(UIFont*)getDetailFont;
-(UIFont*)getTitleFont;

-(float) getWeatherLargeTitle;
-(float) getWeatherMiddleTitle;
-(float) getWeatherSmallTitle;
-(float) getLargeTitle;
-(float) getMiddleTitle;
-(float) getSmallTitle;
-(float) getLargeContact;
-(float) getMiddleContact;
-(float) getSmallContact;

-(float) getSettingFont:(NSString*)Type;

@end
