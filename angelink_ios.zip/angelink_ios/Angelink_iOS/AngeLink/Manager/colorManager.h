//
//  colorManager.h
//  CoachnVan
//
//  Created by Jacky Chan on 26/8/15.
//  Copyright (c) 2015 Jacky Chan. All rights reserved.
//

#import "common.h"

@interface colorManager : NSObject
+(colorManager *) defaultManager;

-(UIColor*)getColorJodeGreen;
-(UIColor*)getColorDarkGreen;
-(UIColor*)getColorGrayGreen;
-(UIColor*)getColorGreen;
-(UIColor*)getColorWhite;
-(UIColor*)getColorBlue;
-(UIColor*)getColorLightYellow;
-(UIColor*)getColorOrange;


-(UIColor*)getColorCode1;
-(UIColor*)getColorCode2;
-(UIColor*)getColorCode3;
-(UIColor*)getColorCode4;
-(UIColor*)getColorCode5;
-(UIColor*)getColorCode6;
-(UIColor*)getColorCode7;
-(UIColor*)getColorCode8;
-(UIColor*)getColorCode9;
-(UIColor*)getColorCode10;

-(UIColor*)getPairingFullCode;
-(UIColor*)getPairingEmptyCode;
@end
