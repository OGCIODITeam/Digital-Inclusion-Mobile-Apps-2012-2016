//
//  dbManager.m
//  CoachnVan
//
//  Created by Jacky Chan on 29/6/15.
//  Copyright (c) 2015 jacky chan. All rights reserved.
//

#import "dbManager.h"

@implementation dbManager
#pragma mark app lifecycle
+ (id)defaultManager {
    static dbManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
    });
    return defaultManager;
}

-(FMDatabaseQueue*)localDb{
    NSString *libraryPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) lastObject];
    NSString *targetPath = [libraryPath stringByAppendingPathComponent:@"local.sqlite"];
    NSString *sourcePath = [[NSBundle mainBundle] pathForResource:DB_FILE ofType:@"sqlite"];
    
    NSFileManager* fm = [NSFileManager defaultManager];
    NSDictionary* attrTargetData = [fm attributesOfItemAtPath:targetPath error:nil];
    NSDictionary* attsSourceData = [fm attributesOfItemAtPath:sourcePath error:nil];
    if (attrTargetData != nil && attsSourceData != nil)
    {
        NSDate *dateT = (NSDate*)[attrTargetData objectForKey: NSFileCreationDate];
        NSDate *dateS = (NSDate*)[attsSourceData objectForKey: NSFileCreationDate];
        if([self dateComparision:dateS andDate2:dateT])
        {
            NSError *error;
            if ([[NSFileManager defaultManager] fileExistsAtPath:targetPath] == YES) {
                [[NSFileManager defaultManager] removeItemAtPath:targetPath error:&error];
                if (![[NSFileManager defaultManager] copyItemAtPath:sourcePath toPath:targetPath error:&error]) {
                    UALogFull(@"error:%@",error);
                    NSString *remark = [NSString stringWithFormat:@"Error:%@",error];
                    [[utilityManager alloc] writeLogFileData:remark event:@"getServerData" module:[[utilityManager alloc] getRootViewModuleName]];
                }
            }
        }
    }
    else {
        if (![[NSFileManager defaultManager] fileExistsAtPath:targetPath]) {
            NSError *error;
            NSString *sourcePath = [[NSBundle mainBundle] pathForResource:DB_FILE ofType:@"sqlite"];
            if(sourcePath.length > 0 && targetPath.length > 0)
            {
                if (![[NSFileManager defaultManager] copyItemAtPath:sourcePath toPath:targetPath error:&error]) {
                    UALogFull(@"error:%@",error);
                    NSString *remark = [NSString stringWithFormat:@"Error:%@",error];
                    [[utilityManager alloc] writeLogFileData:remark event:@"getServerData" module:[[utilityManager alloc] getRootViewModuleName]];
                }
            }
        }
    }
    if (targetPath.length > 0)
    {
        _localDb = [FMDatabaseQueue databaseQueueWithPath:targetPath];
    }
    else
    {
        _localDb = nil;
    }
    return _localDb;
}

-(BOOL)dateComparision:(NSDate*)date1 andDate2:(NSDate*)date2{
    BOOL isTokonValid;
    if ([date1 compare:date2] == NSOrderedDescending) {
        //"date1 is later than date2
        isTokonValid = YES;
    } else if ([date1 compare:date2] == NSOrderedAscending) {
        //date1 is earlier than date2
        isTokonValid = NO;
    } else {
        //dates are the same
        isTokonValid = NO;
        
    }
    return isTokonValid;
}

-(void)dealloc{
    [_localDb close];
}

#pragma mark SQLite function
-(BOOL) insertSQL:(NSString*)tablename tKey:(NSString*)key tValue:(NSString*)value{
    __block BOOL success;
    __block BOOL ended = NO;
    
    
        [self.localDb inDatabase:^(FMDatabase *db) {
            [db setKey:DB_FILE_PWD];
            NSString *query = [NSString stringWithFormat:@"INSERT INTO %@ (%@) VALUES(%@)",tablename,key,value];
            success = [db executeUpdate:query];
            ended = YES;
        }];
        NSCondition *cond = [[NSCondition alloc] init];
        [cond lock];
        while(!ended)
            [cond wait];
        [cond unlock];
    
    NSLog(@"Unknown error finalizing or resetting statement (14: unable to open database file):%@",(success)?@"YES":@"NO");
    return success;
}

-(BOOL) updateSQL:(NSString*)tablename tCol:(NSString*)col tWhere:(NSString*)where{
    __block BOOL success;
    __block BOOL ended = NO;
    
        [self.localDb inDatabase:^(FMDatabase *db) {
            [db setKey:DB_FILE_PWD];
            NSString *query = [NSString stringWithFormat:@"UPDATE %@ SET %@ WHERE %@",tablename,col,where];
            success = [db executeUpdate:query];
            ended = YES;
        }];
        NSCondition *cond = [[NSCondition alloc] init];
        [cond lock];
        while(!ended)
            [cond wait];
        [cond unlock];
    
    return success;
}

-(BOOL) deleteSQL:(NSString*)tablename{
    __block BOOL success;
    __block BOOL ended = NO;
        [self.localDb inDatabase:^(FMDatabase *db) {
            [db setKey:DB_FILE_PWD];
            NSString *query = [NSString stringWithFormat:@"Delete from %@",tablename];
            NSString *reset = [NSString stringWithFormat:@"update SQLITE_SEQUENCE set seq = 0 where name ='%@'",tablename];
            success = [db executeUpdate:query];
            [db executeUpdate:reset];
            ended = YES;
        }];
        NSCondition *cond = [[NSCondition alloc] init];
        [cond lock];
        while(!ended)
            [cond wait];
        [cond unlock];

    return success;
}

-(NSMutableArray*) selectSQL:(NSString*)tablename where:(NSString*)whereStr option:(NSString*)optionStr{
    NSMutableArray *ary_result = [NSMutableArray new];
    __block BOOL ended = NO;

        [self.localDb inDatabase:^(FMDatabase *db) {
            [db setKey:DB_FILE_PWD];
            NSString *where = @"";
            NSString *option = @"";
            if(whereStr.length > 0)
                where = [NSString stringWithFormat:@"WHERE %@",[whereStr stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]]];
            if(optionStr.length > 0)
                option = [NSString stringWithFormat:@"%@ ",[optionStr stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]]];
            NSString *query = [NSString stringWithFormat:@"SELECT * FROM %@ %@ %@",tablename,where,option];
            FMResultSet *rs = [db executeQuery:query];
            while ([rs next]) {
                NSDictionary *dict = [rs resultDictionary];
                [ary_result addObject:dict];
            }
            [rs close];
            ended = YES;
        }];
        NSCondition *cond = [[NSCondition alloc] init];
        [cond lock];
        while(!ended)
            [cond wait];
        [cond unlock];

    if([ary_result isKindOfClass:[NSDictionary class]]){
        NSDictionary *dict = ary_result;
        NSMutableArray *ary = [NSMutableArray new];
        [ary addObject:dict];
        ary_result = ary;
        return ary;
    }
    return ary_result;
}

-(NSMutableArray *) customSQL:(NSString*) query{
    NSMutableArray *ary_result = [NSMutableArray new];
    __block BOOL ended = NO;
    
        [self.localDb inDatabase:^(FMDatabase *db) {
            [db setKey:DB_FILE_PWD];
            FMResultSet *rs = [db executeQuery:query];
            while ([rs next]) {
                NSDictionary *dict = [rs resultDictionary];
                [ary_result addObject:dict];
            }
            [rs close];
            ended = YES;
        }];
        NSCondition *cond = [[NSCondition alloc] init];
        [cond lock];
        while(!ended)
            [cond wait];
        [cond unlock];
    
    return ary_result;
}
@end
