//
//  utilityManager.m
//  CoachnVan_iOS
//
//  Created by jacky chan on 2015/6/3.
//  Copyright (c) 2015年 jacky chan. All rights reserved.
//

#import "utilityManager.h"

@implementation utilityManager

#pragma mark public
#pragma mark app lifecycle
+(id)defaultManager {
    static utilityManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
    });
    return defaultManager;
}

-(CGRect) getScreenSize{
    return [[UIScreen mainScreen] bounds];
}

-(CGFloat) getNavigationBarHeight:(NSObject*)view{
    UIViewController *temp = (UIViewController*)view;
    CGRect appFrame = [[UIScreen mainScreen] applicationFrame];
    appFrame.origin.y += temp.navigationController.navigationBar.frame.size.height;
    appFrame.size.height -= temp.navigationController.navigationBar.frame.size.height;
    if(temp.navigationController.isNavigationBarHidden)
    return 0.0;
    else
    return temp.navigationController.navigationBar.frame.size.height;
}

-(NSDictionary *) readCustomPlist{
    NSString *path = [[NSBundle mainBundle] pathForResource:CUSTOM_PLIST ofType:@"plist"];
    return [[NSDictionary alloc] initWithContentsOfFile:path];
}

-(NSMutableDictionary *) readPlist:(NSString*)filename{
    NSString *path = [[NSBundle mainBundle] pathForResource:filename ofType:@"plist"];
    return [[NSDictionary alloc] initWithContentsOfFile:path];
}

-(float)getUITextViewHeight:(UITextView*) tableView{
    @try {
        CGFloat width = tableView.frame.size.width - 15 - 30 - 15;  //tableView width - left border width - accessory indicator - right border width
        UIFont *font = [[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Contact"]];
        if(font == nil){
            font = [[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Contact"]];
        }
        NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:tableView.text attributes:@{NSFontAttributeName: font}];
        CGRect rect = [attributedText boundingRectWithSize:(CGSize){width, CGFLOAT_MAX}
                                                   options:NSStringDrawingUsesLineFragmentOrigin
                                                   context:nil];
        CGSize size = rect.size;
        size.height = ceilf(size.height);
        size.width  = ceilf(size.width);
        NSLog(@"size.height:%f",size.height);
        return size.height + 30;
    } @catch (NSException *exception) {
        return 30;
    }
}

//NSString to NSDate
-(NSDate*) NSStringToNSDate:(NSString*)dateValue DateFormat:(NSString*) dateFormat{
    UALogFull(@"ToString:%@", dateFormat);
    NSString *currLocale = [[NSLocale currentLocale] localeIdentifier];
    //    if([currLocale hasPrefix:@"zh-Hans"] || [currLocale hasPrefix:@"zh-Hant"] || [currLocale hasPrefix:@"zh_HK"])
    if([[currLocale substringToIndex:2] hasPrefix:@"zh"]){
        dateFormat = [dateFormat stringByReplacingOccurrencesOfString:@"yyyy MMM dd" withString:@"yyyy年MM月dd日"];
        dateFormat = [dateFormat stringByReplacingOccurrencesOfString:@"YYYY MMM dd" withString:@"YYYY年MM月dd日"];
    }
    NSString *dateString = dateValue;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    //    datePicker.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
    
    [dateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:3600*8]]; // GMT+2
    [dateFormatter setDateFormat:dateFormat];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString = [dateFormatter dateFromString:dateString];
    return dateFromString;
}

//NSDate to NSString
-(NSString*) NSDateToNSString:(NSDate*)dateValue DateFormat:(NSString*) DateFormat{
    UALogFull(@"ToString:%@", DateFormat);
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone localTimeZone]];
    NSString *currLocale = [[NSLocale currentLocale] localeIdentifier];
    //    if([currLocale hasPrefix:@"zh-Hans"] || [currLocale hasPrefix:@"zh-Hant"] || [currLocale hasPrefix:@"zh_HK"])
    if([[currLocale substringToIndex:2] hasPrefix:@"zh"])
    {
        DateFormat = [DateFormat stringByReplacingOccurrencesOfString:@"yyyy MMM dd" withString:@"yyyy年MM月dd日"];
        DateFormat = [DateFormat stringByReplacingOccurrencesOfString:@"YYYY MMM dd" withString:@"YYYY年MM月dd日"];
    }
    [dateFormatter setDateFormat:DateFormat];
    NSString *stringDate = [dateFormatter stringFromDate:dateValue];
    return stringDate;
}

//NSDate to Timestamp
-(int) getTimestampFrNSDate:(NSDate*)dateValue{
    return [dateValue timeIntervalSince1970];
}

-(int) compareDateObject:(NSDate*)firstDate secordObject:(NSDate*)secondDate{
    NSTimeInterval distanceBetweenDates = [secondDate timeIntervalSinceDate:firstDate];
    double secondsInMinute = 60;
    //    int secondsBetweenDates = ceil(distanceBetweenDates / secondsInMinute / 60 / 24);
    return ceil(distanceBetweenDates / secondsInMinute / 60);   //return hour
}

-(int) compareDateObject:(NSDate*)firstDate secordObject:(NSDate*)secondDate returnValue:(NSString*)returnType{
    NSTimeInterval distanceBetweenDates = [secondDate timeIntervalSinceDate:firstDate];
    double secondsInMinute = 60;
    //    int secondsBetweenDates = ceil(distanceBetweenDates / secondsInMinute / 60 / 24);
    if([[returnType lowercaseString] isEqualToString:@"hour"])
    return ceil(distanceBetweenDates / secondsInMinute / 60);   //return hour
    else if([[returnType lowercaseString] isEqualToString:@"minute"])
    return ceil(distanceBetweenDates / secondsInMinute);   //return mins
    else if([[returnType lowercaseString] isEqualToString:@"second"])
    return ceil(distanceBetweenDates);   //return mins
    return 0;
}


-(NSDate*) getNSDateFrTimestamp:(int)timestamp{
    return [NSDate dateWithTimeIntervalSince1970:timestamp];
}

-(int) getDateunit:(NSDate*) valDate selectUnit:(NSString*) dateUnit{
    NSDateComponents *components = [[NSCalendar currentCalendar] components: NSCalendarUnitMinute | NSCalendarUnitHour | NSWeekdayCalendarUnit | NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:valDate];
    //    UALogFull(@"components:%@",components);
    if([[dateUnit lowercaseString] isEqualToString:@"year"])
    return (int)[components year];
    else if([[dateUnit lowercaseString] isEqualToString:@"month"])
    return (int)[components month];
    else if([[dateUnit lowercaseString] isEqualToString:@"day"])
    return (int)[components day];
    else if([[dateUnit lowercaseString] isEqualToString:@"hour"])
    return (int)[components hour];
    else if([[dateUnit lowercaseString] isEqualToString:@"mins"])
    return (int)[components minute];
    else if([[dateUnit lowercaseString] isEqualToString:@"weekday"])
    return (int)[components weekday];
    return 0;
}

-(NSString*) getWeekday:(int)value{
    switch (value) {
        case 1:
        return @"SUN";
        break;
        case 2:
        return @"MON";
        break;
        case 3:
        return @"TUE";
        break;
        case 4:
        return @"WED";
        break;
        case 5:
        return @"THU";
        break;
        case 6:
        return @"FRI";
        break;
        case 7:
        return @"SAT";
        break;
    }
    return @"";
}

-(NSString*) ConvertAnotherDateFormat:(NSString*) DateValue beforeDateFormat:(NSString*)bDateFormat afterDateFormat:(NSString*)aDateFormat{
    NSString *currLocale = [[NSLocale currentLocale] localeIdentifier];
    //    if([currLocale hasPrefix:@"zh-Hans"] || [currLocale hasPrefix:@"zh-Hant"] || [currLocale hasPrefix:@"zh_HK"])
    if([[currLocale substringToIndex:2] hasPrefix:@"zh"])
    {
        aDateFormat = [aDateFormat stringByReplacingOccurrencesOfString:@"yyyy MMM dd" withString:@"yyyy年MM月dd日"];
        aDateFormat = [aDateFormat stringByReplacingOccurrencesOfString:@"YYYY MMM dd" withString:@"YYYY年MM月dd日"];
        bDateFormat = [bDateFormat stringByReplacingOccurrencesOfString:@"yyyy MMM dd" withString:@"yyyy年MM月dd日"];
        bDateFormat = [bDateFormat stringByReplacingOccurrencesOfString:@"YYYY MMM dd" withString:@"YYYY年MM月dd日"];
    }
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone localTimeZone]];
    [dateFormatter setDateFormat:aDateFormat];
    NSString *stringDate = [dateFormatter stringFromDate:[self NSStringToNSDate:DateValue DateFormat:bDateFormat]];
    return stringDate;
}

-(NSString*) conventUnicodeToString:(NSString*)value{
    NSData *unicodedStringData = [value dataUsingEncoding:NSUTF8StringEncoding];
    NSString *emojiStringValue = [[NSString alloc] initWithData:unicodedStringData encoding:NSNonLossyASCIIStringEncoding];
    return emojiStringValue;
}

-(NSData*) ConvertImagePathToData:(NSString*)imgFilePath{
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imgFilePath]];
    return imageData;
}

-(void)saveValuetoUserDefaults:(NSDictionary*)valueDict{
    for (NSString* key in valueDict) {
        NSString *value = [valueDict objectForKey:key];
        NSLog(@"Value:%@",value);
        if(value != [ NSNull null ])
        [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    }
}

-(NSString*)getUserDefaultstoString:(NSString*)key{
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

-(void)removeUserDefaultstoString:(NSString*)key{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
}

-(void)removeUserDefaults:(NSDictionary*)valueDict{
    for (NSString* key in valueDict) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    }
}

//Check touch area
-(BOOL) pointInRect:(CGPoint)p rect:(CGRect)r{
    if(p.x < r.origin.x) return FALSE;
    if(p.x > r.origin.x + r.size.width) return FALSE;
    if(p.y < r.origin.y) return FALSE;
    if(p.y > r.origin.y + r.size.height) return FALSE;
    
    return TRUE;
}

#pragma mark get device function
-(NSString*) getPhoneNumber{
    return [self getUserDefaultstoString:@"phone_no"];
}

-(NSString*) getPhoneName{
    return [[UIDevice currentDevice] name];
}

-(NSString*) getUniqueId{
    return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}

#pragma mark create & get path function
-(void)createFolder:(NSString*)folder{
    // Create the folder if necessary
    if (![[NSFileManager defaultManager] fileExistsAtPath:folder])
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:NO attributes:nil error:nil]; //Create folder
}

-(NSString *)documentPath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docDirectory = [paths objectAtIndex:0];
    return docDirectory;
}

-(NSString *)userDocumentPath:(NSString*) userFolder{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docDirectory = [paths objectAtIndex:0];
    return [docDirectory stringByAppendingPathComponent:userFolder];
}

-(BOOL) CreateFile:(NSString*) filename documentFolder:(NSString*) folderName{
    NSString *folderPath = [self userDocumentPath:folderName];
    [self createFolder:folderPath];
    return [self saveFile:filename filetype:[self fileExtension:filename] folderName:folderName isDoucmentFolder:NO];
}

-(NSString*) LoadFilePath:(NSString*) filename  documentFolder:(NSString*) folderName{
    return [NSString stringWithFormat:@"%@/%@",[self userDocumentPath:folderName],filename];
}


-(NSString*) fileMIMEType:(NSString*) file {
    NSFileHandle *readFileHandle = [NSFileHandle fileHandleForReadingAtPath:file];
    NSData *fileHead = [readFileHandle readDataOfLength:100]; // we probably only need 2 bytes. we'll get the first 100 instead.
    NSString *tempPath = [NSHomeDirectory() stringByAppendingPathComponent: @"tmp/fileHead.tmp"];
    [[NSFileManager defaultManager] removeItemAtPath:tempPath error:nil]; // delete any existing version of fileHead.tmp
    if ([fileHead writeToFile:tempPath atomically:YES])
    {
        NSURL* fileUrl = [NSURL fileURLWithPath:file];
        NSURLRequest* fileUrlRequest = [[NSURLRequest alloc] initWithURL:fileUrl cachePolicy:NSURLCacheStorageNotAllowed timeoutInterval:.1];
        
        NSError* error = nil;
        NSURLResponse* response = nil;
        [NSURLConnection sendSynchronousRequest:fileUrlRequest returningResponse:&response error:&error];
        [[NSFileManager defaultManager] removeItemAtPath:tempPath error:nil];
        return [response MIMEType];
    }
    return nil;
}

-(NSString*) fileExtension:(NSString*) mediaType {
    CFStringRef mimeType = (CFStringRef)CFBridgingRetain(mediaType);
    CFStringRef uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassMIMEType, mimeType, NULL);
    CFStringRef extension = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassFilenameExtension);
    //    UALogFull(@"extension:%@",extension);
    return CFBridgingRelease(extension);
}

-(NSString*) filename:(NSString*) file{
    NSArray *parts = [file componentsSeparatedByString:@"/"];
    NSString *filename = [parts lastObject];
    return filename;
}

#pragma mark read & write Json function
-(NSDictionary*) readJsonFile:(NSString*) file isDoucmentFolder:(Boolean) isDoc{
    if(isDoc){
        NSData *dataFromFile = [NSData dataWithContentsOfFile:file];
        //        NSDictionary *resultsDictionary = [dataFromFile objectFromJSONData];
        NSDictionary* resultsDictionary = [NSJSONSerialization JSONObjectWithData:dataFromFile
                                                                          options:kNilOptions
                                                                            error:nil];
        
        return resultsDictionary;
    }
    else{
        NSString *filePath = [[NSBundle mainBundle] pathForResource:file
                                                             ofType:@"json"];
        //        NSData *dataFromFile = [NSData dataWithContentsOfFile:filePath];
        //        NSDictionary *resultsDictionary = [dataFromFile objectFromJSONData];
        
        NSData *dataFromFile = [NSData dataWithContentsOfFile:filePath];
        NSDictionary* resultsDictionary = [NSJSONSerialization JSONObjectWithData:dataFromFile
                                                                          options:kNilOptions
                                                                            error:nil];
        
        return resultsDictionary;
    }
}

-(NSDictionary*) readJsonData:(NSString*)file isDoucmentFolder:(Boolean) isDoc{
    if(isDoc){
        if([[NSFileManager defaultManager] fileExistsAtPath:file]){
            NSData *dataFromFile = [NSData dataWithContentsOfFile:file];
            NSMutableDictionary *resultsDictionary = [dataFromFile objectFromJSONData];
            return resultsDictionary;
        }
        else
        return nil;
    }
    else{
        NSString *folderPath = [self userDocumentPath:@"JSON"];
        [self createFolder:folderPath];
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:file],@"dat"];
        if([[NSFileManager defaultManager] fileExistsAtPath:filepath]){
            NSData *dataFromFile = [NSData dataWithContentsOfFile:filepath];
            NSDictionary* resultsDictionary = [NSJSONSerialization JSONObjectWithData:dataFromFile
                                                                              options:kNilOptions
                                                                                error:nil];
            return resultsDictionary;
        }
        else
        return nil;
    }
}

-(BOOL) writeJsonFile:(NSString*) filename saveData:(NSDictionary*)data{
    NSString *JSON = [data JSONString];
    return [self saveStringFile:JSON Filename:filename filetype:@"json" folderName:@"Json" isDoucmentFolder:NO];
}

-(BOOL) writeJsonFileData:(NSData*)data savePath:(NSString *)filename{
    return [self saveDataFile:data Filename:filename filetype:@"dat" folderName:@"Json" isDoucmentFolder:NO];
}

-(NSData*) readFileData:(NSString*)file isDoucmentFolder:(Boolean) isDoc{
    if(isDoc){
        if([[NSFileManager defaultManager] fileExistsAtPath:file]){
            NSData *dataFromFile = [NSData dataWithContentsOfFile:file];
            return dataFromFile;
        }
        else
        return nil;
    }
    else{
        NSString *folderPath = [self userDocumentPath:@"JSON"];
        [self createFolder:folderPath];
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:file],@"dat"];
        if([[NSFileManager defaultManager] fileExistsAtPath:filepath]){
            NSData *dataFromFile = [NSData dataWithContentsOfFile:filepath];
            return dataFromFile;
        }
        else
        return nil;
    }
}

-(BOOL) removeJsonFile:(NSString*)filename{
    return [self removeDataFile:filename filetype:@"dat" isDoucmentFolder:NO];
}

-(BOOL) removeFile:(NSString*)filename folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc
{
    if(isDoc){
        NSString *filepath = [NSString stringWithFormat:@"%@",[[self documentPath] stringByAppendingPathComponent:filename]];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSError *error;
        BOOL success = [fileManager removeItemAtPath:filepath error:&error];
        if (success) {
            return TRUE;
        }
        else
        {
            NSLog(@"Could not delete file -:%@ ",[error localizedDescription]);
            
        }
    }
    else{
        NSString *folderPath = [self userDocumentPath:folderName];
        [self createFolder:folderPath];
        NSString *filepath = [NSString stringWithFormat:@"%@",[folderPath stringByAppendingPathComponent:filename]];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSError *error;
        BOOL success = [fileManager removeItemAtPath:filepath error:&error];
        if (success) {
            return TRUE;
        }
        else
        {
            NSLog(@"Could not delete file -:%@ ",[error localizedDescription]);
            
        }
    }
    return FALSE;
}

-(BOOL) saveFile:(NSString*)filename filetype:(NSString*)filetype folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc{
    if(isDoc){
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[[self documentPath] stringByAppendingPathComponent:filename],filetype];
        NSFileManager *manager = [NSFileManager defaultManager];
        if ([manager createFileAtPath:filepath contents:nil attributes:nil]) {
            return TRUE;
        }
    }
    else{
        NSString *folderPath = [self userDocumentPath:folderName];
        [self createFolder:folderPath];
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:filename],filetype];
        NSFileManager *manager = [NSFileManager defaultManager];
        if ([manager createFileAtPath:filepath contents:nil attributes:nil]) {
            return TRUE;
        }
    }
    return FALSE;
}

-(BOOL) saveStringFile:(NSString*) stringValue Filename:(NSString*)filename filetype:(NSString*)filetype folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc{
    if(isDoc){
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[[self documentPath] stringByAppendingPathComponent:filename],filetype];
        return [stringValue writeToFile:filepath
                             atomically:YES
                               encoding:NSStringEncodingConversionExternalRepresentation
                                  error:nil];
    }
    else{
        NSString *folderPath = [self userDocumentPath:folderName];
        [self createFolder:folderPath];
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:filename],filetype];
        return [stringValue writeToFile:filepath
                             atomically:YES
                               encoding:NSStringEncodingConversionExternalRepresentation
                                  error:nil];
    }
    return FALSE;
}

-(BOOL) saveDataFile:(NSData*) imageData Filename:(NSString*) filename filetype:(NSString*)filetype folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc{
    @try {
        if(isDoc){
            NSString *filepath = [NSString stringWithFormat:@"%@.%@",[[self documentPath] stringByAppendingPathComponent:filename],filetype];
            return [imageData writeToFile:filepath
                               atomically:YES];
        }
        else{
            NSString *folderPath = [self userDocumentPath:folderName];
            [self createFolder:folderPath];
            NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:filename],filetype];
            NSLog(@"filepath:%@",filepath);
            return [imageData writeToFile:filepath atomically:YES];
        }
    }
    @catch (NSException *exception) {}
    return FALSE;
}

-(NSData*) getDataFile:(NSString*) filename folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc{
    @try {
        if(isDoc){
            NSString *filepath = [NSString stringWithFormat:@"%@",[[self documentPath] stringByAppendingPathComponent:filename]];
            return [NSData dataWithContentsOfFile:[NSURL URLWithString:filepath].path];
        }
        else{
            NSString *folderPath = [self userDocumentPath:folderName];
            [self createFolder:folderPath];
            NSString *filepath = [NSString stringWithFormat:@"%@",[folderPath stringByAppendingPathComponent:filename]];
            NSLog(@"URL:%@",[NSURL URLWithString:filepath]);
            return [NSData dataWithContentsOfFile:[NSURL URLWithString:filepath].path];
        }
    }
    @catch (NSException *exception) {}
    return FALSE;
}

-(NSData*) getDataFileByPath:(NSString*) filePath{
    return [NSData dataWithContentsOfFile:[NSURL URLWithString:filePath].path];
}

-(NSString*) getDataFilePath:(NSString*) filename folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc{
    @try {
        if(isDoc){
            NSString *filepath = [NSString stringWithFormat:@"%@",[[self documentPath] stringByAppendingPathComponent:filename]];
            return filepath;
        }
        else{
            NSString *folderPath = [self userDocumentPath:folderName];
            [self createFolder:folderPath];
            NSString *filepath = [NSString stringWithFormat:@"%@",[folderPath stringByAppendingPathComponent:filename]];
            NSLog(@"URL:%@",[NSURL URLWithString:filepath]);
            return [NSURL URLWithString:filepath].path;
        }
    }
    @catch (NSException *exception) {}
    return @"";
}

-(BOOL) removeDataFile:(NSString*) filename filetype:(NSString*)filetype isDoucmentFolder:(Boolean) isDoc{
    NSError *error;
    if(isDoc){
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[[self documentPath] stringByAppendingPathComponent:filename],filetype];
        return [[NSFileManager defaultManager] removeItemAtPath:filepath error:&error];
    }
    else{
        NSString *folderPath = [self userDocumentPath:@"JSON"];
        [self createFolder:folderPath];
        NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:filename],filetype];
        return [[NSFileManager defaultManager] removeItemAtPath:filepath error:&error];
    }
    return FALSE;
}

-(NSString*) ConvertDictToString:(NSDictionary*)dict{
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:nil];
    NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return json;
}

-(NSDictionary*) ConvertStringToDict:(NSString*)string{
    NSData* data = [string dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data
                                                         options:kNilOptions
                                                           error:nil];
    return json;
}

#pragma mark encoder & decoder String
//-(NSString*)encoderString:(NSString*)value{
//    CocoaSecurityEncoder *encoder = [CocoaSecurityEncoder new];
//    return [encoder base64:[value dataUsingEncoding:NSUTF8StringEncoding]];
//}
//
//-(NSString*)decoderString:(NSString*)value{
//    CocoaSecurityDecoder *decoder = [CocoaSecurityDecoder new];
//    NSData *data = [decoder base64:value];
//    return [self displayDataString:data];
//}

- (NSString *)displayDataString: (NSData *)value {
    return [[NSString alloc] initWithData:value encoding:NSUTF8StringEncoding];
}


//-(void) saveEvent:(NSDictionary*)dict{
//    NSDate *startTime = [self NSStringToNSDate:[dict objectForKey:@"EventStartDate"] DateFormat:DISPLAYDATEFORMATTER];
//    NSDate *endTime = [self NSStringToNSDate:[dict objectForKey:@"EventEndDate"] DateFormat:DISPLAYDATEFORMATTER];
//
//    if(startTime == nil)
//        return ;
//    if(endTime == nil)
//        endTime = [[NSDate alloc] initWithTimeInterval:60*60 sinceDate:startTime];
//
//    EKEventStore *store = [EKEventStore new];
//    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
//        if (!granted) { return; }
//        EKEvent *event = [EKEvent eventWithEventStore:store];
//        event.title = [dict objectForKey:@"EventTitle"];
//        event.startDate = startTime; //today
//        event.endDate = endTime;  //set 1 hour meeting
//        event.calendar = [store defaultCalendarForNewEvents];
//        event.notes = [dict objectForKey:@"EventNotes"];
//        event.URL = [NSURL URLWithString:[dict objectForKey:@"EventURL"]];
//
//        // Set Alerm
//        NSMutableArray *myAlarmsArray = [[NSMutableArray alloc] init];
//        EKAlarm *alarm1 = [EKAlarm alarmWithRelativeOffset:EventAlerm];
//        EKAlarm *alarm2 = [EKAlarm alarmWithRelativeOffset:EventAlerm / 2];
//        [myAlarmsArray addObject:alarm1];
//        [myAlarmsArray addObject:alarm2];
//        event.alarms = myAlarmsArray;
//
//        NSError *err = nil;
//        [store saveEvent:event span:EKSpanThisEvent commit:YES error:&err];
//    }];
//}
//
//-(void) removeEvent:(NSDictionary*)dict{
//    NSDate *startTime = [self NSStringToNSDate:[dict objectForKey:@"EventStartDate"] DateFormat:DISPLAYDATEFORMATTER];
//    NSDate *endTime = [self NSStringToNSDate:[dict objectForKey:@"EventEndDate"] DateFormat:DISPLAYDATEFORMATTER];
//
//    if(startTime == nil)
//        return ;
//    if(endTime == nil)
//        endTime = [[NSDate alloc] initWithTimeInterval:60*60 sinceDate:startTime];
//
//    EKEventStore* store = [EKEventStore new];
//    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
//        if (!granted) { return; }
//        EKEvent* eventToRemove = [store eventWithIdentifier:[dict objectForKey:@"savedEventId"]];
//        eventToRemove.title = [dict objectForKey:@"EventTitle"];
//        eventToRemove.startDate = startTime; //today
//        eventToRemove.endDate = endTime;  //set 1 hour meeting
//        eventToRemove.calendar = [store defaultCalendarForNewEvents];
//        if (eventToRemove) {
//            NSError *err = nil;
//            [store removeEvent:eventToRemove span:EKSpanThisEvent commit:YES error:&err];
//        }
//    }];
//}

-(NSString*) getGeoLang{
    if([[[utilityManager alloc] getUserDefaultstoString:@"displayLang"] isEqualToString:@"tw"])
    return @"zh-tw";
    if([[[utilityManager alloc] getUserDefaultstoString:@"displayLang"] isEqualToString:@"cn"])
    return @"zh-cn";
    return @"en";
}

-(void) popupAnimation:(UIView*) popupView isOpen:(BOOL)isOpen{
    [UIView animateWithDuration:0.2
                          delay:0.4
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         if(isOpen){
                             popupView.frame = CGRectMake(0, [[utilityManager alloc] getScreenSize].size.height - popupView.frame.size.height, popupView.frame.size.width, popupView.frame.size.height);
                         }
                         else{
                             popupView.frame = CGRectMake(0, [[utilityManager alloc] getScreenSize].size.height, popupView.frame.size.width, popupView.frame.size.height);
                         }
                     }
                     completion:^(BOOL finished){
                         
                     }];
}

-(float) calStringInUILabel:(UILabel*)label{
    float widthIs = [label.text boundingRectWithSize:label.frame.size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{ NSFontAttributeName:label.font } context:nil].size.width;
    return widthIs;
}

- (UIImage *)imageFromColor:(UIColor *)color {
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

-(void)setLeftSpaceToTextField:(UITextField*)TextField{
    UIView *leftview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 5)];
    TextField.leftView = leftview;
    TextField.leftViewMode = UITextFieldViewModeAlways;
}

-(void)setButtonToTextField:(UITextField*)TextField Button:(UIButton*)btn Position:(NSString*)position{
    if([[position lowercaseString] isEqualToString:@"left"]){
        TextField.leftView = btn;
        TextField.leftViewMode = UITextFieldViewModeAlways;
    }
    else{
        TextField.rightView = btn;
        TextField.rightViewMode = UITextFieldViewModeAlways;
    }
}

-(void)setImageToTextField:(UITextField *)TextField ImageView:(UIImageView *)img Position:(NSString *)position{
    if([[position lowercaseString] isEqualToString:@"left"]){
        TextField.leftView = img;
        TextField.leftViewMode = UITextFieldViewModeAlways;
    }
    else{
        TextField.rightView = img;
        TextField.rightViewMode = UITextFieldViewModeAlways;
    }
}

-(void) setLabelToTextField:(UITextField*)TextField Label:(UILabel*)lbl Position:(NSString*)position{
    if([[position lowercaseString] isEqualToString:@"left"]){
        TextField.leftView = lbl;
        TextField.leftViewMode = UITextFieldViewModeAlways;
    }
    else{
        TextField.rightView = lbl;
        TextField.rightViewMode = UITextFieldViewModeAlways;
    }
}

-(void)setShadow:(UIView*)view{
    view.layer.masksToBounds = NO;
    view.layer.shadowOffset = CGSizeMake(4, 4);
    view.layer.shadowRadius = 5;
    view.layer.shadowOpacity = 0.4;
}

-(void) setBorder:(UIView*)view{
    view.layer.cornerRadius = [[settingManager alloc] getRadiusSize];
    view.layer.masksToBounds = NO;
    view.layer.borderWidth = [[settingManager alloc] getBorderWidth];
    view.layer.borderColor = [[[settingManager alloc] getBorderColor] CGColor];
}

-(void) setImageViewToCircle:(UIImageView*)img{
    img.layer.cornerRadius = img.frame.size.width/2;
    img.layer.masksToBounds = YES;
    img.layer.borderWidth = [[settingManager alloc] getBorderWidth];
    //    img.layer.borderColor = [[[settingManager alloc] getBorderColor] CGColor];
    img.layer.borderColor = [[UIColor clearColor] CGColor];
}

-(NSMutableArray*) checkNullInArray:(NSMutableArray*)array{
    UALogFull(@"array:%@",array);
    if(array != nil && array.count > 0 && [(NSMutableDictionary*)[array objectAtIndex:0] isKindOfClass:[NSNull class]])
    {
        return nil;
    }
    return array;
}

- (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

- (CAShapeLayer *) addDashedBorderWithColor: (CGColorRef) color view:(UIView*) view {
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    
    CGSize frameSize = view.frame.size;
    
    CGRect shapeRect = CGRectMake(0.0f, 0.0f, frameSize.width, frameSize.height);
    [shapeLayer setBounds:shapeRect];
    [shapeLayer setPosition:CGPointMake( frameSize.width/2,frameSize.height/2)];
    
    [shapeLayer setFillColor:[[UIColor clearColor] CGColor]];
    [shapeLayer setStrokeColor:color];
    [shapeLayer setLineWidth:5.0f];
    [shapeLayer setLineJoin:kCALineJoinRound];
    [shapeLayer setLineDashPattern:
     [NSArray arrayWithObjects:[NSNumber numberWithInt:10],
      [NSNumber numberWithInt:5],
      nil]];
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:shapeRect cornerRadius:0.0];
    [shapeLayer setPath:path.CGPath];
    
    return shapeLayer;
}

-(void)saveImage:(UIImage*) image {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:@"savedImage.jpg"];
    NSData *imageData = UIImageJPEGRepresentation(image,0.8);
    [imageData writeToFile:savedImagePath atomically:NO];
}

-(UIImage*)getImage {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"savedImage.jpg"];
    UIImage *img = [UIImage imageWithContentsOfFile:getImagePath];
    return [self imageWithImage:img scaledToSize:CGSizeMake([self getScreenSize].size.width, 44)];
}

-(UIImage *)generateThumbImage : (NSString *)filepath
{
    NSURL *url = [NSURL fileURLWithPath:filepath];
    
    AVAsset *asset = [AVAsset assetWithURL:url];
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
    imageGenerator.appliesPreferredTrackTransform = YES;
    CMTime time = [asset duration];
    time.value = 0;
    CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:NULL];
    UIImage *thumbnail = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
    
    return thumbnail;
}

-(NSString*) replaceServerDateFormat:(NSString*)value{
    //    return [[value stringByReplacingOccurrencesOfString:@"T" withString:@" "] stringByReplacingOccurrencesOfString:@"-" withString:@"."];
    return [[[value stringByReplacingOccurrencesOfString:@"T" withString:@" "] substringWithRange:NSMakeRange(0, 19)] stringByReplacingOccurrencesOfString:@"-" withString:@"."];
}

-(void) writeErrorLogToTextFile:(NSString*)str event:(NSString*)event module:(NSString*)mod{
    //get the documents directory:
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    //make a file name to write the data to using the documents directory:
    NSString *fileName = [NSString stringWithFormat:@"%@/logfile.txt",
                          documentsDirectory];
    
    //    create log record
    NSString *record = [NSString stringWithFormat:@"%@ - Module:%@ , Remark:%@ , Event:%@",[self NSDateToNSString:[NSDate date] DateFormat:DISPLAYDATEFORMATTER],mod,str,event];
    //create content - four lines of text
    NSString *content = [NSString stringWithFormat:@"%@\n%@",[self getErrorLog],record];
    //save content to the documents directory
    [content writeToFile:fileName
              atomically:NO
                encoding:NSStringEncodingConversionAllowLossy
                   error:nil];
    
}

//-(NSString*) getRootViewModuleName{
//    UINavigationController *menuController = ((AppDelegate*)[[UIApplication sharedApplication] delegate]).nav;
//    return NSStringFromClass([[[menuController viewControllers] lastObject] class]);
//}

- (NSURL *)applicationDocumentsDirectory{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

-(void) exportLogFileToiTune{
    NSString *someText = [self getErrorLog];
    NSError *error = nil;
    NSString *path = [NSString stringWithFormat:@"%@",[[[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"exportLogFile.txt"] absoluteString]];
    //Write to the file
    [someText writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
}

-(NSString *) getErrorLog{
    //get the documents directory:
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    //make a file name to write the data to using the documents directory:
    NSString *fileName = [NSString stringWithFormat:@"%@/logfile.txt",
                          documentsDirectory];
    NSString *content = [[NSString alloc] initWithContentsOfFile:fileName
                                                    usedEncoding:nil
                                                           error:nil];
    //use simple alert from my library (see previous post for details)
    return content;
}

-(BOOL) writeLogFileData:(NSString*)str event:(NSString*)event module:(NSString*)mod{
    NSString *record = [NSString stringWithFormat:@"%@ - Module:%@ , Remark:%@ , Event:%@",[self NSDateToNSString:[NSDate date] DateFormat:DISPLAYDATEFORMATTER],mod,str,event];
    NSString *content = [NSString stringWithFormat:@"%@\n%@",[self readLogFileData:ERROR_LOG_FILE],record];
    NSData* data = [content dataUsingEncoding:NSUTF8StringEncoding];
    return [self saveDataFile:data Filename:ERROR_LOG_FILE filetype:@"dat" folderName:@"Log" isDoucmentFolder:NO];
}

-(NSString*) readLogFileData:(NSString*)file{
    NSString *folderPath = [self userDocumentPath:@"JSON"];
    [self createFolder:folderPath];
    NSString *filepath = [NSString stringWithFormat:@"%@.%@",[folderPath stringByAppendingPathComponent:file],@"dat"];
    if([[NSFileManager defaultManager] fileExistsAtPath:filepath]){
        NSData *dataFromFile = [NSData dataWithContentsOfFile:filepath];
        NSString *str = [[NSString alloc] initWithData:dataFromFile encoding:NSUTF8StringEncoding];
        return str;
    }
    else
    return nil;
}

-(NSString *)htmlFromBodyString:(NSString *)htmlBodyString textFont:(UIFont *)font textColor:(UIColor *)textColor{
    int numComponents = CGColorGetNumberOfComponents([textColor CGColor]);
    
    NSAssert(numComponents == 4 || numComponents == 2, @"Unsupported color format");
    
    // E.g. FF00A5
    NSString *colorHexString = nil;
    
    const CGFloat *components = CGColorGetComponents([textColor CGColor]);
    
    if (numComponents == 4)
    {
        unsigned int red = components[0] * 255;
        unsigned int green = components[1] * 255;
        unsigned int blue = components[2] * 255;
        colorHexString = [NSString stringWithFormat:@"%02X%02X%02X", red, green, blue];
    }
    else
    {
        unsigned int white = components[0] * 255;
        colorHexString = [NSString stringWithFormat:@"%02X%02X%02X", white, white, white];
    }
    
    NSString *HTML = [NSString stringWithFormat:@"<html>\n"
                      "<head>\n"
                      "<style type=\"text/css\">\n"
                      "body {font-family: \"%@\"; font-size: %@; color:#%@;}\n"
                      "</style>\n"
                      "</head>\n"
                      "<body>%@</body>\n"
                      "</html>",
                      font.familyName, @(font.pointSize), colorHexString, htmlBodyString];
    
    return HTML;
}

-(BOOL)isPasswordMatch:(NSString *)pwd withConfirmPwd:(NSString *)cnfPwd {
    if([pwd length]>0 && [cnfPwd length]>0){
        if([pwd isEqualToString:cnfPwd]){
            return TRUE;
        }else{
            return FALSE;
        }
    }else{
        return FALSE;
    }
    return FALSE;
}

-(UIImage *) recolorImage:(UIImage *)originalImage withColor:(UIColor *)color {
    UIGraphicsBeginImageContext(originalImage.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    [color setFill];
    
    CGContextTranslateCTM(context, 0, originalImage.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGContextSetBlendMode(context, kCGBlendModeCopy);
    CGRect rect = CGRectMake(0, 0, originalImage.size.width, originalImage.size.height);
    CGContextDrawImage(context, rect, originalImage.CGImage);
    
    CGContextClipToMask(context, rect, originalImage.CGImage);
    CGContextAddRect(context, rect);
    CGContextDrawPath(context,kCGPathElementMoveToPoint);
    
    UIImage *coloredImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return coloredImg;
}

- (UIImage*) maskImage:(UIImage *)image withMask:(UIImage *)maskImage {
    
    CGImageRef maskRef = maskImage.CGImage;
    
    CGImageRef mask = CGImageMaskCreate(CGImageGetWidth(maskRef),
                                        CGImageGetHeight(maskRef),
                                        CGImageGetBitsPerComponent(maskRef),
                                        CGImageGetBitsPerPixel(maskRef),
                                        CGImageGetBytesPerRow(maskRef),
                                        CGImageGetDataProvider(maskRef), NULL, false);
    
    CGImageRef maskedImageRef = CGImageCreateWithMask([image CGImage], mask);
    UIImage *maskedImage = [UIImage imageWithCGImage:maskedImageRef];
    
    CGImageRelease(mask);
    CGImageRelease(maskedImageRef);
    
    // returns new image with mask applied
    return maskedImage;
}

-(void) TextToSpeech:(NSString*) string{
    AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc]init];
    synthesizer.delegate = self;
    NSLog(@"string:%@",string);
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:string];
    
    NSString *ver = [[UIDevice currentDevice] systemVersion];
    int ver_int = [ver intValue];
    if (ver_int <= 8) {
        [utterance setRate:0.1f];
    }
    else{
        [utterance setRate:0.5f];
    }
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-HK"];
    [synthesizer speakUtterance:utterance];
    
}

- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer
 didFinishSpeechUtterance:(AVSpeechUtterance *)utterance{
    NSLog(@"Finish");
    NSDictionary *userInfo = [[NSDictionary alloc] init];
    [[NSNotificationCenter defaultCenter] postNotificationName: @"TextToSpeech" object:nil userInfo:userInfo];
    [[NSNotificationCenter defaultCenter] postNotificationName: @"infoViewTextToSpeech" object:nil userInfo:userInfo];
}

-(NSNumber *)convertBinaryStringToDecimalNumber:(NSString *)binaryString {
    NSUInteger totalValue = 0;
    for (int i = 0; i < binaryString.length; i++) {
        totalValue += (int)([binaryString characterAtIndex:(binaryString.length - 1 - i)] - 48) * pow(2, i);
    }
    return @(totalValue);
}

-(NSString *)convertDecimalNumberToBinaryString:(NSInteger)value
{
    NSMutableString *string = [NSMutableString string];
    while (value)
    {
        [string insertString:(value & 1)? @"1": @"0" atIndex:0];
        value /= 2;
    }
    return [NSString stringWithString:string];
}

-(NSString*) getCharByString:(NSString*)Value range:(int) point limit:(int) limit{
    return [Value substringWithRange:NSMakeRange(point, limit)];
}

-(UIImage*) getVideoThumbnailImage:(NSString*)filepath{
    NSURL *videoURL = [NSURL fileURLWithPath:filepath];// filepath is your video file path
    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:videoURL options:nil];
    AVAssetImageGenerator *generateImg = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    NSError *error = NULL;
    CMTime time = CMTimeMake(1, 1);
    CGImageRef refImg = [generateImg copyCGImageAtTime:time actualTime:NULL error:&error];
    NSLog(@"error==%@, Refimage==%@", error, refImg);
    UIImage *FrameImage= [[UIImage alloc] initWithCGImage:refImg];
    return FrameImage;
}

- (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (void)textViewDidChange:(UITextView *)textView
{
    CGFloat fixedWidth = textView.frame.size.width;
    CGSize newSize = [textView sizeThatFits:CGSizeMake(fixedWidth, MAXFLOAT)];
    CGRect newFrame = textView.frame;
    newFrame.size = CGSizeMake(fmaxf(newSize.width, fixedWidth), newSize.height);
    textView.frame = newFrame;
}

#pragma mark - Private
- (NSString *)tempZipPath {
    [self saveDataFile:nil Filename:[NSString stringWithFormat:@"%@",[self getUserDefaultstoString:@"memberID"]] filetype:@"zip" folderName:@"temp" isDoucmentFolder:NO];
    NSString *path = [self getDataFilePath:[NSString stringWithFormat:@"%@.zip",[self getUserDefaultstoString:@"memberID"]] folderName:@"temp" isDoucmentFolder:NO];
    return path;
}

- (NSString *)tempUnzipPath {
    NSString *path = [NSString stringWithFormat:@"%@/\%@",
                      NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0],
                      [NSUUID UUID].UUIDString];
    NSURL *url = [NSURL fileURLWithPath:path];
    NSError *error = nil;
    [[NSFileManager defaultManager] createDirectoryAtURL:url
                             withIntermediateDirectories:YES
                                              attributes:nil
                                                   error:&error];
    if (error) {
        return nil;
    }
    return url.path;
}

- (UIColor *) colorWithHexString: (NSString *) hexString {
    NSString *colorString = [[hexString stringByReplacingOccurrencesOfString: @"#" withString: @""] uppercaseString];
    CGFloat alpha, red, blue, green;
    switch ([colorString length]) {
        case 3: // #RGB
            alpha = 1.0f;
            red   = [self colorComponentFrom: colorString start: 0 length: 1];
            green = [self colorComponentFrom: colorString start: 1 length: 1];
            blue  = [self colorComponentFrom: colorString start: 2 length: 1];
            break;
        case 4: // #ARGB
            alpha = [self colorComponentFrom: colorString start: 0 length: 1];
            red   = [self colorComponentFrom: colorString start: 1 length: 1];
            green = [self colorComponentFrom: colorString start: 2 length: 1];
            blue  = [self colorComponentFrom: colorString start: 3 length: 1];
            break;
        case 6: // #RRGGBB
            alpha = 1.0f;
            red   = [self colorComponentFrom: colorString start: 0 length: 2];
            green = [self colorComponentFrom: colorString start: 2 length: 2];
            blue  = [self colorComponentFrom: colorString start: 4 length: 2];
            break;
        case 8: // #AARRGGBB
            alpha = [self colorComponentFrom: colorString start: 0 length: 2];
            red   = [self colorComponentFrom: colorString start: 2 length: 2];
            green = [self colorComponentFrom: colorString start: 4 length: 2];
            blue  = [self colorComponentFrom: colorString start: 6 length: 2];
            break;
        default:
            [NSException raise:@"Invalid color value" format: @"Color value %@ is invalid.  It should be a hex value of the form #RBG, #ARGB, #RRGGBB, or #AARRGGBB", hexString];
            break;
    }
    return [UIColor colorWithRed: red green: green blue: blue alpha: alpha];
}

- (CGFloat) colorComponentFrom: (NSString *) string start: (NSUInteger) start length: (NSUInteger) length {
    NSString *substring = [string substringWithRange: NSMakeRange(start, length)];
    NSString *fullHex = length == 2 ? substring : [NSString stringWithFormat: @"%@%@", substring, substring];
    unsigned hexComponent;
    [[NSScanner scannerWithString: fullHex] scanHexInt: &hexComponent];
    return hexComponent / 255.0;
}
@end
