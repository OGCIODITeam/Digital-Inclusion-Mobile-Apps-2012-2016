//
//  fontManager.m
//  CoachnVan_iOS
//
//  Created by Jacky Chan on 15/6/15.
//  Copyright (c) 2015 jacky chan. All rights reserved.
//

#import "fontManager.h"
#import "AppDelegate.h"

@implementation fontManager
+(id)defaultManager {
    static fontManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
    });
    return defaultManager;
}

-(UIFont*)getWeathersize:(float)size{
    float value = size;
    return [self setHelveticaNeueLTPro_Regular:value];
}

-(UIFont*)getRegularsize:(float)size{
    float value = size;
    return [self setNotoSansCJKtc_Regular:value];
}
    
-(UIFont*)getBoldsize:(float)size{
    float value = size;
    return [self setNotoSansCJKtc_Bold:value];
}
    
-(UIFont*)getSemiBoldsize:(float)size{
    if([[[[utilityManager alloc] getUserDefaultstoString:@"displayLang"] lowercaseString] isEqualToString:@"tw"])
    return [self getMSJHsize:size];
    else if([[[[utilityManager alloc] getUserDefaultstoString:@"displayLang"] lowercaseString] isEqualToString:@"cn"])
    return [self getMSJHsize:size];
    else
    return [self getMyriadProSemiboldsize:size];
}

-(UIFont*) setHelveticaNeueLTPro_Regular:(float)size{
//    [self displayFontFamily];
    return [UIFont fontWithName:@"Helvetica-Light" size:size];
}

-(UIFont*) setNotoSansCJKtc_Regular:(float)size{
    return [UIFont fontWithName:@"NotoSansCJKtc-Regular" size:size];
}
    
-(UIFont*) setNotoSansCJKtc_Bold:(float)size{
    return [UIFont fontWithName:@"NotoSansCJKtc-Bold" size:size];
}
    
    
-(UIFont*)getGoogleIconsize:(float)size{
    return [UIFont fontWithName:@"Material Icons" size:size];
}
    
-(UIFont*)getMSJHsize:(float)size{
    return [UIFont fontWithName:@"Microsoft JhengHei" size:size];
}
    
-(UIFont*)getMSJHBoldsize:(float)size{
    return [UIFont fontWithName:@"Microsoft JhengHei Bold" size:size];
}
    
-(UIFont*)getMyriadProBoldsize:(float)size{
    return [UIFont fontWithName:@"MyriadPro-Bold" size:size];
}
    
-(UIFont*)getMyriadProRegularsize:(float)size{
    return [UIFont fontWithName:@"MyriadPro-Regular" size:size];
}
    
-(UIFont*)getMyriadProSemiboldsize:(float)size{
    return [UIFont fontWithName:@"MyriadPro-Semibold" size:size];
}
-(UIFont*)getDFHei_Md_HK_BFsize:(float)size{
    return [UIFont fontWithName:@"DFHeiMedium-B5" size:size];
}
-(UIFont*)getDFHei_Md_HKP_BFsize:(float)size{
    return [UIFont fontWithName:@"DFPHeiMedium-B5" size:size];
}
-(UIFont*)getADOBEHEITISTDsize:(float)size{
    return [UIFont fontWithName:@"AdobeHeitiStd-Regular" size:size];
}
    
-(UIFont*)getDetailFont{
    return [UIFont systemFontOfSize:[[settingManager alloc] getDetailFontSize]];
}
    
-(UIFont*)getUserFont{
    return [UIFont systemFontOfSize:[[settingManager alloc] getUserFontSize]];
}
    
-(UIFont*)getTitleFont{
    return [UIFont systemFontOfSize:[[settingManager alloc] getTitleFontSize]];
}

-(float) getSettingFont:(NSString*)Type{
    if([[[[settingManager alloc] getFontSize]  lowercaseString] isEqualToString:@"large"]){
        if([Type isEqualToString:@"Title"]){
            return [self getLargeTitle];
        }
        else if([Type isEqualToString:@"Weather"]){
            return [self getWeatherLargeTitle];
        }
        else{
            return [self getLargeContact];
        }
    }
    if([[[[settingManager alloc] getFontSize] lowercaseString] isEqualToString:@"middle"]){
        if([Type isEqualToString:@"Title"]){
            return [self getMiddleTitle];
        }
        else if([Type isEqualToString:@"Weather"]){
            return [self getWeatherMiddleTitle];
        }
        else{
            return [self getMiddleContact];
        }
    }
    if([[[[settingManager alloc] getFontSize]  lowercaseString] isEqualToString:@"small"]){
        if([Type isEqualToString:@"Title"]){
            return [self getSmallTitle];
        }
        else if([Type isEqualToString:@"Weather"]){
            return [self getWeatherSmallTitle];
        }
        else{
            return [self getSmallContact];
        }
    }
    return 0.0;
}

-(float) getLargeTitle{
    return 32.0;
}

-(float) getMiddleTitle{
    return 24.0;
}

-(float) getSmallTitle{
    return 16.0;
}

-(float) getLargeContact{
    return 28.0;
}

-(float) getMiddleContact{
    return 21.0;
}

-(float) getSmallContact{
    return 14.0;
}
-(float) getWeatherLargeTitle{
   return 40.0;
}
-(float) getWeatherMiddleTitle{
   return 24.0;
}
-(float) getWeatherSmallTitle{
   return 16.0; 
}

-(void) displayFontFamily{
    for (NSString *familyName in [UIFont familyNames]) {
        for (NSString *fontName in [UIFont fontNamesForFamilyName:familyName]) {
            NSLog(@"%@", fontName);
        }
    }
}
@end
