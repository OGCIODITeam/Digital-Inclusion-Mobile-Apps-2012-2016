//
//  colorManager.m
//  CoachnVan
//
//  Created by Jacky Chan on 26/8/15.
//  Copyright (c) 2015 Jacky Chan. All rights reserved.
//

#import "colorManager.h"

@implementation colorManager
+(id)defaultManager {
    static colorManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
    });
    return defaultManager;
}

-(UIColor*)getColorJodeGreen{
    return [UIColor colorWithRed:0.0/255.0f green:193.0/255.0f blue:198.0/255.0f alpha:1.0f];
}

-(UIColor*)getColorDarkGreen{
return [UIColor colorWithRed:69.0/255.0f green:105.0/255.0f blue:122.0/255.0 alpha:1.0];
}

-(UIColor*)getColorGrayGreen{
    return [UIColor colorWithRed:173.0/255.0f green:187.0/255.0f blue:188.0/255.0 alpha:1.0];
}

-(UIColor*)getColorGreen{
    return [UIColor colorWithRed:181.0/255.0f green:224.0/255.0f blue:0.0/255.0 alpha:1.0];
}

-(UIColor*)getColorWhite{
 return [UIColor colorWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0 alpha:1.0];
}

-(UIColor*)getColorBlue{
    return [UIColor colorWithRed:2.0/255.0f green:89.0/255.0f blue:177.0/255.0 alpha:1.0];
}

-(UIColor*)getColorLightYellow{
   return [UIColor colorWithRed:255.0/255.0f green:253.0/255.0f blue:233.0/255.0 alpha:1.0];
}

-(UIColor*)getColorOrange{
    return [UIColor colorWithRed:249.0/255.0f green:161.0/255.0f blue:29.0/255.0 alpha:1.0];
}


-(UIColor*)getColorCode1{
    return [UIColor colorWithRed:0.0/255.0f green:193.0/255.0f blue:198.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode2{
    return [UIColor colorWithRed:255.0/255.0f green:253.0/255.0f blue:233.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode3{
    return [UIColor colorWithRed:249.0/255.0f green:161.0/255.0f blue:29.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode4{
    return [UIColor colorWithRed:181.0/255.0f green:224.0/255.0f blue:0.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode5{
    return [UIColor colorWithRed:67.0/255.0f green:105.0/255.0f blue:122.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode6{
    return [UIColor colorWithRed:2.0/255.0f green:89.0/255.0f blue:117.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode7{
    return [UIColor colorWithRed:186.0/255.0f green:196.0/255.0f blue:198.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode8{
    return [UIColor colorWithRed:206.0/255.0f green:216.0/255.0f blue:216.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode9{
    return [UIColor colorWithRed:40.0/255.0f green:66.0/255.0f blue:65.0/255.0 alpha:1.0];
}
-(UIColor*)getColorCode10{
    return [UIColor colorWithRed:6.0/255.0f green:58.0/255.0f blue:63.0/255.0 alpha:1.0];
}


-(UIColor*)getPairingFullCode{
    return [UIColor colorWithRed:181.0/255.0f green:224.0/255.0f blue:0.0/255.0 alpha:1.0];
}

-(UIColor*)getPairingEmptyCode{
    return [UIColor colorWithRed:186.0/255.0f green:196.0/255.0f blue:198.0/255.0 alpha:1.0];
}

@end
