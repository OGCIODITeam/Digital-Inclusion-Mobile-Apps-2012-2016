//
//  connectionManager.m
//  CoachnVan_iOS
//
//  Created by jacky chan on 2015/6/3.
//  Copyright (c) 2015年 jacky chan. All rights reserved.
//

#import "connectionManager.h"
#import "AppDelegate.h"
#import "UIImage+addition.h"

@implementation connectionManager

#pragma mark public
#pragma mark app lifecycle
+ (connectionManager *)defaultManager {
    static connectionManager *defaultManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultManager = [[self alloc] init];
        //        NSMutableDictionary *jsonData = [NSMutableDictionary new];
    });
    return defaultManager;
}

#pragma mark - Download File
-(void)downloadFile:(NSString*)path foldername:(NSString*)foldername progress:(UIProgressView*) pv_loading{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSURL *URL = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        return [NSURL URLWithString:@""];
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
    }];
    [downloadTask resume];
}

-(void)downloadFile:(NSString*)path foldername:(NSString*)foldername progress:(UIProgressView*) pv_loading completionBlock:(void (^)(BOOL succeeded, NSURL *url))completionBlock{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSURL *URL = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request  progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response){
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
        return [documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]];
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error){
        if(pv_loading!=nil)
            pv_loading.hidden = TRUE;
        if ( !error )
        {
            completionBlock(YES,filePath);
        } else{
            completionBlock(NO,nil);
        }
    }];
    if(pv_loading!=nil){
        pv_loading.hidden = FALSE;
        //        [pv_loading setProgressWithDownloadProgressOfTask:downloadTask animated:YES];
    }
    [downloadTask resume];
}

-(void)postRequest:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSDictionary *dict = nil;
    if(parametersDictionary!=nil){
        NSMutableArray *ary = [[NSMutableArray alloc] init];
        [ary addObject:parametersDictionary];
        
        NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                    options:0
                                                                      error:nil];
        NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
        dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    }
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager POST:URL.absoluteString parameters:dict progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSError* error;
        NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                 options:kNilOptions
                                                                   error:&error];
        if([[[jsonDict objectForKey:@"status"] lowercaseString] isEqualToString:@"success"]){
            NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
            if([jsonArray count] > 0){
                NSDictionary* json = [jsonArray objectAtIndex:0];
                completionBlock(true,json);
            }
            else{
                completionBlock(true,nil);
            }
        }
        else{
            completionBlock(false,jsonDict);
        }
        [app hideLoading];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"Error: %@", error);
        completionBlock(false,nil);
        [app hideLoading];
    }];
}

-(void)postArrayReturnArray:(NSString *)urlStr parameters:(NSMutableArray *)parametersArray completionHandler:(void (^)(bool, NSMutableArray*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSDictionary *dict = nil;
    if(parametersArray!=nil){
        NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:parametersArray
                                                                    options:0
                                                                      error:nil];
        NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
        dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    }
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer setTimeoutInterval:300
     ];
    [manager POST:URL.absoluteString parameters:dict progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSError* error;
        NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                 options:kNilOptions
                                                                   error:&error];
        if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"]){
            NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
            completionBlock(true,jsonArray);
        }
        else{
            NSMutableArray *ary = [NSMutableArray new];
            [ary addObject:jsonDict];
            completionBlock(false,ary);
        }
        [app hideLoading];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        completionBlock(false,nil);
        [app hideLoading];
    }];
}

-(void)postRequestReturnArray:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary completionHandler:(void (^)(bool, NSMutableArray*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    
    NSDictionary *dict = nil;
    if(parametersDictionary!=nil){
        NSMutableArray *ary = [[NSMutableArray alloc] init];
        [ary addObject:parametersDictionary];
        
        NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                    options:0
                                                                      error:nil];
        NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
        dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    }
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer setTimeoutInterval:300];
    [manager POST:URL.absoluteString parameters:dict progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSError* error;
        NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                 options:kNilOptions
                                                                   error:&error];
        if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"]){
            NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
            completionBlock(true,jsonArray);
        }
        else{
            NSMutableArray *ary = [NSMutableArray new];
            [ary addObject:jsonDict];
            completionBlock(false,ary);
        }
        
        [app hideLoading];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        completionBlock(false,nil);
        [app hideLoading];
    }];
}

-(void) uploadRequest:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([imageArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[imageArray count];i++){
                NSDictionary *dict = [imageArray objectAtIndex:i];
                NSData *tempImgData = [utility getDataFileByPath:[dict objectForKey:@"image"]];
                UIImage *tempImg = [UIImage imageWithData:tempImgData];
                
                NSLog(@"image description:%@",tempImg.description);
                [formData appendPartWithFileURL:[NSURL fileURLWithPath:[dict objectForKey:@"image"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"imageName"] mimeType:[UIImage contentTypeForImageData:tempImgData] error:nil];
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                      [app hideLoading];
                  }];
    
    [uploadTask resume];
}

-(void) uploadFileArray:(NSString *)urlStr parameters:(NSMutableArray *)parametersArray images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:parametersArray
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([app.mediaArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[app.mediaArray count];i++){
                NSMutableDictionary *dict = [app.mediaArray objectAtIndex:i];
                [formData appendPartWithFileData:[utility getDataFileByPath:[dict objectForKey:@"image"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"imageName"] mimeType:[dict objectForKey:@"fileType"]];
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                      [app hideLoading];
                  }];
    
    [uploadTask resume];
}

-(void) uploadFile:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([app.mediaArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[app.mediaArray count];i++){
                NSMutableDictionary *dict = [app.mediaArray objectAtIndex:i];
                [formData appendPartWithFileData:[utility getDataFileByPath:[dict objectForKey:@"image"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"imageName"] mimeType:[dict objectForKey:@"fileType"]];
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                      [app hideLoading];
                  }];
    
    [uploadTask resume];
}

-(void) checkFBPermission:(BOOL) isReadOnly Controller:(UIViewController*)view completionHandler:(void (^)(bool success, NSDictionary* dict))completionBlock{
    NSDictionary *params = @{};
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                  initWithGraphPath:[NSString stringWithFormat:@"/%@/permissions",[FBSDKAccessToken currentAccessToken].userID]
                                  parameters:params
                                  HTTPMethod:@"GET"];
    [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
                                          id result,
                                          NSError *error) {
        NSLog(@"fetched user:%@", result);
        if (error) {
            completionBlock(false,nil);
        } else {
            NSLog(@"Logged in");
            NSMutableArray *ary = [result objectForKey:@"data"];
            BOOL user_friends = NO;
            BOOL user_posts = NO;
            BOOL email = NO;
            BOOL public_profile = NO;
            BOOL publish_actions = NO;
            for(int i = 0;i<[ary count];i++){
                NSDictionary *dict = [ary objectAtIndex:i];
                if([[dict objectForKey:@"permission"] isEqualToString:@"publish_actions"]){
                    publish_actions = YES;
                }
                else if([[dict objectForKey:@"permission"] isEqualToString:@"user_friends"]){
                    user_friends = YES;
                }
                else if([[dict objectForKey:@"permission"] isEqualToString:@"user_posts"]){
                    user_posts = YES;
                }
                else if([[dict objectForKey:@"permission"] isEqualToString:@"email"]){
                    email = YES;
                }
                else if([[dict objectForKey:@"permission"] isEqualToString:@"public_profile"]){
                    public_profile = YES;
                }
            }
            if(isReadOnly){
                if(user_posts == email == public_profile == user_friends == YES){
                    completionBlock(TRUE,nil);
                }
                else{
                    [self loginFBisReadOnly:YES Controller:view completionHandler:^(bool success, NSDictionary *dict) {
                        if(success){
                            completionBlock(TRUE,nil);
                        }
                        else{
                            completionBlock(FALSE,nil);
                        }
                    }];
                }
            }
            else{
                if(publish_actions == YES){
                    completionBlock(TRUE,nil);
                }
                else{
                    [self loginFBisReadOnly:NO Controller:view completionHandler:^(bool success, NSDictionary *dict) {
                        if(success){
                            completionBlock(TRUE,nil);
                        }
                        else{
                            completionBlock(FALSE,nil);
                        }
                    }];
                }
            }
        }
    }];
}

-(void) getPostFromFB:(NSString*)postID viewcontroller:(UIViewController*)view completionHandler:(void (^)(bool success,  NSDictionary* Dict))completionBlock{
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                  initWithGraphPath:[NSString stringWithFormat:@"/%@",postID]
                                  parameters: @{@"fields":@"attachment,like_count,message,from,created_time"}
                                  HTTPMethod:@"GET"];
    [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
                                          id result,
                                          NSError *error) {
        if (!error) {
            NSDictionary *dict = (NSDictionary*)result;
            NSLog(@"ary:%@",dict);
            completionBlock(true,dict);
        }
        else{
            completionBlock(false,nil);
        }
    }];
}

-(void) getPostDataFromFB:(UIViewController*)view completionHandler:(void (^)(bool success,  NSMutableArray* aryData))completionBlock{
    [self checkFBPermission:YES Controller:view completionHandler:^(bool success, NSDictionary *dict) {
        if(success){
            if ([FBSDKAccessToken currentAccessToken] ) {
                NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:@"full_picture,message,created_time,likes.limit(0).summary(true),comments.summary(true){attachment,created_time,from,like_count,message}",@"fields", nil];
                FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                              initWithGraphPath:[NSString stringWithFormat:@"/%@/posts",[FBSDKAccessToken currentAccessToken].userID]
                                              parameters: params
                                              HTTPMethod:@"GET"];
                [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
                                                      id result,
                                                      NSError *error) {
                    if (!error) {
                        NSDictionary *dict = (NSDictionary*)result;
                        NSMutableArray *ary = [dict objectForKey:@"data"];
                        completionBlock(true,ary);
                    }
                    else{
                        completionBlock(false,nil);
                    }
                }];
            }
        }
    }];
}

-(void) getUserProfileFromFB:(UIViewController*)view completionHandler:(void (^)(bool success,  NSDictionary* jsonData))completionBlock{
    [self checkFBPermission:YES Controller:view completionHandler:^(bool success, NSDictionary *dict) {
        if(success){
            if ([FBSDKAccessToken currentAccessToken] ) {
                FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                              initWithGraphPath:@"/me"
                                              parameters: @{@"fields": @"first_name, last_name, picture.type(large), email, name"}
                                              HTTPMethod:@"GET"];
                [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
                                                      id result,
                                                      NSError *error) {
                    if (!error) {
                        NSDictionary *dict = (NSDictionary*)result;
                        completionBlock(true,dict);
                    }
                    else{
                        completionBlock(false,nil);
                    }
                }];
            }
        }
    }];
}

-(void) sendTextNImageCommentToPostID:(NSString*)PostID message:(NSString *)message imageData:(NSData *)imageData Controller:(UIViewController *)view completionHandler:(void (^)(bool, NSDictionary *))completionBlock{
    [self checkFBPermission:NO Controller:view completionHandler:^(bool success, NSDictionary *dict) {
        if(success){
            if ([FBSDKAccessToken currentAccessToken] ) {
                NSMutableDictionary* photosParams = [NSMutableDictionary new];
                if(imageData != nil){
                    [photosParams setObject:imageData forKey:@"source"];
                }
                if(![message isEqualToString:@""] && message != nil){
                    [photosParams setObject:message forKey:@"message"];
                }
                [[[FBSDKGraphRequest alloc] initWithGraphPath:[NSString stringWithFormat:@"%@/comments",PostID] parameters:photosParams HTTPMethod:@"POST"] startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                    if (!error) {
                        NSDictionary *dict = (NSDictionary*)result;
                        [self getPostFromFB:[dict objectForKey:@"id"] viewcontroller:view completionHandler:^(bool success, NSDictionary *dict) {
                            if(success){                                
                                completionBlock(true,dict);
                            }
                            else{
                                completionBlock(true,nil);
                            }
                        }];
                    }
                    else{
                        completionBlock(false,nil);
                    }
                }];
            }
        }
    }];
}

-(void) sendTextNImageToFB:(NSString *)message imageData:(NSData *)imageData Controller:(UIViewController*)view completionHandler:(void (^)(bool success, NSDictionary* dict))completionBlock{
    [self checkFBPermission:NO Controller:view completionHandler:^(bool success, NSDictionary *dict) {
        if(success){
            if ([FBSDKAccessToken currentAccessToken] ) {
                if(imageData == nil){
                    NSMutableDictionary* photosParams = [NSMutableDictionary new];
                    [photosParams setObject:message forKey:@"message"];
                    [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me/feed/" parameters:photosParams HTTPMethod:@"POST"] startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                        if (!error) {
                            NSDictionary *dict = (NSDictionary*)result;
                            completionBlock(true,dict);
                        }
                        else{
                            completionBlock(false,nil);
                        }
                    }];
                }
                else{
                    NSMutableDictionary* photosParams = [NSMutableDictionary new];
                    [photosParams setObject:imageData forKey:@"source"];
                    [photosParams setObject:message forKey:@"message"];
                    [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me/photos/" parameters:photosParams HTTPMethod:@"POST"] startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                        if (!error) {
                            NSDictionary *dict = (NSDictionary*)result;
                            completionBlock(true,dict);
                        }
                        else{
                            completionBlock(false,nil);
                        }
                    }];
                }
            }
        }
    }];
}

-(void) loginFBisReadOnly:(BOOL) isReadOnly Controller:(UIViewController*)view completionHandler:(void (^)(bool success, NSDictionary* dict))completionBlock{
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    if(isReadOnly){
        [login logInWithReadPermissions:@[@"email",@"user_friends",@"user_likes",@"user_posts"] fromViewController:view handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
            if (error) {
                NSLog(@"Process error");
                completionBlock(false,nil);
            } else if (result.isCancelled) {
                NSLog(@"Cancelled");
                completionBlock(false,nil);
            } else {
                NSLog(@"Logged in");
                completionBlock(true,nil);
            }
        }];
    }
    else{
        [login
         logInWithPublishPermissions: @[@"publish_actions"]
         fromViewController:view
         handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
             if (error) {
                 NSLog(@"Process error");
                 completionBlock(false,nil);
             } else if (result.isCancelled) {
                 NSLog(@"Cancelled");
                 completionBlock(false,nil);
             } else {
                 NSLog(@"Logged in");
                 completionBlock(true,nil);
             }
         }];
    }
}
@end
