//
//  connectionManager.h
//  CoachnVan_iOS
//
//  Created by jacky chan on 2015/6/3.
//  Copyright (c) 2015年 jacky chan. All rights reserved.
//

#import "common.h"
#define ALBUM_DEFAULT @"album/album_default_gen.php"
#define ALBUM_HANDLER @"album/album_handler.php"
#define GET_MY_FD @"relation/get_my_fd_list.php"
#define GET_USER_CURRENT_SIZE @"get_user_size_id.php"
#define UPDATE_DEVICE_TOKEN @"update_device_token.php"
#define REMOVE_USER_WAIT_LIST @"relation/remove_my_wait_list.php"
#define UPDATE_USER_FD_CASE @"relation/update_my_fd_case.php"
#define GET_USER_WAIT_LIST @"relation/get_my_wait_list.php"
#define GET_USER_FD_LIST @"relation/get_my_fd_list.php"
#define GET_USER_SUM_COUNT @"relation/get_sum_count_like.php"
#define GET_USER_INFO_BY_PHONE @"get_user_info_phone.php"
#define GET_USER_INFO_BY_ID @"get_user_info_id.php"
#define SEND_USER_SMS @"sms_send.php"
#define CHECK_SMS_CODE @"sms_check.php"
#define SET_USER_INFO @"set_user_info.php"
#define GET_USER_INFO @"get_user_info.php"
#define GET_WEATHER @"weather.php"
#define GET_BANNER_ADS @"get_ads.php"
#define GET_PUSH_LIST @"setting/select_user_setting.php"
#define SET_USER_PUSH @"setting/update_setting.php"
#define UPDATE_ALL_SETTING @"/setting/update_all_setting.php"
#define CREATE_ALBUM @"album/album_handler.php"
#define ALBUM_PAGE_HANDLER @"album/album_page_handler.php"
#define ALBUM_PAGE_STATUS @"album/update_album_page_status.php"
#define GET_FILE_SIZE @"get_user_size_id.php"
#define ADD_COUNT_LIKE @"relation/add_count_like.php"
#define INSERT_FEEDBACK @"feedback/insert_feedback.php"
#define REQUEST_VIDEO @"album/request_video.php"
#define MSG_NOTICE_LOW_ACTION @"put_msg/msg_notice_low_action.php"
#define UPDATE_USER_BACKUP @"update_user_backup.php"
#define REMOVE_USER_INFO @"remove_user_info.php"


@interface connectionManager : NSObject{
    NSMutableDictionary *jsonData;
    AFJSONRequestSerializer *headerRequest;
}

+(connectionManager *) defaultManager;

-(void) downloadFile:(NSString*)path foldername:(NSString*)foldername progress:(UIProgressView*) pv_loading;
-(void) downloadFile:(NSString*)path foldername:(NSString*)foldername progress:(UIProgressView*) pv_loading completionBlock:(void (^)(BOOL succeeded, NSURL *url))completionBlock;
-(void) postRequest:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary completionHandler:(void (^)(bool, NSDictionary*))completionBlock;
-(void)postArrayReturnArray:(NSString *)urlStr parameters:(NSMutableArray *)parametersArray completionHandler:(void (^)(bool, NSMutableArray*))completionBlock;
-(void)postRequestReturnArray:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary completionHandler:(void (^)(bool, NSMutableArray*))completionBlock;
-(void) uploadRequest:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock;
-(void) uploadFile:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock;
-(void) uploadFileArray:(NSString *)urlStr parameters:(NSMutableArray *)parametersArray images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock;

-(void) getPostFromFB:(NSString*)postID viewcontroller:(UIViewController*)view completionHandler:(void (^)(bool success,  NSDictionary* Dict))completionBlock;
-(void) getPostDataFromFB:(UIViewController*)view completionHandler:(void (^)(bool success,  NSMutableArray* aryData))completionBlock;
-(void) sendTextNImageToFB:(NSString *)message imageData:(NSData *)imageData Controller:(UIViewController*)view completionHandler:(void (^)(bool success, NSDictionary* dict))completionBlock;
-(void) loginFBisReadOnly:(BOOL) isReadOnly Controller:(UIViewController*)view completionHandler:(void (^)(bool success, NSDictionary* dict))completionBlock;
-(void) getUserProfileFromFB:(UIViewController*)view completionHandler:(void (^)(bool success,  NSDictionary* jsonData))completionBlock;
-(void) sendTextNImageCommentToPostID:(NSString*)PostID message:(NSString *)message imageData:(NSData *)imageData Controller:(UIViewController *)view completionHandler:(void (^)(bool, NSDictionary *))completionBlock;
@end
