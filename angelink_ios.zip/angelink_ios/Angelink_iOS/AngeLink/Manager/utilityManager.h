//
//  utilityManager.h
//  CoachnVan_iOS
//
//  Created by jacky chan on 2015/6/3.
//  Copyright (c) 2015年 jacky chan. All rights reserved.
//

#import "common.h"
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 80000
//at least iOS 8 code here
#define TEXTSPEED 0.5f
#else
//lower than iOS 8 code here
#define TEXTSPEED 1.0f
#endif
@import AVFoundation;
@interface utilityManager : NSObject<AVSpeechSynthesizerDelegate>

+(utilityManager *) defaultManager;

-(CGRect) getScreenSize;
-(CGFloat) getNavigationBarHeight:(NSObject*)view;
-(NSDictionary *) readCustomPlist;

-(float)getUITextViewHeight:(UITextView*) tableView;
-(NSDate*) NSStringToNSDate:(NSString*)dateValue DateFormat:(NSString*) dateFormat;
-(NSString*) NSDateToNSString:(NSDate*)dateValue DateFormat:(NSString*) DateFormat;
-(int) getDateunit:(NSDate*) valDate selectUnit:(NSString*) dateUnit;
-(int) getTimestampFrNSDate:(NSDate*)dateValue;
-(NSDate*) getNSDateFrTimestamp:(int)timestamp;
-(NSString*) ConvertAnotherDateFormat:(NSString*) DateValue beforeDateFormat:(NSString*)bDateFormat afterDateFormat:(NSString*)aDateFormat;
-(NSString*) getWeekday:(int)value;
-(int) compareDateObject:(NSDate*)firstDate secordObject:(NSDate*)secondDate;
-(int) compareDateObject:(NSDate*)firstDate secordObject:(NSDate*)secondDate returnValue:(NSString*)returnType;
-(void)saveFBtoUserDefaults:(NSDictionary*)valueDict;
-(void) saveValuetoUserDefaults:(NSDictionary*)valueDict;
-(NSString*) getUserDefaultstoString:(NSString*)key;
-(void) removeUserDefaultstoString:(NSString*)key;
-(void) removeUserDefaults:(NSDictionary*)valueDict;

-(NSString*) ConvertDictToString:(NSDictionary*)dict;
-(NSDictionary*) ConvertStringToDict:(NSString*)string;

-(NSData*) ConvertImagePathToData:(NSString*)imgFilePath;

-(void) saveEvent:(NSDictionary*)dict;
-(void) removeEvent:(NSDictionary*)dict;

//??? Emoji
-(NSString*) conventUnicodeToString:(NSString*)value;

-(BOOL) pointInRect:(CGPoint)p rect:(CGRect)r;

//device info function
-(NSString*) getPhoneNumber;
-(NSString*) getPhoneName;
-(NSString*) getUniqueId;

-(UIImage*) imageFromColor:(UIColor *)color;
-(void) setLeftSpaceToTextField:(UITextField*)TextField;
-(void) setButtonToTextField:(UITextField*)TextField Button:(UIButton*)btn Position:(NSString*)position;
-(void) setImageToTextField:(UITextField*)TextField ImageView:(UIImageView*)img Position:(NSString*)position;
-(void) setLabelToTextField:(UITextField*)TextField Label:(UILabel*)lbl Position:(NSString*)position;
-(void) setShadow:(UIView*)view;
-(void) setBorder:(UIView*)view;
-(void) setImageViewToCircle:(UIImageView*)img;
-(UIImage *) recolorImage:(UIImage *)originalImage withColor:(UIColor *)color;
-(CGFloat) colorComponentFrom: (NSString *) string start: (NSUInteger) start length: (NSUInteger) length;

-(NSString*) documentPath;
-(NSString*) userDocumentPath:(NSString*) userFolder;

-(NSString*) fileMIMEType:(NSString*) file;
-(NSString*) fileExtension:(NSString*) mediaType;
-(NSString*) filename:(NSString*) file;

-(BOOL) CreateFile:(NSString*) filename documentFolder:(NSString*) folderName;
-(NSString*) LoadFilePath:(NSString*) filename  documentFolder:(NSString*) folderName;

//read & write Json file
-(NSDictionary*) readJsonFile:(NSString*) file isDoucmentFolder:(Boolean) isDoc;
-(NSDictionary*) readJsonData:(NSString*)file isDoucmentFolder:(Boolean) isDoc;
-(NSData*) readFileData:(NSString*)file isDoucmentFolder:(Boolean) isDoc;
-(BOOL) writeJsonFile:(NSString*) filename saveData:(NSDictionary*)data;
-(BOOL) writeJsonFileData:(NSData*)data savePath:(NSString *)filename;
-(BOOL) removeFile:(NSString*)filename folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc;
-(BOOL) saveStringFile:(NSString*) stringValue Filename:(NSString*) filename filetype:(NSString*)filetype folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc;
-(BOOL) saveDataFile:(NSData*) imageData Filename:(NSString*) filename filetype:(NSString*)filetype folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc;

-(NSData*) getDataFile:(NSString*) filename folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc;
-(NSString*) getDataFilePath:(NSString*) filename folderName:(NSString*)folderName isDoucmentFolder:(Boolean) isDoc;
-(NSData*) getDataFileByPath:(NSString*) filePath;

-(BOOL) removeJsonFile:(NSString*)filename;

-(NSDictionary *) readPlist:(NSString*)filename;

//encoder & decoder String
-(NSString*) encoderString:(NSString*)value;
-(NSString*) decoderString:(NSString*)value;
-(NSString*) displayDataString: (NSData *)value;

- (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;

//Barcode Generation
//-(UIImage*) getProfileBarCode:(ZXBarcodeFormat) barcodeFormat encodeString:(NSString*) encodeString barCodeSize:(CGRect) size;

-(void) popupAnimation:(UIView*) popupView isOpen:(BOOL)isOpen;
-(float) calStringInUILabel:(UILabel*)label;

-(NSMutableArray*) checkNullInArray:(NSMutableArray*)array;

-(CAShapeLayer*) addDashedBorderWithColor: (CGColorRef) color view:(UIView*) view;

-(void) saveImage:(UIImage*) image;
-(UIImage*) getImage;
-(UIImage *)generateThumbImage : (NSString *)filepath;

-(NSString*) replaceServerDateFormat:(NSString*)value;

-(BOOL) writeLogFileData:(NSString*)str event:(NSString*)event module:(NSString*)mod;
-(void) writeErrorLogToTextFile:(NSString*)str event:(NSString*)event module:(NSString*)mod;
-(NSString*) getErrorLog;
-(void) exportLogFileToiTune;
-(NSString*) getRootViewModuleName;

-(NSString *)htmlFromBodyString:(NSString *)htmlBodyString textFont:(UIFont *)font textColor:(UIColor *)textColor;

-(BOOL)isPasswordMatch:(NSString *)pwd withConfirmPwd:(NSString *)cnfPwd;
-(UIImage*) maskImage:(UIImage *)image withMask:(UIImage *)maskImage;

-(void) TextToSpeech:(NSString*) string;
-(NSString *)convertDecimalNumberToBinaryString:(NSInteger)value;
-(NSNumber *)convertBinaryStringToDecimalNumber:(NSString *)binaryString;
-(NSString*) getCharByString:(NSString*)Value range:(int) point limit:(int) limit;
-(UIImage*) getVideoThumbnailImage:(NSString*)filepath;

- (UIImage *)imageWithColor:(UIColor *)color;

- (void)textViewDidChange:(UITextView *)textView;

- (NSString *)tempZipPath;
- (NSString *)tempUnzipPath;

- (UIColor *) colorWithHexString: (NSString *) hexString;
@end
