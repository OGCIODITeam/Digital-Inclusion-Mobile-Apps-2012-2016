//
//  pushViewController.h
//  AngeLink
//
//  Created by kanhan on 14/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "pushTableViewCell.h"

@interface pushViewController : UIViewController<headerBarViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tv_main;
@property (nonatomic, retain) UIViewController *preView;
@property (nonatomic, retain) NSMutableArray *aryData;
@property (nonatomic, retain) NSString *pushString;
@end
