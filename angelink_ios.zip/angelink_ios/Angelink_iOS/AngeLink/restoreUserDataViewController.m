//
//  restoreUserDataViewController.m
//  AngeLink
//
//  Created by kanhan on 12/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "restoreUserDataViewController.h"

@interface restoreUserDataViewController ()

@end

@implementation restoreUserDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Create a progress bar view and set its appearance
    self.progressBarView = [[TYMProgressBarView alloc] initWithFrame:CGRectMake(0, 0, self.v_download.frame.size.width, self.v_download.frame.size.height)];
    self.progressBarView.barBorderWidth = 0.0;
    self.progressBarView.barFillColor = [UIColor colorWithRed:128.0/255.0 green:222.0/255.0 blue:234.0/255.0 alpha:1.0];
    [self.progressBarView setBarBackgroundColor:[UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:1.0]];
    [self.v_download addSubview:self.progressBarView];
        
    // Set the progress
    self.progressBarView.progress = 0.0f;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(incrementProgress:) userInfo:nil repeats:YES];
    self.lbl_Title.text = @"下載中...";
    self.av_downlad.frame = CGRectMake(0, 0, 100, 100);
    CGAffineTransform transform = CGAffineTransformMakeScale(3.0f, 3.0f);
    self.av_downlad.transform = transform;
    self.av_downlad.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    [self.av_downlad startAnimating];
    [self setFontUI];
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_Title.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    [self.btn_finish.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_finish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_finish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnfinish:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep4ViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(IBAction)pressBtnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Timer

- (void)incrementProgress:(NSTimer *)timer {
    self.progressBarView.progress = self.progressBarView.progress + 0.01f;
    if (self.progressBarView.progress == 1.0) {
        self.progressBarView.progress = 0.0;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}
@end
