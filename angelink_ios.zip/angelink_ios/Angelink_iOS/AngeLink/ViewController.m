//
//  ViewController.m
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "ViewController.h"
#import "albumViewController.h"
#import "popupAngelViewController.h"
#import "AppDelegate.h"

#pragma mark -

@interface ViewController ()
@end

@implementation ViewController

- (BOOL)shouldAutorotate
{
    //    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    return NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTextToSpeech:) name:@"TextToSpeech" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(angelinkNotice:) name:@"angelINK_Message" object:nil];
    UIButton *introButton = [[UIButton alloc] initWithFrame:CGRectMake(20, 0, 70, 68)];
    [introButton setImage:[UIImage imageNamed:@"btn_angel"] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:introButton];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    self.im_weater.layer.cornerRadius=self.im_weater.frame.size.height/2;
    self.im_weater.layer.masksToBounds=YES;
    self.im_weater.layer.borderWidth= 2.0f;
    self.im_weater.layer.borderColor = [[UIColor clearColor] CGColor];
    [self setFontUI];
    [self getBanner];
    [self connectSever];
    [self.btn_TextToSpeech setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.btnFDactive.frame.size.width, 40)];
    [lbl setBackgroundColor:[UIColor colorWithRed:209.0/255.0f green:210.0/255.0f blue:211.0/255.0f alpha:8.0]];
    //    lbl.text = @"即將推出";
    //    lbl.textAlignment = ALIGN_CENTER;
    //    lbl.isAccessibilityElement = false;
    //    lbl.font = [[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Title"]];
    //    lbl.center = CGPointMake(self.btnFDactive.frame.size.width/2, self.btnFDactive.frame.size.height - (lbl.frame.size.height/2));
    //    [self.btnFDactive addSubview:lbl];
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Main_1"];
    UIImage *img2 = [UIImage imageNamed:@"Main_2"];
    UIImage *img3 = [UIImage imageNamed:@"Main_3"];
    UIImage *img4 = [UIImage imageNamed:@"Main_4"];
    UIImage *img5 = [UIImage imageNamed:@"Main_5"];
    UIImage *img6 = [UIImage imageNamed:@"FB_1.2"];
    
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    [aryImg addObject:img4];
    [aryImg addObject:img5];
    [aryImg addObject:img6];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"現時的天氣";
    NSString *str2 = @"讀出現時天文台的天氣警告";
    NSString *str3 = @"致電或查看至親及親友的相關內容";
    NSString *str4 = @"製作及觀看人生紀念冊";
    NSString *str5 = @"查看AngeLINK愛‧連繫的簡介、功能設定及提交意見";
    NSString *str6 = @"登入Facebook及發佈個人最新動態";
    
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    [aryString addObject:str4];
    [aryString addObject:str5];
    [aryString addObject:str6];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_spk.isAccessibilityElement = true;
    self.btn_spk.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_spk.accessibilityLabel = @"天氣預報";
    
    self.btnAlbum.isAccessibilityElement = true;
    self.btnAlbum.accessibilityTraits = UIAccessibilityTraitNone;
    self.btnAlbum.accessibilityLabel = @"人生紀念冊";
    
    self.btnFDlist.isAccessibilityElement = true;
    self.btnFDlist.accessibilityTraits = UIAccessibilityTraitNone;
    self.btnFDlist.accessibilityLabel = @"親友圈";
    
    self.btnSetting.isAccessibilityElement = true;
    self.btnSetting.accessibilityTraits = UIAccessibilityTraitNone;
    self.btnSetting.accessibilityLabel = @"設定";
    
    self.btnFDactive.isAccessibilityElement = true;
    self.btnFDactive.accessibilityTraits = UIAccessibilityTraitNone;
    self.btnFDactive.accessibilityLabel = @"親友動態即將推出";
    
}


-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(IBAction)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(void) registerPage{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep1ViewController"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
}

-(void) mainPage{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
}

-(void) viewWillAppear:(BOOL)animated{
    [self setFontUI];
    [self getBanner];
    [self connectSever];
    if([[utilityManager alloc] getUserDefaultstoString:@"memberID"] != nil){
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"deviceToken"],@"deviceToken",[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id", @"iOS", @"deviceType", nil];
        [[connectionManager alloc] postRequest:UPDATE_DEVICE_TOKEN parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
            NSLog(@"Update Device Token%@",jsonDict);
        }];
    }
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app runGPS];
}

-(void) stopTextToSpeech:(NSNotification *)inNotification {
    [self.btn_TextToSpeech.imageView stopAnimating];
    [self.btn_TextToSpeech.imageView setAnimationImages:nil];
    [self.btn_TextToSpeech setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [self.btn_TextToSpeech addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
    
    //    [self.btn_spk.imageView stopAnimating];
    //    [self.btn_spk.imageView setAnimationImages:nil];
    //    [self.btn_spk setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    //    [self.btn_spk addTarget:self action:@selector(pressBtnInfoSpk:) forControlEvents:UIControlEventTouchUpInside];
}

-(IBAction)pressBtnTextToSpeech:(id)sender{
    [[utilityManager alloc] TextToSpeech:self.WeatherWarning];
    NSMutableArray *imageArray = [NSMutableArray new];
    
    for (int i = 1; i < 5; i ++) {
        [imageArray addObject:[UIImage imageNamed:[NSString stringWithFormat:@"btn_spk_stop%d.png",i]]];
    }
    [self.btn_TextToSpeech.imageView setAnimationImages:[imageArray copy]];
    [self.btn_TextToSpeech.imageView setAnimationDuration:1.0];
    [self.btn_TextToSpeech.imageView startAnimating];
    [self.btn_TextToSpeech removeTarget:nil
                                 action:NULL
                       forControlEvents:UIControlEventAllEvents];
}

-(IBAction)pressBtnFDlist:(id)sender{
    //    NSLog(@"[FBSDKAccessToken currentAccessToken]:%@",[FBSDKAccessToken currentAccessToken]);
    //    if ([FBSDKAccessToken currentAccessToken] ) {
    //        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
    //                                                                 bundle: nil];
    //        UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"circleViewController"];
    //        [[self navigationController] pushViewController:vc animated:TRUE];
    //    }
    //    else{
    //        [[connectionManager alloc] loginFBisReadOnly:YES Controller:self completionHandler:^(bool success, NSDictionary *dict) {
    //            if(success){
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"circleViewController"];
    [[self navigationController] pushViewController:vc animated:TRUE];
    //            }
    //        }];
    //    }
}

-(IBAction)pressBtnChat:(id)sender{
    NSLog(@"[FBSDKAccessToken currentAccessToken]:%@",[FBSDKAccessToken currentAccessToken]);
    if ([FBSDKAccessToken currentAccessToken] ) {
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"fdActViewController"];
        [[self navigationController] pushViewController:vc animated:TRUE];
    }
    else{
        [[connectionManager alloc] loginFBisReadOnly:YES Controller:self completionHandler:^(bool success, NSDictionary *dict) {
            if(success){
                UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                         bundle: nil];
                UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"fdActViewController"];
                [[self navigationController] pushViewController:vc animated:TRUE];
            }
        }];
    }
    
    
}

-(IBAction)pressBtnAlbum:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"albumViewController"];
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(IBAction)pressBtnSetting:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"settingViewController"];
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_temp.font = self.lbl_per.font = [font getWeathersize:[font getSettingFont:@"Weather"]];
    self.lbl_lastUpdate.font = [font getWeathersize:[font getSettingFont:@"Weather"]];
    self.lbl_temp.textColor = self.lbl_per.textColor = self.lbl_lastUpdate.textColor = [UIColor colorWithRed:97.0/255.0 green:97.0/255.0 blue:97.0/255.0 alpha:1.0];
    [self.btnFDlist setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btnAlbum setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btnFDactive setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btnSetting setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_TextToSpeech setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_spk setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_close setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) connectSever{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"zh",@"lang", nil];
    
    connectionManager *connect = [[connectionManager alloc] init];
    [connect postRequest:GET_WEATHER parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            NSDictionary *dict = [jsonDict objectForKey:@"CurrentWeather"];
            NSDictionary *dictWeatherWarning = [jsonDict objectForKey:@"WeatherWarning"];
            self.lbl_temp.text = [dict objectForKey:@"temp"];
            self.lbl_temp.isAccessibilityElement = true;
            self.lbl_temp.accessibilityTraits = UIAccessibilityTraitNone;
            self.lbl_temp.accessibilityLabel = [NSString stringWithFormat:@"氣溫攝氏%@度",self.lbl_temp.text];
            
            self.lbl_per.text = [dict objectForKey:@"humidity"];
            self.lbl_per.isAccessibilityElement = true;
            self.lbl_per.accessibilityTraits = UIAccessibilityTraitNone;
            NSString *temp = @"相對濕度";
            self.lbl_per.accessibilityLabel = [NSString stringWithFormat:@"%@%@%%",temp,self.lbl_per.text];
            
            [self.im_weater setImageWithURL:[NSURL URLWithString:[dict objectForKey:@"image"]] placeholderImage:[UIImage imageNamed:@""]];
            self.WeatherWarning = [dictWeatherWarning objectForKey:@"message"];
            self.lbl_lastUpdate.text = @"";
            self.connectionTime = [NSDate date];
            if(!self.timer.isValid){
                self.timer = [NSTimer scheduledTimerWithTimeInterval: 60.0
                                                              target: self
                                                            selector:@selector(onTick:)
                                                            userInfo: nil repeats:YES];
            }
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"錯誤" message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
        }
    }];
}

-(void)onTick:(NSTimer*)timer
{
    utilityManager *utility = [[utilityManager alloc] init];
    int compare = [utility compareDateObject:self.connectionTime secordObject:[NSDate date] returnValue:@"minute"];
    self.lbl_lastUpdate.text = [NSString stringWithFormat:@"上次連線%d分鐘前",compare];
    self.lbl_lastUpdate.isAccessibilityElement = true;
    self.lbl_lastUpdate.accessibilityTraits = UIAccessibilityTraitNone;
    self.lbl_lastUpdate.accessibilityLabel = self.lbl_lastUpdate.text;
    
}

-(void) setWeatherUI{
    
}

-(void) getBanner{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"zh",@"lang", nil];
    connectionManager *connect = [[connectionManager alloc] init];
    [connect postRequestReturnArray:GET_BANNER_ADS parameters:dict completionHandler:^(bool status, NSMutableArray *JsonArray) {
        if(status)
        {
            int randomInt = arc4random() % [JsonArray count];
            self.bannerDict = [JsonArray objectAtIndex:randomInt];
            [self.iv_banner sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_IMAGE,[self.bannerDict objectForKey:@"imagePath"]]]  placeholderImage:[UIImage imageNamed:@""]];
            UILongPressGestureRecognizer *singleTap = [[UILongPressGestureRecognizer alloc] initWithTarget:self
                                                                                                    action:@selector(singleTapGestureCaptured:)];
            [self.iv_banner addGestureRecognizer:singleTap];
            [self.iv_banner setMultipleTouchEnabled:YES];
            [self.iv_banner setUserInteractionEnabled:YES];
            self.iv_banner.isAccessibilityElement = true;
            self.iv_banner.accessibilityTraits = UIAccessibilityTraitNone;
            self.iv_banner.accessibilityLabel = @"廣告";
        }
    }];
}

- (void)singleTapGestureCaptured:(UIGestureRecognizer *)recognizer {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[self.bannerDict objectForKey:@"description"]]];
}

-(void) angelinkNotice:(NSNotification *)inNotification {
    NSDictionary *dict = [inNotification userInfo];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupAngelViewController *vc = (popupAngelViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupAngelViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    NSString *str = [dict objectForKey:@"tickerText"];
    str = [str stringByReplacingOccurrencesOfString:@"</br>" withString:@"\n"];
    [vc createUIview:[dict objectForKey:@"title"] setMessage:str setImage:[dict objectForKey:@"image"]];
    [self presentViewController:vc animated:YES completion:^{
        
    }];
    
}
@end
