//
//  albumViewController.m
//  AngeLink
//
//  Created by kanhan on 26/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "albumViewController.h"
#import "albumDetailViewController.h"
#import "fdRecord.h"

@interface albumViewController ()

@end

@implementation albumViewController
static NSString * const albumCollectionViewCellKind = @"albumCollectionViewCell";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = YES;
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = @"人生紀念冊";
    header.delegate = self;
    [self.view addSubview:header];
//    header.hidden = YES;
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    [self getServerUserAlbum];
    
    [self.cv_main registerNib:[UINib nibWithNibName:albumCollectionViewCellKind bundle:nil] forCellWithReuseIdentifier:albumCollectionViewCellKind];
    [self.cv_main setBackgroundColor:[UIColor clearColor]];
    self.cv_main.delegate = self;
    self.cv_main.dataSource = self;
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.0"];
    [aryImg addObject:img1];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"圖片顯示自己及可觀看的親友圈內的人生紀念冊\n點擊以觀看內容";
    [aryString addObject:str1];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    [self.btn_close setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_spk setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}

-(void)tapDetected{
    self.infoNum++;
    if(self.infoNum < [self.aryImg count]){
        self.im_info.image = [self.aryImg objectAtIndex:self.infoNum];
    }
    else{
        [[utilityManager alloc] popupAnimation:self.v_info isOpen:NO];
    }
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}


-(void) getServerUserAlbum{
    
    connectionManager *connect = [[connectionManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:[utility getUserDefaultstoString:@"memberID"],@"userFrom",@"1",@"isBestFd", nil];
    [connect postRequestReturnArray:GET_MY_FD parameters:dict completionHandler:^(bool status, NSMutableArray *jsonArray) {
        if(self.aryData == nil)
            self.aryData = [NSMutableArray new];
        else
            [self.aryData removeAllObjects];
        
        utilityManager *utility = [[utilityManager alloc] init];
        NSDictionary *myselfDict = [NSDictionary dictionaryWithObjectsAndKeys:[utility getUserDefaultstoString:@"memberID"],@"user_id",
                                    [utility getUserDefaultstoString:@"username"],@"name",
                                    [utility getUserDefaultstoString:@"mobile"],@"phone",
                                    [utility getUserDefaultstoString:@"phoneAreaCode"],@"phoneAreaCode",
                                    [utility getUserDefaultstoString:@"imagePath"],@"imagePath",
                                    nil];
        
        fdRecord *record = [[fdRecord alloc] initWithDict:myselfDict];
        [self.aryData addObject:record];
        
        if(status)
        {
            for (int i=0; i<[jsonArray count]; i++) {
                fdRecord *record = [[fdRecord alloc] initWithDict:[jsonArray objectAtIndex:i]];
                [self.aryData addObject:record];
            }
            
        }
//        else{
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Server Error" message:@"Server error please try again later!!" delegate:self cancelButtonTitle:nil otherButtonTitles: @"Go back",nil];
//            alert.delegate = self;
//            [alert show];
//        }
        [self.cv_main reloadData];
    }];
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.aryData count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    fontManager *font = [[fontManager alloc] init];
    albumCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:albumCollectionViewCellKind
                                                                              forIndexPath:indexPath];
    cell.lbl_albumname.font =  [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.lbl_albumname.textAlignment = ALIGN_CENTER;
    cell.lbl_albumname.lineBreakMode = LINE_BREAK_WORD_WRAP;
    cell.lbl_albumname.numberOfLines = 2;
    if(indexPath.row ==0){
        cell.lbl_albumname.text = @"我的人生紀念冊";
        fdRecord *record = [self.aryData objectAtIndex:indexPath.row];
        cell.recordDict = [record toDict];
        cell.iv_bg.image = [UIImage imageNamed:@"btn_BkMe"];
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_IMAGE,record.imagePath]];
        [cell.iv_cover setImageWithURL:url placeholderImage:[UIImage imageNamed:@"IMG_bk_dairy"]];
    }
    else{
        fdRecord *record = [self.aryData objectAtIndex:indexPath.row];
        cell.recordDict = [record toDict];
        cell.lbl_albumname.text = [NSString stringWithFormat:@"%@的人生紀念冊",record.name];
        cell.iv_bg.image = [UIImage imageNamed:@"btn_Bkbg"];
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_IMAGE,record.imagePath]];
        [cell.iv_cover setImageWithURL:url placeholderImage:[UIImage imageNamed:@"IMG_bk_dairy"]];
    }
    cell.iv_countMark.hidden = YES;
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width / 2 - 20, self.view.frame.size.width / 2 - 20);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath  {
    albumCollectionViewCell *cell = [self.cv_main cellForItemAtIndexPath:indexPath];
    fdRecord *record = [[fdRecord alloc] initWithDict:cell.recordDict];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    albumDetailViewController *vc = (albumDetailViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"albumDetailViewController"];
    vc.albumTitle = cell.lbl_albumname.text;
    vc.userDict = [record toDict];
    [vc updateUI];
    //    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"albumDetailViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        [self pressBtnback:nil];
    }
}

-(void)getUserCurrentSize{
    connectionManager *connect = [[connectionManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:[utility getUserDefaultstoString:@"memberID"],@"user_id", nil];
    [connect postRequest:GET_USER_CURRENT_SIZE parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            [utility saveValuetoUserDefaults:jsonDict];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
    self.navigationController.navigationBar.hidden = YES;
 }


@end
