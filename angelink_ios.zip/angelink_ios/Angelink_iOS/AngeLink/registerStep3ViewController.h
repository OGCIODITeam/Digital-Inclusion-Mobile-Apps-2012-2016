//
//  registerStep3ViewController.h
//  AngeLink
//
//  Created by kanhan on 3/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface registerStep3ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *iv_pic;
@property (weak, nonatomic) IBOutlet UIButton *btn_cam;
@property (weak, nonatomic) IBOutlet UIButton *btn_lib;
@property (weak, nonatomic) IBOutlet UILabel *lbl_tittle;
@property (weak, nonatomic) IBOutlet UILabel *lbl_name;
@property (weak, nonatomic) IBOutlet UILabel *lbl_mobile;
@property (weak, nonatomic) IBOutlet UITextField *tf_name;
@property (weak, nonatomic) IBOutlet UILabel *lbl_mobileNo;
@property (weak, nonatomic) IBOutlet UIScrollView *sv_info;
@property (weak, nonatomic) IBOutlet UIButton *btn_update;
@property (weak, nonatomic) IBOutlet UILabel *lbl_birth;
@property (weak, nonatomic) IBOutlet UIButton *btn_dateDropdown;
@property (weak, nonatomic) IBOutlet UIButton *btn_calFormat;
@property (nonatomic, assign) BOOL isLunarDate;
@property (nonatomic, retain) UIImage* originalImage;
-(void) updateSelectedDate;
@end
