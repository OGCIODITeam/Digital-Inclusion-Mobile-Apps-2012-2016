//
//  addPageImgViewController.m
//  AngeLink
//
//  Created by kanhan on 26/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "addPageImgViewController.h"
#import "AppDelegate.h"
#import "UIImage+addition.h"
#import "albumPageObj.h"
#import "albumObj.h"

#define FILENAME @"audioFile.aac"

@interface addPageImgViewController ()

@end

@implementation addPageImgViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[utilityManager alloc] popupAnimation:self.v_popup isOpen:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTextToSpeech:) name:@"TextToSpeech" object:nil];
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = self.headerTitle;
    header.delegate = self;
    [self.view addSubview:header];
    
    arrayData = [[NSArray alloc] initWithArray:[NSArray arrayWithObjects:@"btn_bk_layout",@"btn_bk_layout2",nil]];
    
    dropDownView = [[DropDownView alloc] initWithArrayData:arrayData cellHeight:50 heightTableView:100 paddingTop:-8 paddingLeft:-5 paddingRight:-10 refView:self.btn_dropdown animation:BLENDIN openAnimationDuration:1 closeAnimationDuration:1];
    
    dropDownView.delegate = self;
    
    [self.view addSubview:dropDownView.view];
    self.position = @"0";
    self.isAudio = NO;
    self.navigationController.navigationBar.hidden = YES;
    self.txt_box.delegate = self;
    
    fontManager *font = [[fontManager alloc] init];
    [self.btn_popupClose.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_popupClose setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_popupClose setTitle:@"關閉" forState:UIControlStateNormal];
    [self.btn_popupSel.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_popupSel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_popupSel setTitle:@"選擇" forState:UIControlStateNormal];
    if(self.aryTime == nil){
        self.aryTime = [NSMutableArray new];
    }
    self.residenceTime = @"3";
    [self.sel_time setTitle:@"3秒" forState:UIControlStateNormal];
    [self.aryTime addObject:[NSString stringWithFormat:@"3秒"]];
    [self.aryTime addObject:[NSString stringWithFormat:@"5秒"]];
    [self.aryTime addObject:[NSString stringWithFormat:@"7秒"]];
    [self.aryTime addObject:[NSString stringWithFormat:@"10秒"]];
    [self.aryTime addObject:[NSString stringWithFormat:@"15秒"]];
    [self.aryTime addObject:[NSString stringWithFormat:@"20秒"]];
    if(self.pageRecord){
        utilityManager *utility =[[utilityManager alloc] init];
        connectionManager *connect =[[connectionManager alloc] init];
        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
        [self.sel_time setTitle:objPage.residenceTime forState:UIControlStateNormal];
        
        if(![objPage.imagePath isEqualToString:@""])
        {
            NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,objPage.imagePath];
            [connect downloadFile:urlPath foldername:@"temp" progress:nil completionBlock:^(BOOL succeeded, NSURL *url) {
                
                NSData *imageData1 = [utility ConvertImagePathToData:[url absoluteString]];
                self.originalImage  = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
                self.iv_inputImg.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:@"UploadImage" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
                {
                    NSData *imageData1 = [[utilityManager alloc] getDataFile:@"UploadImage.jpeg" folderName:@"temp" isDoucmentFolder:NO];
                    self.iv_inputImg.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
                }
                self.txt_box.frame = CGRectMake(self.txt_box.frame.origin.x, self.txt_box.frame.origin.y, self.iv_inputImg.frame.origin.x - self.txt_box.frame.origin.x - 10, self.txt_box.frame.size.height);
            }];
        }
        if(![objPage.audioPath isEqualToString:@""]){
            NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,objPage.audioPath];
            [connect downloadFile:urlPath foldername:@"temp" progress:nil completionBlock:^(BOOL succeeded, NSURL *url) {
                if(url != nil)
                {
                    NSData *data = [[utilityManager alloc] getDataFileByPath:[url absoluteString]];
                    if([utility saveDataFile:data Filename:@"audioFile" filetype:@"aac" folderName:@"temp" isDoucmentFolder:NO]){
                        NSError *error = nil;
                        self.isAudio = YES;
//                        NSURL *outputFileURL = [NSURL URLWithString:[[utilityManager alloc] LoadFilePath:FILENAME documentFolder:@"temp"]];
                        
                        // Setup audio session
                        AVAudioSession *session = [AVAudioSession sharedInstance];
                        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
//                        int flags = AVAudioSessionSetActiveFlags_NotifyOthersOnDeactivation;
//                        [session setActive:NO withFlags:flags error:nil];
                        // Define the recorder setting
                        NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
                        [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
                        [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
                        [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
                        
                        
                        NSURL *url = [NSURL fileURLWithPath:[utility getDataFilePath:@"audioFile.aac" folderName:@"temp" isDoucmentFolder:NO]];
                        // Initiate and prepare the recorder

                        self.recorder = [[AVAudioRecorder alloc] initWithURL:url settings:recordSetting error:&error];
                        if (error)
                        {
                            NSLog(@"error: %@", [error localizedDescription]);
                            
                        }
                        self.recorder.delegate = self;
                        self.recorder.meteringEnabled = YES;
                        [self.recorder prepareToRecord];
                        self.sel_time.enabled = NO;
                    }
                }
                else{
                    if([[utilityManager alloc] CreateFile:FILENAME documentFolder:@"temp"])
                    {
                        NSError *error = nil;
                        NSURL *outputFileURL = [NSURL URLWithString:[[utilityManager alloc] LoadFilePath:FILENAME documentFolder:@"temp"]];
                        
                        // Setup audio session
                        AVAudioSession *session = [AVAudioSession sharedInstance];
                        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
                        
                        // Define the recorder setting
                        NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
                        
                        [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
                        [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
                        [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
                        
                        // Initiate and prepare the recorder
                        self.recorder = [[AVAudioRecorder alloc] initWithURL:outputFileURL settings:recordSetting error:&error];
                        if (error)
                        {
                            NSLog(@"error: %@", [error localizedDescription]);
                            
                        }
                        
                        self.recorder.delegate = self;
                        self.recorder.meteringEnabled = YES;
                        [self.recorder prepareToRecord];
                    }
                }
            }];
        }
        if(![objPage.description isEqualToString:@""]){
            self.txt_box.text = objPage.albumDescription;
        }
        self.residenceTime = objPage.residenceTime;
        [self.sel_time setTitle:@"3秒" forState:UIControlStateNormal];
        [self.sel_time setTitle:[NSString stringWithFormat:@"%@秒",objPage.residenceTime] forState:UIControlStateNormal];
        
        [self setViewUI];
        if(self.mediaArray == nil){
            self.mediaArray = [NSMutableArray new];
        }
        
    }
    else{
        // Do any additional setup after loading the view.
        [self setViewUI];
        if(self.mediaArray == nil){
            self.mediaArray = [NSMutableArray new];
        }
        if([[utilityManager alloc] CreateFile:FILENAME documentFolder:@"temp"])
        {
            NSURL *outputFileURL = [NSURL URLWithString:[[utilityManager alloc] LoadFilePath:FILENAME documentFolder:@"temp"]];
            
            // Setup audio session
            AVAudioSession *session = [AVAudioSession sharedInstance];
            [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
            
            // Define the recorder setting
            NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
            
            [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
            [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
            [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
            
            // Initiate and prepare the recorder
            self.recorder = [[AVAudioRecorder alloc] initWithURL:outputFileURL settings:recordSetting error:NULL];
            self.recorder.delegate = self;
            self.recorder.meteringEnabled = YES;
            [self.recorder prepareToRecord];
        }
    }
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.2.2_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.2.2_2"];
    UIImage *img3 = [UIImage imageNamed:@"Book_6.2.2_3"];
    UIImage *img4 = [UIImage imageNamed:@"Book_6.2.2_4"];
    UIImage *img5 = [UIImage imageNamed:@"Book_6.2.2_5"];
    UIImage *img6 = [UIImage imageNamed:@"Book_6.2.2_6"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    [aryImg addObject:img4];
    [aryImg addObject:img5];
    [aryImg addObject:img6];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"為自訂頁面加入即時拍攝圖片";
    NSString *str2 = @"從手機圖片庫選擇圖片";
    NSString *str3 = @"加入文字內容";
    NSString *str4 = @"加入即時錄音內容";
    NSString *str5 = @"播放即時錄音內容";
    NSString *str6 = @"設定這頁在短片中的停留時間";
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    [aryString addObject:str4];
    [aryString addObject:str5];
    [aryString addObject:str6];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_cam.isAccessibilityElement = true;
    self.btn_cam.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_cam.accessibilityLabel = @"相機";
    
    self.btn_lib.isAccessibilityElement = true;
    self.btn_lib.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_lib.accessibilityLabel = @"照片庫";
    
    self.btn_dropdown.isAccessibilityElement = true;
    self.btn_dropdown.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_dropdown.accessibilityLabel = @"選擇位置";
    
    self.btn_textToVoice.isAccessibilityElement = true;
    self.btn_textToVoice.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_textToVoice.accessibilityLabel = @"文字語音";

    self.btn_recorder.isAccessibilityElement = true;
    self.btn_recorder.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_recorder.accessibilityLabel = @"錄音";

    self.btn_play.isAccessibilityElement = true;
    self.btn_play.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_play.accessibilityLabel = @"播放";

    self.sel_time.isAccessibilityElement = true;
    self.sel_time.accessibilityTraits = UIAccessibilityTraitNone;
    self.sel_time.accessibilityLabel = @"選擇時間";

    self.btn_saveNquit.isAccessibilityElement = true;
    self.btn_saveNquit.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_saveNquit.accessibilityLabel = @"保存並退出";

    self.btn_saveNnew.isAccessibilityElement = true;
    self.btn_saveNnew.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_saveNnew.accessibilityLabel = @"保存並新增頁面";

    self.btn_recorder_stop.isAccessibilityElement = true;
    self.btn_recorder_stop.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_recorder_stop.accessibilityLabel = @"停止錄音";

    self.btn_stop.isAccessibilityElement = true;
    self.btn_stop.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_stop.accessibilityLabel = @"停止播放";

    self.btn_popupClose.isAccessibilityElement = true;
    self.btn_popupClose.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_popupClose.accessibilityLabel = @"關閉彈出頁面";
    
    self.btn_popupSel.isAccessibilityElement = true;
    self.btn_popupSel.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_popupSel.accessibilityLabel = @"彈出頁面";
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void)pressBtnback:(id)sender{
    if(self.pageRecord){
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(IBAction)pressSelPosition:(id)sender{
//    UIButton *btn = (UIButton*) sender;
    [dropDownView openAnimation];
}
-(void)dropDownCellSelected:(NSInteger)returnIndex{
    
    //    [self.btn_dropdown setTitle:[arrayData objectAtIndex:returnIndex] forState:UIControlStateNormal];
    self.iv_dropdown.image = [UIImage imageNamed:[arrayData objectAtIndex:returnIndex]];
    self.position = [NSString stringWithFormat:@"%ld",(long)returnIndex];
}
-(void)setViewUI{
    fontManager *font = [[fontManager alloc] init];
    self.btn_saveNnew.titleLabel.font = self.btn_saveNquit.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_saveNnew setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNnew setTitle:@"儲存及加頁" forState:UIControlStateNormal];
    [self.btn_saveNquit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNquit setTitle:@"儲存及離開" forState:UIControlStateNormal];
    
    self.v_inputBox.layer.cornerRadius=8.0f;
    self.v_inputBox.layer.masksToBounds=YES;
    self.v_inputBox.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.v_inputBox.layer.borderWidth= 0.0f;
    self.btn_recorder_stop.hidden = self.btn_stop.hidden = YES;
    [self.btn_cam setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_lib setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_dropdown setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_textToVoice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_recorder setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_play setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.sel_time setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNquit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNnew setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_recorder_stop setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_stop setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_popupClose setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_popupSel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnLib:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnCam:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnSaveNPage:(id)sender{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.square = YES;
    hud.label.text = NSLocalizedString(@"Loading", @"Loading");
    [hud showAnimated:YES];
    
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    utilityManager *utility = [[utilityManager alloc] init];
    albumPageObj *obj = (albumPageObj*) self.record;
    NSString *imagePath = @"";
    NSString *audioPath = @"";
    NSString *pageStatus = @"S";
    if(app.mediaArray != nil)
    {
        [app.mediaArray removeAllObjects];
    }
    if(self.originalImage != nil){
        NSMutableDictionary *dict = [NSMutableDictionary new];
        [dict setValue:[[utilityManager alloc] getDataFilePath:@"UploadImage.jpeg" folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict setValue:@"UploadImage.jpeg" forKey:@"fileName"];
        [dict setValue:@"jpeg" forKey:@"fileType"];
        [dict setValue:@"image" forKey:@"paramKey"];
        [app.mediaArray addObject:dict];
        imagePath = @"UploadImage.jpeg";
    }
    if(self.audioDuration != nil && self.isAudio == YES){
        NSMutableDictionary *dict1 = [NSMutableDictionary new];
        [dict1 setValue:[[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict1 setValue:FILENAME forKey:@"fileName"];
        [dict1 setValue:[utility fileExtension:[utility getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO]] forKey:@"fileType"];
        [dict1 setValue:@"audio" forKey:@"paramKey"];
        [app.mediaArray addObject:dict1];
        audioPath = FILENAME;
    }
    if(self.audioDuration == nil){
        self.audioDuration = @"3";
    }
    
    if(self.pageRecord){
        self.btn_saveNnew.enabled = NO;
        self.btn_saveNquit.enabled = NO;
//        utilityManager *utility =[[utilityManager alloc] init];
//        connectionManager *connect =[[connectionManager alloc] init];
        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
        if(![objPage.user_id isEqualToString:objPage.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_AL_PG",@"action",self.txt_box.text,@"description",self.position,@"posType",imagePath,@"imagePath",audioPath,@"audioPath",@"",@"videoPath",@"",@"videoThumb",self.audioDuration,@"residenceTime",objPage.user_id,@"user_id",objPage.albumID,@"albumID",objPage.pageType,@"pageType",objPage.createByID,@"createByID",objPage.pageTitle,@"pageTitle",objPage.pageID,@"albumPageID",pageStatus,@"pageStatus", nil];
        [self uploadFile:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            self.originalImage = nil;
            if(status){
                [self.navigationController popViewControllerAnimated:YES];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNnew.enabled = YES;
                self.btn_saveNquit.enabled = YES;
            }
            [hud hideAnimated:YES];
        }];
    }
    else{
        self.btn_saveNnew.enabled = NO;
        self.btn_saveNquit.enabled = NO;
        if(![obj.user_id isEqualToString:obj.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"INSERT_AL_PG",@"action",self.txt_box.text,@"description",self.position,@"posType",imagePath,@"imagePath",audioPath,@"audioPath",@"",@"videoPath",@"",@"videoThumb",self.audioDuration,@"residenceTime",obj.user_id,@"user_id",obj.albumID,@"albumID",obj.pageType,@"pageType",obj.createByID,@"createByID",obj.pageTitle,@"pageTitle",pageStatus,@"pageStatus", nil];
        [self uploadFile:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                [self.navigationController popViewControllerAnimated:YES];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNnew.enabled = YES;
                self.btn_saveNquit.enabled = YES;
            }
            [hud hideAnimated:YES];
        }];
    }
}

-(IBAction)pressBtnSaveNQuit:(id)sender{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.square = YES;
    hud.label.text = NSLocalizedString(@"Loading", @"Loading");
    [hud showAnimated:YES];
    
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
//    utilityManager *utility = [[utilityManager alloc] init];
    albumPageObj *obj = (albumPageObj*) self.record;
    NSString *imagePath = @"";
    NSString *audioPath = @"";
    NSString *pageStatus = @"S";
    if(app.mediaArray != nil)
    {
        [app.mediaArray removeAllObjects];
    }
    if(self.originalImage != nil){
        NSMutableDictionary *dict = [NSMutableDictionary new];
        [dict setValue:[[utilityManager alloc] getDataFilePath:@"UploadImage.jpeg" folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict setValue:@"UploadImage.jpeg" forKey:@"fileName"];
        [dict setValue:@"jpeg" forKey:@"fileType"];
        [dict setValue:@"image" forKey:@"paramKey"];
        [app.mediaArray addObject:dict];
        imagePath = @"UploadImage.jpeg";
    }
    if(self.audioDuration != nil && self.isAudio == YES){
        NSMutableDictionary *dict1 = [NSMutableDictionary new];
        [dict1 setValue:[[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict1 setValue:FILENAME forKey:@"fileName"];
        [dict1 setValue:@"audio/aac" forKey:@"fileType"];
        [dict1 setValue:@"audio" forKey:@"paramKey"];
        [app.mediaArray addObject:dict1];
        audioPath = FILENAME;
    }
    if(self.audioDuration == nil){
        self.audioDuration = @"3";
    }
    if(self.pageRecord){
        self.btn_saveNnew.enabled = NO;
        self.btn_saveNquit.enabled = NO;
//        utilityManager *utility =[[utilityManager alloc] init];
//        connectionManager *connect =[[connectionManager alloc] init];
        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
        if(![objPage.user_id isEqualToString:objPage.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_AL_PG",@"action",self.txt_box.text,@"description",self.position,@"posType",imagePath,@"imagePath",audioPath,@"audioPath",@"",@"videoPath",@"",@"videoThumb",self.audioDuration,@"residenceTime",objPage.user_id,@"user_id",objPage.albumID,@"albumID",objPage.pageType,@"pageType",objPage.createByID,@"createByID",objPage.pageTitle,@"pageTitle",objPage.pageID,@"albumPageID",pageStatus,@"pageStatus", nil];
        [self uploadFile:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            self.originalImage = nil;
            self.audioDuration = nil;
            if(status){
                [self dismissViewControllerAnimated:YES completion:^{
                    
                }];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNnew.enabled = YES;
                self.btn_saveNquit.enabled = YES;
            }
            [hud hideAnimated:YES];
        }];
        
    }
    else{
        self.btn_saveNnew.enabled = NO;
        self.btn_saveNquit.enabled = NO;
        if(![obj.user_id isEqualToString:obj.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"INSERT_AL_PG",@"action",self.txt_box.text,@"description",self.position,@"posType",imagePath,@"imagePath",audioPath,@"audioPath",@"",@"videoPath",@"",@"videoThumb",self.audioDuration,@"residenceTime",obj.user_id,@"user_id",obj.albumID,@"albumID",obj.pageType,@"pageType",obj.createByID,@"createByID",obj.pageTitle,@"pageTitle",pageStatus,@"pageStatus", nil];
        [self uploadFile:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                [self dismissViewControllerAnimated:YES completion:^{
                    
                }];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNnew.enabled = YES;
                self.btn_saveNquit.enabled = YES;
                
            }
            [hud hideAnimated:YES];
        }];
    }
}

-(void) uploadFile:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([app.mediaArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[app.mediaArray count];i++){
                NSMutableDictionary *dict = [app.mediaArray objectAtIndex:i];
                [formData appendPartWithFileData:[utility getDataFileByPath:[dict objectForKey:@"file"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"fileName"] mimeType:[dict objectForKey:@"fileType"]];
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                  }];
    
    [uploadTask resume];
}

- (void) audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    self.btn_play.hidden = NO;
    self.btn_stop.hidden = YES;
}

-(IBAction)pressBtnPlay:(id)sender{
    if(!self.recorder.recording)
    {
        self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:self.recorder.url error:nil];
        [self.player setDelegate:self];
        [self.player play];
        self.btn_play.hidden = YES;
        self.btn_stop.hidden = NO;
    }
//    if(!self.recorder.recording)
//    {
//        NSError *error = nil;
//        NSError *error1 = nil;
//        NSLog(@"aucio:%@",[self.recorder.url absoluteString]);
//        NSString* resourcePath = [self.recorder.url absoluteString]; //your url
//        
//        NSData *_objectData = [[utilityManager alloc] getDataFileByPath:[self.recorder.url absoluteString]];
//        
//        NSData *songFile = [[NSData alloc] initWithContentsOfURL:resourcePath options:NSDataReadingMappedIfSafe error:&error1 ];
//        self.player = [[AVAudioPlayer alloc] initWithData:songFile error:&error];
//        self.player.numberOfLoops = 1;
//        
//        if (self.player == nil){
//            NSLog([error description]);
//            NSLog([error1 description]);
//        }
//        else{
//            [self.player play];
//        }
//        self.btn_play.hidden = YES;
//        self.btn_stop.hidden = NO;
//    }
    //    if(self.pageRecord){
    //        utilityManager *utility =[[utilityManager alloc] init];
    //        connectionManager *connect =[[connectionManager alloc] init];
    //        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
    //        if(![objPage.audioPath isEqualToString:@""]){
    //            NSError *error = nil;
    //            NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,objPage.audioPath];
    //            self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:urlPath] error:&error];
    //            if (error)
    //            {
    //                NSLog(@"error: %@", [error localizedDescription]);
    //
    //            } else {
    //                [self.player setDelegate:self];
    //                [self.player play];
    //                self.btn_play.hidden = YES;
    //                self.btn_stop.hidden = NO;
    //            }
    //        }
    //    }
}

-(IBAction)pressBtnStop:(id)sender{
    [self.player stop];
    self.btn_play.hidden = NO;
    self.btn_stop.hidden = YES;
}

- (void) audioRecorderDidFinishRecording:(AVAudioRecorder *)avrecorder successfully:(BOOL)flag{
    self.btn_recorder_stop.hidden = YES;
    self.btn_recorder.hidden = NO;
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:self.recorder.url error:nil];
    self.audioDuration = [NSString stringWithFormat:@"%f",self.player.duration];
    self.sel_time.enabled = NO;
}

-(IBAction)pressBtnStopRecorder:(id)sender{
    [self.recorder stop];
}

-(IBAction)pressBtnRecorder:(id)sender{
    [self.recorder record];
    self.btn_recorder_stop.hidden = NO;
    self.btn_recorder.hidden = YES;
    self.isAudio = YES;
}

-(IBAction)pressBtnTextToSpeech:(id)sender{
    [[utilityManager alloc] TextToSpeech:self.txt_box.text];
    NSMutableArray *imageArray = [NSMutableArray new];
    
    for (int i = 1; i < 5; i ++) {
        [imageArray addObject:[UIImage imageNamed:[NSString stringWithFormat:@"btn_spk_stop%d.png",i]]];
    }
    [self.btn_textToVoice.imageView setAnimationImages:[imageArray copy]];
    [self.btn_textToVoice.imageView setAnimationDuration:1.0];
    [self.btn_textToVoice.imageView startAnimating];
    [self.btn_textToVoice removeTarget:nil
                                action:NULL
                      forControlEvents:UIControlEventAllEvents];
}

-(IBAction)pressBtnPopupClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.v_popup isOpen:NO];
}

-(IBAction)pressBtnSel:(id)sender{
    if(!self.isAudio){
        NSInteger row = [self.timePicker selectedRowInComponent:0];
        self.residenceTime = [[self.aryTime objectAtIndex:row] stringByReplacingOccurrencesOfString:@"秒" withString:@""];
        self.audioDuration = [[self.aryTime objectAtIndex:row] stringByReplacingOccurrencesOfString:@"秒" withString:@""];
        [self.sel_time setTitle:[self.aryTime objectAtIndex:row] forState:UIControlStateNormal];
        [[utilityManager alloc] popupAnimation:self.v_popup isOpen:NO];
    }
    else{
        [self.sel_time setTitle:[NSString stringWithFormat:@"%@秒",self.audioDuration] forState:UIControlStateNormal];
        [[utilityManager alloc] popupAnimation:self.v_popup isOpen:NO];
    }
}

-(IBAction)pressBtnSelTime:(id)sender{
    self.v_popup.hidden = NO;
    [[utilityManager alloc] popupAnimation:self.v_popup isOpen:YES];
}

-(void) stopTextToSpeech:(NSNotification *)inNotification {
    [self.btn_textToVoice.imageView stopAnimating];
    [self.btn_textToVoice.imageView setAnimationImages:nil];
    [self.btn_textToVoice setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [self.btn_textToVoice addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    self.originalImage = [UIImage fixrotation:[info objectForKey:UIImagePickerControllerOriginalImage]];
    self.iv_inputImg.image = [UIImage fixrotation:self.originalImage];
    NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
    if([[utilityManager alloc] saveDataFile:imageData Filename:@"UploadImage" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
    {
        NSData *imageData1 = [[utilityManager alloc] getDataFile:@"UploadImage.jpeg" folderName:@"temp" isDoucmentFolder:NO];
        self.iv_inputImg.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
    }
    self.txt_box.frame = CGRectMake(self.txt_box.frame.origin.x, self.txt_box.frame.origin.y, self.iv_inputImg.frame.origin.x - self.txt_box.frame.origin.x - 10, self.txt_box.frame.size.height);
    [self dismissViewControllerAnimated:YES completion:nil];
}

// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [self.aryTime count];
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [self.aryTime objectAtIndex:row];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//- (void)textViewDidChange:(UITextView *)textView{
//    NSString *str = [textView.text stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//    str = [str stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
//    NSUInteger textLength = [str lengthOfBytesUsingEncoding:NSUTF8StringEncoding] / 3;
//    int TLng = (int)textLength;
//    if(TLng > 0){
//        if(TLng%MAXLENGTH == 0){
//            NSLog(@"textLength:%lu",(unsigned long)textLength);
//            textView.text = [NSString stringWithFormat:@"%@\n",textView.text];
//        }
//    }
//}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
