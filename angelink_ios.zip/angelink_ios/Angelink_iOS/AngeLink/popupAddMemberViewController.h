//
//  popupAddMemberViewController.h
//  AngeLink
//
//  Created by kanhan on 26/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"

@interface popupAddMemberViewController : UIViewController<headerBarViewDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *lbl_name,*lbl_phone,*lbl_fb;
@property (weak, nonatomic) IBOutlet UITextField *tf_name;
@property (weak, nonatomic) IBOutlet UIButton *btn_selPhone,*btn_selFB,*btn_sel,*btn_close,*btn_rel,*btn_fd,*btn_cancel,*btn_add;
@property (weak, nonatomic) IBOutlet UITableView *tv_fdList;
@property (weak, nonatomic) IBOutlet UIView *v_sel;
@property (nonatomic, retain) UIViewController *pre_view;
@property (nonatomic, retain) NSMutableArray *aryData,*aryDataOrg;
@property (nonatomic, strong) APAddressBook *addressBook;
@property (nonatomic, strong) APAddressBookContactsRoutine *contacts;
@property (nonatomic, strong) APAddressBookAccessRoutine *access;
@property (nonatomic, strong) APAddressBookExternalChangeRoutine *externalChange;
@property (nonatomic, strong) APThread *thread;
@property (nonatomic, retain) UIButton *selBtn;
@property (nonatomic, retain) NSObject *record;
@property (nonatomic, retain) headerBar *header;
@property (weak, nonatomic) IBOutlet UITextField *tf_search;
@property (nonatomic, retain) UIAlertView *alertMember;
-(void) editMemberRecord:(NSObject*)obj;

@end
