//
//  addPage1ViewController.m
//  AngeLink
//
//  Created by kanhan on 25/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "addPage1ViewController.h"
#import "albumPageObj.h"
#import "albumObj.h"
#import "addPageImgViewController.h"
#import "addPageVideoViewController.h"
@interface addPage1ViewController ()

@end

@implementation addPage1ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden = YES;
    
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = self.headerTitle;
//    header.lbl_backTittle.text = @"關閉";
    [header updateBackLabel:@"關閉"];
    header.delegate = self;
    [self.view addSubview:header];
    [self setViewUI];
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.2.1_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.2.1_2"];
    UIImage *img3 = [UIImage imageNamed:@"Book_6.2.1_3"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"為人生紀念冊相簿加入新一頁，你可以選擇加入圖片或影片";
    NSString *str2 = @"輸入頁面名稱";
    NSString *str3 = @"選擇加入圖片或影片";
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_img.isAccessibilityElement = true;
    self.btn_img.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_img.accessibilityLabel = @"圖像頁面";
    
    self.btn_mov.isAccessibilityElement = true;
    self.btn_mov.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_mov.accessibilityLabel = @"視頻頁面";
    
    self.btn_next.isAccessibilityElement = true;
    self.btn_next.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_next.accessibilityLabel = @"視頻頁面";
}


-(void)setViewUI{
    fontManager *font = [[fontManager alloc] init];
    self.btn_next.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_next setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_next setTitle:@"下一頁" forState:UIControlStateNormal];
    self.iv_bg.layer.cornerRadius=5.0;
    self.iv_bg.layer.masksToBounds=YES;
    self.tf_pageName.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    self.tf_pageName.textColor = [UIColor blackColor];
    self.tf_pageName.placeholder = @"請輸入頁面名稱";
    self.tf_pageName.delegate = self;
    CALayer *bottomBorder = [CALayer layer];
    bottomBorder.frame = CGRectMake(0.0f, self.tf_pageName.frame.size.height - 1, self.tf_pageName.frame.size.width, 1.0f);
    bottomBorder.backgroundColor = [UIColor blackColor].CGColor;
    [self.tf_pageName.layer addSublayer:bottomBorder];
    [self.btn_img setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_mov setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_next setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}

-(void)pressBtnback:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{ }];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(IBAction)pressBtnImg:(id)sender{
    self.btn_img.selected = self.btn_mov.selected = NO;
    self.btn_img.selected = YES;
}

-(IBAction)pressBtnMov:(id)sender{
    self.btn_img.selected = self.btn_mov.selected = NO;
    self.btn_mov.selected = YES;
}

-(IBAction)pressBtnNext:(id)sender{
    utilityManager *utility = [[utilityManager alloc] init];
    NSString *pageType = @"0";
    if(self.btn_img.selected){
        pageType = @"0";
    }
    if(self.btn_mov.selected){
        pageType = @"1";
    }
    albumObj *album = (albumObj*) self.record;
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[utility getUserDefaultstoString:@"memberID"],@"createByID",self.tf_pageName.text,@"pageTitle",pageType,@"pageType",album.albumID,@"albumID",album.userID,@"user_id",  nil];
    albumPageObj *obj = [[albumPageObj alloc] initWithDict:dict];
    if(self.btn_img.selected){
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        addPageImgViewController *vc = (addPageImgViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPageImgViewController"];
        vc.headerTitle = @"新増頁";
        vc.record = obj;
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if (self.btn_mov.selected){
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        addPageVideoViewController *vc = (addPageVideoViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPageVideoViewController"];
        vc.headerTitle = @"新増頁";
        vc.record = obj;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
