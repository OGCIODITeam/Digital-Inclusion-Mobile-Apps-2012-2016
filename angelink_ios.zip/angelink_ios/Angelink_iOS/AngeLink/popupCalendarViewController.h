//
//  popupCalendarViewController.h
//  AngeLink
//
//  Created by kanhan on 12/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface popupCalendarViewController : UIViewController<FSCalendarDataSource,FSCalendarDelegate,UIPickerViewDataSource, UIPickerViewDelegate>
@property (retain, nonatomic) FSCalendar *v_calendar;
@property (weak, nonatomic) IBOutlet UIButton *btn_close;
@property (weak, nonatomic) IBOutlet UIButton *btn_submit;
@property (strong, nonatomic) NSCalendar *gregorianCalendar;
@property (weak, nonatomic) IBOutlet UIView *v_body;
@property (weak, nonatomic) IBOutlet UILabel *lbl_Caltitle;
@property (strong, nonatomic) NSCalendar *lunarCalendar;
@property (strong, nonatomic) NSArray *lunarChars;
@property (nonatomic, retain) NSMutableArray *aryYear;
@property (weak, nonatomic) IBOutlet UIButton *btn_select;
@property (nonatomic, retain) UIViewController *pre_view;
@property (weak, nonatomic) IBOutlet UIButton *btn_popupClose;
@property (weak, nonatomic) IBOutlet UIPickerView *dateSelect;
@property (weak, nonatomic) IBOutlet UIView *v_selecter;
@property (strong, nonatomic) NSCalendar *gregorian;
@property (nonatomic, retain) NSDate *valueDate;

-(void) updateCurrectDate;

@end
