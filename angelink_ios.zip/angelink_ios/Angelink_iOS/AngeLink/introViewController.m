//
//  introViewController.m
//  AngeLink
//
//  Created by kanhan on 11/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "introViewController.h"

@interface introViewController ()
    
    @end

@implementation introViewController
    
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.btn_start.titleLabel.textColor = self.lbl_msg.textColor = self.lbl_tittle.textColor = [UIColor blackColor];
    self.checkbox = [[M13Checkbox alloc] initWithFrame:CGRectMake(4, self.btn_start.frame.origin.y,  40, 40)];
    self.checkbox.center = CGPointMake(self.checkbox.center.x, self.lbl_msg.center.y);
    self.lbl_msg.text = @"下次不要顯示";
    [self.view addSubview:self.checkbox];
//    UILabel *lbl_TBC = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 200)];
//    lbl_TBC.text = @"TBC";
//    lbl_TBC.font = [[fontManager alloc] getBoldsize:[[fontManager alloc] getLargeContact]];
//    [lbl_TBC sizeToFit];
//    lbl_TBC.center = self.sv_img.center;
//    [self.sv_img addSubview:lbl_TBC];
    [self setFontUI];
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_start.isAccessibilityElement = true;
    self.btn_start.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_start.accessibilityLabel = @"開始使用";
    self.lbl_msg.isAccessibilityElement = true;
    self.lbl_msg.accessibilityTraits = UIAccessibilityTraitNone;
    self.lbl_msg.accessibilityLabel = @"下次不要顯示";
    self.checkbox.isAccessibilityElement = true;
    self.checkbox.accessibilityTraits = UIAccessibilityTraitNone;
    self.checkbox.accessibilityLabel = @"下次不要顯示簡介";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.btn_start.titleLabel.font = self.lbl_msg.font = self.lbl_tittle.font = self.tv_intro.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    [self.btn_start setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnStart:(id)sender{
    utilityManager *utility = [[utilityManager alloc] init];
    if(self.checkbox.checkState == true){
        NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"YES",@"skipIntroPage", nil];
        [utility saveValuetoUserDefaults:dict];
    }
    else{
        NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"NO",@"skipIntroPage", nil];
        [utility saveValuetoUserDefaults:dict];
    }
    if(![[utility getUserDefaultstoString:@"memberID"] isEqualToString:@"0"] && [utility getUserDefaultstoString:@"memberID"] !=nil && [[utility getUserDefaultstoString:@"register"] isEqualToString:@"YES"])
        [self mainPage];
    else
        [self registerPage];
    
}
    
-(void) registerPage{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep1ViewController"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
}
    
-(void) mainPage{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
}
    
- (BOOL)shouldAutorotate
{
//    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    return NO;
}
#pragma mark - Navigation
    
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
// Get the new view controller using [segue destinationViewController].
// Pass the selected object to the new view controller.
    [self setFontUI];
}
    
    
    @end
