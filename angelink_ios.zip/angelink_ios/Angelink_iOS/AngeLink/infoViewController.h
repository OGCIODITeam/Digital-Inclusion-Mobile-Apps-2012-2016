//
//  infoViewController.h
//  AngeLink
//
//  Created by kanhan on 21/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"

@interface infoViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,headerBarViewDelegate,YCameraViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *iv_pic;
@property (weak, nonatomic) IBOutlet UIButton *btn_cam;
@property (weak, nonatomic) IBOutlet UIButton *btn_lib;
@property (weak, nonatomic) IBOutlet UILabel *lbl_tittle;
@property (weak, nonatomic) IBOutlet UILabel *lbl_name;
@property (weak, nonatomic) IBOutlet UILabel *lbl_mobile;
@property (weak, nonatomic) IBOutlet UITextField *tf_name;
@property (weak, nonatomic) IBOutlet UILabel *lbl_mobileNo;
@property (weak, nonatomic) IBOutlet UIScrollView *sv_info;
@property (weak, nonatomic) IBOutlet UIButton *btn_update;
@property (weak, nonatomic) IBOutlet UILabel *lbl_birth;
@property (weak, nonatomic) IBOutlet UIButton *btn_dateDropdown;
@property (weak, nonatomic) IBOutlet UIButton *btn_calFormat;
@property (nonatomic, assign) BOOL isLunarDate;
@property (nonatomic, retain) UIImage* originalImage;
@property (nonatomic, retain) NSObject *record;
@property (nonatomic, retain) NSDate *currectDate;

-(void) updateSelectedDate;

@end
