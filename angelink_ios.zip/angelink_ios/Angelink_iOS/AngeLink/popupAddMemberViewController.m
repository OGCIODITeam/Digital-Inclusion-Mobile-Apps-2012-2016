//
//  popupAddMemberViewController.m
//  AngeLink
//
//  Created by kanhan on 26/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "popupAddMemberViewController.h"
#import "addressBookTableViewCell.h"
#import "circleViewController.h"
#import "userObj.h"
#import "fdRecord.h"

@interface popupAddMemberViewController ()

@end

@implementation popupAddMemberViewController
- (id)init
{
    self = [super init];
    self.thread = [[APThread alloc] init];
    [self.thread start];
    [self.thread dispatchAsync:^
     {
         APAddressBookRefWrapper *refWrapper = [[APAddressBookRefWrapper alloc] init];
         self.access = [[APAddressBookAccessRoutine alloc] initWithAddressBookRefWrapper:refWrapper];
         if (!refWrapper.error)
         {
             self.contacts = [[APAddressBookContactsRoutine alloc] initWithAddressBookRefWrapper:refWrapper];
             self.externalChange = [[APAddressBookExternalChangeRoutine alloc] initWithAddressBookRefWrapper:refWrapper];
             self.externalChange.delegate = self;
         }
         else
         {
             NSLog(@"APAddressBook initialization error:\n%@", refWrapper.error);
         }
     }];
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    self.header.lbl_pageTittle.text = @"親友圈 - 新増親友";
    [self.header hiddenBackFunction];
    self.header.delegate = self;
    [self.view addSubview:self.header];
    self.addressBook = [[APAddressBook alloc] init];
    [self setFontUI];
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_selPhone.isAccessibilityElement = true;
    self.btn_selPhone.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_selPhone.accessibilityLabel = @"選擇電話號碼";
    
    self.btn_selFB.isAccessibilityElement = true;
    self.btn_selFB.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_selFB.accessibilityLabel = @"選擇Facebook";
    
    self.btn_sel.isAccessibilityElement = true;
    self.btn_sel.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_sel.accessibilityLabel = @"選擇";
    
    self.btn_close.isAccessibilityElement = true;
    self.btn_close.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_close.accessibilityLabel = @"關閉";
    
    self.btn_rel.isAccessibilityElement = true;
    self.btn_rel.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_rel.accessibilityLabel = @"至親";
    
    self.btn_fd.isAccessibilityElement = true;
    self.btn_fd.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_fd.accessibilityLabel = @"親友";
    
    self.btn_cancel.isAccessibilityElement = true;
    self.btn_cancel.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_cancel.accessibilityLabel = @"取消";
    
    self.btn_add.isAccessibilityElement = true;
    self.btn_add.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_add.accessibilityLabel = @"新増";
    
    self.lbl_name.isAccessibilityElement = true;
    self.lbl_name.accessibilityTraits = UIAccessibilityTraitNone;
    self.lbl_name.accessibilityLabel = @"姓名";

    self.tf_name.isAccessibilityElement = true;
    self.tf_name.accessibilityTraits = UIAccessibilityTraitNone;
    self.tf_name.accessibilityLabel = @"輸入姓名";
    
    self.lbl_phone.isAccessibilityElement = true;
    self.lbl_phone.accessibilityTraits = UIAccessibilityTraitNone;
    self.lbl_phone.accessibilityLabel = @"電話號碼";
    
    self.lbl_fb.isAccessibilityElement = true;
    self.lbl_fb.accessibilityTraits = UIAccessibilityTraitNone;
    self.lbl_fb.accessibilityLabel = @"Facebook";
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    self.lbl_fb.font = self.lbl_name.font = self.lbl_phone.font = self.tf_name.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    self.btn_rel.titleLabel.font = self.btn_fd.titleLabel.font = self.btn_add.titleLabel.font = self.btn_sel.titleLabel.font = self.btn_close.titleLabel.font = [[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Contact"]];
    self.tf_name.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    self.tf_name.textColor = [UIColor blackColor];
    [self.btn_selFB.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_selFB setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_selPhone.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_selPhone setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.lbl_name.text = @"姓名:";
    
    self.lbl_phone.text = @"電話號碼:";
    
    
    self.lbl_fb.text = @"Facebook:";
    
    self.tf_name.layer.cornerRadius=8.0f;
    self.tf_name.layer.masksToBounds=YES;
    self.tf_name.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_name.layer.borderWidth= 2.0f;
    [self.tf_name setBackgroundColor:[UIColor whiteColor]];
    [utility setLeftSpaceToTextField:self.tf_name];
    self.tf_name.delegate = self;
    self.btn_rel.selected = true;
    [[utilityManager alloc] popupAnimation:self.v_sel isOpen:NO];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 52, 52);
    [btn setImage:[UIImage imageNamed:@"btn_search"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(pressBtnSearch:) forControlEvents:UIControlEventTouchUpInside];
    self.tf_search.layer.cornerRadius=8.0f;
    self.tf_search.layer.masksToBounds=YES;
    self.tf_search.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_search.layer.borderWidth= 2.0f;
    [self.tf_search setBackgroundColor:[UIColor whiteColor]];
    [utility setLeftSpaceToTextField:self.tf_search];
    [utility setButtonToTextField:self.tf_search Button:btn Position:@"right"];
    [self.btn_selPhone setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_selFB setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_sel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_close setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_rel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_fd setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_add setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.selBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_rel setImage:[UIImage imageNamed:@"btn_fam_soff"] forState:UIControlStateNormal];
    [self.btn_rel setImage:[UIImage imageNamed:@"btn_fam_son"] forState:UIControlStateSelected];
    [self.btn_fd setImage:[UIImage imageNamed:@"btn_fd_soff"] forState:UIControlStateNormal];
    [self.btn_fd setImage:[UIImage imageNamed:@"btn_fd_son"] forState:UIControlStateSelected];
    
}

-(void) editMemberRecord:(NSObject*)obj{
    self.record = obj;
    fdRecord *fd = (fdRecord*) obj;
    self.tf_name.text = fd.name;
    [self.btn_selPhone setTitle:fd.phone forState:UIControlStateNormal];
    self.btn_fd.selected = self.btn_rel.selected = FALSE;
    if([fd.isBestFd isEqualToString:@"0"]){
        self.btn_fd.selected = TRUE;
    }
    else{
        self.btn_rel.selected = TRUE;
    }
    if(self.record != nil){
        //        [self.btn_close setImage:[UIImage imageNamed:@"btn_add_M"] forState:UIControlStateNormal];
        [self.btn_add setImage:[UIImage imageNamed:@"btn_tickr_M"] forState:UIControlStateNormal];
        self.btn_add.isAccessibilityElement = true;
        self.btn_add.accessibilityTraits = UIAccessibilityTraitNone;
        self.btn_add.accessibilityLabel = @"確認";
    }
    self.header.lbl_pageTittle.text = @"親友圈 - 修改親友資料";
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([textField canResignFirstResponder]) {
        [textField resignFirstResponder];
    }
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    // add your method here
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
}

-(IBAction)pressBtnSearch:(id)sender{
    [self.view endEditing:YES];
    if([self.aryData count] != [self.aryDataOrg count]){
        self.aryData = [self.aryDataOrg mutableCopy];
    }
    if (![self.tf_search.text isEqualToString:@""]) {
        
        NSMutableArray *temp = [NSMutableArray new];
        for (int i = 0; i< [self.aryData count];i++){
            if ([[[[self.aryData objectAtIndex:i] objectForKey:@"name"] lowercaseString] containsString:[self.tf_search.text lowercaseString]]) {
                [temp addObject:[self.aryData objectAtIndex:i]];
            } else {
                NSLog(@"string does not contain bla");
            }
        }
        
        self.aryData = temp;
    }
    [self.tv_fdList reloadData];
}

-(IBAction)pressBtnAddMember:(id)sender{
    connectionManager *connect = [[connectionManager alloc] init];
    NSString *phoneNumber = [self.btn_selPhone.titleLabel.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"852",@"phoneAreaCode",phoneNumber,@"phone", nil];
    [connect postRequest:GET_USER_INFO parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            if(jsonDict != nil){
                userObj *user = [[userObj alloc] initWithDict:jsonDict];
                NSString *memberID  = @"";
                if(user.memberID != nil){
                    memberID = user.memberID;
                }
                NSString *isBestFd = @"";
                if(self.btn_rel.selected){
                    isBestFd = @"1";
                }
                else if (self.btn_fd.selected){
                    isBestFd = @"0";
                }
                connectionManager *connect = [[connectionManager alloc] init];
                utilityManager *utility = [[utilityManager alloc] init];
                NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[utility getUserDefaultstoString:@"memberID"],@"userFrom",memberID,@"userTo",isBestFd,@"isBestFd",self.tf_name.text,@"displayName", nil];
                NSLog(@"Dict:%@",dict);
                [connect postRequest:UPDATE_USER_FD_CASE parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
                    if(status){
                        if(user.memberID != nil){
                            [self dismissViewControllerAnimated:YES
                                                     completion:^{
                                                         circleViewController *view = (circleViewController*) self.pre_view;
                                                         
                                                         [view share:YES];
                                                     }];
                            
                        }
                        else{
                            self.alertMember = [[UIAlertView alloc] initWithTitle:@"無法新增親友" message:@"對方沒有使用AngeLINK，要透過社交平台邀請對方一起使用AngeLINK嗎?" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
                            [self.alertMember show];
                        }
                    }
                    else{
                        if(jsonDict == nil){
                            self.alertMember = [[UIAlertView alloc] initWithTitle:@"無法新增親友" message:@"對方沒有使用AngeLINK，要透過社交平台邀請對方一起使用AngeLINK嗎?" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
                            [self.alertMember show];
                        }
                        else{
                            UIAlertView *albumGrade = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"是" otherButtonTitles: nil];
                            [albumGrade show];

                        }
                    }
                }];
            }
            else{
                self.alertMember = [[UIAlertView alloc] initWithTitle:@"無法新增親友" message:@"對方沒有使用AngeLINK，要透過社交平台邀請對方一起使用AngeLINK嗎?" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
                [self.alertMember show];
            }
        }
        else{
            self.alertMember = [[UIAlertView alloc] initWithTitle:@"無法新增親友" message:@"對方沒有使用AngeLINK，要透過社交平台邀請對方一起使用AngeLINK嗎?" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
            [self.alertMember show];
        }
    }];
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(alertView == self.alertMember){
        if (buttonIndex == 0)
        {
            
        }
        else{
            [self dismissViewControllerAnimated:YES
                                     completion:^{
                                         circleViewController *view = (circleViewController*) self.pre_view;
                                         [view share:NO];
                                     }];
        }
    }
    else{
        [self dismissViewControllerAnimated:YES
                                 completion:^{
                                     circleViewController *view = (circleViewController*) self.pre_view;
                                     [view share:YES];
                                 }];
    }
    NSLog(@"didDismissWithButtonIndex");
}

-(void)pressBtnback:(id)sender{
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 circleViewController *view = (circleViewController*) self.pre_view;
                                 [view share:YES];
                             }];
}

-(IBAction)pressBtnClose:(id)sender{
    [self pressBtnback:nil];
}

-(IBAction)pressBtnCloseSel:(id)sender{
    [[utilityManager alloc] popupAnimation:self.v_sel isOpen:NO];
}

-(IBAction)pressBtnSelField:(id)sender{
    [[utilityManager alloc] popupAnimation:self.v_sel isOpen:NO];
    UIButton *btn = self.selBtn;
    [btn setTitle:@"aaa" forState:UIControlStateNormal];
    [btn.titleLabel setFont:[[fontManager alloc] getRegularsize:[[fontManager alloc] getSettingFont:@"Title"]]];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.selBtn = nil;
}

-(IBAction)pressBtnSel:(id)sender{
    UIButton *btn = (UIButton*) sender;
    self.selBtn = (UIButton*) sender;
    if(btn == self.btn_selPhone){
        [self loadContacts];
    }
    else{
        NSLog(@"select facebook btn");
    }
    [self.view bringSubviewToFront:self.v_sel];
    [[utilityManager alloc] popupAnimation:self.v_sel isOpen:YES];
}

-(void) openPopupSel{
    
}

-(IBAction)pressBtnrel:(id)sender{
    self.btn_rel.selected = self.btn_fd.selected = false;
    self.btn_rel.selected = true;
}

-(IBAction)pressBtnfd:(id)sender{
    self.btn_rel.selected = self.btn_fd.selected = false;
    self.btn_fd.selected = true;
}

-(void)pressBtninfo:(id)sender{
    NSLog(@"press btn info");
}

-(BOOL) checkDuplicateAddressContacts:(NSString *) Value ObjectArray:(NSMutableArray*) array{
    
    for(int i = 0; i<[array count];i++){
        if([[[array objectAtIndex:i] objectForKey:@"phone"] isEqualToString:Value]){
            return TRUE;
            break;
        }
    }
    return FALSE;
}

- (void)loadContacts
{
    
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
        self.aryDataOrg = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
        [self.aryDataOrg removeAllObjects];
    }
    self.addressBook.filterBlock = ^BOOL(APContact *contact)
    {
        return contact.phones.count > 0;
    };
    self.addressBook.fieldsMask = APContactFieldName | APContactFieldThumbnail | APContactFieldPhonesWithLabels;
    self.addressBook.sortDescriptors = @[
                                         [NSSortDescriptor sortDescriptorWithKey:@"name.firstName" ascending:YES],
                                         [NSSortDescriptor sortDescriptorWithKey:@"name.lastName" ascending:YES]];
    self.addressBook.filterBlock = ^BOOL(APContact *contact)
    {
        return contact.phones.count > 0;
    };
    [self.addressBook loadContacts:^(NSArray<APContact *> *contacts, NSError *error) {
        if (contacts)
        {
            NSLog(@"%@",contacts);
            for(int i =0;i<[contacts count];i++){
                [self addAddressBook:[contacts objectAtIndex:i]];
                //                NSMutableDictionary *dict = [NSMutableDictionary new];
                //                [dict setObject:[self contactName:[contacts objectAtIndex:i]] forKey:@"name"];
                //                [dict setObject:[self contactPhones:[contacts objectAtIndex:i]] forKey:@"phone"];
                //                [dict setObject:[contacts objectAtIndex:i].thumbnail ?: [UIImage imageNamed:@"sign_pic_none"] forKey:@"thumbnail"];
                //                if(![self checkDuplicateAddressContacts:[self contactPhones:[contacts objectAtIndex:i]] ObjectArray:self.aryData]){
                //                    [self.aryData addObject:dict];
                //                    [self.aryDataOrg addObject:dict];
                //                }
            }
            //            NSSortDescriptor *sortDescriptor;
            NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name"
                                                                           ascending:YES];
            //            NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
            NSArray *sortedArray = [self.aryDataOrg sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            self.aryDataOrg = [sortedArray mutableCopy];
            self.aryData = [sortedArray mutableCopy];
            
            [self.tv_fdList reloadData];
        }
        else if (error)
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
                                                                message:error.localizedDescription
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
            [alertView show];
        }
    }];
}

- (NSString *)contactName:(APContact *)contact
{
    if (contact.name.compositeName)
    {
        return contact.name.compositeName;
    }
    else if (contact.name.firstName && contact.name.lastName)
    {
        return [NSString stringWithFormat:@"%@ %@", contact.name.firstName, contact.name.lastName];
    }
    else if (contact.name.firstName || contact.name.lastName)
    {
        return contact.name.firstName ?: contact.name.lastName;
    }
    else
    {
        return @"Untitled contact";
    }
}

- (NSString *)contactPhones:(APContact *)contact
{
    if (contact.phones.count > 0)
    {
        NSMutableString *result = [[NSMutableString alloc] init];
        for (APPhone *phone in contact.phones)
        {
            NSString *string = phone.localizedLabel.length == 0 ? phone.number :
            [NSString stringWithFormat:@"%@", phone.number];
            if([contact.phones count]>1)
                [result appendFormat:@"%@, ", string];
            else
                [result appendFormat:@"%@", string];
        }
        return result;
    }
    else
    {
        return @"(No phones)";
    }
}

-(void)addAddressBook:(APContact *)contact{
    if (contact.phones.count > 0){
        for (APPhone *phone in contact.phones){
            NSMutableDictionary *dict = [NSMutableDictionary new];
            NSString *string = phone.localizedLabel.length == 0 ? phone.number : [NSString stringWithFormat:@"%@", phone.number];
            string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
            string = [string stringByReplacingOccurrencesOfString:@"+852" withString:@""];
            string = [[string componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] componentsJoinedByString:@""];
            if([string length] > 8){
                string = [string substringFromIndex: [string length] - 8];
            }
            [dict setObject:[NSString stringWithFormat:@"%@ %@",[self contactName:contact],phone.localizedLabel] forKey:@"name"];
            [dict setObject:string forKey:@"phone"];
            [dict setObject:contact.thumbnail ?: [UIImage imageNamed:@"sign_pic_none"] forKey:@"thumbnail"];
            if(![self checkDuplicateAddressContacts:[self contactPhones:contact] ObjectArray:self.aryData]){
                [self.aryData addObject:dict];
                [self.aryDataOrg addObject:dict];
            }
        }
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.aryData count];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
    [self.selBtn setTitle:[[self.aryData objectAtIndex:indexPath.row] objectForKey:@"phone"] forState:UIControlStateNormal];
    [[utilityManager alloc] popupAnimation:self.v_sel isOpen:NO];
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"addressBookTableViewCell";
    
    addressBookTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:CellIdentifier bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    if(self.selBtn == self.btn_selPhone){
        cell.iv_img.image = [[self.aryData objectAtIndex:indexPath.row] objectForKey:@"thumbnail"];
        cell.lbl_name.text = [NSString stringWithFormat:@"%@\n%@",[[self.aryData objectAtIndex:indexPath.row] objectForKey:@"name"],[[self.aryData objectAtIndex:indexPath.row] objectForKey:@"phone"]];
        cell.lbl_name.lineBreakMode = LINE_BREAK_WORD_WRAP;
        cell.lbl_name.numberOfLines = 2;
        cell.iv_img.layer.cornerRadius=cell.iv_img.frame.size.width/2;
        cell.iv_img.layer.masksToBounds=YES;
        cell.iv_img.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
        cell.iv_img.layer.borderWidth= 2.0f;
        
        cell.v_body.layer.cornerRadius=8.0;
        cell.v_body.layer.masksToBounds=YES;
        cell.v_body.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
        cell.v_body.layer.borderWidth= 2.0f;
        
        cell.lbl_name.frame = CGRectMake(cell.lbl_name.frame.origin.x, cell.lbl_name.frame.origin.y, cell.v_body.frame.size.width - cell.lbl_name.frame.origin.x - 5, cell.lbl_name.frame.size.height);
        
        cell.btn_msg.hidden = cell.btn_call.hidden = cell.btn_accept.hidden = cell.btn_reject.hidden = cell.btn_resend.hidden = true;
        
        [cell setBackgroundColor:[UIColor clearColor]];
        
    }
    else{
        NSLog(@"select facebook btn");
    }
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
