//
//  registerStep2ViewController.m
//  AngeLink
//
//  Created by kanhan on 3/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "registerStep2ViewController.h"
#import "registerStep3ViewController.h"
#import "registerStep4ViewController.h"
#import "popupViewController.h"
#import "userObj.h"

@interface registerStep2ViewController ()

@end

@implementation registerStep2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(noticeShowKeyboard:) name:UIKeyboardDidShowNotification object:nil];
    [center addObserver:self selector:@selector(noticeHideKeyboard:) name:UIKeyboardWillHideNotification object:nil];
    [center addObserver:self selector:@selector(noticeChangeKeyboard:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    self.v_submit.layer.cornerRadius=8.0f;
    self.v_submit.layer.masksToBounds=YES;
    self.v_submit.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.v_submit.layer.borderWidth= 3.0f;
    
    self.v_system.layer.cornerRadius=8.0f;
    self.v_system.layer.masksToBounds=YES;
    self.v_system.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.v_system.layer.borderWidth= 3.0f;
    
    self.v_submit.hidden = self.v_system.hidden = YES;
    
    self.v_popup.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
    self.v_popup.hidden = YES;
    
    self.tf_name.layer.cornerRadius=8.0f;
    self.tf_name.layer.masksToBounds=YES;
    self.tf_name.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_name.layer.borderWidth= 3.0f;
    self.tf_name.delegate = self;
    
    self.tf_mobile.layer.cornerRadius=8.0f;
    self.tf_mobile.layer.masksToBounds=YES;
    self.tf_mobile.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_mobile.layer.borderWidth= 3.0f;
    self.tf_mobile.delegate = self;
    
    self.tf_SMScode.layer.cornerRadius=8.0f;
    self.tf_SMScode.layer.masksToBounds=YES;
    self.tf_SMScode.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_SMScode.layer.borderWidth= 3.0f;
    self.tf_SMScode.delegate = self;
    [self setFontUI];
    
}

-(void) noticeChangeKeyboard:(NSNotification *)inNotification {
    if(self.v_submit.hidden){
        NSDictionary *userInfo = [inNotification userInfo];
        NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
        CGRect keyboardRect = [aValue CGRectValue];
        keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
//        CGFloat keyboardTop = keyboardRect.origin.y;
        
        [UIView animateWithDuration:0.2
                              delay:0.3
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             if(self.view.frame.origin.y == 0){
                                 self.view.frame = CGRectMake(0, self.view.frame.origin.y - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
                             }
                             else{
                                 self.view.frame = CGRectMake(0, 0 - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
                             }
                         }
                         completion:^(BOOL finished){
                         }];
    }
}

-(void) noticeShowKeyboard:(NSNotification *)inNotification {
    if(self.v_submit.hidden){
        NSDictionary *userInfo = [inNotification userInfo];
        NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
        CGRect keyboardRect = [aValue CGRectValue];
        keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
//        CGFloat keyboardTop = keyboardRect.origin.y;
        if(self.view.frame.origin.y == 0)
            self.view.frame = CGRectMake(0, self.view.frame.origin.y - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
    }
}

-(void) noticeHideKeyboard:(NSNotification *)inNotification {
    if(self.v_submit.hidden){
        self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }
}

-(void)onTick:(NSTimer*)timer
{
    self.SMSnum --;
    if(self.SMSnum == 0)
    {
        self.btn_reSend.enabled = true;
        [self.smsTimer invalidate];
        self.smsTimer = nil;
    }
    self.lbl_timerMsg.text = [NSString stringWithFormat:@"說明:%d秒後重新獲取驗證碼",self.SMSnum];
    self.lbl_timerMsg.isAccessibilityElement = true;
    self.lbl_timerMsg.accessibilityTraits = UIAccessibilityTraitNone;
    self.lbl_timerMsg.accessibilityLabel = self.lbl_timerMsg.text;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    self.tf_name.font = self.tf_mobile.font = self.tf_SMScode.font = self.tv_body.font = self.tv_msg.font = [font getRegularsize:[font getSettingFont:@"Title"]];
    [utility setLeftSpaceToTextField:self.tf_name];
    [utility setLeftSpaceToTextField:self.tf_mobile];
    [utility setLeftSpaceToTextField:self.tf_SMScode];
    [self.btn_resetUser.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_resetUser setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_skip.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_skip setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_submit.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_submit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_changePNo.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_changePNo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_reSend.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_reSend setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_register.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_register setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_nameIntro.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_nameIntro setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_mobileIntro.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_mobileIntro setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_close.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_close setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    self.lbl_personInfo.font = self.lbl_name.font = self.lbl_mobile.font = self.lbl_statusMsg.font = self.lbl_code.font = self.lbl_status.font = self.lbl_timerMsg.font = self.lbl_system.font = [font getRegularsize:[font getSettingFont:@"Title"]];
    [self.btn_resetUser setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_skip setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_submit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_changePNo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_reSend setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_register setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_nameIntro setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_mobileIntro setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_close setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

-(IBAction)pressBtnRegister:(id)sender{
    [self sendSMS];
}

-(void) sendSMS{
    connectionManager *connect = [[connectionManager alloc] init];
    if([[utilityManager alloc] getUserDefaultstoString:@"DeviceToken"])
    {
        self.token = [[utilityManager alloc] getUserDefaultstoString:@"DeviceToken"];
    }
    else{
        self.token = @"uatTesting";
    }
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:self.tf_mobile.text,@"phone",@"852",@"phoneAreaCode",self.token,@"deviceToken", nil];
    
    [connect postRequest:SEND_USER_SMS parameters:dict completionHandler:^(bool status, NSDictionary *dict) {
        if(status)
        {
            [self.tf_name resignFirstResponder];
            [self.tf_mobile resignFirstResponder];
            self.v_submit.hidden = NO;
            self.v_system.hidden = YES;
            self.v_popup.hidden = NO;
            if(!self.smsTimer.isValid){
                self.smsTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                                 target: self
                                                               selector:@selector(onTick:)
                                                               userInfo: nil repeats:YES];
                self.btn_reSend.enabled = false;
                self.SMSnum = 60;
            }
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[dict objectForKey:@"error_title"] message:[dict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
        }
    }];
}


-(IBAction)pressBtnresetUser:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep3ViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(IBAction)pressBtnskip:(id)sender{
    utilityManager *utility = [[utilityManager alloc] init];
    connectionManager *connect = [[connectionManager alloc] init];
    dbManager *db = [[dbManager alloc] init];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"phone"],@"phone",[[utilityManager alloc] getUserDefaultstoString:@"phoneAreaCode"],@"phoneAreaCode", nil];
    [connect postRequest:GET_USER_INFO parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            userObj *user = [[userObj alloc] initWithDict:jsonDict];
            [utility saveValuetoUserDefaults:[user toDict]];
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:user.memberID,@"memberID", nil];
            [utility saveValuetoUserDefaults:dict];
            NSString *key = @"userID,username,mobile,phoneAreaCode,imagePath,birthday,lunarBirthday,facebookID,backupPath,deviceToken,currentSize,friendList,pushNotification";
            NSString *value = [NSString stringWithFormat:@"'%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@'", user.memberID,user.username,user.mobile,user.phoneAreaCode,user.imagePath,user.birthday,user.lunarBirthday,user.facebookID,user.backupPath,user.deviceToken,user.currentSize,user.friendList,@"0"];
            [db customSQL:[NSString stringWithFormat:@"Delete From tbl_userProfile Where userID = '%@'",user.memberID]];
            if([db insertSQL:@"tbl_userProfile" tKey:key tValue:value]){
                if(![[utility getUserDefaultstoString:@"backupPath"] isEqualToString:@""])
                {
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                             bundle: nil];
                    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"restoreUserDataViewController"];
                    [self.navigationController pushViewController:vc animated:YES];
                }
                else{
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                             bundle: nil];
                    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep4ViewController"];
                    [self.navigationController pushViewController:vc animated:YES];
                }
            }
        }
    }];
}

-(IBAction)pressBtnChangePNo:(id)sender{
    self.v_popup.hidden = YES;
}

-(IBAction)pressBtnSubmit:(id)sender{
    connectionManager *connect = [[connectionManager alloc] init];
    
    if([[utilityManager alloc] getUserDefaultstoString:@"DeviceToken"])
    {
        self.token = [[utilityManager alloc] getUserDefaultstoString:@"DeviceToken"];
    }
    NSLog(@"code:%@",self.tf_SMScode.text);
    NSString *code = self.tf_SMScode.text;
    NSDictionary *dict1 = [[NSDictionary alloc] initWithObjectsAndKeys:@"852",@"phoneAreaCode",self.tf_mobile.text,@"phone",self.tf_name.text,@"username",code,@"verifyCode",self.token,@"deviceToken", nil];
    utilityManager *utility = [[utilityManager alloc] init];
    [utility saveValuetoUserDefaults:dict1];
    [connect postRequest:CHECK_SMS_CODE parameters:dict1 completionHandler:^(bool status, NSDictionary *dict) {
        if(status)
        {
            if([[[dict objectForKey:@"status"] lowercaseString] isEqualToString:@"fail"])
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[dict objectForKey:@"error_title"] message:[dict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
            }
            else{
                if([[dict objectForKey:@"member"] isEqualToString:@"0"])
                {
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                             bundle: nil];
                    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"registerStep3ViewController"];
                    //                    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"restoreUserDataViewController"];
                    [self.navigationController pushViewController:vc animated:YES];
                    
                }
                else{
                    userObj *user = [[userObj alloc] initWithDict:dict];
                    NSLog(@"user:%@",user);
                    [utility saveValuetoUserDefaults:[user toDict]];
                    NSDictionary *create = [NSDictionary dictionaryWithObjectsAndKeys:[utility NSDateToNSString:[NSDate date] DateFormat:DISPLAYDATEFORMATTER],@"backupDate", nil];
                    [utility saveValuetoUserDefaults:create];
                    self.v_submit.hidden = YES;
                    self.v_system.hidden = NO;
                }
            }
            [self.smsTimer invalidate];
            self.smsTimer = nil;
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[dict objectForKey:@"error_title"] message:[dict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
        }
    }];
}

-(IBAction)pressBtnreSend:(id)sender{
    [self sendSMS];
    if(!self.smsTimer.isValid){
        self.smsTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                         target: self
                                                       selector:@selector(onTick:)
                                                       userInfo: nil repeats:YES];
        self.btn_reSend.enabled = false;
        self.SMSnum = 60;
    }
}

-(IBAction)pressBtnpopupClose:(id)sender{
    //    [UIView animateWithDuration:1
    //                          delay:1.0
    //                        options: UIViewAnimationCurveLinear
    //                     animations:^{
    //                         self.v_popup.hidden = YES;
    //                     }
    //                     completion:^(BOOL finished){
    //                         NSLog(@"Center Animation Done!");
    //                     }];
    self.v_popup.hidden = YES;
}

-(IBAction)pressBtnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}


@end
