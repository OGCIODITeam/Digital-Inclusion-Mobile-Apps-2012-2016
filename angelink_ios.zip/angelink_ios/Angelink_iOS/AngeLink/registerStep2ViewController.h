//
//  registerStep2ViewController.h
//  AngeLink
//
//  Created by kanhan on 3/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface registerStep2ViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *tf_name;
@property (weak, nonatomic) IBOutlet UITextField *tf_mobile;
@property (weak, nonatomic) IBOutlet UITextField *tf_SMScode;
@property (weak, nonatomic) IBOutlet UIView *v_popup;
@property (weak, nonatomic) IBOutlet UITextView *tv_body;
@property (weak, nonatomic) IBOutlet UIButton *btn_resetUser,*btn_skip,*btn_submit,*btn_changePNo,*btn_reSend;
@property (weak, nonatomic) IBOutlet UILabel *lbl_personInfo;
@property (weak, nonatomic) IBOutlet UILabel *lbl_name;
@property (weak, nonatomic) IBOutlet UIButton *btn_register;
@property (weak, nonatomic) IBOutlet UILabel *lbl_mobile;
@property (weak, nonatomic) IBOutlet UILabel *lbl_statusMsg;
@property (weak, nonatomic) IBOutlet UIButton *btn_nameIntro;
@property (weak, nonatomic) IBOutlet UILabel *lbl_code;
@property (weak, nonatomic) IBOutlet UILabel *lbl_status;
@property (weak, nonatomic) IBOutlet UILabel *lbl_timerMsg;
@property (weak, nonatomic) IBOutlet UILabel *lbl_system;
@property (weak, nonatomic) IBOutlet UIButton *btn_mobileIntro;
@property (weak, nonatomic) IBOutlet UIButton *btn_close;
@property (weak, nonatomic) IBOutlet UILabel *tv_msg;
@property (weak, nonatomic) IBOutlet UIView *v_system;
@property (weak, nonatomic) IBOutlet UIView *v_submit;
@property (nonatomic, assign) BOOL newUser;
@property (nonnull, retain) NSString *token;
@property (nonatomic, retain) NSTimer *smsTimer;
@property (assign, nonatomic) int SMSnum;


@end
