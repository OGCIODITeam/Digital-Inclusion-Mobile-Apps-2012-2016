//
//  AppDelegate.h
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
//#import "LocationTracker.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>{
    CLLocationManager *locationManager;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) NSDate *selectedDate;
@property (nonatomic, retain) NSMutableArray *mediaArray,*locationArray;
@property (nonatomic, retain) NSDate *insertTime;

@property (nonatomic, retain) NSTimer *timer,*checklatlng;
@property (nonatomic, retain) MBProgressHUD *hud;

//@property LocationTracker * locationTracker;
//@property (nonatomic) NSTimer* locationUpdateTimer;

-(void) runGPS;
-(void) stopRunGPS;
-(void) showLoading;
-(void) hideLoading;
@end

