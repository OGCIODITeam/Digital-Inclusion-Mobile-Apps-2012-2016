//
//  fdActViewController.m
//  AngeLink
//
//  Created by kanhan on 1/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "fdActViewController.h"
#import "fdActTableViewCell.h"
#import "fbObject.h"
#import "userFBinfo.h"
#import "MessageViewController.h"
#import "AppDelegate.h"

@interface fdActViewController ()

@end

@implementation fdActViewController

-(IBAction)pressBtnTextToSpeech:(id)sender{
    UIButton *btn = (UIButton*)sender;
    self.selBtn = btn;
    
    NSString *str = @"";
    fbObject *obj = [self.aryData objectAtIndex:btn.tag];
    if(obj.FBdescription != nil){
        str = [obj.FBdescription stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    }
    else{
        if(obj.name != nil){
            str = [obj.name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        else if(obj.message != nil){
            str = [obj.message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
    }
    
    [[utilityManager alloc] TextToSpeech:str];
    NSMutableArray *imageArray = [NSMutableArray new];
    
    for (int i = 1; i < 5; i ++) {
        [imageArray addObject:[UIImage imageNamed:[NSString stringWithFormat:@"btn_spk_stop%d.png",i]]];
    }
    [self.selBtn.imageView setAnimationImages:[imageArray copy]];
    [self.selBtn.imageView setAnimationDuration:1.0];
    [self.selBtn.imageView startAnimating];
    [self.selBtn removeTarget:nil
                       action:NULL
             forControlEvents:UIControlEventAllEvents];
    
 
}

-(void) stopTextToSpeech:(NSNotification *)inNotification {
    [self.selBtn.imageView stopAnimating];
    [self.selBtn.imageView setAnimationImages:nil];
    [self.selBtn setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [self.selBtn addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTextToSpeech:) name:@"TextToSpeech" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loopUpdateFunction) name:@"updateData" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addObject:) name:@"addObject" object:nil];
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = @"親友動態";
    header.delegate = self;
    [self.view addSubview:header];
    
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    self.tv_post.separatorColor = [UIColor clearColor];
    [self.tv_post setBackgroundColor:[UIColor clearColor]];
    [self setFontUI];
    
    
    self.refreshControl = [[UIRefreshControl alloc]init];
    [self.refreshControl addTarget:self action:@selector(getFBServer) forControlEvents:UIControlEventValueChanged];
    [self.sv_main addSubview:self.refreshControl];
    [self getFBServer];
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"FB_1.0"];
    UIImage *img2 = [UIImage imageNamed:@"FB_1.1"];
    
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"於Facebook 分享個人訊息，可選擇預設圖案回應留言。";
    NSString *str2 = @"請注意，有關訊息會上載到互聯網，請勿在此輸入個人資料 （如 ： 身份証號碼，銀行帳戶編號等）。";
    
    [aryString addObject:str1];
    [aryString addObject:str2];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    

    [self.view addSubview:self.info];
}

-(void) flashData{
    [self getFBServer];  
}

-(void) addObject:(NSNotification *)inNotification {
    fbObject *obj = (fbObject*) [[inNotification userInfo] objectForKey:@"object"];
    if(obj!=nil){
        [self.aryData insertObject:obj atIndex:0];
    }
    [self getFBServer];
}

-(void) getFBServer{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    [[connectionManager alloc] getUserProfileFromFB:self completionHandler:^(bool success, NSDictionary *jsonData) {
        self.userInfo = jsonData;
        [[connectionManager alloc] getPostDataFromFB:self completionHandler:^(bool success, NSMutableArray *aryData) {
            if(success){
                //                self.loopAry = aryData;
                //                self.aryData = nil;
                [self.aryData removeAllObjects];
                for (int i = 0; i<[aryData count]; i++) {
                    fbObject *obj = [[fbObject alloc] initWithDict:[aryData objectAtIndex:i]];
                    [self.aryData addObject:obj];
                }
            }
            [self.refreshControl endRefreshing];
            [self.tv_post reloadData];
            dispatch_async(dispatch_get_main_queue(), ^{
                [app hideLoading];
            });
        }];
    }];
}

- (void)finishReload{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app.hud hideAnimated:YES];
}

-(IBAction)pressBtnPost:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    MessageViewController *vc = (MessageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"MessageViewController"];
    vc.userInfo = [[userFBinfo alloc] initWithDict:self.userInfo];
    vc.preView = self;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [self presentViewController:nav animated:YES completion:nil];
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.tf_addPost.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    self.tf_addPost.delegate = self;
    [self.btn_addPost setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

-(IBAction)pressBtnCommon:(id)sender{
    UIButton *btn = (UIButton*)sender;
    fbObject *obj = [self.aryData objectAtIndex:btn.tag];
    NSLog(@"obj:%@",[obj toDict]);
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    MessageViewController *vc = (MessageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"MessageViewController"];
    vc.userInfo = [[userFBinfo alloc] initWithDict:self.userInfo];
    vc.dict = [obj toDict];
    vc.obj = obj;
    vc.preView = self;    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [self presentViewController:nav animated:YES completion:nil];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"count:%d",[self.aryData count]);
    return [self.aryData count];    //count number of row from counting array hear cataGorry is An Array
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"fdActTableViewCell";
    fontManager *font = [[fontManager alloc] init];
    fdActTableViewCell* cell = (fdActTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    cell = nil;
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    }
    cell.translatesAutoresizingMaskIntoConstraints = NO;
    userFBinfo *fb = [[userFBinfo alloc] initWithDict:self.userInfo];
    fbObject *obj = [self.aryData objectAtIndex:indexPath.row];
    for(UIView *subview in [cell.v_body subviews]) {
        [subview removeFromSuperview];
    }
    float orgY = 0.0;
    float space = 5.0;
    float orgX = 0.0;
    cell.lbl_username.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.iv_user = [[UIImageView alloc] initWithFrame:CGRectMake(orgX, orgY, 43, 43)];
    [cell.iv_user sd_setImageWithURL:[NSURL URLWithString:fb.picture]];
    
    cell.iv_user.isAccessibilityElement = true;
    cell.iv_user.accessibilityTraits = UIAccessibilityTraitNone;
    cell.iv_user.accessibilityLabel = @"圖片";

    
    orgX += cell.iv_user.frame.size.width;
    orgX += space;
    cell.btn_TextToSpeak = [UIButton buttonWithType:UIButtonTypeCustom];
    cell.btn_TextToSpeak.frame = CGRectMake(self.tv_post.frame.size.width - 43 - 10, orgY, 43, 43);
    [cell.btn_TextToSpeak setTag:indexPath.row];
    [cell.btn_TextToSpeak setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [cell.btn_TextToSpeak addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell.btn_TextToSpeak setTag:indexPath.row];
    [cell.btn_TextToSpeak addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.btn_TextToSpeak.isAccessibilityElement = true;
    cell.btn_TextToSpeak.accessibilityTraits = UIAccessibilityTraitNone;
    cell.btn_TextToSpeak.accessibilityLabel = @"文字轉語音";
    
    cell.lbl_username = [[UILabel alloc] initWithFrame:CGRectMake(orgX, orgY, cell.btn_TextToSpeak.frame.origin.x - orgX - space, 43)];
    cell.lbl_username.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    NSString *str = [[obj.created_time stringByReplacingOccurrencesOfString:@"T" withString:@" "] stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    NSDateFormatter* gmtDf = [[NSDateFormatter alloc] init];
    [gmtDf setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    [gmtDf setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate* gmtDate = [gmtDf dateFromString:str];
    
    cell.lbl_username.text = [NSString stringWithFormat:@"%@\n%@",fb.name,[[utilityManager alloc] NSDateToNSString:gmtDate DateFormat:DISPLAYDATEFORMATTER]];
    [self setColorForText:fb.name orgString:cell.lbl_username.text object:cell.lbl_username withColor:[UIColor blackColor]];
    cell.lbl_username.lineBreakMode = LINE_BREAK_WORD_WRAP;
    cell.lbl_username.numberOfLines = 2;
    
    cell.btn_TextToSpeak.isAccessibilityElement = true;
    cell.btn_TextToSpeak.accessibilityTraits = UIAccessibilityTraitNone;
    cell.btn_TextToSpeak.accessibilityLabel = cell.lbl_username.text;

    orgX = 0.0;
    orgY += cell.lbl_username.frame.size.height;
    orgY += space;
    
    if(obj.FBdescription != nil || obj.message != nil || obj.name != nil){
        cell.tv_description = [[UITextView alloc] initWithFrame:CGRectMake(orgX, orgY, self.tv_post.frame.size.width - 10, 60)];
        cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.tv_description.editable = NO;
        cell.tv_description.selectable = NO;
        cell.tv_description.textContainerInset = UIEdgeInsetsZero;
        cell.tv_description.contentInset = UIEdgeInsetsMake(0.0f,
                                                            0.0f,
                                                            0.0f,
                                                            0.0f);
        if(obj.FBdescription != nil){
            cell.tv_description.text = [obj.FBdescription stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        else if(obj.message != nil){
            cell.tv_description.text = [obj.message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        else if(obj.name != nil){
            cell.tv_description.text = [obj.name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        }
        cell.tv_description.translatesAutoresizingMaskIntoConstraints = NO;
        CGRect frame = cell.tv_description.frame;
        frame.size.height = [[utilityManager alloc] getUITextViewHeight:cell.tv_description];
        cell.tv_description.frame = frame;
        cell.tv_description.textColor = [UIColor blackColor];
        cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.tv_description.scrollEnabled = NO;
        cell.tv_description.frame = CGRectMake(cell.tv_description.frame.origin.x, orgY, cell.tv_description.frame.size.width, cell.tv_description.frame.size.height);
        [cell.v_body addSubview:cell.tv_description];
        orgY += cell.tv_description.frame.size.height;
        orgY += space;
        cell.tv_description.isAccessibilityElement = true;
        cell.tv_description.accessibilityTraits = UIAccessibilityTraitNone;
        cell.tv_description.accessibilityLabel = cell.tv_description.text;

    }
    if(obj.full_picture != nil){
        cell.iv_postImg = [[UIImageView alloc] initWithFrame:CGRectMake(orgX, orgY, 310, 310)];
        [cell.iv_postImg sd_setImageWithURL:[NSURL URLWithString:obj.full_picture] placeholderImage:[UIImage imageNamed:@"IMG_bk_dairy"]];
        cell.iv_postImg.center = CGPointMake((self.tv_post.frame.size.width - 10)/2, cell.iv_postImg.center.y);
        [cell.iv_postImg setContentMode:UIViewContentModeScaleAspectFit];
        [cell.v_body addSubview:cell.iv_postImg];
        orgY += cell.iv_postImg.frame.size.height;
        orgY += space;
        cell.iv_postImg.isAccessibilityElement = true;
        cell.iv_postImg.accessibilityTraits = UIAccessibilityTraitNone;
        cell.iv_postImg.accessibilityLabel = @"圖片";
    }
    cell.btn_fb_like = [[UIImageView alloc] initWithFrame:CGRectMake(orgX, orgY, 98, 65)];
    cell.btn_fb_like.image = [UIImage imageNamed:@"ico_fb_like_tc"];
    
    cell.btn_fb_like.isAccessibilityElement = true;
    cell.btn_fb_like.accessibilityTraits = UIAccessibilityTraitNone;
    cell.btn_fb_like.accessibilityLabel = @"喜歡";
    
    orgX += cell.btn_fb_like.frame.size.width;
    orgX += space;
    
    cell.lbl_like_cnt = [[UILabel alloc] initWithFrame:CGRectMake(orgX, orgY, 50, 65)];
    cell.lbl_like_cnt.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.lbl_like_cnt.text = [NSString stringWithFormat:@"%d",[[[obj.likes objectForKey:@"summary"] objectForKey:@"total_count"] intValue]];
    [cell.lbl_like_cnt sizeToFit];
    
    cell.lbl_like_cnt.isAccessibilityElement = true;
    cell.lbl_like_cnt.accessibilityTraits = UIAccessibilityTraitNone;
    cell.lbl_like_cnt.accessibilityLabel = cell.lbl_like_cnt.text;
    
    //    cell.lbl_like_cnt.center = CGPointMake(cell.lbl_like_cnt.center.x, cell.btn_fb_like.center.y);
    
    cell.lbl_com = [[UILabel alloc] initWithFrame:CGRectMake(self.tv_post.frame.size.width - 30 - 20, orgY, 30, 65)];
    cell.lbl_com.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.lbl_com.text = [NSString stringWithFormat:@"%d",[[[obj.comments objectForKey:@"summary"] objectForKey:@"total_count"] intValue]];
    //    [cell.lbl_com sizeToFit];
    //    cell.lbl_com = [[UILabel alloc] initWithFrame:CGRectMake(self.tv_post.frame.size.width - cell.lbl_com.frame.size.width -30, orgY, cell.lbl_com.frame.size.width, cell.lbl_com.frame.size.height)];
    cell.lbl_com.textAlignment = ALIGN_CENTER;
    cell.lbl_com.center = CGPointMake(cell.lbl_com.center.x, orgY + (65/2));

    cell.lbl_com.isAccessibilityElement = true;
    cell.lbl_com.accessibilityTraits = UIAccessibilityTraitNone;
    cell.lbl_com.accessibilityLabel = cell.lbl_com.text;

    
    cell.btn_com = [UIButton buttonWithType:UIButtonTypeCustom];
    cell.btn_com.frame = CGRectMake(cell.lbl_com.frame.origin.x - space - 140, orgY, 140, 65);
    [cell.btn_com setImage:[UIImage imageNamed:@"btn_fb_reply"] forState:UIControlStateNormal];
    [cell.btn_com addTarget:self action:@selector(pressBtnCommon:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btn_com setTag:indexPath.row];
    cell.btn_com.center = CGPointMake(cell.btn_com.center.x, orgY + (65/2));
    cell.lbl_like_cnt.center = CGPointMake(cell.lbl_like_cnt.center.x, orgY + (65/2));
    cell.btn_fb_like.center = CGPointMake(cell.btn_fb_like.center.x, orgY + (65/2));
    
    cell.btn_com.isAccessibilityElement = true;
    cell.btn_com.accessibilityTraits = UIAccessibilityTraitNone;
    cell.btn_com.accessibilityLabel = @"評論";
    
    [cell.v_body addSubview:cell.iv_user];
    [cell.v_body addSubview:cell.btn_TextToSpeak];
    [cell.v_body addSubview:cell.lbl_username];
    [cell.v_body addSubview:cell.btn_fb_like];
    [cell.v_body addSubview:cell.lbl_like_cnt];
    [cell.v_body addSubview:cell.lbl_com];
    [cell.v_body addSubview:cell.btn_com];
    
    [cell setBackgroundColor:[UIColor clearColor]];
    self.tv_post.frame = CGRectMake(self.tv_post.frame.origin.x, self.tv_post.frame.origin.y, self.tv_post.frame.size.width, self.tv_post.contentSize.height);
    self.sv_main.contentSize = CGSizeMake(self.tv_post.frame.size.width, self.tv_post.frame.size.height + space);
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    return cell;
}

-(void)setColorForText:(NSString*) textToFind orgString:(NSString*) orgStr object:(UILabel*)obj withColor:(UIColor*) color
{
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:obj.text];
    NSRange range = [orgStr rangeOfString:textToFind options:NSCaseInsensitiveSearch];
    if (range.location != NSNotFound) {
        [text addAttribute:NSFontAttributeName value:[[fontManager alloc] getBoldsize:[[fontManager alloc] getSettingFont:@"Contact"]] range:range];
        [text addAttribute:NSForegroundColorAttributeName value:color range:range];
    }
    obj.attributedText = text;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *simpleTableIdentifier = @"fdActTableViewCell";
    fontManager *font = [[fontManager alloc] init];
    fdActTableViewCell* cell = (fdActTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    cell = nil;
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    }
    cell.translatesAutoresizingMaskIntoConstraints = NO;
    float space = 5;
    float orgY = 0.0;
    fbObject *obj = [self.aryData objectAtIndex:indexPath.row];
    orgY += 43;
    orgY += space;
    cell.tv_description = [[UITextView alloc] initWithFrame:CGRectMake(0, orgY, cell.v_body.frame.size.width, 80)];
    cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.tv_description.textContainerInset = UIEdgeInsetsZero;
    cell.tv_description.contentInset = UIEdgeInsetsMake(0.0f,
                                                        0.0f,
                                                        0.0f,
                                                        0.0f);
    if(obj.message != nil){
        cell.tv_description.text = [obj.message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [cell.tv_description setHidden:NO];
    }
    else if(obj.name != nil){
        cell.tv_description.text = [obj.name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [cell.tv_description setHidden:NO];
    }
    else{
        [cell.tv_description setHidden:YES];
    }
    if(!cell.tv_description.hidden){
        cell.tv_description.translatesAutoresizingMaskIntoConstraints = NO;
        CGRect frame = cell.tv_description.frame;
        frame.size.height = [[utilityManager alloc] getUITextViewHeight:cell.tv_description];
        cell.tv_description.frame = frame;
        cell.tv_description.textColor = [UIColor blackColor];
        cell.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.tv_description.scrollEnabled = NO;
        cell.tv_description.frame = CGRectMake(cell.tv_description.frame.origin.x, orgY, cell.tv_description.frame.size.width, cell.tv_description.frame.size.height);
        orgY += cell.tv_description.frame.size.height;
        orgY += space;
    }
    
    if(obj.full_picture != nil){
        orgY += 310;
        orgY += space;
    }
    orgY += 75;
    orgY += space;
    return orgY;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([textField canResignFirstResponder]) {
        [textField resignFirstResponder];
    }
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    // add your method here
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [self.view bringSubviewToFront:self.info];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
