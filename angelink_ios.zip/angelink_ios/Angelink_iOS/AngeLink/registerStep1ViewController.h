//
//  registerStep1ViewController.h
//  AngeLink
//
//  Created by kanhan on 14/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"

@interface registerStep1ViewController : UIViewController<headerBarViewDelegate>
    @property (weak, nonatomic) IBOutlet UILabel *lbl_title;
    @property (weak, nonatomic) IBOutlet UITextView *tv_msg;
    @property (weak, nonatomic) IBOutlet UIButton *btn_agree;

@end
