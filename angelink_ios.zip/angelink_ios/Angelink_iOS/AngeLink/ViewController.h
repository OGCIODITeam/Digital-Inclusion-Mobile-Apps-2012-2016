//
//  ViewController.h
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "infoView.h"


@interface ViewController : UIViewController<UIGestureRecognizerDelegate,infoViewDelegate>

@property (weak, nonatomic) IBOutlet UIButton *btnFDlist;
@property (weak, nonatomic) IBOutlet UIButton *btnAlbum;
@property (weak, nonatomic) IBOutlet UIButton *btnFDactive;
@property (weak, nonatomic) IBOutlet UIButton *btnSetting;
@property (weak, nonatomic) IBOutlet UIView *v_weather;
@property (weak, nonatomic) IBOutlet UIImageView *im_weater;
@property (weak, nonatomic) IBOutlet UILabel *lbl_temp;
@property (weak, nonatomic) IBOutlet UILabel *lbl_per;
@property (weak, nonatomic) IBOutlet UIImageView *iv_temp;
@property (weak, nonatomic) IBOutlet UIImageView *iv_humiv;
@property (weak, nonatomic) IBOutlet UIImageView *iv_deg;
@property (weak, nonatomic) IBOutlet UIImageView *iv_per;
@property (nonatomic, retain) NSString *WeatherWarning;
@property (weak, nonatomic) IBOutlet UIView *v_banner;
@property (weak, nonatomic) IBOutlet UIImageView *iv_banner;
@property (weak, nonatomic) IBOutlet UIButton *btn_TextToSpeech;
@property (weak, nonatomic) IBOutlet UILabel *lbl_lastUpdate;
@property (nonatomic, retain) NSDate *connectionTime;
@property (nonatomic, retain) NSTimer *timer;
@property (nonatomic, retain) NSDictionary *bannerDict;
@property (weak, nonatomic) IBOutlet UIButton *btn_spk;
@property (weak, nonatomic) IBOutlet UIButton *btn_close;

@property (nonatomic, retain) infoView *info;


@end

