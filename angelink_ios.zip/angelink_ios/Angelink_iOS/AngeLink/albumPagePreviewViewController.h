//
//  albumPagePreviewViewController.h
//  AngeLink
//
//  Created by kanhan on 22/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface albumPagePreviewViewController : UIViewController<iCarouselDelegate,iCarouselDataSource,headerBarViewDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet iCarousel *ic_main;
@property (weak, nonatomic) IBOutlet UIButton *btn_prev;
@property (weak, nonatomic) IBOutlet UIButton *btn_next;
@property (nonatomic, retain) NSMutableArray *aryData;
@property (nonatomic, assign) int pageNo;
@property (nonatomic, retain) NSString *headerTitle;
@property (nonatomic, retain) infoView *info;
@end
