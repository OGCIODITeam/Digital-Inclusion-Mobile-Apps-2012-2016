//
//  addDefaultPageViewController.m
//  AngeLink
//
//  Created by kanhan on 6/12/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//
#import "addDefaultPageViewController.h"
#import "albumObj.h"
#import "albumPageObj.h"
#import "selCalendarBtn.h"
#import "popupCalendarViewController.h"
#import "AppDelegate.h"
#import "UIImage+addition.h"


@interface addDefaultPageViewController ()

@end

@implementation addDefaultPageViewController
-(void) loopUploadFunction{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];

    if(self.cnt >= [self.answerList count]){
        [app hideLoading];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        self.btn_nextQuestion.enabled = NO;
        self.btn_skip.enabled = NO;
        NSMutableArray *ary = [NSMutableArray new];
        if([self.answerImage objectAtIndex:self.cnt] != nil)
            [ary addObject:[self.answerImage objectAtIndex:self.cnt]];
        else
            ary = nil;
        [self uploadFile:ALBUM_PAGE_HANDLER parameters:[self.answerList objectAtIndex:self.cnt] images:ary completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                self.cnt++;
                NSDictionary *userInfo = [[NSDictionary alloc] init];
                [[NSNotificationCenter defaultCenter] postNotificationName: @"UploadData" object:nil userInfo:userInfo];
            }
            else{
                self.btn_nextQuestion.enabled = YES;
                self.btn_skip.enabled = YES;
            }
        }];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopTextToSpeech:) name:@"TextToSpeech" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loopUploadFunction) name:@"UploadData" object:nil];
    self.header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    self.header.lbl_pageTittle.text = self.headerTitle;
    //    header.hiddenBackBtn = YES;
    self.header.delegate = self;
    self.TotalQuestion = 0;
    self.CurrectNum = 0;
    [self.view addSubview:self.header];
    if(self.answerList == nil){
        self.answerList = [NSMutableArray new];
    }
    if(self.answerImage == nil){
        self.answerImage = [NSMutableArray new];
    }
    
    if(self.pageRecord){
        albumObj *obj = (albumObj*)self.record;
        albumPageObj* objPage = (albumPageObj*)self.pageRecord;
        
        if(![objPage.imagePath isEqualToString:@""])
        {
            NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,objPage.imagePath];
            [[connectionManager alloc] downloadFile:urlPath foldername:@"temp" progress:nil completionBlock:^(BOOL succeeded, NSURL *url) {
                NSData *imageData1 = [[utilityManager alloc] ConvertImagePathToData:[url absoluteString]];
                self.originalImage  = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
                self.iv_inputImage.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:@"UploadImage" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
                {
                    NSData *imageData1 = [[utilityManager alloc] getDataFile:@"UploadImage.jpeg" folderName:@"temp" isDoucmentFolder:NO];
                    self.iv_inputImage.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
                }
            }];
        }
        
        self.pageSeq = [objPage.pageSeq intValue];
        dbManager *db = [[dbManager alloc] init];
        NSMutableArray *ary = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"pageTitle='%@' and pageSeq='%@'",objPage.pageTitle,objPage.pageSeq] option:@"Order BY questionID"];
//        NSMutableArray *ary = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"pageSeq='%@'",objPage.pageSeq] option:@""];
//        self.questionDict = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"pageSeq='%@'",objPage.pageSeq] option:@""];
        if([ary count]>0){
            self.pageSeq = [[[ary objectAtIndex:0] objectForKey:@"pageSeq"] intValue];
            self.subQuestionID = [[[ary objectAtIndex:0] objectForKey:@"subQuestionID"] intValue];;
        }
        else{
        self.subQuestionID = 1;
        }
        self.stringValue = @"";
        
        self.stringPageTitle = @"";
        [self setViewUI];
        // Do any additional setup after loading the view.
//        albumObj *obj = (albumObj*)self.record;
        if(self.aryObject == nil){
            self.aryObject = [NSMutableArray new];
        }
        else{
            [self.aryObject removeAllObjects];
        }
        [self loadQuestion:obj.albumSeq];
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureCaptured:)];
        [self.sv_main addGestureRecognizer:singleTap];
    }
    else{
        self.pageSeq = 0;
        self.subQuestionID = 1;
        self.stringValue = @"";
        self.stringPageTitle = @"";
        [self setViewUI];
        // Do any additional setup after loading the view.
        albumObj *obj = (albumObj*)self.record;
        if(self.aryObject == nil){
            self.aryObject = [NSMutableArray new];
        }
        else{
            [self.aryObject removeAllObjects];
        }
        
        [self loadQuestion:obj.albumSeq];
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureCaptured:)];
        [self.sv_main addGestureRecognizer:singleTap];
//        NSMutableArray *ary = [[dbManager alloc] selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"questionID='%@'",obj.albumID] option:@"GROUYP BY pageSeq"];
    }
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.4_Input_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.4_Input_2"];
    UIImage *img3 = [UIImage imageNamed:@"Book_6.4_Input_3"];
    UIImage *img4 = [UIImage imageNamed:@"Book_6.4_Input_4"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    [aryImg addObject:img4];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"請在空格內回答問題，完成問答題後小天使會協助你完成人生紀念冊相簿";
    NSString *str2 = @"讀出問題內容";
    NSString *str3 = @"暫時不回答這條問題，並跳到下一題";
    NSString *str4 = @"完成這條問題，並回答下題";
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    [aryString addObject:str4];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];    
    [self setAccessibility];
}

-(void) setAccessibility{    
    self.btn_skip.isAccessibilityElement = true;
    self.btn_skip.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_skip.accessibilityLabel = @"略過";
    
    self.btn_nextQuestion.isAccessibilityElement = true;
    self.btn_nextQuestion.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_nextQuestion.accessibilityLabel = @"儲存";
    
    self.btn_TextToSpeech.isAccessibilityElement = FALSE;
    self.btn_TextToSpeech.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_TextToSpeech.accessibilityLabel = @"說問題";
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (void)singleTapGestureCaptured:(UITapGestureRecognizer *)gesture
{
    [self.view endEditing:YES];
}

-(void) stopTextToSpeech:(NSNotification *)inNotification {
    [self.btn_TextToSpeech.imageView stopAnimating];
    [self.btn_TextToSpeech.imageView setAnimationImages:nil];
    [self.btn_TextToSpeech setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [self.btn_TextToSpeech addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
}

-(IBAction)pressBtnTextToSpeech:(id)sender{
    [[utilityManager alloc] TextToSpeech:self.voiceTitle];
    NSMutableArray *imageArray = [NSMutableArray new];
    
    for (int i = 1; i < 5; i ++) {
        [imageArray addObject:[UIImage imageNamed:[NSString stringWithFormat:@"btn_spk_stop%d.png",i]]];
    }
    [self.btn_TextToSpeech.imageView setAnimationImages:[imageArray copy]];
    [self.btn_TextToSpeech.imageView setAnimationDuration:1.0];
    [self.btn_TextToSpeech.imageView startAnimating];
    [self.btn_TextToSpeech removeTarget:nil
                                 action:NULL
                       forControlEvents:UIControlEventAllEvents];
}

-(void) noticeChangeKeyboard:(NSNotification *)inNotification {
    NSDictionary *userInfo = [inNotification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
//    CGFloat keyboardTop = keyboardRect.origin.y;
    
    [UIView animateWithDuration:0.2
                          delay:0.3
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         if(self.view.frame.origin.y == 0){
                             self.view.frame = CGRectMake(0, self.view.frame.origin.y - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
                         }
                         else{
                             self.view.frame = CGRectMake(0, 0 - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
                         }
                     }
                     completion:^(BOOL finished){
                     }];
}

-(void) noticeShowKeyboard:(NSNotification *)inNotification {
    NSDictionary *userInfo = [inNotification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
//    CGFloat keyboardTop = keyboardRect.origin.y;
    if(self.view.frame.origin.y == 0){
        self.view.frame = CGRectMake(0, self.view.frame.origin.y - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
    }
}

-(void) noticeHideKeyboard:(NSNotification *)inNotification {
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}

-(void) loadQuestion:(NSString*) albumID{
    self.questionID = [albumID intValue];
    if(!self.pageRecord){
        dbManager *db = [[dbManager alloc] init];
        NSMutableArray *ary = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"questionID='%d' AND pageSeq='%d' AND subQuestionID='%d'",self.questionID,self.pageSeq,self.subQuestionID] option:@"Order By pageSeq"];
        NSMutableArray *CheckTotal = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"questionID = '%d'",self.questionID] option:@"Group BY pageSeq, subQuestionID"];
        self.TotalQuestion = (int)[CheckTotal count];
        
        if([ary count] > 0){
            self.CurrectNum ++;
            self.header.lbl_pageTittle.text = [NSString stringWithFormat:@"%@ 題目 %d/%d",self.headerTitle,self.CurrectNum,self.TotalQuestion];
            [self setQuestionUI:ary];
            self.questionList = ary;
        }
        else{
            self.pageSeq++;
            self.subQuestionID = 1;
//            self.CurrectNum ++;
            self.header.lbl_pageTittle.text = [NSString stringWithFormat:@"%@ 題目 %d/%d",self.headerTitle,self.CurrectNum,self.TotalQuestion];
            NSMutableArray *ary = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"questionID='%d' AND pageSeq='%d' AND subQuestionID='%d'",self.questionID,self.pageSeq,self.subQuestionID] option:@"Order By pageSeq"];
            if([ary count] > 0){
                self.stringValue = @"";
                [self loadQuestion:albumID];
            }
            else{
                if([self.answerList count] > 0){
                    self.cnt = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName: @"UploadData" object:nil userInfo:nil];
                }
                else{
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }
        }
    }
    else{
        dbManager *db = [[dbManager alloc] init];
        
        NSMutableArray *ary = [db selectSQL:@"tbl_default_page" where:[NSString stringWithFormat:@"questionID='%@' AND pageSeq='%d' AND subQuestionID='%d'",albumID,self.pageSeq,self.subQuestionID] option:@"Order By pageSeq"];
        NSMutableArray *ary_ques = [db selectSQL:@"tbl_default_answer" where:[NSString stringWithFormat:@"questionID='%@' AND pageSeq='%d' AND subQuestionID='%d'",albumID,self.pageSeq,self.subQuestionID] option:@""];
        if([ary_ques count] > 0){
            self.questionDict = [ary_ques objectAtIndex:0];
        }
        if([ary count] > 0){
            [self setQuestionUI:ary];
            self.questionList = ary;
        }
        else{
            if([self.answerList count] > 0){
                self.cnt = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName: @"UploadData" object:nil userInfo:nil];
            }
            else{
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
        
    }
    [self setAccessibility];
}

-(void) setQuestionUI:(NSMutableArray*)questionList{
    [self.aryObject removeAllObjects];
    NSArray *viewsToRemove = [self.sv_main subviews];
    for (UIView *v in viewsToRemove) {
        if(v != self.v_inputImage){
            [v removeFromSuperview];
        }
    }
    NSString *answer = @"";
    NSMutableArray *ary = [[dbManager alloc] selectSQL:@"tbl_default_answer" where:[NSString stringWithFormat:@"questionID='%d' AND pageSeq='%d' AND subQuestionID='%d'",self.questionID,self.pageSeq,self.subQuestionID] option:@"Order By id desc"];
    if([ary count]>0){
        answer = [[ary objectAtIndex:0] objectForKey:@"answer"];
    }
    
    
    [self.sv_main setBackgroundColor:[UIColor whiteColor]];
    self.sv_main.layer.cornerRadius=8.0f;
    self.sv_main.layer.masksToBounds=YES;
    self.sv_main.layer.borderColor=[[UIColor whiteColor] CGColor];
    self.sv_main.layer.borderWidth= 3.0f;

    if(self.iv_inputImage.frame.size.height > 0){
        self.orgRect = self.v_inputImage.frame;
    }
    int orgX = 5;
    int orgY = 5;
    fontManager *font = [[fontManager alloc] init];
    UILabel *question = [[UILabel alloc] initWithFrame:CGRectMake(orgX, orgY, self.sv_main.frame.size.width - 45 - 10, 100)];
    question.lineBreakMode = LINE_BREAK_WORD_WRAP;
    question.numberOfLines = 2;
    question.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    question.text = [[questionList objectAtIndex:0] objectForKey:@"question"];
    self.voiceTitle = [[questionList objectAtIndex:0] objectForKey:@"question"];
    self.stringPageTitle = [[questionList objectAtIndex:0] objectForKey:@"pageTitle"];

    [self.sv_main addSubview:question];
    [self.aryObject addObject:question];
    [question sizeToFit];
    orgX += question.frame.size.width;
    orgX+= 5;
    self.btn_TextToSpeech = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btn_TextToSpeech.frame = CGRectMake(orgX, orgY, 42, 42);
    [self.btn_TextToSpeech setImage:[UIImage imageNamed:@"btn_spk"] forState:UIControlStateNormal];
    [self.btn_TextToSpeech addTarget:self action:@selector(pressBtnTextToSpeech:) forControlEvents:UIControlEventTouchUpInside];
    [self.sv_main addSubview:self.btn_TextToSpeech];
    self.btn_TextToSpeech.isAccessibilityElement = TRUE;
    self.btn_TextToSpeech.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_TextToSpeech.accessibilityLabel = self.voiceTitle;
    
    orgY += question.frame.size.height;
    orgY += 5;
    [self changeBtnSkip:[[questionList objectAtIndex:0] objectForKey:@"lastQuestion"]];
    orgX = 5;
    if([[[questionList objectAtIndex:0] objectForKey:@"image"] isEqualToString:@"Y"]){
        [self.v_inputImage setBackgroundColor:[UIColor clearColor]];
        [self.iv_inputImage setBackgroundColor:[UIColor lightGrayColor]];
        self.v_inputImage.hidden = NO;
        self.v_inputImage.frame = CGRectMake(self.v_inputImage.frame.origin.x, orgY, self.v_inputImage.frame.size.width, self.v_inputImage.frame.size.height);
        self.iv_inputImage.image = self.originalImage;
//        self.originalImage = nil;
        orgY += self.v_inputImage.frame.size.height;
        orgY += 5;
    }
    else{
        [self.v_inputImage setBackgroundColor:[UIColor clearColor]];
        self.v_inputImage.hidden = YES;
        self.iv_inputImage.image = nil;
//        self.originalImage = nil;
        orgY += 0;
        orgY += 5;
    }
    for (int i = 0; i < [questionList count]; i++) {
        NSDictionary *dict = [questionList objectAtIndex:i];
        if([[dict objectForKey:@"answerType"] isEqualToString:@"BD"] || [[dict objectForKey:@"answerType"] isEqualToString:@"CD"]){
            selCalendarBtn *btn = [[selCalendarBtn alloc] initWithFrame:CGRectMake(orgX, orgY, self.sv_main.frame.size.width - 10, 60)];
            if([[utilityManager alloc] getUserDefaultstoString:@"birthday"] != nil && [[dict objectForKey:@"answerType"] isEqualToString:@"BD"]){
                [btn setTitle:[[utilityManager alloc] getUserDefaultstoString:@"birthday"] forState:UIControlStateNormal];
                self.currectDate = [[utilityManager alloc] NSStringToNSDate:[[utilityManager alloc] getUserDefaultstoString:@"birthday"] DateFormat:BRITHDAYDATETIMEFORMAT];
                AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
                app.selectedDate = [[utilityManager alloc] NSStringToNSDate:[[utilityManager alloc] getUserDefaultstoString:@"birthday"] DateFormat:BRITHDAYDATETIMEFORMAT];
            
            }
            [btn addTarget:self action:@selector(pressBtnCalendar:) forControlEvents:UIControlEventTouchUpInside];
            if(![answer isEqualToString:@""]){
                [btn setTitle:answer forState:UIControlStateNormal];
            }
            [self.sv_main addSubview:btn];
            [self.aryObject addObject:btn];
            orgY += btn.frame.size.height;
            orgY += 5;
        }
        else if([[dict objectForKey:@"answerType"] isEqualToString:@"FT"]){
            UITextField *obj = [[UITextField alloc] initWithFrame:CGRectMake(orgX, orgY, self.sv_main.frame.size.width - 10, 60)];
            if(![answer isEqualToString:@""]){
                obj.text = answer;
            }
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            [[utilityManager alloc] setLeftSpaceToTextField:obj];
            obj.layer.cornerRadius=0.0f;
            obj.layer.masksToBounds=YES;
            obj.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
            obj.layer.borderWidth= 3.0f;
            [obj setBackgroundColor:[UIColor whiteColor]];
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            obj.delegate = self;
            [self.sv_main addSubview:obj];
            [self.aryObject addObject:obj];
            orgY += obj.frame.size.height;
            orgY += 5;
        }
        else if([[dict objectForKey:@"answerType"] isEqualToString:@"LF"]){
            UITextView *obj = [[UITextView alloc] initWithFrame:CGRectMake(orgX, orgY, self.sv_main.frame.size.width - 10, self.sv_main.frame.size.height - orgY - 10)];
            if(![answer isEqualToString:@""]){
                obj.text = answer;
            }
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            obj.layer.cornerRadius=0.0f;
            obj.layer.masksToBounds=YES;
            obj.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
            obj.layer.borderWidth= 3.0f;
            [obj setBackgroundColor:[UIColor whiteColor]];
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            //            obj.delegate = self;
            [self.sv_main addSubview:obj];
            [self.aryObject addObject:obj];
            orgY += obj.frame.size.height;
            orgY += 5;
        }
        else if([[dict objectForKey:@"answerType"] isEqualToString:@"MC"]){
            UIButton *obj = [UIButton buttonWithType:UIButtonTypeCustom];
            obj.frame = CGRectMake(orgX, orgY, self.sv_main.frame.size.width - 10, 60);
            obj.layer.cornerRadius=0.0f;
            obj.layer.masksToBounds=YES;
            obj.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
            obj.layer.borderWidth= 3.0f;
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            //            [obj setBackgroundColor:[UIColor whiteColor]];
            [obj setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [obj setBackgroundImage:[[utilityManager alloc] imageFromColor:[UIColor whiteColor]] forState:UIControlStateNormal];
            [obj setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            [obj setBackgroundImage:[[utilityManager alloc] imageFromColor:[UIColor blueColor]] forState:UIControlStateSelected];
            [obj.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
            //            [obj setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [obj setTitle:[dict objectForKey:@"answer"] forState:UIControlStateNormal];
            if(![answer isEqualToString:@""] && [answer isEqualToString:[dict objectForKey:@"answer"]]){
                obj.selected = YES;
                answer = @"";
            }
            [obj addTarget:self action:@selector(pressBtnSelected:) forControlEvents:UIControlEventTouchUpInside];
            [self.sv_main addSubview:obj];
            [self.aryObject addObject:obj];
            orgY += obj.frame.size.height;
            orgY += 5;
        }
        else if([[dict objectForKey:@"answerType"] isEqualToString:@"MF"]){
            UITextField *obj = [[UITextField alloc] initWithFrame:CGRectMake(orgX, orgY, self.sv_main.frame.size.width - 10, 60)];
            if(![answer isEqualToString:@""]){
                obj.text = answer;
            }
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            [[utilityManager alloc] setLeftSpaceToTextField:obj];
            obj.placeholder = [NSString stringWithFormat:@"%@:請輸入",[dict objectForKey:@"answer"]];
            obj.layer.cornerRadius=0.0f;
            obj.layer.masksToBounds=YES;
            obj.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
            obj.layer.borderWidth= 3.0f;
            obj.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
            [obj setBackgroundColor:[UIColor whiteColor]];
            obj.delegate = self;
            [self.sv_main addSubview:obj];
            [self.aryObject addObject:obj];
            orgY += obj.frame.size.height;
            orgY += 5;
        }
    }
    self.sv_main.contentSize = CGSizeMake(self.sv_main.frame.size.width, orgY);
}

-(IBAction)pressBtnSelected:(id)sender{
    UIButton *obj = (UIButton*) sender;
    for(int i=0;i<[self.aryObject count];i++){
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UIButton class]]){
            UIButton *btn = [self.aryObject objectAtIndex:i];
            if(btn != obj){
                btn.selected = false;
            }
            else{
                btn.selected = true;
            }
        }
    }
    
}

-(void)changeBtnSkip:(NSString*)isSkip{
    if([isSkip isEqualToString:@"Y"]){
        [self.btn_skip setTitle:@"略過" forState:UIControlStateNormal];
    }
    else{
        [self.btn_skip setTitle:@"略過" forState:UIControlStateNormal];
    }
}

-(IBAction)pressBtnSkip:(id)sender{
    NSString *pageStatus = @"P";
    if(self.pageRecord){
        albumPageObj* objPage = (albumPageObj*)self.pageRecord;
        NSDictionary *dict = [self.questionList objectAtIndex:0];
        if([[dict objectForKey:@"lastQuestion"] isEqualToString:@"Y"]){
            self.stringValue = [NSString stringWithFormat:@"%@/r/n",[self getObjectValue:self.stringValue]];
            albumObj *obj = (albumObj*)self.record;
            NSString *imageName = @"";
            NSMutableDictionary *dictImage = [NSMutableDictionary new];
            if(self.originalImage != nil){
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:[NSString stringWithFormat:@"Default%@",objPage.pageID] filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO]){
                    NSMutableDictionary *dictImage = [NSMutableDictionary new];
                    [dictImage setValue:[[utilityManager alloc] getDataFilePath:[NSString stringWithFormat:@"Default%@.jpeg",objPage.pageID] folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
                    [dictImage setValue:[NSString stringWithFormat:@"Default%@.jpeg",objPage.pageID]  forKey:@"fileName"];
                    [dictImage setValue:@"jpeg" forKey:@"fileType"];
                    [dictImage setValue:@"image" forKey:@"paramKey"];
                    imageName = [NSString stringWithFormat:@"Default%@.jpg",objPage.pageID];
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
                else{
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
            }
            else{
                [self.answerImage addObject:dictImage];
                self.originalImage = nil;
            }
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_AL_PG",@"action",self.stringValue,@"description",@"0",@"posType",imageName,@"imagePath",@"",@"audioPath",@"",@"videoPath",@"",@"videoThumb",@"3",@"residenceTime",obj.userID,@"user_id",obj.albumID,@"albumID",@"2",@"pageType",obj.userID,@"createByID",self.stringPageTitle,@"pageTitle",objPage.pageID,@"albumPageID",pageStatus,@"pageStatus", nil];
            [self.answerList addObject:dict];
            self.stringValue = @"";
            self.subQuestionID++;
            [self loadQuestion:obj.albumSeq];
            //            }];
        }
        else{
            self.stringValue = [self getObjectValue:self.stringValue];
            albumObj *obj = (albumObj*)self.record;
            self.subQuestionID++;
            [self loadQuestion:obj.albumSeq];
        }
    }
    else{
        NSDictionary *dict = [self.questionList objectAtIndex:0];
        if([[dict objectForKey:@"lastQuestion"] isEqualToString:@"Y"]){
            self.stringValue = [self getObjectValue:self.stringValue];
            albumObj *obj = (albumObj*)self.record;
            NSString *imageName = @"";
            NSMutableDictionary *dictImage = [NSMutableDictionary new];
            if(self.originalImage != nil){
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:[NSString stringWithFormat:@"Default%@%@",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]] filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO]){
                    dictImage = [NSMutableDictionary new];
                    [dictImage setValue:[[utilityManager alloc] getDataFilePath:[NSString stringWithFormat:@"Default%@%@.jpeg",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]] folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
                    [dictImage setValue:[NSString stringWithFormat:@"Default%@%@.jpeg",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]]  forKey:@"fileName"];
                    [dictImage setValue:@"jpeg" forKey:@"fileType"];
                    [dictImage setValue:@"image" forKey:@"paramKey"];
                    imageName = [NSString stringWithFormat:@"Default%@%@.jpeg",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]];
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
                else{
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
            }
            else{
                [self.answerImage addObject:dictImage];
                self.originalImage = nil;
            }
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"INSERT_AL_PG",@"action",self.stringValue,@"description",@"0",@"posType",imageName,@"imagePath",@"",@"audioPath",@"",@"videoPath",@"",@"videoThumb",@"3",@"residenceTime",obj.userID,@"user_id",obj.albumID,@"albumID",@"2",@"pageType",obj.userID,@"createByID",self.stringPageTitle,@"pageTitle",pageStatus,@"pageStatus", nil];
            [self.answerList addObject:dict];
            self.stringValue = @"";
        }
        else{
            self.stringValue = [self getObjectValue:self.stringValue];
        }
        albumObj *obj = (albumObj*)self.record;
        self.subQuestionID++;
        [self loadQuestion:obj.albumSeq];
    }
}

-(IBAction)pressBtnLib:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnCam:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    self.originalImage = [UIImage fixrotation:[info objectForKey:UIImagePickerControllerOriginalImage]];
    self.iv_inputImage.image = [UIImage fixrotation:self.originalImage];
    NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
    if([[utilityManager alloc] saveDataFile:imageData Filename:@"UploadImage" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
    {
        NSData *imageData1 = [[utilityManager alloc] getDataFile:@"UploadImage.jpeg" folderName:@"temp" isDoucmentFolder:NO];
        self.iv_inputImage.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)pressBtnSave:(id)sender{
    NSString *pageStatus = @"S";
    dbManager *db = [[dbManager alloc] init];
    NSMutableArray *ary = [db selectSQL:@"tbl_default_answer" where:[NSString stringWithFormat:@"questionID = '%d' and pageSeq = '%d' and subQuestion = '%d'",self.questionID,self.pageSeq,self.subQuestionID] option:@""];
    if([ary count]>0){
//        [db updateSQL:@"tbl_default_answer" tCol:[NSString stringWithFormat:@"answer = '%@'",[self getObjectSaveValue]] tWhere:[NSString stringWithFormat:@"questionID = '%d' and pageSeq = '%d' and subQuestion = '%d'",self.questionID,self.pageSeq,self.subQuestionID]];
        [db customSQL:[NSString stringWithFormat:@"Delete from tbl_default_answer Where questionID = '%d' and pageSeq = '%d' and subQuestion = '%d'",self.questionID,self.pageSeq,self.subQuestionID]];
        NSString *strKey = [NSString stringWithFormat:@"questionID,pageSeq,subQuestionID,answer"];
        NSString *strValue = [NSString stringWithFormat:@"'%d','%d','%d','%@'",self.questionID,self.pageSeq,self.subQuestionID,[self getObjectSaveValue]];
        [db insertSQL:@"tbl_default_answer" tKey:strKey tValue:strValue];
    }
    else{
        NSString *strKey = [NSString stringWithFormat:@"questionID,pageSeq,subQuestionID,answer"];
        NSString *strValue = [NSString stringWithFormat:@"'%d','%d','%d','%@'",self.questionID,self.pageSeq,self.subQuestionID,[self getObjectSaveValue]];
        [db insertSQL:@"tbl_default_answer" tKey:strKey tValue:strValue];
    }
    if(self.pageRecord){
        albumPageObj* objPage = (albumPageObj*)self.pageRecord;
        NSDictionary *dict = [self.questionList objectAtIndex:0];
        if([[dict objectForKey:@"lastQuestion"] isEqualToString:@"Y"]){
            self.stringValue = [NSString stringWithFormat:@"%@/r/n",[self getObjectValue:self.stringValue]];
            albumObj *obj = (albumObj*)self.record;
            NSString *imageName = @"";
            NSMutableDictionary *dictImage = [NSMutableDictionary new];
            if(self.originalImage != nil){
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:[NSString stringWithFormat:@"Default%@",objPage.pageID] filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO]){
                    NSMutableDictionary *dictImage = [NSMutableDictionary new];
                    [dictImage setValue:[[utilityManager alloc] getDataFilePath:[NSString stringWithFormat:@"Default%@.jpeg",objPage.pageID] folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
                    [dictImage setValue:[NSString stringWithFormat:@"Default%@.jpeg",objPage.pageID]  forKey:@"fileName"];
                    [dictImage setValue:@"jpeg" forKey:@"fileType"];
                    [dictImage setValue:@"image" forKey:@"paramKey"];
                    imageName = [NSString stringWithFormat:@"Default%@.jpg",objPage.pageID];
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
                else{
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
            }
            else{
                [self.answerImage addObject:dictImage];
                self.originalImage = nil;
            }
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_AL_PG",@"action",self.stringValue,@"description",@"0",@"posType",imageName,@"imagePath",@"",@"audioPath",@"",@"videoPath",@"",@"videoThumb",@"3",@"residenceTime",obj.userID,@"user_id",obj.albumID,@"albumID",@"2",@"pageType",obj.userID,@"createByID",self.stringPageTitle,@"pageTitle",objPage.pageID,@"albumPageID",pageStatus,@"pageStatus", nil];
            [self.answerList addObject:dict];
            self.stringValue = @"";
            self.subQuestionID++;
            [self loadQuestion:obj.albumSeq];
            //            }];
        }
        else{
            self.stringValue = [self getObjectValue:self.stringValue];
            albumObj *obj = (albumObj*)self.record;
            self.subQuestionID++;
            [self loadQuestion:obj.albumSeq];
        }
    }
    else{
        NSDictionary *dict = [self.questionList objectAtIndex:0];
        if([[dict objectForKey:@"lastQuestion"] isEqualToString:@"Y"]){
            self.stringValue = [self getObjectValue:self.stringValue];
            albumObj *obj = (albumObj*)self.record;
            NSString *imageName = @"";
            NSMutableDictionary *dictImage = [NSMutableDictionary new];
            if(self.originalImage != nil){
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:[NSString stringWithFormat:@"Default%@%@",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]] filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO]){
                    dictImage = [NSMutableDictionary new];
                    [dictImage setValue:[[utilityManager alloc] getDataFilePath:[NSString stringWithFormat:@"Default%@%@.jpeg",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]] folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
                    [dictImage setValue:[NSString stringWithFormat:@"Default%@%@.jpeg",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]]  forKey:@"fileName"];
                    [dictImage setValue:@"jpeg" forKey:@"fileType"];
                    [dictImage setValue:@"image" forKey:@"paramKey"];
                    imageName = [NSString stringWithFormat:@"Default%@%@.jpeg",[dict objectForKey:@"questionID"],[dict objectForKey:@"pageSeq"]];
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
                else{
                    [self.answerImage addObject:dictImage];
                    self.originalImage = nil;
                }
            }
            else{
                [self.answerImage addObject:dictImage];
                self.originalImage = nil;
            }
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"INSERT_AL_PG",@"action",self.stringValue,@"description",@"0",@"posType",imageName,@"imagePath",@"",@"audioPath",@"",@"videoPath",@"",@"videoThumb",@"3",@"residenceTime",obj.userID,@"user_id",obj.albumID,@"albumID",@"2",@"pageType",obj.userID,@"createByID",self.stringPageTitle,@"pageTitle",pageStatus,@"pageStatus", nil];
            [self.answerList addObject:dict];
            self.stringValue = @"";
        }
        else{
            self.stringValue = [self getObjectValue:self.stringValue];
        }
        albumObj *obj = (albumObj*)self.record;
        self.subQuestionID++;
        [self loadQuestion:obj.albumSeq];
    }
}

-(void) deselectedBtn{
    for(int i=0;i<[self.aryObject count];i++){
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UIButton class]]){
            UIButton *btn = [self.aryObject objectAtIndex:i];
            btn.selected = false;
        }
    }
}

-(NSString *) getObjectValue:(NSString *)value{
//    NSString *str = @"";
    for(int i=0;i<[self.aryObject count];i++){
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[selCalendarBtn class]])
        {
            if([[[self.questionList objectAtIndex:0] objectForKey:@"answerType"] isEqualToString:@"BD"]){
                AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
                NSLocale *chinese = [NSLocale localeWithLocaleIdentifier:@"zh-CN"];
                NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
                dateFormatter1.locale = chinese;
                dateFormatter1.dateFormat = DATEFORMAT;
                
                SSLunarDate *lunar = [[SSLunarDate alloc] initWithDate:app.selectedDate];
                selCalendarBtn *obj = (selCalendarBtn*)[self.aryObject objectAtIndex:i];
                value = [NSString stringWithFormat:@"%@%@%@%@%@ 出生",value,[[self.questionList objectAtIndex:0] objectForKey:@"before_string"],obj.titleLabel.text,[[self.questionList objectAtIndex:0] objectForKey:@"after_string"],[lunar string]];
            }
            else if([[[self.questionList objectAtIndex:0] objectForKey:@"answerType"] isEqualToString:@"CD"]){
                selCalendarBtn *obj = (selCalendarBtn*)[self.aryObject objectAtIndex:i];
                value = [NSString stringWithFormat:@"%@%@%@%@",value,[[self.questionList objectAtIndex:0] objectForKey:@"before_string"],obj.titleLabel.text,[[self.questionList objectAtIndex:0] objectForKey:@"after_string"]];
            }
        }
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UITextField class]]){
            UITextField *obj = (UITextField*)[self.aryObject objectAtIndex:i];
            if(![obj.text isEqualToString:@""]){
                value = [NSString stringWithFormat:@"%@%@%@%@",value,[[self.questionList objectAtIndex:0] objectForKey:@"before_string"],obj.text,[[self.questionList objectAtIndex:0] objectForKey:@"after_string"]];
            }
        }
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UITextView class]]){
            UITextView *obj = (UITextView*)[self.aryObject objectAtIndex:i];
            if(![obj.text isEqualToString:@""]){
                value = [NSString stringWithFormat:@"%@%@%@%@",value,[[self.questionList objectAtIndex:0] objectForKey:@"before_string"],obj.text,[[self.questionList objectAtIndex:0] objectForKey:@"after_string"]];
            }
        }
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UIButton class]]){
            UIButton *obj = (UIButton*)[self.aryObject objectAtIndex:i];
            if(obj.selected){
                value = [NSString stringWithFormat:@"%@%@%@%@",value,[[self.questionList objectAtIndex:0] objectForKey:@"before_string"],obj.titleLabel.text,[[self.questionList objectAtIndex:0] objectForKey:@"after_string"]];
            }
        }
    }
    return value;
}

-(NSString *) getObjectSaveValue{
    NSString *str = @"";
    for(int i=0;i<[self.aryObject count];i++){
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[selCalendarBtn class]])
        {
            if([[[self.questionList objectAtIndex:0] objectForKey:@"answerType"] isEqualToString:@"BD"]){
                AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
                NSLocale *chinese = [NSLocale localeWithLocaleIdentifier:@"zh-CN"];
                NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
                dateFormatter1.locale = chinese;
                dateFormatter1.dateFormat = DATEFORMAT;
                
//                SSLunarDate *lunar = [[SSLunarDate alloc] initWithDate:app.selectedDate];
                selCalendarBtn *obj = (selCalendarBtn*)[self.aryObject objectAtIndex:i];
                str = obj.titleLabel.text;
            }
            if([[[self.questionList objectAtIndex:0] objectForKey:@"answerType"] isEqualToString:@"CD"]){
                selCalendarBtn *obj = (selCalendarBtn*)[self.aryObject objectAtIndex:i];
                str = obj.titleLabel.text;
            }
        }
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UITextField class]]){
            UITextField *obj = (UITextField*)[self.aryObject objectAtIndex:i];
            if(![obj.text isEqualToString:@""]){
                str = obj.text;
            }
        }
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UITextView class]]){
            UITextView *obj = (UITextView*)[self.aryObject objectAtIndex:i];
            if(![obj.text isEqualToString:@""]){
                str = obj.text;
            }
        }
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[UIButton class]]){
            UIButton *obj = (UIButton*)[self.aryObject objectAtIndex:i];
            if(obj.selected){
                str = obj.titleLabel.text;
            }
        }
    }
    return str;
}

-(void)setViewUI{
    fontManager *font = [[fontManager alloc] init];
    self.btn_skip.titleLabel.font = self.btn_nextQuestion.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_skip setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_skip setTitle:@"暫不回答" forState:UIControlStateNormal];
    [self.btn_nextQuestion setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_nextQuestion setTitle:@"儲存" forState:UIControlStateNormal];
    [self.v_main setBackgroundColor:[UIColor clearColor]];
    [self.btn_skip setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_nextQuestion setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_TextToSpeech setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnCalendar:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupCalendarViewController *vc = (popupCalendarViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupCalendarViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    vc.pre_view = self;
    [self presentViewController:vc animated:YES completion:^{
        if(self.currectDate != nil){
            vc.valueDate = self.currectDate;
            [vc updateCurrectDate];
        }
    }];
}

-(void) callBackFunction{
    for (int i = 0; i < [self.aryObject count]; i++) {
        if([[self.aryObject objectAtIndex:i] isKindOfClass:[selCalendarBtn class]]){
            AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
            NSLocale *chinese = [NSLocale localeWithLocaleIdentifier:@"zh-CN"];
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            dateFormatter1.locale = chinese;
            dateFormatter1.dateFormat = @"yyyy/MM/dd";
            [[self.aryObject objectAtIndex:i] setTitle:[dateFormatter1 stringFromDate:app.selectedDate] forState:UIControlStateNormal];
        }
    }
}

-(void)pressBtnback:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self deselectedBtn];
    [textField resignFirstResponder];
    return YES;
}

-(void) uploadFile:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
//    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([imageArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[imageArray count];i++){
                NSMutableDictionary *dict = [imageArray objectAtIndex:i];
                if(dict != nil && [dict objectForKey:@"file"] != nil){
                    [formData appendPartWithFileData:[utility getDataFileByPath:[dict objectForKey:@"file"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"fileName"] mimeType:[dict objectForKey:@"fileType"]];
                }
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                  }];
    
    [uploadTask resume];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
