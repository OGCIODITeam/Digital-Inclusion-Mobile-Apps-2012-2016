//
//  albumViewController.h
//  AngeLink
//
//  Created by kanhan on 26/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"
#import "albumCollectionViewCell.h"

@interface albumViewController : UIViewController<headerBarViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIAlertViewDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *cv_main;
@property (nonatomic, retain) NSMutableArray *aryData;
@property (weak, nonatomic) IBOutlet UIView *v_info;
@property (weak, nonatomic) IBOutlet UIImageView *im_info;
@property (weak, nonatomic) IBOutlet UIButton *btn_close;
@property (weak, nonatomic) IBOutlet UIButton *btn_spk;
@property (nonatomic, retain) NSMutableArray *aryImg,*aryString;
@property (nonatomic, assign) int infoNum;
@property (nonatomic, retain) infoView *info;



@end
