//
//  stickerCollectionViewCell.m
//  AngeLink
//
//  Created by kanhan on 19/5/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "stickerCollectionViewCell.h"

@implementation stickerCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
