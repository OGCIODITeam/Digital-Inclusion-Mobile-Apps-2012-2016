//
//  addressBookTableViewCell.m
//  AngeLink
//
//  Created by kanhan on 28/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "addressBookTableViewCell.h"

@implementation addressBookTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
