//
//  fdActTableViewCell.h
//  AngeLink
//
//  Created by kanhan on 27/4/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "common.h"

@interface fdActTableViewCell : UITableViewCell
@property (retain, nonatomic) UIImageView *iv_user;
@property (retain, nonatomic) UILabel *lbl_username;
@property (retain, nonatomic) UILabel *lbl_postDate;
@property (retain, nonatomic) UIButton *btn_TextToSpeak;
@property (retain, nonatomic) UITextView *tv_description;
@property (retain, nonatomic) UIImageView *iv_postImg;
@property (retain, nonatomic) UIImageView *btn_fb_like;
@property (retain, nonatomic) UILabel *lbl_like_cnt;
@property (retain, nonatomic) UIButton *btn_com;
@property (retain, nonatomic) UILabel *lbl_com;
@property (weak, nonatomic) IBOutlet UIView *v_body;

@end
