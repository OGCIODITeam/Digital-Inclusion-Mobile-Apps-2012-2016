//
//  fdActTableViewCell.m
//  AngeLink
//
//  Created by kanhan on 27/4/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "fdActTableViewCell.h"

@implementation fdActTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
