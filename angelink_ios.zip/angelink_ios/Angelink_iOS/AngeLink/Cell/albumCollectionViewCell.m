//
//  albumCollectionViewCell.m
//  AngeLink
//
//  Created by kanhan on 20/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "albumCollectionViewCell.h"

@implementation albumCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
