//
//  albumCollectionViewCell.h
//  AngeLink
//
//  Created by kanhan on 20/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "fdListBtn.h"
#import "iv_count.h"

@interface albumCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iv_cover;
@property (weak, nonatomic) IBOutlet UIImageView *iv_bg;
@property (weak, nonatomic) IBOutlet UILabel *lbl_albumname;
@property (weak, nonatomic) IBOutlet UIImageView *iv_lockd;
@property (weak, nonatomic) IBOutlet fdListBtn *btn_edit,*btn_del;
@property (weak, nonatomic) IBOutlet iv_count *iv_countMark;
@property (nonatomic, retain) NSDictionary *recordDict;
@end
