//
//  addressBookTableViewCell.h
//  AngeLink
//
//  Created by kanhan on 28/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "fdListBtn.h"

@interface addressBookTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *v_body;
@property (weak, nonatomic) IBOutlet fdListBtn *btn_msg;
@property (weak, nonatomic) IBOutlet fdListBtn *btn_call;
@property (weak, nonatomic) IBOutlet UIImageView *iv_img;
@property (weak, nonatomic) IBOutlet UILabel *lbl_name;
    @property (weak, nonatomic) IBOutlet fdListBtn *btn_reject;
    @property (weak, nonatomic) IBOutlet fdListBtn *btn_accept;
    @property (weak, nonatomic) IBOutlet fdListBtn *btn_resend;
@property (weak, nonatomic) IBOutlet fdListBtn *btn_del;
@property (weak, nonatomic) IBOutlet fdListBtn *btn_edit;

@end
