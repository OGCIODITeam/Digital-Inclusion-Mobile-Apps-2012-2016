//
//  albumPageTableViewCell.h
//  AngeLink
//
//  Created by kanhan on 22/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface albumPageTableViewCell : UITableViewCell
@property (nonatomic, retain) IBOutlet UILabel *lbl_Title;
@property (weak, nonatomic) IBOutlet UIButton *btn_edit;
@property (weak, nonatomic) IBOutlet UIButton *btn_del;
@property (weak, nonatomic) IBOutlet UIButton *btn_accupt;
@property (weak, nonatomic) IBOutlet UIButton *btn_reject;
@property (nonatomic, retain) IBOutlet UIImageView *iv_page;
@property (nonatomic, retain) IBOutlet UIView *v_body;
@end
