//
//  albumPageTableViewCell.m
//  AngeLink
//
//  Created by kanhan on 22/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "albumPageTableViewCell.h"

@implementation albumPageTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
