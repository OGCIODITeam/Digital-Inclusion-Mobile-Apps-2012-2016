//
//  addressBookRankTableViewCell.h
//  AngeLink
//
//  Created by kanhan on 4/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "fdListBtn.h"

@interface addressBookRankTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *v_body;
@property (weak, nonatomic) IBOutlet UILabel *lbl_name;
@property (weak, nonatomic) IBOutlet UIImageView *iv_img;
@property (weak, nonatomic) IBOutlet UILabel *lbl_mark;
@property (weak, nonatomic) IBOutlet UIImageView *iv_mark;
@property (nonatomic, retain) TYMProgressBarView *progressBarView;
@end
