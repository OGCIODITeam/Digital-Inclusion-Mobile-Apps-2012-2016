//
//  pushTableViewCell.h
//  AngeLink
//
//  Created by kanhan on 22/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface pushTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *v_bg;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UIButton *btn_onoff;
@property (assign, nonatomic) BOOL isON;
@property (nonatomic, retain) NSIndexPath *object;
@end
