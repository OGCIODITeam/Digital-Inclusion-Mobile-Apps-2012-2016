//
//  stickerCollectionViewCell.h
//  AngeLink
//
//  Created by kanhan on 19/5/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface stickerCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iv_sticker;

@end
