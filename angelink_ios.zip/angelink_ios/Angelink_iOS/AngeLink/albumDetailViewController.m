//
//  albumDetailViewController.m
//  AngeLink
//
//  Created by kanhan on 22/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "albumDetailViewController.h"
#import "popupCreateAlbumViewController.h"
#import "albumPageViewController.h"
#import "albumObj.h"
#import "fdRecord.h"

@interface albumDetailViewController ()

@end

@implementation albumDetailViewController
static NSString * const albumCollectionViewCellKind = @"albumCollectionViewCell";
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = self.albumTitle;
    header.delegate = self;
    [self.view addSubview:header];
    
    if(self.aryData == nil)
        self.aryData = [NSMutableArray new];
    else
        [self.aryData removeAllObjects];
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.1_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.1_2"];
    UIImage *img3 = [UIImage imageNamed:@"Book_6.1_3"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"圖片顯示人生紀念冊內的相簿\,點擊以觀看內容";
    NSString *str2 = @"新增一本人生紀念冊相簿";
    NSString *str3 = @"編輯人生紀念冊的相簿";
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
}

-(void) viewWillAppear:(BOOL)animated{
    [self getServerUserAlbum];
    
    [self.cv_main registerNib:[UINib nibWithNibName:albumCollectionViewCellKind bundle:nil] forCellWithReuseIdentifier:albumCollectionViewCellKind];
    [self.cv_main setBackgroundColor:[UIColor clearColor]];
    self.cv_main.delegate = self;
    self.cv_main.dataSource = self;
    
    
    
    fdRecord *record = [[fdRecord alloc] initWithDict:self.userDict];
    if(![record.userid isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        self.v_percent.hidden = YES;
        self.btn_add.frame = CGRectMake(self.btn_add.frame.origin.x, self.btn_add.frame.origin.y + self.v_percent.frame.size.height, self.btn_add.frame.size.width, self.btn_add.frame.size.height);
        self.btn_edit.frame = CGRectMake(self.btn_edit.frame.origin.x, self.btn_edit.frame.origin.y + self.v_percent.frame.size.height, self.btn_edit.frame.size.width, self.btn_edit.frame.size.height);
        self.cv_main.frame = CGRectMake(self.cv_main.frame.origin.x, self.cv_main.frame.origin.y, self.cv_main.frame.size.width, self.cv_main.frame.size.height + self.v_percent.frame.size.height);
        
    }
    else{
        connectionManager *connect = [[connectionManager alloc] init];
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id", nil];
        [connect postRequest:GET_FILE_SIZE parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                if([[[jsonDict objectForKey:@"status"] lowercaseString] isEqualToString:@"fail"]){
                    [self hiddenView];
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                    [alert show];
                }
                else{
                    SDImageCache *imageCache = [SDImageCache sharedImageCache];
                    [imageCache clearMemory];
                    [imageCache clearDisk];
                    [[[SDWebImageManager sharedManager] imageCache] clearDisk];
                    [[[SDWebImageManager sharedManager] imageCache] clearMemory];

                    NSString *percent = [jsonDict objectForKey:@"currentSize"];
                    NSString *sizeLimit = [jsonDict objectForKey:@"sizeLimit"];
                    self.progressBarView = [[TYMProgressBarView alloc] initWithFrame:CGRectMake(5, 5, self.v_percent.frame.size.width - 10, self.v_percent.frame.size.height - self.lbl_percentTitle.frame.size.height - 10)];
                    self.progressBarView.barBorderWidth = 0.0;
                    self.progressBarView.barFillColor = [UIColor colorWithRed:128.0/255.0 green:222.0/255.0 blue:234.0/255.0 alpha:1.0];
                    [self.progressBarView setBarBackgroundColor:[UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:1.0]];
                    [self.v_percent addSubview:self.progressBarView];
                    float currentSize = [percent floatValue];
                    float size = [sizeLimit floatValue];
                    self.progressBarView.progress = currentSize / size;
                    fontManager *font = [[fontManager alloc] init];
                    self.lbl_percentTitle.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
                    self.lbl_percentTitle.textAlignment = ALIGN_CENTER;
                    int num = self.progressBarView.progress * size;
                    self.lbl_percentTitle.text = [NSString stringWithFormat:@"已使用儲存量：%d %%",num];
                }
            }
            else{
                [self hiddenView];
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
            }
        }];
    }
    if([record.userid isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        self.btn_add.hidden = NO;
        self.btn_edit.hidden = NO;
    }
    else{
        self.btn_add.hidden = YES;
        self.btn_edit.hidden = YES;
    }
}

-(void) updateUI{
    fdRecord *record = [[fdRecord alloc] initWithDict:self.userDict];
    if(![record.userid isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        self.v_percent.hidden = YES;
        self.btn_add.frame = CGRectMake(self.btn_add.frame.origin.x, self.btn_add.frame.origin.y + self.v_percent.frame.size.height, self.btn_add.frame.size.width, self.btn_add.frame.size.height);
        self.btn_edit.frame = CGRectMake(self.btn_edit.frame.origin.x, self.btn_edit.frame.origin.y + self.v_percent.frame.size.height, self.btn_edit.frame.size.width, self.btn_edit.frame.size.height);
        self.cv_main.frame = CGRectMake(self.cv_main.frame.origin.x, self.cv_main.frame.origin.y, self.cv_main.frame.size.width, self.cv_main.frame.size.height + self.v_percent.frame.size.height);
        
    }
    [self.btn_add setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_edit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(void) hiddenView{
    self.v_percent.hidden = YES;
    self.btn_add.frame = CGRectMake(self.btn_add.frame.origin.x, self.btn_add.frame.origin.y + self.v_percent.frame.size.height, self.btn_add.frame.size.width, self.btn_add.frame.size.height);
    self.btn_edit.frame = CGRectMake(self.btn_edit.frame.origin.x, self.btn_edit.frame.origin.y + self.v_percent.frame.size.height, self.btn_edit.frame.size.width, self.btn_edit.frame.size.height);
    self.cv_main.frame = CGRectMake(self.cv_main.frame.origin.x, self.cv_main.frame.origin.y, self.cv_main.frame.size.width, self.cv_main.frame.size.height + self.v_percent.frame.size.height);
}

-(void)callBackFunction{
    self.isEdit = false;
    [self.btn_edit setImage:[UIImage imageNamed:@"btn_edit_M"] forState:UIControlStateNormal];
    [self viewWillAppear:YES];
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(IBAction)pressBtnAdd:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupCreateAlbumViewController *vc = (popupCreateAlbumViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupCreateAlbumViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    vc.pre_view = self;
    fdRecord *record = [[fdRecord alloc] initWithDict:self.userDict];
    [vc updateUI];
    [self presentViewController:vc animated:YES completion:^{
        vc.page = self;
    }];
}

-(IBAction)pressBtnEdit:(id)sender{
    if(self.isEdit){
        self.isEdit = NO;
        [self.btn_edit setImage:[UIImage imageNamed:@"btn_edit_M"] forState:UIControlStateNormal];
    }
    else{
        self.isEdit = YES;
        [self.btn_edit setImage:[UIImage imageNamed:@"btn_tickr_M"] forState:UIControlStateNormal];
    }
    
    [self.cv_main reloadData];
}

-(void) getServerUserAlbum{
    dbManager *db = [[dbManager alloc] init];
    connectionManager *connect = [[connectionManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    fdRecord *record = [[fdRecord alloc] initWithDict:self.userDict];
    NSString *checkUser = @"";
    if(![record.userid isEqualToString:[utility getUserDefaultstoString:@"memberID"]])
        checkUser = @"AND public = '1'";
    [db deleteSQL:@"tbl_album"];
    NSString *user;
    if(![record.userid isEqualToString:[utility getUserDefaultstoString:@"memberID"]]){
        user = @" AND public=1";
    }
    else{
        user = @"";
    }
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:record.userid,@"user_id", nil];
    [connect postRequestReturnArray:ALBUM_DEFAULT parameters:dict completionHandler:^(bool status, NSMutableArray *jsonArray) {
        if(status){
            if([jsonArray count] == 1){
                NSDictionary *dict2 = [[NSDictionary alloc] initWithObjectsAndKeys:record.userid,@"user_id",@"SELECT_AL",@"action", nil];
                [connect postRequestReturnArray:ALBUM_HANDLER parameters:dict2 completionHandler:^(bool status, NSMutableArray *jsonArray2) {
                    if(status){
                        for(int i=0;i<[jsonArray2 count];i++){
                            albumObj *album = [[albumObj alloc] initWithDict:[jsonArray2 objectAtIndex:i]];
                            NSString *dictKey = @"albumID,userID,albumSeq,albumTitle,coverPath,albumType,frameType,bgmPath,videoPath,public,createDate,valid,defaultAlbum,shareKey,countP";
                            NSString *dictValue = [NSString stringWithFormat:@"'%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@'",album.albumID,album.userID, album.albumSeq, album.albumTitle, album.coverPath, album.albumType, album.frameType, album.bgmPath, album.videoPath,  album.public,  album.createDate, album.valid, @"1", album.shareKey, album.countP];
                            [db insertSQL:@"tbl_album" tKey:dictKey tValue:dictValue];
                        }
                        
                        NSString *str = [NSString stringWithFormat:@"SELECT albumID, userID,albumSeq,albumTitle,coverPath,albumType,frameType,bgmPath,videoPath,public,createDate,valid,defaultAlbum,shareKey,countP From tbl_album WHERE userID = '%@' %@ UNION SELECT albumID,userID,albumSeq,albumTitle,coverPath,albumType,frameType,bgmPath,videoPath,public,createDate,valid,defaultAlbum,shareKey,countP From tbl_offline_album WHERE userID = '%@' %@ Order By albumType",record.userid,user,record.userid,user];
                        self.aryData = [db customSQL:str];
                        [self.cv_main reloadData];
                    }
                }];
            }
            else{
                for(int i=0;i<[jsonArray count];i++){
                    albumObj *album = [[albumObj alloc] initWithDict:[jsonArray objectAtIndex:i]];
                    NSString *dictKey = @"albumID,userID,albumSeq,albumTitle,coverPath,albumType,frameType,bgmPath,videoPath,public,createDate,valid,defaultAlbum,shareKey,countP";
                    NSString *dictValue = [NSString stringWithFormat:@"'%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@'",album.albumID,album.userID, album.albumSeq, album.albumTitle, album.coverPath, album.albumType, album.frameType, album.bgmPath, album.videoPath,  album.public,  album.createDate, album.valid, @"1",album.shareKey, album.countP];
                    [db insertSQL:@"tbl_album" tKey:dictKey tValue:dictValue];
                }
                NSString *str = [NSString stringWithFormat:@"SELECT albumID, userID,albumSeq,albumTitle,coverPath,albumType,frameType,bgmPath,videoPath,public,createDate,valid,defaultAlbum,shareKey,countP From tbl_album WHERE userID = '%@' %@ UNION SELECT albumID,userID,albumSeq,albumTitle,coverPath,albumType,frameType,bgmPath,videoPath,public,createDate,valid,defaultAlbum,shareKey,countP From tbl_offline_album WHERE userID = '%@' %@ Order By albumType",record.userid,user,record.userid,user];
                self.aryData = [db customSQL:str];
                [self.cv_main reloadData];
            }
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"連線問題，請重試。" delegate:self cancelButtonTitle:nil otherButtonTitles: @"確定",nil];
            alert.delegate = self;
            [alert show];
        }
    }];
    [self updateUI];
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //    return [self.aryData count];
    return [self.aryData count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    fontManager *font = [[fontManager alloc] init];
    albumCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:albumCollectionViewCellKind
                                                                              forIndexPath:indexPath];
    albumObj *album = [[albumObj alloc] initWithDict:[self.aryData objectAtIndex:indexPath.row]];
    cell.lbl_albumname.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.lbl_albumname.textAlignment = ALIGN_CENTER;
    cell.lbl_albumname.text = album.albumTitle;
    if([album.albumType isEqualToString:@"0"]){
        cell.iv_bg.image = [UIImage imageNamed:@"btn_BkMe"];
    }
    else{
        cell.iv_bg.image = [UIImage imageNamed:@"btn_Bkbg"];
    }
    if([album.public isEqualToString:@"1"]){
        cell.iv_lockd.hidden = YES;
    }
    else{
        cell.iv_lockd.hidden = NO;
    }
    if(self.isEdit){
        cell.btn_edit.hidden = NO;
        if([album.albumType intValue] >0 ){
            cell.btn_del.hidden = NO;
        }
        [cell.btn_edit setfdRecord:album];
        [cell.btn_edit addTarget:self action:@selector(pressEdit:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_del setfdRecord:album];
        [cell.btn_del addTarget:self action:@selector(pressDel:) forControlEvents:UIControlEventTouchUpInside];
    }
    else{
        cell.btn_del.hidden = YES;
        cell.btn_edit.hidden = YES;
    }
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_IMAGE,album.coverPath]];
    //    [cell.iv_cover setImageWithURL:url placeholderImage:[UIImage imageNamed:@"IMG_bk_dairy"]];
    [cell.iv_cover sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"IMG_bk_dairy"]];
    //    cell.iv_cover.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
//    if([album.countP intValue] > 0){
//        [cell.iv_countMark updateUI:album.countP image:@"bk_ntf"];
//        cell.iv_countMark.hidden = NO;
//    }
//    else{
        cell.iv_countMark.hidden = YES;
//
//}
    return cell;
}

-(IBAction)pressEdit:(id)sender{
    fdListBtn *btn = (fdListBtn*)sender;
    albumObj *obj = (albumObj*)btn.record;
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupCreateAlbumViewController *vc = (popupCreateAlbumViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupCreateAlbumViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    vc.pre_view = self;
    vc.record = obj;
    [vc updateUI];
    [self presentViewController:vc animated:YES completion:^{
        vc.page = self;
    }];
}
-(IBAction)pressDel:(id)sender{
    fdListBtn *btn = (fdListBtn*)sender;
    albumObj *obj = (albumObj*)btn.record;
    self.albumDelDict = [obj toDict];
    self.deleteAlbum = [[UIAlertView alloc] initWithTitle:@"" message:@"您確定要刪除此相冊" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
    [self.deleteAlbum show];
//    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
//                                                             bundle: nil];
//    popupCreateAlbumViewController *vc = (popupCreateAlbumViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupCreateAlbumViewController"];
//    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
//    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
//    vc.pre_view = self;
//    vc.record = obj;
//    [vc updateUI];
//    [self presentViewController:vc animated:YES completion:^{
//        vc.page = self;
//    }];
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width / 2 - 20, self.view.frame.size.width / 2 - 20);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath  {
    albumObj *obj = [[albumObj alloc] initWithDict:[self.aryData objectAtIndex:indexPath.row]];
    self.albumIndexPath = indexPath;
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"SELECT_AL_PG",@"action",@"93",@"albumID",@"",@"albumPageID", nil];
    self.albumDict = dict;
    if([obj.albumTitle isEqualToString:@"人生畢業禮"]){
        if([[[utilityManager alloc] getUserDefaultstoString:@"closePopup"] isEqualToString:@"Y"]){
            [[connectionManager alloc] postRequest:ALBUM_PAGE_HANDLER parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
                if(status)
                {
                    albumObj *obj = [[albumObj alloc] initWithDict:[self.aryData objectAtIndex:indexPath.row]];
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                             bundle: nil];
                    
                    albumPageViewController *vc = (albumPageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"albumPageViewController"];
                    vc.albumObj = obj;
                    vc.headerTitle = obj.albumTitle;
                    [self.navigationController pushViewController:vc animated:YES];
                }
            }];
        }
        else{
            self.alertAlbum = [[UIAlertView alloc] initWithTitle:@"注意" message:@"「人生畢業禮」是為計劃身後事而設，你是否準備打開？" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
            [self.alertAlbum show];
        }
    }
    else{
        [[connectionManager alloc] postRequest:ALBUM_PAGE_HANDLER parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status)
            {
                albumObj *obj = [[albumObj alloc] initWithDict:[self.aryData objectAtIndex:indexPath.row]];
                UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                         bundle: nil];
                
                albumPageViewController *vc = (albumPageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"albumPageViewController"];
                vc.albumObj = obj;
                vc.headerTitle = obj.albumTitle;
                [self.navigationController pushViewController:vc animated:YES];
            }
        }];
    }
}

-(void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView == self.alertAlbum){
        if (buttonIndex == 0)
        {
            
        }
        else{
            [[connectionManager alloc] postRequest:ALBUM_PAGE_HANDLER parameters:self.albumDict completionHandler:^(bool status, NSDictionary *jsonDict) {
                if(status)
                {
                    albumObj *obj = [[albumObj alloc] initWithDict:[self.aryData objectAtIndex:self.albumIndexPath.row]];
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                             bundle: nil];
                    
                    albumPageViewController *vc = (albumPageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"albumPageViewController"];
                    vc.albumObj = obj;
                    vc.headerTitle = obj.albumTitle;
                    [self.navigationController pushViewController:vc animated:YES];
                }
            }];
        }
    }
    else if(alertView == self.deleteAlbum){
        if (buttonIndex == 0)
        {
            
        }
        else{
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_PUBLIC",@"action",[self.albumDelDict objectForKey:@"userID"],@"user_id",[self.albumDelDict objectForKey:@"albumID"],@"albumID",@"2",@"public", nil];
            [[connectionManager alloc] postRequest:ALBUM_HANDLER parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
                if(status)
                {
                    [self pressBtnEdit:nil];
                    [self getServerUserAlbum];
                }
            }];
        }
    }
    else{
        if (buttonIndex == 0)
        {
            [self pressBtnback:nil];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

