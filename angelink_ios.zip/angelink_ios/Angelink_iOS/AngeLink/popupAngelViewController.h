//
//  popupAngelViewController.h
//  AngeLink
//
//  Created by kanhan on 27/1/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "common.h"

@interface popupAngelViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *v_body;
@property (weak, nonatomic) IBOutlet UIButton *btn_close;
-(void) createUIview:(NSString*) title setMessage:(NSString*) message setImage:(NSString*) Path;
@end
