//
//  circleViewController.m
//  AngeLink
//
//  Created by kanhan on 26/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "circleViewController.h"
#import "addressBookTableViewCell.h"
#import "addressBookRankTableViewCell.h"
#import "popupAddMemberViewController.h"
#import "userObj.h"

@interface circleViewController ()

@end

@implementation circleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = @"親友圈";
    header.delegate = self;
    [self.view addSubview:header];
    utilityManager *utility = [[utilityManager alloc] init];
    UIImage *img = [UIImage imageNamed:@"btn_fd_srh"];
    UIButton *btn_search=[UIButton buttonWithType:UIButtonTypeCustom];
    btn_search.frame = CGRectMake(0, 0, 60, 61);
    [btn_search setImage:img forState:UIControlStateNormal];
    [btn_search addTarget:self action:@selector(pressBtnSearch:) forControlEvents:UIControlEventTouchUpInside];
    btn_search.isAccessibilityElement = true;
    btn_search.accessibilityTraits = UIAccessibilityTraitNone;
    btn_search.accessibilityLabel = @"搜尋";
    [utility setButtonToTextField:self.tf_search Button:btn_search Position:@"right"];
    [utility setLeftSpaceToTextField:self.tf_search];
    [self.tf_search setBackgroundColor:[UIColor whiteColor]];
    [self.tf_search setPlaceholder:@"搜尋"];
    self.btn_fd.selected = true;
    self.tf_search.layer.cornerRadius=0.0f;
    self.tf_search.layer.masksToBounds=YES;
    self.tf_search.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_search.layer.borderWidth= 0.0f;
    self.tf_search.delegate = self;
    self.tv_fd.backgroundColor = self.tv_rank.backgroundColor = self.tv_wait.backgroundColor = self.v_fdList.backgroundColor = [UIColor clearColor];
    
    if(self.aryWait == nil){
        self.aryWait = [NSMutableArray new];
    }
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    if(self.aryRank == nil){
        self.aryRank = [NSMutableArray new];
    }
    
    fontManager *font = [[fontManager alloc] init];
    self.tf_search.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    self.tv_fd.separatorColor = [UIColor clearColor];
    self.tv_rank.separatorColor = [UIColor clearColor];
    self.tv_wait.separatorColor = [UIColor clearColor];
    [self getServerFdList:^(bool status) {}];
    [self getMyWaitList:^(bool status) {}];
    [self.tf_search setValue:[UIColor darkGrayColor]
                    forKeyPath:@"_placeholderLabel.textColor"];
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Circle_5.0_Fd_List_1"];
    UIImage *img2 = [UIImage imageNamed:@"Circle_5.0_Fd_List_2"];
    UIImage *img3 = [UIImage imageNamed:@"Circle_5.0_Fd_List_3"];
//    UIImage *img4 = [UIImage imageNamed:@"Circle_5.0_Fd_List_4"];
    UIImage *img5 = [UIImage imageNamed:@"Circle_5.0_Fd_List_5"];
    UIImage *img6 = [UIImage imageNamed:@"Circle_5.0_Fd_List_6"];
    UIImage *img7 = [UIImage imageNamed:@"Circle_5.0_Fd_List_7"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
//    [aryImg addObject:img4];
    [aryImg addObject:img5];
    [aryImg addObject:img6];
    [aryImg addObject:img7];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"至親及親友名錄";
    NSString *str2 = @"至親及親友聯絡次數排行榜";
    NSString *str3 = @"確認或拒絕至親及親友邀請";
//    NSString *str4 = @"至親及親友名錄";
    NSString *str5 = @"新增至親或添加親友";
    NSString *str6 = @"編輯/刪除至親或親友";
    NSString *str7 = @"致電至親或親友";
    
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
//    [aryString addObject:str4];
    [aryString addObject:str5];
    [aryString addObject:str6];
    [aryString addObject:str7];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    [self setAccessibility];
    [self.btn_fd setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_rank setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_wait setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_addFd setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_fdEdit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

-(void) setAccessibility{
    self.btn_fd.isAccessibilityElement = true;
    self.btn_fd.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_fd.accessibilityLabel = @"親友列";
    
    self.btn_rank.isAccessibilityElement = true;
    self.btn_rank.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_rank.accessibilityLabel = @"龍虎榜";

    self.btn_wait.isAccessibilityElement = true;
    self.btn_wait.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_wait.accessibilityLabel = @"等待回覆";
    
    self.btn_addFd.isAccessibilityElement = true;
    self.btn_addFd.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_addFd.accessibilityLabel = @"添加至親";

    self.btn_fdEdit.isAccessibilityElement = true;
    self.btn_fdEdit.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_fdEdit.accessibilityLabel = @"編輯至親";
}

-(void) viewWillAppear:(BOOL)animated{
    self.editing = FALSE;
    [self.btn_fdEdit setImage:[UIImage imageNamed:@"btn_edit_M"] forState:UIControlStateNormal];
    [self.tv_fd reloadData];
    
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([textField canResignFirstResponder]) {
        [textField resignFirstResponder];
    }
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    // add your method here
    
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
}

-(IBAction)pressBtnadd:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupAddMemberViewController *vc = (popupAddMemberViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupAddMemberViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    vc.pre_view = self;
    [self presentViewController:vc animated:YES completion:^{
        
    }];
}

-(IBAction)pressBtnedit:(id)sender{
    if(self.editing){
        self.editing = false;
        [self.btn_fdEdit setImage:[UIImage imageNamed:@"btn_edit_M"] forState:UIControlStateNormal];
    }
    else{
        self.editing = true;
        [self.btn_fdEdit setImage:[UIImage imageNamed:@"btn_tickr_M"] forState:UIControlStateNormal];
    }
    [self.tv_fd reloadData];
}

-(IBAction)pressBtntagFd:(id)sender{
    self.editing = FALSE;
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Circle_5.0_Fd_List_1"];
    UIImage *img2 = [UIImage imageNamed:@"Circle_5.0_Fd_List_2"];
    UIImage *img3 = [UIImage imageNamed:@"Circle_5.0_Fd_List_3"];
//    UIImage *img4 = [UIImage imageNamed:@"Circle_5.0_Fd_List_4"];
    UIImage *img5 = [UIImage imageNamed:@"Circle_5.0_Fd_List_5"];
    UIImage *img6 = [UIImage imageNamed:@"Circle_5.0_Fd_List_6"];
    UIImage *img7 = [UIImage imageNamed:@"Circle_5.0_Fd_List_7"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
//    [aryImg addObject:img4];
    [aryImg addObject:img5];
    [aryImg addObject:img6];
    [aryImg addObject:img7];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"至親及親友名錄";
    NSString *str2 = @"至親及親友聯絡次數排行榜";
    NSString *str3 = @"確認或拒絕至親及親友邀請";
//    NSString *str4 = @"至親及親友名錄";
    NSString *str5 = @"新增至親或添加親友";
    NSString *str6 = @"編輯/刪除至親或親友";
    NSString *str7 = @"致電至親或親友";
    
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
//    [aryString addObject:str4];
    [aryString addObject:str5];
    [aryString addObject:str6];
    [aryString addObject:str7];
    
    [self.info dataUpdate:aryString imageArray:aryImg];
    [self getServerFdList:^(bool status) {
        self.btn_fd.selected = self.btn_rank.selected = self.btn_wait.selected = false;
        self.btn_fd.selected = true;
        self.sv_main.contentOffset = CGPointMake(0, 0);
        [self getFdList];
    }];
}

-(IBAction)pressBtntagRank:(id)sender{
    self.editing = FALSE;
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Circle_5.1_standing_1"];
    [aryImg addObject:img1];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"至親或親友的聯絡次數";
    [aryString addObject:str1];
    
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.btn_fd.selected = self.btn_rank.selected = self.btn_wait.selected = false;
    self.btn_rank.selected = true;
    self.sv_main.contentOffset = CGPointMake(self.sv_main.frame.size.width, 0);
    [self getRankList];
}

-(IBAction)pressBtntagWait:(id)sender{
    self.editing = FALSE;
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Circle_5.2_Waiting_1"];
    UIImage *img2 = [UIImage imageNamed:@"Circle_5.2_Waiting_2"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"拒絕邀請";
    NSString *str2 = @"接受邀請";
    [aryString addObject:str1];
    [aryString addObject:str2];
    
    [self.info dataUpdate:aryString imageArray:aryImg];
    
    [self getMyWaitList:^(bool status) {
        self.btn_fd.selected = self.btn_rank.selected = self.btn_wait.selected = false;
        self.btn_wait.selected = true;
        self.sv_main.contentOffset = CGPointMake(self.sv_main.frame.size.width*2, 0);
        [self getWaitList];
    }];
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(IBAction)pressBtnSearch:(id)sender{
    [self.view endEditing:YES];
    dbManager *db = [[dbManager alloc] init];
    NSMutableArray *ary1 = [db selectSQL:@"tbl_relation" where:[NSString stringWithFormat:@"username LIKE '%%%@%%' and mode = ''",self.tf_search.text] option:@"ORDER BY username"];
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    [self.aryData addObject:ary1];
    [self.tv_fd reloadData];
}

-(IBAction)pressBtnreject:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    connectionManager *connect = [[connectionManager alloc] init];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom",record.userid,@"userTo", nil];
    [connect postRequest:REMOVE_USER_WAIT_LIST parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"已拒绝好友邀請" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            [self getMyWaitList:^(bool status) {
                if(status){
                    [self getWaitList];
                }
                else{
                    [self getWaitList];
                }
            }];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            [self getMyWaitList:^(bool status) {
                if(status){
                    [self getWaitList];
                }
                else{
                    [self getWaitList];
                }
            }];
        }
    }];
}

-(IBAction)pressBtnaccept:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    connectionManager *connect = [[connectionManager alloc] init];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom",record.userid,@"userTo",record.isBestFd,@"isBestFd", nil];
    [connect postRequest:UPDATE_USER_FD_CASE parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"已接受好友邀請" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            [self getMyWaitList:^(bool status) {
                if(status){
                    [self getWaitList];
                }
                else{
                    [self getWaitList];
                }
            }];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            [self getMyWaitList:^(bool status) {
                if(status){
                    [self getWaitList];
                }
                else{
                    [self getWaitList];
                }
            }];
        }
    }];
}

-(IBAction)pressBtnresend:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    connectionManager *connect = [[connectionManager alloc] init];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom",record.userid,@"userTo",record.isBestFd,@"isBestFd", nil];
    [connect postRequest:UPDATE_USER_FD_CASE parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"重新發送好友邀請" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            [self getWaitList];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            
        }
    }];
}

-(IBAction)pressPhoneCall:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    self.fdRecord = record;
    self.alertView = [[UIAlertView alloc] initWithTitle:@"致電親友" message:@"" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles:@"確定", nil];
    [self.alertView show];
}

-(IBAction)pressEdit:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    //    [record updateName:[[aryObj objectAtIndex:indexPath.row] objectForKey:@"username"]];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupAddMemberViewController *vc = (popupAddMemberViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupAddMemberViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    vc.pre_view = self;
    [self presentViewController:vc animated:YES completion:^{
        [vc editMemberRecord:record];
    }];
}

-(IBAction)pressDel:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom",record.userid,@"userTo", nil];
    [[connectionManager alloc] postRequest:REMOVE_USER_WAIT_LIST parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"已刪除好友" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            [self getServerFdList:^(bool status) {
                
            }];
        }
    }];
}

-(IBAction)pressBtnmsg:(id)sender{
    fdListBtn *btn = (fdListBtn*) sender;
    fdRecord *record = (fdRecord*)btn.record;
    if(record.countAddAlbum == 0){
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"albumViewController"];
        NSMutableArray *navigationArray = [[NSMutableArray alloc] initWithArray: self.navigationController.viewControllers];
        [navigationArray removeObjectAtIndex: [navigationArray count]-1];  // You can pass your index here
        [navigationArray addObject:vc];
        self.navigationController.viewControllers = navigationArray;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)addORDoneRows
{
    if(self.editing)
    {
        [super setEditing:NO animated:NO];
        [self.tv_fd setEditing:NO animated:NO];
        self.tv_fd.allowsSelectionDuringEditing = NO;
        [self.tv_fd reloadData];
        [self.navigationItem.leftBarButtonItem setTitle:@"Edit"];
        [self.navigationItem.leftBarButtonItem setStyle:UIBarButtonItemStylePlain];
    }
    else
    {
        [super setEditing:YES animated:YES];
        [self.tv_fd setEditing:YES animated:YES];
        self.tv_fd.allowsSelectionDuringEditing = YES;
        [self.tv_fd reloadData];
        [self.navigationItem.leftBarButtonItem setTitle:@"Done"];
        [self.navigationItem.leftBarButtonItem setStyle:UIBarButtonItemStyleDone];
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    fontManager *font = [[fontManager alloc] init];
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 45)];
    UILabel *myLabel = [[UILabel alloc] init];
    myLabel.frame = CGRectMake(5, 5, headerView.frame.size.width - 10, headerView.frame.size.height - 10);
    myLabel.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    myLabel.textColor = [UIColor whiteColor];
    if(self.btn_fd.selected == true){
        if (section == 0){
            [headerView setBackgroundColor:[UIColor colorWithRed:238/255.0f green:68/255.0f blue:68/255.0f alpha:0.7]];
            myLabel.text = @"至親";
        }
        else if (section == 1){
            [headerView setBackgroundColor:[UIColor colorWithRed:0/255.0f green:77/255.0f blue:64/255.0f alpha:0.7]];
            myLabel.text = @"親友";
        }
    }
    if(self.btn_wait.selected == true){
        if (section == 0){
            [headerView setBackgroundColor:[UIColor colorWithRed:46/255.0f green:125/255.0f blue:50/255.0f alpha:0.7]];
            myLabel.text = @"親友邀請";
        }
        else if (section == 1){
            [headerView setBackgroundColor:[UIColor colorWithRed:238/255.0f green:68/255.0f blue:68/255.0f alpha:0.7]];
            myLabel.text = @"至親";
        }
        else if (section == 2){
            [headerView setBackgroundColor:[UIColor colorWithRed:0/255.0f green:77/255.0f blue:64/255.0f alpha:0.7]];
            myLabel.text = @"親友";
        }
    }
    [headerView addSubview:myLabel];
    return headerView;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.btn_fd.selected == true){
        return [self.aryData count];
    }
    else if(self.btn_wait.selected == true){
        return [self.aryWait count];
    }
    else if(self.btn_rank.selected == true){
        return 1;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.btn_fd.selected == true){
        return 45;
    }
    if(self.btn_wait.selected == true){
        return 45;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(self.btn_fd.selected == true){
        return [[self.aryData objectAtIndex:section] count];
    }
    if(self.btn_wait.selected == true){
        return [[self.aryWait objectAtIndex:section] count];
    }
    if(self.btn_rank.selected == true){
        return [self.aryRank count];
    }
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(self.editing){
        NSMutableArray *aryObj = [self.aryData objectAtIndex:indexPath.section];
        fdRecord *record = [[fdRecord alloc] initWithDict:[aryObj objectAtIndex:indexPath.row]];
        [record updateName:[[aryObj objectAtIndex:indexPath.row] objectForKey:@"username"]];
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        popupAddMemberViewController *vc = (popupAddMemberViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupAddMemberViewController"];
        vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
        vc.pre_view = self;
        [self presentViewController:vc animated:YES completion:^{
            [vc editMemberRecord:record];
        }];
    }
    else{
        
    }
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    fontManager *font = [[fontManager alloc] init];
    
    if(self.btn_rank.selected == true){        
        static NSString *simpleTableIdentifier = @"addressBookRankTableViewCell";
        addressBookRankTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        cell = nil;
        if(!cell){
            [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
            cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        }
        NSDictionary *aryObj = [self.aryRank objectAtIndex:indexPath.row];
        fdRecord *rd = [[fdRecord alloc] initWithDict:aryObj];
        NSLog(@"record.name:%@",rd.name);
        [rd updateName:[aryObj objectForKey:@"username"]];
        cell.lbl_name.text = rd.name;
        cell.lbl_name.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.lbl_mark.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        cell.lbl_mark.text = [NSString stringWithFormat:@"%d",rd.countSum];
        
        if(rd.imagePath != nil){
            NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,rd.imagePath]];
            [cell.iv_img setImageWithURL:url placeholderImage:[UIImage imageNamed:@"sign_pic_none"]];
        }
        else{
            cell.iv_img.image = [UIImage imageNamed:@"sign_pic_none"];
        }
        cell.iv_img.layer.cornerRadius = cell.iv_img.frame.size.width/2;
        cell.iv_img.layer.masksToBounds=YES;
        cell.iv_img.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
        cell.iv_img.layer.borderWidth= 2.0f;
        
        cell.v_body.layer.cornerRadius=8.0;
        cell.v_body.layer.masksToBounds=YES;
        cell.v_body.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
        cell.v_body.layer.borderWidth= 2.0f;
        float orgY = cell.lbl_name.frame.origin.y + cell.lbl_name.frame.size.height;
        cell.progressBarView = nil;
        if(cell.progressBarView == nil){
            cell.progressBarView = [[TYMProgressBarView alloc] initWithFrame:CGRectMake(cell.lbl_name.frame.origin.x, orgY, cell.lbl_name.frame.size.width, cell.v_body.frame.size.height - orgY - 5)];
        }
        else{
            cell.progressBarView.frame = CGRectMake(cell.lbl_name.frame.origin.x, orgY, cell.lbl_name.frame.size.width, cell.v_body.frame.size.height - orgY - 5);
        }
        cell.progressBarView.barBorderWidth = 0.0;
        cell.progressBarView.barFillColor = [UIColor colorWithRed:212.0/255.0 green:79.0/255.0 blue:79.0/255.0 alpha:1.0];
        [cell.progressBarView setBarBackgroundColor:[UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:1.0]];
        [cell.v_body addSubview:cell.progressBarView];
        
        // Set the progress
        float a = rd.countSum;
        float b = self.maxRank;
        float c = a/b;
        cell.progressBarView.progress = c;
        
        [cell setBackgroundColor:[UIColor clearColor]];
        return cell;
    }
    else{
        static NSString *simpleTableIdentifier = @"addressBookTableViewCell";
        addressBookTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if(!cell){
            [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
            cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        }
        NSMutableArray *aryObj = nil;
        if(self.btn_fd.selected == true){
            aryObj = [self.aryData objectAtIndex:indexPath.section];
        }
        else if(self.btn_wait.selected == true){
            aryObj = [self.aryWait objectAtIndex:indexPath.section];
        }
        fdRecord *record = [[fdRecord alloc] initWithDict:[aryObj objectAtIndex:indexPath.row]];
        [record updateName:[[aryObj objectAtIndex:indexPath.row] objectForKey:@"username"]];
        if(record.imagePath != nil){
            NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,record.imagePath]];
            [cell.iv_img setImageWithURL:url placeholderImage:[UIImage imageNamed:@"sign_pic_none"]];
        }
        else{
            cell.iv_img.image = [UIImage imageNamed:@"sign_pic_none"];
        }
        [record updateName:[[aryObj objectAtIndex:indexPath.row] objectForKey:@"username"]];
        cell.lbl_name.text = record.name;
        cell.lbl_name.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
        if(record.countAddAlbum == 0){
            cell.btn_msg.selected = YES;
        }
        else{
            cell.btn_msg.selected = NO;
            [cell.btn_msg setTitle:[NSString stringWithFormat:@"%d",record.countAddAlbum] forState:UIControlStateNormal];
        }
        cell.iv_img.layer.cornerRadius=cell.iv_img.frame.size.width/2;
        cell.iv_img.layer.masksToBounds=YES;
        cell.iv_img.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
        cell.iv_img.layer.borderWidth= 2.0f;
        
        cell.v_body.layer.cornerRadius=8.0;
        cell.v_body.layer.masksToBounds=YES;
        cell.v_body.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
        cell.v_body.layer.borderWidth= 2.0f;
        
        
        cell.btn_msg.hidden = cell.btn_call.hidden = cell.btn_accept.hidden = cell.btn_reject.hidden = cell.btn_resend.hidden = cell.btn_edit.hidden = cell.btn_del.hidden = true;
        cell.btn_msg.tag = cell.btn_call.tag = cell.btn_accept.tag = cell.btn_reject.tag = cell.btn_resend.tag = indexPath.row;
        
        [cell.btn_msg setfdRecord:(NSObject*)record];
        [cell.btn_call setfdRecord:(NSObject*)record];
        [cell.btn_accept setfdRecord:(NSObject*)record];
        [cell.btn_reject setfdRecord:(NSObject*)record];
        [cell.btn_resend setfdRecord:(NSObject*)record];
        [cell.btn_del setfdRecord:(NSObject*)record];
        [cell.btn_edit setfdRecord:(NSObject*)record];
        
        [cell.btn_call addTarget:self action:@selector(pressPhoneCall:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_accept addTarget:self action:@selector(pressBtnaccept:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_reject addTarget:self action:@selector(pressBtnreject:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_resend addTarget:self action:@selector(pressBtnresend:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_msg addTarget:self action:@selector(pressBtnmsg:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_edit addTarget:self action:@selector(pressEdit:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_del addTarget:self action:@selector(pressDel:) forControlEvents:UIControlEventTouchUpInside];
        
        if(!self.editing){
            if(self.btn_fd.selected == true){
                cell.btn_call.hidden = cell.btn_msg.hidden = false;
            }
            else if(self.btn_wait.selected == true){
                if(indexPath.section == 0){
                    cell.btn_accept.hidden = cell.btn_reject.hidden = false;
                }
                else{
                    cell.btn_resend.hidden = false;
                }
            }
        }
        else{
            cell.btn_del.hidden = cell.btn_edit.hidden = NO;
        }
        
        
        [cell.btn_call addTarget:self action:@selector(pressPhoneCall:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btn_call setTag:indexPath.row];
        
        
        
        [cell setBackgroundColor:[UIColor clearColor]];
        return cell;
    }
    return nil;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleNone;
}

-(void)share:(BOOL)isMember{
    self.editing = FALSE;
    [self.btn_fdEdit setImage:[UIImage imageNamed:@"btn_edit_M"] forState:UIControlStateNormal];
    if(!isMember){
        WhatsAppMessage *whatsappMsg = [[WhatsAppMessage alloc] initWithMessage:@"https://angelink.ywca.org.hk/share.php" forABID:@"你好，我正在使用 AngeLINK，誠邀你一同使用。"];
        NSArray *applicationActivities = @[[[JBWhatsAppActivity alloc] init]];
        NSArray *excludedActivities    = @[UIActivityTypePrint, UIActivityTypePostToWeibo, UIActivityTypeMessage];
        NSArray *activityItems         = @[@"https://angelink.ywca.org.hk/share.php", whatsappMsg];
        UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:applicationActivities];
        activityViewController.excludedActivityTypes = excludedActivities;
        [self presentViewController:activityViewController animated:YES completion:^{}];
        //        [self.tv_fd reloadData];
        //        [self getFdList];
    }
    [self getServerFdList:^(bool status) {
        [self getFdList];
    }];
}

-(void) getMyWaitList:(void (^)(bool))completionBlock{
    [self.aryData removeAllObjects];
    [self.aryRank removeAllObjects];
    [self.aryWait removeAllObjects];
    
    connectionManager *connect = [[connectionManager alloc] init];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom", nil];
    [connect postRequestReturnArray:GET_USER_WAIT_LIST parameters:dict completionHandler:^(bool status, NSMutableArray *jsonArray) {
        [self getServerFdList:^(bool status) {}];
        if(status){
                dbManager *db = [[dbManager alloc] init];
                for(int i=0;i<[jsonArray count];i++){
                    fdRecord *record = [[fdRecord alloc] initWithDict:[jsonArray objectAtIndex:i]];
                    if([[db selectSQL:@"tbl_relation" where:[NSString stringWithFormat:@"userid='%@'",record.userid] option:@""] count]>0){
                        NSString *query = [NSString stringWithFormat:@" imagePath='%@', isBestFd='%@', username='%@', phone='%@', phoneAreaCode='%@', mode='%@' ",record.imagePath,record.isBestFd,record.name,record.phone,record.phoneAreaCode,record.mode];
                        NSString *where = [NSString stringWithFormat:@"userid='%@'",record.userid];
                        [db updateSQL:@"tbl_relation" tCol:query tWhere:where];
                    }
                    else{
                        NSString *key = @"userid,username,phoneAreaCode,phone,isBestFd,countSum,mode,countFbPost,countComment,countLike,countPhone,countAddAlbum";
                        NSString *value = [NSString stringWithFormat:@"'%@','%@','%@','%@','%@','%@','%@','%d','%d','%d','%d','%d'",record.userid,record.name,record.phoneAreaCode,record.phone,record.isBestFd,@"0",record.mode,record.countFbPost,record.countComment,record.countLike,record.countPhone,record.countAddAlbum];
                        [db insertSQL:@"tbl_relation" tKey:key tValue:value];
                    }
                }
                [self getWaitList];
                completionBlock(true);
        }
        else{
            [self getWaitList];
            completionBlock(false);
        }
    }];
    
}

-(void) getServerFdList:(void (^)(bool))completionBlock{
    [self.aryData removeAllObjects];
    [self.aryRank removeAllObjects];
    [self.aryWait removeAllObjects];
    connectionManager *connect = [[connectionManager alloc] init];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom", nil];
    [connect postRequestReturnArray:GET_USER_FD_LIST parameters:dict completionHandler:^(bool status, NSMutableArray *jsonArray) {
        if(status){
            if(self.aryData == nil){
                self.aryData = [NSMutableArray new];
            }
            else{
                [self.aryData removeAllObjects];
            }
            dbManager *db = [[dbManager alloc] init];
            [db deleteSQL:@"tbl_relation"];
            for(int i=0;i<[jsonArray count];i++){
                fdRecord *record = [[fdRecord alloc] initWithDict:[jsonArray objectAtIndex:i]];
                if([[db selectSQL:@"tbl_relation" where:[NSString stringWithFormat:@"userid='%@'",record.userid] option:@""] count]>0){
                    NSString *query = [NSString stringWithFormat:@" imagePath='%@', isBestFd='%@', username='%@', phone='%@', phoneAreaCode='%@', mode='' ",record.imagePath,record.isBestFd,record.name,record.phone,record.phoneAreaCode];
                    NSString *where = [NSString stringWithFormat:@"userid='%@'",record.userid];
                    [db updateSQL:@"tbl_relation" tCol:query tWhere:where];
                }
                else{
                    NSString *key = @"userid,username,phoneAreaCode,phone,isBestFd,countSum,mode,countFbPost,countComment,countLike,countPhone,countAddAlbum,imagePath";
                    NSString *value = [NSString stringWithFormat:@"'%@','%@','%@','%@','%@','%@','%@','%d','%d','%d','%d','%d','%@'",record.userid,record.name,record.phoneAreaCode,record.phone,record.isBestFd,@"0",@"",record.countFbPost,record.countComment,record.countLike,record.countPhone,record.countAddAlbum,record.imagePath];
                    [db insertSQL:@"tbl_relation" tKey:key tValue:value];
                }
            }
            
            [self getFdList];
            completionBlock(true);
        }
        else{
            completionBlock(false);
        }
    }];
    
}

-(void) updateFdCount:(void (^)(bool))completionBlock{
    connectionManager *connect = [[connectionManager alloc] init];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userTo", nil];
    [connect postRequestReturnArray:GET_USER_SUM_COUNT parameters:dict completionHandler:^(bool state, NSMutableArray *jsonArray1) {
        if(state){
            if([jsonArray1 count] > 0){
                dbManager *db = [[dbManager alloc] init];
                for(int j=0;j<[jsonArray1 count];j++){
                    NSDictionary *dict1 = [jsonArray1 objectAtIndex:j];
                    NSString *query = [NSString stringWithFormat:@"countSum='%@'",[dict1 objectForKey:@"countSum"]];
                    NSString *where = [NSString stringWithFormat:@"userid='%@'",[dict1 objectForKey:@"userFrom"]];
                    int count = [[dict1 objectForKey:@"countSum"] intValue];
                    if(count >= self.maxRank){
                        self.maxRank = count;
                    }
                    [db updateSQL:@"tbl_relation" tCol:query tWhere:where];
                }
                completionBlock(true);
            }
            else{
                completionBlock(false);
            }
        }
        else{
            completionBlock(false);
        }
    }];
}

-(void) getFdList{
    if(self.aryData == nil)
        self.aryData = [NSMutableArray new];
    else
        [self.aryData removeAllObjects];
    dbManager *db = [[dbManager alloc] init];
    NSMutableArray *ary1 = [db selectSQL:@"tbl_relation" where:@"isBestFd='1' AND mode=''" option:@""];
    NSMutableArray *ary2 = [db selectSQL:@"tbl_relation" where:@"isBestFd='0' AND mode=''" option:@""];
    [self.aryData addObject:ary1];
    [self.aryData addObject:ary2];
    [self.tv_fd reloadData];
}

-(void) getRankList{
    [self updateFdCount:^(bool status) {
        if(status){
            if(self.aryRank == nil){
                self.aryRank = [NSMutableArray new];
            }
            else{
                [self.aryRank removeAllObjects];
            }
            dbManager *db = [[dbManager alloc] init];
            NSMutableArray *ary = [db selectSQL:@"tbl_relation" where:@"" option:@""];
            NSMutableArray *ary1 = [db selectSQL:@"tbl_relation" where:@"mode=''" option:@"Order By countSum DESC, username ASC"];
            self.aryRank = ary1;
            [self.tv_rank reloadData];
        }
    }];
}

-(void) getWaitList{
    [self.aryWait removeAllObjects];
    dbManager *db = [[dbManager alloc] init];
    NSMutableArray *ary1 = [db selectSQL:@"tbl_relation" where:@"mode='INVITE'" option:@""];
    NSMutableArray *ary2 = [db selectSQL:@"tbl_relation" where:@"mode='REPLY' AND isBestFd='1'" option:@""];
    if(ary2 == nil)
        ary2 = [NSMutableArray new];
    NSMutableArray *ary3 = [db selectSQL:@"tbl_relation" where:@"mode='REPLY' AND isBestFd='0'" option:@""];
    if(ary3 == nil)
        ary3 = [NSMutableArray new];
    [self.aryWait addObject:ary1];
    [self.aryWait addObject:ary2];
    [self.aryWait addObject:ary3];
    [self.tv_wait reloadData];
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(self.alertView == alertView){
        if(buttonIndex == 1){
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"userFrom",self.fdRecord.userid,@"userTo",@"P",@"countType",@"1",@"countAmt", nil];
            [[connectionManager alloc] postRequest:ADD_COUNT_LIKE parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",self.fdRecord.phone]]];
            }];
        }
    }    
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    self.btn_fd.selected = self.btn_rank.selected = self.btn_wait.selected = false;
}
@end
