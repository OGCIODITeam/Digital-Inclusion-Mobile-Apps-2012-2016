//
//  albumDetailViewController.h
//  AngeLink
//
//  Created by kanhan on 22/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//
#import "common.h"
#import "headerBar.h"
#import "infoView.h"
#import "albumCollectionViewCell.h"

@interface albumDetailViewController : UIViewController<headerBarViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIAlertViewDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *cv_main;
@property (nonatomic, retain) NSMutableArray *aryData;
@property (nonatomic, retain) NSString *albumTitle;
@property (weak, nonatomic) IBOutlet UIView *v_percent;
@property (weak, nonatomic) IBOutlet UILabel *lbl_percentTitle;
@property (retain, nonatomic) TYMProgressBarView *progressBarView;
@property (weak, nonatomic) IBOutlet UIButton *btn_add;
@property (weak, nonatomic) IBOutlet UIButton *btn_edit;
@property (retain, nonatomic) NSDictionary *userDict,*albumDict,*albumDelDict;
@property (assign, nonatomic) BOOL isEdit;
@property (retain, nonatomic) UIAlertView *alertView,*alertAlbum,*deleteAlbum;
@property (retain, nonatomic) NSIndexPath *albumIndexPath;
@property (nonatomic, retain) MBProgressHUD *hud;
@property (nonatomic, retain) infoView *info;

-(void)callBackFunction;
-(void) updateUI;
@end

