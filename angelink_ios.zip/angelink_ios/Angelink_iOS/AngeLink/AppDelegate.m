//
//  AppDelegate.m
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "AppDelegate.h"
#define SET_LATLNG_TIME 60 //1 min. set location point
#define TOTAL_CHECK_POINT 288

#define ROOTVIEW [[[UIApplication sharedApplication] keyWindow] rootViewController]

@interface AppDelegate ()
@end

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [application setStatusBarHidden:YES];
    NSUserDefaults *user_default = [NSUserDefaults standardUserDefaults];
    NSString *temp = [[NSLocale preferredLanguages] objectAtIndex:0];
    NSString *language = [temp substringToIndex:2];
    [user_default setValue:@"zh-Hant" forKey:@"lang"];
    [[BundleLocalization sharedInstance] setLanguage:[user_default objectForKey:@"lang"]];
    [user_default setObject:[NSArray arrayWithObject:[user_default objectForKey:@"lang"]] forKey:@"Applanguage"];
    [user_default synchronize];
    
    
    //    [Bugsnag startBugsnagWithApiKey:@"546a18ba0dd0a4cb9839e5221915cd6d"];
    if([application respondsToSelector:@selector(registerUserNotificationSettings:)]){
        UIUserNotificationType userNotificationTypes = (UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound);
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:userNotificationTypes categories:nil];
        [application registerUserNotificationSettings:settings];
        [application registerForRemoteNotifications];
    }
    //若iOS為較舊的版本
    else {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert| UIRemoteNotificationTypeBadge |  UIRemoteNotificationTypeSound)];
    }
    UIImage *navBarBackgroundImage = [UIImage imageNamed:@"hd_typo.png"];
    [[UINavigationBar appearance] setBackgroundImage:navBarBackgroundImage forBarMetrics:UIBarMetricsDefault];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *docDirPath = [documentsDirectory stringByAppendingPathComponent:@"Info.plist"];
    if(self.mediaArray == nil){
        self.mediaArray = [NSMutableArray new];
    }
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if(![fileManager fileExistsAtPath: docDirPath]) {
        NSString *bundle = [[NSBundle mainBundle] pathForResource:@"Info" ofType:@"plist"];
        
        [fileManager copyItemAtPath:bundle toPath:docDirPath error:&error];
    }
    [self runGPS];
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];
    return YES;
}

-(void) runGPS{
    
    if([[[utilityManager alloc] getUserDefaultstoString:@"GPS"] isEqualToString:@"1"]){
        dispatch_async(dispatch_get_main_queue(), ^{
            locationManager = [[CLLocationManager alloc] init];
            locationManager.delegate = self;
            locationManager.distanceFilter = kCLDistanceFilterNone;
            locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        });
#ifdef __IPHONE_8_0
        if(IS_OS_8_OR_LATER) {
            // Use one or the other, not both. Depending on what you put in info.plist
            [locationManager requestWhenInUseAuthorization];
            [locationManager requestAlwaysAuthorization];
        }
#endif
        
        //        [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
        if(!self.timer.isValid){
            dispatch_async(dispatch_get_main_queue(), ^{
                [locationManager startUpdatingLocation];
            });
            //            self.timer = [NSTimer scheduledTimerWithTimeInterval: 60.0// *15
            self.timer = [NSTimer scheduledTimerWithTimeInterval: SET_LATLNG_TIME// *15
                                                          target: self
                                                        selector:@selector(aTime:)
                                                        userInfo: nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
        }
    }
}

-(void) stopRunGPS{
    if(!self.timer.isValid){
        [self.timer invalidate];
    }
    if(!self.checklatlng.isValid){
        [self.checklatlng invalidate];
    }
}

-(void)Latlng
{
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL isMoving = NO;
        int aryLimit = 0;
        NSMutableArray *ary = self.locationArray;
        NSLog(@"latlng ary:%@",ary);
        for(int i = 0 ; i<[ary count];i++){
            isMoving = NO;
            for(int j = i+1;j<[ary count];j++){
                CLLocation *loc1 = [[CLLocation alloc] initWithLatitude:[[[ary objectAtIndex:i] objectForKey:@"lat"] doubleValue] longitude:[[[ary objectAtIndex:i] objectForKey:@"lng"] doubleValue]];
                CLLocation *loc2 = [[CLLocation alloc] initWithLatitude:[[[ary objectAtIndex:j] objectForKey:@"lat"] doubleValue] longitude:[[[ary objectAtIndex:j] objectForKey:@"lng"] doubleValue]];
                CLLocationDistance distance = [loc1 distanceFromLocation:loc2];
                if(distance >= 50.0 ){
                    isMoving = YES;
                }
            }
            if(!isMoving){
                aryLimit++;
            }
        }
        
        //    192
        if(aryLimit > TOTAL_CHECK_POINT){
            connectionManager *connect = [[connectionManager alloc] init];
            utilityManager *utility = [[utilityManager alloc] init];
            if([utility getUserDefaultstoString:@"memberID"] != nil){
                NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys: [utility getUserDefaultstoString:@"memberID"], @"user_id", nil];
                [connect postRequest:MSG_NOTICE_LOW_ACTION parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
                    [[utilityManager alloc] writeErrorLogToTextFile:@"GPS Cal. done, send message to push server" event:@"GPS" module:@""];
                    [self.locationArray removeAllObjects];
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Send GPS Message to Server..." delegate:nil cancelButtonTitle:@"Close" otherButtonTitles: nil];
                    [alert show];
                }];
                [[utilityManager alloc] writeErrorLogToTextFile:@"GPS Cal. fail, send message to push server" event:@"GPS" module:@""];
                [[utilityManager alloc] exportLogFileToiTune];
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Send GPS Message to Server..." delegate:nil cancelButtonTitle:@"Close" otherButtonTitles: nil];
                [alert show];
            }
        }
    });
}

-(void)aTime:(NSTimer*)timer
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [locationManager startUpdatingLocation];
    });
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    if(self.locationArray == nil){
        self.locationArray = [NSMutableArray new];
    }
    if(self.insertTime == nil){
        self.insertTime = [NSDate date];
        //        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys: [[utilityManager alloc] NSDateToNSString:[NSDate date] DateFormat:SQLITEDATETIMEFORMAT], @"createDate", [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude], @"lat", [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude], @"lng", nil];
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys: [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude], @"lat", [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude], @"lng", nil];
        NSLog(@"dict:%@",dict);
        [self.locationArray addObject:dict];
        NSLog(@"self.insertTime:%@ array count:%d",self.insertTime, [self.locationArray count]);
        NSString *str = [NSString stringWithFormat:@"%d) %@ - LAT:%f , LNG:%f",[self.locationArray count] ,self.insertTime,newLocation.coordinate.latitude,newLocation.coordinate.longitude];
        [[utilityManager alloc] writeErrorLogToTextFile:str event:@"GPS" module:@""];
    }
    else{
        if([[utilityManager alloc] compareDateObject:self.insertTime secordObject:[NSDate date] returnValue:@"second"] > SET_LATLNG_TIME){
            self.insertTime = [NSDate date];
            NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys: [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude], @"lat", [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude], @"lng", nil];
            [self.locationArray addObject:dict];
            NSLog(@"self.insertTime:%@ array count:%d",self.insertTime, [self.locationArray count]);
            NSString *str = [NSString stringWithFormat:@"%d) %@ - LAT:%f , LNG:%f",[self.locationArray count] ,self.insertTime,newLocation.coordinate.latitude,newLocation.coordinate.longitude];
            [[utilityManager alloc] writeErrorLogToTextFile:str event:@"GPS" module:@""];
        }
    }
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [locationManager stopUpdatingLocation];
//    });
    if([self.locationArray count] >= TOTAL_CHECK_POINT){
        [self Latlng];
    }
    [[utilityManager alloc] exportLogFileToiTune];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    [self runGPS];
    [self Latlng];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    [application beginBackgroundTaskWithName:@"MyTask" expirationHandler:^{
        // Clean up any unfinished task business by marking where you
        // stopped or ending the task outright.
        [self runGPS];
        [self Latlng];
        //            [application endBackgroundTask:bgTask];
        //            bgTask = UIBackgroundTaskInvalid;
    }];
    
    // Start the long-running task and return immediately.
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // Do the work associated with the task, preferably in chunks.
        [self runGPS];
        [self Latlng];
        
        //            [application endBackgroundTask:bgTask];
        //            bgTask = UIBackgroundTaskInvalid;
    });
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [self runGPS];
    [self Latlng];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [self runGPS];
    [self Latlng];
}

-(BOOL)prefersStatusBarHidden{
    return YES;
}

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
            options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    
    BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
                                                                  openURL:url
                                                        sourceApplication:options[UIApplicationOpenURLOptionsSourceApplicationKey]
                                                               annotation:options[UIApplicationOpenURLOptionsAnnotationKey]
                    ];
    // Add any custom logic here.
    return handled;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [FBSDKAppEvents activateApp];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    if ( application.applicationState == UIApplicationStateActive )
    {
        // app was already in the foreground
        if([userInfo objectForKey:@"FD_INVITE"] != nil){
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                     bundle: nil];
            
            UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
            UIViewController *vc1 = [mainStoryboard instantiateViewControllerWithIdentifier: @"circleViewController"];
            [vc.navigationController pushViewController:vc1 animated:YES];
            [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
        }
        else{
            if([userInfo objectForKey:@"tickerText"] != nil){
                [[NSNotificationCenter defaultCenter] postNotificationName: @"angelINK_Message" object:nil userInfo:userInfo];
            }
            else{
                NSDictionary *aps = [userInfo objectForKey:@"aps"];
                NSDictionary *dict = [aps objectForKey:@"alert"];
                [HDNotificationView showNotificationViewWithImage:[UIImage imageNamed:@"Icon"] title:@"AngeLINK" message:dict isAutoHide:YES];
            }
        }
    }
    else if(application.applicationState == UIApplicationStateBackground)
    {
        if([userInfo objectForKey:@"tickerText"] != nil){
            [[NSNotificationCenter defaultCenter] postNotificationName: @"angelINK_Message" object:nil userInfo:userInfo];
        }
        else{
            NSDictionary *aps = [userInfo objectForKey:@"aps"];
            NSDictionary *dict = [aps objectForKey:@"alert"];
            [HDNotificationView showNotificationViewWithImage:[UIImage imageNamed:@"Icon"] title:@"AngeLINK" message:dict isAutoHide:YES];
        }
    }
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    const unsigned *tokenBytes = [deviceToken bytes];
    NSString *iOSDeviceToken =
    [NSString stringWithFormat:@"%08x%08x%08x%08x%08x%08x%08x%08x",
     ntohl(tokenBytes[0]), ntohl(tokenBytes[1]), ntohl(tokenBytes[2]),
     ntohl(tokenBytes[3]), ntohl(tokenBytes[4]), ntohl(tokenBytes[5]),
     ntohl(tokenBytes[6]), ntohl(tokenBytes[7])];
    //將Device Token傳給Provider...
    
    connectionManager *connect = [[connectionManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    NSDictionary *DeviceToken = [NSDictionary dictionaryWithObjectsAndKeys: iOSDeviceToken, @"DeviceToken", @"iOS", @"deviceType", nil];
    [[utilityManager alloc] saveValuetoUserDefaults:DeviceToken];
    if([utility getUserDefaultstoString:@"memberID"] != nil){
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:iOSDeviceToken,@"deviceToken",[utility getUserDefaultstoString:@"memberID"],@"user_id", @"iOS", @"deviceType", nil];
        [connect postRequest:UPDATE_DEVICE_TOKEN parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        }];
    }
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    
}

-(void) showLoading{
    if(self.hud == nil){
        UINavigationController *myNavCon = (UINavigationController*)self.window.rootViewController;
        self.hud = [MBProgressHUD showHUDAddedTo:myNavCon.view animated:YES];
        self.hud.mode = MBProgressHUDModeIndeterminate;
        self.hud.square = YES;
        self.hud.label.text = NSLocalizedString(@"Loading", @"Loading");
        [self.hud showAnimated:YES];
    }
    else{
        [self.hud showAnimated:YES];
    }
    [self.window bringSubviewToFront:self.hud];
}

-(void) hideLoading{
    [self.hud hideAnimated:YES];
    self.hud = nil;
}



@end
