//
//  popupCreateAlbumViewController.h
//  AngeLink
//
//  Created by kanhan on 7/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface popupCreateAlbumViewController : UIViewController<iCarouselDelegate,iCarouselDataSource,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIView *v_popupBody;
@property (weak, nonatomic) IBOutlet UILabel *lbl_Title;
@property (weak, nonatomic) IBOutlet UILabel *lbl_BgTitle;
@property (weak, nonatomic) IBOutlet iCarousel *ic_Bg;
@property (weak, nonatomic) IBOutlet UIButton *btn_save;
@property (weak, nonatomic) IBOutlet UIButton *btn_cancel;
@property (nonatomic, retain) NSMutableArray *aryData;
@property (weak, nonatomic) IBOutlet UITextField *tf_albumName;
@property (weak, nonatomic) IBOutlet UILabel *lbl_albumName;
@property (nonatomic, retain) UIViewController *pre_view;
@property (weak, nonatomic) IBOutlet UIButton *btn_cam;
@property (weak, nonatomic) IBOutlet UIButton *btn_lib;
@property (weak, nonatomic) IBOutlet UIScrollView *sv_Bg;
@property (nonatomic, assign) BOOL isDefault;
@property (nonatomic, retain) UIImage* originalImage;
@property (nonatomic, retain) UIViewController *page;
@property (nonatomic, retain) NSObject *record;
@property (nonatomic, retain) NSString *bgType;
@property (nonatomic, retain) MBProgressHUD *hud;
-(void) updateUI;


@end
