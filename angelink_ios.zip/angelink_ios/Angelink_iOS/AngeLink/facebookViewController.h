//
//  facebookViewController.h
//  AngeLink
//
//  Created by kanhan on 14/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface facebookViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lbl_tittle;
@property (weak, nonatomic) IBOutlet UITextView *tv_description;
@property (weak, nonatomic) IBOutlet UIButton *btn_signFB;
@property (weak, nonatomic) IBOutlet UIButton *btn_skip;

@end
