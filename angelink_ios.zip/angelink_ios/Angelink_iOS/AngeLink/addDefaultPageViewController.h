//
//  addDefaultPageViewController.h
//  AngeLink
//
//  Created by kanhan on 6/12/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface addDefaultPageViewController : UIViewController<headerBarViewDelegate,UITextFieldDelegate,UITextViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *sv_main;
@property (weak, nonatomic) IBOutlet UIButton *btn_skip;
@property (weak, nonatomic) IBOutlet UIButton *btn_nextQuestion;
@property (retain, nonatomic) UIButton *btn_TextToSpeech;
@property (nonatomic, retain) NSString *headerTitle,*editValue,*userValue;
@property (weak, nonatomic) IBOutlet UIView *v_main;

@property (weak, nonatomic) IBOutlet UIView *v_inputImage;
@property (weak, nonatomic) IBOutlet UIImageView *iv_inputImage;

@property (nonatomic, retain) UIImage *originalImage;

@property (nonatomic, assign) NSObject *record,*pageRecord;
@property (nonatomic, assign) int questionID,pageSeq,subQuestionID,cnt;
@property (nonatomic, retain) NSMutableArray *aryObject,*questionList,*answerList,*answerImage;
@property (nonatomic, retain) NSString *stringValue, *stringPageTitle,*voiceTitle,*pageTitle;
@property (assign, nonatomic) BOOL isEdit,isPressBtn;
@property (nonatomic, retain) MBProgressHUD *hud;
@property (nonatomic, assign) CGRect orgRect;
@property (nonatomic, retain) headerBar *header;
@property (nonatomic,assign) int countQuestion;
@property (nonatomic, retain) NSMutableDictionary *questionDict;
@property (nonatomic, retain) infoView *info;
@property (nonatomic, assign) int TotalQuestion,CurrectNum;

@property (nonatomic, retain) NSDate *currectDate;
-(void) callBackFunction;
@end
