//
//  infoViewController.m
//  AngeLink
//
//  Created by kanhan on 21/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "infoViewController.h"
#import "AppDelegate.h"
#import "popupCalendarViewController.h"
#import "UIImage+addition.h"
#import "userObj.h"

@interface infoViewController ()

@end

@implementation infoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = @"更新個人資料";
    header.delegate = self;
    [self.view addSubview:header];
    
    self.iv_pic.layer.cornerRadius=self.iv_pic.frame.size.width/2;
    self.iv_pic.layer.masksToBounds=YES;
    self.iv_pic.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.iv_pic.layer.borderWidth= 3.0f;
    self.tf_name.layer.cornerRadius=8.0f;
    self.tf_name.layer.masksToBounds=YES;
    self.tf_name.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.tf_name.layer.borderWidth= 3.0f;
    utilityManager *utility = [[utilityManager alloc] init];
    if([utility getUserDefaultstoString:@"username"])
        self.tf_name.text = [utility getUserDefaultstoString:@"username"];
    self.lbl_mobileNo.text = [utility getUserDefaultstoString:@"phone"];
    [self.btn_dateDropdown setTitle:@"請選擇出身日期" forState:UIControlStateNormal];
    [self setFontUI];
    [self setScollUI];
    [self getUserInfo];
    [self setAccessibility];
    [self.btn_cam setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_lib setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_dateDropdown setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_calFormat setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

-(void) setAccessibility{
    self.btn_cam.isAccessibilityElement = true;
    self.btn_cam.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_cam.accessibilityLabel = @"相機";
    
    self.btn_lib.isAccessibilityElement = true;
    self.btn_lib.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_lib.accessibilityLabel = @"照片庫";
    
    self.btn_update.isAccessibilityElement = true;
    self.btn_update.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_update.accessibilityLabel = @"更新";
    
    self.btn_dateDropdown.isAccessibilityElement = true;
    self.btn_dateDropdown.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_dateDropdown.accessibilityLabel = @"選擇生日日期";
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtninfo:(id)sender{
    NSLog(@"press btn info");
}

-(void) updateSelectedDate{
    if(!self.isLunarDate){
        [self changeToDate];
        //        [self.btn_calFormat setImage:[UIImage imageNamed:@"西"] forState:UIControlStateNormal];
        [self.btn_calFormat setTitle:@"西" forState:UIControlStateNormal];
    }
    else{
        [self changeToLunarDate];
        //        [self.btn_calFormat setImage:[UIImage imageNamed:@"農"] forState:UIControlStateNormal];
        [self.btn_calFormat setTitle:@"農" forState:UIControlStateNormal];
        self.isLunarDate = false;
    }
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_tittle.textColor = self.lbl_name.textColor = self.lbl_mobile.textColor = self.tf_name.textColor = self.lbl_mobileNo.textColor = self.lbl_mobile.textColor = self.lbl_birth.textColor = [UIColor blackColor];
    
    self.lbl_tittle.font = self.lbl_name.font = self.lbl_mobile.font = self.tf_name.font = self.lbl_mobileNo.font = self.lbl_mobile.font = self.lbl_birth.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    [self.btn_dateDropdown.titleLabel setFont:[font getRegularsize:[font getSettingFont:@"Contact"]]];
    [self.btn_dateDropdown setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_update.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_update setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_calFormat.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_calFormat setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_calFormat setTitle:@"西" forState:UIControlStateNormal];
    self.tf_name.delegate = self;
}

-(void) setScollUI{
    float orgY = 0.0;
    float space = 5.0;
    self.iv_pic.center = CGPointMake(self.sv_info.frame.size.width/2, orgY + self.iv_pic.frame.size.height/2);
    self.btn_cam.center = CGPointMake(self.iv_pic.center.x+ self.iv_pic.frame.size.width/2, self.iv_pic.frame.origin.y + self.btn_cam.frame.size.height/2);
    self.btn_lib.center = CGPointMake(self.btn_cam.center.x, self.btn_cam.frame.origin.y + self.btn_cam.frame.size.height + self.btn_lib.frame.size.height/2);
    
    orgY += self.iv_pic.frame.size.height;
    orgY += space;
    
    self.lbl_name.frame = CGRectMake(0, orgY, self.sv_info.frame.size.width, self.lbl_name.frame.size.height);
    
    orgY += self.lbl_name.frame.size.height;
    orgY += space;
    
    self.tf_name.frame = CGRectMake(0, orgY, self.sv_info.frame.size.width, self.tf_name.frame.size.height);
    
    orgY += self.tf_name.frame.size.height;
    orgY += space;
    
    self.lbl_mobile.frame = CGRectMake(0, orgY, self.sv_info.frame.size.width, self.lbl_mobile.frame.size.height);
    
    orgY += self.lbl_mobile.frame.size.height;
    orgY += space;
    
    self.lbl_mobileNo.frame = CGRectMake(0, orgY, self.sv_info.frame.size.width, self.lbl_mobileNo.frame.size.height);
    
    orgY += self.lbl_mobileNo.frame.size.height;
    orgY += space;
    
    self.lbl_birth.frame = CGRectMake(0, orgY, self.sv_info.frame.size.width, self.lbl_birth.frame.size.height);
    
    orgY += self.lbl_birth.frame.size.height;
    orgY += space;
    
    self.btn_calFormat.frame = CGRectMake(0, orgY, self.btn_calFormat.frame.size.width, self.btn_calFormat.frame.size.height);
    
    //    self.btn_dateDropdown.frame = CGRectMake(self.btn_calFormat.frame.size.width, orgY, self.sv_info.frame.size.width - self.btn_calFormat.frame.size.width, self.btn_dateDropdown.frame.size.height);
    if([[utilityManager alloc] getUserDefaultstoString:@"birthday"] != nil || [[[utilityManager alloc] getUserDefaultstoString:@"birthday"] isEqualToString:@""]){
        [self.btn_dateDropdown setTitle:[[utilityManager alloc] getUserDefaultstoString:@"birthday"] forState:UIControlStateNormal];
        self.currectDate = [[utilityManager alloc] NSStringToNSDate:[[utilityManager alloc] getUserDefaultstoString:@"birthday"] DateFormat:SQLITEDATETIMEFORMAT];
    }

    self.btn_dateDropdown.frame = CGRectMake(0, orgY, self.sv_info.frame.size.width, self.btn_dateDropdown.frame.size.height);
    
    
    orgY += self.btn_dateDropdown.frame.size.height;
    orgY += space;
    
    self.btn_update.center = CGPointMake(self.sv_info.frame.size.width/2, orgY + self.btn_update.frame.size.height/2);
    
    orgY+= self.btn_update.frame.size.height;
    orgY += space;
    
    self.sv_info.contentSize = CGSizeMake(self.sv_info.frame.size.width, orgY);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)changeToLunarDate{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    if(app.selectedDate != nil)
    {
        SSLunarDate *lunar = [[SSLunarDate alloc] initWithDate:app.selectedDate];
        [self.btn_dateDropdown setTitle:[NSString stringWithFormat:@"%@ %@",[lunar string], [lunar zodiacString]] forState:UIControlStateNormal];
    }
}

-(void)changeToDate{
    
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    if(app.selectedDate != nil)
    {
        NSLocale *chinese = [NSLocale localeWithLocaleIdentifier:@"zh-CN"];
        NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
        dateFormatter1.locale = chinese;
        dateFormatter1.dateFormat = @"yyyy/MM/dd";
        [self.btn_dateDropdown setTitle:[dateFormatter1 stringFromDate:app.selectedDate] forState:UIControlStateNormal];
    }
}

-(IBAction)pressBtnlunar:(id)sender{
    if(!self.isLunarDate){
        [self changeToDate];
        //        [self.btn_calFormat setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [self.btn_calFormat setTitle:@"西" forState:UIControlStateNormal];
        self.isLunarDate = true;
    }
    else{
        [self changeToLunarDate];
        //        [self.btn_calFormat setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [self.btn_calFormat setTitle:@"農" forState:UIControlStateNormal];
        self.isLunarDate = false;
    }
}

-(IBAction)pressBtnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)pressBtncam:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnlib:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnupdate:(id)sender{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    NSDate* date = [NSDate date];
    if(app.selectedDate)
        date = app.selectedDate;
    utilityManager *utility = [[utilityManager alloc] init];
    connectionManager *connect = [[connectionManager alloc] init];
    dbManager *db = [[dbManager alloc] init];
    
    NSLocale *chinese = [NSLocale localeWithLocaleIdentifier:@"zh-CN"];
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    dateFormatter1.locale = chinese;
    dateFormatter1.dateFormat = DATEFORMAT;
    
    SSLunarDate *lunar = [[SSLunarDate alloc] initWithDate:date];
    
    NSDictionary *dictInfo = [[NSDictionary alloc] initWithObjectsAndKeys:
                              [utility getUserDefaultstoString:@"memberID"],@"user_id",
                              self.tf_name.text,@"name",
                              [utility getUserDefaultstoString:@"phone"],@"phone",
                              [utility getUserDefaultstoString:@"phoneAreaCode"],@"phoneAreaCode",
                              [dateFormatter1 stringFromDate:date],@"birthday",
                              [NSString stringWithFormat:@"%@ %@",[lunar string],[lunar zodiacString]],@"lunarBirthday",
                              @"",@"facebookID",
                              @"",@"friendList",
                              @"",@"backupPath",
                              ([utility getUserDefaultstoString:@"DeviceToken"]?[utility getUserDefaultstoString:@"DeviceToken"]:@"abc"),@"deviceToken",
                              @"iOS",@"deviceType",
                              @"userPic.png",@"imageName",
                              nil];
    
    NSMutableArray *imgAry = [[NSMutableArray alloc] init];
    if(self.originalImage != nil){
        NSDictionary *imageDict = [[NSDictionary alloc] initWithObjectsAndKeys:[[utilityManager alloc] getDataFilePath:@"userPic.jpeg" folderName:@"temp" isDoucmentFolder:NO],@"image",@"userPic.jpeg",@"imageName",@"imagefile",@"paramKey",nil];
        [imgAry addObject:imageDict];
    }
    
    [connect uploadRequest:SET_USER_INFO parameters:dictInfo images:imgAry completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            userObj *user = [[userObj alloc] initWithDict:jsonDict];
            NSLog(@"user:%@",user);
            [utility saveValuetoUserDefaults:[user toDict]];
            NSString *value = [NSString stringWithFormat:@"username='%@',mobile='%@',phoneAreaCode='%@',imagePath='%@',birthday='%@',lunarBirthday='%@',facebookID='%@',backupPath='%@',currentSize='%@'",user.username,user.mobile,user.phoneAreaCode,user.imagePath,user.birthday,user.lunarBirthday,user.facebookID,user.backupPath,user.currentSize];
            if([db updateSQL:@"tbl_userProfile" tCol:value tWhere:[NSString stringWithFormat:@"userID='%@'",[utility getUserDefaultstoString:@"memberID"]]]){
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
        }
    }];
}

-(IBAction)pressBtncalendar:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    popupCalendarViewController *vc = (popupCalendarViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"popupCalendarViewController"];
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    vc.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7f];
    vc.pre_view = self;
    [self presentViewController:vc animated:YES completion:^{
        if(self.currectDate != nil){
            vc.valueDate = self.currectDate;
            [vc updateCurrectDate];
        }
    }];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    self.originalImage = [UIImage fixrotation:[info objectForKey:UIImagePickerControllerOriginalImage]];
    self.iv_pic.image = [UIImage fixrotation:self.originalImage];
    NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
    if([[utilityManager alloc] saveDataFile:imageData Filename:@"userPic" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
    {
        NSData *imageData1 = [[utilityManager alloc] getDataFile:@"userPic.jpeg" folderName:@"temp" isDoucmentFolder:NO];
        self.iv_pic.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void) getUserInfo{
    userObj *user = (userObj*) self.record;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_IMAGE,user.imagePath]];
//    [self.iv_pic setImageWithURL:url placeholderImage:[UIImage imageNamed:@"sign_pic_none"]];
    self.iv_pic.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
    self.tf_name.text = user.username;
    [self.btn_dateDropdown setTitle:user.birthday forState:UIControlStateNormal];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}

@end
