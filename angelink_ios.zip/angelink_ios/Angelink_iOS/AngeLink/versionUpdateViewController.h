//
//  versionUpdateViewController.h
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface versionUpdateViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loadingBar;

@end
