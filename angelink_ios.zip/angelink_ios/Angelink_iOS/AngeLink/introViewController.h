//
//  introViewController.h
//  AngeLink
//
//  Created by kanhan on 11/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface introViewController : UIViewController
    @property (weak, nonatomic) IBOutlet UIScrollView *sv_img;
    @property (weak, nonatomic) IBOutlet UIButton *btn_start;
    @property (weak, nonatomic) IBOutlet UILabel *lbl_msg;
    @property (weak, nonatomic) IBOutlet UILabel *lbl_tittle;
    @property (weak, nonatomic) IBOutlet UIPageControl *pc_img;
@property (weak, nonatomic) IBOutlet UITextView *tv_intro;
    @property (nonatomic, retain) M13Checkbox *checkbox;



@end
