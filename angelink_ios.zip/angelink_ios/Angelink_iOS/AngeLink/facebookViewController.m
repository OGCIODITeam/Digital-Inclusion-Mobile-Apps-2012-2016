//
//  facebookViewController.m
//  AngeLink
//
//  Created by kanhan on 14/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "facebookViewController.h"
#import <FBSDKShareKit/FBSDKShareKit.h>

@interface facebookViewController ()

@end

@implementation facebookViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setFontUI];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"YES",@"register", nil];
    [[utilityManager alloc] saveValuetoUserDefaults:dict];
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_tittle.font = self.tv_description.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    self.lbl_tittle.text = @"Facebook用途";
    
    
    [self.btn_signFB.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_signFB setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

    [self.btn_skip.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_skip setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [self.btn_signFB setTitle:@"Facebook連結" forState:UIControlStateNormal];
    [self.btn_skip setTitle:@"略過" forState:UIControlStateNormal];
}

-(IBAction)pressBtnsigeFB:(id)sender{
    [[connectionManager alloc] loginFBisReadOnly:YES Controller:self completionHandler:^(bool success, NSDictionary *dict) {
        if ([FBSDKAccessToken currentAccessToken] ) {
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                     bundle: nil];
            
            UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
            [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
        }
    }];
}

-(void)fetchUserInfo
{
    if ([FBSDKAccessToken currentAccessToken])
    {
        utilityManager *utility = [[utilityManager alloc] init];
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"FBAccessToken",[[FBSDKAccessToken currentAccessToken] tokenString], nil];
        [utility saveValuetoUserDefaults:dict];

        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        
        UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
        [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"錯誤" message:@"連接到Facebook錯誤！" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
        [alert show];
    }
}

-(IBAction)pressBtnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)pressBtnskip:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}


@end
