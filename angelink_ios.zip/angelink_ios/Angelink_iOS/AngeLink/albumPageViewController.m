//
//  albumPageViewController.m
//  AngeLink
//
//  Created by kanhan on 22/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "albumPageViewController.h"
#import "albumObj.h"
#import "albumPageObj.h"
#import "albumPageTableViewCell.h"
#import "albumPagePreviewViewController.h"
#import "addPage1ViewController.h"
#import "addDefaultPageViewController.h"
#import "addPageImgViewController.h"
#import "addPageVideoViewController.h"

@interface albumPageViewController ()

@end

@implementation albumPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isEdit = false;
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = self.headerTitle;
    header.delegate = self;
    [self.view addSubview:header];
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    
    [self setViewUI];
    albumObj *obj = (albumObj *) self.albumObj;
    if([obj.userID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        self.btn_convertVideo.enabled = YES;
    }
    else{
        self.btn_vidoeShare.enabled = NO;
    }
    if(![obj.videoPath isEqualToString:@"(null)"] && ![obj.videoPath isEqualToString:@""]){
        self.btn_videoPlay.enabled = YES;
        self.btn_vidoeShare.enabled = YES;
    }
    else{
        self.btn_videoPlay.enabled = NO;
        self.btn_vidoeShare.enabled = NO;
    }
    
    self.tv_main.separatorColor = [UIColor clearColor];
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.2_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.2_2"];
    UIImage *img3 = [UIImage imageNamed:@"Book_6.2_3"];
    UIImage *img4 = [UIImage imageNamed:@"Book_6.2_4"];
    UIImage *img5 = [UIImage imageNamed:@"Book_6.2_5"];
    UIImage *img6 = [UIImage imageNamed:@"Book_6.2_6"];
    UIImage *img7 = [UIImage imageNamed:@"Book_6.2_7"];
    UIImage *img8 = [UIImage imageNamed:@"Book_6.2_8"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    [aryImg addObject:img4];
    [aryImg addObject:img5];
    [aryImg addObject:img6];
    [aryImg addObject:img7];
    [aryImg addObject:img8];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"把此人生紀念冊相簿製作成短片當短片製作完成後，系統會通知你";
    NSString *str2 = @"播放已製作之短片";
    NSString *str3 = @"在其他社交平台分享已製作之短片";
    NSString *str4 = @"讓至親及親友觀看此人生紀念冊相簿";
    NSString *str5 = @"只有自己才能看到此人生紀念冊相簿";
    NSString *str6 = @"逐頁觀看此人生紀念冊相簿";
    NSString *str7 = @"為此人生紀念冊相簿增加新頁";
    NSString *str8 = @"編輯此人生紀念冊相簿內容";
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    [aryString addObject:str4];
    [aryString addObject:str5];
    [aryString addObject:str6];
    [aryString addObject:str7];
    [aryString addObject:str8];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_videoPlay.isAccessibilityElement = true;
    self.btn_videoPlay.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_videoPlay.accessibilityLabel = @"視頻播放";
    
    self.btn_vidoeShare.isAccessibilityElement = true;
    self.btn_vidoeShare.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_vidoeShare.accessibilityLabel = @"視頻共享";
    
    self.btn_public.isAccessibilityElement = true;
    self.btn_public.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_public.accessibilityLabel = @"公開";
    
    self.btn_private.isAccessibilityElement = true;
    self.btn_private.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_private.accessibilityLabel = @"私人";
    
    self.btn_preview.isAccessibilityElement = true;
    self.btn_preview.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_preview.accessibilityLabel = @"預覽";
    
    self.btn_addPage.isAccessibilityElement = true;
    self.btn_addPage.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_addPage.accessibilityLabel = @"添加頁面";
    
    self.btn_editPage.isAccessibilityElement = true;
    self.btn_editPage.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_editPage.accessibilityLabel = @"編輯頁面";
    
    self.btn_convertVideo.isAccessibilityElement = true;
    self.btn_convertVideo.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_convertVideo.accessibilityLabel = @"製作短片";
    
    self.btn_StartPage.isAccessibilityElement = true;
    self.btn_StartPage.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_StartPage.accessibilityLabel = @"開始創建頁面";
}

-(void) viewWillAppear:(BOOL)animated{
    SDImageCache *imageCache = [SDImageCache sharedImageCache];
    [imageCache clearMemory];
    [imageCache clearDisk];
    [[[SDWebImageManager sharedManager] imageCache] clearDisk];
    [[[SDWebImageManager sharedManager] imageCache] clearMemory];
    self.isEdit = false;
    [self.btn_editPage setImage:[UIImage imageNamed:@"btn_edit_tri"] forState:UIControlStateNormal];
    [self getServerData];
    albumObj *obj = (albumObj *) self.albumObj;
    self.btn_private.selected = self.btn_public.selected = false;
    if([obj.public isEqualToString:@"0"]){
        self.btn_private.selected = TRUE;
    }
    if([obj.public isEqualToString:@"1"]){
        self.btn_public.selected = TRUE;
    }
}

-(void)getServerData{
    connectionManager *connect = [[connectionManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    self.btn_StartPage.hidden = YES;
    albumObj *obj = (albumObj*) self.albumObj;
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"SELECT_AL_PG",@"action",[utility getUserDefaultstoString:@"memberID"],@"user_id",obj.albumID,@"albumID", nil];
    [connect postRequestReturnArray:ALBUM_PAGE_HANDLER parameters:dict completionHandler:^(bool status , NSMutableArray *JsonArray) {
        if(status){
            if([obj.albumTitle isEqualToString:@"人生畢業禮"]){
                if([JsonArray count] > 0){
                    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"Y",@"closePopup", nil];
                    [[utilityManager alloc] saveValuetoUserDefaults:dict];
                }
            }
            [self.aryData removeAllObjects];
            if([JsonArray count] > 0){
                self.btn_public.enabled = self.btn_private.enabled = YES;
            }
            else if([obj.albumType isEqualToString:@"1"]){
                self.btn_public.enabled = self.btn_private.enabled = YES;
            }
            else{
                self.btn_public.enabled = self.btn_private.enabled = NO;
            }
            for(int i = 0;i<[JsonArray count];i++){
                albumPageObj *pobj = [[albumPageObj alloc] initWithDict:[JsonArray objectAtIndex:i]];
                if([pobj.pageStatus isEqualToString:@"P"]){
                    if([pobj.createByID isEqualToString:[utility getUserDefaultstoString:@"memberID"]]){
                        [self.aryData addObject:pobj];
                    }
                    else if([pobj.user_id isEqualToString:[utility getUserDefaultstoString:@"memberID"]]){
                        [self.aryData addObject:pobj];
                    }
                }
                else{
                    [self.aryData addObject:pobj];
                }
                [self.tv_main reloadData];
            }
            if([JsonArray count] < 1 && [obj.albumType isEqualToString:@"0"]){
                if([obj.userID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
                    self.btn_StartPage.hidden = NO;
                    if([obj.albumTitle isEqualToString:@"人生畢業禮"]){
                        NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"Y",@"closePopup", nil];
                        [[utilityManager alloc] saveValuetoUserDefaults:dict];
                    }
                }
                else{
                    self.btn_StartPage.hidden = YES;
                }
                self.btn_StartPage.center = self.tv_main.center;
            }
        }
    }];
}

-(void) setViewUI {
    fontManager *font = [[fontManager alloc] init];
    self.btn_convertVideo.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_convertVideo setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btn_convertVideo setTitle:@"製作短片" forState:UIControlStateNormal];
    self.btn_StartPage.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_StartPage setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btn_StartPage setTitle:@"開始" forState:UIControlStateNormal];
    [self.btn_videoPlay setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_vidoeShare setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_public setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_private setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_addPage setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_editPage setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_convertVideo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_StartPage setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnPlayVideo:(id)sender{
    albumObj *obj = (albumObj *) self.albumObj;
    if(![obj.videoPath isEqualToString:@"(null)"] && ![obj.videoPath isEqualToString:@""]){
        vc_PopupVideo *temp1 = [[vc_PopupVideo alloc] init];
        [self presentViewController:temp1 animated:FALSE completion:nil];
        temp1.url = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,obj.videoPath];
        [temp1 startup];
    }
    else{
        self.btn_videoPlay.enabled = NO;
    }
}

-(IBAction)pressBtnVideoShare:(id)sender{
    albumObj *obj = (albumObj *) self.albumObj;
    
    if([obj.userID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        if(![obj.shareKey isEqualToString:@"(null)"] && ![obj.shareKey isEqualToString:@""]){
            NSString *shareMessage = [NSString stringWithFormat:@"我與您分享我的 AngeLink 人生紀念冊 - [%@]\n%@/%@",obj.albumTitle,SERVER_USER_FOLDER,obj.shareKey];
            WhatsAppMessage *whatsappMsg = [[WhatsAppMessage alloc] initWithMessage:shareMessage forABID:shareMessage];
            NSArray *applicationActivities = @[[[JBWhatsAppActivity alloc] init]];
            NSArray *excludedActivities    = @[UIActivityTypePrint, UIActivityTypePostToWeibo, UIActivityTypeMessage];
            NSArray *activityItems         = @[shareMessage, whatsappMsg];
            UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:applicationActivities];
            activityViewController.excludedActivityTypes = excludedActivities;
            [self presentViewController:activityViewController animated:YES completion:^{
                
            }];
            [self getServerData];
        }
    }
}

-(IBAction)pressBtnSelPublic:(id)sender{
    if(self.btn_public.selected == true){
        self.btn_public.selected = self.btn_private.selected = NO;
        self.btn_private.selected = YES;
        self.isPublic = NO;
    }
    else{
        self.btn_public.selected = self.btn_private.selected = NO;
        self.btn_public.selected = YES;
        self.isPublic = YES;
    }
}

-(IBAction)pressBtnStartPage:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    addDefaultPageViewController *vc = (addDefaultPageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addDefaultPageViewController"];
    vc.headerTitle = self.headerTitle;
    vc.record = self.albumObj;
    [self.navigationController pushViewController:vc animated:YES];
    //    [self presentViewController:vc animated:YES completion:^{}];
}

-(IBAction)pressBtnPreview:(id)sender{
    NSMutableArray *successAry = [NSMutableArray new];
    for(int i = 0; i <[self.aryData count];i++){
        albumPageObj *obj = [self.aryData objectAtIndex:i];
        if([obj.pageStatus isEqualToString:@"S"])
        {
            [successAry addObject:obj];
        }
    }
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    albumPagePreviewViewController *vc = (albumPagePreviewViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"albumPagePreviewViewController"];
    vc.headerTitle = self.headerTitle;
    vc.aryData = successAry;
    [self.navigationController pushViewController:vc animated:YES];
}

-(IBAction)pressBtnAddPage:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    addPage1ViewController *vc = (addPage1ViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPage1ViewController"];
    vc.headerTitle = @"新増頁";
    vc.record = self.albumObj;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [self presentViewController:nav animated:YES completion:^{
        
    }];
    //    [self.navigationController pushViewController:vc animated:YES];
}

-(IBAction)pressBtnEditPage:(id)sender{
    if(self.isEdit){
        self.isEdit = false;
        [self.btn_editPage setImage:[UIImage imageNamed:@"btn_edit_tri"] forState:UIControlStateNormal];
    }
    else{
        self.isEdit = true;
        [self.btn_editPage setImage:[UIImage imageNamed:@"btn_tickr_tri"] forState:UIControlStateNormal];
    }
    [self.tv_main reloadData];
}

-(IBAction)pressBtnDelRow:(id)sender{
    connectionManager *connect = [[connectionManager alloc] init];
    UIButton *btn = (UIButton*)sender;
    albumPageObj *obj = [self.aryData objectAtIndex:btn.tag];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:obj.pageID,@"albumPageID",@"D",@"pageStatus", nil];
    [connect postRequest:ALBUM_PAGE_STATUS parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            if([[[dict objectForKey:@"status"] lowercaseString] isEqualToString:@"fail"]){
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
            }
            else{
                self.isEdit = false;
                [self.btn_editPage setImage:[UIImage imageNamed:@"btn_edit_tri"] forState:UIControlStateNormal];
                [self getServerData];
            }
        }        
    }];
}

-(IBAction)pressBtnEditRow:(id)sender{
    UIButton *btn = (UIButton*)sender;
    albumObj *objAlbum = (albumObj*) self.albumObj;
    albumPageObj *objAlbumPage = [self.aryData objectAtIndex:btn.tag];
    if([objAlbum.albumType isEqualToString:@"0"]){
        if([objAlbumPage.pageType isEqualToString:@"0"]){
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
            addPageImgViewController *vc = (addPageImgViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPageImgViewController"];
            vc.headerTitle = self.headerTitle;
            vc.record = self.albumObj;
            vc.pageRecord = objAlbumPage;
            //            [self.navigationController pushViewController:vc animated:YES];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
        else if([objAlbumPage.pageType isEqualToString:@"1"]){
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
            addPageVideoViewController *vc = (addPageVideoViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPageVideoViewController"];
            vc.headerTitle = self.headerTitle;
            vc.record = self.albumObj;
            vc.pageRecord = objAlbumPage;
            //            [self.navigationController pushViewController:vc animated:YES];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
        else if([objAlbumPage.pageType isEqualToString:@"2"]){
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
            addDefaultPageViewController *vc = (addDefaultPageViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addDefaultPageViewController"];
            vc.headerTitle = self.headerTitle;
            vc.record = self.albumObj;
            vc.pageRecord = objAlbumPage;
            vc.pageTitle = objAlbumPage.pageTitle;
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
    else{
        if([objAlbumPage.pageType isEqualToString:@"0"]){
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
            addPageImgViewController *vc = (addPageImgViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPageImgViewController"];
            vc.headerTitle = self.headerTitle;
            vc.record = self.albumObj;
            vc.pageRecord = objAlbumPage;
            //            [self.navigationController pushViewController:vc animated:YES];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
        else if([objAlbumPage.pageType isEqualToString:@"1"]){
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
            addPageVideoViewController *vc = (addPageVideoViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"addPageVideoViewController"];
            vc.headerTitle = self.headerTitle;
            vc.record = self.albumObj;
            vc.pageRecord = objAlbumPage;
            //            [self.navigationController pushViewController:vc animated:YES];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
    }
    
}

-(IBAction)pressBtnConvertVideo:(id)sender{
    albumObj *obj = (albumObj*) self.albumObj;
    if([obj.userID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
        hud.mode = MBProgressHUDModeIndeterminate;
        hud.square = YES;
        hud.label.text = NSLocalizedString(@"Loading", @"Loading");
        [hud showAnimated:YES];
        
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:obj.userID,@"user_id",obj.albumID,@"albumID", nil];
        [[connectionManager alloc] postRequest:REQUEST_VIDEO parameters:dict completionHandler:^(bool status , NSDictionary *jsonDict) {
            [hud hideAnimated:YES];
            self.btn_videoPlay.enabled = NO;
            self.btn_vidoeShare.enabled = NO;
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"當短片完成製作後，客戶會收到通知。" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
        }];
    }
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.aryData count];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"albumPageTableViewCell";
    fontManager *font = [[fontManager alloc] init];
    albumObj *objAlbum = (albumObj*) self.albumObj;
    albumPageTableViewCell* cell = (albumPageTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    cell = nil;
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    }
    albumPageObj *obj = [self.aryData objectAtIndex:indexPath.row];
    if(self.isEdit){
        if([obj.createByID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
            cell.btn_edit.hidden = NO;
            cell.btn_edit.isAccessibilityElement = true;
            cell.btn_edit.accessibilityTraits = UIAccessibilityTraitNone;
            cell.btn_edit.accessibilityLabel = @"編輯";

            cell.btn_edit.tag = indexPath.row;
            [cell.btn_edit addTarget:self action:@selector(pressBtnEditRow:) forControlEvents:UIControlEventTouchUpInside];
            if([obj.pageType intValue] < 2){
                cell.btn_del.hidden = NO;
                cell.btn_del.tag = indexPath.row;
                cell.btn_del.isAccessibilityElement = true;
                cell.btn_del.accessibilityTraits = UIAccessibilityTraitNone;
                cell.btn_del.accessibilityLabel = @"刪除";
                [cell.btn_del addTarget:self action:@selector(pressBtnDelRow:) forControlEvents:UIControlEventTouchUpInside];
            }
        }
    }
    else{
        cell.btn_edit.hidden = YES;
        cell.btn_del.hidden = YES;
    }
    cell.v_body.layer.cornerRadius=8.0f;
    cell.v_body.layer.masksToBounds=YES;
    cell.v_body.layer.borderColor=[[UIColor colorWithRed:128.0/255.0 green:83.0/255.0 blue:85.0/255.0 alpha:1.0] CGColor];
    cell.v_body.layer.borderWidth= 0.0f;
    
    cell.lbl_Title.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    cell.lbl_Title.lineBreakMode = LINE_BREAK_WORD_WRAP;
    cell.lbl_Title.numberOfLines = 2;
    
    cell.lbl_Title.text = obj.pageTitle;
    if([obj.user_id isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        if([[obj.pageStatus uppercaseString] isEqualToString:@"P"] && ![obj.createByID isEqualToString:obj.user_id]){
            cell.btn_accupt.hidden = NO;
            cell.btn_reject.hidden = NO;
            cell.btn_accupt.tag = indexPath.row;
            cell.btn_reject.tag = indexPath.row;
            [cell.btn_accupt addTarget:self action:@selector(pressBtnaccept:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btn_reject addTarget:self action:@selector(pressBtnreject:) forControlEvents:UIControlEventTouchUpInside];
        }
        else{
            cell.btn_accupt.hidden = YES;
            cell.btn_reject.hidden = YES;
        }
    }
    else{
        cell.btn_accupt.hidden = YES;
        cell.btn_reject.hidden = YES;
    }
    if(![obj.videoPath isEqualToString:@""]){
        NSString *str = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,obj.videoThumb];
        [cell.iv_page sd_setImageWithURL:[NSURL URLWithString:str] placeholderImage:nil];
    }
    else{
        NSString *str = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,obj.displayImage];
        [cell.iv_page sd_setImageWithURL:[NSURL URLWithString:str] placeholderImage:nil];
    }
    if([obj.pageStatus isEqualToString:@"P"]){
        [cell.v_body setBackgroundColor:[UIColor colorWithRed:255.0/255.0f green:165.0/255.0f blue:169.0/255.0f alpha:1.0]];
        cell.v_body.layer.borderWidth= 1.0f;
    }
    else{
        [cell.v_body setBackgroundColor:[UIColor whiteColor]];
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

-(IBAction)pressBtnpublic:(id)sender{
    albumObj *objAlbum = (albumObj*) self.albumObj;
    if([objAlbum.userID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        self.btn_public.selected = self.btn_private.selected = false;
        UIButton *btn = (UIButton*)sender;
        btn.selected = TRUE;
        connectionManager *connect = [[connectionManager alloc] init];
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_PUBLIC",@"action",objAlbum.userID,@"user_id",objAlbum.albumID,@"albumID",@"1",@"public", nil];
        [connect postRequest:ALBUM_HANDLER parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                
            }
        }];
    }
    else{
        
    }
}

-(IBAction)pressBtnpervate:(id)sender{
    albumObj *objAlbum = (albumObj*) self.albumObj;
    if([objAlbum.userID isEqualToString:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]){
        self.btn_public.selected = self.btn_private.selected = false;
        UIButton *btn = (UIButton*)sender;
        btn.selected = TRUE;
        connectionManager *connect = [[connectionManager alloc] init];
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_PUBLIC",@"action",objAlbum.userID,@"user_id",objAlbum.albumID,@"albumID",@"0",@"public", nil];
        [connect postRequest:ALBUM_HANDLER parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                
            }
        }];
    }
    else{
        
    }
}

-(IBAction)pressBtnaccept:(id)sender{
    connectionManager *connect = [[connectionManager alloc] init];
    UIButton *btn = (UIButton*)sender;
    albumPageObj *obj = [self.aryData objectAtIndex:btn.tag];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:obj.pageID,@"albumPageID",@"S",@"pageStatus", nil];
    [connect postRequest:ALBUM_PAGE_STATUS parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            if([[[dict objectForKey:@"status"] lowercaseString] isEqualToString:@"fail"]){
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
            }
        }
        [self getServerData];
    }];
}

-(IBAction)pressBtnreject:(id)sender{
    connectionManager *connect = [[connectionManager alloc] init];
    UIButton *btn = (UIButton*)sender;
    albumPageObj *obj = [self.aryData objectAtIndex:btn.tag];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:obj.pageID,@"albumPageID",@"R",@"pageStatus", nil];
    [connect postRequest:ALBUM_PAGE_STATUS parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status){
            if([[[dict objectForKey:@"status"] lowercaseString] isEqualToString:@"fail"]){
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
            }
        }
        [self getServerData];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
