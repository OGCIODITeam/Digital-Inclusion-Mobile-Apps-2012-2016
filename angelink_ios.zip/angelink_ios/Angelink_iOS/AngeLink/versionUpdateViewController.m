//
//  versionUpdateViewController.m
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "versionUpdateViewController.h"
#import "AppDelegate.h"

@interface versionUpdateViewController ()

@end

@implementation versionUpdateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    CGAffineTransform transform = CGAffineTransformMakeScale(3.0f, 3.0f);
    self.loadingBar.transform = transform;
    [self.loadingBar startAnimating];

    //    NSProcessInfo *processInfo = [NSProcessInfo processInfo];
//    NSString *processName = [processInfo processName];
//    int processID = [processInfo processIdentifier];
//    NSString *reqSysVer = @"3.1";
//    NSString *currSysVer = [[UIDevice currentDevice] systemVersion];
//    
//    NSLog(@"currSysVer:%@",currSysVer);

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        utilityManager *utility = [[utilityManager alloc] init];
        if([[utility getUserDefaultstoString:@"skipIntroPage"] isEqualToString:@"YES"]){
            [self mainPage];
        }
        else{
            UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"introViewController"];
            [[UIApplication sharedApplication].keyWindow setRootViewController:vc];
        }
    });
}

-(void) mainPage{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ViewController"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [[UIApplication sharedApplication].keyWindow setRootViewController:nav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
