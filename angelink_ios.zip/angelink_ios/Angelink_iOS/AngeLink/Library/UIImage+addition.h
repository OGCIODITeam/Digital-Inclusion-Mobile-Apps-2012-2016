//
//  UIImage+addition.h
//  AngeLink
//
//  Created by kanhan on 15/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (CalculatedSize)
+ (UIImage *) imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;
+ (NSString *) contentTypeForImageData:(NSData *)data;
+ (NSString *)extensionForImageData:(NSData *)data;
+ (NSString *) encodeImageToBase64String:(UIImage *)image;
+ (NSData *) convertImageToNSData:(UIImage*)image;
+ (NSData *) convertImageToPNG:(UIImage*)image;
+ (NSData *) convertImageToJPEG:(UIImage*)image;
+ (NSData *) convertImageToLowJPEG:(UIImage*)image;
+ (UIImage *)fixrotation:(UIImage *)image;

- (NSUInteger)calculatedSize;
@end
