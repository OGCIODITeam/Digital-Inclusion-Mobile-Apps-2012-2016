//
//  lunarManager.h
//  chinese-lunar
//
//  Created by kanhan on 7/7/2016.
//  Copyright © 2016 LC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface lunarManager : NSObject
+(lunarManager *) defaultManager;

-(NSMutableArray*) _expression:(NSString*) expr;

@end
