//
//  vc_PopupVideo.h
//  BeaconAppProject
//
//  Created by jacky chan on 13/7/21.
//
//

#import "common.h"

@interface vc_PopupVideo : UIViewController<UIAlertViewDelegate>{
    NSString *url,*btn_title;
    MPMoviePlayerViewController* mvp;
    UIActivityIndicatorView *ua_loading;
    IBOutlet UIButton *btn_close;
    IBOutlet UIButton *btn_download;
    BOOL *isloading;
}
@property(nonatomic, retain) NSString *url,*btn_title;
@property(nonatomic, retain) IBOutlet UIButton *btn_close;
@property(nonatomic, retain) IBOutlet UIButton *btn_download;
@property(nonatomic, retain) UIActivityIndicatorView *ua_loading;
@property(nonatomic, retain) NSString *path;

-(void) startLoading;
-(void) endLoading;
-(void) startup;


@end
