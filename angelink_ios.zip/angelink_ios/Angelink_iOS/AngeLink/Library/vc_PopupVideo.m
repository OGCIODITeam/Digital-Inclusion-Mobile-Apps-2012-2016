//
//  vc_PopupVideo.m
//  BeaconAppProject
//
//  Created by jacky chan on 13/7/21.
//
//

#import "vc_PopupVideo.h"

@interface vc_PopupVideo ()

@end

@implementation vc_PopupVideo
@synthesize url,btn_title;
@synthesize ua_loading;
@synthesize btn_close;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        btn_title = @"關閉";
        isloading = FALSE;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view setBackgroundColor:[UIColor clearColor]];
}

-(void) viewDidUnload{
    mvp = nil;
}

-(void) dealloc{
    mvp = nil;
}

-(void)startup{
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
    [self.view setBackgroundColor:[UIColor blackColor]];
    utilityManager *utility = [[utilityManager alloc] init];
    self.view.frame = CGRectMake(0, 0, [utility getScreenSize].size.width,[utility getScreenSize].size.height);
    [self createBtnClose];

    self.path = @"";
    
    NSString *filename = [[[NSURL URLWithString:url] absoluteString] lastPathComponent];
    
    NSString* documentsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    filename = [filename stringByReplacingOccurrencesOfString:@"%20" withString:@" "];
    
    NSString* foofile = [documentsPath stringByAppendingPathComponent:filename];
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:foofile];
    if(!fileExists){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"注意" message:@"觀看視頻可能會消耗大量的移動數據。" delegate:self cancelButtonTitle:@"退出" otherButtonTitles: @"了解", nil];
        alert.delegate = self;
        [alert show];
    }
    else{
       [self videoPlayer:foofile];
    }
}

-(void) connectToVideo{
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    self.path = @"";
    
    NSString *filename = self.url;
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:filename];
    if(!fileExists){
        NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //Update the progress view
                //            [_myProgressView setProgress:downloadProgress.fractionCompleted];
                
            });
        } destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
            NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
            self.path = [[documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]] path];
            return [documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]];
        } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
            // Do operation after download is complete
            if(error){
                NSLog(@"Error: %@", error);
            }
            else{
                [self videoPlayer:self.path];
            }
        }];
        [downloadTask resume];
        [self startLoading];
    }
    else{
        [self videoPlayer:filename];
    }
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0){
        [self pressClose:nil];
    }
    else if (buttonIndex == 1){
        [self connectToVideo];
    }
}

-(void) videoPlayer:(NSString *) Path{
    NSLog(@"Path1:%@",Path);
    mvp = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:Path]];
    mvp.view.frame = CGRectMake(0, 0, self.view.frame.size.height,self.view.frame.size.width);
    //    mvp.view.center = self.view.center;
    mvp.view.transform = CGAffineTransformMakeRotation(M_PI / 2);
    mvp.view.center = self.view.center;
    [self.view addSubview:mvp.view];
    mvp.moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
    [mvp.moviePlayer.backgroundView setBackgroundColor:[UIColor clearColor]];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(MovieLoadingFinishedCallback:) name:MPMoviePlayerLoadStateDidChangeNotification object:mvp.moviePlayer];
    [self.view bringSubviewToFront:btn_close];
    [self.view bringSubviewToFront:btn_download];
    mvp.moviePlayer.scalingMode = MPMovieScalingModeAspectFit;
    [mvp.moviePlayer prepareToPlay];
    [mvp.moviePlayer play];
}

-(CGRect)getResizedVideoFrame:(CGRect )naturalSize andPlayerViewSize:(CGRect)playerSize {
    float resVi = naturalSize.size.width / naturalSize.size.height;
    float resPl = playerSize.size.width / playerSize.size.height;
    return (resPl > resVi ? CGRectMake(0, 0, naturalSize.size.width * playerSize.size.height/naturalSize.size.height, playerSize.size.height) : CGRectMake(0, 0,playerSize.size.width, naturalSize.size.height * playerSize.size.width/naturalSize.size.width));
}

-(void) createBtnClose{
    btn_close = [UIButton buttonWithType:UIButtonTypeCustom];
    btn_close.frame = CGRectMake(self.view.frame.size.width - 90, self.view.frame.size.height - 80, 70, 65);
    [btn_close setBackgroundColor:[UIColor clearColor]];
    [btn_close setImage:[UIImage imageNamed:@"btn_x_S"] forState:UIControlStateNormal];
    [btn_close setBackgroundColor:[UIColor clearColor]];
    [btn_close addTarget:self action:@selector(pressClose:) forControlEvents:UIControlEventTouchUpInside];
    btn_close.transform = CGAffineTransformMakeRotation(M_PI / 2);
    
    btn_close.isAccessibilityElement = true;
    btn_close.accessibilityTraits = UIAccessibilityTraitNone;
    btn_close.accessibilityLabel = @"關閉";

    [self.view addSubview:btn_close];
    [self.view bringSubviewToFront:btn_close];
    btn_download = [UIButton buttonWithType:UIButtonTypeCustom];
    btn_download.frame = CGRectMake(btn_close.frame.origin.x - 90, self.view.frame.size.height - 80, 70, 70);
    [btn_download setBackgroundColor:[UIColor clearColor]];
    [btn_download setImage:[UIImage imageNamed:@"btn_download_S"] forState:UIControlStateNormal];
    [btn_download setBackgroundColor:[UIColor clearColor]];
    [btn_download addTarget:self action:@selector(pressDownload:) forControlEvents:UIControlEventTouchUpInside];
    btn_download.transform = CGAffineTransformMakeRotation(M_PI / 2);
    
    btn_download.isAccessibilityElement = true;
    btn_download.accessibilityTraits = UIAccessibilityTraitNone;
    btn_download.accessibilityLabel = @"下載";
    
    [self.view addSubview:btn_download];
    [self.view bringSubviewToFront:btn_download];
    
}

- (void)movieEventFullscreenHandler:(NSNotification*)notification {
    //    [mvp.moviePlayer setFullscreen:YES animated:NO];
    //    [mvp.moviePlayer setControlStyle:MPMovieControlStyleFullscreen];
}
- (void)MovieLoadingFinishedCallback:(NSNotification *)notification {
    MPMoviePlayerController *player = notification.object;
    if (player.loadState & MPMovieLoadStatePlayable)
    {
        [self endLoading];
        //        [player play];
    }
}

-(void) startLoading{
    ua_loading = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    ua_loading.center = self.view.center;
    [ua_loading setHidesWhenStopped:NO];
    [ua_loading setActivityIndicatorViewStyle: UIActivityIndicatorViewStyleWhite];
    [self.view addSubview:ua_loading];
    [ua_loading startAnimating];
    isloading = TRUE;
}

-(void) endLoading{
    if(isloading)
    {
        [ua_loading stopAnimating];
        //        [mvp.moviePlayer play];
        [ua_loading removeFromSuperview];
        isloading = FALSE;
    }
}

-(IBAction)pressClose:(id)sender{
    [mvp.moviePlayer stop];
//    mvp = nil;
    [self dismissModalViewControllerAnimated:YES];
}

-(IBAction)pressDownload:(id)sender{
    NSURL *videoUrl = [NSURL URLWithString:self.url];
    
    dispatch_queue_t q = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
    dispatch_async(q, ^{
        
        NSData *videoData = [NSData dataWithContentsOfURL:videoUrl];
        dispatch_async(dispatch_get_main_queue(), ^{
            // Write it to cache directory
            NSString *videoPath = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[[utilityManager alloc] filename:self.url]];
            [videoData writeToFile:videoPath atomically:YES];
            // After that use this path to save it to PhotoLibrary
            ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
            [library writeVideoAtPathToSavedPhotosAlbum:[NSURL fileURLWithPath:videoPath] completionBlock:^(NSURL *assetURL, NSError *error)
             {
                 if (error)
                 {
                     NSLog(@"Error");
                     UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"下載並保存錯誤" delegate:nil cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                     [UIView beginAnimations:@"" context:nil];
                     [UIView setAnimationDuration:0.1];
                     alert.transform = CGAffineTransformRotate(alert.transform, M_PI / 2);
                     [UIView commitAnimations];
                     [alert show];
                 }
                 else
                 {
                     NSLog(@"Success");
                     UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"下載並保存成功" delegate:nil cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                     [UIView beginAnimations:@"" context:nil];
                     [UIView setAnimationDuration:0.1];
                     alert.transform = CGAffineTransformRotate(alert.transform, M_PI / 2);
                     [UIView commitAnimations];
                     [alert show];
                 }
                 
             }];
        });
    });
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
