//
//  settingViewController.h
//  AngeLink
//
//  Created by kanhan on 17/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface settingViewController : UIViewController<headerBarViewDelegate,CLLocationManagerDelegate,infoViewDelegate>{
CLLocationManager* locationManager;
}
@property (weak, nonatomic) IBOutlet UIScrollView *sv_main;
@property (weak, nonatomic) IBOutlet UIImageView *iv_img;
@property (weak, nonatomic) IBOutlet UILabel *lbl_backupStatus;
@property (weak, nonatomic) IBOutlet UILabel *lbl_username;

@property (weak, nonatomic) IBOutlet UIButton *btn_edit;
@property (weak, nonatomic) IBOutlet UIButton *btn_fb_login;
@property (weak, nonatomic) IBOutlet UIButton *btn_backup;
@property (weak, nonatomic) IBOutlet UIButton *btn_autoUpload;
@property (weak, nonatomic) IBOutlet UIButton *sel_dropdown;
@property (weak, nonatomic) IBOutlet UIButton *btn_notice;
@property (weak, nonatomic) IBOutlet UIButton *btn_about;
@property (weak, nonatomic) IBOutlet UIButton *btn_contact;
@property (weak, nonatomic) IBOutlet UIButton *btn_poicy;
@property (weak, nonatomic) IBOutlet UIButton *btn_suggest;
@property (weak, nonatomic) IBOutlet UIButton *btn_GPS;
@property (weak, nonatomic) IBOutlet UIView *v_fontSize;
@property (weak, nonatomic) IBOutlet UISlider *slideSize;

@property (weak, nonatomic) IBOutlet UIView *v_profile;
@property (nonatomic, retain) infoView *info;
@end
