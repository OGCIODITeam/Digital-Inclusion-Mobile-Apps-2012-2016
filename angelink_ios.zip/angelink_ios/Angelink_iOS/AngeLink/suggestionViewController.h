//
//  suggestionViewController.h
//  AngeLink
//
//  Created by kanhan on 21/12/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"

@interface suggestionViewController : UIViewController<headerBarViewDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextView *lbl_Username;
@property (weak, nonatomic) IBOutlet UITextView *tv_message;
@property (weak, nonatomic) IBOutlet UIButton *btn_cancel;
@property (weak, nonatomic) IBOutlet UIButton *btn_send;
@property (weak, nonatomic) IBOutlet UIScrollView *sv_main;
@property (weak, nonatomic) IBOutlet UITextField *tf_email;
@end
