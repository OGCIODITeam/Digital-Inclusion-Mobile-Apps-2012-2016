//
//  registerStep4ViewController.h
//  AngeLink
//
//  Created by kanhan on 3/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface registerStep4ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lbl_Tittle;
@property (weak, nonatomic) IBOutlet UIButton *btn_selectAll;
@property (weak, nonatomic) IBOutlet UILabel *lbl_selectAllTittle;
@property (weak, nonatomic) IBOutlet UIButton *btn_cusSelect;

-(void) callBackFunction;
@end
