//
//  pushViewController.m
//  AngeLink
//
//  Created by kanhan on 14/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "pushViewController.h"
#import "registerStep4ViewController.h"
#import "pushObject.h"

@interface pushViewController ()

@end

@implementation pushViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.delegate = self;
    [self.view addSubview:header];
    self.tv_main.separatorColor = [UIColor clearColor];
//    [self getPushString];
    [self getPushList];
}

-(void)getPushList{
//    GET_PUSH_LIST
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id", nil];
    [[connectionManager alloc] postRequestReturnArray:GET_PUSH_LIST parameters:dict completionHandler:^(bool status, NSMutableArray *ary) {
        if(status)
        {
            if(self.aryData == nil){
                self.aryData = [NSMutableArray new];
            }
            else{
                [self.aryData removeAllObjects];
            }
            for(int i =0; i<[ary count];i++){
                pushObject *obj = [[pushObject alloc] initWithDict:[ary objectAtIndex:i]];
                [self.aryData addObject:obj];
            }
            [self.tv_main reloadData];
        }
    }];    
}

-(void)updateUserPushRecord:(void (^)(bool))completionBlock{
    connectionManager *connect = [[connectionManager alloc] init];
    NSMutableArray *ary = [NSMutableArray new];
    for(int i = 0;i<[self.aryData count];i++){
        pushObject *obj = [self.aryData objectAtIndex:i];
        [obj updateUserid:[[utilityManager alloc] getUserDefaultstoString:@"memberID"]];
//        NSDictionary *dict = [obj toSetting];
        [ary addObject:[obj toSetting]];
    }
    [connect postArrayReturnArray:SET_USER_PUSH parameters:ary completionHandler:^(bool status, NSMutableArray *aryData) {
        if(status){
            completionBlock(YES);
        }
        else{
            completionBlock(NO);
        }
    }];
}

-(void)pressBtnback:(id)sender{
    [self updateUserPushRecord:^(bool status) {
        if([self.preView isKindOfClass:[registerStep4ViewController class]]){
            [self dismissViewControllerAnimated:YES
                                     completion:^{
                                         registerStep4ViewController *temp = (registerStep4ViewController*) self.preView;
                                         [temp callBackFunction];
                                     }];
        }
        else{
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
}

-(void)pressBtninfo:(id)sender{
    NSLog(@"press btn info");
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.aryData count];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"pushTableViewCell";
//    [self getPushString];
    fontManager *font = [[fontManager alloc] init];
    pushTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if(!cell){
        [tableView registerNib:[UINib nibWithNibName:simpleTableIdentifier bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    }
    pushObject *obj = [self.aryData objectAtIndex:indexPath.row];
    cell.v_bg.layer.cornerRadius=8.0f;
    cell.v_bg.layer.masksToBounds=YES;
    cell.v_bg.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    cell.v_bg.layer.borderWidth= 3.0f;
    cell.lbl_title.lineBreakMode = LINE_BREAK_WORD_WRAP;
    cell.lbl_title.numberOfLines = 2;
    cell.lbl_title.font = [font getRegularsize:[font getMiddleContact]];
    cell.lbl_title.text = obj.nameTC;
//    NSLog(@"%d, value:%@",indexPath.row,[[utilityManager alloc] getCharByString:self.pushString range:indexPath.row limit:1]);
    if(obj.enable)
    {
        cell.isON = true;
    }
    else{
        cell.isON = false;
    }
    if(cell.isON){
        [cell.btn_onoff setImage:[UIImage imageNamed:@"btn_on"] forState:UIControlStateNormal];
    }
    else{
        [cell.btn_onoff setImage:[UIImage imageNamed:@"btn_off"] forState:UIControlStateNormal];
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    [cell.btn_onoff addTarget:self action:@selector(pressBtnOnOff:) forControlEvents:UIControlEventTouchUpInside];
    cell.btn_onoff.tag = indexPath.row;
    return cell;
}

-(IBAction)pressBtnOnOff:(id)sender{
    UIButton *btn = (UIButton*)sender;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:btn.tag inSection:0] ;
    pushTableViewCell *cell = [self.tv_main cellForRowAtIndexPath:indexPath];
    pushObject *obj = [self.aryData objectAtIndex:indexPath.row];
    if(obj.enable){
        [obj updateEnable:FALSE];
    }
    else{
        [obj updateEnable:TRUE];
    }
    if(obj.enable){
        [cell.btn_onoff setImage:[UIImage imageNamed:@"btn_on"] forState:UIControlStateNormal];
    }
    else{
        [cell.btn_onoff setImage:[UIImage imageNamed:@"btn_off"] forState:UIControlStateNormal];
    }
//    [self setPushString];
    [self.tv_main reloadData];
}

//-(void) setPushString{
//    self.pushString = @"";
//    for(int i =0; i< [self.aryData count];i++){
//        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:0];
//        pushTableViewCell *cell = [self.tv_main cellForRowAtIndexPath:indexPath];
//        if(cell.isON)
//        {
//            self.pushString = [NSString stringWithFormat:@"%@%@",self.pushString,@"1"];
//        }
//        else{
//            self.pushString = [NSString stringWithFormat:@"%@%@",self.pushString,@"0"];
//        }
//    }
//    NSLog(@"pushString:%@",self.pushString);
//    dbManager *db = [[dbManager alloc] init];
//    [db updateSQL:@"tbl_userProfile" tCol:[NSString stringWithFormat:@"pushNotification='%@'",[[utilityManager alloc] convertBinaryStringToDecimalNumber:self.pushString]] tWhere:[NSString stringWithFormat:@"userID='%@'",[[utilityManager alloc] getUserDefaultstoString:@"memberID"]]];
//}
//
//-(void) getPushString{
//    dbManager *db = [[dbManager alloc] init];
//    utilityManager *utility = [[utilityManager alloc] init];
//    NSMutableArray *ary = [db selectSQL:@"tbl_userProfile" where:[NSString stringWithFormat:@"userID='%@'",[utility getUserDefaultstoString:@"memberID"]] option:@""];
//    NSDictionary *dict = [ary objectAtIndex:0];
//    NSLog(@"%@",[utility convertDecimalNumberToBinaryString: [[dict objectForKey:@"pushNotification"] integerValue]]);
//    if([utility convertDecimalNumberToBinaryString: [[dict objectForKey:@"pushNotification"] isEqualToString:@""]]){
//        self.pushString = @"00000000";
//    }
//    else{
//        self.pushString = [utility convertDecimalNumberToBinaryString: [[dict objectForKey:@"pushNotification"] integerValue]];
//    }
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
