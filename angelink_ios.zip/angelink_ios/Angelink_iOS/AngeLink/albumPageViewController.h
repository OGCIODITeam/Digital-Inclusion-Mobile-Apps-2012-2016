//
//  albumPageViewController.h
//  AngeLink
//
//  Created by kanhan on 22/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface albumPageViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,headerBarViewDelegate,infoViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tv_main;

@property (weak, nonatomic) IBOutlet UIButton *btn_videoPlay;
@property (weak, nonatomic) IBOutlet UIButton *btn_vidoeShare;
@property (weak, nonatomic) IBOutlet UIButton *btn_public;
@property (weak, nonatomic) IBOutlet UIButton *btn_private;
@property (weak, nonatomic) IBOutlet UIButton *btn_preview;
@property (weak, nonatomic) IBOutlet UIButton *btn_addPage;
@property (weak, nonatomic) IBOutlet UIButton *btn_editPage;
@property (weak, nonatomic) IBOutlet UIButton *btn_convertVideo;
@property (weak, nonatomic) IBOutlet UIButton *btn_StartPage;

@property (nonatomic, retain) NSMutableArray *aryData;
@property (nonatomic, retain) NSString *headerTitle;
@property (nonatomic, assign) BOOL isPublic,isEdit;
@property (nonatomic, retain) NSObject *albumObj;
@property (nonatomic, retain) UIAlertView *alertView;

@property (nonatomic, retain) infoView *info;


@end
