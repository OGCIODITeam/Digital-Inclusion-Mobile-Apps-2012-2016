//
//  popupCalendarViewController.m
//  AngeLink
//
//  Created by kanhan on 12/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "popupCalendarViewController.h"
#import "AppDelegate.h"
#import "registerStep3ViewController.h"
#import "addDefaultPageViewController.h"
#import "infoViewController.h"
@interface popupCalendarViewController ()

@end

@implementation popupCalendarViewController

- (void)viewDidLoad {
    utilityManager *utility = [[utilityManager alloc] init];
    fontManager *font = [[fontManager alloc] init];
    self.aryYear = [NSMutableArray new];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.v_calendar = [[FSCalendar alloc] initWithFrame:CGRectMake(0, 0, self.v_body.frame.size.width - 10, 300)];
    self.v_calendar.dataSource = self;
    self.v_calendar.delegate = self;
    
    self.v_calendar.center = CGPointMake(self.v_body.frame.size.width/2, self.v_body.frame.size.height/2);
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, self.v_calendar.frame.size.width, 50);
    [btn addTarget:self action:@selector(pressBtnYear:) forControlEvents:UIControlEventTouchUpInside];
    [self.v_calendar addSubview:btn];
    [self.v_body addSubview:self.v_calendar];
    [self.v_calendar setBackgroundColor:[UIColor whiteColor]];
    
    self.v_body.layer.cornerRadius=8.0f;
    self.v_body.layer.masksToBounds=YES;
    
    self.lbl_Caltitle.text = @"行事曆";
    [self setFontUI];
    self.gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *currentMonth = self.v_calendar.currentPage;
    NSDate *previousMonth = [self.gregorian dateByAddingUnit:NSCalendarUnitMonth value:-12*66 toDate:currentMonth options:0];
    [self.v_calendar setCurrentPage:previousMonth animated:NO];
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear fromDate:self.v_calendar.minimumDate];
    NSDateComponents *components1 = [[NSCalendar currentCalendar] components:NSCalendarUnitYear fromDate:[NSDate date]];
    int minYear = (int)[components year];
    int maxYear = (int)[components1 year];
    NSLog(@"%d,%d",minYear,maxYear);
    for(int i = 0;maxYear - i > minYear;i++){
        NSString *value = [NSString stringWithFormat:@"%d",maxYear - i];
        [self.aryYear addObject:value];
    }
    [utility popupAnimation:self.v_selecter isOpen:NO];
    [self.btn_popupClose.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_popupClose setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_popupClose setTitle:@"關閉" forState:UIControlStateNormal];
    [self.btn_select.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_select setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_select setTitle:@"選擇" forState:UIControlStateNormal];
    [self setAccessibility];
}

-(void) updateCurrectDate{
    @try {
        self.v_calendar.selectedDate = self.valueDate;
        NSDate *currentMonth = self.v_calendar.selectedDate;
//        NSDate *previousMonth = [self.gregorian dateByAddingUnit:NSCalendarUnitMonth value:-12*66 toDate:currentMonth options:0];
        [self.v_calendar setCurrentPage:currentMonth animated:NO];
    } @catch (NSException *exception) {}
}

-(void) setAccessibility{
    self.btn_submit.isAccessibilityElement = true;
    self.btn_submit.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_submit.accessibilityLabel = @"確定";
    
    self.btn_close.isAccessibilityElement = true;
    self.btn_close.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_close.accessibilityLabel = @"關閉";
    
    self.btn_select.isAccessibilityElement = true;
    self.btn_select.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_select.accessibilityLabel = @"選擇";
    
    self.btn_popupClose.isAccessibilityElement = true;
    self.btn_popupClose.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_popupClose.accessibilityLabel = @"取消";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.btn_close.titleLabel.font = self.btn_submit.titleLabel.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    self.lbl_Caltitle.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    [self.btn_close setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_select setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_submit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_popupClose setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}

- (void)calendar:(FSCalendar *)calendar boundingRectWillChange:(CGRect)bounds animated:(BOOL)animated
{
    calendar.frame = (CGRect){calendar.frame.origin,bounds.size};
}

-(IBAction)pressBtnPopupClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.v_selecter isOpen:NO];
}

-(IBAction)pressBtnSel:(id)sender{
    NSInteger row = [self.dateSelect selectedRowInComponent:0];
    NSString *currentYear = [self.aryYear objectAtIndex:row];
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear fromDate:self.v_calendar.currentPage];
    int pickerYear = (int)[components year];
    int selYear = [currentYear intValue];
    NSLog(@"%d,%d",pickerYear,selYear);
    NSDate *currentMonth = self.v_calendar.currentPage;
    int diffYear = selYear - pickerYear;
    NSDate *previousMonth = [self.gregorian dateByAddingUnit:NSCalendarUnitMonth value:diffYear*12 toDate:currentMonth options:0];
    [self.v_calendar setCurrentPage:previousMonth animated:YES];
    [[utilityManager alloc] popupAnimation:self.v_selecter isOpen:NO];
}

-(IBAction)pressBtnYear:(id)sender{
    [[utilityManager alloc] popupAnimation:self.v_selecter isOpen:YES];
}

-(IBAction)pressBtnSubmit:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        if(self.v_calendar.selectedDate != nil){
            AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
            app.selectedDate = self.v_calendar.selectedDate;
            if([self.pre_view isKindOfClass:[registerStep3ViewController class]]){
                registerStep3ViewController *temp = (registerStep3ViewController*) self.pre_view;
                [temp updateSelectedDate];
            }
            else if ([self.pre_view isKindOfClass:[addDefaultPageViewController class]]){
                addDefaultPageViewController *temp = (addDefaultPageViewController*) self.pre_view;
                [temp callBackFunction];
            }
            else if ([self.pre_view isKindOfClass:[infoViewController class]]){
                infoViewController *temp = (infoViewController*) self.pre_view;
                [temp updateSelectedDate];
            }
        }
    }];
}

-(IBAction)pressBtnclose:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        if(self.v_calendar.selectedDate != nil){
            if([self.pre_view isKindOfClass:[registerStep3ViewController class]]){
                registerStep3ViewController *temp = (registerStep3ViewController*) self.pre_view;
                [temp updateSelectedDate];
            }
            else if ([self.pre_view isKindOfClass:[addDefaultPageViewController class]]){
                addDefaultPageViewController *temp = (addDefaultPageViewController*) self.pre_view;
                [temp callBackFunction];
            }
            else if ([self.pre_view isKindOfClass:[infoViewController class]]){
                infoViewController *temp = (infoViewController*) self.pre_view;
                [temp updateSelectedDate];
            }
        }
    }];
}

#pragma mark - FSCalendarDataSource
- (NSString *)calendar:(FSCalendar *)calendar subtitleForDate:(NSDate *)date
{
    SSLunarDate *lunar = [[SSLunarDate alloc] initWithDate:date];
    return [lunar dayString];
}

#pragma mark - FSCalendarDelegate

- (BOOL)calendar:(FSCalendar *)calendar shouldSelectDate:(NSDate *)date
{
    NSLocale *chinese = [NSLocale localeWithLocaleIdentifier:@"zh-CN"];
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    dateFormatter1.locale = chinese;
    dateFormatter1.dateFormat = @"yyyy/MM/dd";
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    app.selectedDate = date;
    NSLog(@"Should select date %@",[dateFormatter1 stringFromDate:date]);
//    [self pressBtnclose:nil];
    SSLunarDate *lunar = [[SSLunarDate alloc] initWithDate:date];
    self.lbl_Caltitle.text = [NSString stringWithFormat:@"行事曆\n%@",[lunar string]];
    return true;
}

// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [self.aryYear count];
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [self.aryYear objectAtIndex:row];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}
@end
