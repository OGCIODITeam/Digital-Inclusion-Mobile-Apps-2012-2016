//
//  popupCreateAlbumViewController.m
//  AngeLink
//
//  Created by kanhan on 7/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "popupCreateAlbumViewController.h"
#import "UIImage+addition.h"
#import "AppDelegate.h"
#import "albumDetailViewController.h"
#import "albumObj.h"

@interface popupCreateAlbumViewController ()

@end

@implementation popupCreateAlbumViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(noticeShowKeyboard:) name:UIKeyboardDidShowNotification object:nil];
    [center addObserver:self selector:@selector(noticeHideKeyboard:) name:UIKeyboardWillHideNotification object:nil];
    [center addObserver:self selector:@selector(noticeChangeKeyboard:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    if(self.aryData == nil){
        self.aryData = [NSMutableArray new];
    }
    else{
        [self.aryData removeAllObjects];
    }
    
    UIImage *img0 = [UIImage imageNamed:@"thm_dot"];
    UIImage *img1 = [UIImage imageNamed:@"thm_forest"];
    UIImage *img2 = [UIImage imageNamed:@"thm_elegant"];
    UIImage *img3 = [UIImage imageNamed:@"thm_angel"];
    UIImage *img4 = [UIImage imageNamed:@"thm_floral"];
    
    
    
    
    [self.aryData addObject:img0];
    [self.aryData addObject:img1];
    [self.aryData addObject:img2];
    [self.aryData addObject:img3];
    [self.aryData addObject:img4];
    
    self.v_popupBody.layer.cornerRadius=8.0f;
    self.v_popupBody.layer.masksToBounds=YES;
    self.v_popupBody.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.v_popupBody.layer.borderWidth= 0.0f;
    
    self.ic_Bg.delegate = self;
    self.ic_Bg.dataSource = self;
    self.ic_Bg.type = iCarouselTypeLinear;
    self.ic_Bg.pagingEnabled = YES;
    self.bgType = @"0";
    [self setFontUI];
    [self updateUI];
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_cam.isAccessibilityElement = true;
    self.btn_cam.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_cam.accessibilityLabel = @"相機";
    
    self.btn_lib.isAccessibilityElement = true;
    self.btn_lib.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_lib.accessibilityLabel = @"照片庫";
    
    self.btn_save.isAccessibilityElement = true;
    self.btn_save.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_save.accessibilityLabel = @"保存";
    
    self.btn_cancel.isAccessibilityElement = true;
    self.btn_cancel.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_cancel.accessibilityLabel = @"取消";
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

-(void) updateUI{
    if(self.record){
        albumObj *obj = (albumObj*)self.record;
        if([obj.albumType isEqualToString:@"0"]){
            self.isDefault = true;
        }
        else{
            self.isDefault = false;
        }
        self.tf_albumName.text = obj.albumTitle;
        if(![obj.coverPath isEqualToString:@""])
        {
            NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,obj.coverPath];
            NSLog(@"Path:%@",urlPath);
            [[connectionManager alloc] downloadFile:urlPath foldername:@"temp" progress:nil completionBlock:^(BOOL succeeded, NSURL *url) {
                self.originalImage  = [UIImage imageWithContentsOfFile:[url absoluteString]];
                NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
                if([[utilityManager alloc] saveDataFile:imageData Filename:@"album" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
                {
//                    NSData *imageData1 = [[utilityManager alloc] getDataFile:@"album.jpeg" folderName:@"temp" isDoucmentFolder:NO];
                }
            }];
        }
    }
    
    float orgY = 10;
    int sumWithoutName = 45 + 5 + 45 + 5 + 128 + 5 + 138 + 10;
    int sumWithName = 45 + 5 + 45 + 5 + 128 + 5 + 138 + 5 + 45 + 10;
    if(self.isDefault){
        self.v_popupBody.frame = CGRectMake(0,0,self.v_popupBody.frame.size.width,sumWithoutName);
        self.v_popupBody.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2 - 10);
        self.tf_albumName.hidden = YES;
    }
    else{
        self.v_popupBody.frame = CGRectMake(0,0,self.v_popupBody.frame.size.width,sumWithName);
        self.v_popupBody.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2 - 10);
        self.tf_albumName.hidden = NO;
    }
    self.lbl_Title.frame = CGRectMake(0, orgY, self.lbl_Title.frame.size.width, 45);
    self.lbl_Title.center = CGPointMake(self.v_popupBody.frame.size.width/2, self.lbl_Title.center.y);
    orgY += self.lbl_Title.frame.size.height;
    orgY += 5;
    self.lbl_BgTitle.frame = CGRectMake(0, orgY, self.lbl_BgTitle.frame.size.width, 45);
    self.lbl_BgTitle.center = CGPointMake(self.v_popupBody.frame.size.width/2, self.lbl_BgTitle.center.y);
    orgY += self.lbl_BgTitle.frame.size.height;
    orgY += 5;
    self.sv_Bg.frame = CGRectMake(0, orgY, self.sv_Bg.frame.size.width, 128);
    self.ic_Bg.frame = CGRectMake(0, 0, self.sv_Bg.frame.size.width, self.sv_Bg.frame.size.height);
    self.sv_Bg.center = CGPointMake(self.v_popupBody.frame.size.width/2, self.sv_Bg.center.y);
    orgY += self.sv_Bg.frame.size.height;
    orgY += 5;
    self.btn_cam.frame = CGRectMake(0, orgY, 138, 138);
    self.btn_cam.center = CGPointMake(self.v_popupBody.frame.size.width / 4, self.btn_cam.center.y);
    self.btn_lib.frame = CGRectMake(0, orgY, 138, 138);
    self.btn_lib.center = CGPointMake(self.v_popupBody.frame.size.width / 4 * 3, self.btn_lib.center.y);
    
    orgY += self.sv_Bg.frame.size.height;
    orgY += 5;
    
    self.tf_albumName.frame = CGRectMake(0, orgY, self.tf_albumName.frame.size.width, 45);
    self.tf_albumName.center = CGPointMake(self.v_popupBody.frame.size.width/2, self.tf_albumName.center.y);
    orgY += self.tf_albumName.frame.size.height;
    orgY += 5;
    CALayer *bottomBorder = [CALayer layer];
    bottomBorder.frame = CGRectMake(0.0f, self.tf_albumName.frame.size.height - 1, self.tf_albumName.frame.size.width, 1.0f);
    bottomBorder.backgroundColor = [UIColor blackColor].CGColor;
    [self.tf_albumName.layer addSublayer:bottomBorder];    
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_BgTitle.font = self.lbl_Title.font = self.lbl_albumName.font = self.tf_albumName.font = [font getRegularsize:[font getSettingFont:@"Title"]];
    [self.btn_save.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_save setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_cancel.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.lbl_Title.text = @"編輯";
    self.lbl_BgTitle.text = @"選擇封面圖片";
    self.tf_albumName.placeholder = @"輸入名稱";
    [self.btn_save setTitle:@"儲存" forState:UIControlStateNormal];
    [self.btn_cancel setTitle:@"取消" forState:UIControlStateNormal];
    CALayer *bottomBorder = [CALayer layer];
    bottomBorder.frame = CGRectMake(0.0f, self.tf_albumName.frame.size.height - 1, self.tf_albumName.frame.size.width, 1.0f);
    bottomBorder.backgroundColor = [UIColor blackColor].CGColor;
    [self.tf_albumName.layer addSublayer:bottomBorder];
    [self.btn_save setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_cam setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_lib setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

-(IBAction)pressBtnCreate:(id)sender{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    [app showLoading];
    NSDate* date = [NSDate date];
    if(app.selectedDate)
        date = app.selectedDate;
    NSString *imagePath = @"";
    utilityManager *utility = [[utilityManager alloc] init];
    connectionManager *connect = [[connectionManager alloc] init];
//    dbManager *db = [[dbManager alloc] init];
    NSMutableArray *imgAry = [[NSMutableArray alloc] init];
    if(self.originalImage != nil){
        NSDictionary *imageDict = [[NSDictionary alloc] initWithObjectsAndKeys:[[utilityManager alloc] getDataFilePath:@"album.jpeg" folderName:@"temp" isDoucmentFolder:NO],@"image",@"album.jpeg",@"imageName",@"coverPath",@"paramKey",nil];
        [imgAry addObject:imageDict];
        imagePath = @"album.jpeg";
    }
    NSDictionary *dictInfo;
    albumObj *obj = (albumObj*)self.record;
    NSLog(@"obj:%@",[obj toDict]);
    if(self.record){
        albumObj *obj = (albumObj*)self.record;
        dictInfo = [[NSDictionary alloc] initWithObjectsAndKeys:
                                  @"UPDATE_AL",@"action",
                                  obj.userID,@"user_id",
                                  self.tf_albumName.text,@"albumTitle",
                                  imagePath,@"coverPath",
                                  obj.albumTitle,@"albumType",
                                  obj.videoPath,@"videoPath",
                    self.bgType,@"frameType",                    
                    obj.albumID,@"albumID",
                                  obj.public,@"public",
                                  nil];
    }
    else{
        dictInfo = [[NSDictionary alloc] initWithObjectsAndKeys:
                                  @"INSERT_AL",@"action",
                                  [utility getUserDefaultstoString:@"memberID"],@"user_id",
                                  self.tf_albumName.text,@"albumTitle",
                                  imagePath,@"coverPath",
                                  self.bgType,@"albumType",
                                  @"",@"videoPath",
                                  @"1",@"public",
                                  nil];
        
    }
    
    
    self.btn_save.enabled = NO;
    self.btn_cancel.enabled = NO;
    [connect uploadRequest:CREATE_ALBUM parameters:dictInfo images:imgAry completionHandler:^(bool status, NSDictionary *jsonDict) {
        AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
        [app hideLoading];
        if(status)
        {
            [self dismissViewControllerAnimated:YES completion:^{
                albumDetailViewController *vc = (albumDetailViewController*) self.page;
                [vc callBackFunction];
            }];
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
            [alert show];
            self.btn_save.enabled = YES;
            self.btn_cancel.enabled = YES;
        }
    }];    
}

-(IBAction)pressBtnCancel:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return [self.aryData count];
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    switch (option)
    {
        case iCarouselOptionWrap:
        {
            return YES;
        }
//        case iCarouselOptionVisibleItems:
//        {
//            return 3;
//        }
        default:
        {
            return value;
        }
    }
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    //create new view if no view is available for recycling
    if (view == nil)
    {
        UIView *cView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 128.0f, 128.0f)];
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 108.0f, 108.0f)];
        imageView.image = [self.aryData objectAtIndex:index];
        [cView addSubview:imageView];
        view = cView;
    }
    albumObj *obj = (albumObj*)self.record;
    if([obj.frameType isEqualToString:[NSString stringWithFormat:@"%d",(int)index]]){
        [view setBackgroundColor:[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0]];
    }
    //show placeholder
    //    ((FXImageView *)view).processedImage = [UIImage imageNamed:@"placeholder.png"];
    //
    //    //set image
    //    ((FXImageView *)view).image = _images[index];
    
    return view;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    UIView *view = carousel.currentItemView;
    [view setBackgroundColor:[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0]];
    self.bgType = [NSString stringWithFormat:@"%d",(int)index];
}

- (void)carouselDidScroll:(iCarousel *)carousel{
    UIView *view = carousel.currentItemView;
    [view setBackgroundColor:[UIColor clearColor]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void) noticeChangeKeyboard:(NSNotification *)inNotification {
    NSDictionary *userInfo = [inNotification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
//    CGFloat keyboardTop = keyboardRect.origin.y;
    
    [UIView animateWithDuration:0.2
                          delay:0.3
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         if(self.view.frame.origin.y == 0){
                             self.view.frame = CGRectMake(0, self.view.frame.origin.y - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
                         }
                         else{
                             self.view.frame = CGRectMake(0, 0 - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
                         }
                     }
                     completion:^(BOOL finished){
                     }];
    
}

-(void) noticeShowKeyboard:(NSNotification *)inNotification {
    NSDictionary *userInfo = [inNotification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
//    CGFloat keyboardTop = keyboardRect.origin.y;
    if(self.view.frame.origin.y == 0)
        self.view.frame = CGRectMake(0, self.view.frame.origin.y - keyboardRect.size.height, self.view.frame.size.width, self.view.frame.size.height);
}

-(void) noticeHideKeyboard:(NSNotification *)inNotification {
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}

-(IBAction)pressBtncam:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnlib:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    self.originalImage = [UIImage fixrotation:[info objectForKey:UIImagePickerControllerOriginalImage]];
    NSData *imageData = [UIImage convertImageToLowJPEG:self.originalImage];
    if([[utilityManager alloc] saveDataFile:imageData Filename:@"album" filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
    {
//        NSData *imageData1 = [[utilityManager alloc] getDataFile:@"album.jpeg" folderName:@"temp" isDoucmentFolder:NO];
//        self.iv_pic.image = [UIImage fixrotation:[UIImage imageWithData:imageData1]];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
