//
//  restoreUserDataViewController.h
//  AngeLink
//
//  Created by kanhan on 12/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"

@interface restoreUserDataViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lbl_Title;
@property (weak, nonatomic) IBOutlet UIView *v_download;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *av_downlad;
@property (weak, nonatomic) IBOutlet UIButton *btn_finish;
@property (retain, nonatomic) TYMProgressBarView *progressBarView;
@property (nonatomic) NSTimer *timer;

@end
