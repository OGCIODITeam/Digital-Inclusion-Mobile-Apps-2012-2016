//
//  circleViewController.h
//  AngeLink
//
//  Created by kanhan on 26/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"
#import "fdRecord.h"

@interface circleViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,headerBarViewDelegate,UITextFieldDelegate,UIAlertViewDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *btn_fd;
@property (weak, nonatomic) IBOutlet UIButton *btn_rank;
@property (weak, nonatomic) IBOutlet UIButton *btn_wait;
@property (weak, nonatomic) IBOutlet UITextField *tf_search;
@property (weak, nonatomic) IBOutlet UIButton *btn_addFd;
@property (weak, nonatomic) IBOutlet UIButton *btn_fdEdit;
@property (weak, nonatomic) IBOutlet UITableView *tv_fd;
@property (nonatomic, retain) NSMutableArray *aryData,*aryRank,*aryWait;
@property (weak, nonatomic) IBOutlet UIView *v_fdList;
@property (weak, nonatomic) IBOutlet UIScrollView *sv_main;
@property (weak, nonatomic) IBOutlet UITableView *tv_rank;
@property (weak, nonatomic) IBOutlet UITableView *tv_wait;
@property (nonatomic, retain) UIAlertView *alertView;
@property (nonatomic, retain) fdRecord *fdRecord;
@property (nonatomic, assign) int maxRank;

@property (nonatomic, retain) infoView *info;



-(void)share:(BOOL)isMember;
@end
