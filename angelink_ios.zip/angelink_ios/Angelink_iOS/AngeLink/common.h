//
//  common.h
//  AngeLink
//
//  Created by kanhan on 8/9/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#ifndef common_h
#define common_h


#ifdef __IPHONE_6_0
# define ALIGN_CENTER NSTextAlignmentCenter
# define ALIGN_RIGHT NSTextAlignmentRight
# define LINE_BREAK_WORD_WRAP NSLineBreakByWordWrapping
#else
# define ALIGN_CENTER UITextAlignmentCenter
# define ALIGN_RIGHT UITextAlignmentRight
# define LINE_BREAK_WORD_WRAP UILineBreakModeWordWrap
#endif

#define DB_FILE @"angelink_v1"
#define DB_FILE_PWD @"ywcakanhan"
#define CUSTOM_PLIST @"menu"
#define ERROR_LOG_FILE @"gpsLog"

//NSDate Format
#define DISPLAYDATEFORMATTER @"yyyy MMM dd HH:mm"
#define SQLITEDATETIMEFORMAT @"yyyy-MM-dd HH:mm:ss"
#define DATEFORMAT @"yyyy-MM-dd HH:mm:ss"
#define BRITHDAYDATETIMEFORMAT @"yyyy-MM-dd"

#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)

#define MAXLENGTH 20

#ifdef DEVELOP_MODE
//Developer Server
//#define SERVER_HOST @"https://angelink-uat2.kanhan.com/api/"
//#define SERVER_IMAGE @"https://angelink-uat2.kanhan.com/"
//#define SERVER_USER_FOLDER @"https://angelink-uat2.kanhan.com"
//UAT Server
//#define SERVER_HOST @"http://angelink-uat.kanhan.com/api/"
//#define SERVER_IMAGE @"http://angelink-uat.kanhan.com"
//#define SERVER_USER_FOLDER @"http://angelink-uat.kanhan.com"
//Production Server
#define SERVER_HOST @"https://angelink.ywca.org.hk/api/"
#define SERVER_IMAGE @"https://angelink.ywca.org.hk/"
#define SERVER_USER_FOLDER @"https://angelink.ywca.org.hk"
#else
//Developer Server
//#define SERVER_HOST @"http://angelink-uat2.kanhan.com/api/"
//#define SERVER_IMAGE @"http://angelink-uat2.kanhan.com/"
//#define SERVER_USER_FOLDER @"http://angelink-uat2.kanhan.com"
//UAT Server
//#define SERVER_HOST @"http://angelink-uat.kanhan.com/api/"
//#define SERVER_IMAGE @"http://angelink-uat.kanhan.com"
//#define SERVER_USER_FOLDER @"http://angelink-uat.kanhan.com"
//Production Server
#define SERVER_HOST @"https://angelink.ywca.org.hk/api/"
#define SERVER_IMAGE @"https://angelink.ywca.org.hk/"
#define SERVER_USER_FOLDER @"https://angelink.ywca.org.hk"
#endif

//Framework
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <CoreLocation/CoreLocation.h>

//Pod
#import "sqlite3.h"
#import "FMDB.h"    //db control
#import "AFNetworking.h"    //connect network
#import "UIImageView+AFNetworking.h"    //connect network
#import "UIRefreshControl+AFNetworking.h"   //connect network
//#import "UIAlertView+AFNetworking.h"    //connect network
#import "UIKit+AFNetworking.h"
#import "UALogger.h"
//#import "SSZipArchive.h"
#import "M13Checkbox.h"
#import "FSCalendar.h"
#import "TYMProgressBarView.h"
#import "FBSDKLoginKit.h"
#import "FBSDKCoreKit.h"
#import <FBSDKShareKit/FBSDKShareKit.h>
#import "APAddressBook.h"
#import "APPhone.h"
#import "APJob.h"
#import "APName.h"
#import "APEmail.h"
#import "APContact.h"
#import "APAddressBook.h"
#import "APAddressBookAccessRoutine.h"
#import "APAddressBookContactsRoutine.h"
#import "APAddressBookExternalChangeRoutine.h"
#import "APContactListBuilder.h"
#import "APAddressBookRefWrapper.h"
#import "APThread.h"
#import "iCarousel.h"
#import "StepSlider.h"
#import <Bugsnag/Bugsnag.h>
#import "LMDropdownView.h"
#import <EasyPickersCollection/i2KEPCMultiComponentPickerView.h>
#import <EasyPickersCollection/i2KEPCBasePickerView.h>
#import <EasyPickersCollection/i2KEPCSingleComponentPickerView.h>
#import <EasyPickersCollection/i2KEPCDatePickerView.h>
#import "MBProgressHUD.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "Objective-Zip.h"
#import "TSAssetsPickerController.h"
#import "YCameraViewController.h"


//Library
#import "JSONKit.h"
#import "BundleLocalization.h"
#import "SlideNavigationController.h"
#import "JBWhatsAppActivity.h"
#import "vc_PopupVideo.h"
#import "HDNotificationView.h"
#import "JSImagePickerViewController.h"
#import "BHInputToolbar.h"
#import "UIPlaceHolderTextView.h"
//Class

//Manager
#import "apiManager.h"
#import "connectionManager.h"
#import "colorManager.h"
#import "dbManager.h"
#import "fontManager.h"
#import "settingManager.h"
#import "utilityManager.h"
#import "lunarManager.h"
#import "SSLunarDate.h"
#import "SSHolidayHK.h"
#import "fdListBtn.h"
#endif /* common_h */
