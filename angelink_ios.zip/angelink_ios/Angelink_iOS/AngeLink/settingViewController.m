//
//  settingViewController.m
//  AngeLink
//
//  Created by kanhan on 17/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "settingViewController.h"
#import "contactViewController.h"
#import "infoViewController.h"
#import "userObj.h"
#import "AppDelegate.h"

@interface settingViewController ()

@end

@implementation settingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    header.lbl_pageTittle.text = @"人生紀念冊";
    header.delegate = self;
    [self.view addSubview:header];
    [self settingUI];
    self.lbl_backupStatus.text = @"尚未備份";
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    
    if([[[[utilityManager alloc] getUserDefaultstoString:@"FontSize"] lowercaseString] isEqualToString:@"small"]){
        self.slideSize.value = 0.0;
    }
    else if([[[[utilityManager alloc] getUserDefaultstoString:@"FontSize"] lowercaseString] isEqualToString:@"middle"]){
        self.slideSize.value = 0.5;
    }
    else{
        self.slideSize.value = 1.0;
    }
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Setting_4.0.0_1"];
    UIImage *img2 = [UIImage imageNamed:@"Setting_4.0.0_2"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"你可以詳細設定AngeLINK愛‧連繫 的各項細節。";
    NSString *str2 = @"編輯關於自己的資料";
    [aryString addObject:str1];
    [aryString addObject:str2];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    if ([FBSDKAccessToken currentAccessToken] ) {
        self.btn_fb_login.selected = YES;
        [self.btn_fb_login removeTarget:nil action:NULL forControlEvents:UIControlEventAllTouchEvents];
        [self.btn_fb_login addTarget:self action:@selector(pressBtnsigeOutFB:) forControlEvents:UIControlEventTouchUpInside];
    }
    else{
        self.btn_fb_login.selected = NO;
        [self.btn_fb_login removeTarget:nil action:NULL forControlEvents:UIControlEventAllTouchEvents];
        [self.btn_fb_login addTarget:self action:@selector(pressBtnsigeFB:) forControlEvents:UIControlEventTouchUpInside];
    }
}

-(void) viewWillAppear:(BOOL)animated{
    [self updateUserInfo];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        [locationManager requestWhenInUseAuthorization];
}

-(void) updateUserInfo{
    utilityManager *utility = [[utilityManager alloc] init];
    //    dbManager *db = [[dbManager alloc] init];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id", nil];
    [[connectionManager alloc] postRequest:GET_USER_INFO parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            dbManager *db = [[dbManager alloc] init];
            userObj *user = [[userObj alloc] initWithDict:jsonDict];
            NSLog(@"user:%@",user);
            [utility saveValuetoUserDefaults:[user toDict]];
            NSString *value = [NSString stringWithFormat:@"username='%@',mobile='%@',phoneAreaCode='%@',imagePath='%@',birthday='%@',lunarBirthday='%@',facebookID='%@',backupPath='%@',currentSize='%@'",user.username,user.mobile,user.phoneAreaCode,user.imagePath,user.birthday,user.lunarBirthday,user.facebookID,user.backupPath,user.currentSize];
            if([db updateSQL:@"tbl_userProfile" tCol:value tWhere:[NSString stringWithFormat:@"userID='%@'",[utility getUserDefaultstoString:@"memberID"]]]){
            }
            self.lbl_username.text = user.username;
            NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,user.imagePath]];
            //            self.iv_img.image = nil;
            self.iv_img.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
            //            [self.iv_img setImageWithURL:url placeholderImage:[UIImage imageNamed:@"sign_pic_none"]];
            [self settingUI];
        }
    }];
}

-(void)pressBtnback:(id)sender{
    [[self navigationController] popViewControllerAnimated:TRUE];
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(IBAction)pressBtnsigeFB:(id)sender{
    [[connectionManager alloc] loginFBisReadOnly:YES Controller:self completionHandler:^(bool success, NSDictionary *dict) {
        if ([FBSDKAccessToken currentAccessToken] ) {
            self.btn_fb_login.selected = YES;
            [self.btn_fb_login removeTarget:nil action:NULL forControlEvents:UIControlEventAllTouchEvents];
            [self.btn_fb_login addTarget:self action:@selector(pressBtnsigeOutFB:) forControlEvents:UIControlEventTouchUpInside];
        }
        else{
            self.btn_fb_login.selected = NO;
            [self.btn_fb_login removeTarget:nil action:NULL forControlEvents:UIControlEventAllTouchEvents];
            [self.btn_fb_login addTarget:self action:@selector(pressBtnsigeFB:) forControlEvents:UIControlEventTouchUpInside];
        }
    }];
}

-(IBAction)pressBtnsigeOutFB:(id)sender{
    FBSDKLoginManager *loginManager = [[FBSDKLoginManager alloc] init];
    [loginManager logOut];
    [FBSDKAccessToken setCurrentAccessToken:nil];
    [FBSDKProfile setCurrentProfile:nil];
    if ([FBSDKAccessToken currentAccessToken] ) {
        self.btn_fb_login.selected = YES;
        [self.btn_fb_login removeTarget:nil action:NULL forControlEvents:UIControlEventAllTouchEvents];
        [self.btn_fb_login addTarget:self action:@selector(pressBtnsigeOutFB:) forControlEvents:UIControlEventTouchUpInside];
    }
    else{
        self.btn_fb_login.selected = NO;
        [self.btn_fb_login removeTarget:nil action:NULL forControlEvents:UIControlEventAllTouchEvents];
        [self.btn_fb_login addTarget:self action:@selector(pressBtnsigeFB:) forControlEvents:UIControlEventTouchUpInside];
    }    
}

-(void) settingUI{
    fontManager *font = [[fontManager alloc] init];
    utilityManager *utility = [[utilityManager alloc] init];
    dbManager *db = [[dbManager alloc] init];
    NSMutableArray *ary = [db selectSQL:@"tbl_userProfile" where:[NSString stringWithFormat:@"userid = '%@'",[utility getUserDefaultstoString:@"memberID"]] option:@""];
    if([ary count]>0){
        NSDictionary *dict = [ary objectAtIndex:0];
        self.lbl_username.text = [dict objectForKey:@"username"];
        //        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_IMAGE,[dict objectForKey:@"imagePath"]]];
        //        self.iv_img.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
        //        [self.iv_img setImageWithURL:url placeholderImage:[UIImage imageNamed:@"sign_pic_none"]];
    }
    self.sv_main.frame = CGRectMake(0, 110, self.sv_main.frame.size.width, self.view.frame.size.height - 110);
    float orgX = 0.0;
    float orgY = 0.0;
    int padding = 5;
    
    self.lbl_username.font = self.lbl_backupStatus.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    
    float coodY = 5.0;
    
    self.v_profile.layer.cornerRadius=8.0f;
    self.v_profile.layer.masksToBounds=YES;
    self.v_profile.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.v_profile.layer.borderWidth= 0.0f;
    self.v_profile.frame = CGRectMake(0, orgY, self.v_profile.frame.size.width, 200);
    self.v_profile.center = CGPointMake(self.sv_main.frame.size.width / 2, self.v_profile.center.y);
    
    self.lbl_username.frame = CGRectMake(0, coodY, self.lbl_username.frame.size.width, 50);
    self.lbl_username.center = CGPointMake(self.v_profile.frame.size.width/2, self.lbl_username.center.y);
    coodY += self.lbl_username.frame.size.height;
    coodY += 5;
    
    self.iv_img.frame = CGRectMake(0, coodY, 134, 134);
    self.iv_img.center = CGPointMake(self.v_profile.frame.size.width / 2, self.iv_img.center.y);
    self.btn_edit.center = CGPointMake(self.iv_img.frame.origin.x + self.iv_img.frame.size.width, self.iv_img.frame.origin.y + (self.iv_img.frame.size.height / 4));
    
    coodY += self.iv_img.frame.size.height;
    coodY += 5;
    
    //    self.iv_img.frame = CGRectMake(0, self.iv_img.frame.origin.y, 134, 134);
    
    self.iv_img.layer.cornerRadius = self.iv_img.frame.size.width / 2;
    self.iv_img.layer.masksToBounds=YES;
    self.iv_img.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.iv_img.layer.borderWidth= 3.0f;
    
    orgY += self.v_profile.frame.size.height;
    orgY += padding;
    
    self.btn_fb_login.frame = CGRectMake(0, orgY, self.btn_fb_login.frame.size.width, self.btn_fb_login.frame.size.height);
    self.btn_fb_login.center = CGPointMake(self.sv_main.frame.size.width/2, self.btn_fb_login.center.y);
    
    orgY += self.btn_fb_login.frame.size.height;
    orgY += padding;
    
    self.v_fontSize.frame = CGRectMake(0, orgY, self.v_fontSize.frame.size.width, self.v_fontSize.frame.size.height);
    self.v_fontSize.center = CGPointMake(self.sv_main.frame.size.width/2, self.v_fontSize.center.y);
    
    orgY += self.v_fontSize.frame.size.height;
    orgY += padding;
    
    
    self.btn_backup.frame = CGRectMake(orgX, orgY, self.btn_backup.frame.size.width, self.btn_backup.frame.size.height);
    
    self.btn_autoUpload.frame = CGRectMake(self.sv_main.frame.size.width - self.btn_autoUpload.frame.size.width, orgY, self.btn_autoUpload.frame.size.width, self.btn_autoUpload.frame.size.height);
    
    orgY += self.btn_autoUpload.frame.size.height;
    orgY += padding;
    
    self.lbl_backupStatus.frame = CGRectMake(orgX, orgY, self.lbl_backupStatus.frame.size.width, self.lbl_backupStatus.frame.size.height);
    self.lbl_backupStatus.layer.cornerRadius = 5.0;
    self.lbl_backupStatus.layer.masksToBounds=YES;
    self.lbl_backupStatus.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.lbl_backupStatus.layer.borderWidth= 0.0f;
    self.lbl_backupStatus.textAlignment = ALIGN_CENTER;
    [self.lbl_backupStatus setBackgroundColor:[UIColor darkGrayColor]];
    self.lbl_backupStatus.textColor = [UIColor whiteColor];
    
    self.sel_dropdown.frame = CGRectMake(self.sv_main.frame.size.width - self.sel_dropdown.frame.size.width, orgY, self.sel_dropdown.frame.size.width, self.sel_dropdown.frame.size.height);
    
    orgY += self.lbl_backupStatus.frame.size.height;
    orgY += padding;
    
    self.btn_notice.frame = CGRectMake(orgX, orgY, self.btn_notice.frame.size.width, self.btn_notice.frame.size.height);
    
    self.btn_about.frame = CGRectMake(self.sv_main.frame.size.width - self.btn_about.frame.size.width, orgY, self.btn_about.frame.size.width, self.btn_about.frame.size.height);
    
    orgY += self.btn_about.frame.size.height;
    orgY += padding;
    
    self.btn_contact.frame = CGRectMake(orgX, orgY, self.btn_contact.frame.size.width, self.btn_contact.frame.size.height);
    
    self.btn_poicy.frame = CGRectMake(self.sv_main.frame.size.width - self.btn_poicy.frame.size.width, orgY, self.btn_poicy.frame.size.width, self.btn_poicy.frame.size.height);
    
    orgY += self.btn_poicy.frame.size.height;
    orgY += padding;
    
    self.btn_suggest.frame = CGRectMake(orgX, orgY, self.btn_suggest.frame.size.width, self.btn_suggest.frame.size.height);
    
    self.btn_GPS.frame = CGRectMake(self.sv_main.frame.size.width - self.btn_GPS.frame.size.width, orgY, self.btn_GPS.frame.size.width, self.btn_GPS.frame.size.height);
    
    orgY += self.btn_GPS.frame.size.height;
    orgY += padding;
    
    self.sv_main.contentSize = CGSizeMake(self.sv_main.frame.size.width, orgY);
    if([[utility getUserDefaultstoString:@"Backup"] isEqualToString:@"1"]){
        [self.btn_backup setImage:[UIImage imageNamed:@"btn_backup_on"] forState:UIControlStateNormal];
    }
    else{
        [self.btn_backup setImage:[UIImage imageNamed:@"btn_backup"] forState:UIControlStateNormal];
    }
    if([[utility getUserDefaultstoString:@"AutoUpload"] isEqualToString:@"1"]){
        [self.btn_autoUpload setImage:[UIImage imageNamed:@"btn_autoul_on"] forState:UIControlStateNormal];
    }
    else{
        [self.btn_autoUpload setImage:[UIImage imageNamed:@"btn_autoul"] forState:UIControlStateNormal];
    }
    if([[utility getUserDefaultstoString:@"GPS"] isEqualToString:@"1"]){
        [self.btn_GPS setImage:[UIImage imageNamed:@"btn_gps_on"] forState:UIControlStateNormal];
    }
    else{
        [self.btn_GPS setImage:[UIImage imageNamed:@"btn_gps"] forState:UIControlStateNormal];
    }
    
    [self.btn_edit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_fb_login setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_backup setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_autoUpload setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.sel_dropdown setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_notice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_about setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_contact setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_poicy setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_suggest setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_GPS setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

-(IBAction)pressBtnUserInfo:(id)sender{
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id", nil];
    [[connectionManager alloc] postRequest:GET_USER_INFO parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            userObj *user = [[userObj alloc] initWithDict:jsonDict];
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                     bundle: nil];
            infoViewController *vc = (infoViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"infoViewController"];
            vc.record = user;
            [[self navigationController] pushViewController:vc animated:TRUE];
        }
    }];
}

-(IBAction)sliderDidMove:(id)sender{
    UISlider *slider=(UISlider *)sender;
    float sliderValue=(float)(slider.value );
    if(sliderValue < 0.5){
        [[settingManager alloc] setFontSize:@"Small"];
    }
    if(sliderValue <= 0.9 && sliderValue>= 0.5){
        [[settingManager alloc] setFontSize:@"Middle"];
    }
    if(sliderValue > 0.9){
        [[settingManager alloc] setFontSize:@"Large"];
    }
    [self viewDidLoad];
}

-(IBAction)pressBtnBackup:(id)sender{
    //    NSError *error = nil;
    utilityManager *utility = [[utilityManager alloc] init];
    NSString *sampleDataPath = [[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"local.sqlite"];
    NSString *str = [[utilityManager alloc] tempZipPath];
    //
    //    OZZipFile *unzipFile= [[OZZipFile alloc] initWithFileName:str mode:OZZipFileModeUnzip error:&error];
    //    if(error){
    //        NSLog(@"Error:%@",[error description]);
    //    }
    //    [unzipFile goToFirstFileInZipWithError:&error];
    //    if(error){
    //        NSLog(@"Error:%@",[error description]);
    //    }
    //    OZFileInZipInfo *info= [unzipFile getCurrentFileInZipInfoWithError:&error];
    //    if(error){
    //        NSLog(@"Error:%@",[error description]);
    //    }
    //    OZZipReadStream *read= [unzipFile readCurrentFileInZipWithError:&error];
    //    if(error){
    //        NSLog(@"Error:%@",[error description]);
    //    }
    //    NSMutableData *data= [[NSMutableData alloc] initWithLength:info.length];
    //    [read readDataWithBuffer:data error:&error];
    //    if(error){
    //        NSLog(@"Error:%@",[error description]);
    //    }
    //    [read finishedReadingWithError:&error];
    //    if(error){
    //        NSLog(@"Error:%@",[error description]);
    //    }
    if([[utility getUserDefaultstoString:@"Backup"] isEqualToString:@"1"]){
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"Backup", nil];
        [utility saveValuetoUserDefaults:dict];
        [self.btn_backup setImage:[UIImage imageNamed:@"btn_backup"] forState:UIControlStateNormal];
    }
    else{
        OZZipFile *zipFile= [[OZZipFile alloc] initWithFileName:str mode:OZZipFileModeCreate];
        OZZipWriteStream *steam = [zipFile writeFileInZipWithName:@"local.sqlite" compressionLevel:OZZipCompressionLevelBest];
        [steam writeData:[utility getDataFileByPath:sampleDataPath]];
        [steam finishedWriting];
        NSMutableArray *ary = [NSMutableArray new];
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[utility getUserDefaultstoString:@"memberID"],@"user_id",[NSString stringWithFormat:@"%@.zip",[utility getUserDefaultstoString:@"memberID"]],@"backup_name", nil];
        NSMutableDictionary *dictZip = [NSMutableDictionary new];
        [dictZip setValue:str forKey:@"file"];
        [dictZip setValue:[NSString stringWithFormat:@"%@.zip",[utility getUserDefaultstoString:@"memberID"]]  forKey:@"fileName"];
        [dictZip setValue:@"application/zip" forKey:@"fileType"];
        [dictZip setValue:@"backup_file" forKey:@"paramKey"];
        [ary addObject:dictZip];
        [self uploadFile:UPDATE_USER_BACKUP parameters:dict images:ary completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"1",@"Backup", nil];
                [utility saveValuetoUserDefaults:dict];
                [self.btn_backup setImage:[UIImage imageNamed:@"btn_backup_on"] forState:UIControlStateNormal];
            }
            else{
                NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"Backup", nil];
                [utility saveValuetoUserDefaults:dict];
                [self.btn_backup setImage:[UIImage imageNamed:@"btn_backup"] forState:UIControlStateNormal];
            }
            NSLog(@"jsonDict:%@",jsonDict);
        }];
        //        }
    }
}

-(IBAction)pressBtnAutoUpload:(id)sender{
    utilityManager *utility = [[utilityManager alloc] init];
    if([[utility getUserDefaultstoString:@"AutoUpload"] isEqualToString:@"1"]){
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"AutoUpload", nil];
        [utility saveValuetoUserDefaults:dict];
        [self.btn_autoUpload setImage:[UIImage imageNamed:@"btn_autoul"] forState:UIControlStateNormal];
    }
    else{
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"1",@"AutoUpload", nil];
        [utility saveValuetoUserDefaults:dict];
        [self.btn_autoUpload setImage:[UIImage imageNamed:@"btn_autoul_on"] forState:UIControlStateNormal];
    }
}

-(IBAction)pressBtnPush:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"pushViewController"];
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(IBAction)pressBtnAbout:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    contactViewController *vc = (contactViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"contactViewController"];
    vc.catType = @"關於愛、連繫";
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(IBAction)pressBtnContact:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    contactViewController *vc = (contactViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"contactViewController"];
    vc.catType = @"關於我們";
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(IBAction)pressBtnPolicy:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    contactViewController *vc = (contactViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"contactViewController"];
    vc.catType = @"條款細則";
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(IBAction)pressBtnSuggest:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"suggestionViewController"];
    [[self navigationController] pushViewController:vc animated:TRUE];
}

-(IBAction)pressBtnGPS:(id)sender{
    utilityManager *utility = [[utilityManager alloc] init];
    //    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=Settings"]];
    //    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    NSURL *url = [NSURL URLWithString:@"prefs:root=LOCATION_SERVICES"];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        NSLog(@"go to WIFI");
        [[UIApplication sharedApplication] openURL:url];
    } else {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    if([[utility getUserDefaultstoString:@"GPS"] isEqualToString:@"1"]){
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"GPS", nil];
        [utility saveValuetoUserDefaults:dict];
        [self.btn_GPS setImage:[UIImage imageNamed:@"btn_gps"] forState:UIControlStateNormal];
        [app runGPS];
    }
    else{
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"1",@"GPS", nil];
        [utility saveValuetoUserDefaults:dict];
        [self.btn_GPS setImage:[UIImage imageNamed:@"btn_gps_on"] forState:UIControlStateNormal];        
        [app stopRunGPS];
    }
}

-(void) uploadFile:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([imageArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[imageArray count];i++){
                NSMutableDictionary *dict = [imageArray objectAtIndex:i];
                [formData appendPartWithFileData:[utility getDataFileByPath:[dict objectForKey:@"file"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"fileName"] mimeType:[dict objectForKey:@"fileType"]];
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                  }];
    
    [uploadTask resume];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
