//
//  addPage1ViewController.h
//  AngeLink
//
//  Created by kanhan on 25/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface addPage1ViewController : UIViewController<headerBarViewDelegate,UITextFieldDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *iv_bg;
@property (weak, nonatomic) IBOutlet UITextField *tf_pageName;
@property (weak, nonatomic) IBOutlet UIButton *btn_img;
@property (weak, nonatomic) IBOutlet UIButton *btn_mov;
@property (weak, nonatomic) IBOutlet UIButton *btn_next;
@property (nonatomic, retain) NSString *headerTitle;
@property (nonatomic, retain) NSObject *record;
@property (nonatomic, retain) infoView *info;


@end
