//
//  MessageViewController.h
//  AngeLink
//
//  Created by kanhan on 22/5/2017.
//  Copyright © 2017 kanhan. All rights reserved.
//

#import "common.h"
#import "fbObject.h"
#import "userFBinfo.h"

@interface MessageViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,BHInputToolbarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate>{
    BOOL keyboardIsVisible;
}
@property (weak, nonatomic) IBOutlet UITableView *tv_post;
@property (weak, nonatomic) IBOutlet UIView *v_popup;
@property (weak, nonatomic) IBOutlet UIButton *btn_cam;
@property (weak, nonatomic) IBOutlet UIButton *btn_lib;
@property (weak, nonatomic) IBOutlet UIButton *btn_sticker;
@property (weak, nonatomic) IBOutlet UIButton *btn_close;
@property (nonatomic, retain) UIImage *originalImage;
@property (nonatomic, retain) NSDictionary *dict;
@property (nonatomic, retain) fbObject *obj;
@property (nonatomic, retain) userFBinfo *userInfo;
@property (nonatomic, retain) NSMutableArray *aryData;
@property (weak, nonatomic) IBOutlet UIImageView *iv_image;
@property (retain, nonatomic) UIToolbar *functionToolbar;
@property (weak, nonatomic) IBOutlet UIView *v_img;
@property (weak, nonatomic) IBOutlet UIButton *btn_v_img_Close;
@property (weak, nonatomic) IBOutlet UITextView *tv_message;
@property (weak, nonatomic) IBOutlet UIImageView *iv_userPic;
@property (weak, nonatomic) IBOutlet UIView *v_warm;
@property (nonatomic, retain) UIViewController *preView;
@property (nonatomic, retain) UIButton *selBtn;
@end
