//
//  fdActViewController.h
//  AngeLink
//
//  Created by kanhan on 1/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"

@interface fdActViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,headerBarViewDelegate,UITextFieldDelegate,infoViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *btn_addPost;
@property (weak, nonatomic) IBOutlet UITableView *tv_post;
@property (strong, nonatomic) IBOutlet UITextField *tf_addPost;
@property (nonatomic, retain) NSMutableArray *aryData,*loopAry;
@property (nonatomic, retain) UIRefreshControl *refreshControl;
@property (nonatomic, retain) NSDictionary *userInfo;
@property (nonatomic, retain) MBProgressHUD *hud;
@property (nonatomic, assign) int cnt;
@property (weak, nonatomic) IBOutlet UIScrollView *sv_main;
@property (nonatomic, retain) UIButton *selBtn;
@property (nonatomic, retain) infoView *info;

-(void) flashData;
@end
