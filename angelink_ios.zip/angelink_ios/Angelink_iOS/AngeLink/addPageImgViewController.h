//
//  addPageImgViewController.h
//  AngeLink
//
//  Created by kanhan on 26/11/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "common.h"
#import "headerBar.h"
#import "infoView.h"
#import "DropDownView.h"

@interface addPageImgViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,headerBarViewDelegate,AVAudioRecorderDelegate, AVAudioPlayerDelegate,UIPickerViewDataSource, UIPickerViewDelegate,DropDownViewDelegate,UITextViewDelegate,infoViewDelegate>{
    NSArray *arrayData;    
    DropDownView *dropDownView;
}
@property (strong, nonatomic) IBOutlet UIView *v_dropdownBox;
@property (weak, nonatomic) IBOutlet UITableView *tv_dropdown;
@property (weak, nonatomic) IBOutlet UIButton *btn_cam;
@property (weak, nonatomic) IBOutlet UIButton *btn_lib;
@property (weak, nonatomic) IBOutlet UIButton *btn_dropdown;
@property (weak, nonatomic) IBOutlet UIImageView *iv_dropdown;
@property (weak, nonatomic) IBOutlet UIView *v_inputBox;
@property (weak, nonatomic) IBOutlet UITextView *txt_box;
@property (weak, nonatomic) IBOutlet UIImageView *iv_inputImg;
@property (weak, nonatomic) IBOutlet UIButton *btn_textToVoice;
@property (weak, nonatomic) IBOutlet UIButton *btn_recorder;
@property (weak, nonatomic) IBOutlet UIButton *btn_play;
@property (weak, nonatomic) IBOutlet UIButton *sel_time;
@property (weak, nonatomic) IBOutlet UIButton *btn_saveNquit;
@property (weak, nonatomic) IBOutlet UIButton *btn_saveNnew;
@property (weak, nonatomic) IBOutlet UIButton *btn_recorder_stop;
@property (weak, nonatomic) IBOutlet UIButton *btn_stop;
@property (nonatomic, retain) NSString *headerTitle;
@property (nonatomic, retain) NSString *audioDuration,*residenceTime,*position;
@property (nonatomic, strong) NSObject *record,*pageRecord,*albumRecord;
@property (nonatomic, retain) AVAudioRecorder *recorder;
@property (nonatomic, retain) AVAudioPlayer *player;
@property (nonatomic, retain) AVPlayerItem *playerItem;
@property (nonatomic,assign) BOOL isAudio;
@property (nonatomic, retain) UIImage *originalImage;
@property (weak, nonatomic) IBOutlet UIView *v_popup;
@property (weak, nonatomic) IBOutlet UIPickerView *timePicker;
@property (weak, nonatomic) IBOutlet UIButton *btn_popupClose;
@property (weak, nonatomic) IBOutlet UIButton *btn_popupSel;
@property (nonatomic, retain) NSMutableArray *mediaArray,*aryTime;
@property (nonatomic, retain) infoView *info;
@end
