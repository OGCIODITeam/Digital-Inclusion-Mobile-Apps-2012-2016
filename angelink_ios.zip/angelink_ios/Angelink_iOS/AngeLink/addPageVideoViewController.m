//
//  addPageVideoViewController.m
//  AngeLink
//
//  Created by kanhan on 1/12/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "addPageVideoViewController.h"
#import "AppDelegate.h"
#import "UIImage+addition.h"
#import "albumPageObj.h"
#define FILENAME @"videoFile.mp4"
#define THUMBFILENAME @"videoThumb.jpeg"
#define THUMB @"videoThumb"
@interface addPageVideoViewController ()

@end

@implementation addPageVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    headerBar *header = [[headerBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 105)];
    
    header.lbl_pageTittle.text = self.headerTitle;
    header.delegate = self;
    [self.view addSubview:header];
    self.navigationController.navigationBar.hidden = YES;
    // Do any additional setup after loading the view.
    [self setViewUI];
    if(self.mediaArray == nil){
        self.mediaArray = [NSMutableArray new];
    }
    if(self.pageRecord){
        utilityManager *utility =[[utilityManager alloc] init];
        connectionManager *connect =[[connectionManager alloc] init];
        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
//        NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,objPage.videoPath];
        if(![objPage.videoPath isEqualToString:@""]){
            NSString *urlPath = [NSString stringWithFormat:@"%@%@",SERVER_USER_FOLDER,objPage.videoPath];
            [connect downloadFile:urlPath foldername:@"temp" progress:nil completionBlock:^(BOOL succeeded, NSURL *url) {
                if(url != nil)
                {
                    NSData *data = [[utilityManager alloc] getDataFileByPath:[url absoluteString]];
                    if([utility saveDataFile:data Filename:@"videoFile" filetype:@"mp4" folderName:@"temp" isDoucmentFolder:NO])
                    {
                        UIImage *img = [[utilityManager alloc] getVideoThumbnailImage:[[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO]];
                        self.iv_videoThumb.image = img;
                        NSData *imageData = [UIImage convertImageToLowJPEG:img];
                        if([[utilityManager alloc] saveDataFile:imageData Filename:THUMB filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
                        {
                        }
                    }
                }
            }];
        }
    }
    else{
        if([[utilityManager alloc] CreateFile:THUMBFILENAME documentFolder:@"temp"]){
            
        }
    }
    
    NSMutableArray *aryImg = [NSMutableArray new];
    UIImage *img1 = [UIImage imageNamed:@"Book_6.2.3_1"];
    UIImage *img2 = [UIImage imageNamed:@"Book_6.2.3_2"];
    UIImage *img3 = [UIImage imageNamed:@"Book_6.2.3_3"];
    [aryImg addObject:img1];
    [aryImg addObject:img2];
    [aryImg addObject:img3];
    
    NSMutableArray *aryString = [NSMutableArray new];
    NSString *str1 = @"為自訂頁面加入影片";
    NSString *str2 = @"從手機影片庫中加入影片";
    NSString *str3 = @"播放所選擇的影片內容";
    [aryString addObject:str1];
    [aryString addObject:str2];
    [aryString addObject:str3];
    
    self.info = [[infoView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    [self.info dataUpdate:aryString imageArray:aryImg];
    self.info.delegate = self;
    [self.view addSubview:self.info];
    [self setAccessibility];
}

-(void) setAccessibility{
    self.btn_selVideo.isAccessibilityElement = true;
    self.btn_selVideo.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_selVideo.accessibilityLabel = @"相機";
    
    self.btn_play.isAccessibilityElement = true;
    self.btn_play.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_play.accessibilityLabel = @"播放";
    
    self.btn_saveNquit.isAccessibilityElement = true;
    self.btn_saveNquit.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_saveNquit.accessibilityLabel = @"保存並退出";
    
    self.btn_saveNpage.isAccessibilityElement = true;
    self.btn_saveNpage.accessibilityTraits = UIAccessibilityTraitNone;
    self.btn_saveNpage.accessibilityLabel = @"保存並新增頁面";
}

-(void)pressBtnback:(id)sender{
    if(self.pageRecord){
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)pressBtnInfoClose:(id)sender{
    [[utilityManager alloc] popupAnimation:self.info isOpen:NO];
}

-(void)pressBtninfo:(id)sender{
    [self.info resetView];
    [[utilityManager alloc] popupAnimation:self.info isOpen:YES];
}

-(IBAction)pressBtnSelVideo:(id)sender{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.mediaTypes = [[NSArray alloc] initWithObjects:(NSString *)kUTTypeMovie, nil];
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)pressBtnPlay:(id)sender{
    vc_PopupVideo *temp1 = [[vc_PopupVideo alloc] init];
    [self presentViewController:temp1 animated:FALSE completion:nil];
    temp1.url = [[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO];
    [temp1 startup];
}

-(void)setViewUI{
    fontManager *font = [[fontManager alloc] init];
    self.btn_saveNpage.titleLabel.font = self.btn_selVideo.titleLabel.font = self.btn_saveNquit.titleLabel.font = [font getBoldsize:[font getSettingFont:@"Contact"]];
    [self.btn_saveNpage setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNpage setTitle:@"儲存及加頁" forState:UIControlStateNormal];
    [self.btn_saveNquit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNquit setTitle:@"儲存及離開" forState:UIControlStateNormal];
    [self.btn_selVideo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_selVideo setTitle:@"選擇影片" forState:UIControlStateNormal];
    
    self.iv_videoThumb.layer.cornerRadius=8.0f;
    self.iv_videoThumb.layer.masksToBounds=YES;
    self.iv_videoThumb.layer.borderColor=[[UIColor colorWithRed:112.0/255.0 green:198.0/255.0 blue:221.0/255.0 alpha:1.0] CGColor];
    self.iv_videoThumb.layer.borderWidth= 0.0f;
    
    [self.btn_selVideo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_play setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNquit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_saveNpage setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}

-(IBAction)pressBtnSaveNPage:(id)sender{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.square = YES;
    hud.label.text = NSLocalizedString(@"Loading", @"Loading");
    [hud showAnimated:YES];
    
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    utilityManager *utility = [[utilityManager alloc] init];
    albumPageObj *obj = (albumPageObj*) self.record;
    NSString *videoPath = @"";
    NSString *videoTime = @"";
    NSString *pageStatus = @"S";
    if(app.mediaArray != nil)
    {
        [app.mediaArray removeAllObjects];
    }
    if(self.iv_videoThumb.image != nil){
        NSMutableDictionary *dict = [NSMutableDictionary new];
        [dict setValue:[[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict setValue:FILENAME forKey:@"fileName"];
        [dict setValue:[utility fileExtension:[utility getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO]] forKey:@"fileType"];
        [dict setValue:@"video" forKey:@"paramKey"];
        [app.mediaArray addObject:dict];
        NSMutableDictionary *dict1 = [NSMutableDictionary new];
        [dict1 setValue:[[utilityManager alloc] getDataFilePath:THUMBFILENAME folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict1 setValue:THUMBFILENAME forKey:@"fileName"];
        [dict1 setValue:[utility fileExtension:[utility getDataFilePath:THUMBFILENAME folderName:@"temp" isDoucmentFolder:NO]] forKey:@"fileType"];
        [dict1 setValue:@"videoThumb" forKey:@"paramKey"];
        [app.mediaArray addObject:dict1];
        videoPath = FILENAME;
    }
    if(self.pageRecord){
        self.btn_saveNquit.enabled = NO;
        self.btn_saveNpage.enabled = NO;
        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
        if(![objPage.user_id isEqualToString:objPage.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_AL_PG",@"action",@"",@"description",@"0",@"posType",@"",@"imagePath",@"",@"audioPath",FILENAME,@"videoPath",THUMBFILENAME,@"videoThumb",videoTime,@"residenceTime",objPage.user_id,@"user_id",objPage.albumID,@"albumID",objPage.pageType,@"pageType",objPage.createByID,@"createByID",objPage.pageTitle,@"pageTitle",objPage.pageID,@"albumPageID",pageStatus,@"pageStatus", nil];
        [self upload:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                //                [utility removeFile:THUMBFILENAME folderName:@"temp" isDoucmentFolder:NO];
                //                [utility removeFile:FILENAME folderName:@"temp" isDoucmentFolder:NO];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNpage.enabled = YES;
                self.btn_saveNquit.enabled = YES;
            }
            [hud hideAnimated:YES];
        }];
    }
    else{
        self.btn_saveNquit.enabled = NO;
        self.btn_saveNpage.enabled = NO;
        if(![obj.user_id isEqualToString:obj.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"INSERT_AL_PG",@"action",@"",@"description",@"0",@"posType",@"",@"imagePath",@"",@"audioPath",FILENAME,@"videoPath",THUMBFILENAME,@"videoThumb",videoTime,@"residenceTime",obj.user_id,@"user_id",obj.albumID,@"albumID",obj.pageType,@"pageType",obj.createByID,@"createByID",obj.pageTitle,@"pageTitle",pageStatus,@"pageStatus", nil];
        [self upload:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                [utility removeFile:THUMBFILENAME folderName:@"temp" isDoucmentFolder:NO];
                [utility removeFile:FILENAME folderName:@"temp" isDoucmentFolder:NO];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNpage.enabled = YES;
                self.btn_saveNquit.enabled = YES;
            }
            [hud hideAnimated:YES];
        }];
    }
}
- (void)upload:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
//    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
//    NSError *error;
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    AFJSONRequestSerializer *serializer = [AFJSONRequestSerializer serializer];
    //    serializer.timeoutInterval= [[[NSUserDefaults standardUserDefaults] valueForKey:@"timeoutInterval"] longValue];
    //    [serializer setTimeoutInterval:10000];
    //    [serializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    //    [serializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    //    manager.requestSerializer = serializer;
    //    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager POST:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if([imageArray count]>0){
            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[imageArray count];i++){
                NSMutableDictionary *dict = [imageArray objectAtIndex:i];
                [formData appendPartWithFileData:[utility getDataFileByPath:[dict objectForKey:@"file"]] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"fileName"] mimeType:[dict objectForKey:@"fileType"]];
            }
        }
    }  progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                 options:kNilOptions
                                                                   error:nil];
        if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
        {
            NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
            if([jsonArray count] > 0){
                NSDictionary* json = [jsonArray objectAtIndex:0];
                completionBlock(true,json);
            }
            else{
                completionBlock(true,nil);
            }
        }
        else{
            completionBlock(false,jsonDict);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"Error: %@", error);
        completionBlock(false,nil);
    }];
}

-(void) uploadFile:(NSString *)urlStr parameters:(NSDictionary *)parametersDictionary images:(NSMutableArray *)imageArray completionHandler:(void (^)(bool, NSDictionary*))completionBlock{
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",SERVER_HOST,urlStr]];
    NSMutableArray *ary = [[NSMutableArray alloc] init];
    [ary addObject:parametersDictionary];
    
    NSData *convertDictToJson = [NSJSONSerialization dataWithJSONObject:ary
                                                                options:0
                                                                  error:nil];
    NSString *convertDictjsonString = [[NSString alloc] initWithData:convertDictToJson encoding:NSUTF8StringEncoding];
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:convertDictjsonString,@"DATA",nil];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:URL.absoluteString parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if([app.mediaArray count]>0){
//            utilityManager *utility = [[utilityManager alloc] init];
            for(int i = 0;i<[app.mediaArray count];i++){
                NSMutableDictionary *dict = [app.mediaArray objectAtIndex:i];
                [formData appendPartWithFileData:[dict objectForKey:@"file"] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"fileName"] mimeType:[dict objectForKey:@"fileType"]];
                //                [formData appendPartWithFileData:[dict objectForKey:@"file"] name:[dict objectForKey:@"paramKey"] fileName:[dict objectForKey:@"fileName"] mimeType:@"multipart/form-data"];
                
            }
        }
    } error:nil];
    [request setTimeoutInterval:300];
    NSURLSessionConfiguration* config = [NSURLSessionConfiguration defaultSessionConfiguration];
    config.timeoutIntervalForRequest = 10000.0;
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:config];
    NSURLSessionUploadTask *uploadTask;
    uploadTask = [manager
                  uploadTaskWithStreamedRequest:request
                  progress:^(NSProgress * _Nonnull uploadProgress) {
                      
                      // This is not called back on the main queue.
                      // You are responsible for dispatching to the main queue for UI updates
                      dispatch_async(dispatch_get_main_queue(), ^{
                          //Update the progress view
                          //                          [progressView setProgress:uploadProgress.fractionCompleted];
                      });
                  }
                  completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
                      if (error) {
                          NSLog(@"Error: %@", error);
                          completionBlock(false,nil);
                      } else {
                          NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                   options:kNilOptions
                                                                                     error:&error];
                          if([[jsonDict objectForKey:@"status"] isEqualToString:@"success"])
                          {
                              NSMutableArray* jsonArray = [jsonDict objectForKey:@"data"];
                              if([jsonArray count] > 0){
                                  NSDictionary* json = [jsonArray objectAtIndex:0];
                                  completionBlock(true,json);
                              }
                              else{
                                  completionBlock(true,nil);
                              }
                          }
                          else{
                              completionBlock(false,jsonDict);
                          }
                      }
                  }];
    
    [uploadTask resume];
}


-(IBAction)pressBtnSaveNQuit:(id)sender{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.square = YES;
    hud.label.text = NSLocalizedString(@"Loading", @"Loading");
    [hud showAnimated:YES];
    
    AppDelegate *app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    utilityManager *utility = [[utilityManager alloc] init];
    albumPageObj *obj = (albumPageObj*) self.record;
    NSString *videoPath = @"";
    NSString *videoTime = @"";
    NSString *pageStatus = @"S";
    if(app.mediaArray != nil)
    {
        [app.mediaArray removeAllObjects];
    }
    if(self.iv_videoThumb.image != nil){
        NSMutableDictionary *dict = [NSMutableDictionary new];
        [dict setValue:[[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict setValue:FILENAME forKey:@"fileName"];
        [dict setValue:[utility fileMIMEType:[utility getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO]] forKey:@"fileType"];
        [dict setValue:@"video" forKey:@"paramKey"];
        [app.mediaArray addObject:dict];
        NSMutableDictionary *dict1 = [NSMutableDictionary new];
        [dict1 setValue:[[utilityManager alloc] getDataFilePath:THUMBFILENAME folderName:@"temp" isDoucmentFolder:NO] forKey:@"file"];
        [dict1 setValue:THUMBFILENAME forKey:@"fileName"];
        [dict1 setValue:[utility fileMIMEType:[utility getDataFilePath:THUMBFILENAME folderName:@"temp" isDoucmentFolder:NO]] forKey:@"fileType"];
        [dict1 setValue:@"videoThumb" forKey:@"paramKey"];
        [app.mediaArray addObject:dict1];
        videoPath = FILENAME;
    }
    if(self.pageRecord){
        self.btn_saveNquit.enabled = NO;
        self.btn_saveNpage.enabled = NO;

        albumPageObj *objPage = (albumPageObj*)self.pageRecord;
        if(![objPage.user_id isEqualToString:objPage.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"UPDATE_AL_PG",@"action",@"",@"description",@"0",@"posType",@"",@"imagePath",@"",@"audioPath",FILENAME,@"videoPath",THUMBFILENAME,@"videoThumb",videoTime,@"residenceTime",objPage.user_id,@"user_id",objPage.albumID,@"albumID",objPage.pageType,@"pageType",objPage.createByID,@"createByID",objPage.pageTitle,@"pageTitle",objPage.pageID,@"albumPageID",pageStatus,@"pageStatus", nil];
        [self upload:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                [self dismissViewControllerAnimated:YES completion:^{}];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNpage.enabled = YES;
                self.btn_saveNquit.enabled = YES;
            }
            [hud hideAnimated:YES];
        }];
    }
    else{
        self.btn_saveNquit.enabled = NO;
        self.btn_saveNpage.enabled = NO;
        if(![obj.user_id isEqualToString:obj.createByID]){
            pageStatus = @"P";
        }
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"INSERT_AL_PG",@"action",@"",@"description",@"0",@"posType",@"",@"imagePath",@"",@"audioPath",FILENAME,@"videoPath",THUMBFILENAME,@"videoThumb",videoTime,@"residenceTime",obj.user_id,@"user_id",obj.albumID,@"albumID",obj.pageType,@"pageType",obj.createByID,@"createByID",obj.pageTitle,@"pageTitle",pageStatus,@"pageStatus", nil];
        [self upload:ALBUM_PAGE_HANDLER parameters:dict images:app.mediaArray completionHandler:^(bool status, NSDictionary *jsonDict) {
            if(status){
                [self dismissViewControllerAnimated:YES completion:^{}];
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[jsonDict objectForKey:@"error_title"] message:[jsonDict objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"關閉" otherButtonTitles: nil];
                [alert show];
                self.btn_saveNpage.enabled = YES;
                self.btn_saveNquit.enabled = YES;                
            }
            [hud hideAnimated:YES];
        }];
        
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];
    NSData *videoData = [NSData dataWithContentsOfURL:videoURL];
    if([[utilityManager alloc] saveDataFile:videoData Filename:@"videoFile" filetype:@"mp4" folderName:@"temp" isDoucmentFolder:NO]){
        UIImage *img = [[utilityManager alloc] getVideoThumbnailImage:[[utilityManager alloc] getDataFilePath:FILENAME folderName:@"temp" isDoucmentFolder:NO]];
        self.iv_videoThumb.image = img;
        NSData *imageData = [UIImage convertImageToLowJPEG:img];
        if([[utilityManager alloc] saveDataFile:imageData Filename:THUMB filetype:[UIImage extensionForImageData:imageData] folderName:@"temp" isDoucmentFolder:NO])
        {
        }
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
