//
//  registerStep4ViewController.m
//  AngeLink
//
//  Created by kanhan on 3/10/2016.
//  Copyright © 2016 kanhan. All rights reserved.
//

#import "registerStep4ViewController.h"
#import "pushViewController.h"

@interface registerStep4ViewController ()

@end

@implementation registerStep4ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setFontUI];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) setFontUI{
    fontManager *font = [[fontManager alloc] init];
    self.lbl_Tittle.font = self.lbl_selectAllTittle.font = [font getRegularsize:[font getSettingFont:@"Contact"]];
    [self.btn_selectAll.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Title"]]];
    [self.btn_selectAll setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

    [self.btn_cusSelect.titleLabel setFont:[font getBoldsize:[font getSettingFont:@"Contact"]]];
    [self.btn_cusSelect setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    self.lbl_Tittle.text = @"通知設定";
    self.lbl_selectAllTittle.text = @"開啟所有通知";
    [self.btn_cusSelect setTitle:@"自訂" forState:UIControlStateNormal];
    [self.btn_selectAll setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.btn_cusSelect setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

-(IBAction)pressBtnselectAllPush:(id)sender{
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:[[utilityManager alloc] getUserDefaultstoString:@"memberID"],@"user_id",@"1",@"enable", nil];
    [[connectionManager alloc] postRequest:UPDATE_ALL_SETTING parameters:dict completionHandler:^(bool status, NSDictionary *jsonDict) {
        if(status)
        {
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                     bundle: nil];
            
            UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"facebookViewController"];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }];
}

-(IBAction)pressBtncustom:(id)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    pushViewController *vc = (pushViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"pushViewController"];
    vc.preView = self;
    [self presentViewController:vc animated:YES completion:NULL];
}

-(IBAction)pressBtnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void) callBackFunction{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"facebookViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [self setFontUI];
}


@end
