//
//  ResourceListData.h
//  dementia
//
//

#import <Foundation/Foundation.h>

@interface ResourceListData : NSObject

@property (strong, nonatomic) NSString *resourceTitle;

- (id)initWithData:(NSString *)data;

@end
