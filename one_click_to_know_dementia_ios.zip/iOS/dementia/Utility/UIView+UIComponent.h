//
//  UIView+UIComponent.h
//
//

#import <UIKit/UIKit.h>

@interface UIView (UIComponent)

- (void)setTextFieldEdge;

- (void)addUnderlineToText;
    
@end
