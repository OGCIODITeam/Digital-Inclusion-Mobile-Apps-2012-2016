//
//  KnowledgeDetailViewController.h
//  dementia
//
//

#import "BaseViewController.h"

@interface KnowledgeDetailViewController : BaseViewController <UIWebViewDelegate>

@property (strong, nonatomic) NSDictionary *detailDict;

@end
