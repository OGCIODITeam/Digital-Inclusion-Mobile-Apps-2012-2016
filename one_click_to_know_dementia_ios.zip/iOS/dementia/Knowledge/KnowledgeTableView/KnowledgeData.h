//
//  KnowledgeData.h
//  dementia
//
//

#import <Foundation/Foundation.h>

@interface KnowledgeData : NSObject

@property (strong, nonatomic) NSString *knowledgeTitle;

- (id)initWithData:(NSString *)data;

@end
