//
//  UINavigationItem+iOS7Spacing.h
//
//  Created by Marius Kažemėkaitis on 2013-10-11.
//  Copyright (c) 2013 Lemon Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UINavigationItem (iOS7Spacing)

@end
