//
//  InitialSlidingViewController.h
//  dementia
//
//

#import "ECSlidingViewController.h"

@interface InitialSlidingViewController : ECSlidingViewController

@end
