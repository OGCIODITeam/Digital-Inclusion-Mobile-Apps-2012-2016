//
//  DrawerHeaderCell.h
//  dementia
//
//

#import <UIKit/UIKit.h>

@interface DrawerHeaderCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *myLocationMark;

@end
