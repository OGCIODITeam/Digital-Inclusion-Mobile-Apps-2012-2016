//
//  BaseViewController.h
//  dementia
//
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
