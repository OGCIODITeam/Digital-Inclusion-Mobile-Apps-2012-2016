package com.mofinity.bean;

public class ActivityBean {

	private String name;
	private Class<?> cls;
	private String[] types;
	private String meta;
	private String detail;
	private String imageUrl;
	private int id;
	private String sid;
	
	public ActivityBean(Class<?> cls, int id, String sid, String name, String[] types, String meta, String detail, String imageUrl){
		this.name = name;
		this.id = id;
		this.cls = cls;
		this.sid = sid;
		if (types != null){
			this.types = new String[types.length];
			for (int i=0; i< types.length; i++){
				this.types[i] = types[i];
			}
		}
		this.meta = meta;
		this.detail = detail;
		this.imageUrl = imageUrl;
	}

	public ActivityBean(Class<?> cls, int id, String name, String[] types, String meta, String detail, String imageUrl){
		this.name = name;
		this.id = id;
		this.cls = cls;
		if (types != null){
			this.types = new String[types.length];
			for (int i=0; i< types.length; i++){
				this.types[i] = types[i];
			}
		}
		this.meta = meta;
		this.detail = detail;
		this.imageUrl = imageUrl;
	}

	public String getSid(){
		return sid;
	}
	
	public int getId(){
		return id;
	}

	public String getName() {
		return name;
	}

	public Class<?> getActivityClass() {
		return cls;
	}
	
	public String toString(){
		return name;
	}
	
	public String[] getTypes(){
		return types;
	}
	
	public String getMeta() {
		return meta;
	}
	
	public String getDetail(){
		return detail;
	}
	
	public String getImageUrl(){
		return imageUrl;
	}
	
}
