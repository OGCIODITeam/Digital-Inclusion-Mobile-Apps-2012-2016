package com.mofinity.bean;

import java.io.Serializable;


public class TblSpeechBean implements Serializable {

	public int  seq;
	public String speechType, speechId, pronunciation, text, textZh, textNe, textUr;
	
	public TblSpeechBean(){	
	}
	
	public TblSpeechBean(String speechId, String speechType, int seq, String pronunciation, String text, String textZh, String textNe, String textUr ){
		this.speechId=speechId;
		this.seq = seq;
		this.speechType=speechType;
		this.pronunciation=pronunciation;
		this.text=text;
		this.textZh=textZh;
		this.textNe=textNe;
		this.textUr=textUr;
	}	
}
