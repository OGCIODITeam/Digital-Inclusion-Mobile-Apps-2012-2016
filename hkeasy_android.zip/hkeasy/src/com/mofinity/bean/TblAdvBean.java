package com.mofinity.bean;


public class TblAdvBean {
	
	public int advId;
	public String advType;
	public String imageUrl;
	public String imageUrlZh;
	public String imageUrlNe;
	public String imageUrlUd;
	public String link;
	public String linkZh;
	public String linkNe;
	public String linkUd;
	
		
	public TblAdvBean() {
		
	}
	public TblAdvBean(int advId, String advType, String imageUrl, String imageUrlZh, 
			String imageUrlNe, String imageUrlUd, String link, String linkZh,
			String linkNe, String linkUd){
		this.advId=advId;
		this.advType=advType;
		this.imageUrl=imageUrl;
		this.imageUrlZh=imageUrlZh;
		this.imageUrlNe=imageUrlNe;
		this.imageUrlUd=imageUrlUd;
		this.link=link;
		this.linkZh=linkZh;
		this.linkNe=linkNe;
		this.linkUd=linkUd;
	}

}
