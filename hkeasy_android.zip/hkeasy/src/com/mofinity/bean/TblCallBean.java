/*
 * Copyright Mofinity Limited 2012 - 2013
 * 
 * All rights are reserved.
 * 
 * TblCallBean.java
 *
 * Created by appladm on 2013-08-01 v12.0.571
 */

package com.mofinity.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class TblCallBean implements Serializable {
	private static org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TblCallBean.class);

	int callId;
	String callType;
	int seq;
	String title;
	String titleZh;
	String phoneNo;
	Timestamp dateModified;
	String modifiedBy;


	public TblCallBean(
			int callId,
			String callType,
			int seq,
			String title,
			String titleZh,
			String phoneNo,
			Timestamp dateModified,
			String modifiedBy) {
		this.callId = callId;
		this.callType = callType;
		this.seq = seq;
		this.title = title;
		this.titleZh = titleZh;
		this.phoneNo = phoneNo;
		this.dateModified = dateModified;
		this.modifiedBy = modifiedBy;
	}

	public TblCallBean(
			int callId) {
		this.callId = callId;
	}

	public TblCallBean() {}

	public void setCallId(int callId) { this.callId = callId; }
	public void setCallType(String callType) { this.callType = callType; }
	public void setSeq(int seq) { this.seq = seq; }
	public void setTitle(String title) { this.title = title; }
	public void setTitleZh(String titleZh) { this.titleZh = titleZh; }
	public void setPhoneNo(String phoneNo) { this.phoneNo = phoneNo; }
	public void setDateModified(Timestamp dateModified) { this.dateModified = dateModified; }
	public void setModifiedBy(String modifiedBy) { this.modifiedBy = modifiedBy; }

	public int getCallId() { return callId; }
	public String getCallType() { return callType; }
	public int getSeq() { return seq; }
	public String getTitle() { return title; }
	public String getTitleZh() { return titleZh; }
	public String getPhoneNo() { return phoneNo; }
	public Timestamp getDateModified() { return dateModified; }
	public String getModifiedBy() { return modifiedBy; }

	public static int maxCallId() { return 11; }
	public static int maxCallType() { return 1; }
	public static int maxSeq() { return 11; }
	public static int maxTitle() { return 255; }
	public static int maxTitleZh() { return 255; }
	public static int maxTitleNe() { return 255; }
	public static int maxTitleUd() { return 255; }
	public static int maxPhoneNo() { return 200; }
	public static int maxDateModified() { return 34; }
	public static int maxModifiedBy() { return 20; }

	public static int minCallId() { return 1; }
	public static int minCallType() { return 1; }
	public static int minSeq() { return 1; }
	public static int minTitle() { return 1; }
	public static int minTitleZh() { return 0; }
	public static int minTitleNe() { return 0; }
	public static int minTitleUd() { return 0; }
	public static int minPhoneNo() { return 0; }
	public static int minDateModified() { return 0; }
	public static int minModifiedBy() { return 0; }

	public String toTableName() { return "tbl_call"; }
	public String toShortName() { return "call"; }
	public String toString() { return "" + "callId:" +callId+ " "; }

	public java.util.HashMap<String, Object> toKeyMap() {
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
		m.put("callId", callId);
		return m;
	}

	public java.util.HashMap<String, Object> toMap() {
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
		m.put("callId", callId);
		m.put("callType", callType);
		m.put("seq", seq);
		m.put("title", title);
		m.put("titleZh", titleZh);
		m.put("phoneNo", phoneNo);
		m.put("dateModified", dateModified);
		m.put("modifiedBy", modifiedBy);
		return m;
	}

	public TblCallBean empty() {
		TblCallBean target = new TblCallBean();
		return target;
	}

	public boolean copy(TblCallBean source) {
		if ( source == null ) {
			log.warn("null parameter value");
			return false;
		}
		setCallId(source.getCallId());
		setCallType(source.getCallType());
		setSeq(source.getSeq());
		setTitle(source.getTitle());
		setTitleZh(source.getTitleZh());
		setPhoneNo(source.getPhoneNo());
		setDateModified(source.getDateModified());
		setModifiedBy(source.getModifiedBy());
		return true;
	}

	public TblCallBean clone() {
		TblCallBean target = new TblCallBean();
		target.setCallId(getCallId());
		target.setCallType(getCallType());
		target.setSeq(getSeq());
		target.setTitle(getTitle());
		target.setTitleZh(getTitleZh());
		target.setPhoneNo(getPhoneNo());
		target.setDateModified(getDateModified());
		target.setModifiedBy(getModifiedBy());
		return target;
	}

	public int compareTo(Object o) {
		if ( o == null || !(o instanceof TblCallBean) ) return 1;
		TblCallBean bean = (TblCallBean)o;
		if (this.callId!=bean.callId) return -1;
		return 0;
	}

	public boolean equals(Object o) {
		if ( o == null || !(o instanceof TblCallBean) ) return false;
		TblCallBean bean = (TblCallBean)o;
		if (this.callId!=bean.callId) return false;
		return true;
	}


}
