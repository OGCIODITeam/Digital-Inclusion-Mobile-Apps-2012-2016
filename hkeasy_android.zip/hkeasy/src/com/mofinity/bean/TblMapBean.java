/*
 * Copyright Mofinity Limited 2012 - 2013
 * 
 * All rights are reserved.
 * 
 * TblMapBean.java
 *
 * Created by appladm on 2013-08-01 v12.0.571
 */

package com.mofinity.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class TblMapBean implements Serializable {
	private static org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(TblMapBean.class);

	int mapId;
	String mapType;
	int seq;
	String name;
	String nameZh;
	String address;
	String addressZh;
	String district;
	String phoneNo;
	String remark;
	double mapX;
	double mapY;
	Timestamp dateModified;
	String modifiedBy;


	public TblMapBean(
			int mapId,
			String mapType,
			int seq,
			String name,
			String nameZh,
			String address,
			String addressZh,
			String district,
			String phoneNo,
			String remark,
			double mapX,
			double mapY,
			Timestamp dateModified,
			String modifiedBy) {
		this.mapId = mapId;
		this.mapType = mapType;
		this.seq = seq;
		this.name = name;
		this.nameZh = nameZh;
		this.address = address;
		this.addressZh = addressZh;
		this.district = district;
		this.phoneNo = phoneNo;
		this.remark = remark;
		this.mapX = mapX;
		this.mapY = mapY;
		this.dateModified = dateModified;
		this.modifiedBy = modifiedBy;
	}

	public TblMapBean(
			int mapId) {
		this.mapId = mapId;
	}

	public TblMapBean() {}

	public void setMapId(int mapId) { this.mapId = mapId; }
	public void setMapType(String mapType) { this.mapType = mapType; }
	public void setSeq(int seq) { this.seq = seq; }
	public void setName(String name) { this.name = name; }
	public void setNameZh(String nameZh) { this.nameZh = nameZh; }
	public void setAddress(String address) { this.address = address; }
	public void setAddressZh(String addressZh) { this.addressZh = addressZh; }
	public void setDistrict(String district) { this.district = district; }
	public void setPhoneNo(String phoneNo) { this.phoneNo = phoneNo; }
	public void setRemark(String remark) { this.remark = remark; }
	public void setMapX(double mapX) { this.mapX = mapX; }
	public void setMapY(double mapY) { this.mapY = mapY; }
	public void setDateModified(Timestamp dateModified) { this.dateModified = dateModified; }
	public void setModifiedBy(String modifiedBy) { this.modifiedBy = modifiedBy; }

	public int getMapId() { return mapId; }
	public String getMapType() { return mapType; }
	public int getSeq() { return seq; }
	public String getName() { return name; }
	public String getNameZh() { return nameZh; }
	public String getAddress() { return address; }
	public String getAddressZh() { return addressZh; }
	public String getDistrict() { return district; }
	public String getPhoneNo() { return phoneNo; }
	public String getRemark() { return remark; }
	public double getMapX() { return mapX; }
	public double getMapY() { return mapY; }
	public Timestamp getDateModified() { return dateModified; }
	public String getModifiedBy() { return modifiedBy; }

	public static int maxMapId() { return 11; }
	public static int maxMapType() { return 1; }
	public static int maxSeq() { return 11; }
	public static int maxName() { return 255; }
	public static int maxNameZh() { return 255; }
	public static int maxNameNe() { return 255; }
	public static int maxNameUd() { return 255; }
	public static int maxAddress() { return 1024; }
	public static int maxAddressZh() { return 1024; }
	public static int maxDistrict() { return 1024; }
	public static int maxAddressUd() { return 1024; }
	public static int maxPhoneNo() { return 200; }
	public static int maxRemark() { return 255; }
	public static int maxMapX() { return 14; }
	public static int maxMapY() { return 14; }
	public static int maxDateModified() { return 34; }
	public static int maxModifiedBy() { return 20; }

	public static int minMapId() { return 1; }
	public static int minMapType() { return 1; }
	public static int minSeq() { return 1; }
	public static int minName() { return 0; }
	public static int minNameZh() { return 0; }
	public static int minNameNe() { return 0; }
	public static int minNameUd() { return 0; }
	public static int minAddress() { return 0; }
	public static int minAddressZh() { return 0; }
	public static int minDistrict() { return 0; }
	public static int minAddressUd() { return 0; }
	public static int minPhoneNo() { return 0; }
	public static int minRemark() { return 0; }
	public static int minMapX() { return 0; }
	public static int minMapY() { return 0; }
	public static int minDateModified() { return 0; }
	public static int minModifiedBy() { return 0; }

	public String toTableName() { return "tbl_map"; }
	public String toShortName() { return "map"; }
	public String toString() { return "" + "mapId:" +mapId+ " "; }

	public java.util.HashMap<String, Object> toKeyMap() {
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
		m.put("mapId", mapId);
		return m;
	}

	public java.util.HashMap<String, Object> toMap() {
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
		m.put("mapId", mapId);
		m.put("mapType", mapType);
		m.put("seq", seq);
		m.put("name", name);
		m.put("nameZh", nameZh);
		m.put("address", address);
		m.put("addressZh", addressZh);
		m.put("district", district);
		m.put("phoneNo", phoneNo);
		m.put("remark", remark);
		m.put("mapX", mapX);
		m.put("mapY", mapY);
		m.put("dateModified", dateModified);
		m.put("modifiedBy", modifiedBy);
		return m;
	}


	public TblMapBean empty() {
		TblMapBean target = new TblMapBean();
		return target;
	}

	public boolean copy(TblMapBean source) {
		if ( source == null ) {
			log.warn("null parameter value");
			return false;
		}
		setMapId(source.getMapId());
		setMapType(source.getMapType());
		setSeq(source.getSeq());
		setName(source.getName());
		setNameZh(source.getNameZh());
		setAddress(source.getAddress());
		setAddressZh(source.getAddressZh());
		setDistrict(source.getDistrict());
		setPhoneNo(source.getPhoneNo());
		setRemark(source.getRemark());
		setMapX(source.getMapX());
		setMapY(source.getMapY());
		setDateModified(source.getDateModified());
		setModifiedBy(source.getModifiedBy());
		return true;
	}

	public TblMapBean clone() {
		TblMapBean target = new TblMapBean();
		target.setMapId(getMapId());
		target.setMapType(getMapType());
		target.setSeq(getSeq());
		target.setName(getName());
		target.setNameZh(getNameZh());
		target.setAddress(getAddress());
		target.setAddressZh(getAddressZh());
		target.setDistrict(getDistrict());
		target.setPhoneNo(getPhoneNo());
		target.setRemark(getRemark());
		target.setMapX(getMapX());
		target.setMapY(getMapY());
		target.setDateModified(getDateModified());
		target.setModifiedBy(getModifiedBy());
		return target;
	}

	public int compareTo(Object o) {
		if ( o == null || !(o instanceof TblMapBean) ) return 1;
		TblMapBean bean = (TblMapBean)o;
		if (this.mapId!=bean.mapId) return -1;
		return 0;
	}

	public boolean equals(Object o) {
		if ( o == null || !(o instanceof TblMapBean) ) return false;
		TblMapBean bean = (TblMapBean)o;
		if (this.mapId!=bean.mapId) return false;
		return true;
	}


}
