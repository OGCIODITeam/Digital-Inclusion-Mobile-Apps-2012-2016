/*
 * Copyright Mofinity Limited 2012 - 2013
 * 
 * All rights are reserved.
 * 
 * TblLinkBean.java
 *
 * Created by appladm on 2013-08-01 v12.0.571
 */

package com.mofinity.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import org.slf4j.Logger;

public class TblLinkBean implements Serializable {
	private static Logger log = org.slf4j.LoggerFactory.getLogger(TblLinkBean.class);

	String link;
	int seq;
	String description;
	String descriptionZh;
	Timestamp dateModified;
	String modifiedBy;


	public TblLinkBean(
			String link,
			int seq,
			String description,
			String descriptionZh,
			Timestamp dateModified,
			String modifiedBy) {
		this.link = link;
		this.seq = seq;
		this.description = description;
		this.descriptionZh = descriptionZh;
		this.dateModified = dateModified;
		this.modifiedBy = modifiedBy;
	}

	public TblLinkBean(
			String link) {
		this.link = link;
	}

	public TblLinkBean() {}

	public void setLink(String link) { this.link = link; }
	public void setSeq(int seq) { this.seq = seq; }
	public void setDescription(String description) { this.description = description; }
	public void setDescriptionZh(String descriptionZh) { this.descriptionZh = descriptionZh; }
	public void setDateModified(Timestamp dateModified) { this.dateModified = dateModified; }
	public void setModifiedBy(String modifiedBy) { this.modifiedBy = modifiedBy; }

	public String getLink() { return link; }
	public int getSeq() { return seq; }
	public String getDescription() { return description; }
	public String getDescriptionZh() { return descriptionZh; }
	public Timestamp getDateModified() { return dateModified; }
	public String getModifiedBy() { return modifiedBy; }

	public static int maxLink() { return 255; }
	public static int maxSeq() { return 11; }
	public static int maxDescription() { return 1024; }
	public static int maxDescriptionZh() { return 1024; }
	public static int maxDescriptionNe() { return 1024; }
	public static int maxDescriptionUd() { return 1024; }
	public static int maxDateModified() { return 34; }
	public static int maxModifiedBy() { return 20; }

	public static int minLink() { return 1; }
	public static int minSeq() { return 1; }
	public static int minDescription() { return 1; }
	public static int minDescriptionZh() { return 0; }
	public static int minDescriptionNe() { return 0; }
	public static int minDescriptionUd() { return 0; }
	public static int minDateModified() { return 0; }
	public static int minModifiedBy() { return 0; }

	public String toTableName() { return "tbl_link"; }
	public String toShortName() { return "link"; }
	public String toString() { return "" + "link:" +link+ " "; }

	public java.util.HashMap<String, Object> toKeyMap() {
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
		m.put("link", link);
		return m;
	}

	public java.util.HashMap<String, Object> toMap() {
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
		m.put("link", link);
		m.put("seq", seq);
		m.put("description", description);
		m.put("descriptionZh", descriptionZh);
		m.put("dateModified", dateModified);
		m.put("modifiedBy", modifiedBy);
		return m;
	}

	public TblLinkBean empty() {
		TblLinkBean target = new TblLinkBean();
		return target;
	}

	public boolean copy(TblLinkBean source) {
		if ( source == null ) {
			log.warn("null parameter value");
			return false;
		}
		setLink(source.getLink());
		setSeq(source.getSeq());
		setDescription(source.getDescription());
		setDescriptionZh(source.getDescriptionZh());
		setDateModified(source.getDateModified());
		setModifiedBy(source.getModifiedBy());
		return true;
	}

	public TblLinkBean clone() {
		TblLinkBean target = new TblLinkBean();
		target.setLink(getLink());
		target.setSeq(getSeq());
		target.setDescription(getDescription());
		target.setDescriptionZh(getDescriptionZh());
		target.setDateModified(getDateModified());
		target.setModifiedBy(getModifiedBy());
		return target;
	}

	public int compareTo(Object o) {
		if ( o == null || !(o instanceof TblLinkBean) ) return 1;
		TblLinkBean bean = (TblLinkBean)o;
		if (this.link==null || this.link.compareTo(bean.link)!=0) return -1;
		return 0;
	}

	public boolean equals(Object o) {
		if ( o == null || !(o instanceof TblLinkBean) ) return false;
		TblLinkBean bean = (TblLinkBean)o;
		if (this.link==null || !this.link.equals(bean.link)) return false;
		return true;
	}


}
