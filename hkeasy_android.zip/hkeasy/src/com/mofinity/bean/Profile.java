package com.mofinity.bean;

import java.io.Serializable;

import android.content.Context;
import android.util.Log;

import com.mofinity.util.StoreObj;

public class Profile implements Serializable {
	private static String filename="mof_cws";
	private static String lang = "en";
	private static String ver="1.1.36";
	public static Profile profile=null;
	
	public String language = "";
	//public String server_link="http://192.168.91.11:80";
	//public String forum_link = "http://192.168.91.11:80";
	public String server_link="http://hk.mofinity.com:9080";
	public String forum_link = "http://hk.mofinity.com:9080";
	//public String server_link="http://103.25.74.238:9080";
	//public String forum_link = "http://103.25.74.238:9080";
	
	public String dbDownload=server_link + "/hke/sqlite3/hke.db";
	public String soundDownload=server_link + "/hke/mp3/";
	public String versioncheck=server_link + "/hke/data_version.php";
	public String email="ylfesc@yang.org.hk";
	public String marketUrl="market://details?id=com.mofinity.hkeasy";
	public String forumUrl = forum_link + "/bb3/";
	public String termsUrl = server_link + "/hke/others/terms.html";
	public String aboutUrl = server_link + "/hke/others/about.html";
	public String usefulinfo = server_link + "/hke/others/useful.php";
	public String urlFbShareLink = "https://play.google.com/store/apps/details?id=com.mofinity.hkeasy";
	public String logoUrl = server_link + "/hke/image/hkeasy.gif";
	
	public double lng=22.269290, lat=114.236239;
	
	public static void setLanguage(String _lang){
		lang = _lang;
	}
	
	public static String getLanguage(){
		return lang;
	}
	
	public static boolean isEnglish(){
		return "en".equals(lang);
	}
	
	public static void setVersion(String _ver){
		ver = _ver;
	}
	
	public static String getVersion(){
		return ver;
	}
	
    // static function starts.
    public static void storeProfile(Context ctx, Serializable profile){
    	StoreObj.storeObject(ctx, profile, filename);
    }
    
    public static Profile loadProfile(Context ctx){
    	if (profile == null ){
    		profile = (Profile)StoreObj.readObject(ctx, filename);
    		Log.i("Profile","Reload lar:"+profile);
    		if (profile == null) {
    			profile = new Profile();
    		}
    	} 
    	return profile;
    }
    
}
