package com.mofinity.bean;



public class CachProfile {
	public static boolean menu_reload = false;
	public static boolean setting_reload = false;
	public static String search_words="";
}
