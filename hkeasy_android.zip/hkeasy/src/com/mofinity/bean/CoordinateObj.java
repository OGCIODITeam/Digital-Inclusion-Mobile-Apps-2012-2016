package com.mofinity.bean;

import java.io.Serializable;


public class CoordinateObj implements Serializable {

	private int top=0, left=0;
	
	public CoordinateObj(int itop, int ileft){
		top = itop;
		left = ileft;
	}
	public int[] getCoordinate(){
		return new int[] {top, left};
	}
	
}
