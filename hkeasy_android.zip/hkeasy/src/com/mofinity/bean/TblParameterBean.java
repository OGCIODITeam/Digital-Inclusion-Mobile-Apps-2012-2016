package com.mofinity.bean;

import java.io.Serializable;


public class TblParameterBean implements Serializable {

	public int seq;
	public String name1, name2, value1, value2, description, descriptionZh, descriptionNe, descriptionUr, remark;
	
	public TblParameterBean(){	
	}
	
	public TblParameterBean(String name1, String name2, int seq, String value1, String value2, String description,
			String descriptionZh, String descriptionNe, String descriptionUr, String remark){
		this.name1 = name1;
		this.name2 = name2;
		this.seq = seq;
		this.value1=value1;
		this.value2=value2;
		this.description=description;
		this.descriptionZh=descriptionZh;
		this.descriptionNe=descriptionNe;
		this.descriptionUr=descriptionUr;
		this.remark=remark;
	}	
}
