package com.mofinity.hkeasy;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;

public class Translate extends Activity{
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.translate);
        AQuery aq = new AQuery(this);
        //aq.id(R.id.txt).text("On translate page, you can translate the address, and etc. Click on Ok to go to google translation page.");
        aq.id(R.id.title).text(R.string.translate);
        aq.id(R.id.ok).clicked(this,"translate");
        aq.id(R.id.back).clicked(this,"onBackPressed");
    }    
	
	public void translate(){
		Profile profile = Profile.loadProfile(this);
		//Log.d("profile language is","profile.language:"+profile.language);
        String translateUrl="https://translate.google.com.hk/m/translate?hl=zh-TW&tab=wT";
    	if ("ur".equals(profile.language)){
    		translateUrl="https://translate.google.com.hk/m/translate?hl=ur&tl=zh-TW";
    	} else if ("zh_TW".equals(profile.language)){
    		translateUrl="https://translate.google.com.hk/m/translate?hl=zh-TW&tl=zh-TW";
    	} else if ("ne".equals(profile.language)){
    		translateUrl="https://translate.google.com.hk/m/translate?hl=en&tl=zh-TW";
    	} else {
    		//assume english
    		translateUrl="https://translate.google.com.hk/m/translate?hl=en&tl=zh-TW";
    	}
		Uri uri = Uri.parse(translateUrl); 
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
		startActivity(intent);		
	}
	
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    	    
}

