/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mofinity.hkeasy;

import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerDragListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblMapBean;
import com.mofinity.model.DBOperation;



/**
 * This shows how to create a simple activity with a map and a marker on the map.
 * <p>
 * Notice how we deal with the possibility that the Google Play services APK is not
 * installed/enabled/updated on a user's device.
 */
public class BasicMapActivity extends FragmentActivity implements OnMarkerClickListener, OnInfoWindowClickListener, OnMarkerDragListener
			  { 
    /**
     * Note that this may be null if the Google Play services APK is not available.
     */
    private GoogleMap mMap;
    private String searchType;
    private LatLngBounds bounds=null;
    private LatLngBounds.Builder latlngbuilder = null;
    private boolean updated = false;
    private List<TblMapBean> entries=null;
    private int mapId= -1;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.basic_demo);
        setUpMapIfNeeded();
        
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
        	searchType = bundle.getString("searchType");
        	String title = bundle.getString("title");
        	mapId = bundle.getInt("mapid",-1);
        	setTitle(title);
        	bundle.clear();
        } else {

        }
        
        latlngbuilder = new LatLngBounds.Builder();
        
        mMap.setOnMarkerClickListener(this);
        mMap.setOnInfoWindowClickListener(this);
        mMap.setOnMarkerDragListener(this);
        // added myLocatoin Enable button
        mMap.setMyLocationEnabled(true);
        
        updateMark();
        Profile profile = Profile.loadProfile(this);

        if (mapId <0){
        	mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(profile.lat, profile.lng) , 13.0f));
        }
        //startUpdates(null);
        //getLocation(null);        
    }
    
    public void updateMapCenter(){
        // Pan to see all markers in view.
        // Cannot zoom to bounds until the map has a size.
/*        final View mapView = getSupportFragmentManager().findFragmentById(R.id.map).getView();
        if (mapView.getViewTreeObserver().isAlive()) {
            mapView.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
                @SuppressWarnings("deprecation") // We use the new method when supported
                @SuppressLint("NewApi") // We check which build version we are using.
                @Override
                public void onGlobalLayout() {
                    LatLngBounds bounds = new LatLngBounds.Builder()
                            .include(cur_loc)
                            .build();
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                      mapView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    } else {
                      mapView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                    Log.d("BasicMapActivity","updateMapCenter is called."+"cur_loc.getLng:"+cur_loc.toString());
                    mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 50));
                    return;
                }
            });
        }*/
//        bounds = latlngbuilder.include(cur_loc).build();
        /*Marker item = mMap.addMarker(new MarkerOptions()
        .title(""+getText(R.string.curloc))
        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));*/

        if (!updated){
//        	mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(cur_loc , 13.0f));
        	updated = true;
        	//mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 10));
        	//mMap.animateCamera(CameraUpdateFactory.zoomTo(13f));
        }
    }

    public void updateMark(){
    	entries = loadMap();
	    try {
	    	if (entries == null || entries.size() <=0){
	    		return;
	    	}
	    	int i = 0;
	    	for(TblMapBean entry : entries){
	    		
	            String name= entry.getName();
	            String address = entry.getAddress();
				if ("zh_TW".equals(Profile.getLanguage())){
					name = entry.getNameZh();
					address = entry.getAddressZh();
				}
				
				//if not value, use english as default.
				if (name == null ||name.length()<=0){
					name = entry.getName();
				}
				if (address == null || address.length() <=0){
					address = entry.getAddress();
				}

				
				LatLng mark = new LatLng(entry.getMapX(),entry.getMapY());
				//latlngbuilder.include(mark);
				
				Marker item = mMap.addMarker(new MarkerOptions()
		        .position(mark)
		        .title(name)
		        .snippet(address)
		        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
				
				// zoom to selected hosiptal
	    		if (mapId == entry.getMapId()){
	    			mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mark , 17.0f));
	    			item.showInfoWindow();
	    		}	    			

	    	}
	    	//latlngbuilder.include(cur_loc);
	    	//bounds= latlngbuilder.build();
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    } 
	}

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #mMap} is not null.
     * <p>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not have been
     * completely destroyed during this process (it is likely that it would only be stopped or
     * paused), {@link #onCreate(Bundle)} may not be called again so we should call this method in
     * {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera. In this case, we
     * just add a marker near Africa.
     * <p>
     * This should only be called once and when we are sure that {@link #mMap} is not null.
     */
    private void setUpMap() {
        //mMap.addMarker(new MarkerOptions().position(cur_loc).title("Your Location"));
    }
    
    @Override
    public boolean onMarkerClick(final Marker marker) {
         // This causes the marker at Adelaide to change color.
         marker.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        // We return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false;
    }
    
	public List<TblMapBean> loadMap(){
		return DBOperation.getMap(this, searchType);
	}

    @Override
    public void onInfoWindowClick(Marker marker) {
    	//Log.d("marker is marker is","marker is:"+marker.getId()+" title:"+marker.getTitle());
        //Toast.makeText(getBaseContext(), "Click Info Window", Toast.LENGTH_SHORT).show();
        int pos = 0;
        try {
        	pos = Integer.parseInt(marker.getId().replace("m",""));
        } catch (Exception ex){Log.e("error on integer convert",ex.toString());}
        
        TblMapBean entry = entries.get(pos);
        String name = entry.getName();
        String address = entry.getAddress();
        String telephone = entry.getPhoneNo();
        String remark = entry.getRemark();
        
        if ("A&E Services".equals(remark)){
        	remark = ""+getText(R.string.emergency);
        }
        
		if ("zh_TW".equals(Profile.getLanguage())){
			name = entry.getNameZh();
			address = entry.getAddressZh();
		} 
		
		//if not value, use english as default.
		if (name == null ||name.length()<=0){
			name = entry.getName();
		}
		if (address == null || address.length() <=0){
			address = entry.getAddress();
		}
        
        //Log.d("name from entries","name from entries:"+entries.get(pos).getName());
        Intent intent = new Intent(this, MapDetails.class);
        intent.putExtra("name",name);
        intent.putExtra("address", address);
        intent.putExtra("telephone",telephone);
        intent.putExtra("remark",remark);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    @Override
    public void onMarkerDragStart(Marker marker) {
    	Toast.makeText(getBaseContext(), "onMarkerDragStart", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
    	Toast.makeText(getBaseContext(), "onMarkerDragEnd", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onMarkerDrag(Marker marker) {
    	Toast.makeText(getBaseContext(), "onMarkerDrag Current Position: " + marker.getPosition(), Toast.LENGTH_SHORT).show();
    }
	
	@Override
	protected void onStop() {
		super.onStop();
	}
	
    @Override
	protected void onPause() {
		super.onPause();
	}
}
