package com.mofinity.hkeasy;


import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblSpeechBean;
import com.mofinity.model.DBOperation;
import com.mofinity.util.Tool;


public class Sentance extends ListActivity {

    /** Called when the activity is first created. */
	private AQuery aq_main = null;
	private Profile profile = null;
	private String searchType = null;
	ArrayAdapter<TblSpeechBean> result = null;
	List<TblSpeechBean> contents = null;
	public int cur_pos = -1;
	public MediaPlayer mpx = null;
	private File path=null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.empty_list);
        
        searchType = getIntent().getStringExtra("searchType");
        String title = getIntent().getStringExtra("title");
        String keyword = getIntent().getStringExtra("keywords");
        //Log.d("Sentance.class","searchType is:"+searchType +" keyword:"+keyword);
        profile = Profile.loadProfile(this);
        aq_main = new AQuery(this);
        aq_main.id(R.id.title).visible().text(title);
        aq_main.id(R.id.nomatchresult).gone();
        aq_main.id(R.id.back).clicked(this, "close");
        
        if (keyword != null){
        	aq_main.id(R.id.searchtxt).text(keyword);
        } else {
        	aq_main.id(R.id.search_box).gone();
        }

        //aq.id(R.id.next).gone();
        
        aq_main.id(R.id.search).clicked(this, "search");
        mpx = new MediaPlayer();
        
        renderGroups();

    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
    
    @Override
    public void onStop(){
    	if (mpx != null ) mpx.reset();
    	super.onStop();
    }
    
    @Override
    public void onResume(){
    	super.onResume();
    }
    
    public void search(View view){
    	Tool.hideKeyboard(Sentance.this, view);
    	cur_pos = -1;
		result.clear();
		renderGroups();
		result.notifyDataSetChanged();
    }
    
    public void upload(View view){
    	Intent intent = new Intent(Sentance.this, Sentance.class);
    	startActivity(intent);
    	finish();
    }
    
    public void renderGroups() {
		
		List<TblSpeechBean> entries = loadSpeech();
		if (entries == null || entries.size() <=0){
			aq_main.id(R.id.nomatchresult).visible();
			aq_main.id(android.R.id.list).invisible();
			return;
		}
		contents = entries;
		aq_main.id(R.id.nomatchresult).gone();
		aq_main.id(android.R.id.list).visible().adapter(getAA(entries)).itemClicked(this, "itemClicked");
	}

	public List<TblSpeechBean> loadSpeech(){
		String searchtxt = ""+aq_main.id(R.id.searchtxt).getText();
		//Log.d("searchtxt is","searchtxt is:"+searchtxt);
		if (searchtxt != null && searchtxt.length() > 0){
			return DBOperation.getSpeechByWord(this, searchtxt, profile.language);
			//return DBOperation.getSpeech(this, searchType);
		} else {
			return DBOperation.getSpeech(this, searchType);
		}
	}
	
	// adaptive array
	
	private List<TblSpeechBean> list;
	
	private ArrayAdapter<TblSpeechBean> getAA(List<TblSpeechBean> entries){
		
		list = new ArrayList<TblSpeechBean>();
		for(TblSpeechBean entry : entries){
			list.add(entry);
		}
				
		//ArrayAdapter<TblSpeechBean> result = new ArrayAdapter<TblSpeechBean>(this, R.layout.learn_item, list){
		result = new ArrayAdapter<TblSpeechBean>(this, R.layout.learn_item, list){
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				
				if(convertView == null){
					convertView = getLayoutInflater().inflate(R.layout.learn_item, null);
				}
				
				TblSpeechBean ai = (TblSpeechBean) getItem(position);
				AQuery aq = new AQuery(convertView);
				
				String name = ai.text;
				if ("zh_TW".equals(Profile.getLanguage())){
					name = ai.textZh;
				}else if ("ur".equals(Profile.getLanguage())){
					name = ai.textUr;
				}else if ("ne".equals(Profile.getLanguage())){
					name = ai.textNe;
				}
				String meta = ai.pronunciation+"";
				String text = ai.textZh;
				String imageUrl = null;
				
				if(meta != null ){ 
					text += "   <br><font color=\"brown\">" + meta + "</font>";
				}

				Spanned span = Html.fromHtml(text);
				aq.id(R.id.name).text(name);
				
				if (text == null || text.length()<1) {
					aq.id(R.id.detail).gone();
					aq.id(R.id.name).getView().setPadding(10,30,0,30);
				} else {
					aq.id(R.id.name).getView().setPadding(10,15,0,15);
					aq.id(R.id.name2).getView();
					aq.id(R.id.name2).text(span);
				}

				aq.id(R.id.name).width(Tool.getWidth(Sentance.this)-215);
				aq.id(R.id.li_img1).visible().width(25).height(25).image(R.drawable.expand);
				
				if (position == cur_pos){
					aq.id(R.id.li_img1).visible().width(25).height(25).image(R.drawable.collapse);
					aq.id(R.id.borderline).visible();
					aq.id(R.id.ll).visible();
			
					LinearLayout ll = (LinearLayout)convertView.findViewById(R.id.ll);
					ll.setOnClickListener(new OnClickListener(){
						@Override
						public void onClick(View v){
							clickplay();
						}
					});
					//aq.id(R.id.ll).clicked(this, "clicksound");
					//aq.id(R.id.img_arrow2).clicked(this, "close");
					//aq.id(R.id.name2).clicked(this, "aaaa");
				} else {
					aq.id(R.id.borderline).gone();
					aq.id(R.id.ll).gone();
				}
				
				return convertView;
			}
		};
		
		
		return result;
	}
		
	public void clicksound(){
		TblSpeechBean ai = list.get(cur_pos);
		//Log.d("Sentance.class","speech id:"+ai.speechId);
		byte[] sound = DBOperation.getSound(this, ai.speechId);

		path = Tool.byte2File(Tool.getCacheDirectory()+"112233.mp3", sound);
		playFile(path);
	}
	
	public void clickplay(){
		playFile(path);
	}
	
	public void playFile(final File sound){
		try{
		    if (sound == null) {
		        // Set to Readable and MODE_WORLD_READABLE
		        return;
		    }
		    
			mpx.reset();
			FileInputStream fis = new FileInputStream(sound);
			mpx.setDataSource(fis.getFD());
			mpx.prepare();
			mpx.start();
		
			mpx.setOnCompletionListener(new OnCompletionListener(){
				@Override
				public void onCompletion(MediaPlayer mp) {
					// TODO Auto-generated method stub
				}

			});
	//		mpx.stop();
			} catch (Exception ex){
				if (mpx != null) mpx.stop();
			}
	}
	
	public void itemClicked(AdapterView<?> parent, View view, int position, long id){
		
		ListView aa = (ListView)aq_main.id(android.R.id.list).getView();
		//Parcelable state = aa.onSaveInstanceState();
		int firstvisiblepos = aa.getFirstVisiblePosition();
		int lastvisiblepos = aa.getLastVisiblePosition();
		View v = aa.getChildAt(0);
		int top = (v == null)? 0: v.getTop();
		//Log.d("aaaaaaaaaaaa","poistion is:"+firstvisiblepos+" top:"+top+" botton:"+lastvisiblepos);

		if (cur_pos == position){
			cur_pos = -1;
		} else {
			cur_pos = position;
			clicksound();
		}
		result.clear();
		aq_main.id(android.R.id.list).adapter(getAA(contents));
		result.notifyDataSetChanged();

		//aa.onRestoreInstanceState(state);
		if (position == lastvisiblepos){
			aa.setSelectionFromTop(firstvisiblepos+1, top);
		} else {
			aa.setSelectionFromTop(firstvisiblepos, top);
		}
	}
        
    public void onPause(){
    	super.onPause();
    }
    
}