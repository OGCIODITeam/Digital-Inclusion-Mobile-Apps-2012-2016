package com.mofinity.hkeasy;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import br.com.dina.ui.widget.UITableView;
import br.com.dina.ui.widget.UITableView.ClickListener;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;

public class Useful extends Activity {
	
	private UITableView contentView;
	private Profile profile;
	private AQuery aq = null;
	
	
	@Override
	public void onResume(){
		super.onResume();
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.cell_list);  
        //Tool.setLanguage(this, getBaseContext());
        
        contentView = (UITableView) findViewById(R.id.content);
        
        profile = Profile.loadProfile(this);
        aq = new AQuery(this);
        aq.id(R.id.setting).text(R.string.useful);
        aq.id(R.id.back).clicked(this, "close");
       	createLoadedMenu();
    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
    
    public void createLoadedMenu(){
    	contentView.clear();
    	createMenu();
    }
    
    private void createList() {
    	ContentClickListener contentlistener = new ContentClickListener();
    	contentView.setClickListener(contentlistener);
    	contentView.addBasicItem((String)getString(R.string.easycall));
    	contentView.addBasicItem((String)getString(R.string.usefullink));
    	contentView.addBasicItem((String)getString(R.string.usefulinfo));
    }
       
	
	private void createMenu(){
		
        createList();      
        contentView.commit();
	}
	

    
    private class ContentClickListener implements ClickListener {

		@Override
		public void onClick(int index) {
			//Log.d("MainActivity", "item clicked: " + index);
			Intent intent = null;
        	
			if(index == 0) {
				intent = new Intent(Useful.this, Learn.class);
				intent.putExtra("searchType","CALL_TYPE");
			}
			else if(index == 1) {
				intent = new Intent(Useful.this, Link.class);
			}
			else if(index == 2) {
				//intent = new Intent(Useful.this, Webpage.class);
				//intent.putExtra("index", 3);
		        String lang="?lang=en";
		        if ("en".equals(Profile.getLanguage())){

				} else if ("zh_TW".equals(Profile.getLanguage())){
					lang="?lang=zh";
				} else if ("ur".equals(Profile.getLanguage())){
					lang="?lang=Ur";
				} else if ("ne".equals(Profile.getLanguage())){
					lang="?lang=Ne";
				}
		        
				String translateUrl = profile.usefulinfo+lang;
				Uri uri = Uri.parse(translateUrl); 
				intent = new Intent(Intent.ACTION_VIEW, uri);	
			}
			
			if (intent != null){
				startActivity(intent);
			}
		}
    	
    }
    
}
