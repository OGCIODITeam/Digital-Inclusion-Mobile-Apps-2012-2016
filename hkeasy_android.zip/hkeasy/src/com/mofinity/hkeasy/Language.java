package com.mofinity.hkeasy;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import br.com.dina.ui.widget.UITableSelectView;
import br.com.dina.ui.widget.UITableSelectView.ClickListener;

import com.androidquery.AQuery;
import com.mofinity.bean.CachProfile;
import com.mofinity.bean.Profile;
import com.mofinity.util.Tool;



public class Language extends Activity{
	UITableSelectView	langView;
	SharedPreferences pref = null;
	private boolean init = false;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.single_content_table);        
        AQuery aq = new AQuery(this);
        aq.id(R.id.back).clicked(this, "onBackPressed");
        init = getIntent().getBooleanExtra("init", false);
        if (init){
        	aq.id(R.id.back).invisible();
        }
        aq.id(R.id.selectmsg).visible();
        
        langView = (UITableSelectView) findViewById(R.id.content);
        LangClickListener langlistener = new LangClickListener();
    	langView.setClickListener(langlistener);
    	if ("en".equals(Profile.getLanguage())){
    		langView.setSelectTag(0);
    	} else if ("zh_TW".equals(Profile.getLanguage())){
    		langView.setSelectTag(1);
    	} else if ("ur".equals(Profile.getLanguage())){
    		langView.setSelectTag(2);
    	} else if ("ne".equals(Profile.getLanguage())){
    		langView.setSelectTag(3);
    	}

   		langView.addBasicItem((String)getText(R.string.english));
   		langView.addBasicItem((String)getText(R.string.chinese));
   		langView.addBasicItem((String)getText(R.string.pakistanese));
   		langView.addBasicItem((String)getText(R.string.nepalese));

    	langView.commit();
    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    private class LangClickListener implements ClickListener {

		@Override
		public void onClick(int index) {
			//Log.d("MainActivity", "item clicked: " + index);
			if(index == 0) {
				Profile.setLanguage("en");
				Tool.setupPreferenceLang(Language.this, "en");
				langView.setSelectTag(0);
			}
			else if(index == 1) {
				Profile.setLanguage("zh_TW");
				Tool.setupPreferenceLang(Language.this, "zh_TW");
				langView.setSelectTag(1);
			}
			else if(index == 2) {
				Profile.setLanguage("ur");
				Tool.setupPreferenceLang(Language.this, "ur");
				langView.setSelectTag(2);
			}
			else if(index == 3) {
				Profile.setLanguage("ne");
				Tool.setupPreferenceLang(Language.this, "ne");
				langView.setSelectTag(3);
			}
			langView.clear();
	   		langView.addBasicItem((String)getText(R.string.english));
	   		langView.addBasicItem((String)getText(R.string.chinese));
	   		langView.addBasicItem((String)getText(R.string.pakistanese));
	   		langView.addBasicItem((String)getText(R.string.nepalese));

	    	langView.commit();
	    	Profile profile = Profile.loadProfile(Language.this);
	    	profile.language = Profile.getLanguage();
	    	CachProfile.menu_reload = true;
	    	CachProfile.setting_reload = true;
	    	Profile.storeProfile(Language.this, profile);
			
	    	if (init){
	    		startActivity(new Intent(Language.this, MainActivity.class));
	    		finish();
	    		return;
	    	} else {
	    		onBackPressed();
	    	}
		}
    	
    }
    
    private void setupPreferenceLang(String lang){
    	pref = PreferenceManager.getDefaultSharedPreferences(this);
    	
        if (lang != null){
        	if ("zh_TW".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "zh_TW");
		        editor.commit();
        	} else if ("en".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "en");
		        editor.commit();
        	} else if ("ur".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "ur");
		        editor.commit();
        	} else if ("ne".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "ne");
		        editor.commit();
        	} 
        }
    	
        Tool.setLanguage(this,getBaseContext());
    }
}
