package com.mofinity.hkeasy;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.androidquery.AQuery;

public class MapDetails extends Activity {
	private String phone ="";
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.mapdetail);
        String name = getIntent().getStringExtra("name");
        String address = getIntent().getStringExtra("address");
        phone = getIntent().getStringExtra("telephone");
        String remark = getIntent().getStringExtra("remark");
        
        AQuery aq = new AQuery(this);
        aq.id(R.id.name_val).text(name);
        aq.id(R.id.address_val).text(address);
        aq.id(R.id.telephone_val).text(phone);
        aq.id(R.id.remark_val).text(remark==null ? "":remark);
        
        aq.id(R.id.back).clicked(this, "onBackPressed");
        aq.id(R.id.call).clicked(this, "call");
    }
    
    public void call(){
		Intent callIntent = new Intent(Intent.ACTION_DIAL);
		callIntent.setData(Uri.parse("tel:"+phone));
		startActivity(callIntent);
    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    protected void onPause(){
    	super.onPause();
    }
    
    protected void onResume() {
    	super.onResume();
    }
           
}
