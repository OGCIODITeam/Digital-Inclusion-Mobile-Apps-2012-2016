package com.mofinity.hkeasy;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;

import com.androidquery.AQuery;
import com.androidquery.callback.BitmapAjaxCallback;
import com.androidquery.util.AQUtility;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblAdvBean;
import com.mofinity.model.DBOperation;

public class AdvActivity extends Activity {
	
    /** Called when the activity is first created. */
	public static String update_time = null;
	public boolean status = false;
	private Profile profile = null;
	private String imageUrl="";
	private String linkUrl="";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adv);
        profile = Profile.loadProfile(this);
        
        AQUtility.cleanCacheAsync(this, 0, 0);
		BitmapAjaxCallback.clearCache();

        /*new Thread(new Runnable() { 
        	public void run() {                 
        		while (doWork()!=1) {
        		}
        	}
        }).start();*/
        TblAdvBean a = null;
        try{
        	a = DBOperation.getAdv(this, "F");
        } catch (Exception ex){
        	Log.e("error on getAdv","Error is:"+ex.toString());
        }
        imageUrl = "http://www.yang.org.hk/PublishWebSite/yang/gallery/ebb10576-70a7-4441-9d16-7ec38e798c1b.JPG";
        linkUrl = null;
        if (a != null){
        	if ("ud".equals(profile.language)){
        		imageUrl=a.imageUrlUd;
        		linkUrl=a.linkUd;
        	} else if ("zh".equals(profile.language)){
        		imageUrl=a.imageUrlZh;
        		linkUrl=a.linkZh;
        	} else if ("ne".equals(profile.language)){
        		imageUrl=a.imageUrlNe;
        		linkUrl=a.linkNe;
        	} else {
        		//assume english
        		imageUrl=a.imageUrl;
        		linkUrl=a.link;
        	}
        }
        Log.d("aaaaaaaaaaaaabbbbbbbbbbbbbbb","url image is:"+imageUrl);
        Log.d("aaaaaaaaaaaaaaaaaaaaaaaaa","link url is:"+linkUrl);
        AQuery aq = new AQuery(this);
        aq.id(R.id.imageView1).image(imageUrl,  true, true, 200, AQuery.INVISIBLE).clicked(this, "toAdv");
        //aq.id(R.id.imageView1).clicked(this, "toAdv");
        aq.id(R.id.imageView2).clicked(this, "closeAdv");
    }
    
    public void closeAdv(View view){
	     Intent intent = new Intent();
	     intent.setClass(AdvActivity.this,Menu.class);
	     startActivity(intent);
		 finish();
    }
    @Override
    public void onBackPressed(){
    	// disable back bottom
    }
    
	public void toAdv(View view){
		if (linkUrl == null || linkUrl.length() <= 0) return;
		Uri uri = Uri.parse(linkUrl);  
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
		startActivity(intent);
	}
    
}

