package com.mofinity.hkeasy;

import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.androidquery.AQuery;
import com.mofinity.bean.CachProfile;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblParameterBean;
import com.mofinity.model.DBOperation;
import com.mofinity.util.Tool;


public class Learn extends ListActivity {

    /** Called when the activity is first created. */
	private AQuery aq_main = null;
	private Profile profile = null;
	private String searchType = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.empty_list);
        
        searchType = getIntent().getStringExtra("searchType");
        profile = Profile.loadProfile(this);
        aq_main = new AQuery(this);
        if ("SPEECH_TYPE".equals(searchType)){
        	aq_main.id(R.id.title).visible().text(R.string.learn);
        } else if ("CALL_TYPE".equals(searchType)){
        	aq_main.id(R.id.title).visible().text(R.string.easycall);
        	aq_main.id(R.id.search_box).gone();
        } else if ("MAP_TYPE".equals(searchType)){
        	aq_main.id(R.id.title).visible().text(R.string.map);
        	aq_main.id(R.id.search_box).gone();
        }
        aq_main.id(R.id.nomatchresult).gone();
        aq_main.id(R.id.back).clicked(this, "close");
        //aq.id(R.id.back).invisible();
        //aq.id(R.id.next).gone();
        
        aq_main.id(R.id.search).clicked(this, "search");
        renderGroups();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
    
    @Override
    public void onResume(){
    	//if (list != null) list.clear();
    	//renderGroups();
    	super.onResume();
    }
    
    public void search(View view){
    	Tool.hideKeyboard(Learn.this, view);
    	String searchtxt = ""+aq_main.id(R.id.searchtxt).getText();
    	if (searchtxt==null || searchtxt.length() <=0){
    		return;
    	}
    	Intent intent = new Intent(this, Sentance.class);
    	intent.putExtra("title",""+getText(R.string.search));
		//Log.d("searchtxt is","searchtxt is:"+searchtxt);
    	intent.putExtra("keywords",searchtxt);
    	startActivity(intent);
    }
        
	public void renderGroups() {
		
		List<TblParameterBean> entries = loadParameter();
		if (entries == null || entries.size() <=0){
			aq_main.id(R.id.nomatchresult).visible();
			aq_main.id(android.R.id.list).invisible();
			return;
		}
		//Log.d("entries size aaaaa","size:"+entries.size());
	
		aq_main.id(R.id.nomatchresult).gone();
		aq_main.id(android.R.id.list).visible().adapter(getAA(entries)).itemClicked(this, "itemClicked");
	}
	
	public List<TblParameterBean> loadParameter(){
		if (CachProfile.search_words.length() > 0){
			return DBOperation.getParameters(this, searchType);
		} else {
			return DBOperation.getParameters(this, searchType);
		}
	}
	
	// adaptive array
	
	private List<TblParameterBean> list;
	
	private ArrayAdapter<TblParameterBean> getAA(List<TblParameterBean> entries){
		
		list = new ArrayList<TblParameterBean>();
		for(TblParameterBean entry : entries){
			list.add(entry);
		}
				
		ArrayAdapter<TblParameterBean> result = new ArrayAdapter<TblParameterBean>(this, R.layout.list_item, list){
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
	
				if(convertView == null){
					convertView = getLayoutInflater().inflate(R.layout.list_item, null);
				}
				
				TblParameterBean ai = (TblParameterBean) getItem(position);
				AQuery aq = new AQuery(convertView);

				String name = ai.description;
				if ("en".equals(Profile.getLanguage())){

				} else if ("zh_TW".equals(Profile.getLanguage())){
					name = ai.descriptionZh;
				} else if ("ur".equals(Profile.getLanguage())){
					name = ai.descriptionUr;
				} else if ("ne".equals(Profile.getLanguage())){
					name = ai.descriptionNe;
				}
				String meta = null;
				String text = null;
				String imageUrl = "accessory";
				imageUrl = ai.value1;
				
				if(meta != null ){ 
					text += "   <br/><small><font color=\"brown\">" + meta + "</font></small>";
				}

				//Spanned span = Html.fromHtml(text);
				//aq.id(R.id.name).text(name);
				
				if (text == null || text.length()<1) {
					aq.id(R.id.detail).gone();
					//aq.id(R.id.name).getView().setPadding(10,30,0,30);
					aq.id(R.id.name).text(name);
				} else {
					//Log.d("aaaaaa",""+Tool.getWidth(LibListActivity.this));
					//aq.id(R.id.name).getView().setPadding(10,10,0,0);
					//aq.id(R.id.detail).getView().setPadding(10,0,0,0);
					aq.id(R.id.detail).text(text);
				}
				//Log.d("aaaaaaaa","value:"+profile.updated.contains(ai.getSid())+" "+ai.getSid());
				if (imageUrl == null || imageUrl.length() < 1){
					//aq.id(R.id.name).width(Tool.getWidth(LibListActivity.this)-190);
					//aq.id(R.id.name).width(Tool.getWidth(Learn.this)-190);
					aq.id(R.id.li_img1).gone();
				} else {
					//aq.id(R.id.name).width(Tool.getWidth(Learn.this)-240);
					aq.id(R.id.li_img1).visible().width(50).height(50).image(getResources().getIdentifier(imageUrl,"drawable","com.mofinity.hkeasy"));
				}
				
				return convertView;
			}
		};
		
		
		return result;
	}	
	
	public void itemClicked(AdapterView<?> parent, View view, int position, long id){
		
		TblParameterBean ai = list.get(position);			
		Intent intent = new Intent(this, Sentance.class);
		if ("CALL_TYPE".equals(searchType)){
			intent = new Intent(this, Call.class);
		} else if ("MAP_TYPE".equals(searchType)){
			intent = new Intent(this, MapList.class);
			//intent = new Intent(this, com.mofinity.hkeasy.Map.class);
		}
		intent.putExtra("searchType",ai.name2);
		String name = ai.description;
		if ("en".equals(Profile.getLanguage())){

		} else if ("zh_TW".equals(Profile.getLanguage())){
			name = ai.descriptionZh;
		} else if ("ur".equals(Profile.getLanguage())){
			name = ai.descriptionUr;
		} else if ("ne".equals(Profile.getLanguage())){
			name = ai.descriptionNe;
		}
		intent.putExtra("title", name);
		startActivity(intent);
	}
        
  
    public void onPause(){
    	super.onPause();
    }
    
}