package com.mofinity.hkeasy;


import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblLinkBean;
import com.mofinity.model.DBOperation;
import com.mofinity.util.Tool;


public class Link extends ListActivity {

    /** Called when the activity is first created. */
	private AQuery aq = null;
	private Profile profile = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.empty_list);
        
        profile = Profile.loadProfile(this);
        aq = new AQuery(this);
        aq.id(R.id.title).visible().text(R.string.usefullink);
        aq.id(R.id.nomatchresult).gone();
        aq.id(R.id.search_box).gone();
        aq.id(R.id.back).clicked(this, "close");
        //aq.id(R.id.next).gone();
        
        aq.id(R.id.search).clicked(this, "search");
        renderGroups();

    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
    
    @Override
    public void onResume(){
    	super.onResume();
    }
    
    public void search(View view){
    	Tool.hideKeyboard(Link.this, view);
    	
    }
    
    public void upload(View view){
    	Intent intent = new Intent(Link.this, Link.class);
    	startActivity(intent);
    	finish();
    }
    
    public void renderGroups() {
		
		List<TblLinkBean> entries = loadLink();
		if (entries == null || entries.size() <=0){
			aq.id(R.id.nomatchresult).visible();
			aq.id(android.R.id.list).invisible();
			return;
		}
	
		aq.id(R.id.nomatchresult).gone();
		aq.id(android.R.id.list).visible().adapter(getAA(entries)).itemClicked(this, "itemClicked");
	}

	public List<TblLinkBean> loadLink(){
			return DBOperation.getLink(this);
	}
	
	// adaptive array
	
	private List<TblLinkBean> list;
	
	private ArrayAdapter<TblLinkBean> getAA(List<TblLinkBean> entries){
		
		list = new ArrayList<TblLinkBean>();
		for(TblLinkBean entry : entries){
			list.add(entry);
		}
				
		ArrayAdapter<TblLinkBean> result = new ArrayAdapter<TblLinkBean>(this, R.layout.list_item, list){
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				
				if(convertView == null){
					convertView = getLayoutInflater().inflate(R.layout.list_item, null);
				}
				
				TblLinkBean ai = (TblLinkBean) getItem(position);
				AQuery aq = new AQuery(convertView);
				
				String name = null;
				String meta = null;
				String text = "";
				String imageUrl = null;
				
				if ("en".equals(Profile.getLanguage())){
					name = ai.getDescription();
				} else if ("zh_TW".equals(Profile.getLanguage())){
					name = ai.getDescriptionZh();
				}

				//if not value, use english as default.
				if (name == null ||name.length()<=0){
					name = ai.getDescription();
				}
				
				if(meta != null ){ 
					text += "   <br/><small><font color=\"brown\">" + meta + "</font></small>";
				}
				
				Spanned span = Html.fromHtml(text);
				aq.id(R.id.name).text(name);
				
				if (text == null || text.length()<1) {
					aq.id(R.id.detail).gone();
					aq.id(R.id.name).getView().setPadding(10,30,0,30);
				} else {
					//Log.d("aaaaaa",""+Tool.getWidth(LibListActivity.this));
					aq.id(R.id.name).getView().setPadding(10,10,0,0);
					aq.id(R.id.detail).getView().setPadding(10,0,0,0);
					aq.id(R.id.detail).text(span);
				}
				//Log.d("aaaaaaaa","value:"+profile.updated.contains(ai.getSid())+" "+ai.getSid());
				if (imageUrl == null || imageUrl.length() < 1){
					//aq.id(R.id.name).width(Tool.getWidth(LibListActivity.this)-190);
					aq.id(R.id.name).width(Tool.getWidth(Link.this)-190);
					aq.id(R.id.li_img1).gone();
				} else {
					aq.id(R.id.name).width(Tool.getWidth(Link.this)-215);
					aq.id(R.id.li_img1).visible().width(25).height(25).image(getResources().getIdentifier(imageUrl,"drawable","com.mofinity.hkeasy"));
				}
				
				return convertView;
			}
		};
		
		
		return result;
	}	
	
	public void itemClicked(AdapterView<?> parent, View view, int position, long id){
		
		TblLinkBean ai = list.get(position);			
		Uri uri = Uri.parse(ai.getLink()); 
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
		startActivity(intent);
	}
        
    public void onPause(){
    	super.onPause();
    }
    
}