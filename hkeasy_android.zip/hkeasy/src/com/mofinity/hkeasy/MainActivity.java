package com.mofinity.hkeasy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblParameterBean;
import com.mofinity.bean.TblSpeechBean;
import com.mofinity.model.DBOperation;
import com.mofinity.util.Tool;

public class MainActivity extends Activity{
	
    /** Called when the activity is first created. */
	public static String update_time = null;
	public boolean status = false;
	private String dbname = "hkeasy.db";
	private AQuery aq = null;
	private boolean old_db = false;
	private boolean start = false;
	public List<TblSpeechBean> speech=null;
	public Profile profile = null;
	public String dbversion = "";
	private ProgressDialog pd=null;
	public int pp =0;
	public int sleeptime = 20;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        setLanguage();
        aq = new AQuery(this);

        new Thread(new Runnable() { 
        	public void run() {                 
        		while (doWork()!=1) {
        		}
        	}
        }).start();

		// download database
		profile = Profile.loadProfile(this);
		
		//update useful info
		profile.versioncheck= profile.server_link + "/hke/data_version.php";
		profile.usefulinfo= profile.server_link + "/hke/others/useful.php";
		
		Profile.storeProfile(this, profile);

		old_db = Tool.isDBExists();
		if (old_db){
			start = true;
			List<TblParameterBean> a = null;
			try {
				a = DBOperation.getParameters(this, "SYSTEM");
				for (TblParameterBean b : a){
					if ("DATA_VERSION".equals(b.name2)){
						dbversion = b.value2;
						aq.ajax(profile.versioncheck, JSONObject.class, this, "downloadData");
						return;
					}
				}
			} catch (Exception ex){
				start = false;
				Log.e("MainActivity.class","Error downloaded database");
			}
			
		}
		
		new AlertDialog.Builder(this)
		.setMessage(R.string.downloaddb)
		.setPositiveButton(R.string.ok, 
		new DialogInterface.OnClickListener() {
			@Override             
			public void onClick(DialogInterface dialog, int which) {
				//Log.d("profile pforil","profiledbDownload"+profile.dbDownload);
				pd = Tool.setProgressBarDialog(MainActivity.this,getString(R.string.downloading));
				
				aq.progress(pd).ajax(profile.dbDownload, File.class, MainActivity.this, "downloadDB");
			}          
		})
		.setNegativeButton(R.string.cancel, 
			new DialogInterface.OnClickListener() {
				@Override             
				public void onClick(DialogInterface dialog, int which) {
					finish();
					return;
				}
			})

		.show();
		//aq.ajax(profile.dbDownload, File.class, this, "downloadDB");
		
    }

    
	public void downloadData(String url, JSONObject jo, AjaxStatus status){
		//Log.d("MainActivity.class bbbbbbbb","url:"+url+" status:"+status.getMessage());
		
		if(jo == null){
			//Tool.networkErrorAlert(this);
			//Tool.setAlertMessage (MainActivity.this, "Login Fail"+url, null, getString(R.string.ok));
			// not network, just start the application without DB update.
			startActivity(new Intent(this,AdvActivity.class));
			finish();
			return;
		}
		
		try {

			String version = jo.getString("version");
			
			//Log.d("version is.....","version:"+version);
			if (version == null || version.equals(dbversion)){
				//Tool.setAlertMessage (MainActivity.this, getString(R.string.getversionfail)+":"+rmessage, null, getString(R.string.ok));
				startActivity(new Intent(this,AdvActivity.class));
				finish();
				return;
			}
			
			new AlertDialog.Builder(this)
			.setMessage(R.string.updatedata)
			.setPositiveButton(R.string.ok, 
			new DialogInterface.OnClickListener() {
				@Override             
				public void onClick(DialogInterface dialog, int which) {
					pd = Tool.setProgressBarDialog(MainActivity.this,getString(R.string.downloading));
					
					aq.progress(pd).ajax(profile.dbDownload, File.class, MainActivity.this, "downloadDB");
				}          
			})
			.setNegativeButton(R.string.cancel, 
			new DialogInterface.OnClickListener() {
				@Override             
				public void onClick(DialogInterface dialog, int which) {
					startActivity(new Intent(MainActivity.this,AdvActivity.class));
					finish();
					return;
				}
			})
			.show();
			
		}catch (Exception ex){
			Log.e("Download Data.class","Error:"+ex.toString());
		}
	}
    
    public void setLanguage(){
		Profile profile = Profile.loadProfile(this);
		//Log.d("aaa","language original:"+profile.language+" login: "+profile.login);
		if (profile.language.length() <= 0){
			// ask user set default language
			Intent intent = new Intent(this,Language.class);
			intent.putExtra("init",true);
			startActivity(intent);
			finish();
			
			String lang = Locale.getDefault().getLanguage();
			if ("zh".equals(lang)){
				lang = "zh_TW";
			}
			Profile.setLanguage(lang);
			profile.language = lang;
			//Log.d("aaaa", "language becomes:"+lang);
		} else {
			Profile.setLanguage(profile.language);
		}
		//Log.d("aaa","language "+Profile.getLanguage());
		Tool.setupPreferenceLang(this, Profile.getLanguage());
    }
    
	
    @Override 
    public void onConfigurationChanged(Configuration newConfig) {   
    	// refresh your views here   
    	super.onConfigurationChanged(newConfig); 
    } 
    @Override
	protected void onStop() {
		/* may as well just finish since saving the state is not important for this toy app */
		super.onStop();
	}

    @Override
    public void onPause(){
    	super.onPause();
    }
    
    public int doWork(){
    	try {

    	} catch (Exception ex){
    		
    	} finally {
    	}
        return 1;
    }
    
	public void downloadDB(String url, File file, AjaxStatus status){
		
		Log.d("MainActivity.class","url:"+url+" status:"+status.getMessage());
		
		if(file == null ){
			if (start == false) {
				//Tool.setAlertMessage (MainActivity.this, "DB Download Fail"+url, null, getString(R.string.ok));
				new AlertDialog.Builder(this)
				.setMessage(R.string.downloadfail)
				.setPositiveButton(R.string.ok, 
				new DialogInterface.OnClickListener() {
					@Override             
					public void onClick(DialogInterface dialog, int which) {
						//Log.d("profile pforil","profiledbDownload"+profile.dbDownload);
						MainActivity.this.finish();
						return;
					}          
				})
				.show();
//				finish();
				return;
			}
			
			new AlertDialog.Builder(this)
			.setMessage(R.string.updatefail)
			.setPositiveButton(R.string.ok, 
			new DialogInterface.OnClickListener() {
				@Override             
				public void onClick(DialogInterface dialog, int which) {
					//Log.d("profile pforil","profiledbDownload"+profile.dbDownload);
					startActivity(new Intent(MainActivity.this,AdvActivity.class));
					finish();
					return;
				}          
			})
			.show();
			//Tool.networkErrorAlert(this);
			//Tool.setAlertMessage (MainActivity.this, "DB Download Fail"+url, null, getString(R.string.ok));
			return;
		} else {	
			start = true;
			//Log.d("file path is:","file path is:"+file.getAbsolutePath()+" size:"+file.length());
			
			FileInputStream fis = null;
			FileOutputStream fout = null;
			try {
			 fout = new FileOutputStream(Tool.getDatabaseDirectory()+dbname);
			 fis = new FileInputStream(file);
			 byte[] content = new byte[4096];

			 while (fis.read(content) != -1) {
				// convert to char and display it
				fout.write(content);
			 }
			
			} catch (Exception ex){
				if (!old_db) start = false;
				Log.e("MainActivity.class", "error writing file, error:"+ex.toString());
				try {
				fis.close();
				fout.close();
				} catch (Exception nex){}
			}
		}
		
		Profile profile = Profile.loadProfile(this);
		Profile.storeProfile(this, profile);
		
		if (!start){
			 new AlertDialog.Builder(this)
				.setMessage(R.string.networkerror)
				.setPositiveButton(R.string.ok, 
				new DialogInterface.OnClickListener() {
					@Override             
					public void onClick(DialogInterface dialog, int which) {
						 MainActivity.this.finish();
					}          
				})                  
				.show();
			 return;
		}
		//downloadSound();
		startActivity(new Intent(this,AdvActivity.class));
		finish();
	}
}

