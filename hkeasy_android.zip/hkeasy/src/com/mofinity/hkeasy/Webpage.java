package com.mofinity.hkeasy;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;
import com.mofinity.util.Tool;


public class Webpage extends Activity {
	
	private static final String classname = "Webpage";
	private Profile profile = null;
	WebView myWebView=null;
	private ProgressDialog progressDialog = null;
	private boolean disable_redirect_to_browser = true;
	
	private ValueCallback<Uri> mUploadMessage;  
	private final static int FILECHOOSER_RESULTCODE=1;  

	 @Override  
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {  
	  if(requestCode==FILECHOOSER_RESULTCODE)  
	  {  
	   if (null == mUploadMessage) return;  
	            Uri result = intent == null || resultCode != RESULT_OK ? null  
	                    : intent.getData();  
	            mUploadMessage.onReceiveValue(result);  
	            mUploadMessage = null;  
	  }
	} 
	
	@Override 
	protected void onDestroy() { 
		super.onDestroy(); 
		//TODO Auto-generated method stub 
	}
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.webpage);
        profile = Profile.loadProfile(this);
        AQuery aq = new AQuery(this);
        aq.id(R.id.back).clicked(this,"onBackPressed");
        int index = getIntent().getIntExtra("index",0);
        int title=0;
        String url = "";
        profile = Profile.loadProfile(this);
        String lang="?lang=en";
        if ("en".equals(Profile.getLanguage())){

		} else if ("zh_TW".equals(Profile.getLanguage())){
			lang="?lang=zh";
		} else if ("ur".equals(Profile.getLanguage())){
			lang="?lang=Ur";
		} else if ("ne".equals(Profile.getLanguage())){
			lang="?lang=Ne";
		}

        if (index ==0){
        	aq.id(R.id.title).text(R.string.forum);
        	aq.id(R.id.next).text(R.string.home).visible().clicked(this, "back2menu");
        	url = profile.forumUrl;
        } else if (index == 3){
        	aq.id(R.id.title).text(R.string.terms);
        	url = profile.termsUrl+lang;
        } else if (index == 4 ){
        	aq.id(R.id.title).text(R.string.aboutus);
        	url = profile.aboutUrl+lang;        	
        } else {
        	aq.id(R.id.title).text(R.string.usefulinfo);
        	url = profile.usefulinfo+lang;
        }
        
        
        
        WebView mWebView = (WebView) findViewById(R.id.web_content);
        
        if (disable_redirect_to_browser){
	        myWebView = mWebView;
	        //temporary dim to disable redirect_to_browser
	        /*mWebView.setWebViewClient(new MyWebViewClient(){
	            @Override
	            public void onPageFinished(WebView view, final String url) {
	                progressDialog.cancel();
	
	            }
	            @Override
	            public void onPageStarted(WebView view, String url, Bitmap favicon) {
	            	progressDialog = Tool.setProgressDialog(Webpage.this, "");
	                //progressDialog.show();
	            }
	            @Override
	            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
	                //Log.d("error error error error","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	            	//progressDialog.cancel();
	            }
	            
	            @Override
	            public void onFormResubmission (WebView view, Message dontResend, Message resend){
	
	            	//L.v("### FORM ","## FORM RE SUBMIT");
	            	resend.sendToTarget();
	            	Toast.makeText(getApplicationContext(), "RESUBMIT DATA", Toast.LENGTH_LONG).show();
	            }
	            
	
	        });*/
	        
	        mWebView.setWebChromeClient(new WebChromeClient()  
	        {  
	               //The undocumented magic method override  
	               //Eclipse will swear at you if you try to put @Override here  
	            // For Android 3.0+
	            public void openFileChooser(ValueCallback<Uri> uploadMsg) {  
	
	                mUploadMessage = uploadMsg;  
	                Intent i = new Intent(Intent.ACTION_GET_CONTENT);  
	                i.addCategory(Intent.CATEGORY_OPENABLE);  
	                i.setType("image/*");  
	                Webpage.this.startActivityForResult(Intent.createChooser(i,"File Chooser"), FILECHOOSER_RESULTCODE);  
	
	               }
	
	            // For Android 3.0+
	               public void openFileChooser( ValueCallback uploadMsg, String acceptType ) {
	               mUploadMessage = uploadMsg;
	               Intent i = new Intent(Intent.ACTION_GET_CONTENT);
	               i.addCategory(Intent.CATEGORY_OPENABLE);
	               i.setType("*/*");
	               Webpage.this.startActivityForResult(
	               Intent.createChooser(i, "File Browser"),
	               FILECHOOSER_RESULTCODE);
	               }
	
	            //For Android 4.1
	               public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture){
	                   mUploadMessage = uploadMsg;  
	                   Intent i = new Intent(Intent.ACTION_GET_CONTENT);  
	                   i.addCategory(Intent.CATEGORY_OPENABLE);  
	                   i.setType("image/*");  
	                   Webpage.this.startActivityForResult( Intent.createChooser( i, "File Chooser" ), Webpage.FILECHOOSER_RESULTCODE );
	
	               }
	
	        });  
        }
        
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setDefaultTextEncodingName("utf-8");
        //webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        //webSettings.setSavePassword(false);
        //webSettings.setSaveFormData(false);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        
        mWebView.setScrollBarStyle(mWebView.SCROLLBARS_INSIDE_OVERLAY);
        mWebView.setInitialScale(10);
        //mWebView.invokeZoomPicker(); 
        //mWebView.setWebChromeClient(new MyWebChromeClient());
        //mWebView.addJavascriptInterface(new DemoJavaScriptInterface(), "demo");
        //final String mimeType="text/html";
        //final String encoding ="utf-8";
        //final String html ="<img src='http://202.153.107.224/mtp2server/testdb?proc=get_ad&plt=asdw&img=cardPay.png'>";
        //mWebView.loadDataWithBaseURL("", html, mimeType, encoding, "");
        if ("en".equals(Profile.getLanguage())){
        	mWebView.loadUrl(url);
        } else {
        	mWebView.loadUrl(url);
        }
    }
    
    @Override
    public void onBackPressed(){
    	
    	if (myWebView.canGoBack()){
    		myWebView.goBack();
    	} else {
    		super.onBackPressed();
    		overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    	}
    }
    
    public void back2menu(){
    	super.onBackPressed();
    	overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    @Override 
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	//Log.d("here here here","key is:"+keyCode+" boolean:"+(keyCode == KeyEvent.KEYCODE_BACK));
    	// Check if the key event was the Back button and if there's history
    	if ((keyCode == KeyEvent.KEYCODE_BACK) && myWebView.canGoBack()) {
    		myWebView.goBack();
    		return true;
    	}     
    	// If it wasn't the Back key or there's no web page history, bubble up to the default
    	// system behavior (probably exit the activity)
    	return super.onKeyDown(keyCode, event); 
    }	
     
    /*private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return true;
        }
    }*/
    
    protected void onPause(){
    	super.onPause();
    }
    
    protected void onResume() {
    	super.onResume();
    }
    
}
