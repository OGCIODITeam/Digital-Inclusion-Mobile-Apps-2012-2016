package com.mofinity.hkeasy;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import br.com.dina.ui.widget.UITableView;
import br.com.dina.ui.widget.UITableView.ClickListener;

import com.androidquery.AQuery;
import com.mofinity.bean.CachProfile;
import com.mofinity.bean.Profile;
import com.mofinity.model.PostOnFb;
import com.mofinity.util.Tool;

public class Setting extends Activity {
	
	private UITableView accountView;
	private UITableView contactView;
	private UITableView	rateView;
	private Profile profile;
	private AQuery aq_1=null, aq = null;
	
	
	@Override
	public void onResume(){
    	if (CachProfile.setting_reload){
    		CachProfile.setting_reload=false;
    		//finish();
    		//startActivity(getIntent());
    		
    		String version =String.format(getString(R.string.version), Profile.getVersion());
            aq.id(R.id.textVersion).text(version);
            aq.id(R.id.back).text(R.string.back);
            aq.id(R.id.setting).text(R.string.setting);
            createLoadedMenu();
    		
    	} else {
    		createLoadedMenu();
    	}
		super.onResume();
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.setting);  
        //Tool.setLanguage(this, getBaseContext());
        
        accountView = (UITableView) findViewById(R.id.accountSetting);
        contactView = (UITableView) findViewById(R.id.contactButton);
        rateView = (UITableView) findViewById(R.id.rateButton);

        profile = Profile.loadProfile(this);
        aq = new AQuery(this);
        String version =String.format(getString(R.string.version), Profile.getVersion());
        aq.id(R.id.textVersion).text(version);
        aq.id(R.id.back).clicked(this, "close");
       	createLoadedMenu();
    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
    
    public void createLoadedMenu(){
    	accountView.clear();
        contactView.clear();
        rateView.clear();
    	createMenu();
    }
    
    private void createList() {
    	AcctClickListener acctlistener = new AcctClickListener();
    	accountView.setClickListener(acctlistener);
    	String lang =null;
    	if ("en".equals(Profile.getLanguage())){
    		lang = (String)getText(R.string.english);
    	} else if ("zh_TW".equals(Profile.getLanguage())){
    		lang = (String)getText(R.string.chinese);
    	} else if ("ur".equals(Profile.getLanguage())){
    		lang = (String)getText(R.string.pakistanese);
    	} else {
    		lang = (String)getText(R.string.nepalese);
    	}
    	accountView.addBasicItem((String)getString(R.string.language), null, lang);
    	accountView.addBasicItem((String)getString(R.string.facebook));
    	accountView.addBasicItem((String)getString(R.string.share));
    	accountView.addBasicItem((String)getString(R.string.terms));
    	accountView.addBasicItem((String)getString(R.string.aboutus));

    	ContactClickListener contactlistener = new ContactClickListener();
    	contactView.setClickListener(contactlistener);
    	contactView.addBasicItem((String)getText(R.string.contactus));
    	
    	RateClickListener ratelistener = new RateClickListener();
    	rateView.setClickListener(ratelistener);
    	rateView.addBasicItem((String)getText(R.string.appsrating));
    }
       
	
	private void createMenu(){
		
        createList();      
		aq.id(R.id.textVersion).visible();        
        accountView.commit();
        contactView.commit();
        rateView.commit();
	}
	

    
    private class AcctClickListener implements ClickListener {

		@Override
		public void onClick(int index) {
			//Log.d("MainActivity", "item clicked: " + index);
			Intent intent = null;
        	
			if(index == 0) {
				intent = new Intent(Setting.this, Language.class);
			}
			else if (index == 1) {
				try {
				    getPackageManager().getPackageInfo("com.facebook.katana", 0);
					//intent = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://profile/hkeasy1"));
				    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/hkeasy1"));
				} catch (Exception e) {
					intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/hkeasy1"));
				}				
			}
			else if (index == 2) {
				PostOnFb b = new PostOnFb(Setting.this,(String)getText(R.string.hkeasy),profile.logoUrl);
				return;
			}
			else if(index == 3) {
				intent = new Intent(Setting.this, Webpage.class);
			}
			else if(index == 4) {
				intent = new Intent(Setting.this, Webpage.class);
			}
			
			if (intent != null){
				intent.putExtra("index", index);
				startActivity(intent);
			}
		}
    	
    }
    
    private class ContactClickListener implements ClickListener {

		@Override
		public void onClick(int index) {
			Tool.sendemail(Setting.this, new String[]{profile.email}, null, (String)getText(R.string.emailsubject), "", null);
			return;
		}
    }
    
    private class RateClickListener implements ClickListener {

		@Override
		public void onClick(int index) {
			//Log.d("MainActivity", "item clicked: " + index);
			Intent intent = new Intent(Intent.ACTION_VIEW); 
			intent.setData(Uri.parse(profile.marketUrl)); 
			startActivity(intent);
		}
    }
    
}
