package com.mofinity.hkeasy;

import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblMapBean;
import com.mofinity.model.DBOperation;
import com.mofinity.util.Tool;


public class MapList extends ListActivity {

    /** Called when the activity is first created. */
	private AQuery aq_main = null;
	private Profile profile = null;
	private String searchType = null;
	private String title = null;
	private Spinner spinner = null;
	private ArrayAdapter<TblMapBean> aa_result=null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.empty_list);
        
        searchType = getIntent().getStringExtra("searchType");
        title = getIntent().getStringExtra("title");
        
        profile = Profile.loadProfile(this);
        aq_main = new AQuery(this);
       	aq_main.id(R.id.title).visible().text(title);
       	aq_main.id(R.id.search_box).gone();

        aq_main.id(R.id.nomatchresult).gone();
        aq_main.id(R.id.back).clicked(this, "close");
        
	    aq_main.id(R.id.spinner1).visible();
	    defineSpinner();

        renderGroups();

    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
                
	public void renderGroups() {
		
		List<TblMapBean> entries = DBOperation.getMap(this, searchType);
		if (entries == null || entries.size() <=0){
			aq_main.id(R.id.nomatchresult).visible();
			aq_main.id(android.R.id.list).invisible();
			return;
		}
		//Log.d("entries size aaaaa","size:"+entries.size());
	
		aq_main.id(R.id.nomatchresult).gone();
		aa_result = getAA(entries);
		aq_main.id(android.R.id.list).visible().adapter(aa_result).itemClicked(this, "itemClicked");
		//aq_main.id(android.R.id.list).visible().adapter(getAA(entries)).itemClicked(this, "itemClicked");
		
	}
	
	// adaptive array
	
	private List<TblMapBean> list;
	
	private ArrayAdapter<TblMapBean> getAA(List<TblMapBean> entries){
		
		list = new ArrayList<TblMapBean>();
		for(TblMapBean entry : entries){
			list.add(entry);
		}
				
		ArrayAdapter<TblMapBean> result = new ArrayAdapter<TblMapBean>(this, R.layout.list_item, list){
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
	
				if(convertView == null){
					convertView = getLayoutInflater().inflate(R.layout.list_item, null);
				}
				
				TblMapBean ai = (TblMapBean) getItem(position);
				AQuery aq = new AQuery(convertView);

				String name = ai.getName();
				String meta = ai.getPhoneNo();
				String text = ai.getAddress();
				String imageUrl = null;

				if ("zh_TW".equals(Profile.getLanguage())){
					name = ai.getNameZh();
					text = ai.getAddressZh();
				}
				
				if(meta != null ){ 
					text += "   <br/><small><font color=\"brown\">" + getString(R.string.telephone)+": " + meta + "</font></small>";
				}
				
				if (text == null || text.length()<1) {
					aq.id(R.id.detail).gone();
					aq.id(R.id.name).getView().setPadding(10,30,0,30);
					aq.id(R.id.name).text(name);
				} else {
					aq.id(R.id.name).text(name);
					Spanned span = Html.fromHtml(text);
					//Log.d("aaaaaa",""+Tool.getWidth(LibListActivity.this));
					aq.id(R.id.name).getView().setPadding(10,10,0,0);
					aq.id(R.id.detail).getView().setPadding(10,0,0,0);
					aq.id(R.id.detail).text(span);
				}
				//Log.d("aaaaaaaa","value:"+profile.updated.contains(ai.getSid())+" "+ai.getSid());
				if (imageUrl == null || imageUrl.length() < 1){
					//aq.id(R.id.name).width(Tool.getWidth(LibListActivity.this)-190);
					aq.id(R.id.name).width(Tool.getWidth(MapList.this)-190);
					aq.id(R.id.li_img1).gone();
				} else {
					aq.id(R.id.name).width(Tool.getWidth(MapList.this)-240);
					aq.id(R.id.li_img1).visible().width(50).height(50).image(getResources().getIdentifier(imageUrl,"drawable","com.mofinity.hkeasy"));
				}
				
				return convertView;
			}
		};
		
		
		return result;
	}
	
	private void defineSpinner(){
		//spinner 1 for make
	    ArrayAdapter<CharSequence> adapter = null;
	    spinner = (Spinner)findViewById(R.id.spinner1);
	    adapter = new ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    
	    String [] options;
	    options = new String[4];
	    options[0] = getString(R.string.alldistrict);
	    options[1] = getString(R.string.hongkong);
	    options[2] = getString(R.string.kowloon);
	    options[3] = getString(R.string.newterritory);
	
	    for (int i=0; i<options.length; i++){
	    	adapter.add(options[i]);
	    }
	 
	    spinner.setAdapter(adapter);
	    
	    spinner.setOnItemSelectedListener(new GroupItemSelectedListener());
	    
		//ArrayAdapter<CharSequence>aadapter = (ArrayAdapter)spinner.getAdapter();
		//spinner.setSelection(2);
	}
	
	public class GroupItemSelectedListener implements OnItemSelectedListener {
		public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
			if (pos > 0){
				aa_result.clear();
				aq_main.id(android.R.id.list).adapter(getAA(newContents(DBOperation.getMap(MapList.this, searchType),pos)));
				aa_result.notifyDataSetChanged();
			} else {
				aq_main.id(android.R.id.list).adapter(getAA(DBOperation.getMap(MapList.this, searchType)));
				aa_result.notifyDataSetChanged();
			}
		}
		public void onNothingSelected(AdapterView<?> parent) {
			// Do nothing.    }	
		}
	}
	
	public List<TblMapBean> newContents(List<TblMapBean> in, int pos){
		List<TblMapBean> outContents = new ArrayList<TblMapBean>();
		for (int i=0; i<in.size(); i++){
			if (pos > 0){
				if (pos == 1 && !"HK".equals(in.get(i).getDistrict())) continue;
				if (pos == 2 && !"KL".equals(in.get(i).getDistrict())) continue;
				if (pos == 3 && !"NT".equals(in.get(i).getDistrict())) continue;
			}
			outContents.add(in.get(i));
		}
		return outContents;
	}

	public void itemClicked(AdapterView<?> parent, View view, int position, long id){
		
		TblMapBean ai = list.get(position);			
		Intent intent = new Intent(this, BasicMapActivity.class);
		intent.putExtra("searchType",searchType);
		intent.putExtra("title", title);
		intent.putExtra("mapid", ai.getMapId());
		
		startActivity(intent);
	}
        
  
    public void onPause(){
    	super.onPause();
    }
    
}