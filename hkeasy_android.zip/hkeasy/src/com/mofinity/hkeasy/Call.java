package com.mofinity.hkeasy;


import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.androidquery.AQuery;
import com.mofinity.bean.Profile;
import com.mofinity.bean.TblCallBean;
import com.mofinity.model.DBOperation;
import com.mofinity.util.Tool;


public class Call extends ListActivity {

    /** Called when the activity is first created. */
	private AQuery aq = null;
	private Profile profile = null;
	private String searchType = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left);
        setContentView(R.layout.empty_list);
        
        searchType = getIntent().getStringExtra("searchType");
        String title = getIntent().getStringExtra("title");
        //Log.d("Sentance.class","searchType is:"+searchType);
        profile = Profile.loadProfile(this);
        aq = new AQuery(this);
        aq.id(R.id.title).visible().text(title);
        aq.id(R.id.nomatchresult).gone();
        aq.id(R.id.back).clicked(this, "close");
        aq.id(R.id.search_box).gone();
        //aq.id(R.id.next).gone();
        
        aq.id(R.id.search).clicked(this, "search");
        renderGroups();

    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    
    public void close(){
    	onBackPressed();
    }
    
    @Override
    public void onResume(){
    	super.onResume();
    }
    
    public void search(View view){
    	Tool.hideKeyboard(Call.this, view);
    	
    }
    
    /*public void upload(View view){
    	Intent intent = new Intent(Call.this, Call.class);
    	startActivity(intent);
    	finish();
    }*/
    
    public void renderGroups() {
		
		List<TblCallBean> entries = loadCall();

		if (entries == null || entries.size() <=0){
			aq.id(R.id.nomatchresult).visible();
			aq.id(android.R.id.list).invisible();
			return;
		}
	
		aq.id(R.id.nomatchresult).gone();
		//createCallButton(entries);
		aq.id(android.R.id.list).visible().adapter(getAA(entries)).itemClicked(this, "itemClicked");
	}

	public List<TblCallBean> loadCall(){
		return DBOperation.getCall(this, searchType);
	}
	
	/*
	public void createCallButton(List<TblCallBean> entries){
		LinearLayout ll = (LinearLayout)aq.id(R.id.content_list).getView();
		int i=0;
		for (TblCallBean entry: entries){
			String name = entry.getTitle();
			if ("en".equals(Profile.getLanguage())){

			} else if ("zh_TW".equals(Profile.getLanguage())){
				name = entry.getTitleZh();
			} else if ("ur".equals(Profile.getLanguage())){
				name = entry.getTitleUd();
			} else if ("ne".equals(Profile.getLanguage())){
				name = entry.getTitleNe();
			}
			
			TextView a = ViewTool.createTextView(this, name, i);
			a.setOnClickListener(new OnClickListener(){
				public void onClick(View v){
	        		try {

	        		} catch (ActivityNotFoundException ex) {
	        			Log.e("Call.class", "Call failed", ex);
	        		}
			}
			});
			i++;
			ll.addView(a);
		}
		
	}*/
	
	// adaptive array
	
	private List<TblCallBean> list;
	
	private ArrayAdapter<TblCallBean> getAA(List<TblCallBean> entries){
		
		list = new ArrayList<TblCallBean>();
		for(TblCallBean entry : entries){
			list.add(entry);
		}
				
		ArrayAdapter<TblCallBean> result = new ArrayAdapter<TblCallBean>(this, R.layout.list_item, list){
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				
				if(convertView == null){
					convertView = getLayoutInflater().inflate(R.layout.list_item, null);
				}
				
				TblCallBean ai = (TblCallBean) getItem(position);
				AQuery aq = new AQuery(convertView);
				
				String name = ai.getTitle();
				
				if ("zh_TW".equals(Profile.getLanguage())){
					name = ai.getTitleZh();
				}
				
				//if not value, use english as default.
				if (name == null ||name.length()<=0){
					name = ai.getTitle();
				}

				
				String meta = null;
				String text = ai.getPhoneNo();
				String imageUrl = null;
				
				if(meta != null ){ 
					text += "   <br/><small><font color=\"brown\">" + meta + "</font></small>";
				}

				Spanned span = Html.fromHtml(text);
				aq.id(R.id.name).text(name);
				
				if (text == null || text.length()<1) {
					aq.id(R.id.detail).gone();
					aq.id(R.id.name).getView().setPadding(10,30,0,30);
				} else {
					//Log.d("aaaaaa",""+Tool.getWidth(LibListActivity.this));
					aq.id(R.id.name).getView().setPadding(10,10,0,0);
					aq.id(R.id.detail).getView().setPadding(10,0,0,0);
					aq.id(R.id.detail).text(span);
				}
				//Log.d("aaaaaaaa","value:"+profile.updated.contains(ai.getSid())+" "+ai.getSid());
				if (imageUrl == null || imageUrl.length() < 1){
					//aq.id(R.id.name).width(Tool.getWidth(LibListActivity.this)-190);
					aq.id(R.id.name).width(Tool.getWidth(Call.this)-190);
					aq.id(R.id.li_img1).gone();
				} else {
					aq.id(R.id.name).width(Tool.getWidth(Call.this)-215);
					aq.id(R.id.li_img1).visible().width(25).height(25).image(getResources().getIdentifier(imageUrl,"drawable","com.mofinity.hkeasy"));
				}
				
				return convertView;
			}
		};
		
		
		return result;
	}	
	
	public void itemClicked(AdapterView<?> parent, View view, int position, long id){
		
		TblCallBean ai = list.get(position);
		//Log.d("aaaaaaaaaaaaaaaa","click at:"+position+" |"+ai.getPhoneNo()+"|");
		Intent callIntent = new Intent(Intent.ACTION_DIAL);
		callIntent.setData(Uri.parse("tel:"+ai.getPhoneNo()));
		startActivity(callIntent);
	}
        
    public void onPause(){
    	super.onPause();
    }
    
}