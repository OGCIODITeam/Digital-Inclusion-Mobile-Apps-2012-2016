package com.mofinity.util;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;

import com.mofinity.hkeasy.R;


public class ViewTool{
	private static final String classname="ViewTool";

	public static void removeTableView(TableLayout tl){
    	tl.removeAllViews();
    }
    
    public static void addTableView(TableLayout tl, TableRow tr){
        // Policy screen define
     	
        tl.addView(tr,new TableLayout.LayoutParams(
               android.view.ViewGroup.LayoutParams.FILL_PARENT,
               android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
    }
    
    public static ImageView createImageView(Context ctx, int image_id, int height, int width){
        //image button
        ImageView img_add = new ImageView(ctx);
        img_add.setAdjustViewBounds(false);
        img_add.setScaleType(ImageButton.ScaleType.FIT_CENTER);
        img_add.setImageResource(image_id);
        img_add.setLayoutParams(new LayoutParams(
                android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        img_add.getLayoutParams().height = height;
        img_add.getLayoutParams().width = width;
        return img_add;

    }
    
    public static ImageView createImageView(Context ctx, String image_path, int height, int width){
    	final ImageView img_add1 = new ImageView(ctx);
        img_add1.setAdjustViewBounds(false);
        img_add1.setScaleType(ImageButton.ScaleType.FIT_CENTER);

        if (image_path != null) {
       	 	Tool.loadImageOnView(img_add1, image_path, width, height);
        } else {
        	img_add1.setImageResource(R.drawable.space);
        } 
        
        img_add1.setLayoutParams(new LayoutParams(
                android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        img_add1.getLayoutParams().height = height;
        img_add1.getLayoutParams().width = width;
        
        return img_add1;
    }
    
    public static CheckedTextView createCheckedTextView(Context ctx, String label_txt, int label_id){
    	CheckedTextView b = new CheckedTextView(ctx);
   	  	if (label_txt != null){
   		  b.setText(label_txt);
   	  	} else {
   	  		Log.e(classname, "label_txt is null:" + label_txt);
   	  	}
   	  	b.setId(label_id);
        b.setLayoutParams(new LayoutParams(
                  android.view.ViewGroup.LayoutParams.FILL_PARENT,
                  android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(20, 15, 0, 15);
        b.setTextColor(Color.BLACK);
        b.setTextSize(18);
        return b;
    }
    
    public static TextView createTextView(Context ctx, String label_txt, int label_id){
    	TextView b = new TextView(ctx);
   	  	if (label_txt != null){
   		  b.setText(label_txt);
   	  	} else {
   		  Log.e(classname, "label_txt is null:" + label_txt);
   	  	}
   	  	b.setId(label_id);
        b.setLayoutParams(new LayoutParams(
                  android.view.ViewGroup.LayoutParams.FILL_PARENT,
                  android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(20, 15, 0, 15);
        b.setTextColor(Color.BLACK);
        b.setTextSize(18);
        return b;
    }

    public static EditText createEditText(Context ctx, String label_txt, int label_id, int width){
    	EditText b = new EditText(ctx);
   	  	if (label_txt != null){
   		  b.setHint(label_txt);
   	  	} else {
   		  Log.e(classname, "label_txt is null:" + label_txt);
   	  	}
   	  	b.setId(label_id);
        b.setLayoutParams(new LayoutParams(
                  android.view.ViewGroup.LayoutParams.FILL_PARENT,
                  android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        b.getLayoutParams().width = width;
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(20, 15, 0, 15);
        b.setTextColor(Color.BLACK);
        b.setTextSize(18);
        return b;
    }
    
    public static Button createButton(Context ctx, String label_txt, int label_id, int width){
    	Button b = new Button(ctx);
   	  	if (label_txt != null){
   		  b.setHint(label_txt);
   	  	} else {
   		  Log.e(classname, "label_txt is null:" + label_txt);
   	  	}
   	  	b.setId(label_id);
        b.setLayoutParams(new LayoutParams(
                  android.view.ViewGroup.LayoutParams.FILL_PARENT,
                  android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        b.getLayoutParams().width = width;
        b.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL);
        b.setPadding(20, 15, 0, 15);
        b.setTextColor(Color.BLACK);
        b.setTextSize(18);
        return b;
    }
    
    public static TableRow createTableRow(Context ctx){
    	return createTableRow(ctx, true);
    }
    public static TableRow createTableRow(Context ctx, boolean bg){
    	TableRow tr = new TableRow(ctx);
        tr.setLayoutParams(new LayoutParams(
                android.view.ViewGroup.LayoutParams.FILL_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                ));
        if (bg){
        	tr.setBackgroundDrawable(tr.getContext().getResources().getDrawable(R.drawable.table_border1));
        }
        tr.setGravity(Gravity.CENTER_VERTICAL);
        return tr;
    }    
}
