package com.mofinity.util;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import android.util.Log;

 public class AES256Cipher {
	 
	public static String encrypt(String message){
		try {
			//message = "1,1,96131724";
			byte[] ib = message.getBytes("UTF-8");
			byte[] key = "abc123456789abcd".getBytes("UTF-8");
			//byte[] key = "cslrbtapi0123456".getBytes("UTF-8");
			byte[] iv = "0102030405060708".getBytes("UTF-8");
			//iv =new byte[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		
			byte[] result = encrypt(iv, key, ib);
//			Log.d("aaaaaaaaaa","size:"+result.length);
//			Log.d("bbbbbbbbb",Tool.byte2hex(result));
//			String base64Text = Base64.encodeToString(result, Base64.DEFAULT);
//			Log.d("AES256Cipher.class", base64Text);
			//byte[] a = decrypt(iv, key, result);
			//Log.d("AES256Cipher.class", new String(a));
			return Tool.byte2hex(result);
		} catch (Exception ex){
			Log.e("AES256Cipher.class", "error is:"+ex.toString());
			return null;
		} 
	}
	 
	public static byte[] encrypt(byte[] ivBytes, byte[] keyBytes, byte[] textBytes) 			
		throws java.io.UnsupportedEncodingException, 				
		NoSuchAlgorithmException,				
		NoSuchPaddingException,				
		InvalidKeyException,				
		InvalidAlgorithmParameterException,				
		IllegalBlockSizeException,				
		BadPaddingException {
			AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
	    	SecretKeySpec newKey = new SecretKeySpec(keyBytes, "AES");
	    	Cipher cipher = null;
			cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
			return cipher.doFinal(textBytes);
	}
 
	public static byte[] decrypt(byte[] ivBytes, byte[] keyBytes, byte[] textBytes) 			
			throws java.io.UnsupportedEncodingException, 			
			NoSuchAlgorithmException,			
			NoSuchPaddingException,			
			InvalidKeyException,			
			InvalidAlgorithmParameterException,			
			IllegalBlockSizeException,			
			BadPaddingException {				
				AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
				SecretKeySpec newKey = new SecretKeySpec(keyBytes, "AES");
				Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
				cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
				return cipher.doFinal(textBytes);
	}} 
 
