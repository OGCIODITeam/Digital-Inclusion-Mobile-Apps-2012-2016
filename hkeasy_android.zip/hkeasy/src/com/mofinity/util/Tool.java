package com.mofinity.util;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.http.util.ByteArrayBuffer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CountDownTimer;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.mofinity.hkeasy.R;
import com.mofinity.util.Utility.FlushedInputStream;




public class Tool{
	
	public static String byte2hex(byte[] b) { 
		String hs = "";
		String stmp = "";
		for (int n = 0; n < b.length; n++) {
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1) {
				hs = hs + "0" + stmp;
			}
			else {
				hs = hs + stmp;
			}
		}
		return hs.toLowerCase();
	}

	public static String getLimitedText(int no_of_line, int size, String tmp){
		if (size <=0) size=18;
		
		Paint mPaint = new Paint();
		mPaint.setTextSize(size);
		mPaint.setTypeface(Typeface.DEFAULT);
		//Rect bounds = new Rect();
		//mPaint.getTextBounds(tmp, 0, tmp.length(), bounds);
		
		int num_of_char = mPaint.breakText(tmp.toCharArray(), 0, tmp.length(), 300, null);
		
		num_of_char = no_of_line * num_of_char;

		if (tmp.length() > num_of_char){
			tmp = tmp.substring(0,num_of_char)+"...";
		}
		return tmp;
	}

    public static void setAlertMessage (Context cx, String title, String message, String confirm){
    	AlertDialog alertDialog = new AlertDialog.Builder(cx).create();
    	alertDialog.setTitle(title);
    	alertDialog.setMessage(message);
    	alertDialog.setButton(confirm, new DialogInterface.OnClickListener() {
    		public void onClick(DialogInterface dialog, int which) {
    			return;
    		} }); 
    	alertDialog.show();
    }
    
    public static void hideKeyboard(Context cx, View view){
    	InputMethodManager imm = (InputMethodManager) cx.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(view.getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
    }
    
    public static void networkErrorAlert(Context ctx){

    	setAlertMessage(ctx, ctx.getString(R.string.networkerror), "", ctx.getString(R.string.ok));
    	
		//Intent intent = new Intent(ctx, ErrorPage.class);
		//ActivityStack activityStack = (ActivityStack) ((Activity) ctx).getParent();
		//activityStack.push("ToErrorPage", intent);
    }
    
    public static ProgressDialog setProgressBarDialog(Context ctx, String message){
    	ProgressDialog pd = new ProgressDialog(ctx);
    	pd.setMessage(message);
    	pd.setCancelable(false);
    	pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    	pd.setProgress(0);
    	pd.show();
    	return pd;
    }
    
    public static ProgressDialog setProgressBarDialog1(Context ctx, String message){
    	ProgressDialog dialog = new ProgressDialog(ctx); 
    	dialog.setIndeterminate(true);
    	dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    	dialog.setCancelable(true); 
    	dialog.setInverseBackgroundForced(false); 
    	dialog.setCanceledOnTouchOutside(true); 
    	dialog.setTitle(message);
    	return dialog;
    }
    
    public static ProgressDialog setProgressDialog(Context ctx, String message){
    	return(ProgressDialog.show(ctx, message,ctx.getString(R.string.loading),false, true));
    	/*ProgressDialog pd = new ProgressDialog(ctx);
    	pd.setTitle(message);
    	pd.setMessage(message);
    	pd.setCancelable(false);
    	pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
    	pd.show();
    	return pd;*/
    }
        
    public static String getDate(String tmp){
    	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss", Locale.ENGLISH);
    	String msg = "";
    	try{
    		Date result =  df.parse(tmp);
    		DateFormat sf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
    		msg = sf.format(result);
    	} catch (Exception ex){}
    	return msg;
    }

    public static String getDateSimple(String tmp){
    	DateFormat df = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
    	String msg = "";
    	try{
    		Date result =  df.parse(tmp);
    		DateFormat sf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
    		msg = sf.format(result);
    	} catch (Exception ex){}
    	return msg;
    }

    
    public static String handleSpecialChar(String message){
    	message = message.replaceAll("&","&amp;");
    	message = message.replaceAll(">", "&gt;");
    	message = message.replaceAll("<", "&lt;");
    	message = message.replaceAll("'", "&apos;");
    	message = message.replaceAll("\"", "&quot;");
    	return message;
    }
    
    public static float getpxfromdp(Context ctx, int val){
        Resources r = ctx.getResources(); 
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, r.getDisplayMetrics());
    }
    
    public static int[] getScreenSize(Activity activity){
    	Display display = activity.getWindowManager().getDefaultDisplay();  
    	int width = display.getWidth(); 
    	int height = display.getHeight();
    	return new int[]{width, height};
    }
    
    public static int getWidth(Activity activity){
    	return getScreenSize(activity)[0];
    }
    
    public static void setLanguage(Context ctx, Context baseContext){
    	SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
    	String storedLocale = pref.getString("storedLocale", null);
    	Locale cur_locale = null;
    	//Log.d("stored","store chinese:"+storedLocale);
    	if (storedLocale != null && storedLocale.equals("zh_TW")){
    		cur_locale = Locale.TRADITIONAL_CHINESE;
    	} else if (storedLocale.equals("en")) {
    		cur_locale = Locale.ENGLISH;
    	} else if (storedLocale.equals("ur")){
    		cur_locale = new Locale("ur");
    	} else if (storedLocale.equals("ne")){
    		cur_locale = new Locale("ne");
    	}
		Configuration config1 = new Configuration();
		config1.locale = cur_locale;
		baseContext.getResources().updateConfiguration(config1, baseContext.getResources().getDisplayMetrics());
    }
    
    public static void setupPreferenceLang(Context ctx, String lang){
    	SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
    	
        if (lang != null){
        	if ("zh_TW".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "zh_TW");
		        editor.commit();
        	} else if ("en".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "en");
		        editor.commit();
        	} else if ("ur".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "ur");
		        editor.commit();
        	} else if ("ne".equals(lang)){
		        SharedPreferences.Editor editor = pref.edit();
		        editor.putString("storedLocale", "ne");
		        editor.commit();
        	} 
        }
    	
        Tool.setLanguage(ctx,((Activity)ctx).getBaseContext());
    }


    /*
    public static Bitmap captureScreenImage(Context cx, Vector<CoordinateObj>damagepart){
    	Paint paint = new Paint(); 

    	double factor = ((double)Tool.getWidth((Activity)cx))/Tool.getpxfromdp(cx, 320);
    	Bitmap returnedBitmap = null; 
    	if (factor > 2){
    		returnedBitmap = Bitmap.createBitmap(800, 1200,Bitmap.Config.ARGB_8888);
    	} else if (factor > 1.5){
    		returnedBitmap = Bitmap.createBitmap(600, 1000,Bitmap.Config.ARGB_8888);
    	} else if (factor >=1.25){
    		returnedBitmap = Bitmap.createBitmap(600, 1000,Bitmap.Config.ARGB_8888);
    	} else {
    		returnedBitmap = Bitmap.createBitmap(500, 800,Bitmap.Config.ARGB_8888);
    	}
    	
    	Canvas canvas = new Canvas(returnedBitmap);
    	canvas.drawColor(Color.WHITE);
    	Bitmap car = null;
    	if (factor >= 2.5){
    		car = BitmapFactory.decodeResource(cx.getResources(),R.drawable.motor_2_5);
    	} else if (factor >= 1.75){
    		car = BitmapFactory.decodeResource(cx.getResources(),R.drawable.motor_1_75);
    	} else if (factor >= 1.5){
    		car = BitmapFactory.decodeResource(cx.getResources(),R.drawable.motor_1_5);
    	} else if (factor >= 1.25){
    		car = BitmapFactory.decodeResource(cx.getResources(),R.drawable.motor_1_25);
    	} else {
    		car = BitmapFactory.decodeResource(cx.getResources(),R.drawable.motor);
    	}
    	
    	canvas.drawBitmap(car, 0, 0, paint);
    	Bitmap crossimg = BitmapFactory.decodeResource(cx.getResources(),R.drawable.bandaid1);
    	for (CoordinateObj e:damagepart){
    		canvas.drawBitmap(crossimg, e.getCoordinate()[0], e.getCoordinate()[1], null);
    	}
    	//al.draw(canvas);
    	return returnedBitmap;
    }*/
    
    public static void bitmap2file(Bitmap img, String fullname){
    	ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    	FileOutputStream fo = null;
    	try {
	    	img.compress(Bitmap.CompressFormat.JPEG, 40, bytes);  
	    	//you can create a new file name "test.jpg" in sdcard folder. 
	    	File f = new File(fullname); 
	    	f.createNewFile(); 
	    	//write the bytes in file 
	    	fo = new FileOutputStream(f); 
	    	fo.write(bytes.toByteArray());
	    	fo.close();
    	} catch (Exception ex){
    		Log.e("Tool","Error on write to file path:"+fullname, ex);
    	} finally {
    		try {
    			if (fo != null){
    				fo.close();
    			}
    		} catch (Exception ex){	}
    	}
    }
    
    public static void deletefiles(String fullname){
    	try {
    		File file = new File(fullname);
    		file.delete();
    	} catch (Exception ex){
    		Log.e("Tool", "Fail on delete file.", ex);
    	}
    }
    public static void sendemail(Context context, String[] emailTos, String[] emailCCs,
    		String subject, String emailText, List<String> filePaths) {
    	//need to "send multiple" to get more than one attachment     
    	final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND_MULTIPLE);
    	emailIntent.setType("plain/text");
    	//emailIntent.setType("message/rfc822");
    	if (emailTos != null){
    		//Log.d("aaaaaaaaaaaaaaaaaaaa", "email to:"+emailTos[0]);
    		emailIntent.putExtra(Intent.EXTRA_EMAIL,          
    			emailTos); 
    	}
    	if (emailCCs != null){
    		emailIntent.putExtra(Intent.EXTRA_CC,          
    			emailCCs);    
    	}
    	if (subject != null){
    		emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
    	}

    	if (emailText!= null){
    		emailIntent.putExtra(Intent.EXTRA_TEXT, emailText);
    	}
    	    	
    	//has to be an ArrayList     
    	ArrayList<Uri> uris = new ArrayList<Uri>();     
    	//convert from paths to Android friendly Parcelable Uri's
    	if (filePaths != null){
	    	for (String file : filePaths)     
	    	{         
	    		File fileIn = new File(file);
	    		Uri u = Uri.fromFile(fileIn);
	    		uris.add(u);     
	   		}     
	    	emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
    	}
    	context.startActivity(Intent.createChooser(emailIntent, "Send mail..."));  
    }

    
    public static String getFilename(String fullname){
    	if (fullname == null) return "";
    	int pos = fullname.lastIndexOf(File.separator);
    	return fullname.substring(pos+1);
    }
    
    public static boolean checkfiles(String path, String filename){
    	
    	File directory = new File(path); 
    	directory.mkdirs();
    	java.io.File file = new java.io.File(path , filename); 
    	if (file.exists()) {   
    		Log.i("Tool","file exists");
    		return true; 
    	}
    	Log.i("Tool","file not exists");
    	return false;
    }
    
    public static boolean isExist(String path){
    	java.io.File file = new java.io.File(path);
    	if (file.exists()){
    		return true;
    	}
    	return false;
    }
    
    public static void copyDatabase(Context ctx, String in_path_file, String dbname){
 	   InputStream in = null;
 	   OutputStream out = null;
     	try {
     		if (in_path_file == null){
     			in = ctx.getAssets().open("rsa.sqlite3");
     		} else {
     			in = new FileInputStream(in_path_file);
     		}
     		out = new FileOutputStream("/data/data/com.mofinity.hkeasy/databases/"+dbname);
     		
     		byte[] buffer = new byte[1024];
     		int length;
     		while((length = in.read(buffer))>0){
     			out.write(buffer,0,length);
     		}
     		out.flush();
     	} catch (Exception ex){
     		Log.e("Tool", "Fail on copy database:", ex);
     	} finally {
     		try{
     			if (in != null) in.close();
     			if (out!= null) out.close();
     		} catch (Exception ex){}
     	}
     }
    
    public static void copyRWFile(Context cox, String in_fullname, String store_fullname){
  	   InputStream in = null;
  	   OutputStream out = null;
      	try {

      		in = new FileInputStream(in_fullname);
      		out = cox.openFileOutput(store_fullname, Context.MODE_WORLD_WRITEABLE|Context.MODE_WORLD_READABLE);
      		
      		byte[] buffer = new byte[1024];
      		int length;
      		while((length = in.read(buffer))>0){
      			out.write(buffer,0,length);
      		}
      		out.flush();
      	} catch (Exception ex){
      		Log.e("Tool", "Fail on copy Files:", ex);
      	} finally {
      		try{
      			if (in != null) in.close();
      			if (out!= null) out.close();
      		} catch (Exception ex){}
      	}
      } 

    public static void copyFile(String in_fullname, String store_fullname){
   	   InputStream in = null;
   	   FileOutputStream out = null;
       	try {

       		in = new FileInputStream(in_fullname);
       		out = new FileOutputStream(store_fullname);
       		
       		byte[] buffer = new byte[1024];
       		int length;
       		while((length = in.read(buffer))>0){
       			out.write(buffer,0,length);
       		}
       		out.flush();
       	} catch (Exception ex){
       		Log.e("Tool", "Fail on copy Files:", ex);
       	} finally {
       		try{
       			if (in != null) in.close();
       			if (out!= null) out.close();
       		} catch (Exception ex){}
       	}
      } 
    
	public static CountDownTimer showCounter(final TextView label, int second, final AudioRecorder adr){
		 CountDownTimer a = new CountDownTimer(second * 1000, 1000) {     
			 public void onTick(long millisUntilFinished) {         
				 label.setText("" + millisUntilFinished / 1000);     
			 }     
			 public void onFinish() {
				 label.setText("done!");
					 try{
						 adr.stop();
					 } catch (Exception ex){
					 }
				 }
			 }.start();
			 return a;
		}
	
	public static int getCurHour(){
		final Calendar c = Calendar.getInstance();
		return c.get(Calendar.HOUR_OF_DAY);
	}
	
	public static String getCurDate(){
    	final Calendar c = Calendar.getInstance();
    	int myYear = c.get(Calendar.YEAR);
    	int myMonth = c.get(Calendar.MONTH);
    	int myDay = c.get(Calendar.DAY_OF_MONTH);
    	int myHour = c.get(Calendar.HOUR_OF_DAY);
    	int myMinute = c.get(Calendar.MINUTE);
    	return (getDate(myYear, myMonth, myDay)+" "+getTime(myHour, myMinute));
	}
    
    public static String getDate(int myYear, int myMonth, int myDay){
    	String year = String.valueOf(myYear);
    	String month = String.valueOf(myMonth+1);
    	String day = String.valueOf(myDay);
    	
    	if (month.length()<= 1) month = "0"+month;
    	if (day.length() <= 1) day = "0"+day;
    	
    	return year+"-"+month+"-"+day;
    }
    
    public static String getTime(int myHour, int myMinute){
    	String hour = String.valueOf(myHour);
    	String minute = String.valueOf(myMinute);
    	if (hour.length() <= 1) hour = "0"+hour;
    	if (minute.length() <= 1) minute ="0"+minute;
    	return hour+":"+minute;
    }
    
    public static String getFiletype(String filename){
    	int pos1 = filename.lastIndexOf(".");
    	if (pos1 >0){
    		return filename.substring(pos1+1);
    	} 
    	Log.e("Tool", "Error on photo name");
    	return null;
    }
    

    public static void resizePhoto(String filename){
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 2;
		Bitmap bmp = BitmapFactory.decodeFile(filename,options);
		
    	try {
    		String ext = getFiletype(filename);
    		FileOutputStream out = new FileOutputStream(filename);
    		if (ext.equalsIgnoreCase("png")){
    			bmp.compress(Bitmap.CompressFormat.PNG, 90, out);
    		} else if (ext.equalsIgnoreCase("jpg")){
    			bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
    		} else {
    			//do nothing.
    		}
    	} catch (Exception e) {        
    		e.printStackTrace(); 
    	} 
    }
    
    // input path, it will load image and display on car_photo imageview.
    public static int loadImageOnView(ImageView photo, String path, int newWidth, int newHeight){
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 10;
		Bitmap bm = BitmapFactory.decodeFile(path,options);
		// if cannot load the file, return immediately and do nothing.
		if (bm == null) return -1;
		
		int width = bm.getWidth();
		int height = bm.getHeight();
		
		if (newWidth == 0 || newHeight == 0){
			newWidth = width;
			newHeight = height;
		}
		float scaleWidth = ((float) newWidth)/width;
		float scaleHeight = ((float)newHeight)/ height;

		if (scaleWidth > scaleHeight) scaleWidth = scaleHeight;
		else scaleHeight = scaleWidth;
		
		if (scaleHeight >1) {
			scaleHeight = 1;
			scaleWidth = 1;
		}
				
		Matrix matrix = new Matrix();
		matrix.postScale(scaleWidth, scaleWidth);
		//matrix.postRotate(45);
		
		Bitmap resizebm = Bitmap.createBitmap(bm, 0, 0, width, height, matrix , true);
		
		photo.setImageBitmap(resizebm); 

		photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
		return 0;
    }
    
    // And to convert the image URI to the direct file system path of the image file 
    public static String getRealPathFromURI(Activity atx, Uri contentUri) {
    	// can post image         
    	String [] proj={MediaStore.Images.Media.DATA};
    	Cursor cursor = atx.managedQuery( contentUri,
    			proj,    // Which columns to return
    			null,    // WHERE clause; which rows to return (all rows)
    			null,    // WHERE clause selection arguments (none)
    			null); 	 // Order-by clause (ascending by name)
    	int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
    	cursor.moveToFirst();
    	return cursor.getString(column_index); 
    }

    public static  void DownloadFromUrl(String imageURL, String fileName) {  //this is the downloader method
    	try {
    		URL url = new URL(imageURL); 
    		//you can write here any link
    	    File file = new File(fileName);
    	
    	    URLConnection ucon = url.openConnection();
    	    ucon.setConnectTimeout(30*1000);
    	    InputStream is = ucon.getInputStream();
    	    BufferedInputStream bis = new BufferedInputStream(is);
    	
            /*
            * Read bytes to the Buffer until there is nothing more to read(-1).
            */
            ByteArrayBuffer baf = new ByteArrayBuffer(50);
            int current = 0;
            while ((current = bis.read()) != -1) {
            	baf.append((byte) current);
    	    }
    	 
    	/* Convert the Bytes read to a String. */
    	FileOutputStream fos = new FileOutputStream(file);
    	fos.write(baf.toByteArray());
    	fos.close();
    	
    	} catch (IOException e) {
    		Log.e("Tool", "Path: "+imageURL+" error message",  e);
    	} 
    }
     
    public static Bitmap DownloadBitmap(String stringUrl) {
        URL url = null;
        HttpURLConnection connection = null;
        InputStream inputStream = null;
        
        try {
            url = new URL(stringUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setUseCaches(true);
            inputStream = connection.getInputStream();
            
            return BitmapFactory.decodeStream(new FlushedInputStream(inputStream));
        } catch (Exception e) {
            Log.w("Tool.class", "Error while retrieving bitmap from " + stringUrl, e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        
        return null;
    }

    public static Bitmap DownloadBitmap(String stringUrl, String fileName) {
        URL url = null;
        HttpURLConnection connection = null;
        InputStream inputStream = null;
        File file = new File(fileName);
        
        try {
            url = new URL(stringUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setUseCaches(true);
            inputStream = connection.getInputStream();

            BufferedInputStream bis = new BufferedInputStream(inputStream);
        	
            /*
            * Read bytes to the Buffer until there is nothing more to read(-1).
            */
            ByteArrayBuffer baf = new ByteArrayBuffer(50);
            int current = 0;
            while ((current = bis.read()) != -1) {
            	baf.append((byte) current);
    	    }
    	 
	    	/* Convert the Bytes read to a String. */
	    	FileOutputStream fos = new FileOutputStream(file);
	    	fos.write(baf.toByteArray());
	    	fos.close();
    	
    	
            return BitmapFactory.decodeStream(new FlushedInputStream(inputStream));
        } catch (Exception e) {
            Log.w("Tool.class", "Error while retrieving bitmap from " + stringUrl, e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        
        return null;
    }
    
    public static String getStorageDirectory(){
    	return (Environment.getExternalStorageDirectory()+File.separator+"Mofinity"+File.separator);
    	//return (File.separator+"data"+File.separator+"data"+File.separator+"com.mofinity.rsa"+File.separator+"photo"+File.separator);
    }
    
    public static String getDatabaseDirectory(){
    	return (File.separator+"data"+File.separator+"data"+File.separator+"com.mofinity.hkeasy"+File.separator+"databases"+File.separator);
    }
    
    public static String getCacheDirectory() {
    	return (File.separator+"data"+File.separator+"data"+File.separator+"com.mofinity.hkeasy"+File.separator+"cache"+File.separator);

    }
    public static String getDatabaseName(){
    	return ("hkeasy.db");
    }
    
    public static byte[] image2Blob(String path){
    	ByteArrayOutputStream baos = new ByteArrayOutputStream();  
    	
    	Bitmap bm = BitmapFactory.decodeFile(path);
    	bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
    	byte[] photo = baos.toByteArray();
    	return photo;
    }
    
    public static int[] imageWidth(String path){
    	Bitmap bm = BitmapFactory.decodeFile(path);
    	int[] a = {bm.getHeight(), bm.getWidth()};
    	return a;
    }
    
    public static Bitmap blob2Image(byte[] img){
    	ByteArrayInputStream imageStream = new ByteArrayInputStream(img);
    	Bitmap theImage= BitmapFactory.decodeStream(imageStream);
    	return theImage;
    }
    
    public static boolean isDBExists(){
    	File dir = new File(getDatabaseDirectory());
    	dir.mkdirs();
    	if (dir.isDirectory()){
    		String[] children = dir.list();
    		for (int i=0; i< children.length; i++){
    			Log.d("Tool.class","DB name is:"+children[i]);
    		}
    		return (children.length > 0);
    	}
    	return false;
    }
    
    public static File byte2File(String fullname, byte[] data){
       	ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    	FileOutputStream fo = null;
    	File f = null;
    	try {  
	    	//you can create a new file name "test.jpg" in sdcard folder.
	    	f = new File(fullname); 
	    	//f.deleteOnExit();
	    	f.createNewFile(); 
	    	//write the bytes in file 
	    	fo = new FileOutputStream(f); 
	    	fo.write(data);
	    	fo.close();
	    	return f;
    	} catch (Exception ex){
    		Log.e("Tool","Error on write to file path:"+fullname, ex);
    		return null;
    	} finally {
    		try {
    			if (fo != null){
    				fo.close();
    			}
    		} catch (Exception ex){	}
    	}
    }
    public static File byte2TempFile(Context ctx, byte[] mp3SoundByteArray) {
        try {
            // create temp file that will hold byte array
            File file = File.createTempFile("tta", "mp3", ctx.getCacheDir());
            file.deleteOnExit();
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(mp3SoundByteArray);
            fos.close();
            //Log.d("aaaaaaaaaaaaaaaa", "path:"+file.getAbsolutePath());
            
            return file;
        } catch (IOException ex) {
            String s = ex.toString();
            ex.printStackTrace();
            return null;
        }
    }
    
    public static int getResId(String variableName, Context context, Class<?> c) {

        try {
            Field idField = c.getDeclaredField(variableName);
            return idField.getInt(idField);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        } 
        
        //getResId("icon", context, Drawable.class);
    }
}
