package com.mofinity.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import android.content.Context;
import android.util.Log;


public class StoreObj {

	private static final String classname="StoreObj";
	
	public static void storeObject(Context cx, Serializable obj, String filename){
		ObjectOutputStream os = null; 
		try {
			FileOutputStream fos = cx.openFileOutput(filename, Context.MODE_PRIVATE);
			os = new ObjectOutputStream(fos);
			os.writeObject(obj);
			os.close();
		} catch (FileNotFoundException ex){
			Log.e(classname, "FileNotFound", ex);
		} catch (IOException ex1){
			Log.e(classname, "IOException",ex1);
		} finally {
			try {
				if (os != null){
					os.flush();
					os.close();
				}
			} catch (IOException ex){}
		}
	}

	public static Object readObject(Context cx, String filename){
		ObjectInputStream is = null;
		Object obj = null;
		try {
			FileInputStream fis = cx.openFileInput(filename);
			is = new ObjectInputStream(fis);
            obj = is.readObject();
		} catch (FileNotFoundException ex){
			Log.e(classname, "FileNotFound", ex);
		} catch (IOException ex1){
			Log.e(classname, "IOException",ex1);
		} catch (ClassNotFoundException nex){
			Log.e(classname, "ClassNotFoundException",nex);
		} finally {
			try {
				if (is != null){
					is.close();
				}
			} catch (IOException ex){}
		}
		return obj;
	}
}
