package com.mofinity.model;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.android.AsyncFacebookRunner;
import com.facebook.android.DialogError;
import com.facebook.android.Facebook;
import com.facebook.android.Facebook.DialogListener;
import com.facebook.android.FacebookError;
import com.mofinity.bean.Profile;
import com.mofinity.facebook.BaseRequestListener;
import com.mofinity.facebook.SessionEvents.AuthListener;
import com.mofinity.facebook.Utility;
import com.mofinity.hkeasy.R;


public class PostOnFb {

	/* Edit HKEasy on mofinity.hkeasy@gmail.com
	 */
	
    private static final String APP_ID = "230136700496247";//"553002914794123";//"230136700496247";  
    private static final String[] PERMISSIONS = { "offline_access","publish_stream"};
    private static final String[] permissions = { "offline_access", "publish_stream", "user_photos", "publish_checkins",
    "photo_upload" };

    private static final String TOKEN = "access_token";
    private static final String EXPIRES = "expires_in";
    private static final String KEY = "facebook-credentials";
    
    final static int AUTHORIZE_ACTIVITY_RESULT_CODE = 0;
    final static int PICK_EXISTING_PHOTO_RESULT_CODE = 1;
    
    private Activity ctx;

    private Facebook facebook;
    private String messageToPost;
    private String imgUrl;
    
    private TextView mText;
    private ImageView mUserPic;
    private Handler mHandler;
    public String facebookname=null;
    private Profile profile = null;
    private String linkurl = null;
    
    private int message_id=0;
    
    public PostOnFb(Activity ctx){
    	this.ctx = ctx;
    	profile = Profile.loadProfile(ctx);
    	linkurl = profile.urlFbShareLink;
    }

    public PostOnFb(Activity ctx, String messageToPost, int message_id, String imgUrl){
    	this.ctx = ctx;
    	this.messageToPost = messageToPost;
    	this.imgUrl = imgUrl;
    	this.message_id = 1;
    
    	profile = Profile.loadProfile(ctx);
    	linkurl = profile.urlFbShareLink;
    	
        facebook = new Facebook(APP_ID);
        //AQuery aq = new AQuery(ctx);
        //aq.id(R.id.progress).visible();
        mHandler = new Handler();
        restoreCredentials(facebook);
        Utility.mAsyncRunner = new AsyncFacebookRunner(facebook);
        loginandrequest();
    }

    
    public PostOnFb(Activity ctx, String messageToPost, String imgUrl){
    	this.ctx = ctx;
    	this.messageToPost = messageToPost;
    	this.imgUrl = imgUrl;
    	profile = Profile.loadProfile(ctx);
    	linkurl = profile.urlFbShareLink;
    	
        facebook = new Facebook(APP_ID);
        //AQuery aq = new AQuery(ctx);
        //aq.id(R.id.progress).visible();
        mHandler = new Handler();
        restoreCredentials(facebook);
        Utility.mAsyncRunner = new AsyncFacebookRunner(facebook);
        loginandrequest();
    }
        
    public class FbAPIsAuthListener implements AuthListener {

        @Override
        public void onAuthSucceed() {
            requestUserData();
        }

        @Override
        public void onAuthFail(String error) {
            
        }
    }

    public boolean clearCredentials(){
        Editor editor = 
        ctx.getApplicationContext().getSharedPreferences(KEY,Context.MODE_PRIVATE).edit();    
        editor.putString(TOKEN, null);
        editor.putLong(EXPIRES, 2000000);
        return editor.commit();    	
    }

    public boolean saveCredentials(Facebook facebook) {
        Editor editor = 
        ctx.getApplicationContext().getSharedPreferences(KEY,Context.MODE_PRIVATE).edit();    
        editor.putString(TOKEN, facebook.getAccessToken());
        editor.putLong(EXPIRES, facebook.getAccessExpires());
        return editor.commit();
    }

    public boolean restoreCredentials(Facebook facebook) {
        SharedPreferences sharedPreferences =    
        ctx.getApplicationContext().getSharedPreferences(KEY, Context.MODE_PRIVATE);
        facebook.setAccessToken(sharedPreferences.getString(TOKEN, null));
        facebook.setAccessExpires(sharedPreferences.getLong(EXPIRES, 0));
        return facebook.isSessionValid();
    }

   public void doNotShare(View button){
    	ctx.finish();
   }

    public void loginandrequest(){

       if (! facebook.isSessionValid()) {
        	loginToWall();
        } else {
        	requestUserData();
        }
    	//postToWall(messageToPost);
    }

    public void loginToWall(){
    	//LoginFacebook fb = new LoginFacebook(ctx);
    	//fb.login();
         //facebook.authorize(ctx,  PERMISSIONS, new LoginDialogListener());
         facebook.authorize(ctx, PERMISSIONS, Facebook.FORCE_DIALOG_AUTH,
                 new LoginDialogListener());
    }

    public void postToWall(String message){
    	//requestUserData();
    	//not message, not post
    	if (message == null) {
    		Log.d("PostOnFb","update user name lar");;
    		return;
    	}
    	
        Bundle parameters = new Bundle();
        //parameters.putString("caption", message);
        parameters.putString("description",ctx.getString(R.string.yang));
       	parameters.putString("picture",profile.logoUrl);
        parameters.putString("link",linkurl);
        
        //parameters.putString("link","http://aaa.bbb.com");
        parameters.putString("name",message);
        
        facebook.dialog(ctx, "feed", parameters, new DialogListener(){
            @Override
            public void onComplete(Bundle values) {}

            @Override
            public void onCancel() {}

            @Override
            public void onError(DialogError de) {}

            @Override
            public void onFacebookError(FacebookError fbe) {}

        });
        
        //facebook.dialog(this), "stream.publish", parameters, new WallPostDialogListener());
    }

   class LoginDialogListener implements DialogListener {
        public void onComplete(Bundle values) {
        	
        	saveCredentials(facebook);
        	requestUserData();
        }

        public void onFacebookError(FacebookError error) {
            showToast("Authentication with Facebook failed!");
            //ctx.finish();
        }

        public void onError(DialogError error) {
            showToast("Authentication with Facebook failed!");
            //ctx.finish();
        }

        public void onCancel() {
        	
            showToast("Authentication with Facebook cancelled!");
            //ctx.finish();
        }
    }
   
   public void requestUserData() {
       Bundle params = new Bundle();
       params.putString("fields", "name, picture");
       Utility.mAsyncRunner.request("me", params, new UserRequestListener());
   }
   
   /*
    * Callback for fetching current user's name, picture, uid.
    */
   public class UserRequestListener extends BaseRequestListener {

       @Override
       public void onComplete(final String response, final Object state) {
    	   Log.d("before", "url:");
           JSONObject jsonObject;
           try {
               jsonObject = new JSONObject(response);

               final String picURL = jsonObject.getJSONObject("picture")
                       .getJSONObject("data").getString("url");
               final String name = jsonObject.getString("name");
               //final String email = jsonObject.getString("email");
               Utility.userUID = jsonObject.getString("id");
               //Log.d("hereherlehj aflkj adf", "url:"+picURL+" name:"+name);
               Profile profile = Profile.loadProfile(ctx);
               //profile.email = email;
               facebookname=name;
/*               if (messageToPost != null){
                   postToWall(messageToPost);
               }
*/
               
               mHandler.post(new Runnable() {
                   @Override
                   public void run() {
                	   //Log.d("aaaaaaa","ccccccccccccc"+name+ " userid:"+Utility.userUID);
                	   postToWall(messageToPost);
                       //mUserPic.setImageBitmap(Utility.getBitmap(picURL));
                   }
               });

           } catch (JSONException e) {
               e.printStackTrace();
           }
       }

   }

    class WallPostDialogListener implements DialogListener {
        public void onComplete(Bundle values) {
                    final String postId = values.getString("post_id");
                    if (postId != null) {
                    showToast("Message posted to your facebook wall!");
                } else {
                    showToast("Wall post cancelled!");
                }
                ctx.finish();
            }

        public void onFacebookError(FacebookError e) {
            showToast("Failed to post to wall!");
            e.printStackTrace();
            ctx.finish();
        }

        public void onError(DialogError e) {
            showToast("Failed to post to wall!");
            e.printStackTrace();
            ctx.finish();
        }

        public void onCancel() {
            showToast("Wall post cancelled!");
            ctx.finish();
        }
    }
    
    private void showToast(String message){
        Toast.makeText(ctx.getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}  
