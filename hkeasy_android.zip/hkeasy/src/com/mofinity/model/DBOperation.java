package com.mofinity.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.mofinity.bean.TblAdvBean;
import com.mofinity.bean.TblCallBean;
import com.mofinity.bean.TblLinkBean;
import com.mofinity.bean.TblMapBean;
import com.mofinity.bean.TblParameterBean;
import com.mofinity.bean.TblSpeechBean;
import com.mofinity.util.Tool;

public class DBOperation {

	public static SQLiteDatabase getDatabase(Context cx, String dbname){
		SQLiteDatabase db = null;
		if (db == null){
			if (dbname == null ||dbname.length() <= 0) return null;
			
			//always copy now.
			/*if (!Tool.checkfiles(Tool.getDatabaseDirectory(), dbname)){
	    		Tool.copyDatabase(cx, null, dbname);
	    	}*/
	        db = cx.openOrCreateDatabase(dbname, SQLiteDatabase.OPEN_READWRITE, null);   
	        //db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY);
	        
	        db.setVersion(1);
	        db.setLocale(Locale.CHINESE);
	        db.setLockingEnabled(false);
		} 
        return db;
	}
	public static SQLiteDatabase getDatabase(Context cx){
		
		return getDatabase(cx,Tool.getDatabaseName());
	}
	
/*	public static SQLiteDatabase getDatabase(Context cx, String dbname) {
		SQLiteDatabase db = null;
		SQLiteDatabase.loadLibs(cx);
		if (db == null){
			if (dbname == null ||dbname.length() <= 0) return null;
			
			try {
			
				File databaseFile = cx.getDatabasePath(dbname);
				
				//Tool.copyFile(databaseFile.getPath(), Tool.getStorageDirectory()+"aaa.db");
				db = SQLiteDatabase.openOrCreateDatabase(databaseFile, CachProfile.loginname +"~"+CachProfile.password, null);
			
				//db = cx.openOrCreateDatabase(dbname, SQLiteDatabase.OPEN_READWRITE, null);
			} catch (Exception ex){
				// login error.
				//Tool.setAlertMessage (cx, cx.getString(R.string.loginfail), null, cx.getString(R.string.ok));
			}
	        
		} 
        return db;
	}
	public static SQLiteDatabase getDatabase(Context cx){
			return getDatabase(cx,Tool.getDatabaseName());
	}
*/
	public static boolean insertUpdateData(SQLiteDatabase db, String sql, String[] args){
		db.execSQL(sql, args);
		return true;
	}
	
	public static Cursor selectData(SQLiteDatabase db, String sql, String[] args){
		return db.rawQuery(sql, args);
	}
	
	public static boolean isExists(SQLiteDatabase db, String sql, String[] args){
		Cursor c = db.rawQuery(sql, args);
		if (c != null ) {
			c.moveToFirst();
			boolean result = (c.getInt(0) > 0);
			c.close();
			return (result);
		}
		return false;
	}
	
	public static TblAdvBean getAdv(Context cx, String adv_type){
		SQLiteDatabase db = getDatabase(cx);
		TblAdvBean a = new TblAdvBean();
		if (db == null) return null;
		Cursor c = db.rawQuery("select adv_id, adv_type, image_url, image_url_zh, image_url_ne, " +
				"image_url_ud, link, link_zh, link_ne, link_ud " +
				"from tbl_adv where adv_type=? ",new String[]{adv_type});
		if (c != null && c.getCount()>0) {
			c.moveToFirst();
			a.advId=c.getInt(0);
			a.advType=c.getString(1);
			a.imageUrl=c.getString(2);
			a.imageUrlZh=c.getString(3);
			a.imageUrlNe=c.getString(4);
			a.imageUrlUd=c.getString(5);
			a.link=c.getString(6);
			a.linkZh=c.getString(7);
			a.linkNe=c.getString(8);
			a.linkUd=c.getString(9);
			
			c.close();
			db.close();
			return (a);
		}
		db.close();
		return null;
	}
	
	//----------------------------Speech----------------------------------
	public static List<TblSpeechBean> getSpeech(Context cx, String speechType){
		List<TblSpeechBean> lc = new ArrayList<TblSpeechBean>();
		SQLiteDatabase db = getDatabase(cx);
	
		if (db == null) return null;
		String sql = "select speech_id, speech_type, seq, pronunciation, text, text_zh, text_ne, text_ud from tbl_speech where speech_type = ? order by seq";
		String [] args = new String[]{speechType};
		Cursor c = selectData(db, sql, args);
		
		if (c != null ) c.moveToFirst();
        Log.d("DBOperation","count is:"+ c.getCount()+"sql:"+sql+" speechType:"+speechType);
		for (int i=0; i< c.getCount(); i++){
			String speechId = c.getString(0);
			//String speechType = c.getString(1);
			int seq = c.getInt(2);
			//String voice = c.getString(3);
			String pronunciation = c.getString(3);
			String text = c.getString(4);
			String textZh = c.getString(5);
			String textNe = c.getString(6);
			String textUr = c.getString(7);
			TblSpeechBean tb = new TblSpeechBean(speechId, speechType, seq, pronunciation, text, textZh, textNe, textUr);
			lc.add(tb);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}

	public static List<TblSpeechBean> getSpeechByWord(Context cx, String words, String language){
		List<TblSpeechBean> lc = new ArrayList<TblSpeechBean>();
		SQLiteDatabase db = getDatabase(cx);
	
		if (db == null) return null;
		String sql = "select speech_id, speech_type, seq, pronunciation, text, text_zh, text_ne, text_ud from tbl_speech where text like ?";
		if ("zh_TW".equals(language)){
			sql += " or text_zh like '%"+words+"%'";
		} else if ("ur".equals(language)){
			sql += " or text_ud like '%"+words+"%'";
		} else if ("ne".equals(language)){
			sql += " or text_ne like '%"+words+"%'";
		}
		sql += " order by seq";
		//Log.d("search by word logs","sql is:"+sql);
		String [] args = new String[]{"%"+words+"%"};
		Cursor c = selectData(db, sql, args);
		
		if (c != null ) c.moveToFirst();
        //int count = c.getCount();
		for (int i=0; i< c.getCount(); i++){
			String speechId = c.getString(0);
			String speechType = c.getString(1);
			int seq = c.getInt(2);
			String pronunciation = c.getString(3);
			String text = c.getString(4);
			String textZh = c.getString(5);
			String textNe = c.getString(6);
			String textUr = c.getString(7);
			TblSpeechBean tb = new TblSpeechBean(speechId, speechType, seq, pronunciation, text, textZh, textNe, textUr);
			lc.add(tb);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}

	public static List<TblSpeechBean> getSpeech(Context cx){
		List<TblSpeechBean> lc = new ArrayList<TblSpeechBean>();
		SQLiteDatabase db = getDatabase(cx);

		if (db == null) return null;
		String sql = "select speech_id, speech_type, seq, voice, pronunciation, text, text_zh, text_ne, text_ud from tbl_speech order by seq";
		Cursor c = selectData(db, sql, null);

		if (c != null ) c.moveToFirst();
        //int count = c.getCount();

		for (int i=0; i< c.getCount(); i++){
			String speechId = c.getString(0);
			String speechType = c.getString(1);
			int seq = c.getInt(2);
			String voice = c.getString(3);
			String pronunciation = c.getString(4);
			String text = c.getString(5);
			String textZh = c.getString(6);
			String textNe = c.getString(7);
			String textUr = c.getString(8);
			TblSpeechBean tb = new TblSpeechBean(speechId, speechType, seq, pronunciation, text, textZh, textNe, textUr);
			lc.add(tb);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}
	
	public static byte[] getSound(Context cx, String speechId){
		
		SQLiteDatabase db = getDatabase(cx);
		if (db == null) return null;
		String sql = "select voice from tbl_speech where speech_id = ?";
		String[] args = new String[]{speechId};
		Cursor c = selectData(db, sql, args);
		byte[] sound_data= null;
		if (c != null && c.getCount() > 0){
			c.moveToFirst();
			sound_data = c.getBlob(0);
		}
		c.close();
		db.close();
		return sound_data;
	}
	
	//----------------------------Call----------------------------------
	public static List<TblCallBean> getCall(Context cx, String callType){
		List<TblCallBean> lc = new ArrayList<TblCallBean>();
		SQLiteDatabase db = getDatabase(cx);
	
		if (db == null) return null;
		String sql = "select call_id, call_type, seq, title, title_zh, phone_no from tbl_call where call_type = ? order by seq";
		String [] args = new String[]{callType};
		Cursor c = selectData(db, sql, args);
		
		if (c != null ) c.moveToFirst();
        //Log.d("DBOperation","count is:"+ c.getCount()+"sql:"+sql+" speechType:"+speechType);
		for (int i=0; i< c.getCount(); i++){
			int callId = c.getInt(0);
			//String speechType = c.getString(1);
			int seq = c.getInt(2);
			String title = c.getString(3);
			String titleZh = c.getString(4);
			String phoneNo = c.getString(5);
			TblCallBean tb = new TblCallBean(callId, callType, seq, title, titleZh, phoneNo, null, null);
			lc.add(tb);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}

	//----------------------------Link----------------------------------
	public static List<TblLinkBean> getLink(Context cx){
		List<TblLinkBean> lc = new ArrayList<TblLinkBean>();
		SQLiteDatabase db = getDatabase(cx);
	
		if (db == null) return null;
		String sql = "select link, seq, description, description_zh from tbl_link order by seq";
		String [] args = new String[]{};
		Cursor c = selectData(db, sql, args);
		
		if (c != null ) c.moveToFirst();
        //Log.d("DBOperation","count is:"+ c.getCount()+"sql:"+sql+" speechType:"+speechType);
		for (int i=0; i< c.getCount(); i++){
			String link = c.getString(0);
			int seq = c.getInt(1);
			String description = c.getString(2);
			String descriptionZh = c.getString(3);
			TblLinkBean tb = new TblLinkBean(link, seq, description, descriptionZh, null, null);
			lc.add(tb);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}
	
	//----------------------------Map----------------------------------
	public static List<TblMapBean> getMap(Context cx, String mapType){
		List<TblMapBean> lc = new ArrayList<TblMapBean>();
		SQLiteDatabase db = getDatabase(cx);
	
		if (db == null) return null;
		String sql = "select map_id, map_type, seq, name, name_zh, address, address_zh, district, phone_no, remark, map_x, map_y from tbl_map where map_type = ? order by name";
		String [] args = new String[]{mapType};
		Cursor c = selectData(db, sql, args);
		
		if (c != null ) c.moveToFirst();
		for (int i=0; i< c.getCount(); i++){
			int mapId = c.getInt(0);
			int seq = c.getInt(2);
			String name = c.getString(3);
			String nameZh = c.getString(4);
			String address = c.getString(5);
			String addressZh = c.getString(6);
			String district = c.getString(7);
			String phoneNo = c.getString(8);
			String remark = c.getString(9);
			double mapX = c.getDouble(10);
			double mapY = c.getDouble(11);
			TblMapBean tb = new TblMapBean(mapId, mapType, seq, name, nameZh, 
					address, addressZh, district, phoneNo, remark, mapX, mapY, null, null);
			lc.add(tb);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}	

	//----------------------------------tbl_parameter-------------------------------------------

	public static List<TblParameterBean> getParameters(Context cx, String name1){
		List<TblParameterBean> lc = new ArrayList<TblParameterBean>();
		SQLiteDatabase db = getDatabase(cx);

		if (db == null) return null;
		String sql = "select name1, name2, seq, value1, value2, description, description_zh, description_ne, description_ud, remark from tbl_parameter where name1 = ?  order by seq";
		String[] arg = new String[]{name1};
		Cursor c = selectData(db, sql, arg);

		if (c != null ) c.moveToFirst();
        //int count = c.getCount();

		for (int i=0; i< c.getCount(); i++){
			String name2 = c.getString(1);
			int seq = c.getInt(2);
			String value1 = c.getString(3);
			String value2 = c.getString(4);
			String description = c.getString(5);
			String descriptionZh = c.getString(6);
			String descriptionNe = c.getString(7);
			String descriptionUd = c.getString(8);
			String remark = c.getString(9);
			TblParameterBean a = new TblParameterBean(name1, name2, seq, value1, value2, description, descriptionZh, descriptionNe, descriptionUd, remark);
			lc.add(a);
			c.moveToNext();
		}
		c.close();
		db.close();
		return lc;
	}


}
