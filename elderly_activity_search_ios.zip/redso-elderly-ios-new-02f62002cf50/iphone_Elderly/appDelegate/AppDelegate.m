//
//  AppDelegate.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-2.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//



#import "AppDelegate.h"
#import "ElderlyNavigationController.h"
#import "ElderlySplashViewController.h"
#import "ElderlyRootViewController.h"
#import "ElderlySettingManager.h"
#import "ElderlyGuideMannager.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyUserModel.h"
#import "ElderlyDatabaseManager.h"

#import "ElderlyHTTPRequestManager.h"
#import "AsyncTask.h"
#import "ElderlySearchKeyModel.h"
#import "ElderlyAlertUtils.h"
#import "FBSession.h"

#import <MediaPlayer/MediaPlayer.h>

@implementation AppDelegate

@synthesize rootController;
@synthesize settingManager;
@synthesize profileSettingManager;
@synthesize databaseManager;
@synthesize httpRequestManager;
//@synthesize deviceToken;

- (void)dealloc
{
//    self.deviceToken = nil;

    [settingManager release];
    [profileSettingManager release];
    [databaseManager release];
    [httpRequestManager release];
    [_window release];
    [super dealloc];
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.

    ElderlySplashViewController* splashViewController = [[ElderlySplashViewController alloc] initWithNibName:nil bundle:nil];
    self.window.rootViewController = splashViewController;
    [splashViewController release];

    [self initManager];
    [self.window makeKeyAndVisible];

    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeAlert |UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound)];
    
    if(launchOptions){
        NSDictionary* dir=[launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if(dir){
            //
            
//            NSString* pushMsg = nil;
//            for (id key in dir) {
//                DLog(@"key: %@, value: %@", key, [dir objectForKey:key]);
//                if([[dir objectForKey:key] isKindOfClass:[NSDictionary class]]){
//                    NSDictionary* userInfoSub = [dir objectForKey:key];
//                    for(id subKey in userInfoSub){
//                        pushMsg = [userInfoSub objectForKey:subKey];
//                        break;
//                    }
//                }
//            }
//            
//            if(pushMsg != nil){
//                [ElderlyAlertUtils showAlert:pushMsg delegate:nil];
//            }
        }
    }

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    [[ElderlyGuideMannager sharedInstance] saveGudieFile];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [[NSNotificationCenter defaultCenter] postNotificationName:MPMoviePlayerPlaybackDidFinishNotification object:nil];

    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [FBSession.activeSession handleOpenURL:url];
}

- (void)applicationWillTerminate:(UIApplication *)application{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [FBSession.activeSession close];
}



-(void)clearSplashAndCreateMainPage{
    
    rootController=[[ElderlyRootViewController alloc] init];
    self.window.rootViewController = rootController;
    [rootController release];
    

}

-(void)initManager{

    settingManager = [[ElderlySettingManager alloc] init];
    profileSettingManager = [[ElderlyProfileSettingManager alloc] init];
    [ElderlyGuideMannager sharedInstance];
    databaseManager = [[ElderlyDatabaseManager alloc] init];
    [databaseManager checkSqliteVersion];

    ElderlyUserModel* model = [databaseManager getElderlyUser];
    if(model != nil)
        profileSettingManager.userModel = model ;
    
    httpRequestManager = [[ElderlyHTTPRequestManager alloc] init];
    
    
//    ElderlySearchKeyModel* model2 = [[ElderlySearchKeyModel alloc] init];
//    model2.eventType = @"康樂及運動";
//    model2.activeArea = @"東區";
//    model2.month = @"2013-09-02";
//    
//    asyncTask = [httpRequestManager searchElderlyList:model2];
//
//    [asyncTask setFinishBlock:^{
//        
//        NSArray* list=[asyncTask result];
//        if(list != nil){
//            
//            
//        }
//        
//        asyncTask=nil;
//        
//    }];
    
}


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)_deviceToken{
    printf("didRegisterForRemoteNotificationsWithDeviceToken \n");
    
    if ([_deviceToken length]==0)
        return;
    
    NSString *token = [[_deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    token = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
//    
//    [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"deviceToken"];
//    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    DLog(@"Device Token=%@",token);
    
    
    if(token > 0){
        asyncTask = [httpRequestManager postToken:token];
        [asyncTask setFinishBlock:^{
        asyncTask = nil;
        }];
    }

    
    
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error{

    DLog(@"%@",[NSString stringWithFormat: @"Error didFailToRegisterForRemoteNotificationsWithError: %@", error]);
}


-(void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    
    NSLog(@"didReceiveRemoteNotification");
    
    NSString* pushMsg = nil;
    for (id key in userInfo) {
        DLog(@"key: %@, value: %@", key, [userInfo objectForKey:key]);
        if([[userInfo objectForKey:key] isKindOfClass:[NSDictionary class]]){
            NSDictionary* userInfoSub = [userInfo objectForKey:key];
            for(id subKey in userInfoSub){
                pushMsg = [userInfoSub objectForKey:subKey];
                break;
            }
        }
    }
    
    if(pushMsg != nil){
        [ElderlyAlertUtils showAlert:pushMsg delegate:nil];
    }
}


@end
