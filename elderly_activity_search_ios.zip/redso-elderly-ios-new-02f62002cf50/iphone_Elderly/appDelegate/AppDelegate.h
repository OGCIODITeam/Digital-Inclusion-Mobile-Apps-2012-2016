//
//  AppDelegate.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-2.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ElderlyRootViewController;
@class ElderlySettingManager;
@class ElderlyUserModel;
@class ElderlyProfileSettingManager;
@class ElderlyDatabaseManager;
@class ElderlyHTTPRequestManager;
@class AsyncTask;
@class ElderlyBannerModel;
@interface AppDelegate : UIResponder <UIApplicationDelegate>{

    ElderlyRootViewController* rootController;
    
    AsyncTask* asyncTask;

}

@property (retain, nonatomic) UIWindow *window;
@property(assign,readonly) ElderlyRootViewController* rootController;
@property(assign,readonly) ElderlySettingManager* settingManager;
@property(assign,readonly) ElderlyProfileSettingManager* profileSettingManager;
@property (assign, readonly) ElderlyDatabaseManager* databaseManager;
@property(assign,readonly) ElderlyHTTPRequestManager* httpRequestManager;

-(void)clearSplashAndCreateMainPage;

@end
