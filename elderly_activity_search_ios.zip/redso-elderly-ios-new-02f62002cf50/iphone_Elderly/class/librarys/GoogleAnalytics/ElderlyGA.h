//
//  ElderlyGA.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyGA : NSObject

+(ElderlyGA*)sharedInstance;

-(void)trackPageView:(NSString*)pageCode;

-(void)trackEvent:(NSString*)pageCode;

-(void)trackEvent:(NSString *)pageCode ActionCode:(NSString*)actionCode LabelCode:(NSString*)labelCode;

@end
