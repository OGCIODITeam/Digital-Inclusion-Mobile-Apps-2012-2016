//
//  GoogleANTracker.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GANTracker.h"

@interface GoogleANTracker : GANTracker{
    NSMutableDictionary *trackerMap;
}

@end
