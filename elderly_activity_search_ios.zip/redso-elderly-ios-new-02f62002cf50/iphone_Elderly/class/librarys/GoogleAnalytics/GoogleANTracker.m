//
//  GoogleANTracker.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "GoogleANTracker.h"

@implementation GoogleANTracker


- (id)init
{
    self = [super init];
    if (self) {
        trackerMap = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [trackerMap release];
    [super dealloc];
}

- (BOOL)trackPageview:(NSString *)pageURL
            withError:(NSError **)error{
    
    BOOL canTrack = YES;
    
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    NSNumber *lastTimeNumber = [trackerMap objectForKey:pageURL];
    if (lastTimeNumber!=nil) {
        NSTimeInterval lastTime = lastTimeNumber.doubleValue;
        if (now - lastTime < 2) {
            canTrack = NO;
        }
    }
    
    if (canTrack) {
        [trackerMap setObject:[NSNumber numberWithDouble:now] forKey:pageURL];
        return [super trackPageview:pageURL withError:error];
    }
    
    return NO;
}


@end
