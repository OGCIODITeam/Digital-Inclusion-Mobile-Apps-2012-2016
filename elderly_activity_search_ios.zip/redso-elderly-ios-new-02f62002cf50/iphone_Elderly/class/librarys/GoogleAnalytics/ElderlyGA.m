//
//  ElderlyGA.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyGA.h"
#import "GoogleANTracker.h"

@implementation ElderlyGA

#define GAACCOUNT @"UA-43684574-1"

static ElderlyGA* elderlyGa;
static const NSInteger kGANDispatchPeriodSec = 10;

+(ElderlyGA*)sharedInstance{
    if (elderlyGa==nil) {
        elderlyGa = [[ElderlyGA alloc] init];
        [elderlyGa startTrace];
    }
    return elderlyGa;
}

-(void)startTrace{
    [[GoogleANTracker sharedTracker] startTrackerWithAccountID:GAACCOUNT
                                               dispatchPeriod:kGANDispatchPeriodSec
                                                     delegate:nil];
}

-(void)trackPageView:(NSString*)pageCode{
    
    NSError *error;
    [[GoogleANTracker sharedTracker] trackPageview:pageCode withError:&error];

}

-(void)trackEvent:(NSString*)pageCode{

    NSError *error;
    [[GoogleANTracker sharedTracker] trackEvent:pageCode action:GA_CODE_CLICK label:nil value:-1 withError:&error];

}

-(void)trackEvent:(NSString *)pageCode ActionCode:(NSString*)actionCode LabelCode:(NSString*)labelCode{

    NSError *error;
    [[GoogleANTracker sharedTracker] trackEvent:pageCode action:actionCode label:labelCode value:-1 withError:&error];

}

@end
