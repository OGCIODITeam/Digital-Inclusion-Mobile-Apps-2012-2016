//
//  FacebookHelper.h
//  WTIA
//
//  Created by Kevin on 20/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __FBHELPER__
#define __FBHELPER__
// New Notification 
#define kFacebookDidChangeNotification @"kFacebookDidChangeNotification"
#endif

#import <Foundation/Foundation.h>
#import "Facebook.h"
//#import "SBJSON.h"

@class ShareingObject;


@interface FacebookHelper : NSObject <FBDialogDelegate,FBRequestDelegate, FBSessionDelegate,FBViewControllerDelegate> {
	
	Facebook *_facebook;
	BOOL _isLoggedIn;
    
}

@property (nonatomic, readonly) Facebook *facebook;
@property (nonatomic, readonly) BOOL isLoggedIn;

@property(nonatomic,retain) ShareingObject* loginToShareingObject;


+ (FacebookHelper *) defaultHelper;

//-(void)rootView:(UIView*)view;
- (void) login;
- (void) logout;

- (void)shareMessageWithObject:(ShareingObject *)shareObject;

@end
