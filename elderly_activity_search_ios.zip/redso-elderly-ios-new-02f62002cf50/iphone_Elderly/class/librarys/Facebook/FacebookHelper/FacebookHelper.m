//
//  FacebookHelper.m
//  WTIA
//
//  Created by Kevin on 20/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FacebookHelper.h"
#import "ShareingObject.h"
#import "ElderlyAlertUtils.h"
#define ACCESS_TOKEN_KEY @"FBAccessTokenKey"
#define EXPIRATION_DATE_KEY @"FBExpirationDateKey"
#define FACEBOOK_ID  @"534016993338196"

@interface FacebookHelper()
-(void)apiGraphMe;
@end

static FacebookHelper* fb_helper;

@implementation FacebookHelper
@synthesize facebook = _facebook, isLoggedIn = _isLoggedIn;

+ (FacebookHelper *) defaultHelper{
	@synchronized(self){
		if ( fb_helper == nil ) fb_helper = [[FacebookHelper alloc] init];
		return fb_helper;
	}
}

- (void) setupFacebook{
	[_facebook release];
	_facebook = [[ Facebook alloc] initWithAppId:FBSession.activeSession.appID andDelegate:nil];
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	_facebook.accessToken = [defaults objectForKey:ACCESS_TOKEN_KEY];
	_facebook.expirationDate = [defaults objectForKey:EXPIRATION_DATE_KEY];
	_isLoggedIn = [_facebook isSessionValid];
    if (_isLoggedIn) {
        [self apiGraphMe];
    }
	
}

- (id) init{
	if ( self = [ super init] ) {
		[self setupFacebook];		
	}
	return self;
	
}

- (void) settingDidUpdate:(NSNotification *)notification {
	[self setupFacebook];
	
}

- (void) dealloc{
	[_facebook release];
	_isLoggedIn = NO;
    self.loginToShareingObject=nil;
	[super dealloc];
}

//-(void)rootView:(UIView*)view{
//    _facebook.rootView=view;
//}

- (NSUInteger) retainCount{
	return NSUIntegerMax;
}

- (void) login{	
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:ACCESS_TOKEN_KEY] 
        && [defaults objectForKey:EXPIRATION_DATE_KEY]) {
        _facebook.accessToken = [defaults objectForKey:ACCESS_TOKEN_KEY];
        _facebook.expirationDate = [defaults objectForKey:EXPIRATION_DATE_KEY];
    }
    if (![_facebook isSessionValid]) {
//        [_facebook authorize:[NSArray arrayWithObjects: @"publish_stream", nil]
//                    delegate:self];
        FBSession.activeSession = [[[FBSession alloc] initWithPermissions:[NSArray arrayWithObjects: @"publish_stream", nil]] autorelease];
//        [FBSession.activeSession openWithCompletionHandler:^(FBSession *aSesstion,
//                                             FBSessionState status,
//                                             NSError *error) {
//            
//            NSLog(@"error >> %@", error);
//            NSLog(@"status = %d", status);
//            if(aSesstion.isOpen) {
//                [self fbDidLogin];
//            }
//        }];
//
        [FBSession.activeSession openWithBehavior:FBSessionLoginBehaviorForcingWebView completionHandler:^(FBSession *aSesstion,
                                                             FBSessionState status,
                                                             NSError *error) {
            
            NSLog(@"error >> %@", error);
            //if(error!=nil)
            //    [SCMPAlertUtils showAlert:lang(@"connect_error") delegate:self];

            NSLog(@"status = %d", status);
            if(aSesstion.isOpen) {
                [self fbDidLogin];
            }
           
        }];
        
//        [_facebook authorize:[NSArray arrayWithObjects: @"publish_stream", nil]
//                    delegate:self];
    }
}

- (void) logout{
	[_facebook logout:self];
}


- (void) apiGraphMe {
    /*
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"name,picture",  @"fields",
                                   nil];
    */
//    [_facebook requestWithGraphPath:@"me" andParams:params andDelegate:self];
}

- (void)facebookViewControllerCancelWasPressed:(id)sender{

}

- (void)fbDidLogin {
	DLog(@"Did Login");
	_isLoggedIn = YES;
	
    [self apiGraphMe];
    
	// store the access token and expiration date to the user defaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:_facebook.accessToken forKey:ACCESS_TOKEN_KEY];
    [defaults setObject:_facebook.expirationDate forKey:EXPIRATION_DATE_KEY];
    [defaults synchronize];
    
    if(self.loginToShareingObject!=nil){
        [self shareMessageWithObject:self.loginToShareingObject];
        self.loginToShareingObject=nil;
    }

}

-(void)fbDidNotLogin:(BOOL)cancelled {
	DLog(@"did not login");
    self.loginToShareingObject=nil;
	_isLoggedIn = NO;
	
	// store the access token and expiration date to the user defaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:_facebook.accessToken forKey:ACCESS_TOKEN_KEY];
    [defaults setObject:_facebook.expirationDate forKey:EXPIRATION_DATE_KEY];
    [defaults synchronize];
	
	[[NSNotificationCenter defaultCenter] postNotificationName:kFacebookDidChangeNotification
														object:[NSNumber numberWithBool:NO]
													  userInfo:nil];

}

- (void)fbDidLogout {
	DLog(@"did Log out");
	_isLoggedIn = NO;
    self.loginToShareingObject=nil;
	
	// store the access token and expiration date to the user defaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults removeObjectForKey:ACCESS_TOKEN_KEY];
	[defaults removeObjectForKey:EXPIRATION_DATE_KEY];
    [defaults synchronize];
	
	_facebook.accessToken = nil;
	_facebook.expirationDate = nil;
	
	// Send out notification to notify facebook is logout.
	[[NSNotificationCenter defaultCenter] postNotificationName:kFacebookDidChangeNotification
														object:[NSNumber numberWithBool:NO]
													  userInfo:nil];
	
}

- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
};

- (void)request:(FBRequest *)request didLoad:(id)result {
    if ([result isKindOfClass:[NSArray class]]) {
        result = [result objectAtIndex:0];
    }
    if ([result objectForKey:@"name"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kFacebookDidChangeNotification
                                                            object:[NSNumber numberWithBool:YES]
                                                          userInfo:nil];
    }
};

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    DLog(@"Err message: %@", [[error userInfo] objectForKey:@"error_msg"]);
    DLog(@"Err code: %d", [error code]);
    
    if ([error code] == 190) {
        _isLoggedIn = NO;
    }
};


- (void)dialogDidComplete:(FBDialog *)dialog {

    [[NSNotificationCenter defaultCenter] postNotificationName:kFacebookDidChangeNotification
														object:[NSNumber numberWithBool:NO]
													  userInfo:nil];
}

- (void)dialogCompleteWithUrl:(NSURL *)url {
    if(!_isLoggedIn)return;
    NSString* _url=[url absoluteString];
    const char* __url=[_url UTF8String];
    if(__url!=nil && strstr(__url,"fbconnect://success?post_id=")!=nil)
        [ElderlyAlertUtils showAlert:lang(@"sharedSuccess") delegate:self];

}

- (void)dialogDidNotCompleteWithUrl:(NSURL *)url {
    
    
}


- (void)dialog:(FBDialog *)dialog didFailWithError:(NSError *)error {
    [ElderlyAlertUtils showAlert:lang(error.code==-1009?@"connect_error":@"sharedFail") delegate:self];

}

- (void)shareMessageWithObject:(ShareingObject *)shareObject {
    if(self.loginToShareingObject!=shareObject)
        self.loginToShareingObject=shareObject;
//	SBJSON *jsonWriter = [[SBJSON new] autorelease];
	
    
//	NSString *attachmentStr = [jsonWriter stringWithObject:attachment];
//	DLog(@"attachmentStr = %@", attachmentStr);
    if ([self isLoggedIn]) {
        
        NSMutableDictionary* attachment = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                           shareObject.adTitle, @"name",
                                           shareObject.adLink, @"link",
                                           shareObject.adImageLink, @"picture",
                                           [NSString stringWithFormat:@"at %@", [ElderlyUtils getAppName]], @"caption",
                                           shareObject.adDescription, @"description",
                                           //                                actionLinksStr, @"action_links",
                                           nil];

        [_facebook dialog: @"feed"
                andParams: attachment
              andDelegate: self];
    }
    else {
        [self login];
    }
}


- (void)fbDidExtendToken:(NSString*)accessToken
               expiresAt:(NSDate*)expiresAt{
    
}

- (void)fbSessionInvalidated{
    
}


@end
