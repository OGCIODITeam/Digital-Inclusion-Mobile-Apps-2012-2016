//
//  ShareingObject.h
//  iPhone_SCMP
//
//  Created by fanty.xiao on 6/11/12.
//  Copyright (c) 2012年 GTGZ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShareingObject : NSObject

@property (retain, nonatomic) NSString *adTitle;
@property (retain,nonatomic) NSString* adLink;
@property (retain, nonatomic) NSString *adDescription;
@property (retain, nonatomic) NSString *adImageLink;
@property (retain, nonatomic) NSDate *adDate;

@end
