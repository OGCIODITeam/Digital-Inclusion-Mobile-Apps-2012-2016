

#import <Foundation/Foundation.h>

#include <stdlib.h>
#include <stdbool.h>

@interface Base64DataFHS : NSObject

+(BOOL)Base64EncodeDataFHS:(const void *)inInputData inInputDataSize:(size_t)inInputDataSize outOutputData:(char *)outOutputData  ioOutputDataSize:(size_t *)ioOutputDataSize;

@end
