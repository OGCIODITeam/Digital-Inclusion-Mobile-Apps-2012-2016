#include "Base64TranscoderFHS.h"


#include <math.h>
#include <string.h>

@implementation Base64DataFHS

+(size_t) EstimateBas64EncodedDataSizeFHS:(size_t)inDataSize {
    size_t theEncodedDataSize = (int)ceil(inDataSize / 3.0) * 4;
    theEncodedDataSize = theEncodedDataSize / 72 * 74 + theEncodedDataSize % 72;
    return(theEncodedDataSize);
}


+(BOOL)Base64EncodeDataFHS:(const void *)inInputData inInputDataSize:(size_t)inInputDataSize outOutputData:(char *)outOutputData  ioOutputDataSize:(size_t *)ioOutputDataSize{
    const u_int8_t kBase64EncodeTable_[64] = {
        /*  0 */ 'A',	/*  1 */ 'B',	/*  2 */ 'C',	/*  3 */ 'D',
        /*  4 */ 'E',	/*  5 */ 'F',	/*  6 */ 'G',	/*  7 */ 'H',
        /*  8 */ 'I',	/*  9 */ 'J',	/* 10 */ 'K',	/* 11 */ 'L',
        /* 12 */ 'M',	/* 13 */ 'N',	/* 14 */ 'O',	/* 15 */ 'P',
        /* 16 */ 'Q',	/* 17 */ 'R',	/* 18 */ 'S',	/* 19 */ 'T',
        /* 20 */ 'U',	/* 21 */ 'V',	/* 22 */ 'W',	/* 23 */ 'X',
        /* 24 */ 'Y',	/* 25 */ 'Z',	/* 26 */ 'a',	/* 27 */ 'b',
        /* 28 */ 'c',	/* 29 */ 'd',	/* 30 */ 'e',	/* 31 */ 'f',
        /* 32 */ 'g',	/* 33 */ 'h',	/* 34 */ 'i',	/* 35 */ 'j',
        /* 36 */ 'k',	/* 37 */ 'l',	/* 38 */ 'm',	/* 39 */ 'n',
        /* 40 */ 'o',	/* 41 */ 'p',	/* 42 */ 'q',	/* 43 */ 'r',
        /* 44 */ 's',	/* 45 */ 't',	/* 46 */ 'u',	/* 47 */ 'v',
        /* 48 */ 'w',	/* 49 */ 'x',	/* 50 */ 'y',	/* 51 */ 'z',
        /* 52 */ '0',	/* 53 */ '1',	/* 54 */ '2',	/* 55 */ '3',
        /* 56 */ '4',	/* 57 */ '5',	/* 58 */ '6',	/* 59 */ '7',
        /* 60 */ '8',	/* 61 */ '9',	/* 62 */ '+',	/* 63 */ '/'
    };
    
    /*
     -1 = Base64 end of data marker.
     -2 = White space (tabs, cr, lf, space)
     -3 = Noise (all non whitespace, non-base64 characters)
     -4 = Dangerous noise
     -5 = Illegal noise (null byte)
     */
    
    const u_int8_t kBits_00000011_ = 0x03;
    const u_int8_t kBits_00001111_ = 0x0F;
    const u_int8_t kBits_00111111_ = 0x3F;
    const u_int8_t kBits_11000000_ = 0xC0;
    const u_int8_t kBits_11110000_ = 0xF0;
    const u_int8_t kBits_11111100_ = 0xFC;
    
        
    size_t theEncodedDataSize =[self EstimateBas64EncodedDataSizeFHS:inInputDataSize]; 
    if (*ioOutputDataSize < theEncodedDataSize) {
        return false;
    }
    
    *ioOutputDataSize = theEncodedDataSize;
    const u_int8_t *theInPtr = (const u_int8_t *)inInputData;
    u_int32_t theInIndex = 0, theOutIndex = 0;
    for (; theInIndex < (inInputDataSize / 3) * 3; theInIndex += 3) {
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex] & kBits_11111100_) >> 2];
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex] & kBits_00000011_) << 4 | (theInPtr[theInIndex + 1] & kBits_11110000_) >> 4];
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex + 1] & kBits_00001111_) << 2 | (theInPtr[theInIndex + 2] & kBits_11000000_) >> 6];
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex + 2] & kBits_00111111_) >> 0];
        
        if (theOutIndex % 74 == 72) {
            outOutputData[theOutIndex++] = '\r';
            outOutputData[theOutIndex++] = '\n';
		}
	}
    
    const size_t theRemainingBytes = inInputDataSize - theInIndex;
    
    if (theRemainingBytes == 1) {
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex] & kBits_11111100_) >> 2];
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex] & kBits_00000011_) << 4 | (0 & kBits_11110000_) >> 4];
        outOutputData[theOutIndex++] = '=';
        outOutputData[theOutIndex++] = '=';
        
        if (theOutIndex % 74 == 72) {
            outOutputData[theOutIndex++] = '\r';
            outOutputData[theOutIndex++] = '\n';
		}
	} else if (theRemainingBytes == 2) {
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex] & kBits_11111100_) >> 2];
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex] & kBits_00000011_) << 4 | (theInPtr[theInIndex + 1] & kBits_11110000_) >> 4];
        outOutputData[theOutIndex++] = kBase64EncodeTable_[(theInPtr[theInIndex + 1] & kBits_00001111_) << 2 | (0 & kBits_11000000_) >> 6];
        outOutputData[theOutIndex++] = '=';
        
        if (theOutIndex % 74 == 72) {
            outOutputData[theOutIndex++] = '\r';
            outOutputData[theOutIndex++] = '\n';
		}
	}
    
    return true;
}

@end
