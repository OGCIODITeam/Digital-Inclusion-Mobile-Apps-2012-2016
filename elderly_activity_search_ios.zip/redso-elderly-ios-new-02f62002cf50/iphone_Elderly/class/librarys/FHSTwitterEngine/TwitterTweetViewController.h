//
//  TwitterTweetViewController.h
//  SCMPNews
//
//  Created by fanty on 13-3-12.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TwitterTweetViewController;

@protocol TwitterTweetViewControllerDelegate <NSObject>

-(void)didTweetShared:(TwitterTweetViewController*)tweetViewController;
-(void)didTweetCancel:(TwitterTweetViewController*)tweetViewController;

@end

@interface TwitterTweetViewController : UIViewController{
    
    UITextView* tweetTextView;
    UILabel* shareTitleLabel;
    UILabel* tweetTextRemindLabel;
    int allowTextLength;
}

@property(nonatomic,retain) NSString* sharedMessage;

@property(nonatomic,assign) id<TwitterTweetViewControllerDelegate> delegate;

-(NSString*)sharedText;

@end
