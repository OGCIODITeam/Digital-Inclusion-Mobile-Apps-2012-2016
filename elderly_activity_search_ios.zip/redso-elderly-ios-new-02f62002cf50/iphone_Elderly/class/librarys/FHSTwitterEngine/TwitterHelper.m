//
//  TwitterHelper.m
//  TWConnect
//
//  Created by Kevin Chan on 30/04/2011.
//  Copyright 2011 No COMPANY. All rights reserved.
//

#import "TwitterHelper.h"
#import "FHSTwitterEngine.h"
#import "AppDelegate.h"

//#import "SA_OAuthTwitterController.h"
#import "ShareingObject.h"

#import "TwitterTweetViewController.h"
#import "ElderlyRootViewController.h"
#import "ElderlyAlertUtils.h"

#ifndef kOAuthConsumerKey

#define kOAuthConsumerKey				@"JDSsZ1U8mpsm5upec06Hg"		//Elderly With Twitter App OAuth Key
#define kOAuthConsumerSecret			@"Z25vpMHyZfBzd32bXKiQG9wOBV9Y5Z6q1f9d9cXYE"


//#define kOAuthConsumerKey				@"D8sdZ0ILYIRbsMByIJDJg"		//REPLACE With Twitter App OAuth Key
//#define kOAuthConsumerSecret			@"zTYTPDhxLIevCUctNAAfFBncnSN2KNzkSi4W4J3px9A"

#endif


@interface TwitterHelper()<FHSTwitterEngineAccessTokenDelegate,UIAlertViewDelegate,TwitterTweetViewControllerDelegate>
-(void)showTweetViewController;
-(void)sharedClose;
@end

@implementation TwitterHelper
@synthesize delegate;
-(id)init{
    self=[super init];
    
    if(self){
        [[FHSTwitterEngine sharedEngine]permanentlySetConsumerKey:kOAuthConsumerKey andSecret:kOAuthConsumerSecret];
        [[FHSTwitterEngine sharedEngine]setDelegate:self];

    }
    
    return self;
}

-(void)dealloc{
    self.sharedMessage=nil;
    [super dealloc];
}


-(void)showTweetViewController{
    
    TwitterTweetViewController* viewController=[[TwitterTweetViewController alloc] init];
    
    viewController.delegate=self;
    viewController.sharedMessage=self.sharedMessage;
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    [appDelegate.rootController presentModalViewController:viewController animated:YES];
    
    [viewController release];
}

-(void)shareTweet:(ShareingObject *)content{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    oldOrientation = appDelegate.rootController.interfaceOrientation;
    
    
    
    self.sharedMessage = [NSString stringWithFormat:@"%@:%@", content.adTitle,  content.adLink];
    
    if(![[FHSTwitterEngine sharedEngine] isAuthorized]){
        [[FHSTwitterEngine sharedEngine] clearAccessToken];
        
        AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
        [[FHSTwitterEngine sharedEngine] showOAuthLoginControllerFromViewController:appDelegate.rootController withCompletion:self];

    }
    else{
        [self showTweetViewController];
    }
}

-(void)sharedClose{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    if(oldOrientation!=appDelegate.rootController.interfaceOrientation){
        
        [appDelegate.rootController dismissModalViewControllerAnimated:NO];
    
        //[appDelegate.rootController setTheInterfaceOrientation:oldOrientation ];
    
        if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
            [[UIDevice currentDevice] performSelector:@selector(setOrientation:)
                                       withObject:(id)oldOrientation];
        
        }
    }
    else{
        [appDelegate.rootController dismissModalViewControllerAnimated:YES];

    }


    if([self.delegate respondsToSelector:@selector(twitterDidClose:)])
        [self.delegate twitterDidClose:self];


}

#pragma mark  login delegate

-(void)didLogined:(BOOL)success{
    
    if(success){
        AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
        [appDelegate.rootController dismissModalViewControllerAnimated:NO];

        [self showTweetViewController];
        
    }
    else{        
        [self sharedClose];
    }

}

-(void)didCanceled{

    [self sharedClose];
}



#pragma mark  twittertweet delegate

-(void)showAction:(TwitterTweetViewController*)tweetViewController{
    dispatch_async(GCDBackgroundThread, ^{
        @autoreleasepool {
            NSError *returnCode = [[FHSTwitterEngine sharedEngine]postTweet:[tweetViewController sharedText]];
            
            dispatch_sync(GCDMainThread, ^{
                @autoreleasepool {
//                    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
                    //appDelegate.showLoading=NO;
                    
                    if(!returnCode){
                        
                        [ElderlyAlertUtils showAlert:lang(@"sharedSuccess") delegate:self];
                    }
                    else{
                        [ElderlyAlertUtils showAlert:lang(returnCode.code==-1009?@"connect_error":@"sharedFail") delegate:self];
                    }
                }
            });
        }
    });
}

-(void)didTweetShared:(TwitterTweetViewController*)tweetViewController{
    
    [self performSelector:@selector(showAction:) withObject:tweetViewController afterDelay:0.5f];

}

-(void)didTweetCancel:(TwitterTweetViewController*)tweetViewController{

    [self sharedClose];
}


#pragma mark TwitterEngineDelegate
/*
- (void) requestSucceeded: (NSString *) requestIdentifier {
    [AppDelegate appDelegate].showLoading=NO;

    [SCMPAlertUtils showAlert:lang(@"sharedSuccess") delegate:self];
}

- (void) requestFailed: (NSString *) requestIdentifier withError: (NSError *) error {
    [AppDelegate appDelegate].showLoading=NO;
    

    if(error.code!=403 && error.code!=-100)
        [engine clearAccessToken];

    if(error.code==403 && [[[UIDevice currentDevice] systemVersion] floatValue]>=6.1){
        [SCMPAlertUtils showAlert:lang(@"sharedSuccess") delegate:self];
    }
    else{
        [SCMPAlertUtils showAlert:lang(error.code==-1009?@"connect_error":@"Shared failed") delegate:self];
    }
}
*/

#pragma mark  alertview delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    [self sharedClose];

}

#pragma mark  titter token delegate
- (void)storeAccessToken:(NSString *)accessToken {
    [[NSUserDefaults standardUserDefaults]setObject:accessToken forKey:@"savedAccess_twitter"];
}

- (NSString *)loadAccessToken {
    return [[NSUserDefaults standardUserDefaults]objectForKey:@"savedAccess_twitter"];
}



@end
