//
//  TwitterViewController.m
//  SCMPNews
//
//  Created by fanty on 13-3-12.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import "TwitterTweetViewController.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

#import "ElderlyUtils.h"
#import "ElderlyAlertUtils.h"

@interface TwitterTweetViewController ()<UITextViewDelegate>
-(void)updateTextRemind;
-(void)sharedBackClick;
-(void)sharedDoneClick;
@end

@implementation TwitterTweetViewController

@synthesize sharedMessage;
@synthesize delegate;
-(id)init{
    self=[super init];
    
    self.navigationItem.leftBarButtonItem=[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(sharedBackClick)] autorelease];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc] initWithTitle:@"Share" style:UIBarButtonItemStyleDone target:self action:@selector(sharedDoneClick)] autorelease];
    return self;
}


- (void)viewDidLoad{
    [super viewDidLoad];
    self.title=@"Connect to Twitter";
    self.view.backgroundColor=[UIColor whiteColor];
    
    if([ElderlyUtils systemVersion] >= 7.0){
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars=NO;
        self.automaticallyAdjustsScrollViewInsets=NO;
    }
    
    UINavigationBar* _navBar = [[UINavigationBar alloc] initWithFrame: CGRectMake(0, 0, self.view.frame.size.width, 44)];
	_navBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;

    UINavigationItem *navItem = [[UINavigationItem alloc] initWithTitle: NSLocalizedString(@"Twitter Info", nil)];
    navItem.leftBarButtonItem=[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(sharedBackClick)] autorelease];
    navItem.rightBarButtonItem=[[[UIBarButtonItem alloc] initWithTitle:@"Share" style:UIBarButtonItemStyleDone target:self action:@selector(sharedDoneClick)] autorelease];
	
	[_navBar pushNavigationItem: navItem animated: NO];

    [navItem release];
    
    [self.view addSubview:_navBar];
    
    [_navBar release];
    
    
    CGRect frame=self.view.frame;
    
    float textViewHeight=160.0f;
    if(UIInterfaceOrientationIsLandscape(self.interfaceOrientation)){
        frame.size.width=frame.size.height;
        textViewHeight=110.0f;
    }
    
    shareTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 54.0f, frame.size.width-20.0f, 30.0f)];
    shareTitleLabel.backgroundColor=[UIColor clearColor];

    shareTitleLabel.numberOfLines = 1 ;
    shareTitleLabel.text = @"Share in Twitter";
    [self.view addSubview:shareTitleLabel];
    [shareTitleLabel release];
        
    tweetTextRemindLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 56.0f, frame.size.width-20.0f, 30.0f)];

    tweetTextRemindLabel.numberOfLines = 1 ;
    tweetTextRemindLabel.backgroundColor=[UIColor clearColor];
    tweetTextRemindLabel.textColor = [UIColor darkGrayColor];
    tweetTextRemindLabel.textAlignment = UITextAlignmentRight;
    
    [self.view addSubview:tweetTextRemindLabel];
    [tweetTextRemindLabel release];
    
    tweetTextView =[[ UITextView alloc] initWithFrame:CGRectMake(10.0f, 84.0f, frame.size.width-20.0f, textViewHeight)];

    tweetTextView.delegate = self;
    tweetTextView.font=[UIFont systemFontOfSize:15.0f];

    tweetTextView.layer.borderWidth = 1;
    tweetTextView.layer.borderColor = [[UIColor grayColor] CGColor];
    tweetTextView.layer.cornerRadius = 5;
    tweetTextView.text=self.sharedMessage;
    [self.view addSubview:tweetTextView];
    
    [tweetTextView release];
    
    [self.view bringSubviewToFront:_navBar];
    
    [self updateTextRemind];
}


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    self.sharedMessage=nil;
    [super dealloc];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [tweetTextView becomeFirstResponder];
}


#pragma mark  textview delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    if(UIInterfaceOrientationIsLandscape(self.interfaceOrientation)){
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.30f];
        
        CGRect rect=shareTitleLabel.frame;
        rect.origin.y=19.0f;
        shareTitleLabel.frame=rect;
        
        rect=tweetTextRemindLabel.frame;
        rect.origin.y=21.0f;
        tweetTextRemindLabel.frame=rect;
        
        rect=tweetTextView.frame;
        rect.origin.y=49.0f;
        tweetTextView.frame=rect;
        
        [UIView commitAnimations];
    }
    return YES;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    
    return YES;
}

-(BOOL)shouldAutorotate{
    
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations{
    
    return UIInterfaceOrientationMaskAll;
    
}
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation{
    
    float w=300.0f;
    
    if(UIInterfaceOrientationIsLandscape(self.interfaceOrientation))
        w=([ElderlyUtils isRetain4]?548:460.0f);
    CGRect rect=tweetTextView.frame;
    rect.size.width=w;
    tweetTextView.frame=rect;
    
    rect=tweetTextRemindLabel.frame;
    rect.size.width=w;
    tweetTextRemindLabel.frame=rect;

    
}
 

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text length]<1)return YES;

    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.30f];

        CGRect rect=shareTitleLabel.frame;
        rect.origin.y=54.0f;
        shareTitleLabel.frame=rect;
        
        rect=tweetTextRemindLabel.frame;
        rect.origin.y=56.0f;
        tweetTextRemindLabel.frame=rect;

        rect=tweetTextView.frame;
        rect.origin.y=84.0f;
        tweetTextView.frame=rect;
        
        [UIView commitAnimations];
         
        return NO;
    }
    if(range.location>=140)
        return NO;
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    
    [self updateTextRemind];
    
}

#pragma mark method


- (void) updateTextRemind{
    
    allowTextLength = 140 - [tweetTextView.text length] ;
    
    if(allowTextLength < 0){
        allowTextLength = 0;
    }
    
    tweetTextRemindLabel.text = [ NSString stringWithFormat:lang(@"shareTwitter"),allowTextLength ];
    
}

-(void)sharedBackClick{
    if([self.delegate respondsToSelector:@selector(didTweetCancel:)])
        [self.delegate didTweetCancel:self];
}

-(void)sharedDoneClick{
    
    NSString* text=[ElderlyUtils trim:tweetTextView.text];
    if([text length]<1)return;
    if([text length]>140){
        [ElderlyAlertUtils showAlert:lang(@"limitTweet") delegate:nil];
        return;
    }
    
    if([self.delegate respondsToSelector:@selector(didTweetShared:)])
        [self.delegate didTweetShared:self];
}

-(NSString*)sharedText{
    
    NSString* text=[ElderlyUtils trim:tweetTextView.text];
    if([text length]>140){
        text=[text substringToIndex:140];
    }
    else if([text length]<1)
        text=@"";

    return text;
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    if([tweetTextView isFirstResponder])
        [tweetTextView resignFirstResponder];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.30f];
    
    CGRect rect=shareTitleLabel.frame;
    rect.origin.y=54.0f;
    shareTitleLabel.frame=rect;
    
    rect=tweetTextRemindLabel.frame;
    rect.origin.y=56.0f;
    tweetTextRemindLabel.frame=rect;
    
    rect=tweetTextView.frame;
    rect.origin.y=84.0f;
    tweetTextView.frame=rect;
    
    [UIView commitAnimations];

}

@end
