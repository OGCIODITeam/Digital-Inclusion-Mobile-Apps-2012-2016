//
//  TwitterHelper.h
//  SCMPNews
//
//  Created by fanty on 13-3-12.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import <Foundation/Foundation.h>


@class TwitterHelper;
@class ShareingObject;
@protocol TwitterHelperDelegate <NSObject>
-(void)twitterDidClose:(TwitterHelper*)helper;
@end

@interface TwitterHelper : NSObject {
    UIInterfaceOrientation   oldOrientation;
}
@property(nonatomic,assign) id<TwitterHelperDelegate> delegate;
@property(nonatomic,retain) NSString* sharedMessage;

- (void) shareTweet:(ShareingObject *)content;



@end
