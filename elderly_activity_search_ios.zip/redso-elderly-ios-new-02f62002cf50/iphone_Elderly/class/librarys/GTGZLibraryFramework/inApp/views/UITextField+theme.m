//
//  UITextField+theme.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "UITextField+theme.h"
#import "GTGZThemeManager.h"
@implementation UITextField (theme)

-(void)theme:(NSString*)key{
    GTGZTheme* theme=[[GTGZThemeManager sharedInstance] get:key];
    if(theme!=nil){
        if(theme.backgroundColor!=nil)
            self.backgroundColor=theme.backgroundColor;
        else
            self.backgroundColor=[UIColor clearColor];
        if(theme.textColor!=nil)
            self.textColor=theme.textColor;
        if(theme.fontSize>0)
            self.font=[theme font];
    }
}

@end
