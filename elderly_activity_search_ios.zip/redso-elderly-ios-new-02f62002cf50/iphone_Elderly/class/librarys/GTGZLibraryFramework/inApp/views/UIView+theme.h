//
//  UIView+theme.h
//  GTGZLibrary
//
//  Created by fanty on 13-4-22.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (theme)

-(void)theme:(NSString*)key;

@end

