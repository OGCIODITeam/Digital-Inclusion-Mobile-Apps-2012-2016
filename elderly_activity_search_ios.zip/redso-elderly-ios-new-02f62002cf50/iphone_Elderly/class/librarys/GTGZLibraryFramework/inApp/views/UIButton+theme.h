//
//  UIButton+theme.h
//  GTGZLibrary
//
//  Created by fanty on 13-4-26.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (theme)

-(void)theme:(NSString*)key;
@end
