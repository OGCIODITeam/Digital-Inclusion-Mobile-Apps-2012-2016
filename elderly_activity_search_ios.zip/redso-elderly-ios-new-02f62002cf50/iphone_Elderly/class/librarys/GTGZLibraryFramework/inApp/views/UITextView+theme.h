//
//  UITextView+theme.h
//  SVW_STAR
//
//  Created by fanty on 13-7-8.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UITextView (theme)

-(void)theme:(NSString*)key;
@end
