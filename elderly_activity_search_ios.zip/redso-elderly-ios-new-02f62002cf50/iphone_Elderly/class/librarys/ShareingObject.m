//
//  ShareingObject.m
//  iPhone_SCMP
//
//  Created by fanty.xiao on 6/11/12.
//  Copyright (c) 2012年 GTGZ. All rights reserved.
//

#import "ShareingObject.h"

@implementation ShareingObject

@synthesize adTitle;
@synthesize adLink;
@synthesize adDescription;
@synthesize adImageLink;
@synthesize adDate;

- (void)dealloc{
    self.adTitle = nil;
    self.adLink=nil;
    self.adDescription = nil;
    self.adImageLink = nil;
    self.adDate = nil;
    [super dealloc];
}

@end


