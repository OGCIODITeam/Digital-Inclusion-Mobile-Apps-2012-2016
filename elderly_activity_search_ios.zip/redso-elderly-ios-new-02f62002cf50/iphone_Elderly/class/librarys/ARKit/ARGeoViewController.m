
//
//  ARGeoViewController.m
//  ARKitDemo
//
//  Created by Zac White on 8/2/09.
//  Copyright 2009 Gravity Mobile. All rights reserved.
//

#import "ARGeoViewController.h"

#import "ARGeoCoordinate.h"

@implementation ARGeoViewController

@synthesize centerLocation;

- (void)setCenterLocation:(CLLocation *)newLocation {
	[centerLocation release];
	centerLocation = [newLocation retain];
	
	for (ARGeoCoordinate *geoLocation in self.coordinates) {
		if ([geoLocation isKindOfClass:[ARGeoCoordinate class]]) {
			[geoLocation calibrateUsingOrigin:centerLocation];
			
//			NSLog(@"geo: %@", geoLocation);
            
		}
	}
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    self.centerLocation = newLocation;
    [self updateLocations];
}

- (void) updateLocationInfoAt:(ARCoordinate *)coordinate inView:(UIView *)viewToDraw{
    
    if ( [coordinate isKindOfClass:[ARGeoCoordinate class]]) {
        ARGeoCoordinate *geoCoordinate = (ARGeoCoordinate *)coordinate;
//        NSLog(@"geoPoint: %@", geoCoordinate);
        UILabel *distanceLabel = (UILabel *)[viewToDraw viewWithTag:10001];        
        distanceLabel.text = [NSString stringWithFormat:@"%0.2f米", geoCoordinate.radialDistance];
    }
}

@end
