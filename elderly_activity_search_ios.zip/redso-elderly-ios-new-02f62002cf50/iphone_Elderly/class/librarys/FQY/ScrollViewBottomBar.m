//
//  ScrollViewBottomBar.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ScrollViewBottomBar.h"
@interface ScrollViewBottomBar()

@property(retain,nonatomic)UIImageView *theImageView;
@property(assign)Boolean isAtBottom;
@end
@implementation ScrollViewBottomBar
@synthesize  theImageView;
@synthesize  isAtBottom;
 

//-(void)setTheNotificationForKey:(NSString *)theNotificationKey{
//    NSLog(@"%@", theNotificationKey);
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receivedMsg) name:theNotificationKey object:nil];
//}


- (id)initWithFrame:(CGRect)frame
{
        
    self = [super initWithFrame:frame];
    if (self) {
        //   self.backgroundColor=[UIColor redColor];
        // Initialization code
       UIImage *imageA = [UIImage imageNamed:@"btn_scroll.png"];
        self.frame=CGRectMake(self.frame.origin.x, self.frame.origin.y, imageA.size.width,imageA.size.height);
        UIImageView *imageView=[[UIImageView alloc]initWithImage:imageA];
     //   [imageView setImage:imageA];
        self.theImageView=imageView;
  //      NSLog(@"self.theImageView %@,imageView %@",self.theImageView,imageView);
        [self addSubview:self.theImageView];
 //       NSLog(@"imageA %@",imageA);
        [imageView release];imageView=nil;
        self.isAtBottom=NO;
        
     
      
    }
    return self;
}

//-(void)receivedMsg{
//   // NSLog(@"update!");
//    if (self.isAtBottom) {
//        [self notReachedBottom];
//    }else{
//        [self reachedBottom];
//    }
//}


-(void)reachedBottom{
    if (!self.isAtBottom) {
         UIImage *imageA = [UIImage imageNamed:@"btn_scroll_up.png"];
         [self.theImageView setImage:imageA];
        self.isAtBottom=YES;
    }
}
-(void)notReachedBottom{
    if (self.isAtBottom) {
     UIImage *imageA = [UIImage imageNamed:@"btn_scroll.png"];
         [self.theImageView setImage:imageA];
        self.isAtBottom=NO;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    self.theImageView=nil;
    
    [super dealloc];
}

@end
