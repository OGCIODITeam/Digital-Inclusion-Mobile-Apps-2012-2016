//
//  ScrollViewBottomBar.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollViewBottomBar : UIView
-(void)reachedBottom;
-(void)notReachedBottom;
//-(void)setTheNotificationForKey:(NSString *)theNotificationKey;
//赶时间，暂时用消息接收，以后再改
 @end
