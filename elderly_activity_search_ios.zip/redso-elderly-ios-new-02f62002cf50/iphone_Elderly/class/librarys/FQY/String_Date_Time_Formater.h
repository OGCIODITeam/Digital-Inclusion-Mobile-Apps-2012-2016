//
//  String_Date_Time_Formater.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-9-26.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface String_Date_Time_Formater : NSObject
// 24小时转换成12小时制，带上下午
+(NSString *)changeFrom24hTo12h:(NSString *)oString;

//get a darkerColor
+(UIColor *)darkerColorForColor:(UIColor *)c;
+(UIColor *)lighterColorForColor:(UIColor *)c;
/*get the first day from the array,and change it to Chinese long format
   默認 原格式 @"yyyy-MM-dd";
   默認 新格式 @"yyyy年MM月dd日";
*/

+(NSString *)getADateFromNSArray:(NSArray *)dateStringArray fromFormat:(NSString *)oldFormat toFormat:(NSString *)newFormat atIndex:(int)index;

//get all the days from the array,and change it to Chinese long format
 +(NSString *)getAllDateFromNSArray:(NSArray *)dateStringArray fromFormat:(NSString *)oldFormat toFormat:(NSString *)newFormat;

//chang a string or nsdate format to some string format given
+(NSString *)changeDate:(id)theDate FormatFrom:(NSString *)oldFormat to:(NSString *)newFormat showWeekDay:(BOOL)showWeekDay;

+(float)getY:(UIView *)theViewAbove with:(float)gap;
    
+(float)getXFrom:(UIView *)theViewOntTheLeft with:(float)gap;

+(void)writeToFile:(NSArray *)theArray withFileName:(NSString  *)fileName;

+(NSArray *)loadFileToArrayWithFileName:(NSString *)fileName;
@end
