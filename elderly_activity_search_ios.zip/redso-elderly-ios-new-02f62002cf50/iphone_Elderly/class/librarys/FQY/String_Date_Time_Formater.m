//
//  String_Date_Time_Formater.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-9-26.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//
#import "ElderlyNewActivityModel.h"
#import "String_Date_Time_Formater.h"
// from 23:23 to 11:23 PM
@implementation String_Date_Time_Formater
+(NSString *)changeFrom24hTo12h:(NSString *)oString{
     NSDateFormatter *inFormatter = [[NSDateFormatter alloc] init];
    [inFormatter setDateFormat:@"HH:mm"];
    NSDate *theDate=[inFormatter dateFromString:oString];
    [inFormatter setDateFormat:@"hh:mm a"];
    NSString *the12=[inFormatter stringFromDate:theDate];
    [inFormatter release];
     return the12;
}

+(UIColor *)darkerColorForColor:(UIColor *)c
{
    NSString *version = [[UIDevice currentDevice] systemVersion];
    
    if ([version floatValue] >= 5.0 ) {
        float r, g, b, a;
        if ([c getRed:&r green:&g blue:&b alpha:&a])
            return [UIColor colorWithRed:MAX(r - 0.05, 0.0)
                                   green:MAX(g - 0.05, 0.0)
                                    blue:MAX(b - 0.05, 0.0)
                                   alpha:a];
    }
    return c;
}

+(UIColor *)lighterColorForColor:(UIColor *)c
{
    NSString *version = [[UIDevice currentDevice] systemVersion];
    
    if ([version floatValue] >= 5.0 ) {
        float r, g, b, a;
        if ([c getRed:&r green:&g blue:&b alpha:&a])
            return [UIColor colorWithRed:MAX(r + 0.05, 0.0)
                                   green:MAX(g + 0.05, 0.0)
                                    blue:MAX(b + 0.05, 0.0)
                                   alpha:a];
    }
    return c;
}

//from 2013-11-30 to 2013年11月30日（星期六）
+(NSString *)getADateFromNSArray:(NSArray *)dateStringArray fromFormat:(NSString *)oldFormat toFormat:(NSString *)newFormat atIndex:(int)index
{
    if (!oldFormat)oldFormat=@"yyyy-MM-dd";
    if (!newFormat)newFormat=@"yyyy年MM月dd日";
    NSDateFormatter *isoDateFormatter = [[NSDateFormatter alloc] init];
    [isoDateFormatter setDateFormat:oldFormat];
    NSDateFormatter *f = [[NSDateFormatter alloc] init];
    [f setDateFormat:@"EEEE"];
    NSDateFormatter *outPutDateFormatter = [[NSDateFormatter alloc] init];
    [outPutDateFormatter setDateFormat:newFormat];
      NSString *str=[dateStringArray objectAtIndex:index];
    NSDate *aDate=[isoDateFormatter dateFromString:str];
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *weekdayComponents =[gregorian components:NSWeekdayCalendarUnit fromDate:aDate];
    [gregorian release];
     NSInteger weekday = [weekdayComponents weekday];
    NSString *weekDayInChinese=[self getChineseWeekDayFromInt:weekday];
     NSString *date=[NSString stringWithFormat:@"%@%@",[outPutDateFormatter stringFromDate:aDate],weekDayInChinese];
     [isoDateFormatter release];isoDateFormatter=nil;
    [f release];f=nil;
    [outPutDateFormatter release];outPutDateFormatter=nil;
        return date;
}
+(NSString *)getAllDateFromNSArray:(NSArray *)dateStringArray fromFormat:(NSString *)oldFormat toFormat:(NSString *)newFormat
{
    if (!oldFormat)oldFormat=@"yyyy-MM-dd";
    if (!newFormat)newFormat=@"yyyy年MM月dd日";
    NSMutableString *aStr=[[NSMutableString alloc]initWithString:@""];
     NSDateFormatter *readDateFormatter = [[NSDateFormatter alloc] init];
    [readDateFormatter setDateFormat:oldFormat];
     NSDateFormatter *weekDayFormat = [[NSDateFormatter alloc] init];
    [weekDayFormat setDateFormat:@"EEEE"];
     NSDateFormatter *outPutDateFormatter = [[NSDateFormatter alloc] init];
    [outPutDateFormatter setDateFormat:newFormat];

    for (NSString *str in dateStringArray) {
            NSDate *theDate=[readDateFormatter dateFromString:str];
        //查看是星期几
            NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
            NSDateComponents *weekdayComponents =[gregorian components:NSWeekdayCalendarUnit fromDate:theDate];
            NSInteger weekday = [weekdayComponents weekday];
            [gregorian release];gregorian=nil;

        //转换成 中文的(星期几)
            NSString *weekDayInChinese=[self getChineseWeekDayFromInt:weekday];
        //合并
            NSString *whole=[NSString stringWithFormat:@"%@%@",[outPutDateFormatter stringFromDate:theDate],weekDayInChinese];
            [aStr appendString:whole];
            [aStr appendString:@"\n"];
    }
    NSString *result=[NSString stringWithString:aStr];
    [aStr release];aStr=nil;
    [readDateFormatter release];readDateFormatter=nil;
    [weekDayFormat release];weekDayFormat=nil;
    [outPutDateFormatter release]; outPutDateFormatter=nil;
    return result;
}

+(NSString *)changeDate:(id)theDate FormatFrom:(NSString *)oldFormat to:(NSString *)newFormat showWeekDay:(BOOL)showWeekDay
{
    if (!oldFormat)oldFormat=@"yyyy-MM-dd";
    if (!newFormat)newFormat=@"yyyy年MM月dd日";
    NSDate *aDate=nil;
    if ([theDate isKindOfClass:[NSString class]]) {
        NSDateFormatter *readDateFormatter = [[NSDateFormatter alloc] init];
        [readDateFormatter setDateFormat:oldFormat];
       aDate=[readDateFormatter dateFromString:theDate];
        [readDateFormatter release];readDateFormatter=nil;
    }else{
        aDate=(NSDate *)theDate;
    }
    
    NSDateFormatter *weekDayFormat = [[NSDateFormatter alloc] init];
    [weekDayFormat setDateFormat:@"EEEE"];
    NSDateFormatter *outPutDateFormatter = [[NSDateFormatter alloc] init];
    [outPutDateFormatter setDateFormat:newFormat];
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *weekdayComponents =[gregorian components:NSWeekdayCalendarUnit fromDate:aDate];
    [gregorian release];
    NSInteger weekday = [weekdayComponents weekday];
    NSString *weekDayInChinese=[self getChineseWeekDayFromInt:weekday];
    NSString *result=nil;
    if (showWeekDay) {
      result=[NSString stringWithFormat:@"%@%@",[outPutDateFormatter stringFromDate:aDate],weekDayInChinese];
    }else{
      result=[NSString stringWithFormat:@"%@",[outPutDateFormatter stringFromDate:aDate]];
     }
    [weekDayFormat release];weekDayFormat=nil;
    [outPutDateFormatter release]; outPutDateFormatter=nil;
    return result;

 }

+(NSString *)getChineseWeekDayFromInt:(int )weekDay{
    NSString *theWeekDay=nil;
    switch (weekDay) {
        case 1:
            theWeekDay=lang(@"weekday7");
            break;
        case 2:
            theWeekDay=lang(@"weekday1");
            break;
        case 3:
            theWeekDay=lang(@"weekday2");
            break;
        case 4:
            theWeekDay=lang(@"weekday3");
            break;
        case 5:
            theWeekDay=lang(@"weekday4");
            break;
        case 6:
            theWeekDay=lang(@"weekday5");
            break;
        case 7:
            theWeekDay=lang(@"weekday6");
            break;
            
        default:
            break;
    }
    if (theWeekDay) {
        return [NSString stringWithFormat:@"（%@）", theWeekDay];
        
    }else{
        return @"";
    }
}
 
+(float)getXFrom:(UIView *)theViewOntTheLeft with:(float)gap{
    return theViewOntTheLeft.frame.origin.x+theViewOntTheLeft.frame.size.width+gap;
}

+(float)getY:(UIView *)theViewAbove with:(float)gap{
    return  theViewAbove.frame.origin.y+theViewAbove.frame.size.height+gap;
}

+(void)writeToFile:(NSArray *)theArray withFileName:(NSString  *)fileName{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    NSString* documentsDir = [paths objectAtIndex:0];
    NSString* myFilePath = [NSString stringWithFormat:@"%@/%@", documentsDir, fileName];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:theArray];
   [data writeToFile:myFilePath  atomically:YES];
}

+(NSArray *)loadFileToArrayWithFileName:(NSString *)fileName{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    NSString* documentsDir = [paths objectAtIndex:0];
    NSString* myFilePath = [NSString stringWithFormat:@"%@/%@", documentsDir, fileName];
    NSData *data=[NSData dataWithContentsOfFile: myFilePath];
    NSArray *theArray =  [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return theArray;
}

@end
