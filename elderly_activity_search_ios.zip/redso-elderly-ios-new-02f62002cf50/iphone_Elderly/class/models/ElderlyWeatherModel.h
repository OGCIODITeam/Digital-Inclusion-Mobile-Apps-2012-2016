//
//  ElderlyWeatherModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-7.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyWeatherModel : NSObject

@property(nonatomic,retain)NSDate* date;
@property(nonatomic,assign)NSInteger code;
@property(nonatomic,retain)NSString* name;
@property(nonatomic,retain)NSString* name_tc;
@property(nonatomic,retain)NSString* type;
@property(nonatomic,assign)NSInteger temperature;
@property(nonatomic,assign)NSInteger maxTemperature;
@property(nonatomic,assign)NSInteger minTemperature;
@property(nonatomic,retain)NSArray* warning;
@property(nonatomic,assign)NSInteger uvRadiation;
@property(nonatomic,assign)NSInteger humidity;


@end
