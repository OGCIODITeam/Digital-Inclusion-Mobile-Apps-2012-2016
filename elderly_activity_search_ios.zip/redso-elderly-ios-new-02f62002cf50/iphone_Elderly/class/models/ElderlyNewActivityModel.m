//
//  ElderlyNewActivityModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyNewActivityModel.h"

@implementation ElderlyNewActivityModel


@synthesize activityId;
@synthesize nid;
@synthesize title;
@synthesize title_tc;
@synthesize eventType;
@synthesize eventType_tc;
@synthesize activityDateArray;
@synthesize stratTime;
@synthesize endTime;
@synthesize activeArea;
@synthesize activeArea_tc;
@synthesize fee;
@synthesize fee_tc;
@synthesize menberFee;
@synthesize menberFee_tc;
@synthesize nonMenberFee;
@synthesize nonMenberFee_tc;
@synthesize activityType;
@synthesize endDate;

- (void)dealloc
{
    self.activityId = nil;
    self.nid = nil;
    self.title = nil;
    self.title_tc = nil;
    self.eventType = nil;
    self.eventType_tc = nil;
    self.activityDateArray = nil;
    self.stratTime = nil;
    self.endTime = nil;
    self.activeArea = nil;
    self.activeArea_tc = nil;
    self.fee = nil;
    self.fee_tc=nil;
     self.menberFee = nil;
    self.menberFee_tc = nil;
    self.nonMenberFee = nil;
    self.nonMenberFee_tc = nil;
    self.activityType = nil;
    self.endDate = nil;
    [super dealloc];
}
-(void)encodeWithCoder:(NSCoder *)aCoder{
    //encode properties/values
    [aCoder encodeObject:self.activityId forKey:@"activityId"];
    [aCoder encodeObject:self.nid forKey:@"nid"];
    [aCoder encodeObject:self.title forKey:@"title"];
    [aCoder encodeObject:self.title_tc forKey:@"title_tc"];
    [aCoder encodeObject:self.eventType forKey:@"eventType"];
    [aCoder encodeObject:self.eventType_tc forKey:@"eventType_tc"];
    [aCoder encodeObject:self.activityDateArray forKey:@"activityDateArray"];
    [aCoder encodeObject:self.stratTime forKey:@"stratTime"];
    [aCoder encodeObject:self.endTime forKey:@"endTime"];
    [aCoder encodeObject:self.activeArea forKey:@"activeArea"];
    [aCoder encodeObject:self.activeArea_tc forKey:@"activeArea_tc"];
    [aCoder encodeObject:self.fee forKey:@"fee"];
    [aCoder encodeObject:self.fee_tc forKey:@"fee_tc"];
    [aCoder encodeObject:self.menberFee forKey:@"menberFee"];
    [aCoder encodeObject:self.menberFee_tc forKey:@"menberFee_tc"];
    [aCoder encodeObject:self.nonMenberFee forKey:@"nonMenberFee"];
    [aCoder encodeObject:self.nonMenberFee_tc forKey:@"nonMenberFee_tc"];
    [aCoder encodeObject:self.activityType forKey:@"activityType"];
    [aCoder encodeObject:self.endDate forKey:@"endDate"];
}


-(id)initWithCoder:(NSCoder *)aDecoder{
    if((self = [super init])) {
        //decode properties/values
        self.activityId    = [aDecoder decodeObjectForKey:@"activityId"];
        self.nid    = [aDecoder decodeObjectForKey:@"nid"];
        self.title    = [aDecoder decodeObjectForKey:@"title"];
        self.title_tc    = [aDecoder decodeObjectForKey:@"title_tc"];
        self.eventType    = [aDecoder decodeObjectForKey:@"eventType"];
        self.eventType_tc    = [aDecoder decodeObjectForKey:@"eventType_tc"];
        self.activityDateArray    = [aDecoder decodeObjectForKey:@"activityDateArray"];
        self.stratTime    = [aDecoder decodeObjectForKey:@"stratTime"];
        self.endTime    = [aDecoder decodeObjectForKey:@"endTime"];
        self.activeArea    = [aDecoder decodeObjectForKey:@"activeArea"];
        self.activeArea_tc    = [aDecoder decodeObjectForKey:@"activeArea_tc"];
        self.fee    = [aDecoder decodeObjectForKey:@"fee"];
        self.fee_tc    = [aDecoder decodeObjectForKey:@"fee_tc"];
        self.menberFee    = [aDecoder decodeObjectForKey:@"menberFee"];
        self.menberFee_tc    = [aDecoder decodeObjectForKey:@"menberFee_tc"];
        self.nonMenberFee    = [aDecoder decodeObjectForKey:@"nonMenberFee"];
        self.nonMenberFee_tc    = [aDecoder decodeObjectForKey:@"nonMenberFee_tc"];
        self.activityType    = [aDecoder decodeObjectForKey:@"activityType"];
        self.endDate    = [aDecoder decodeObjectForKey:@"endDate"];
    }
    return  self;
}
@end
