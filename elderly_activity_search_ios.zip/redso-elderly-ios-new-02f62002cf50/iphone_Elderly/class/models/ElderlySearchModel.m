//
//  ElderlySearchModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlySearchModel.h"

@implementation ElderlySearchModel


@synthesize nid;
@synthesize centerId;
@synthesize organization;
@synthesize organization_tc;
@synthesize activityCenterName;
@synthesize longitude;
@synthesize latitude;
@synthesize activityList;
@synthesize activityCenterName_tc;

- (void)dealloc
{
    self.nid = nil;
    self.centerId = nil;
    self.organization = nil;
    self.organization_tc = nil;
    self.activityCenterName = nil;
    self.activityList = nil;
    self.activityCenterName_tc = nil;
    [super dealloc];
}

@end
