//
//  ElderlyUserModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyUserModel : NSObject<NSCopying,NSMutableCopying>

@property(nonatomic,assign)NSInteger uid;
@property(nonatomic,retain)NSString* portraitPath;
@property(nonatomic,retain)NSString* portraitBigPath;
@property(nonatomic,retain)NSString* userName;
@property(nonatomic,retain)NSString* gender;
@property(nonatomic,retain)NSString* area;
@property(nonatomic,retain)NSString* region;
@property(nonatomic,retain)NSArray* myInterestArray;

@end
