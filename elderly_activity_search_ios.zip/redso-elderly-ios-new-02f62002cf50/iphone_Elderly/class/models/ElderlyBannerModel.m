//
//  ElderlyBannerModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyBannerModel.h"

@implementation ElderlyBannerModel



@synthesize bId;
@synthesize title;
@synthesize title_tc;
@synthesize bannerDescription;
@synthesize bannerDescription_tc;
@synthesize type;
@synthesize imageUrl;
@synthesize link;

- (void)dealloc
{
    self.link=nil;
    self.title = nil;
    self.title_tc = nil;
    self.bannerDescription = nil;
    self.bannerDescription_tc = nil;
    self.type = nil;
    self.imageUrl = nil;
    self.link = nil;
    [super dealloc];
}

@end
