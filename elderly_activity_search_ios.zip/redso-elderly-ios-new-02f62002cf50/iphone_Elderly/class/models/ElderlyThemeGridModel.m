//
//  ElderlyThemeGridModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-15.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyThemeGridModel.h"

@implementation ElderlyThemeGridModel

@synthesize gridId;
@synthesize image;
@synthesize header;
@synthesize color;
@synthesize arrowDown;
@synthesize arrowUp;
@synthesize imageColor;

-(void)dealloc{

    self.image = nil;
    self.header = nil;
    self.color = nil;
    self.arrowDown = nil;
    self.arrowUp = nil;
    self.imageColor = nil;
    [super dealloc];
}

@end
