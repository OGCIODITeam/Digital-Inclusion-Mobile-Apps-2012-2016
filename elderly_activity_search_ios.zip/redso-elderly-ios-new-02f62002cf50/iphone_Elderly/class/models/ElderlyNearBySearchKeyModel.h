//
//  ElderlyNearBySearchKeyModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-18.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyNearBySearchKeyModel : NSObject

@property(nonatomic,retain)NSString* activityType;
@property(nonatomic,assign)long searchDistance;
@property(nonatomic,assign)float latitude;
@property(nonatomic,assign)float longitude;
@property(nonatomic,retain)NSString* date;
@property(nonatomic,retain)NSString* activeArea;


@end
