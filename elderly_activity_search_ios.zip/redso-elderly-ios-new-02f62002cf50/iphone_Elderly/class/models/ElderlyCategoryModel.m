//
//  ElderlyCategoryModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-27.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyCategoryModel.h"

@implementation ElderlyCategoryModel


@synthesize key;
@synthesize name;
@synthesize name_tc;
@synthesize isSelected;

- (id)init
{
    self = [super init];
    if (self) {

    }
    return self;
}

-(void)dealloc{

    self.key = nil;
    self.name = nil;
    self.name_tc = nil;

    [super dealloc];
}


- (id)mutableCopyWithZone:(NSZone *)zone
{
    
    ElderlyCategoryModel *model = NSCopyObject(self, 0, zone);
    model->key = [self.key mutableCopy];
    model->name = [self.name mutableCopy];
    model->name_tc = [self.name_tc mutableCopy];

    return model;
}

@end
