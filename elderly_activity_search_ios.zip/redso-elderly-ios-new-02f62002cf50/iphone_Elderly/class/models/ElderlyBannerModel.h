//
//  ElderlyBannerModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyBannerModel : NSObject


@property(nonatomic,assign)NSInteger bId;
@property(nonatomic,retain)NSString* title;
@property(nonatomic,retain)NSString* title_tc;
@property(nonatomic,retain)NSString* bannerDescription;
@property(nonatomic,retain)NSString* bannerDescription_tc;
@property(nonatomic,retain)NSString* type;
@property(nonatomic,retain)NSString* imageUrl;
@property(nonatomic,retain)NSString* link;
@end
