//
//  ElderlyNearBySearchKeyModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-18.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyNearBySearchKeyModel.h"

@implementation ElderlyNearBySearchKeyModel

@synthesize activityType;
@synthesize searchDistance;
@synthesize latitude;
@synthesize longitude;
@synthesize date;
@synthesize activeArea;

- (void)dealloc
{
    self.activityType = nil;
    self.date = nil;
    self.activeArea = nil;
    [super dealloc];
}

@end
