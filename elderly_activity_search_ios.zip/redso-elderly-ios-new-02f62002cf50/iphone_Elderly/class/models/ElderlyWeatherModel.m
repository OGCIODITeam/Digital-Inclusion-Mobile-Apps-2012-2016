//
//  ElderlyWeatherModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-7.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyWeatherModel.h"

@implementation ElderlyWeatherModel


@synthesize date;
@synthesize code;
@synthesize name;
@synthesize name_tc;
@synthesize type;
@synthesize temperature;
@synthesize maxTemperature;
@synthesize minTemperature;
@synthesize warning;
@synthesize uvRadiation;
@synthesize humidity;


-(void)dealloc{

    
    self.date = nil;
    self.name = nil;
    self.name_tc = nil;
    self.type = nil;
    self.warning = nil;
    [super dealloc];
}


@end
