//
//  AreaModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-27.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyAreaModel : NSObject

@property(nonatomic,retain)NSString* key;
@property(nonatomic,retain)NSString* name;
@property(nonatomic,retain)NSString* name_tc;
@property(nonatomic,retain)NSArray* regionList;
@property(nonatomic,retain)NSString* value;

@end
