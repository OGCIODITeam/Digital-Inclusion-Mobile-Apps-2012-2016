//
//  ElderlySearchModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlySearchModel : NSObject

@property(nonatomic,retain)NSString* nid;
@property(nonatomic,retain)NSString* centerId;
@property(nonatomic,retain)NSString* organization;
@property(nonatomic,retain)NSString* organization_tc;
@property(nonatomic,retain)NSString* activityCenterName;
@property(nonatomic,retain)NSString* activityCenterName_tc;
@property(nonatomic,assign)float longitude;
@property(nonatomic,assign)float latitude;
@property(nonatomic,retain)NSArray* activityList; // ElderlyNewActivityModel

@end
