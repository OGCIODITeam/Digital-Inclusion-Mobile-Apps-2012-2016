//
//  ElderlyActivityDetailModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyActivityDetailModel : NSObject


@property(nonatomic,retain)NSString* activityId;
@property(nonatomic,retain)NSString* nid;
@property(nonatomic,retain)NSString* centerId;
@property(nonatomic,retain)NSString* centerNid;
@property(nonatomic,retain)NSString* activityCenterName;
@property(nonatomic,retain)NSString* activityCenterName_tc;
@property(nonatomic,retain)NSString* title;
@property(nonatomic,retain)NSString* title_tc;
@property(nonatomic,retain)NSString* activityDescription;
@property(nonatomic,retain)NSString* activityDescription_tc;
@property(nonatomic,retain)NSString* activityDetail;
@property(nonatomic,retain)NSString* activityDetail_tc;
@property(nonatomic,retain)NSString* organlization;
@property(nonatomic,retain)NSString* organlization_tc;
@property(nonatomic,retain)NSString* categoriesValue;
@property(nonatomic,retain)NSString* categoriesValue_tc;
@property(nonatomic,retain)NSArray* dateArray;
@property(nonatomic,retain)NSString* startTime;
@property(nonatomic,retain)NSString* endTime;
@property(nonatomic,retain)NSString* location;
@property(nonatomic,retain)NSString* location_tc;
@property(nonatomic,retain)NSString* fee;
@property(nonatomic,retain)NSString* fee_tc;
@property(nonatomic,retain)NSString* applicationMethod;
@property(nonatomic,retain)NSString* applicationMethod_tc;
@property(nonatomic,retain)NSString* activityTarget;
@property(nonatomic,retain)NSString* activityTarget_tc;
@property(nonatomic,retain)NSString* ageLowerLimit;
@property(nonatomic,retain)NSString* ageLowerLimit_tc;
@property(nonatomic,retain)NSString* eventType;
@property(nonatomic,retain)NSString* eventType_tc;
@property(nonatomic,retain)NSString* activeArea;
@property(nonatomic,retain)NSString* activeArea_tc;
@property(nonatomic,retain)NSString* remark;
@property(nonatomic,retain)NSString* remark_tc;
@property(nonatomic,assign)float longitude;
@property(nonatomic,assign)float latitude;
@property(nonatomic,retain)NSString* link;
@property(nonatomic,retain)NSString* menberFee;
@property(nonatomic,retain)NSString* nonMenberFee;
@property(nonatomic,retain)NSString* menberFee_tc;
@property(nonatomic,retain)NSString* nonMenberFee_tc;
@property(nonatomic,retain)NSString* activityType;
@property(nonatomic,retain)NSString* endDate;


@end
