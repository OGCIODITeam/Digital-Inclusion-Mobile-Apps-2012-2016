//
//  ElderlyUserModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyUserModel.h"

@implementation ElderlyUserModel



@synthesize uid;
@synthesize portraitPath;
@synthesize portraitBigPath;
@synthesize userName;
@synthesize gender;
@synthesize area;
@synthesize region;
@synthesize myInterestArray;



- (id)copyWithZone:(NSZone *)zone
{
    
    ElderlyUserModel *userModel = [[[self class] allocWithZone:zone] init];
    userModel.uid = uid;
    userModel.userName = userName ;
    userModel.uid = uid ;
    userModel.portraitBigPath = portraitBigPath;
    userModel.portraitPath = portraitPath;
    userModel.gender = gender ;
    userModel.area = area ;
    userModel.region = region ;
    userModel.myInterestArray = myInterestArray ;
    
    
    return userModel ;
    
}

- (id)mutableCopyWithZone:(NSZone *)zone

{
    
    ElderlyUserModel *userModel = NSCopyObject(self, 0, zone);
    userModel.uid = uid;
    userModel.userName = userName;
    userModel.uid = uid ;
    userModel.portraitBigPath = portraitBigPath;
    userModel.portraitPath = portraitPath;
    userModel.gender = gender ;
    userModel.area = area ;
    userModel.region = region ;
    userModel.myInterestArray = myInterestArray ;
    return userModel;
}


- (void)dealloc{
    self.portraitPath = nil;
    self.portraitBigPath = nil;
    self.userName = nil;
    self.gender = nil;
    self.area = nil;
    self.region = nil;
    self.myInterestArray = nil;
    [super dealloc];
}





@end
