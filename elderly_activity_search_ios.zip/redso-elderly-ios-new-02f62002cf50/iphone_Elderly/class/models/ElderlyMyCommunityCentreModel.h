//
//  ElderlyMyCommunityCentreModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyMyCommunityCentreModel : NSObject

@property(nonatomic,retain)NSString* vid;
@property(nonatomic,retain)NSString* nid;
@property(nonatomic,retain)NSString* locationValue;
@property(nonatomic,retain)NSString* locationValue_tc;
@property(nonatomic,assign)float longltude;
@property(nonatomic,assign)float latitude;
@property(nonatomic,retain)NSString* organizationValue;
@property(nonatomic,retain)NSString* organizationValue_tc;
@property(nonatomic,retain)NSString* categoriesValue;
@property(nonatomic,retain)NSString* categoriesValue_tc;
@property(nonatomic,retain)NSString* centreValue;
@property(nonatomic,retain)NSString* centreValue_tc;
@property(nonatomic,retain)NSString* districtValue;
@property(nonatomic,retain)NSString* districtValue_tc;

@end
