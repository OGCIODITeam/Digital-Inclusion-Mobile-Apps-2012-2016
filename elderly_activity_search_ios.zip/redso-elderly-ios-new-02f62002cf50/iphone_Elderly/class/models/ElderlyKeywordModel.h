//
//  ElderlyKeywordModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyKeywordModel : NSObject

@property(nonatomic,retain)NSString* kId;
@property(nonatomic,retain)NSString* code;
@property(nonatomic,retain)NSString* code_tc;
@property(nonatomic,assign)NSInteger seq;

@end
