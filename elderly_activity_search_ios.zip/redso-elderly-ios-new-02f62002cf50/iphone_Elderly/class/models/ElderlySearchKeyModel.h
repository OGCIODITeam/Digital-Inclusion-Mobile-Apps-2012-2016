//
//  ElderlySearchKeyModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum {
    locationSearch ,
    easySrach,
    adSearch,
    hotSearch,
    myActivitySearch
    } searchType;

@interface ElderlySearchKeyModel : NSObject

@property(nonatomic,retain)NSString* eventType;
@property(nonatomic,retain)NSString* month;
@property(nonatomic,retain)NSString* activeArea;
@property(nonatomic,assign)NSInteger age;
@property(nonatomic,retain)NSString* fee;
@property(nonatomic,retain)NSString* organization;
@property(nonatomic,retain)NSString* keyword;
@property(nonatomic,assign)BOOL isAdSearch;
@property(nonatomic,assign)searchType searchtype;

@end
