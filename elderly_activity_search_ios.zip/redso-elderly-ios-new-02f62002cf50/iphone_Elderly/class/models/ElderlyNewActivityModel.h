//
//  ElderlyNewActivityModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyNewActivityModel : NSObject

@property(nonatomic,retain)NSString* activityId;
@property(nonatomic,retain)NSString* nid;
@property(nonatomic,retain)NSString* title;
@property(nonatomic,retain)NSString* title_tc;
@property(nonatomic,retain)NSString* eventType;
@property(nonatomic,retain)NSString* eventType_tc;
@property(nonatomic,retain)NSArray* activityDateArray;
@property(nonatomic,retain)NSString* stratTime;
@property(nonatomic,retain)NSString* endTime;
@property(nonatomic,retain)NSString* activeArea;
@property(nonatomic,retain)NSString* activeArea_tc;
@property(nonatomic,retain)NSString* fee;
@property(nonatomic,retain)NSString* fee_tc;
@property(nonatomic,retain)NSString* menberFee;
@property(nonatomic,retain)NSString* menberFee_tc;
@property(nonatomic,retain)NSString* nonMenberFee;
@property(nonatomic,retain)NSString* nonMenberFee_tc;
@property(nonatomic,retain)NSString* activityType;
@property(nonatomic,retain)NSString* endDate;
@end
