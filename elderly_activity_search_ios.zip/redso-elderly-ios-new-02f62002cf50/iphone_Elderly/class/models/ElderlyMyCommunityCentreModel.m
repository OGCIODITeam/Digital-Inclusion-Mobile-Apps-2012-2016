//
//  ElderlyMyCommunityCentreModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyMyCommunityCentreModel.h"

@implementation ElderlyMyCommunityCentreModel

@synthesize vid;
@synthesize nid;
@synthesize locationValue;
@synthesize locationValue_tc;
@synthesize longltude;
@synthesize latitude;
@synthesize organizationValue;
@synthesize organizationValue_tc;
@synthesize categoriesValue;
@synthesize categoriesValue_tc;
@synthesize centreValue;
@synthesize centreValue_tc;
@synthesize districtValue;
@synthesize districtValue_tc;


- (void)dealloc
{

    self.vid = nil;
    self.nid = nil;
    self.locationValue = nil;
    self.locationValue_tc = nil;
    self.organizationValue = nil;
    self.organizationValue_tc = nil;
    self.categoriesValue = nil;
    self.categoriesValue_tc = nil;
    self.districtValue = nil;
    self.districtValue_tc = nil;
    self.centreValue = nil;
    self.centreValue_tc = nil;
    
    [super dealloc];
}

@end
