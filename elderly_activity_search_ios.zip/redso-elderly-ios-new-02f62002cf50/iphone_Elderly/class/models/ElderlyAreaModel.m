//
//  AreaModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-27.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyAreaModel.h"

@implementation ElderlyAreaModel

@synthesize key;
@synthesize name;
@synthesize name_tc;
@synthesize regionList;
@synthesize value;


-(void)dealloc{

    self.value = nil;
    self.key = nil;
    self.name = nil;
    self.name_tc = nil;
    self.regionList = nil;
    [super dealloc];
}

@end
