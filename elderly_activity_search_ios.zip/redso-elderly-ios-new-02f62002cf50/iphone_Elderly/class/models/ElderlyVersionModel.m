//
//  ElderlyVersionModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyVersionModel.h"

@implementation ElderlyVersionModel

@synthesize link;
@synthesize type;
@synthesize versionNum;
@synthesize versionMsg;
@synthesize versionMsg_tc;

- (void)dealloc
{
    self.link = nil;
    self.type = nil;
    self.versionMsg = nil;
    self.versionMsg_tc = nil;
    self.versionNum = nil;
    [super dealloc];
}

@end
