//
//  ElderlySearchKeyModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlySearchKeyModel.h"

@implementation ElderlySearchKeyModel


@synthesize eventType;
@synthesize month;
@synthesize activeArea;
@synthesize age;
@synthesize fee;
@synthesize organization;
@synthesize keyword;
@synthesize isAdSearch;
@synthesize searchtype;

- (void)dealloc
{
    self.month = nil;
    self.eventType = nil;
    self.activeArea = nil;
    self.fee = nil;
    self.organization = nil;
    self.keyword = nil;
    [super dealloc];
}

@end
