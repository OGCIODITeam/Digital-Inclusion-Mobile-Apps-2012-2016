//
//  ElderlyVersionModel.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyVersionModel : NSObject

@property(nonatomic,assign)NSInteger vId;
@property(nonatomic,retain)NSString* link;
@property(nonatomic,retain)NSString* type;
@property(nonatomic,retain)NSString* versionNum;
@property(nonatomic,retain)NSString* versionMsg;
@property(nonatomic,retain)NSString* versionMsg_tc;

@end
