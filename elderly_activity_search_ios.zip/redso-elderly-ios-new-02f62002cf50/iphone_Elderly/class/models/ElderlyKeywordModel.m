//
//  ElderlyKeywordModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyKeywordModel.h"

@implementation ElderlyKeywordModel

@synthesize kId;
@synthesize code;
@synthesize code_tc;
@synthesize seq;

- (void)dealloc
{
    self.kId = nil;
    self.code_tc = nil;
    self.code = nil;
    [super dealloc];
}

@end
