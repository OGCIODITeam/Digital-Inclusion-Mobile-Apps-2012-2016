//
//  ElderlyActivityDetailModel.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyActivityDetailModel.h"

@implementation ElderlyActivityDetailModel


@synthesize activityId;
@synthesize nid;
@synthesize centerId;
@synthesize centerNid;
@synthesize activityCenterName;
@synthesize title;
@synthesize activityDescription;
@synthesize activityDetail;
@synthesize organlization;
@synthesize categoriesValue;

@synthesize categoriesValue_tc;
@synthesize activityCenterName_tc;
@synthesize title_tc;
@synthesize activityDescription_tc;
@synthesize activityDetail_tc;
@synthesize organlization_tc;
@synthesize dateArray;
@synthesize startTime;
@synthesize endTime;
@synthesize location;
@synthesize fee;
@synthesize applicationMethod;
@synthesize activityTarget;
@synthesize ageLowerLimit;
@synthesize eventType;
@synthesize activeArea;
@synthesize remark;

@synthesize location_tc;
@synthesize fee_tc;
@synthesize applicationMethod_tc;
@synthesize activityTarget_tc;
@synthesize ageLowerLimit_tc;
@synthesize eventType_tc;
@synthesize activeArea_tc;
@synthesize remark_tc;

@synthesize longitude;
@synthesize latitude;
@synthesize link;
@synthesize menberFee;
@synthesize nonMenberFee;
@synthesize menberFee_tc;
@synthesize nonMenberFee_tc;
@synthesize activityType;
@synthesize endDate;

- (void)dealloc
{
    self.nid = nil;
    self.activityId = nil;
    self.centerId = nil;
    self.centerNid = nil;
    self.activityCenterName = nil;
    self.title = nil;
    self.activityDescription = nil;
    self.activityDetail = nil;
    self.organlization = nil;
    self.dateArray = nil;
    self.startTime = nil;
    self.endTime = nil;
    self.location = nil;
    self.fee = nil;
    self.applicationMethod = nil;
    self.activityTarget = nil;
    self.ageLowerLimit = nil;
    self.eventType = nil;
    self.activeArea = nil;
    self.remark = nil;
    self.link = nil;
    self.categoriesValue = nil;
    
    self.categoriesValue_tc = nil;
    self.activityCenterName_tc = nil;
    self.title_tc = nil;
    self.activityDescription_tc = nil;
    self.activityDetail_tc = nil;
    self.organlization_tc = nil;
    self.location_tc = nil;
    self.fee_tc = nil;
    self.applicationMethod_tc = nil;
    self.activityTarget_tc = nil;
    self.ageLowerLimit_tc = nil;
    self.eventType_tc = nil;
    self.activeArea_tc = nil;
    self.remark_tc = nil;
    self.menberFee_tc = nil;
    self.nonMenberFee_tc = nil;
    self.activityType = nil;
    self.endDate = nil;
    [super dealloc];
}



@end
