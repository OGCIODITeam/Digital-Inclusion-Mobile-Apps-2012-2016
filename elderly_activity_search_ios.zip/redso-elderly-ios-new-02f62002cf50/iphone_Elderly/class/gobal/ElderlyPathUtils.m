//
//  ElderlyPathUtils.m
//  iphone_Elderly
//
//  Created by fanty on 13-9-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyPathUtils.h"

#define KEY_PORTRAIN_FILE @"Portrait"

@implementation ElderlyPathUtils


+(NSString*) resourceSqlitePath{
    return [NSString stringWithFormat:@"%@/Elderly.sqlite",
            [[NSBundle mainBundle]  resourcePath] ];
    
}

+(NSString*) localDatabasePath{
    NSString* root=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* databasePath=[root stringByAppendingPathComponent:@"database"];
    NSFileManager* fileManager=[NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:databasePath]){
        [fileManager createDirectoryAtPath:databasePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return [databasePath stringByAppendingPathComponent:@"local_data.sqlite"];
}

+(NSString*)getPortraitPath:(BOOL)big{
    
    
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [path objectAtIndex:0];
    //获取文件管理器
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //指定新建文件夹路径
    NSString *imageDocPath = [documentPath stringByAppendingPathComponent:KEY_PORTRAIN_FILE];
    //创建ImageFile文件夹
    [fileManager createDirectoryAtPath:imageDocPath withIntermediateDirectories:YES attributes:nil error:nil];
    //返回保存图片的路径（图片保存在ImageFile文件夹下）
    NSString * imagePath = [imageDocPath stringByAppendingPathComponent:[NSString stringWithFormat:@"portrait_%@.png",(big?@"big":@"small")]];
    
    return imagePath;
    
}

+(NSString*)getWeatherCachePath{

    NSString* root=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* databasePath=[root stringByAppendingPathComponent:@"cache"];
    NSFileManager* fileManager=[NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:databasePath]){
        [fileManager createDirectoryAtPath:databasePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return [databasePath stringByAppendingPathComponent:@"weather_Data.xml"];

}

+(NSString*)getPortraitDocPath{
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [path objectAtIndex:0];
    //指定新建文件夹路径
    NSString *imageDocPath = [documentPath stringByAppendingPathComponent:KEY_PORTRAIN_FILE];
    
    return imageDocPath;
}

+(NSString*)getMainBannerCachePath{
    NSString* root=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* databasePath=[root stringByAppendingPathComponent:@"cache"];
    NSFileManager* fileManager=[NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:databasePath]){
        [fileManager createDirectoryAtPath:databasePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return [databasePath stringByAppendingPathComponent:@"mainBanner_Data.xml"];

}

+(NSString*)getNewActivityCachePath{
    
    NSString* root=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* databasePath=[root stringByAppendingPathComponent:@"cache"];
    NSFileManager* fileManager=[NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:databasePath]){
        [fileManager createDirectoryAtPath:databasePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return [databasePath stringByAppendingPathComponent:@"newActivityBanner_Data.xml"];
}

+(NSString*)getActivityBannerPictureCachePath:(NSString*)path{

    NSString* root=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* databasePath=[root stringByAppendingPathComponent:@"cache"];
    NSFileManager* fileManager=[NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:databasePath]){
        [fileManager createDirectoryAtPath:databasePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    return [databasePath stringByAppendingPathComponent: [fileManager displayNameAtPath:path]];

}


@end
