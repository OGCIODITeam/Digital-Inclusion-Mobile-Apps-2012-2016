//
//  ElderlyUtils.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyUtils : NSObject

+(NSString*)language;
+(BOOL)languageType;
+(UIColor*)colorConvertFromString:(NSString*)value;
+(NSString*)convertStringFromDate:(NSDate*)date;
+(BOOL)isRetain4;
+ (NSString*)getAppName;
+(BOOL)isValidateEmail:(NSString *)email;
+(NSString*)trim:(NSString*)value;

+(NSString*)text:(id)model key:(NSString*)key;

+(NSString*)converDateStringFromeString:(NSString*)value;
+(double)systemVersion;

+(BOOL)checkNetWork;

+(NSString*)getTelNumber:(NSString*)number;

@end
