//
//  ElderlyUtils.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyUtils.h"
#import "AppDelegate.h"
#import "ElderlySettingManager.h"
#import "Reachability.h"

@implementation ElderlyUtils


+(NSString*)language{
    
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    BOOL lang = [appDelegate.settingManager getlanguageType];
        
    if(lang){
        return @"zh-cn";
    }
    else{
        return @"zh-hk";
    }
}

+(BOOL)languageType{
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    return [appDelegate.settingManager getlanguageType];
}


+(UIColor*)colorConvertFromString:(NSString*)value{
    if([value length]<7)return [UIColor whiteColor];
    
    SEL blackSel = NSSelectorFromString(value);
    if ([UIColor respondsToSelector: blackSel]){
        UIColor* color  = [UIColor performSelector:blackSel];
        if(color!=nil)
            return color;
    }
    
    NSRange range;
    range.location=1;
    range.length=2;
    NSString* r=[NSString stringWithFormat:@"0x%@",[value substringWithRange:range]];
    range.location=3;
    NSString* g=[NSString stringWithFormat:@"0x%@",[value substringWithRange:range]];
    range.location=5;
    NSString* b=[NSString stringWithFormat:@"0x%@",[value substringWithRange:range]];
    
    
    float rColor=0;
    float gColor=0;
    float bColor=0;
    float alpha=1;
    
    [[NSScanner scannerWithString:r] scanHexFloat:&rColor];
    [[NSScanner scannerWithString:g] scanHexFloat:&gColor];
    [[NSScanner scannerWithString:b] scanHexFloat:&bColor];
    
    
    rColor=rColor / 255;
    gColor=gColor / 255;
    bColor=bColor / 255;
    
    
    if([value length]==9){
        range.location=7;
        NSString* a=[NSString stringWithFormat:@"0x%@",[value substringWithRange:range]];
        
        [[NSScanner scannerWithString:a] scanHexFloat:&alpha];
        
        alpha=alpha / 255;
    }
    
    return [UIColor colorWithRed:rColor green:gColor blue:bColor alpha:alpha];
}


+(NSString*)convertStringFromDate:(NSDate*)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //zzz表示时区，zzz可以删除，这样返回的日期字符将不包含时区信息。
    
    NSLocale *zh_Locale = [[NSLocale alloc] initWithLocaleIdentifier:[ElderlyUtils language]];
    [dateFormatter setLocale:zh_Locale];
    [zh_Locale release];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    NSString *destDateString = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    
    return destDateString;
}

+(BOOL)isRetain4{
    CGSize size=[[UIApplication sharedApplication] delegate].window.bounds.size;
    return (size.height>480.0f);
}

+ (NSString*)getAppName{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];
}

+(NSString*)trim:(NSString*)value{
    return [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet] ];
}

+(BOOL)isValidateEmail:(NSString *)email {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

+(NSString*)text:(id)model key:(NSString*)key{

    BOOL languageType = [self languageType];
    
    if(languageType){
        key = [key stringByReplacingOccurrencesOfString:@"_tc" withString:@""];
    }
    else{
        NSRange range = [key rangeOfString:@"_tc"];
        if(range.location == NSNotFound){
            key = [key stringByAppendingString:@"_tc"];
        }
    }
    return [model valueForKey:key];

}

+(NSString*)converDateStringFromeString:(NSString*)value{

    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate* date = [dateFormatter dateFromString:value];
    
    NSLocale *locale=[[NSLocale alloc] initWithLocaleIdentifier:[ElderlyUtils language]];
    [dateFormatter setLocale:locale];
    
    [dateFormatter setDateFormat:@"yyyy年MM月dd日 (EEEE) "];
    [locale release];
    
    NSString* strDate = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    
    return strDate;
    
}

+(double)systemVersion{

    return [[[UIDevice currentDevice] systemVersion] doubleValue];

}

+(BOOL)checkNetWork{
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus internetStatus = [reachability currentReachabilityStatus];
    return internetStatus;
}

+(NSString*)getTelNumber:(NSString*)number{


    NSRange range = [number rangeOfString:@"[0-9]{4}-[0-9]{4}" options:NSRegularExpressionSearch];
    if (range.location != NSNotFound) {
        return [[number substringWithRange:range] stringByReplacingOccurrencesOfString:@"-" withString:@""];
    }
    
    range = [number rangeOfString:@"[0-9]{8}" options:NSRegularExpressionSearch];
    if (range.location != NSNotFound) {
        return [number substringWithRange:range];
    }

    range = [number rangeOfString:@"[0-9]{4} [0-9]{4}" options:NSRegularExpressionSearch];
    if (range.location != NSNotFound) {
        return [[number substringWithRange:range] stringByReplacingOccurrencesOfString:@" " withString:@""];
    }
    
    return nil;
}


@end
