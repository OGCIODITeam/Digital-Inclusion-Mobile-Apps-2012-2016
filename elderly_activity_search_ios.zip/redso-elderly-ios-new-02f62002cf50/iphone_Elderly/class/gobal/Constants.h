/*
 @header Constants.h
 @abstract iPhone_eBay
 @author Henry.Yu
 @version 1.0 */

#ifndef iPhone_Elderly_Constants_h
#define iPhone_Elderly_Constants_h


#define  APP_VERSION    @"1.0"

// Google Analytics begin
#define GA_CODE_PG_SPLASHSCREEN @"pg_SplashScreen"
#define GA_CODE_PG_MAINPAGE @"pg_MainPage"
#define GA_CODE_PHOTOBUTTON @"PhotoButton"
#define GA_CODE_WEATHERFORECASTBUTTON @"WeatherForecastButton"
#define GA_CODE_BANNER @"Banner"
#define GA_CODE_LATESTACTIVITYBUTTON @"LatestActivityButton"
#define GA_CODE_FAVOURITECENTERBUTTON @"FavouriteCenterButton"
#define GA_CODE_MYACTIVITYBUTTON @"MyActivityButton"
#define GA_CODE_SEARCHNEARBYBUTTON @"SearchNearbyButton"
#define GA_CODE_EASYSEARCHBUTTON @"EasySearchButton"
#define GA_CODE_ADVANCEDSEARCHBUTTON @"AdvancedSearchButton"
#define GA_CODE_SETTINGBUTTON @"SettingButton"
#define GA_CODE_PG_LATESTACTIVITY @"pg_LatestActivity"
#define GA_CODE_LCSDBUTTON @"LCSDButton"
#define GA_CODE_ELDERCENTERBUTTON @"ElderCenterButton"
#define GA_CODE_PG_ACTIVITYDETAIL_ACTIVITYNUMBER_ACTIVITYTITLE @"pg_ActivityDetail＿ActivityNumber_ActivityTitle"
#define GA_CODE_ADDBUTTON @"AddButton"
#define GA_CODE_SHAREBUTTON @"ShareButton"
#define GA_CODE_ACTIVITYDETAILSHARE @"ActivityDetailShare"
#define GA_CODE_MAPBUTTON @"MapButton"
#define GA_CODE_ARBUTTON @"ARButton"
#define GA_CODE_PIN @"Pin"
#define GA_CODE_CURRENTLOCATIONBUTTON @"CurrentLocationButton"
#define GA_CODE_ACTIVITYDETAILBUTTON @"ActivityDetailButton"
#define GA_CODE_PG_FAVOURITECENTER @"pg_FavouriteCenter"
#define GA_CODE_DATE @"Date"
#define GA_CODE_PG_MYACTIVITY @"pg_MyActivity"
#define GA_CODE_PG_SEARCHNEARBY @"pg_SearchNearby"
#define GA_CODE_LIVINGLOCATIONBUTTON @"LivingLocationButton"
#define GA_CODE_SELECTDISTANCEBUTTON @"SelectDistanceButton"
#define GA_CODE_PG_EASYSEARCH @"pg_EasySearch"
#define GA_CODE_SEARCHBUTTON @"SearchButton"
#define GA_CODE_PG_ADVANCEDSEARCH @"pg_AdvancedSearch"
#define GA_CODE_ACTIVITYTYPE @"ActivityType"
#define GA_CODE_ACTIVITYLOCATION @"ActivityLocation"
#define GA_CODE_ORGANIZATION @"Organization"
#define GA_CODE_AGE @"Age"
#define GA_CODE_PRICE @"Price"
#define GA_CODE_KEYWORD @"Keyword"
#define GA_CODE_HOTKEY @"Hotkey"
#define GA_CODE_PG_SETTING @"pg_Setting"
#define GA_CODE_SMALLFONTSIZE @"SmallFontSize"
#define GA_CODE_MEDIUMFONTSIZE @"MediumFontSize"
#define GA_CODE_LARGEFONTSIZE @"LargeFontSize"
#define GA_CODE_TRADITIONALCHINESE @"TraditionalChinese"
#define GA_CODE_SIMPLIFIEDCHINESE @"SimplifiedChinese"
#define GA_CODE_COLOUR1 @"Colour1"
#define GA_CODE_COLOUR2 @"Colour2"
#define GA_CODE_CLICK @"Click"
// Google Analytics end

//#define   DEBUG       1

#define   DEV_VERSION   1

#define lang(key)            NSLocalizedStringFromTable(key, [ElderlyUtils language], @"")

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#ifdef DEBUG
#   define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#   define DLog(...)
#endif

#define HTTP_ERROR_CODE @"connect_error"


#define NotificationThemeChanged                  @"themeChanged"
#define loadCount 20

#import "UIView+theme.h"
#import "UILabel+theme.h"
#import "UIButton+theme.h"
#import "UITextView+theme.h"
#import "UITextField+theme.h"
#endif
