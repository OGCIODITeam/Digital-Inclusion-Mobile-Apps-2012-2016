//
//  HTTPRequest.m
//  iphone_Elderly
//
//  Created by fanty on 13-9-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "HTTPRequest.h"

#define HTTP_TIMEOUT   10.0f

@implementation HTTPRequest

-(id)init{
    self=[super init];
    
    if(self){
        [self setTimeOutSeconds:HTTP_TIMEOUT];
        self.persistentConnectionTimeoutSeconds=HTTP_TIMEOUT;
    }
    return  self;
}

-(void)dealloc{
    [super dealloc];
}

@end


@implementation FormDataRequest

- (id)init{
    self = [super init];
    if (self) {
        [self setTimeOutSeconds:HTTP_TIMEOUT];
        self.persistentConnectionTimeoutSeconds=HTTP_TIMEOUT;
        
    }
    return self;
}

-(void)dealloc{
    [super dealloc];
}

@end
