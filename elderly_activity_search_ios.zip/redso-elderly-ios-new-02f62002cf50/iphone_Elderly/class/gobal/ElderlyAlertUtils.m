//
//  ElderlyAlertUtils.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyAlertUtils.h"

@implementation ElderlyAlertUtils

+(UIAlertView*)showAlert:(NSString*)message cancelButton:(NSString*)cancelButton delegate:(id)delegate{
    
    UIAlertView* alert=[[UIAlertView alloc] initWithTitle:lang(@"Elderly") message:message delegate:delegate cancelButtonTitle:cancelButton otherButtonTitles:nil, nil];
    
    [alert show];
    [alert release];
    return alert;
    
}

+(UIAlertView*)showAlert:(NSString*)message delegate:(id)delegate {
    return [self showAlert:message cancelButton:lang(@"confirm") delegate:delegate];
}

+(UIAlertView*)showOKCancelAlert:(NSString *)message delegate:(id) delegate {

    
    UIAlertView* alert=[[UIAlertView alloc] initWithTitle:lang(@"Elderly") message:message delegate:delegate cancelButtonTitle:lang(@"confirm") otherButtonTitles:lang(@"cancel"), nil];
    
    [alert show];
    [alert release];
    return alert;
}

+(UIAlertView*)showAlert:(NSString*)title message:(NSString *)message button:(NSString*)button cancelButton:(NSString*)cancelButton delegate:(id) delegate{
    
    
    UIAlertView* alert=[[UIAlertView alloc] initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButton otherButtonTitles:button, nil];
    
    
    [alert show];
    [alert release];
    return alert;
}


@end
