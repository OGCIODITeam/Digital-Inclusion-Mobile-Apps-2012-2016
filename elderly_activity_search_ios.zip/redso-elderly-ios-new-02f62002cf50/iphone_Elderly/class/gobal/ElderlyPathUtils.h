//
//  ElderlyPathUtils.h
//  iphone_Elderly
//
//  Created by fanty on 13-9-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyPathUtils : NSObject


+(NSString*) resourceSqlitePath;

+(NSString*) localDatabasePath;

+(NSString*)getPortraitPath:(BOOL)big;

+(NSString*)getWeatherCachePath;

+(NSString*)getMainBannerCachePath;

+(NSString*)getNewActivityCachePath;

+(NSString*)getActivityBannerPictureCachePath:(NSString*)path;

+(NSString*)getPortraitDocPath;

@end
