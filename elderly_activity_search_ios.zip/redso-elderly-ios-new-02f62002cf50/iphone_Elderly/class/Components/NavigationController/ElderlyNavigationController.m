//
//  ElderlyNavigationController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyNavigationController.h"


#define CUSTOM_BAR_IMAGE_TAG   13

#define BAR_HEIGHT   44

@interface ElderlyBarButtonItem(private)

@end


@implementation ElderlyBarButtonItem

- (id)initWithTitle:(NSString *)title image:(UIImage*)image right:(BOOL)right target:(id)_target action:(SEL)_action{
    
    self=[super init];
    
    UIView* bgView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, BAR_HEIGHT, BAR_HEIGHT)];
    
    UIButton* button=[UIButton buttonWithType:UIButtonTypeCustom];
    button.frame=CGRectMake((right?6:-6), 0, BAR_HEIGHT, BAR_HEIGHT);
    [button theme:@"navigationController_button"];
    if(image!=nil){
        [button setBackgroundImage:image forState:UIControlStateNormal];
        bgView.frame=CGRectMake(0, 0, image.size.width, image.size.height);
        
        button.frame=CGRectMake((right?6:-6), 0, image.size.width, image.size.height);
    }
    if(_target!=nil && _action!=nil)
        [button addTarget:_target action:_action forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:title forState:UIControlStateNormal];
    
    [bgView addSubview:button];
    self.customView=bgView;
    
    [bgView release];
    
    return self;
}


@end




@interface ElderlyNavigationController ()

@end

@implementation ElderlyNavigationController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
