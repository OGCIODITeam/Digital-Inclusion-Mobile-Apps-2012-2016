//
//  ElderlyNavigationController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ElderlyBarButtonItem:UIBarButtonItem
- (id)initWithImage:(NSString*)themeImage target:(id)target action:(SEL)action;
@end


@interface ElderlyNavigationController : UINavigationController{

    UIImageView* backgroundImage;
    NSString* bgImage;
}

-(void)barBackground:(NSString*) image;

@end
