//
//  AreaParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-27.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "AreaParser.h"
#import "ElderlyAreaModel.h"

@implementation AreaParser

- (void)onParse: (GDataXMLElement*) rootElement{

    
    if(rootElement == nil)
        return ;
    
    NSArray* array = [rootElement elementsForName:@"District"];
    NSMutableArray* list = [[NSMutableArray alloc ] init];
    
    for(GDataXMLElement* element in array){
    
        ElderlyAreaModel* areaModel = [[ElderlyAreaModel alloc] init];
        areaModel.key = [[[element elementsForName:@"key"] objectAtIndex:0] stringValue];
        areaModel.name = [[[element elementsForName:@"name_sc"] objectAtIndex:0] stringValue];
        areaModel.name_tc = [[[element elementsForName:@"name_tc"] objectAtIndex:0] stringValue];
        areaModel.value = [[[element elementsForName:@"value"] objectAtIndex:0] stringValue];

        
        if([[element elementsForName:@"RegionList"] objectAtIndex:0] != nil){
        
            NSArray* regionListElementArray = [[[element elementsForName:@"RegionList"] objectAtIndex:0] elementsForName:@"Region"];
            NSMutableArray* regionList = [[NSMutableArray alloc] init];
            
            for (GDataXMLElement* regionElement in regionListElementArray) {
                ElderlyAreaModel* regionModel = [[ElderlyAreaModel alloc] init];
                regionModel.key = [[[regionElement elementsForName:@"key"] objectAtIndex:0] stringValue];
                regionModel.name = [[[regionElement elementsForName:@"name_sc"] objectAtIndex:0] stringValue];
                regionModel.name_tc = [[[regionElement elementsForName:@"name_tc"] objectAtIndex:0] stringValue];
                regionModel.value = [[[regionElement elementsForName:@"value"] objectAtIndex:0] stringValue];
                [regionList addObject:regionModel];
                [regionModel release];
            }
            areaModel.regionList = regionList;
            [regionList release];
        }
        [list addObject:areaModel];
        [areaModel release];
    }
    
    [result release];
    result = [list retain];
    [list release];

}

@end
