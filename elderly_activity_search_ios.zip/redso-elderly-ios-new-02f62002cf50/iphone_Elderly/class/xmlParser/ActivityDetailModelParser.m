//
//  ActivityDetailModelParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ActivityDetailModelParser.h"
#import "ElderlyActivityDetailModel.h"

@implementation ActivityDetailModelParser

- (void)onParse: (GDataXMLElement*) rootElement{


    
    GDataXMLElement* firstElement = [[rootElement elementsForName:@"activity"] objectAtIndex:0];
    NSString* type = [[[rootElement elementsForName:@"activityType"] objectAtIndex:0] stringValue];
    

    
    NSArray* array = [firstElement children];
    if(array == nil || [array count] < 1)
        return;
    
    ElderlyActivityDetailModel* model = [[ElderlyActivityDetailModel alloc] init];
    model.activityType = type;
    
    for(GDataXMLElement* ele in array){
        
        if([[ele name] isEqualToString:@"id"]){
            model.activityId = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"nid"]){
            model.nid = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"centerId"]){
            model.centerId = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"centerNid"]){
            model.centerNid = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"activityCenterName"]){
            model.activityCenterName_tc = [ele stringValue];
            model.activityCenterName = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"title"]){
            model.title_tc = [ele stringValue];
            model.title = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"description"]){
            model.activityDescription_tc = [ele stringValue];
            model.activityDescription = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"activityDetail"]){
            model.activityDetail_tc = [ele stringValue];
            model.activityDetail = [ele big5ToGb];
            
        }
        else if([[ele name] isEqualToString:@"organization"]){
            model.organlization_tc = [ele stringValue];
            model.organlization = [ele big5ToGb];
            
        }
        else if([[ele name] isEqualToString:@"categoriesValue"]){
            model.categoriesValue_tc = [ele stringValue];
            model.categoriesValue = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"eventType"]){
            model.eventType_tc = [ele stringValue];
            model.eventType = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"date"]){
            model.dateArray = [[ele stringValue] componentsSeparatedByString:@","];
        }
        else if([[ele name] isEqualToString:@"startTime"]){
            model.startTime = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"endTime"]){
            model.endTime = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"location"]){
            model.location_tc = [ele stringValue];
            model.location = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"memberFee"]){
            model.menberFee_tc = [ele stringValue];
            model.menberFee = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"nonmenberFee"]){
            model.nonMenberFee_tc = [ele stringValue];
            model.nonMenberFee = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"fee"]){
            model.fee_tc = [ele stringValue];
            model.fee = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"applicationMethod"]){
            model.applicationMethod_tc = [ele stringValue];
            model.applicationMethod = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"activityTarget"]){
            model.activityTarget_tc = [ele stringValue];
            model.activityTarget = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"ageLowerLimit"]){
            model.ageLowerLimit_tc = [ele stringValue];
            model.ageLowerLimit = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"activeArea"]){
            model.activeArea_tc = [ele stringValue];
            model.activeArea = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"remark"]){
            model.remark_tc = [ele stringValue];
            model.remark = [ele big5ToGb];
        }
        else if([[ele name] isEqualToString:@"latitude"]){
            model.latitude = [[ele stringValue] floatValue];

        }
        else if([[ele name] isEqualToString:@"longitude"]){
            model.longitude = [[ele stringValue] floatValue];
        }
        else if([[ele name] isEqualToString:@"link"]){
            model.link = [ele stringValue];
        }
        else if([[ele name] isEqualToString:@"endDate"]){
            model.endDate = [ele stringValue];
        }
    
    }

    [result release];
    result = [model retain];
    [model release];
}

@end
