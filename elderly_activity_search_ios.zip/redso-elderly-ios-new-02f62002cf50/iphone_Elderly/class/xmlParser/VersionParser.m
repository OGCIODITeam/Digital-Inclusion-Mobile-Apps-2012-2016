//
//  VersionParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "VersionParser.h"
#import "ElderlyVersionModel.h"

@implementation VersionParser


- (void)onParse: (GDataXMLElement*) rootElement{

    NSArray* array = [rootElement elementsForName:@"version"];
    if(array == nil || [array count] < 1)
        return;
    ElderlyVersionModel* versionModel = [ElderlyVersionModel alloc];
    
    GDataXMLElement* firstElement = [array objectAtIndex:0];
    NSArray* versionArray = [firstElement children];
    for(GDataXMLElement* element in versionArray){
        
        if([[element name] isEqualToString:@"id"]){
            versionModel.vId = [element intValue];
        }
        else if([[element name] isEqualToString:@"link"]){
            versionModel.link = [element stringValue];
        }
        else if([[element name] isEqualToString:@"type"]){
            versionModel.type = [element stringValue];
        }
        else if([[element name] isEqualToString:@"versionNum"]){
            versionModel.versionNum = [element stringValue];
        }
        else if([[element name] isEqualToString:@"msg"]){
            versionModel.versionMsg_tc = [element stringValue];
            versionModel.versionMsg = [element big5ToGb];
        }
    }
    
    [result release];
    result = [versionModel retain];
    [versionModel release];
}
//<response><status>0</status><msg>success</msg><version><id>15</id><link>b</link><type>A</type><version_num>b</version_num><image>b</image></version></response>
@end
