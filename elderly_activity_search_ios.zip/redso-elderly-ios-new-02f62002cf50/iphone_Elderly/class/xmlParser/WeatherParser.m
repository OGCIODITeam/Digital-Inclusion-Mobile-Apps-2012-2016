//
//  WeatherParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-15.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "WeatherParser.h"
#import "ElderlyWeatherModel.h"

@implementation WeatherParser


- (void)onParse: (GDataXMLElement*) rootElement{

    
    NSArray* array = [rootElement children];
    
    NSMutableArray* list = [[NSMutableArray alloc] init];

    for(GDataXMLElement* element in array){
    
        if([[element name] isEqualToString:@"currentWeather"]){
        
            NSArray* currentWeather = [element children];
            [self parserChildren:currentWeather data:list];
        
        }
        else if([[element name] isEqualToString:@"forecastWeatherList"]){
        
            NSArray* forecastWeatherArray = [element children];
            
            for(GDataXMLElement* forecastWeatherElement in forecastWeatherArray){
                
                if([[forecastWeatherElement name] isEqualToString:@"forecastWeather"]){
                    
                    NSArray* forecastWeather = [forecastWeatherElement children];
                    [self parserChildren:forecastWeather data:list];
                }
            }
        }
    }
    [result release];
    result = [list retain];
    [list release];
}


-(void)parserChildren:(NSArray*)xmlResource data:(NSMutableArray*)list{
    
    ElderlyWeatherModel* model = [[ElderlyWeatherModel alloc] init];
    
    for(GDataXMLElement* currentElement in xmlResource){
        
        if([[currentElement name] isEqualToString:@"date"]){
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = @"yyyy-MM-dd";
            model.date = [dateFormatter dateFromString:[currentElement stringValue]];
            [dateFormatter release];
        }
        else if([[currentElement name] isEqualToString:@"code"]){
            
            model.code = [currentElement intValue];
        }
        else if([[currentElement name] isEqualToString:@"name"]){
            
            model.name_tc = [currentElement stringValue];
            model.name = [currentElement big5ToGb];
        }
        else if([[currentElement name] isEqualToString:@"type"]){
            
            model.type = [currentElement stringValue];
        }
        else if([[currentElement name] isEqualToString:@"temperature"]){
            
            model.temperature = [currentElement intValue];
        }
        else if([[currentElement name] isEqualToString:@"maxTemperature"]){
            
            model.maxTemperature = [currentElement intValue];
        }
        else if([[currentElement name] isEqualToString:@"minTemperature"]){
            
            model.minTemperature = [currentElement intValue];
        }
        else if([[currentElement name] isEqualToString:@"warning"]){

            NSRange range = [[currentElement stringValue] rangeOfString:@","];
            if(range.location == NSNotFound){
                model.warning = [NSArray arrayWithObjects:[currentElement stringValue], nil];
            }
            else{
                model.warning = [[currentElement stringValue] componentsSeparatedByString:@","];
            }
            
          
        }
        else if([[currentElement name] isEqualToString:@"uvRadiation"]){
            
            model.uvRadiation = [currentElement intValue];
        }
        else if([[currentElement name] isEqualToString:@"humidity"]){
            
            model.humidity = [currentElement intValue];
        }
        
    }
    [list addObject:model];
    [model release];


}

@end
