//
//  CategoryParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "CategoryParser.h"
#import "ElderlyCategoryModel.h"

@implementation CategoryParser

- (void)onParse: (GDataXMLElement*) rootElement{

    if(rootElement == nil)
        return ;
    
    NSArray* array = [rootElement elementsForName:@"item"];
    NSMutableArray* list = [[NSMutableArray alloc ] init];
   
    for(GDataXMLElement* element in array){
        
        ElderlyCategoryModel* categoryModel = [[ElderlyCategoryModel alloc] init];
        categoryModel.key = [[[element elementsForName:@"key"] objectAtIndex:0] stringValue];
        categoryModel.name = [[[element elementsForName:@"name_sc"] objectAtIndex:0] stringValue];
        categoryModel.name_tc = [[[element elementsForName:@"name_tc"] objectAtIndex:0] stringValue];
        
        [list addObject:categoryModel];
        [categoryModel release];
        

    }
    
    [result release];
    result = [list retain];
    [list release];



}

@end
