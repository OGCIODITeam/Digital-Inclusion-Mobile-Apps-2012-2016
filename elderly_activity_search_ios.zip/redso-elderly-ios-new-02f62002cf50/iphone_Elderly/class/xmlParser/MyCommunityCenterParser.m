//
//  MyCommunityCenterParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "MyCommunityCenterParser.h"
#import "ElderlyMyCommunityCentreModel.h"

@implementation MyCommunityCenterParser

- (void)onParse: (GDataXMLElement*) rootElement{

    
    NSArray* array = [[[rootElement elementsForName:@"contentTypeServiceUnitList"] objectAtIndex:0] elementsForName:@"contentTypeServiceUnit"];

    
    NSMutableArray* list = [[NSMutableArray alloc] init];
    for(GDataXMLElement* element in array){
    
        if([[element name] isEqualToString:@"contentTypeServiceUnit"]){
        
            ElderlyMyCommunityCentreModel* model = [[ElderlyMyCommunityCentreModel alloc] init];
            
            NSArray* contentTypeServiceUnitArray = [element children];
            for(GDataXMLElement* ele in contentTypeServiceUnitArray){
            
                if([[ele name] isEqualToString:@"vid"]){
                    model.vid = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"nid"]){
                    model.nid = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"fieldElderlyLocationValue"]){
                    model.locationValue_tc = [ele stringValue];
                    model.locationValue = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"latitude"]){
                    model.latitude = [[ele stringValue] floatValue];
                }
                else if([[ele name] isEqualToString:@"longitude"]){
                    model.longltude = [[ele stringValue] floatValue];
                }
                else if([[ele name] isEqualToString:@"fieldElderlyOrganizationValue"]){
                    model.organizationValue_tc = [ele stringValue];
                    model.organizationValue = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"fieldElderlyCategoriesValue"]){
                    model.categoriesValue_tc = [ele stringValue];
                    model.categoriesValue = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"fieldElderlyCentreValue"]){
                    model.centreValue_tc = [ele stringValue];
                    model.centreValue = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"fieldElderlyDistrictValue"]){
                    model.districtValue_tc = [ele stringValue];
                    model.districtValue = [ele big5ToGb];
                }
            }
            [list addObject:model];
            [model release];
        
        }
    }
    
    [result release];
    result = [list retain];
    [list release];
    
}

@end
