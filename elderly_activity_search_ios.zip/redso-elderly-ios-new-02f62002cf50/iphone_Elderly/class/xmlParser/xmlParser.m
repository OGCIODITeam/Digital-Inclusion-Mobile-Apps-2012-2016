//
//  xmlParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-7.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "XmlParser.h"
#import "ApiError.h"

@implementation XmlParser

@synthesize error;

- (void)dealloc{
    [result release];
    [error release];
    [super dealloc];
}

-(void)parse:(NSData*)data{
    
    [result release];
    result=nil;
    [error release];
    error=nil;
    
    
    if([data length]<1){
        if(error==nil)
            error=[[ApiError alloc] init];
        return;
    }
    
    NSString* xml=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
//    NSLog(@"xml >>>>> %@",xml);
    
    GDataXMLDocument *xmlDoc = [[GDataXMLDocument alloc] initWithXMLString:xml options:0 error:nil];
    
    [xml release];
    
    
    GDataXMLElement *rootElement = [xmlDoc rootElement];
    if(rootElement!=nil){
        [self onParse:rootElement];
        if(result==nil){
            if(error==nil)
                error=[[ApiError alloc] init];
            error.status=[[[rootElement elementsForName:@"status"] objectAtIndex:0] boolValue];
            error.errorMessage=[[[rootElement elementsForName:@"msg"] objectAtIndex:0] stringValue];
            
        }
        
    }
    [xmlDoc release];
    
    if(result==nil){
        if(error==nil)
            error=[[ApiError alloc] init];
    }
    
}

-(void) onParse:(GDataXMLElement *)rootElement{
    
}

-(id)getResult{
    return result;
}
-(ApiError*)getError{
    return error;
}

@end
