//
//  KeywordModelParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "KeywordModelParser.h"
#import "ElderlyKeywordModel.h"

@implementation KeywordModelParser

- (void)onParse: (GDataXMLElement*) rootElement{

    
    NSArray* array = [[[rootElement elementsForName:@"keywordList"] objectAtIndex:0] elementsForName:@"keyword"];
    if(array == nil || [array count] < 1)
        return;
    
    NSMutableArray* list = [[NSMutableArray alloc] init];
    
    for(GDataXMLElement* element in array){
    
        if([[element name] isEqualToString:@"keyword"]){
        
            ElderlyKeywordModel* keywordModel = [[ElderlyKeywordModel alloc] init];
            
            NSArray* keywordArray = [element children];
            for(GDataXMLElement* keywordElement in keywordArray){
                if([[keywordElement name] isEqualToString:@"id"]){
                    keywordModel.kId = [keywordElement stringValue];
                }
                else if([[keywordElement name] isEqualToString:@"code"]){
                    keywordModel.code_tc = [keywordElement stringValue];
                    keywordModel.code = [keywordElement big5ToGb];
                }
                else if([[keywordElement name] isEqualToString:@"seq"]){
                    keywordModel.seq = [keywordElement intValue];
                }
            }
            
            
            [list addObject:keywordModel];
            [keywordModel release];
        }
    }
    
    [result release];
    result = [list retain];
    [list release];


}

@end
