//
//  ActivityModelParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ActivityModelParser.h"
#import "ElderlyNewActivityModel.h"

@implementation ActivityModelParser

- (void)onParse: (GDataXMLElement*) rootElement{

    
    NSArray* array = [[[rootElement elementsForName:@"activityList"] objectAtIndex:0] elementsForName:@"activity"];
    
    NSString* type = [[[rootElement elementsForName:@"activityType"] objectAtIndex:0] stringValue];
    
    if(array == nil || [array count] < 1)
        return;
    
    
    NSMutableArray* list = [[NSMutableArray alloc] init];
    for(GDataXMLElement* element in array){
        
        if([[element name] isEqualToString:@"activity"]){
            
            ElderlyNewActivityModel* model = [[ElderlyNewActivityModel alloc] init];
            model.activityType = type;
            NSArray* contentTypeServiceUnitArray = [element children];
            for(GDataXMLElement* ele in contentTypeServiceUnitArray){
                
                if([[ele name] isEqualToString:@"id"]){
                    model.activityId = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"nid"]){
                    model.nid = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"title"]){
                    model.title_tc = [ele stringValue];
                    model.title = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"eventType"]){
                    model.eventType_tc = [ele stringValue];
                    model.eventType = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"date"]){
                    model.activityDateArray = [[ele stringValue] componentsSeparatedByString:@","];
                }
                else if([[ele name] isEqualToString:@"startTime"]){
                    model.stratTime = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"endTime"]){
                    model.endTime = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"activeArea"]){
                    model.activeArea_tc = [ele stringValue];
                    model.activeArea = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"memberFee"]){
                    model.menberFee_tc = [ele stringValue];
                    model.menberFee = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"nonmenberFee"]){
                    model.nonMenberFee_tc = [ele stringValue];
                    model.nonMenberFee = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"fee"]){
                    model.fee_tc = [ele stringValue];
                    model.fee = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"endDate"]){
                    model.endDate = [ele stringValue];
                }
            }
            [list addObject:model];
            [model release];
            
            
        }
        
    }
    
    
    [result release];
    result = [list retain];
    [list release];



}

@end
