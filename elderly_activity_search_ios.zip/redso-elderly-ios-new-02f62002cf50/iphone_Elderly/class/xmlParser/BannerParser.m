//
//  BannerParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-4.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "BannerParser.h"
#import "ElderlyBannerModel.h"

@implementation BannerParser


- (void)onParse: (GDataXMLElement*) rootElement{    
    NSArray* array = [[[rootElement elementsForName:@"bannerList"] objectAtIndex:0] elementsForName:@"banner"];
    NSMutableArray* list = [[NSMutableArray alloc] init];
    for(GDataXMLElement* element in array){
    
        if([[element name] isEqualToString:@"banner"]){
            
            ElderlyBannerModel* model = [[ElderlyBannerModel alloc] init];
            NSArray* bannerArray = [element children];
            for(GDataXMLElement* bannerElement in bannerArray){
                if([[bannerElement name] isEqualToString:@"id"]){
                    model.bId = [bannerElement intValue];
                }
                else if([[bannerElement name] isEqualToString:@"title"]){
                    model.title_tc = [bannerElement stringValue];
                    model.title = [bannerElement big5ToGb];
                }
                else if([[bannerElement name] isEqualToString:@"description"]){
                    model.bannerDescription_tc = [bannerElement stringValue];
                    model.bannerDescription = [bannerElement big5ToGb];
                }
                else if([[bannerElement name] isEqualToString:@"image"]){
                    model.imageUrl = [bannerElement stringValue];
                }
                else if([[bannerElement name] isEqualToString:@"type"]){
                    model.type = [bannerElement stringValue];
                }
                else if(([[bannerElement name] isEqualToString:@"link"])){
                    model.link = [bannerElement stringValue];
                }
            
            }
            [list addObject:model];
            [model release];
        }
    }
    
    [result release];
    result = [list retain];
    [list release];

}

@end
