//
//  SearchParser.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "SearchParser.h"
#import "ElderlySearchModel.h"
#import "ElderlyNewActivityModel.h"

@implementation SearchParser



- (void)onParse: (GDataXMLElement*) rootElement{


    NSArray* array = [[[rootElement elementsForName:@"activityCenterList"] objectAtIndex:0] elementsForName:@"activityCenter"];
    
    
    if(array == nil || [array count] < 1)
        return;

    NSMutableArray* list = [[NSMutableArray alloc] init];
    

    for(GDataXMLElement* element in array){
    
        if([[element name] isEqualToString:@"activityCenter"]){
            
            
            ElderlySearchModel* searchModel = [[ElderlySearchModel alloc] init];
            
            NSArray* activityCenterArray = [element children];
            for(GDataXMLElement* ele in activityCenterArray){
            
                if([[ele name] isEqualToString:@"activityCenterName"]){
                    searchModel.activityCenterName_tc = [ele stringValue];
                    searchModel.activityCenterName = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"organization"]){
                    searchModel.organization_tc = [ele stringValue];
                    searchModel.organization = [ele big5ToGb];
                }
                else if([[ele name] isEqualToString:@"nid"]){
                    searchModel.nid = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"id"]){
                    searchModel.centerId = [ele stringValue];
                }
                else if([[ele name] isEqualToString:@"longitude"]){
                    searchModel.longitude = [[ele stringValue] floatValue];
                }
                else if([[ele name] isEqualToString:@"latitude"]){
                    searchModel.latitude = [[ele stringValue] floatValue];
                }
                else if([[ele name] isEqualToString:@"activityList"]){
                    
                    NSArray* activityArray = [ele children];
                    NSMutableArray* activityList = [[NSMutableArray alloc] init];
                    for(GDataXMLElement* activityElement in activityArray){
                        
                        if([[activityElement name] isEqualToString:@"activity"]){
                            
                            ElderlyNewActivityModel* model = [[ElderlyNewActivityModel alloc] init];

                            for(GDataXMLElement* activityChildElement in [activityElement children]){
                                
                                if([[activityChildElement name] isEqualToString:@"id"]){
                                    model.activityId = [activityChildElement stringValue];
                                }
                                else if([[activityChildElement name] isEqualToString:@"nid"]){
                                    model.nid = [activityChildElement stringValue];
                                }
                                else if([[activityChildElement name] isEqualToString:@"title"]){
                                    model.title_tc = [activityChildElement stringValue];
                                    model.title = [activityChildElement big5ToGb];
                                }
                                else if([[activityChildElement name] isEqualToString:@"eventType"]){
                                    model.eventType_tc = [activityChildElement stringValue];
                                    model.eventType = [activityChildElement big5ToGb];
                                }
                                else if([[activityChildElement name] isEqualToString:@"date"]){
                                    model.activityDateArray = [[activityChildElement stringValue] componentsSeparatedByString:@","];
                                }
                                else if([[activityChildElement name] isEqualToString:@"startTime"]){
                                    model.stratTime = [activityChildElement stringValue];
                                }
                                else if([[activityChildElement name] isEqualToString:@"endTime"]){
                                    model.endTime = [activityChildElement stringValue];
                                }
                                else if([[activityChildElement name] isEqualToString:@"activeArea"]){
                                    model.activeArea_tc = [activityChildElement stringValue];
                                    model.activeArea = [activityChildElement big5ToGb];
                                }
                                else if([[activityChildElement name] isEqualToString:@"memberFee"]){
                                    model.menberFee_tc = [activityChildElement stringValue];
                                    model.menberFee = [activityChildElement big5ToGb];
                                }
                                else if([[activityChildElement name] isEqualToString:@"nonmenberFee"]){
                                    model.nonMenberFee_tc = [activityChildElement stringValue];
                                    model.nonMenberFee = [activityChildElement big5ToGb];
                                }
                                else if([[activityChildElement name] isEqualToString:@"fee"]){
                                    model.fee_tc = [activityChildElement stringValue];
                                    model.fee = [activityChildElement big5ToGb];
                                }
                                else if([[activityChildElement name] isEqualToString:@"endDate"]){
                                    model.endDate = [ele stringValue];
                                }
                            }
                            [activityList addObject:model];
                            [model release];
                        }
                        
                    }
                    searchModel.activityList = [activityList retain];
                    [activityList release];
                }
            }
        
            [list addObject:searchModel];
            [searchModel release];
        }
    
    }
    [result release];
    result = [list retain];
    [list release];
    

}


@end
