//
//  ActivityDetailModelParser.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "XmlParser.h"

@interface ActivityDetailModelParser : XmlParser

- (void)onParse: (GDataXMLElement*) rootElement;

@end
