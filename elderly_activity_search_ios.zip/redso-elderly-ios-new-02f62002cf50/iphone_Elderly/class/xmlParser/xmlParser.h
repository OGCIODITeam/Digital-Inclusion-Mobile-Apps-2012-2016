//
//  xmlParser.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-7.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GDataXMLNode+New.h"
#import "GDataXMLElement+New.h"
#import "GDataXMLNode.h"
#import "InterfaceUtils.h"

@class ApiError;

@interface XmlParser : NSObject<ParserInterface>{
    id result;
    ApiError* error;
}

@property(nonatomic,readonly)ApiError* error;
- (void)onParse: (GDataXMLElement*) rootElement;


@end

