//
//  ElderlyThemeManager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ElderlyThemeGridModel;

@interface ElderlyThemeManager : NSObject{

    NSMutableArray* themeGridList;

}


+(ElderlyThemeManager*)sharedInstance;


@property(nonatomic,assign)NSInteger gridIndex;
/*
 @return UIImage from image name  usr [UIImage imageName:];
 */
-(UIImage*) imageByTheme:(NSString*)imageName;

/*
 @return UIImage from image name  usr [UIImage imageWithContentsOfFile:];
 */
-(UIImage*)imageResourceByTheme:(NSString*)imageName;

-(UIImage*)imageByMotif:(NSString *)imageName;

-(UIImage*)imageByLangeuage:(NSString*)imageName;


-(void)openGridResource:(NSString*)file;

-(NSString*)getColorImageName;
-(ElderlyThemeGridModel*)getThemeGridModel;
-(ElderlyThemeGridModel*)getThemeGridModel:(NSInteger)index;
-(NSArray*)getAllColorImageName;


@end
