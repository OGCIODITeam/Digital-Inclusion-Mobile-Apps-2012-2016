//
//  ElderlyApiManager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyApiManager : NSObject

+(NSURL*)bannerApi:(NSString*)type;
+(NSURL*)versionApi;
+(NSURL*)keywordListApi;
+(NSString*)imageApi:(NSString*)path width:(NSInteger)width;
+(NSURL*)myCommunityCentreListApi;
+(NSURL*)weatherListApi;
+(NSURL*)activityPageListApi:(NSString*)activityType offset:(NSInteger)offset pageSize:(NSInteger)pageSize;
+(NSURL*)myFavouriteCentreApi;
+(NSURL*)activityDetailApi:(NSString*)activityType activityId:(NSString*)activityId;
+(NSURL*)searchNearListApi;
+(NSURL*)searchElderlyApi;
+(NSURL*)searchLcsdApi;
+(NSURL*)dateListApi;
+(NSURL*)tokenApi;
+(NSURL*)dateListByCoordinateApi;
+(NSURL*)easySearchListApi;
+(NSURL*)searchLcsdListByKeywordApi;
+(NSURL*)aboutUsApi;
@end
