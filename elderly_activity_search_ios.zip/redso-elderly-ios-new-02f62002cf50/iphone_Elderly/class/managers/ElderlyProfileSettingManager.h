//
//  ElderlyProfileSettingManager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-2.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ElderlyUserModel;
@interface ElderlyProfileSettingManager : NSObject


@property(nonatomic,retain)ElderlyUserModel* userModel;

-(void)savePortrait:(UIImage*)image imagePath:(NSString*)path;
-(UIImage*)readPortrait:(NSString*)path;
-(UIImage*)readPortraitBig:(NSString *)path;
-(void)deletePortraitFile:(NSString*)path;
@end
