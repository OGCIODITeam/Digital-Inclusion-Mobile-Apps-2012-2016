//
//  ElderlyCacheManager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyCacheManager.h"
#import "ElderlyPathUtils.h"
#import "WeatherParser.h"
#import "BannerParser.h"

static ElderlyCacheManager* cacheManager=nil;

@implementation ElderlyCacheManager

+(ElderlyCacheManager*)sharedInstance{
    
    if(cacheManager == nil)
        cacheManager = [[ElderlyCacheManager alloc] init];
    
    return cacheManager;
}


-(void)saveWeaterCacheData:(NSData*)data{
    [data writeToFile:[ElderlyPathUtils getWeatherCachePath] atomically:YES];
}


-(NSArray*)readWeaterCacheData{

    NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];
    NSArray* array=nil;
    
    NSData* xmlData=[[NSData alloc] initWithContentsOfFile:[ElderlyPathUtils getWeatherCachePath]];
    WeatherParser* parser=[[WeatherParser alloc] init];
    [parser parse:xmlData];
    
    [xmlData release];
    
    if(parser.error==nil){
        array=[[parser getResult] retain];
    }
    [parser release];
    [pool release];
    return [array autorelease];
}

-(void)saveMainBannerCacheData:(NSData*)data{
    [data writeToFile:[ElderlyPathUtils getMainBannerCachePath] atomically:YES];
}


-(NSArray*)readMainBannerCacheData{


    NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];
    NSArray* array=nil;

    NSData* xmlData=[[NSData alloc] initWithContentsOfFile:[ElderlyPathUtils getMainBannerCachePath]];
    BannerParser* parser=[[BannerParser alloc] init];
    [parser parse:xmlData];
    
    [xmlData release];
    
    if(parser.error==nil){
        array=[[parser getResult] retain];
    }
    [parser release];
    [pool release];
    return [array autorelease];
}

-(void)saveActivityDetailCacheData:(NSData*)data{
      [data writeToFile:[ElderlyPathUtils getNewActivityCachePath] atomically:YES];
}


-(NSArray*)readActivityDetailCacheData{

    NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];
    NSArray* array=nil;
    
    NSData* xmlData=[[NSData alloc] initWithContentsOfFile:[ElderlyPathUtils getNewActivityCachePath]];
    BannerParser* parser=[[BannerParser alloc] init];
    [parser parse:xmlData];
    
    [xmlData release];
    
    if(parser.error==nil){
        array=[[parser getResult] retain];
    }
    [parser release];
    [pool release];
    return [array autorelease];
}

-(void)saveActivityBannerCachePicture:(UIImage*)image imagePath:(NSString*)path{
    NSData* imageData = UIImagePNGRepresentation(image);
    [imageData writeToFile:path atomically:YES];
}

-(UIImage*)readActivityBannerCachePicture:(NSString*)path{

    UIImage* image = [UIImage imageWithContentsOfFile:path];
   
    return image;

}

@end
