//
//  ElderlyProfileSettingManager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-2.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyProfileSettingManager.h"
#import "ElderlyThemeManager.h"
#import "ElderlyUserModel.h"



@implementation ElderlyProfileSettingManager
@synthesize userModel;

- (id)init
{
    self = [super init];
    if (self) {
        userModel = [[ElderlyUserModel alloc] init];
        
    }
    return self;
}

- (void)dealloc
{
    self.userModel = nil;
    [super dealloc];
}






-(void)savePortrait:(UIImage*)image imagePath:(NSString*)path{
    NSData* imageData = UIImagePNGRepresentation(image);
    [imageData writeToFile:path atomically:YES];
}

-(UIImage*)readPortrait:(NSString*)path{

    UIImage* image = [UIImage imageWithContentsOfFile:path];
    if(image == nil){
        NSString* imageName = @"photo_none.png";
        if([ElderlyUtils isRetain4]){
             imageName =@"photo_none_iP5.png";
        }
        image = [[ElderlyThemeManager sharedInstance] imageByTheme:imageName];

    }
    return image;

}

-(UIImage*)readPortraitBig:(NSString *)path{

    UIImage* image = [UIImage imageWithContentsOfFile:path];
    if(image == nil){
        image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"photo_none_big.png"];
    }
    return image;
}

-(void)deletePortraitFile:(NSString*)path{

    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:path error:nil];

}

@end
