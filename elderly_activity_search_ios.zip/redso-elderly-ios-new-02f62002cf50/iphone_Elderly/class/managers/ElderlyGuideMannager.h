//
//  ElderlyGuideMannager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-21.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>


#define KEY_CONFIGURATION_FILE @"configuration"

#define inputNameGuide @"inputNameGuide"
#define inputGenderGuide @"inputGenderGuide"
#define inputAreaGuide @"inputAreaGuide"

#define inputRegionGuide @"inputRegionGuide"
#define myInterestGuide @"myInterestGuide"
#define myInterestListGuide @"myInterestListGuide"

#define myCommunityGuide @"myCommunityGuide"
#define myCommunitySelectGuide @"myCommunitySelectGuide"
#define myCommunitySelectedGuide @"myCommunitySelectedGuide"

#define myCommunityListGuide @"myCommunityListGuide"
#define latestActivitiesGuide @"latestActivitiesGuide"
#define advancedSearchGuide @"advancedSearchGuide"

#define advancedSearchSingleGuide @"advancedSearchSingleGuide"
#define profileSettingPictureGuide @"profileSettingPictureGuide"

@class ElderlyGuideModel;
@interface ElderlyGuideMannager : NSObject{

    NSMutableDictionary* dic; 
}



+(ElderlyGuideMannager*)sharedInstance;

-(void)setGudieState:(NSString*)key state:(BOOL)status;
-(void)saveGudieFile;
-(BOOL)getGudieState:(NSString*)key;

@end
