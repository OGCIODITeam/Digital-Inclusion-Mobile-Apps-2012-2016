//
//  ElderlySettingManager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-12.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlySettingManager.h"
#import "GTGZThemeManager.h"
#import "ElderlyThemeManager.h"


//#import "DateListParser.h"


#define KEY_FONTTYPE @"FONTTYPE"
#define KEY_LANGUAGETYPE @"LANGUAGETYPE"
#define KEY_COLORTYPE @"COLORTYPE"

@implementation ElderlySettingManager


-(id)init{

    self = [super init];
    if(self){
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        fontType = [defaults integerForKey:KEY_FONTTYPE];
    
        
        languageType = [defaults boolForKey:KEY_LANGUAGETYPE];
        colorType = [defaults boolForKey:KEY_COLORTYPE];
        [[GTGZThemeManager sharedInstance] openTheme:[NSString stringWithFormat:@"view_theme_%d.xml",fontType]];
        NSString* resourcePath=[[NSBundle mainBundle]  resourcePath];
        [[ElderlyThemeManager sharedInstance] openGridResource:[resourcePath stringByAppendingPathComponent:[NSString stringWithFormat:@"grid_theme_%d.xml",colorType]]];
        
//    
//        NSData* data = [NSData dataWithContentsOfFile:[resourcePath stringByAppendingPathComponent:@"123.xml"]];
//        DateListParser* xml = [[DateListParser alloc] init];
//        [xml parse:data];
        
    }
    return self;
}

-(void)dealloc{
    [super dealloc];
}


-(void)setFontType:(NSInteger)type{
    
    if(fontType == type)
        return ;
    
    fontType = type;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:fontType forKey:KEY_FONTTYPE];
    [defaults synchronize];

    [[GTGZThemeManager sharedInstance] openTheme:[NSString stringWithFormat:@"view_theme_%d.xml",type]];

    [[NSNotificationCenter defaultCenter] postNotificationName:NotificationThemeChanged object:nil];
}


-(NSInteger)getFontType{
    return fontType;
}



-(void)setlanguageType:(BOOL)type{
    
    if(languageType == type)
        return ;
    
    languageType = type;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:languageType forKey:KEY_LANGUAGETYPE];
    [defaults synchronize];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NotificationThemeChanged object:nil];
}


-(BOOL)getlanguageType{
    return languageType;
}

-(void)setColorType:(BOOL)type{

    if(colorType == type)
        return ;
    
    colorType = type;
    NSString* resourcePath=[[NSBundle mainBundle]  resourcePath];
    [[ElderlyThemeManager sharedInstance] openGridResource:[resourcePath stringByAppendingPathComponent:[NSString stringWithFormat:@"grid_theme_%d.xml",colorType]]];
    

    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:colorType forKey:KEY_COLORTYPE];
    [defaults synchronize];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NotificationThemeChanged object:nil];
}


-(BOOL)getColorType{
    return colorType;
}




@end
