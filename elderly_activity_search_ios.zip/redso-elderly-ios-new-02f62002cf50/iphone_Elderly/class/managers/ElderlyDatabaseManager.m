//
//  ElderlyDatabaseManager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyDatabaseManager.h"
#import "CategoryParser.h"
#import "AreaParser.h"
#import "ElderlyAreaModel.h"
#import "SqliteLib.h"
#import "ElderlyPathUtils.h"
#import "ElderlyMyCommunityCentreModel.h"
#import "ElderlyUserModel.h"
#import "ElderlyActivityDetailModel.h"
#import "ElderlyNewActivityModel.h"
#import "ElderlySearchModel.h"
#import "ElderlyCategoryModel.h"

@implementation ElderlyDatabaseManager



- (id)init
{
    self = [super init];
    if (self) {
        
        [self readLocation];
        [self readCategory];
        
    }
    return self;
}

-(void)checkSqliteVersion{
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    BOOL newSqlite=YES;
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    if([sqlite query:@"select dbVersion from setting"] && [sqlite next]){
        
        NSString* version=[sqlite stringValue:0];
        if(version!=nil){
            [sqlite open:[ElderlyPathUtils resourceSqlitePath]];
            [sqlite query:@"select dbVersion from setting"];
            [sqlite next];
            NSString* _nVersion=[sqlite stringValue:0];
            if([version isEqualToString:_nVersion]){
                newSqlite=NO;
            }
            [sqlite close];
        }
    }
    [sqlite release];
    if(newSqlite){
        NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];
        NSData* data=[NSData dataWithContentsOfFile:[ElderlyPathUtils resourceSqlitePath]];
        [data writeToFile:[ElderlyPathUtils localDatabasePath] atomically:YES];
        [pool release];
    }
}

-(void)updateMyCommuntiyCentre:(NSDictionary*)dic {
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    [sqlite execute:@"delete from myCommunityCentre"];
    
    NSArray* keys = [dic allKeys];
    
    for(NSString* key in keys){
    
        ElderlyMyCommunityCentreModel* model = [dic objectForKey:key];

        
        [sqlite prepare:@"insert into myCommunityCentre (id,vid,nid,locationValue,locationValue_tc,longltude,latitude,organizationValue,organizationValue_tc,categoriesValue,categoriesValue_tc,centreValue,centreValue_tc,districtValue,districtValue_tc) values(:id,:vid,:nid,:locationValue,:locationValue_tc,:longltude,:latitude,:organizationValue,:organizationValue_tc,:categoriesValue,:categoriesValue_tc,:centreValue,:centreValue_tc,:districtValue,:districtValue_tc)" ];
        
        [sqlite bind:key index:0];
        [sqlite bind:model.vid index:1];
        [sqlite bind:model.nid index:2];
        [sqlite bind:model.locationValue index:3];
        [sqlite bind:model.locationValue_tc index:4];
        [sqlite bindFloat:model.longltude index:5];
        [sqlite bindFloat:model.latitude index:6];
        [sqlite bind:model.organizationValue index:7];
        [sqlite bind:model.organizationValue_tc index:8];
        [sqlite bind:model.categoriesValue index:9];
        [sqlite bind:model.categoriesValue_tc index:10];
        [sqlite bind:model.centreValue index:11];
        [sqlite bind:model.centreValue_tc index:12];
        [sqlite bind:model.districtValue index:13];
        [sqlite bind:model.districtValue_tc index:14];
        
        [sqlite finalize];
        
    }

    [sqlite release];
    
}

-(void)getMyCommuntiyCentre:(NSMutableDictionary*)dic{

    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];

    
    if( [sqlite query:@"select * from myCommunityCentre"]){
    
        while (sqlite.next) {
            ElderlyMyCommunityCentreModel* model = [[ElderlyMyCommunityCentreModel alloc] init];
            
            NSString* key = [sqlite stringValue:0];
            model.vid = [sqlite stringValue:1];
            model.nid = [sqlite stringValue:2];
            model.locationValue = [sqlite stringValue:3];
            model.locationValue_tc = [sqlite stringValue:4];
            model.longltude = [[sqlite stringValue:5] floatValue];
            model.latitude = [[sqlite stringValue:6] floatValue];
            model.organizationValue = [sqlite stringValue:7];
            model.organizationValue_tc = [sqlite stringValue:8];
            model.categoriesValue = [sqlite stringValue:9];
            model.categoriesValue_tc = [sqlite stringValue:10];
            model.centreValue = [sqlite stringValue:11];
            model.centreValue_tc = [sqlite stringValue:12];
            model.districtValue = [sqlite stringValue:13];
            model.districtValue_tc = [sqlite stringValue:14];
            
            [dic setObject:model forKey:key];
            [model release];
        }
    }
    [sqlite release];
}

-(void)updateElderlyUser:(ElderlyUserModel*)model{

    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    [sqlite execute:@"delete from user"];
    
    [sqlite prepare:@"insert into user (userId,userName,userSex,area,region,portraitPath,portraitBigPath)values(:userId,:userName,:userSex,:area,:region,:portraitPath,:portraitBigPath)" ];
        
    [sqlite bindInt:model.uid index:0];
    [sqlite bind:model.userName index:1];
    [sqlite bind:model.gender index:2];
    [sqlite bind:model.area index:3];
    [sqlite bind:model.region index:4];
    [sqlite bind:model.portraitPath index:5];
    [sqlite bind:model.portraitBigPath index:6];
    [sqlite finalize];
    
    [sqlite release];
}

-(ElderlyUserModel*)getElderlyUser{

    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    if( [sqlite query:@"select * from user"] && [sqlite next]){
        ElderlyUserModel* model = [[[ElderlyUserModel alloc] init] autorelease];

        model.uid = [[sqlite stringValue:0] integerValue];
        model.userName = [sqlite stringValue:1];
        model.gender = [sqlite stringValue:2];
        model.area = [sqlite stringValue:3];
        model.region = [sqlite stringValue:4];
        model.portraitPath = [sqlite stringValue:5];
        model.portraitBigPath = [sqlite stringValue:6];
        
        [sqlite release];
        return model;
    }
    
    [sqlite release];

    return nil;
}





-(void)readLocation{

    if(areaArray == nil)
        areaArray = [[NSMutableArray alloc] init];
    NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    
    NSString* resourcePath=[[NSBundle mainBundle]  resourcePath];
    NSData* data = [NSData dataWithContentsOfFile:[resourcePath stringByAppendingPathComponent:@"location.xml"]];
    AreaParser* xml = [[AreaParser alloc] init];
    [xml parse:data];
    [areaArray addObjectsFromArray:[xml getResult]];
    [xml release];
     [pool release];
}

-(void)readCategory{

    if(categoryList == nil)
        categoryList = [[NSMutableArray alloc] init];

    NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    NSString* resourcePath=[[NSBundle mainBundle]  resourcePath];
    NSData* data = [NSData dataWithContentsOfFile:[resourcePath stringByAppendingPathComponent:@"activity_category.xml"]];
    CategoryParser* xml = [[CategoryParser alloc] init];
    [xml parse:data];
    [categoryList addObjectsFromArray:[xml getResult]];
    [xml release];
    
    [pool release];
}


- (void)dealloc
{
    [areaArray release];
    [categoryList release];
    [super dealloc];
}

-(NSArray*)getCategoryArray{
    return categoryList;
}

-(NSArray*)getCategoryNameArray{

    NSMutableArray* categoryArray = [[[NSMutableArray alloc] init] autorelease];
    for(ElderlyCategoryModel* categroyModel in categoryList){
        [categoryArray addObject:[ElderlyUtils text:categroyModel key:@"name"]];
    }

    return categoryArray;

}

-(NSArray*)getAreaArray{
    return areaArray;
}

-(NSArray*)getAreaNameArray{

    NSMutableArray* array = [[[NSMutableArray alloc] init] autorelease];
    for (ElderlyAreaModel* model in areaArray) {
        [array addObject:[ElderlyUtils text:model key:@"name"]];
    }
    
    return array;

}


-(NSString*)showAreaContent:(NSString*)key{

    for(ElderlyAreaModel* model in areaArray){
        if([model.name isEqualToString:key] || [model.name_tc isEqualToString:key])
            return [ElderlyUtils text:model key:@"name"];
        
        for(ElderlyAreaModel* regionModel in model.regionList){
            if([regionModel.name isEqualToString:key] || [regionModel.name_tc isEqualToString:key])
                return [ElderlyUtils text:regionModel key:@"name"];
        }
    }
    return nil;
}

-(ElderlyAreaModel*)getAreaModelForName:(NSString*)key{

    if(key == nil || key.length < 1)
        return nil;
   
    for(ElderlyAreaModel* model in areaArray){
        if([model.name isEqualToString:key] || [model.name_tc isEqualToString:key])
            return model;
        
        for(ElderlyAreaModel* regionModel in model.regionList){
            if([regionModel.name isEqualToString:key] || [regionModel.name_tc isEqualToString:key])
                return regionModel;
        }
    }
    return nil;
}

-(NSArray*)getRegionName:(NSString*)key{

    if(key == nil || key.length < 1)
        return nil;
    
    NSMutableArray* array = [[[NSMutableArray alloc] init] autorelease];
    for(ElderlyAreaModel* model in areaArray){
        if([model.name isEqualToString:key] || [model.name_tc isEqualToString:key]){
            for(ElderlyAreaModel* regionModel in model.regionList){
                 [array addObject:[ElderlyUtils text:regionModel key:@"name"]];
            }
        }
    }
    return array;

}

-(NSArray*)getAllDistrictArray{

    NSMutableArray* array = [[[NSMutableArray alloc] init] autorelease];
    for(ElderlyAreaModel* model in areaArray){
        for(ElderlyAreaModel* districtModel in model.regionList){
            [array addObject:districtModel];
        }
    }
    
    return array;
}

-(NSArray*)getAllDistrictNameArray{

    NSMutableArray* array = [[[NSMutableArray alloc] init] autorelease];
    for(ElderlyAreaModel* model in areaArray){
        for(ElderlyAreaModel* districtModel in model.regionList){
            [array addObject:[ElderlyUtils text:districtModel key:@"name"]];
        }
    }
    
    return array;

}

-(NSInteger)getEasySearchAreaDefaultIndex:(NSString*)key{
    
    NSInteger index = 0;
    
    if(key == nil || key.length < 1)
        return index;
    
    for(int i=0;i<areaArray.count;i++){
    
        ElderlyAreaModel* model = [areaArray objectAtIndex:i];
        if([model.name isEqualToString:key] || [model.name_tc isEqualToString:key]){
            index = i;
            return index;
        }
        
        for(int j=0;j<model.regionList.count;j++){
        
            ElderlyAreaModel* regionModel = [model.regionList objectAtIndex:j];
            if([regionModel.name isEqualToString:key] || [regionModel.name_tc isEqualToString:key]){
                index = j;
                return index;
            }
        }
    }
    
    return index;
}


-(BOOL)isMyActivityExisted:(NSString*) activityId activityType:(NSString*) activityType{
    
    BOOL isExisted = NO;
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    NSString *sqlStr = [NSString stringWithFormat:@"select * from activity a where a.activityId='%@' and a.activityType='%@'", activityId, activityType];
    
    if( [sqlite query:sqlStr]){
        if (sqlite.next) {
            isExisted = YES;
        }
    }
        
    [sqlite release];
    
    return isExisted;
}


-(NSArray*)findMyActivityByDate:(NSString*) date{
    NSMutableArray* array = [[[NSMutableArray alloc] init] autorelease];
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    NSString *activityType = @"E";
    
    NSString *centerSql = [NSString stringWithFormat:@"select * from activity a where a.activityType='%@' and a.date  like '%%%@%%' group by centerId", activityType, date];
    if( [sqlite query:centerSql]){
        while (sqlite.next) {
            ElderlySearchModel *searchModel = [[ElderlySearchModel alloc] init];
            searchModel.centerId = [sqlite stringValueByColumnName:@"centerId"];
            searchModel.activityCenterName = [sqlite stringValueByColumnName:@"activityCenterName"];
            searchModel.activityCenterName_tc = [sqlite stringValueByColumnName:@"activityCenterName_tc"];
            searchModel.organization = [sqlite stringValueByColumnName:@"organlization"];
            searchModel.organization_tc = [sqlite stringValueByColumnName:@"organlization_tc"];
            [array addObject:searchModel];
            [searchModel release];
        }
    }
    
    for (int i=0; i<array.count; i++) {
        ElderlySearchModel *searchModel = [array objectAtIndex:i];
        NSMutableArray *activityList = [[NSMutableArray alloc] init];
        searchModel.activityList = activityList;
        [activityList release];
        
        NSString *sqlStr = [NSString stringWithFormat:@"select * from activity a where a.activityType='%@' and a.date like '%%%@%%' and centerId='%@'", activityType, date, searchModel.centerId];
        
        if( [sqlite query:sqlStr]){
            while (sqlite.next) {
                ElderlyNewActivityModel *detail = [[ElderlyNewActivityModel alloc] init];
                
                detail.activityId = [sqlite stringValueByColumnName:@"activityId"];
                detail.nid = [sqlite stringValueByColumnName:@"nid"];
                detail.title = [sqlite stringValueByColumnName:@"title"];
                detail.title_tc = [sqlite stringValueByColumnName:@"title_tc"];
                detail.eventType = [sqlite stringValueByColumnName:@"eventType"];
                detail.eventType_tc = [sqlite stringValueByColumnName:@"eventType_tc"];
                
                NSString *dateStr = [sqlite stringValueByColumnName:@"date"];
                NSArray *dateList = [dateStr componentsSeparatedByString:@","];
                detail.activityDateArray = dateList;
                
                detail.stratTime = [sqlite stringValueByColumnName:@"startTime"];
                detail.endTime = [sqlite stringValueByColumnName:@"endTime"];
                detail.activeArea = [sqlite stringValueByColumnName:@"activeArea"];
                detail.activeArea_tc = [sqlite stringValueByColumnName:@"activeArea_tc"];
                detail.fee = [sqlite stringValueByColumnName:@"fee"];
                detail.fee_tc = [sqlite stringValueByColumnName:@"fee_tc"];
                detail.menberFee = [sqlite stringValueByColumnName:@"menberFee"];
                detail.menberFee_tc = [sqlite stringValueByColumnName:@"menberFee_tc"];
                detail.nonMenberFee = [sqlite stringValueByColumnName:@"nonMenberFee"];
                detail.nonMenberFee_tc = [sqlite stringValueByColumnName:@"nonMenberFee_tc"];
                
                detail.activityType = [sqlite stringValueByColumnName:@"activityType"];
                detail.endDate = [sqlite stringValueByColumnName:@"endDate"];
                
                [activityList addObject:detail];
                [detail release];
            }
        }
        
        
        
        
    }
    
    
    
    
    [sqlite release];
    
    return array;
}


-(NSArray*)findMyLCSDByDate:(NSString*) date{
    

    
    NSString *activityType = @"L";
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    NSMutableArray *activityList = [[[NSMutableArray alloc] init] autorelease];
    
    NSString *sqlStr = [NSString stringWithFormat:@"select * from activity a where a.activityType='%@' and strftime('%%Y%%m','%@') between strftime('%%Y%%m',a.date) and strftime('%%Y%%m',a.endDate) ", activityType, date];
    
    if( [sqlite query:sqlStr]){
        while (sqlite.next) {
            ElderlyNewActivityModel *detail = [[ElderlyNewActivityModel alloc] init];
            
            detail.activityId = [sqlite stringValueByColumnName:@"activityId"];
            detail.nid = [sqlite stringValueByColumnName:@"nid"];
            detail.title = [sqlite stringValueByColumnName:@"title"];
            detail.title_tc = [sqlite stringValueByColumnName:@"title_tc"];
            detail.eventType = [sqlite stringValueByColumnName:@"eventType"];
            detail.eventType_tc = [sqlite stringValueByColumnName:@"eventType_tc"];
            
            NSString *dateStr = [sqlite stringValueByColumnName:@"date"];
            NSArray *dateList = [dateStr componentsSeparatedByString:@","];
            detail.activityDateArray = dateList;
            
            detail.stratTime = [sqlite stringValueByColumnName:@"startTime"];
            detail.endTime = [sqlite stringValueByColumnName:@"endTime"];
            detail.activeArea = [sqlite stringValueByColumnName:@"activeArea"];
            detail.activeArea_tc = [sqlite stringValueByColumnName:@"activeArea_tc"];
            detail.fee = [sqlite stringValueByColumnName:@"fee"];
            detail.fee_tc = [sqlite stringValueByColumnName:@"fee_tc"];
            detail.menberFee = [sqlite stringValueByColumnName:@"menberFee"];
            detail.menberFee_tc = [sqlite stringValueByColumnName:@"menberFee_tc"];
            detail.nonMenberFee = [sqlite stringValueByColumnName:@"nonMenberFee"];
            detail.nonMenberFee_tc = [sqlite stringValueByColumnName:@"nonMenberFee_tc"];
            
            detail.activityType = [sqlite stringValueByColumnName:@"activityType"];
            detail.endDate = [sqlite stringValueByColumnName:@"endDate"];
            
            [activityList addObject:detail];
            [detail release];
        }
    }
    
    [sqlite release];
    
    return activityList;
    
}


-(void)saveMyActivity:(ElderlyActivityDetailModel*) detail{
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    [sqlite prepare:@"insert into activity (activityId,nid,centerId,centerNid,activityCenterName,activityCenterName_tc,title, title_tc, activityDescription, activityDescription_tc, activityDetail, activityDetail_tc, organlization, organlization_tc, categoriesValue, categoriesValue_tc, date, startTime, endTime, location, location_tc, fee, fee_tc, applicationMethod, applicationMethod_tc, activityTarget, activityTarget_tc, ageLowerLimit, ageLowerLimit_tc, eventType, eventType_tc, activeArea, activeArea_tc, remark, remark_tc, longitude, latitude, link, menberFee, nonMenberFee, menberFee_tc, nonMenberFee_tc, activityType, endDate)values(:activityId,:nid,:centerId,:centerNid,:activityCenterName,:activityCenterName_tc,:title, :title_tc, :activityDescription, :activityDescription_tc, :activityDetail, :activityDetail_tc, :organlization, :organlization_tc, :categoriesValue, :categoriesValue_tc, :date, :startTime, :endTime, :location, :location_tc, :fee, :fee_tc, :applicationMethod, :applicationMethod_tc, :activityTarget, :activityTarget_tc, :ageLowerLimit, :ageLowerLimit_tc, :eventType, :eventType_tc, :activeArea, :activeArea_tc, :remark, :remark_tc, :longitude, :latitude, :link, :menberFee, :nonMenberFee, :menberFee_tc, :nonMenberFee_tc, :activityType, :endDate)" ];
    
//    [sqlite prepare:@"insert into activity (activityId,nid,centerId,centerNid) values(:activityId,:nid,:centerId,:centerNid,:activityCenterName,:activityCenterName_tc)"];
    [sqlite bind:detail.activityId index:0];
    [sqlite bind:detail.nid index:1];
    [sqlite bind:detail.centerId index:2];
    [sqlite bind:detail.centerNid index:3];
    [sqlite bind:detail.activityCenterName index:4];
    [sqlite bind:detail.activityCenterName_tc index:5];
    [sqlite bind:detail.title index:6];
    [sqlite bind:detail.title_tc index:7];
    [sqlite bind:detail.activityDescription index:8];
    [sqlite bind:detail.activityDescription_tc index:9];
    [sqlite bind:detail.activityDetail index:10];
    [sqlite bind:detail.activityDetail_tc index:11];
    [sqlite bind:detail.organlization index:12];
    [sqlite bind:detail.organlization_tc index:13];
    [sqlite bind:detail.categoriesValue index:14];
    [sqlite bind:detail.categoriesValue_tc index:15];
    
    NSString *dateStr = [detail.dateArray componentsJoinedByString:@","];
    [sqlite bind:dateStr index:16];//date
    
    [sqlite bind:detail.startTime index:17];
    [sqlite bind:detail.endTime index:18];
    [sqlite bind:detail.location index:19];
    [sqlite bind:detail.location_tc index:20];
    [sqlite bind:detail.fee index:21];
    [sqlite bind:detail.fee_tc index:22];
    [sqlite bind:detail.applicationMethod index:23];
    [sqlite bind:detail.applicationMethod_tc index:24];
    [sqlite bind:detail.activityTarget index:25];
    [sqlite bind:detail.activityTarget_tc index:26];
    [sqlite bind:detail.ageLowerLimit index:27];
    [sqlite bind:detail.ageLowerLimit_tc index:28];
    [sqlite bind:detail.eventType index:29];
    [sqlite bind:detail.eventType_tc index:30];
    [sqlite bind:detail.activeArea index:31];
    [sqlite bind:detail.activeArea_tc index:32];
    [sqlite bind:detail.remark index:33];
    [sqlite bind:detail.remark_tc index:34];
    [sqlite bindFloat:detail.longitude index:35];
    [sqlite bindFloat:detail.latitude index:36];
    [sqlite bind:detail.link index:37];
    [sqlite bind:detail.menberFee index:38];
    [sqlite bind:detail.nonMenberFee index:39];
    [sqlite bind:detail.menberFee_tc index:40];
    [sqlite bind:detail.nonMenberFee_tc index:41];
    [sqlite bind:detail.activityType index:42];
    [sqlite bind:detail.endDate index:43];
    [sqlite finalize];
    
    
    [sqlite release];
}

-(ElderlyActivityDetailModel*)getMyActivityDetail:(NSString*) activityId activityType:(NSString*) activityType{

    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    
    NSString *sqlStr = [NSString stringWithFormat:@"select * from activity a where a.activityId='%@' and a.activityType='%@'", activityId, activityType];
    
    if( [sqlite query:sqlStr]){
        while (sqlite.next) {
            ElderlyActivityDetailModel *detail = [[[ElderlyActivityDetailModel alloc] init] autorelease];
            
            detail.activityId = [sqlite stringValueByColumnName:@"activityId"];
            detail.nid = [sqlite stringValueByColumnName:@"nid"];
            detail.centerId = [sqlite stringValueByColumnName:@"centerId"];
            detail.activityCenterName = [sqlite stringValueByColumnName:@"activityCenterName"];
            detail.activityCenterName_tc = [sqlite stringValueByColumnName:@"activityCenterName_tc"];
            detail.title = [sqlite stringValueByColumnName:@"title"];
            detail.title_tc = [sqlite stringValueByColumnName:@"title_tc"];
            detail.activityDescription = [sqlite stringValueByColumnName:@"activityDescription"];
            detail.activityDescription_tc = [sqlite stringValueByColumnName:@"activityDescription_tc"];
            detail.activityDetail = [sqlite stringValueByColumnName:@"activityDetail"];
            detail.activityDetail_tc = [sqlite stringValueByColumnName:@"activityDetail_tc"];
            detail.organlization = [sqlite stringValueByColumnName:@"organlization"];
            detail.organlization_tc = [sqlite stringValueByColumnName:@"organlization_tc"];
            detail.categoriesValue = [sqlite stringValueByColumnName:@"categoriesValue"];
            detail.categoriesValue_tc = [sqlite stringValueByColumnName:@"categoriesValue_tc"];
            NSString *dateStr = [sqlite stringValueByColumnName:@"date"];
            NSArray *dateList = [dateStr componentsSeparatedByString:@","];
            detail.dateArray = dateList;
            
            detail.startTime = [sqlite stringValueByColumnName:@"startTime"];
            detail.endTime = [sqlite stringValueByColumnName:@"endTime"];
            detail.location = [sqlite stringValueByColumnName:@"location"];
            detail.location_tc = [sqlite stringValueByColumnName:@"location_tc"];
            detail.fee = [sqlite stringValueByColumnName:@"fee"];
            detail.fee_tc = [sqlite stringValueByColumnName:@"fee_tc"];
            detail.applicationMethod = [sqlite stringValueByColumnName:@"applicationMethod"];
            detail.applicationMethod_tc = [sqlite stringValueByColumnName:@"applicationMethod_tc"];
            detail.activityTarget = [sqlite stringValueByColumnName:@"activityTarget"];
            detail.activityTarget_tc = [sqlite stringValueByColumnName:@"activityTarget_tc"];
            detail.ageLowerLimit = [sqlite stringValueByColumnName:@"ageLowerLimit"];
            detail.ageLowerLimit_tc = [sqlite stringValueByColumnName:@"ageLowerLimit_tc"];
            detail.eventType = [sqlite stringValueByColumnName:@"eventType"];
            detail.eventType_tc = [sqlite stringValueByColumnName:@"eventType_tc"];
            detail.activeArea = [sqlite stringValueByColumnName:@"activeArea"];
            detail.activeArea_tc = [sqlite stringValueByColumnName:@"activeArea_tc"];
            detail.remark = [sqlite stringValueByColumnName:@"remark"];
            detail.remark_tc = [sqlite stringValueByColumnName:@"remark_tc"];
            detail.longitude = [[sqlite stringValueByColumnName:@"longitude"] floatValue];
            detail.latitude = [[sqlite stringValueByColumnName:@"latitude"] floatValue];
            detail.link = [sqlite stringValueByColumnName:@"link"];
            detail.menberFee = [sqlite stringValueByColumnName:@"menberFee"];
            detail.menberFee_tc = [sqlite stringValueByColumnName:@"menberFee_tc"];
            detail.nonMenberFee = [sqlite stringValueByColumnName:@"nonMenberFee"];
            detail.nonMenberFee_tc = [sqlite stringValueByColumnName:@"nonMenberFee_tc"];
            detail.centerNid = [sqlite stringValueByColumnName:@"centerNid"];
            detail.activityType = [sqlite stringValueByColumnName:@"activityType"];
            detail.endDate = [sqlite stringValueByColumnName:@"endDate"];
            
            [sqlite finalize];
            
            
            [sqlite release];
            return detail;

        }
    }

    [sqlite finalize];
    
    
    [sqlite release];
    return nil;
}


-(void)deleteMyActivityById:(NSString*) activityId activityType:(NSString*) activityType{
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    NSString *sqlStr = [NSString stringWithFormat:@"delete from activity where activityId='%@' and activityType='%@'", activityId, activityType];
    
    DLog(@"sqlStr  >>>  %@", sqlStr);
    
    [sqlite execute:sqlStr];
    
    [sqlite finalize];
    [sqlite release];
}

-(void)updateMyInterest:(NSArray*)array{
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    [sqlite execute:@"delete from myInterest"];
    
    
    for(ElderlyCategoryModel* model in array){
        [sqlite prepare:@"insert into myInterest (key,name,name_tc) values(:key,:name,:name_tc)" ];
        
        [sqlite bind:model.key index:0];
        [sqlite bind:model.name index:1];
        [sqlite bind:model.name_tc index:2];
        
        [sqlite finalize];
        
    }
    [sqlite release];
    
}


-(NSArray*)getMyInterest{
    
    SqliteLib* sqlite=[[SqliteLib alloc] init];
    [sqlite open:[ElderlyPathUtils localDatabasePath]];
    
    [sqlite query:@"select * from myInterest"];
    
    NSMutableArray* list = [[[NSMutableArray alloc] init] autorelease];
    
    while (sqlite.next) {
        ElderlyCategoryModel* model = [[ElderlyCategoryModel alloc] init];
        model.key = [sqlite stringValue:0];
        model.name = [sqlite stringValue:1];
        model.name_tc = [sqlite stringValue:2];
        
        [list addObject:model];
        [model release];
    }
    
    [sqlite release];

    return list;
}


@end
