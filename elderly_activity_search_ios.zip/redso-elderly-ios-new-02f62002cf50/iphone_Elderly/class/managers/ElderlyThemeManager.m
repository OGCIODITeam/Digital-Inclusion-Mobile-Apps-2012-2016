//
//  ElderlyThemeManager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyThemeManager.h"
#import "GTGZThemeManager.h"
#import "GDataXMLNode.h"
#import "ElderlyThemeGridModel.h"

static ElderlyThemeManager* instance=nil;

@implementation ElderlyThemeManager

@synthesize gridIndex;

+(ElderlyThemeManager*)sharedInstance{
    if(instance==nil)
        instance=[[ElderlyThemeManager alloc] init];
    return instance;
}

-(id)init{
    self=[super init];
    
    [[GTGZThemeManager sharedInstance] setDefaultFontName:@"STHeitiTC-Medium"];
    
    themeGridList = [[NSMutableArray alloc] init];
    
    self.gridIndex = 0;
    
    return self;
}

-(void)dealloc{

    [themeGridList release];
    [super dealloc];
}

-(UIImage*) imageByTheme:(NSString*)imageName{
    return [[GTGZThemeManager sharedInstance] imageByTheme:imageName];
}

-(UIImage*)imageResourceByTheme:(NSString*)imageName{
    return [[GTGZThemeManager sharedInstance] imageResourceByTheme:imageName];
    
}

-(UIImage*)imageByMotif:(NSString *)imageName{

    
    if(themeGridList.count > self.gridIndex){
        ElderlyThemeGridModel* model = [themeGridList objectAtIndex:self.gridIndex];
        NSLog(@"%@",[NSString stringWithFormat:imageName,model.imageColor]);
        return [[GTGZThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:imageName,model.imageColor]];

    }
    
    return nil;
}

-(UIImage*)imageByLangeuage:(NSString*)imageName{
    
    NSString* language = @"tc";
    if([ElderlyUtils languageType]){
        language = @"sc";
    }
    return [[GTGZThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:imageName,language]];
}


-(void)openGridResource:(NSString*)file{
    [themeGridList removeAllObjects];
    
    NSString* xml=[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil];
    GDataXMLDocument *xmlDoc = [[GDataXMLDocument alloc] initWithXMLString:xml options:0 error:nil];
    GDataXMLElement *rootElement = [xmlDoc rootElement];
    NSArray *array = [rootElement elementsForName:@"Item"];
    for(GDataXMLElement* element in array){
        ElderlyThemeGridModel* model=[[ElderlyThemeGridModel alloc] init];
        model.gridId=[[[element elementsForName:@"grid"] objectAtIndex:0] intValue];
        model.image=[[[element elementsForName:@"image"] objectAtIndex:0] stringValue];
        model.header=[[[element elementsForName:@"header"] objectAtIndex:0] stringValue];
        model.color= [[[element elementsForName:@"color"] objectAtIndex:0] stringValue];
        model.arrowUp= [[[element elementsForName:@"arrowUp"] objectAtIndex:0] stringValue];
        model.arrowDown= [[[element elementsForName:@"arrowDown"] objectAtIndex:0] stringValue];
        model.imageColor = [[[element elementsForName:@"imageColor"] objectAtIndex:0] stringValue];
        [themeGridList addObject:model];
        [model release];
    }
    [xmlDoc release];
    
}


-(NSString*)getColorImageName{
    
    if(themeGridList.count > self.gridIndex){
        ElderlyThemeGridModel* model = [themeGridList objectAtIndex:self.gridIndex];
        return model.header;
    }
    return nil;
}


-(ElderlyThemeGridModel*)getThemeGridModel{
    
    ElderlyThemeGridModel* model = [themeGridList objectAtIndex:self.gridIndex];
    return model;
}

-(ElderlyThemeGridModel*)getThemeGridModel:(NSInteger)index{
    
    if(themeGridList.count > index){
        ElderlyThemeGridModel* model = [themeGridList objectAtIndex:index];
        return model;
    }
    return nil;
}


-(NSArray*)getAllColorImageName{
    
    NSMutableArray* temp = [[[NSMutableArray alloc] init] autorelease];
    for(ElderlyThemeGridModel* model in themeGridList){
    
        [temp addObject:model.image];
    }
    return temp;
}


@end
