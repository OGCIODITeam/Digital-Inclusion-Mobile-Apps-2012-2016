//
//  ElderlyCacheManager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlyCacheManager : NSObject

+(ElderlyCacheManager*)sharedInstance;

-(void)saveWeaterCacheData:(NSData*)data;
-(NSArray*)readWeaterCacheData;

-(void)saveMainBannerCacheData:(NSData*)data;
-(NSArray*)readMainBannerCacheData;

-(void)saveActivityDetailCacheData:(NSData*)data;
-(NSArray*)readActivityDetailCacheData;

-(void)saveActivityBannerCachePicture:(UIImage*)image imagePath:(NSString*)path;
-(UIImage*)readActivityBannerCachePicture:(NSString*)path;

@end
