//
//  ElderlySettingManager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-12.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ElderlySettingManager : NSObject{

    NSInteger fontType;
    BOOL languageType;
    BOOL colorType;
    
    

}



-(void)setFontType:(NSInteger)type;
-(NSInteger)getFontType;

-(void)setlanguageType:(BOOL)type;
-(BOOL)getlanguageType;

-(void)setColorType:(BOOL)type;
-(BOOL)getColorType;



@end
