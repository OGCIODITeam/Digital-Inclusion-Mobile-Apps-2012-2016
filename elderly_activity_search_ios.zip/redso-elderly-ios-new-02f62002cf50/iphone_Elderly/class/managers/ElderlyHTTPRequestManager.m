//
//  ElderlyHTTPRequestManager.m
//  iphone_Elderly
//
//  Created by fanty on 13-9-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyHTTPRequestManager.h"
#import "ElderlyApiManager.h"
#import "HTTPRequest.h"
#import "AsyncTask.h"
#import "MyCommunityCenterParser.h"
#import "BannerParser.h"
#import "VersionParser.h"
#import "KeywordModelParser.h"
#import "WeatherParser.h"
#import "ActivityModelParser.h"
#import "MyCommunityCenterParser.h"
#import "ActivityDetailModelParser.h"
#import "SearchParser.h"
#import "ElderlySearchKeyModel.h"
#import "ElderlyNewActivityModel.h"
#import "DateListParser.h"
#import "ElderlyNearBySearchKeyModel.h"


@implementation ElderlyHTTPRequestManager

-(AsyncTask*)getMyCommunityCentreList:(NSString*)district offset:(NSInteger)offset pageSize:(NSInteger)pageSize{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[MyCommunityCenterParser alloc] init] autorelease];

    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager myCommunityCentreListApi]];
    [request setPostValue:district forKey:@"district"];
    [request setPostValue:[NSString stringWithFormat:@"%d",offset] forKey:@"offset"];
    [request setPostValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
    
    task.request=request;
    [task start];
    return task;
}

//type: M(Main page),L(Latest activities),A(activity Detail)  
-(AsyncTask*)getBannerlist:(NSString*)type{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[BannerParser alloc] init] autorelease];
    HTTPRequest* request=[HTTPRequest requestWithURL:[ElderlyApiManager bannerApi:type]];

    task.request=request;
    [task start];
    return task;

}

-(AsyncTask*)checkElderlyVersion{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[VersionParser alloc] init] autorelease];
    HTTPRequest* request=[HTTPRequest requestWithURL:[ElderlyApiManager versionApi]];
    
    task.request=request;
    [task start];
    return task;
}

-(AsyncTask*)getKeywordList{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[KeywordModelParser alloc] init] autorelease];
    HTTPRequest* request=[HTTPRequest requestWithURL:[ElderlyApiManager keywordListApi]];
    
    task.request=request;
    [task start];
    return task;
}

-(AsyncTask*)getWeatherList{
    
    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[WeatherParser alloc] init] autorelease];
    HTTPRequest* request=[HTTPRequest requestWithURL:[ElderlyApiManager weatherListApi]];
    
    task.request=request;
    [task start];
    return task;
}

-(AsyncTask*)getActivityPageList:(NSString*)activityType offset:(NSInteger)offset pageSize:(NSInteger)pageSize{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[ActivityModelParser alloc] init] autorelease];
    NSLog(@"url >>>>  %@", [ElderlyApiManager activityPageListApi:activityType offset:offset pageSize:pageSize]);
    HTTPRequest* request=[HTTPRequest requestWithURL:[ElderlyApiManager activityPageListApi:activityType offset:offset pageSize:pageSize]];
    
    task.request=request;
    [task start];
    return task;
}

//-(AsyncTask*)getMyFavouriteCentre:(NSString*)activityCenterId date:(NSString*)date{
//    
//    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
//    task.parser = [[[ActivityModelParser alloc] init] autorelease];
//    
//    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager myFavouriteCentreApi]];
//    [request setPostValue:@"E" forKey:@"activityType"];
//    [request setPostValue:activityCenterId forKey:@"activityCenterId"];
//    [request setPostValue:date forKey:@"date"];
//    
//    task.request=request;
//    [task start];
//    return task;
//}

-(NSArray*)getMyFavouriteCentre:(NSString*)activityCenterId date:(NSString*)date{
    
    NSArray *activityList = nil;
    
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager myFavouriteCentreApi]];
    [request setPostValue:@"E" forKey:@"activityType"];
    [request setPostValue:activityCenterId forKey:@"activityCenterId"];
    [request setPostValue:date forKey:@"date"];
    
    DLog(@"activityType  >>>  %@", @"E");
    DLog(@"activityCenterId  >>>  %@", activityCenterId);
    DLog(@"date  >>>  %@", date);
    DLog(@"url  >>>  %@", request.url);
    [request startSynchronous];
    if (request.error==nil) {
//        NSLog(@"[request responseString]  >>>  %@", [request responseString]);
        
        ActivityModelParser *parser = [[ActivityModelParser alloc] init];
        [parser parse:[request responseData]];
        activityList = [[[parser getResult] retain] autorelease];
        [parser release];
    }
    
    
    return activityList;
}

-(AsyncTask*)getActivityDetail:(NSString*)activityType cativityId:(NSString*)cativityId{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[ActivityDetailModelParser alloc] init] autorelease];
    HTTPRequest* request=[HTTPRequest requestWithURL:[ElderlyApiManager activityDetailApi:activityType activityId:cativityId]];
    
    task.request=request;
    [task start];
    return task;

}


-(AsyncTask*)searchNearByList:(ElderlyNearBySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize;{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[SearchParser alloc] init] autorelease];
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager searchNearListApi]];
    [request setPostValue:@"E" forKey:@"activityType"];
    [request setPostValue:[NSString stringWithFormat:@"%li",model.searchDistance] forKey:@"searchDistance"];
    [request setPostValue:[NSString stringWithFormat:@"%f",model.longitude] forKey:@"longitude"];
    [request setPostValue:[NSString stringWithFormat:@"%f",model.latitude] forKey:@"latitude"];
    [request setPostValue:model.date forKey:@"date"];
    [request setPostValue:model.activeArea forKey:@"activerArea"];
    
    DLog(@"date=%@", model.date);
    DLog(@"latitude=%f", model.latitude);
    DLog(@"longitude=%f", model.longitude);
    DLog(@"searchDistance=%li", model.searchDistance);
    
    task.request=request;
    [task start];
    return task;

}

-(AsyncTask*)searchElderlyList:(ElderlySearchKeyModel*)model  offset:(NSInteger)offset pageSize:(NSInteger)pageSize{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[SearchParser alloc] init] autorelease];
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager searchElderlyApi]];
    

    
    

    [request setPostValue:model.month forKey:@"date"];

    [request setPostValue:[NSString stringWithFormat:@"%d",model.age] forKey:@"age"];
    [request setPostValue:model.fee forKey:@"fee"];
    [request setPostValue:model.eventType forKey:@"eventType"];
    [request setPostValue:model.activeArea forKey:@"activeArea"];
    [request setPostValue:model.keyword forKey:@"keyword"];
    [request setPostValue:model.organization forKey:@"organization"];
    [request setPostValue:[NSString stringWithFormat:@"%d",offset] forKey:@"offset"];
    [request setPostValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
    
    DLog(@"date=%@", model.month);
    DLog(@"age=%d", model.age);
    DLog(@"fee=%@", model.fee);
    DLog(@"eventType=%@", model.eventType);
    DLog(@"activeArea=%@", model.activeArea);
    DLog(@"keyword=%@", model.keyword);
    DLog(@"organization=%@", model.organization);
    
//    
//    [request startSynchronous];
//    NSLog(@"xml >>>  %@", [request responseString]);
    task.request=request;
    [task start];
    return task;
}

-(AsyncTask*)searchLcsdList:(ElderlySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[ActivityModelParser alloc] init] autorelease];
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager searchLcsdApi]];
    

    [request setPostValue:model.month forKey:@"date"];
    [request setPostValue:[NSString stringWithFormat:@"%d",model.age] forKey:@"age"];
    [request setPostValue:model.fee forKey:@"fee"];
    [request setPostValue:model.eventType forKey:@"eventType"];
    [request setPostValue:model.activeArea forKey:@"activeArea"];
    [request setPostValue:model.keyword forKey:@"keyword"];
    [request setPostValue:model.organization forKey:@"organization"];
    [request setPostValue:[NSString stringWithFormat:@"%d",offset] forKey:@"offset"];
    [request setPostValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
    
    
    DLog(@"date=%@", model.month);
    DLog(@"age=%d", model.age);
    DLog(@"fee=%@", model.fee);
    DLog(@"eventType=%@", model.eventType);
    DLog(@"activeArea=%@", model.activeArea);
    DLog(@"keyword=%@", model.keyword);
    DLog(@"organization=%@", model.organization);
    DLog(@"offset=%d", offset);
    DLog(@"pageSize=%d", pageSize);
    
 
    task.request=request;
    [task start];
    return task;

}


-(AsyncTask*)getDateList:(ElderlySearchKeyModel*)model activityType:(NSString*) activityType{
    
    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[DateListParser alloc] init] autorelease];
    
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager dateListApi]];
    

    [request setPostValue:model.month forKey:@"date"];
    [request setPostValue:[NSString stringWithFormat:@"%d",model.age] forKey:@"age"];
    [request setPostValue:model.fee forKey:@"fee"];
    [request setPostValue:model.eventType forKey:@"eventType"];
    [request setPostValue:model.activeArea forKey:@"activeArea"];  
    [request setPostValue:model.keyword forKey:@"keyword"];
    [request setPostValue:model.organization forKey:@"organization"];
    [request setPostValue:activityType forKey:@"activityType"];
    
    

    
    DLog(@"date=%@", model.month);
    DLog(@"age=%d", model.age);
    DLog(@"fee=%@", model.fee);
    DLog(@"eventType=%@", model.eventType);
    DLog(@"activeArea=%@", model.activeArea);
    DLog(@"keyword=%@", model.keyword);
    DLog(@"organization=%@", model.organization);
    DLog(@"activityType=%@", activityType);
    
    task.request=request;
    [task start];
    return task;

}

-(AsyncTask*)postToken:(NSString*)token{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[XmlParser alloc] init] autorelease];
    
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager tokenApi]];
    
    [request setPostValue:@"ios" forKey:@"platform"];
    [request setPostValue:token forKey:@"token"];
    
    DLog(@"platform=%@", @"ios");
    DLog(@"token=%@", token);

    
    task.request=request;
    [task start];
    return task;

}

-(AsyncTask*)getDateListByCoordinate:(ElderlyNearBySearchKeyModel*)model{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[DateListParser alloc] init] autorelease];
    
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager dateListByCoordinateApi]];
    
    
    [request setPostValue:model.date forKey:@"date"];
//    [request setPostValue:@"E" forKey:@"activityType"];
    [request setPostValue:[NSString stringWithFormat:@"%li",model.searchDistance] forKey:@"searchDistance"];
    [request setPostValue:[NSString stringWithFormat:@"%f",model.longitude] forKey:@"longitude"];
    [request setPostValue:[NSString stringWithFormat:@"%f",model.latitude] forKey:@"latitude"];
    
    
    
    DLog(@"date=%@", model.date);
    DLog(@"latitude=%f", model.latitude);
    DLog(@"longitude=%f", model.longitude);
    DLog(@"searchDistance=%li", model.searchDistance);

    
    task.request=request;
    [task start];
    return task;
}

-(AsyncTask*)easySearchList:(ElderlySearchKeyModel*)model activityType:(NSString*) activityType offset:(NSInteger)offset pageSize:(NSInteger)pageSize{

    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    if([activityType isEqualToString:@"E"]){
        task.parser = [[[SearchParser alloc] init] autorelease];
    }
    else{
        task.parser = [[[ActivityModelParser alloc] init] autorelease];
    }
       FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager easySearchListApi]];
    
    [request setPostValue:activityType forKey:@"activityType"];
    [request setPostValue:model.month forKey:@"date"];
    [request setPostValue:model.eventType forKey:@"eventType"];
    [request setPostValue:model.activeArea forKey:@"activeArea"];
    [request setPostValue:[NSString stringWithFormat:@"%d",offset] forKey:@"offset"];
    [request setPostValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
    
    DLog(@"date=%@", model.month);
    DLog(@"eventType=%@", model.eventType);
    DLog(@"activeArea=%@", model.activeArea);
    
    //
    //    [request startSynchronous];
    //    NSLog(@"xml >>>  %@", [request responseString]);
    task.request=request;
    [task start];
    return task;

}

-(AsyncTask*)searchLcsdListByKeyword:(ElderlySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize{
    
    AsyncTask* task = [[[AsyncTask alloc] init] autorelease];
    task.parser = [[[ActivityModelParser alloc] init] autorelease];
    FormDataRequest* request=[FormDataRequest requestWithURL:[ElderlyApiManager searchLcsdListByKeywordApi]];
    
    [request setPostValue:model.month forKey:@"date"];
    [request setPostValue:model.keyword forKey:@"keyword"];
    [request setPostValue:[NSString stringWithFormat:@"%d",offset] forKey:@"offset"];
    [request setPostValue:[NSString stringWithFormat:@"%d",pageSize] forKey:@"pageSize"];
    
    DLog(@"date=%@", model.month);
    DLog(@"keyword=%@", model.keyword);
    
    //
    //    [request startSynchronous];
    //    NSLog(@"xml >>>  %@", [request responseString]);
    task.request=request;
    [task start];
    return task;
}

@end
