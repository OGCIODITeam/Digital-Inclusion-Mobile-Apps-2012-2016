//
//  ElderlyApiManager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-5.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyApiManager.h"

@implementation ElderlyApiManager

//UAT
//#define DOMAIN_HOST @"http://cn.gtomato.com:10080/elderly"

//PRO
#define DOMAIN_HOST @"http://www.e123.hk/elderly"


//#define DOMAIN_HOST @"http://192.168.1.97:8080/elderly"


+(NSURL*)bannerApi:(NSString*)type{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/bannerList.do?type=%@",DOMAIN_HOST,type]];
}

+(NSURL*)versionApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/checkVersion.do?type=I",DOMAIN_HOST]];
}

+(NSURL*)keywordListApi{

    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/keywordList.do",DOMAIN_HOST]];
}

+(NSString*)imageApi:(NSString*)path width:(NSInteger)width{

    return [NSString stringWithFormat:@"%@/api/image.do?path=%@&width=%d",DOMAIN_HOST,path,width];
}

+(NSURL*)myCommunityCentreListApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/myCommunityCentreList.do",DOMAIN_HOST]];
}

+(NSURL*)weatherListApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/weatherList.do",DOMAIN_HOST]];
}

+(NSURL*)activityPageListApi:(NSString*)activityType offset:(NSInteger)offset pageSize:(NSInteger)pageSize{
      return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/activityPageList.do?activityType=%@&offset=%d&pageSize=%d",DOMAIN_HOST,activityType,offset,pageSize]];
}

+(NSURL*)myFavouriteCentreApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/myFavouriteCentre.do",DOMAIN_HOST]];
}


+(NSURL*)activityDetailApi:(NSString*)activityType activityId:(NSString*)activityId{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/activityDetail.do?activityType=%@&id=%@",DOMAIN_HOST,activityType,activityId]];
}

+(NSURL*)searchNearListApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/searchNearbyList.do",DOMAIN_HOST]];

}

+(NSURL*)searchElderlyApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/searchElderlyList.do",DOMAIN_HOST]];
}

+(NSURL*)searchLcsdApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/searchLcsdList.do",DOMAIN_HOST]];
}

+(NSURL*)dateListApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/dateList.do",DOMAIN_HOST]];
}

+(NSURL*)tokenApi{

    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/getToken.do",DOMAIN_HOST]];
}

+(NSURL*)dateListByCoordinateApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/dateListByCoordinate.do",DOMAIN_HOST]];
}

+(NSURL*)easySearchListApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/easySearchList.do",DOMAIN_HOST]];
}

+(NSURL*)searchLcsdListByKeywordApi{
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/api/searchLcsdListByKeword.do",DOMAIN_HOST]];
}

+(NSURL*)aboutUsApi{

    NSString* language = @"tc";
    if([ElderlyUtils languageType]){
        language = @"sc";
    }
    return [NSURL URLWithString:[NSString stringWithFormat:@"%@/about/about_%@.html",DOMAIN_HOST,language]];
    
}



@end
