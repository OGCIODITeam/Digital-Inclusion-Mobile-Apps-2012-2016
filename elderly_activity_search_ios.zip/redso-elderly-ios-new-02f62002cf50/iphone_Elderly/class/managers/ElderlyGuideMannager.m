//
//  ElderlyGuideMannager.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-21.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyGuideMannager.h"
#import "GDataXMLNode.h"


#define Guide_Value @"1"

@implementation ElderlyGuideMannager

static ElderlyGuideMannager* instance = nil;


+(ElderlyGuideMannager*)sharedInstance{

    if(instance==nil)
        instance=[[ElderlyGuideMannager alloc] init];
    return instance;
    
}


-(id)init{
    self=[super init];
    
    dic = [[NSMutableDictionary alloc] init];
    [self openGuideResource];
    return self;
}

-(void)dealloc{
    
    [dic release];
    [super dealloc];
}


-(void)openGuideResource{


    NSString* xml=[NSString stringWithContentsOfFile:[self getGuidePath] encoding:NSUTF8StringEncoding error:nil];
    
    if(xml == nil){
    

        
        [dic setValue:Guide_Value forKey:inputNameGuide];
        [dic setValue:Guide_Value forKey:inputGenderGuide];
        [dic setValue:Guide_Value forKey:inputAreaGuide];
        [dic setValue:Guide_Value forKey:inputRegionGuide];
        [dic setValue:Guide_Value forKey:myInterestGuide];
        [dic setValue:Guide_Value forKey:myInterestListGuide];
        [dic setValue:Guide_Value forKey:myCommunityGuide];
        [dic setValue:Guide_Value forKey:myCommunitySelectGuide];
        [dic setValue:Guide_Value forKey:myCommunitySelectedGuide];
        [dic setValue:Guide_Value forKey:myCommunityListGuide];
        [dic setValue:Guide_Value forKey:latestActivitiesGuide];
        [dic setValue:Guide_Value forKey:advancedSearchGuide];
        [dic setValue:Guide_Value forKey:advancedSearchSingleGuide];
        [dic setValue:Guide_Value forKey:profileSettingPictureGuide];

        return ;
    }
    
    GDataXMLDocument *xmlDoc = [[GDataXMLDocument alloc] initWithXMLString:xml options:0 error:nil];
    GDataXMLElement *rootElement = [xmlDoc rootElement];
    NSArray *array = [rootElement children];

    for(GDataXMLElement* element in array){
        
        
        if([[element name] isEqualToString:inputNameGuide]){
            [dic setValue:[element stringValue] forKey:inputNameGuide];

        }
        else if([[element name] isEqualToString:inputGenderGuide]){
            [dic setValue:[element stringValue] forKey:inputGenderGuide];
            
        }
        else if([[element name] isEqualToString:inputAreaGuide]){
            [dic setValue:[element stringValue] forKey:inputAreaGuide];
            
        }
        else if([[element name] isEqualToString:inputRegionGuide]){
            [dic setValue:[element stringValue] forKey:inputRegionGuide];
            
        }
        else if([[element name] isEqualToString:myInterestGuide]){
            [dic setValue:[element stringValue] forKey:myInterestGuide];
            
        }
        else if([[element name] isEqualToString:myInterestListGuide]){
            [dic setValue:[element stringValue] forKey:myInterestListGuide];
            
        }
        else if([[element name] isEqualToString:myCommunityGuide]){
            [dic setValue:[element stringValue] forKey:myCommunityGuide];
            
        }
        else if([[element name] isEqualToString:myCommunitySelectGuide]){
            [dic setValue:[element stringValue] forKey:myCommunitySelectGuide];
            
        }
        else if([[element name] isEqualToString:myCommunitySelectedGuide]){
            [dic setValue:[element stringValue] forKey:myCommunitySelectedGuide];
            
        }
        else if([[element name] isEqualToString:myCommunityListGuide]){
            [dic setValue:[element stringValue] forKey:myCommunityListGuide];
            
        }
        else if([[element name] isEqualToString:latestActivitiesGuide]){
            [dic setValue:[element stringValue] forKey:latestActivitiesGuide];
            
        }
        else if([[element name] isEqualToString:advancedSearchGuide]){
            [dic setValue:[element stringValue] forKey:advancedSearchGuide];
            
        }
        else if([[element name] isEqualToString:advancedSearchSingleGuide]){
            [dic setValue:[element stringValue] forKey:advancedSearchSingleGuide];
            
        }
        else if([[element name] isEqualToString:profileSettingPictureGuide]){
            [dic setValue:[element stringValue] forKey:profileSettingPictureGuide];
        }
    }
    [xmlDoc release];
    
}


-(void)saveGudieFile{

    NSArray* array = [dic allKeys];
    
    GDataXMLElement *rootElement = [GDataXMLNode elementWithName:@"Elderly"];
    
    for(int i=0; i<array.count;i++){
    
        NSString* key = [array objectAtIndex:i];
        NSString* value = [dic valueForKey:key];
        
        GDataXMLElement *element = [GDataXMLNode elementWithName:key stringValue:value];
        [rootElement addChild:element];
    }
    
    GDataXMLDocument *document = [[GDataXMLDocument alloc] initWithRootElement:rootElement];
    NSData *data =  [document XMLData];
   
      
    [data writeToFile:[self getGuidePath] atomically:YES];

    [document release];
}

-(NSString*)getGuidePath{

    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [path objectAtIndex:0];
    //获取文件管理器
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //指定新建文件夹路径
    NSString *imageDocPath = [documentPath stringByAppendingPathComponent:KEY_CONFIGURATION_FILE];
    //创建ImageFile文件夹
    [fileManager createDirectoryAtPath:imageDocPath withIntermediateDirectories:YES attributes:nil error:nil];
    //返回保存图片的路径（图片保存在ImageFile文件夹下）
    NSString * imagePath = [imageDocPath stringByAppendingPathComponent:@"guide.xml"];

    return imagePath;
}


-(BOOL)getGudieState:(NSString*)key{
   return [[dic valueForKey:key] boolValue];
}

-(void)setGudieState:(NSString*)key state:(BOOL)status{

    [dic setValue:[NSString stringWithFormat:@"%d",status] forKey:key];
}

@end
