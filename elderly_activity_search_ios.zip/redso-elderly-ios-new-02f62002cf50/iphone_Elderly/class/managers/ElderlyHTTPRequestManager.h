//
//  ElderlyHTTPRequestManager.h
//  iphone_Elderly
//
//  Created by fanty on 13-9-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>
@class AsyncTask;
@class ElderlySearchKeyModel;
@class ElderlyNearBySearchKeyModel;
@interface ElderlyHTTPRequestManager : NSObject

-(AsyncTask*)getMyCommunityCentreList:(NSString*)district offset:(NSInteger)offset pageSize:(NSInteger)pageSize;


//type: M(Main page),L(Latest activities),A(activity Detail) 
-(AsyncTask*)getBannerlist:(NSString*)type;

-(AsyncTask*)checkElderlyVersion;

-(AsyncTask*)getKeywordList;

-(AsyncTask*)getWeatherList;

//activityType:L(康文屬)，E(長者活動中心)
-(AsyncTask*)getActivityPageList:(NSString*)activityType offset:(NSInteger)offset pageSize:(NSInteger)pageSize;

//date(2013-09-05)
//-(AsyncTask*)getMyFavouriteCentre:(NSString*)activityCenterId date:(NSString*)date;
-(NSArray*)getMyFavouriteCentre:(NSString*)activityCenterId date:(NSString*)date;

//activityType:L(康文屬)，E(長者活動中心)
-(AsyncTask*)getActivityDetail:(NSString*)activityType cativityId:(NSString*)cativityId;

-(AsyncTask*)searchNearByList:(ElderlyNearBySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize;

-(AsyncTask*)searchElderlyList:(ElderlySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize;

-(AsyncTask*)searchLcsdList:(ElderlySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize;

-(AsyncTask*)getDateList:(ElderlySearchKeyModel*)model activityType:(NSString*) activityType;

-(AsyncTask*)postToken:(NSString*)token;

-(AsyncTask*)getDateListByCoordinate:(ElderlyNearBySearchKeyModel*)model;

-(AsyncTask*)easySearchList:(ElderlySearchKeyModel*)model activityType:(NSString*) activityType offset:(NSInteger)offset pageSize:(NSInteger)pageSize;

-(AsyncTask*)searchLcsdListByKeyword:(ElderlySearchKeyModel*)model offset:(NSInteger)offset pageSize:(NSInteger)pageSize;

@end
