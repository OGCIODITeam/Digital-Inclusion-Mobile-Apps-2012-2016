//
//  ElderlyDatabaseManager.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ElderlyUserModel;
@class ElderlyActivityDetailModel;
@class ElderlyAreaModel;
@interface ElderlyDatabaseManager : NSObject{

    NSMutableArray* areaArray;
    NSMutableArray* categoryList;
}


-(void)checkSqliteVersion;
-(void)updateMyCommuntiyCentre:(NSDictionary*)dic;
-(void)getMyCommuntiyCentre:(NSMutableDictionary*)dic;

-(void)updateElderlyUser:(ElderlyUserModel*)model;
-(ElderlyUserModel*)getElderlyUser;

-(NSArray*)getCategoryArray;
-(NSArray*)getCategoryNameArray;

-(NSString*)showAreaContent:(NSString*)key;

-(NSArray*)getAreaArray;
-(NSArray*)getAreaNameArray;


-(ElderlyAreaModel*)getAreaModelForName:(NSString*)key;
-(NSArray*)getRegionName:(NSString*)key;
-(NSInteger)getEasySearchAreaDefaultIndex:(NSString*)key;

-(NSArray*)getAllDistrictArray;
-(NSArray*)getAllDistrictNameArray;

-(BOOL)isMyActivityExisted:(NSString*) activityId activityType:(NSString*) activityType;
-(NSArray*)findMyActivityByDate:(NSString*) date;
-(NSArray*)findMyLCSDByDate:(NSString*) date;
-(void)saveMyActivity:(ElderlyActivityDetailModel*) detail;
-(ElderlyActivityDetailModel*)getMyActivityDetail:(NSString*) activityId activityType:(NSString*) activityType;
-(void)deleteMyActivityById:(NSString*) activityId activityType:(NSString*) activityType;

-(void)updateMyInterest:(NSArray*)array;
-(NSArray*)getMyInterest;

@end
