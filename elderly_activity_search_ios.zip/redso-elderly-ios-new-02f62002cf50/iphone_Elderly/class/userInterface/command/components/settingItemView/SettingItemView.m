//
//  SettingItemView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-12.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "SettingItemView.h"
#import "ElderlyThemeManager.h"
#import "ButtonText.h"

@implementation SettingItemView

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        
        buttonArray = [[NSMutableArray alloc] init];
        
        self.clipsToBounds = YES;
        
        UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"item_setting.png"];
        UIImageView* bgView = [[UIImageView alloc] initWithFrame:CGRectMake((self.bounds.size.width - img.size.width)*0.5f, 0, img.size.width, img.size.height)];
        bgView.image = img;
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 15, img.size.width , 25)];
        [titleLabel theme:@"setting_item_Title"];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        [bgView addSubview:titleLabel];
        [titleLabel release];
        
        
        
        [self addSubview:bgView];
        [bgView release];
        
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


-(void)dealloc{

    [buttonArray release];
    [super dealloc];
}

-(void)setTitle:(NSString*)title{

    titleLabel.text = title;
    [titleLabel theme:@"setting_item_Title"];

}


-(void)setButtonViewTitle:(NSArray*)array selectIndex:(NSInteger)index{
    
    
    
    for(ButtonText* itemButton in buttonArray){
        [itemButton removeFromSuperview];
    }

    [buttonArray removeAllObjects];
    
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_language.png"];
    UIImage* selectImg = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_language_on.png"];
    UIImage* sureImage = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_setting_sure.png"];
    float space = 12;
    float orginX = (self.bounds.size.width - img.size.width*array.count -12)*0.5;
    
    if(array.count >2){
        img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_size.png"];
        selectImg = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_size_on.png"];
        space = 15;
        orginX = (self.bounds.size.width - img.size.width*array.count -30)*0.5f;
    }
   
    for(int i=0; i<array.count;i++){

        ButtonText* button = [[ButtonText alloc] initWithFrame:CGRectMake(orginX, 55, img.size.width, img.size.height)];
//        [button setTitle:[array objectAtIndex:i] forState:UIControlStateNormal];
        button.spacing = 5.0f;
        button.alignment = UITextAlignmentCenter;
        [button text:[array objectAtIndex:i]];
        [button arrow:sureImage];
        [button setBackgroundImage:img forState:UIControlStateNormal];
        [button setBackgroundImage:selectImg forState:UIControlStateSelected];
        button.isSelectedButton = (i == index?NO:YES);
        [button textHighlight:(i == index)];
        button.selected = (i == index);
        button.tag = i;
        [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        
        [buttonArray addObject:button];
        
        [button release];
        orginX = CGRectGetMaxX(button.frame)+space;
            
    }
    
}

-(void)clickButton:(id)sender{
    
    UIButton* button = (UIButton*)sender;

    if(self.delegate != nil){
        [self.delegate didSelectSettingItemView:self selectIndex:button.tag];
    }
}

-(void)selectButton:(NSInteger)selectedIndex{

    if(selectedIndex < buttonArray.count){
        
        for(ButtonText* itemButton in buttonArray){
            itemButton.selected = (itemButton.tag == selectedIndex);
            [itemButton textHighlight:(itemButton.tag == selectedIndex)];
            itemButton.isSelectedButton = (itemButton.tag == selectedIndex?NO:YES);
           

        }
    }


}

-(void)setButtonViewTitleTheme:(NSArray*)array{

    for(int i=0;i<array.count;i++){
    
        ButtonText* itemButton = [buttonArray objectAtIndex:i];
        [itemButton theme:[array objectAtIndex:i]];
        
    }

}

@end
