//
//  SettingItemView.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-12.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SettingItemView;

@protocol SettingItemViewDelegate <NSObject>

@optional

-(void)didSelectSettingItemView:(SettingItemView*)itemView selectIndex:(NSInteger)index;

@end


@interface SettingItemView : UIView{

    UILabel* titleLabel;
    
    NSMutableArray* buttonArray;

}

@property(nonatomic,assign)id<SettingItemViewDelegate> delegate;

-(void)setTitle:(NSString*)title;
-(void)setButtonViewTitle:(NSArray*)array selectIndex:(NSInteger)index;
-(void)setButtonViewTitleTheme:(NSArray*)array;
-(void)selectButton:(NSInteger)selectedIndex;

@end
