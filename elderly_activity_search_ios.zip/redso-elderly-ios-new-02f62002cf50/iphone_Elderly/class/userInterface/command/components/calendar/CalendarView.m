//
//  CalendarView.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 7/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "CalendarView.h"



@implementation CalendarButton;

@synthesize date;

- (void)dealloc
{
    self.date = nil;
    [super dealloc];
}

@end

@interface CalendarView()


@property (retain, nonatomic) UIView *bodyView;
@property (retain, nonatomic) UIView *dateHolder;
@property (retain, nonatomic) NSDate *currentDate;
@property (retain, nonatomic) UIImage *bgGirdImage;
@property (retain, nonatomic) UIImage *todayGirdImage;
@property (retain, nonatomic) UILabel *monthLabel;
@property (assign, nonatomic) BOOL *isChangingMonth;

@property (retain, nonatomic) UIButton *topLeftButton;
@property (retain, nonatomic) UIButton *topRightButton;

@end

@implementation CalendarView
@synthesize bodyView;
@synthesize dateHolder;
@synthesize currentDate;
@synthesize bgGirdImage;
@synthesize todayGirdImage;
@synthesize monthLabel;
@synthesize isChangingMonth;
@synthesize topLeftButton;
@synthesize topRightButton;

@synthesize delegate;

- (void)dealloc
{
    self.bodyView = nil;
    self.dateHolder = nil;
    self.currentDate = nil;
    self.bgGirdImage = nil;
    self.todayGirdImage = nil;
    self.monthLabel = nil;
    self.topLeftButton = nil;
    self.topRightButton = nil;
    self.delegate = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame andDate:(NSDate*) date
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.currentDate = date;
        
        
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.9];
//        self.alpha = 0.8;
        
        UIButton *mBgButton = [UIButton buttonWithType:UIButtonTypeCustom];
        CGRect bgButtonFrame = self.frame;
        bgButtonFrame.origin = CGPointZero;
        mBgButton.frame = bgButtonFrame;
        [mBgButton addTarget:self action:@selector(onBgButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:mBgButton];
        
        
        
        
        float bodyWidth = self.frame.size.width - 40;
        float gridWidth = bodyWidth/7;
        CGRect bodyFrame = CGRectMake(0, 0, bodyWidth, bodyWidth + gridWidth);
        UIView *calendarBody = [[UIView alloc] initWithFrame:bodyFrame];
        calendarBody.clipsToBounds = YES;
//        calendarBody.backgroundColor = [UIColor blackColor];
//        [calendarBody theme:@"calendar_body_bg"];
        
        calendarBody.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 20);
        [self addSubview:calendarBody];
        self.bodyView = calendarBody;
        [calendarBody release];
        
        
        
        [self initHeader];
        [self initWeeklyHeader];
        
        UIColor *color = [ElderlyUtils colorConvertFromString:@"#b3b3b3"];
        self.bgGirdImage = [self createBgGirdImage:color];
        color = [ElderlyUtils colorConvertFromString:@"#ffffff"];
        self.todayGirdImage = [self createBgGirdImage:color];
        
        [self initGridHolder];
        [calendarBody addSubview:self.dateHolder];
        
        [self initGrids];
        
    }
    return self;
}

- (void)initGridHolder{
    float gridWidth = self.bodyView.frame.size.width/7;
    CGRect gridHolderFrame = CGRectMake(0, gridWidth*2, self.bodyView.frame.size.width, gridWidth*6);
    
    UIView *gridHolder = [[UIView alloc] initWithFrame:gridHolderFrame];
    
    
    
    
//    CGRect gridHolderFrame = gridHolder.frame;
//    gridHolderFrame.origin.y += gridWidth*2;
//    gridHolderFrame.size.height -= gridWidth*2;
//    gridHolder.frame = gridHolderFrame;
    self.dateHolder = gridHolder;
    [gridHolder release];
}

- (void)initHeader{
    
    UIView *calendarBody = self.bodyView;
    
    UIImage *leftImage = [UIImage imageNamed:@"btn_calendar_left.png"];
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setImage:leftImage forState:UIControlStateNormal];
    leftButton.frame = CGRectMake(0, 0, leftImage.size.width, leftImage.size.height);
    [leftButton addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    self.topLeftButton = leftButton;
    [leftButton setAccessibilityLabel:lang(@"onMonth")];
    
    
    UIImage *rightImage = [UIImage imageNamed:@"btn_calendar_right.png"];
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:rightImage forState:UIControlStateNormal];
    rightButton.frame = CGRectMake(calendarBody.frame.size.width - rightImage.size.width, 0, rightImage.size.width, rightImage.size.height);
    [rightButton addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    self.topRightButton = rightButton;
    [rightButton setAccessibilityLabel:lang(@"nextMonth")];
    
    
    UIImage *bgImage = [UIImage imageNamed:@"calendar_header.png"];
    bgImage = [bgImage stretchableImageWithLeftCapWidth:bgImage.size.width/2 topCapHeight:bgImage.size.height/2];
    CGRect bgRect = CGRectMake(leftButton.frame.size.width, 0, rightButton.frame.origin.x - leftButton.frame.size.width, bgImage.size.height);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:bgRect];
    imageView.image = bgImage;
    
    
    UILabel *tmpMonthLabel = [[UILabel alloc] initWithFrame:bgRect];
    tmpMonthLabel.backgroundColor = [UIColor clearColor];
    tmpMonthLabel.textAlignment = NSTextAlignmentCenter;
    [tmpMonthLabel theme:@"date_Label"];
    self.monthLabel = tmpMonthLabel;
    
    [self setMonthLabelText];
    
    
    
    [calendarBody addSubview:imageView];
    [calendarBody addSubview:leftButton];
    [calendarBody addSubview:rightButton];
    [calendarBody addSubview:monthLabel];
    
    [imageView release];
    [tmpMonthLabel release];
}

- (void)setMonthLabelText{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = lang(@"dateFormat2");
    NSString *str = [dateFormatter stringFromDate:self.currentDate];
    self.monthLabel.text = str;
    [dateFormatter release];
}

- (void)initWeeklyHeader{
    
    float gridWidth = self.bodyView.frame.size.width/7;
    CGRect gridFrame = CGRectMake(0, gridWidth, gridWidth, gridWidth);
    for (int i=0; i<7; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:gridFrame];
        [label theme:@"calendar_date_header_label"];
        label.textAlignment = NSTextAlignmentCenter;
        NSString *langStr = [NSString stringWithFormat:@"dateHeader%d",i];
        label.text = lang(langStr);
        [self.bodyView addSubview:label];
        
        CGRect labelFrame = label.frame;
        labelFrame.origin.x += 1;
        labelFrame.origin.y += 1;
        labelFrame.size.width -= 2;
        labelFrame.size.height -= 2;
        label.frame = labelFrame;
        [label release];
        
        
        gridFrame.origin.x += gridFrame.size.width;
    }
}

- (void)initGrids{
    float gridWidth = self.bodyView.frame.size.width/7;
    float gridY = 0;
    
    unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *comp = [cal components:units fromDate:self.currentDate];
    [comp setDay:01];
    
    
    NSDate *startDate = [cal dateFromComponents:comp];
    comp = [cal components:units fromDate:startDate];
    
    if (comp.weekday>1) {
        CGRect blankFrame = CGRectMake(1, gridY + 1, (comp.weekday-1)*gridWidth - 2, gridWidth - 2);
        UIView *blankView = [[UIView alloc] initWithFrame:blankFrame];
        [blankView theme:@"calendar_body_bg"];
        [self.dateHolder addSubview:blankView];
        [blankView release];
    }
    
    NSDateComponents *currentComp = [cal components:units fromDate:self.currentDate];
    NSDateComponents *todayComp = [cal components:units fromDate:[NSDate date]];

    while (comp.month == currentComp.month) {
        CGRect gridFrame = CGRectMake((comp.weekday-1)*gridWidth + 1, gridY + 1, gridWidth-2, gridWidth-2);
        CalendarButton *button = [CalendarButton buttonWithType:UIButtonTypeCustom];
        button.frame = gridFrame;
        [button setTitle:[NSString stringWithFormat:@"%d", comp.day] forState:UIControlStateNormal];
        if (comp.year==todayComp.year && comp.month==todayComp.month && comp.day==todayComp.day) {
            [button setTitleColor:[ElderlyUtils colorConvertFromString:@"#5e5e5e"] forState:UIControlStateNormal];
            [button setBackgroundImage:self.todayGirdImage forState:UIControlStateNormal];
        }else{
            [button setBackgroundImage:self.bgGirdImage forState:UIControlStateNormal];
        }
        button.date = [cal dateFromComponents:comp];
        [button addTarget:self action:@selector(onGridClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.dateHolder addSubview:button];
        
        if (comp.weekday==7) {
            gridY += gridWidth;
            
        }
        
        [comp setDay:comp.day + 1];
        NSDate *date = [cal dateFromComponents:comp];
        comp = [cal components:units fromDate:date];
        
    }
    
    if (comp.weekday>1) {
        CGRect blankFrame = CGRectMake((comp.weekday-1)*gridWidth + 1, gridY + 1, (7*gridWidth -  (comp.weekday-1)*gridWidth) - 2, gridWidth - 2);
        UIView *blankView = [[UIView alloc] initWithFrame:blankFrame];
        [blankView theme:@"calendar_body_bg"];
        [self.dateHolder addSubview:blankView];
        [blankView release];
    }
    
    [cal release];
    
}

- (UIImage*)createBgGirdImage:(UIColor*) color{
    float gridWidth = self.bodyView.frame.size.width/7;
    CGRect rect=CGRectMake(0.0f, 0.0f, gridWidth, gridWidth);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

-(void)themeChanged{

    [ self.monthLabel theme:@"date_Label"];
}

- (void)onButtonClick:(id) sender{
    
    if (isChangingMonth==NO) {
        isChangingMonth = YES;
        
        UIView *tmpHolder = [self.dateHolder retain];
        [self initGridHolder];
        
        unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
        NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *currentComp = [cal components:units fromDate:self.currentDate];
        
        if ([sender isEqual:self.topLeftButton]) {
            [currentComp setMonth:currentComp.month - 1];
        }else{
            [currentComp setMonth:currentComp.month + 1];
        }
        [currentComp setDay:01];
        NSDate *date = [cal dateFromComponents:currentComp];
        self.currentDate = date;
        [cal release];
        
        [self initGrids];
        
        CGRect newHolderFrame = self.dateHolder.frame;
        if ([sender isEqual:self.topLeftButton]) {
            newHolderFrame.origin.x = -newHolderFrame.size.width;
        }else{
            newHolderFrame.origin.x = newHolderFrame.size.width;
        }
        
        self.dateHolder.frame = newHolderFrame;
        [self.bodyView addSubview:self.dateHolder];
        
        [UIView animateWithDuration:0.5 animations:^{
            CGRect frame = tmpHolder.frame;
            if ([sender isEqual:self.topLeftButton]) {
                frame.origin.x = frame.size.width;
            }else{
                frame.origin.x = -frame.size.width;
            }
            tmpHolder.frame = frame;
            
            frame = self.dateHolder.frame;
            frame.origin.x = 0;
            self.dateHolder.frame = frame;
            
        } completion:^(BOOL isFinished){
            
            [self setMonthLabelText];
            
            [tmpHolder removeFromSuperview];
            [tmpHolder release];
            
            isChangingMonth = NO;
        }];
    }
    
}


- (void)onGridClick:(id)sender{
    if (self.delegate!=nil) {
        CalendarButton *button = (CalendarButton*) sender;
        NSDate *date = button.date;
        [self.delegate onDateSelect:date];
    }
}

- (void)onBgButtonClick:(id)sender{
    if (self.delegate!=nil) {
        [self.delegate onNoDateSelect];
    }
}


@end
