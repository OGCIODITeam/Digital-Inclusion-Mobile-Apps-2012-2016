//
//  CalendarHeaderView.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 7/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>
#define CalendarHeaderViewHeight 37;

@protocol CalendarHeaderViewDelegate <NSObject>

- (void)onHeaderClick;
- (void)onLeftButtonClick;
- (void)onRightButtonClick;

@end

@interface CalendarHeaderView : UIView

@property (assign, nonatomic) id<CalendarHeaderViewDelegate> deleagte;

- (id)initWithFrame:(CGRect)frame dateFormat:(NSString*)dateFormat;
- (void)setDate:(NSDate*) date;
- (NSDate*)getDate;
-(BOOL)calendarHeaderViewDateFormat;

- (void)changeTheme;

@end
