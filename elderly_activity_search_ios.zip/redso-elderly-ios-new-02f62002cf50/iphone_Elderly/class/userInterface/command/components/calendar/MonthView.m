//
//  MonthView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-10-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "MonthView.h"
#import "CalendarView.h"

@interface MonthView()

@property (retain, nonatomic) NSDate *currentDate;
@property (retain, nonatomic) UIView* bodyView;
@property (retain, nonatomic) UIButton *topLeftButton;
@property (retain, nonatomic) UIButton *topRightButton;
@property (retain, nonatomic) UILabel *monthLabel;
@property (retain, nonatomic) UIView *dateHolder;
@property (assign, nonatomic) BOOL isChangingYear;


- (void)initHeader;
- (void)initGridHolder;
- (void)initGrids;

@end


@implementation MonthView

@synthesize currentDate;
@synthesize delegate;
@synthesize topLeftButton;
@synthesize topRightButton;
@synthesize monthLabel;
@synthesize dateHolder;
@synthesize isChangingYear;


- (id)initWithFrame:(CGRect)frame andDate:(NSDate*) date{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.currentDate  = date;
        
        self.backgroundColor =  [UIColor colorWithRed:0 green:0 blue:0 alpha:0.9];
        
        UIButton* bgButtonView = [[UIButton alloc] initWithFrame:self.frame];
        [bgButtonView addTarget:self action:@selector(onBgButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:bgButtonView];
        [bgButtonView release];
        
        float bodyWidth = self.frame.size.width - 40;
        CGRect bodyFrame = CGRectMake(0, 0, bodyWidth, 140);
        UIView *calendarBody = [[UIView alloc] initWithFrame:bodyFrame];
        calendarBody.clipsToBounds = YES;
        //        calendarBody.backgroundColor = [UIColor blackColor];
        //        [calendarBody theme:@"calendar_body_bg"];
        calendarBody.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
        [self addSubview:calendarBody];
        self.bodyView = calendarBody;
        [calendarBody release];
        
        [self initHeader];
        [self initGridHolder];
        [calendarBody addSubview:self.dateHolder];
        [self initGrids];
        
        
    }
    return self;

}

- (void)dealloc
{
    self.currentDate = nil;
    self.topLeftButton = nil;
    self.topRightButton = nil;
    self.monthLabel = nil;
    self.dateHolder = nil;
    [super dealloc];
}


-(void)themeChanged{
    [self.monthLabel theme:@"date_Label"];
}

- (void)onBgButtonClick{
    if (self.delegate!=nil) {
        [self.delegate onNoMonthSelect];
    }
}

- (void)initHeader{
    
    UIView *calendarBody = self.bodyView;
    
    UIImage *leftImage = [UIImage imageNamed:@"btn_calendar_left.png"];
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setImage:leftImage forState:UIControlStateNormal];
    leftButton.frame = CGRectMake(0, 0, leftImage.size.width, leftImage.size.height);
    [leftButton addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    self.topLeftButton = leftButton;
    [leftButton setAccessibilityLabel:lang(@"onYear")];
    
    
    UIImage *rightImage = [UIImage imageNamed:@"btn_calendar_right.png"];
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:rightImage forState:UIControlStateNormal];
    rightButton.frame = CGRectMake(calendarBody.frame.size.width - rightImage.size.width, 0, rightImage.size.width, rightImage.size.height);
    [rightButton addTarget:self action:@selector(onButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    self.topRightButton = rightButton;
    [rightButton setAccessibilityLabel:lang(@"nextYear")];

    
    
    UIImage *bgImage = [UIImage imageNamed:@"calendar_header.png"];
    bgImage = [bgImage stretchableImageWithLeftCapWidth:bgImage.size.width/2 topCapHeight:bgImage.size.height/2];
    CGRect bgRect = CGRectMake(leftButton.frame.size.width, 0, rightButton.frame.origin.x - leftButton.frame.size.width, bgImage.size.height);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:bgRect];
    imageView.image = bgImage;
    
    
    UILabel *tmpMonthLabel = [[UILabel alloc] initWithFrame:bgRect];
    tmpMonthLabel.backgroundColor = [UIColor clearColor];
    tmpMonthLabel.textAlignment = NSTextAlignmentCenter;
    [tmpMonthLabel theme:@"date_Label"];
    self.monthLabel = tmpMonthLabel;
    
    [self setMonthLabelText];
    
    
    
    [calendarBody addSubview:imageView];
    [calendarBody addSubview:leftButton];
    [calendarBody addSubview:rightButton];
    [calendarBody addSubview:monthLabel];
    
    [imageView release];
    [tmpMonthLabel release];
}

-(void)initGridHolder{

    CGRect gridHolderFrame = CGRectMake(0, self.topLeftButton.frame.size.height+1, self.bodyView.frame.size.width, self.bodyView.frame.size.height-self.topLeftButton.frame.size.height);
    UIView *gridHolder = [[UIView alloc] initWithFrame:gridHolderFrame];
    self.dateHolder = gridHolder;
    [gridHolder release];

}

- (void)initGrids{
    

    unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *comp = [cal components:units fromDate:self.currentDate];
    
    NSDate *startDate = [cal dateFromComponents:comp];
    comp = [cal components:units fromDate:startDate];
    [comp setMonth:1];

    NSDateComponents *todayComp = [cal components:units fromDate:[NSDate date]];
    
    
    UIColor *bgGirdcolor = [ElderlyUtils colorConvertFromString:@"#b3b3b3"];
    UIColor *todayGirdcolor = [ElderlyUtils colorConvertFromString:@"#ffffff"];
    
    float orginX = 0;
    float gridY = 0;
    for (int i=0; i<12;i++ ) {
       
        CGRect gridFrame = CGRectMake(orginX, gridY , 70, 34);
        
        CalendarButton *button = [CalendarButton buttonWithType:UIButtonTypeCustom];
        button.frame = gridFrame;
        [button setTitle:[NSString stringWithFormat:@"%d月", comp.month] forState:UIControlStateNormal];
        if (comp.year==todayComp.year && comp.month==todayComp.month) {
            [button setTitleColor:[ElderlyUtils colorConvertFromString:@"#5e5e5e"] forState:UIControlStateNormal];
            [button setBackgroundColor:todayGirdcolor];
        }else{
            [button setBackgroundColor:bgGirdcolor ];
        }
        button.date = [cal dateFromComponents:comp];
        [button addTarget:self action:@selector(onGridClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.dateHolder addSubview:button];
        orginX = CGRectGetMaxX(button.frame)+1;
        if(orginX >= self.bodyView.frame.size.width){
            orginX = 0;
            gridY = CGRectGetMaxY(button.frame)+1;
        }
        
        [comp setMonth:comp.month + 1];
        NSDate *date = [cal dateFromComponents:comp];
        comp = [cal components:units fromDate:date];
 
    }
    
}

- (void)setMonthLabelText{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy年";
    NSString *str = [dateFormatter stringFromDate:self.currentDate];
    self.monthLabel.text = str;
    [dateFormatter release];
}

- (void)onButtonClick:(id) sender{
    
    if (self.isChangingYear==NO) {
        self.isChangingYear = YES;
        
        UIView *tmpHolder = [self.dateHolder retain];
        [self initGridHolder];
        
        unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
        NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *currentComp = [cal components:units fromDate:self.currentDate];
        
        if ([sender isEqual:self.topLeftButton]) {
            [currentComp setYear:currentComp.year - 1];
        }else{
            [currentComp setYear:currentComp.year + 1];
        }
        
        NSDate *date = [cal dateFromComponents:currentComp];
        self.currentDate = date;
        [cal release];
        
        [self initGrids];
        
        CGRect newHolderFrame = self.dateHolder.frame;
        if ([sender isEqual:self.topLeftButton]) {
            newHolderFrame.origin.x = -newHolderFrame.size.width;
        }else{
            newHolderFrame.origin.x = newHolderFrame.size.width;
        }
        
        self.dateHolder.frame = newHolderFrame;
        [self.bodyView addSubview:self.dateHolder];
        
        [UIView animateWithDuration:0.5 animations:^{
            CGRect frame = tmpHolder.frame;
            if ([sender isEqual:self.topLeftButton]) {
                frame.origin.x = frame.size.width;
            }else{
                frame.origin.x = -frame.size.width;
            }
            tmpHolder.frame = frame;
            
            frame = self.dateHolder.frame;
            frame.origin.x = 0;
            self.dateHolder.frame = frame;
            
        } completion:^(BOOL isFinished){
            
            [self setMonthLabelText];
            
            [tmpHolder removeFromSuperview];
            [tmpHolder release];
            
            self.isChangingYear = NO;
        }];
    }
}

- (void)onGridClick:(id)sender{
    if (self.delegate!=nil) {
        CalendarButton *button = (CalendarButton*) sender;
        NSDate *date = button.date;
        [self.delegate onMonthSelect:date];
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
