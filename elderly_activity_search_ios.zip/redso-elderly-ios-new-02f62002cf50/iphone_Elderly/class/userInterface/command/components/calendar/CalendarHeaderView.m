//
//  CalendarHeaderView.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 7/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "CalendarHeaderView.h"
@interface CalendarHeaderView()

@property (retain, nonatomic) UIButton *dateLabel;
@property (retain, nonatomic) NSDate *currentDate;
@property (retain, nonatomic) NSString* currentDateFormat;

@end

@implementation CalendarHeaderView
@synthesize dateLabel;
@synthesize deleagte;
@synthesize currentDate;
@synthesize currentDateFormat;

- (void)dealloc
{
    self.dateLabel = nil;
    self.deleagte = nil;
    self.currentDate = nil;
    self.currentDateFormat = nil;
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame dateFormat:(NSString*)dateFormat
{
    self = [super initWithFrame:frame];
    if (self) {
        self.currentDateFormat = dateFormat;
        UIImage *leftImage = [UIImage imageNamed:@"btn_calendar_left.png"];
        UIButton *_tmpLeftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_tmpLeftBtn setImage:leftImage forState:UIControlStateNormal];
        _tmpLeftBtn.frame = CGRectMake(0, 0, leftImage.size.width, leftImage.size.height);
        [_tmpLeftBtn addTarget:self action:@selector(onLeftButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        BOOL isMonth = [dateFormat isEqualToString:lang(@"dateFormat2")];
        
        [_tmpLeftBtn setAccessibilityLabel:(isMonth?lang(@"onMonth"):lang(@"onDay"))];
        
        UIImage *rightImage = [UIImage imageNamed:@"btn_calendar_right.png"];
        UIButton *_tmpRightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_tmpRightBtn setImage:rightImage forState:UIControlStateNormal];
        _tmpRightBtn.frame = CGRectMake(frame.size.width - rightImage.size.width, 0, rightImage.size.width, rightImage.size.height);
        [_tmpRightBtn addTarget:self action:@selector(onRightButtonClick:) forControlEvents:UIControlEventTouchUpInside];
         [_tmpRightBtn setAccessibilityLabel:isMonth?lang(@"nextMonth"):lang(@"nextDay")];
        
        UIImage *bgImage = [UIImage imageNamed:@"calendar_header.png"];
        bgImage = [bgImage stretchableImageWithLeftCapWidth:bgImage.size.width/2 topCapHeight:bgImage.size.height/2];
        CGRect bgRect = CGRectMake(_tmpLeftBtn.frame.size.width, 0, _tmpRightBtn.frame.origin.x - _tmpLeftBtn.frame.size.width, bgImage.size.height);
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:bgRect];
        imageView.image = bgImage;
        
        

        UIButton *bgButton = [[UIButton alloc] init];
        bgButton.frame = bgRect;
        [bgButton theme:@"date_Label"];
        [bgButton addTarget:self action:@selector(onBgButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        self.dateLabel = bgButton;
        
        
        [self addSubview:imageView];
        [self addSubview:_tmpLeftBtn];
        [self addSubview:_tmpRightBtn];
        [self addSubview:bgButton];
        
        [imageView release];
        [bgButton release];
        
//        [self setDate:[[NSDate alloc] init]];
    }
    return self;
}

- (void)setDate:(NSDate*) date{
    self.currentDate = date;
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = self.currentDateFormat;
    NSString *str = [dateFormatter stringFromDate:date];
    [self.dateLabel setTitle:str forState:UIControlStateNormal];
    [dateFormatter release];

}


-(BOOL)calendarHeaderViewDateFormat{

    return [self.currentDateFormat isEqualToString:lang(@"dateFormat")];
}

- (NSDate*)getDate{
    return self.currentDate;
}

- (void)onBgButtonClick:(id) sender{
    if (self.deleagte!=nil) {
        [self.deleagte onHeaderClick];
    }
}

- (void)onLeftButtonClick:(id) sender{
    if (self.deleagte!=nil) {
        [self.deleagte onLeftButtonClick];
    }
}

- (void)onRightButtonClick:(id) sender{
    if (self.deleagte!=nil) {
        [self.deleagte onRightButtonClick];
    }
}

- (void)changeTheme{
    [self.dateLabel theme:@"date_Label"];
}

@end
