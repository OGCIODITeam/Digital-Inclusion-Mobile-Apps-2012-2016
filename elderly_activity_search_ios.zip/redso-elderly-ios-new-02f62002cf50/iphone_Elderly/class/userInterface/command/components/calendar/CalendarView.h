//
//  CalendarView.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 7/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CalendarViewDelegate <NSObject>

- (void)onDateSelect:(NSDate*) date;
- (void)onNoDateSelect;

@end

@interface CalendarButton : UIButton
@property (retain, nonatomic) NSDate *date;

@end

@interface CalendarView : UIView
@property (assign, nonatomic) id<CalendarViewDelegate> delegate;

- (id)initWithFrame:(CGRect)frame andDate:(NSDate*) date;
-(void)themeChanged;

@end
