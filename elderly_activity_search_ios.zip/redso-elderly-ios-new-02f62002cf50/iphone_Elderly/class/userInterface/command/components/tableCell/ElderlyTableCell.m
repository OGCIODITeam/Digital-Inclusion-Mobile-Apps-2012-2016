//
//  ElderlyTableCell.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyTableCell.h"
#import "ElderlyThemeManager.h"

@implementation ElderlyTableCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 10, 200, 30)];
        [titleLabel theme:@"myInterest_tableCell_title"];
        titleLabel.numberOfLines = 1;
        [self addSubview:titleLabel];
        [titleLabel release];
        
        subheadLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, CGRectGetHeight(titleLabel.frame)+5, 200, 24)];
        subheadLabel.numberOfLines = 0;
        [titleLabel theme:@"myInterest_tableCell_title"];
        [self addSubview:subheadLabel];
        [subheadLabel release];
        
        
        UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_add.png"];
        selectButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, img.size.width, img.size.height)];
        selectButton.userInteractionEnabled = NO;
        [selectButton setImage:img forState:UIControlStateNormal];
        [selectButton setAccessibilityLabel:lang(@"select")];
        [self addSubview:selectButton];
        [selectButton release];

    }
    return self;
}

//- (void)setSelected:(BOOL)selected animated:(BOOL)animated
//{
//    [super setSelected:selected animated:animated];
//
//    // Configure the view for the selected state
//}


-(void)setTitle:(NSString*)title{

    titleLabel.text = title;
    [titleLabel theme:@"myInterest_tableCell_title"];
  //  [titleLabel sizeToFit];

}

-(void)setSubHeadTitle:(NSString*)title{

    subheadLabel.frame=CGRectMake(20, CGRectGetHeight(titleLabel.frame)+5, 200, 24);
    subheadLabel.text = title;
    [subheadLabel theme:@"myInterest_tableCell_title"];
    [subheadLabel sizeToFit];
   
}


-(void)setSelectImage:(UIImage*)img{
    [selectButton setImage:img forState:UIControlStateSelected];
}

-(void)selectItem:(BOOL)selected{

    selectButton.selected = selected;
}

-(BOOL)getSelectItem{

    return selectButton.selected;
}

-(void)layoutSubviews{

    [super layoutSubviews];
    
    CGRect rect = self.bounds;
    
    CGRect tmpRect = selectButton.frame;
    tmpRect.origin.x = rect.size.width - selectButton.frame.size.width*1.7f;
    tmpRect.origin.y = (rect.size.height - selectButton.frame.size.height)*0.5f;
    selectButton.frame = tmpRect;
    
  
    tmpRect = titleLabel.frame;
    if(tmpRect.size.width > 200)
        tmpRect.size.width = 200;
    
    if(subheadLabel.text.length >1){
    

       
        titleLabel.frame = tmpRect;
        
        tmpRect = subheadLabel.frame;
        tmpRect.origin.x = titleLabel.frame.origin.x;
        tmpRect.origin.y = CGRectGetMaxY(titleLabel.frame)+5;
        if(tmpRect.size.width > 200)
            tmpRect.size.width = 200;
        
        if(tmpRect.size.height > 48)
            tmpRect.size.height = 48;
    
    }
    else{
        tmpRect.origin.y = (self.bounds.size.height - titleLabel.frame.size.height)*0.5f;
        titleLabel.frame = tmpRect;
    }
    
}

-(float)getCellHeight{

    float h = titleLabel.frame.size.height;
    if(subheadLabel.text.length > 0){
        h+= subheadLabel.frame.size.height;
        h+=20;
        
        if(h <65)
            h =65;
        
        return h;
    }
    
    return 48;

}

@end
