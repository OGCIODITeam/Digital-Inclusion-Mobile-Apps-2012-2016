//
//  WeatherTableCell.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-14.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "WeatherTableCell.h"
#import "ElderlyThemeManager.h"

@implementation WeatherTableCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        self.backgroundColor = [UIColor clearColor];
        
        UIImageView* bgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 301, 50)];
        bgView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"weather_item.png"];
        [self addSubview:bgView];
        [bgView release];
        
        
        iconView = [[UIImageView alloc] initWithFrame:CGRectMake(13, 3.5, 46, 43)];
        [self addSubview:iconView];
        [iconView release];
        
        dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(iconView.frame)+5, 0, 220, 25)];
        [dateLabel theme:@"weatherTableCell_title"];
        dateLabel.shadowColor = [UIColor blackColor];
        dateLabel.shadowOffset = CGSizeMake(1.0, 1.0);
        [self addSubview:dateLabel];
        [dateLabel release];
        
        
        temperatureLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(iconView.frame)+5, CGRectGetMaxY(dateLabel.frame), 230, 25)];
        [temperatureLabel theme:@"weatherTableCell_subTitle"];
        temperatureLabel.shadowColor = [UIColor blackColor];
        temperatureLabel.shadowOffset = CGSizeMake(1.0, 1.0);
        
        [self addSubview:temperatureLabel];
        [temperatureLabel release];
        
    }
    return self;
}



-(void)setWeatherIcon:(UIImage*)img{
    
    iconView.image = img;

}


-(void)setDate:(NSDate*)date{

    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    NSLocale *locale=[[NSLocale alloc] initWithLocaleIdentifier:[ElderlyUtils language]];
    [dateFormatter setLocale:locale];
    [dateFormatter setDateFormat:@"MM月dd日 (EEEE) "];
    [locale release];
    
    dateLabel.text = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    
    
}

-(void)layoutSubviews{

     [dateLabel theme:@"weatherTableCell_title"];
    [temperatureLabel theme:@"weatherTableCell_subTitle"];

}


-(void)setTemperature:(NSString*)temperature weatherName:(NSString*)name{

    temperatureLabel.text = [NSString stringWithFormat:@"%@°c  %@",temperature,name];

}

@end
