//
//  WeatherTableCell.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-14.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherTableCell : UITableViewCell{

    UIImageView* iconView;
    UILabel* dateLabel;
    UILabel* temperatureLabel;

}


-(void)setWeatherIcon:(UIImage*)img;
-(void)setDate:(NSDate*)date;
-(void)setTemperature:(NSString*)temperature weatherName:(NSString*)name;

@end
