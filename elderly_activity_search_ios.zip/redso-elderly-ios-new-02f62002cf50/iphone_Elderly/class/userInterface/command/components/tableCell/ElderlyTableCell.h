//
//  ElderlyTableCell.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface ElderlyTableCell : UITableViewCell{

    UILabel* titleLabel;
    UILabel* subheadLabel;
    UIButton* selectButton;

    
}

-(void)setTitle:(NSString*)title;
-(void)setSubHeadTitle:(NSString*)title;
-(void)setSelectImage:(UIImage*)img;

-(float)getCellHeight;

-(void)selectItem:(BOOL)selected;
-(BOOL)getSelectItem;


@end
