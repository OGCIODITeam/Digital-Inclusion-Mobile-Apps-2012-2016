//
//  TapItemView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-11.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "TapItemView.h"
#import "MyCommunityCentre.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyThemeManager.h"

@implementation TapItemView

@synthesize leftText;
@synthesize text;
@synthesize tag;


-(id)initWithImage:(UIImage*)image{
    self=[self init];
    if(self){
        label=[[UILabel alloc] init];
        [label theme:@"label_custom_label"];
        [self addSubview:label];
        ElderlyThemeGridModel* model = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
        label.textColor = [ElderlyUtils colorConvertFromString:model.color];
        [label release];
        
        chooseView = [[MyCommunityCentre alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height) bgImage:image];
        [chooseView theme:@"tap_choose_title"];
        [self addSubview:chooseView];
        [chooseView release];
        
        CGRect rect=self.frame;
        rect.size.height=chooseView.frame.size.height+7.0f;
        self.frame=rect;
    }
    
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    CGRect rect=chooseView.frame;
    rect.origin.y=5.0f;
    rect.origin.x=self.frame.size.width-10.0f-rect.size.width;
    chooseView.frame=rect;
    
    rect=label.frame;
    rect.size.width=self.frame.size.width-CGRectGetMinX(chooseView.frame)-10.0f-5.0f;
    rect.size.height=self.frame.size.height;
    rect.origin.x=10.0f;
    label.frame=rect;

}


-(void)setLeftText:(NSString *)value{
    label.text = value;
}

-(void)setText:(NSString *)value{
    [chooseView setTitle:value];

    [chooseView setAccessibilityLabel:label.text];
    [chooseView setAccessibilityTitle:[NSString stringWithFormat:@"%@%@",value,label.text]];

}

-(void)setTag:(NSInteger)value{
    chooseView.tag = value;
}

-(void)highlight:(BOOL)isHighlight{
    [chooseView sethighlight:isHighlight];
}


-(void)themeChanged{
    [chooseView theme:@"tap_choose_title"];
    [label theme:@"label_custom_label"];
    ElderlyThemeGridModel* model = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    label.textColor = [ElderlyUtils colorConvertFromString:model.color];
}

-(void)addTarget:(id)own action:(SEL)action{
    [chooseView addTarget:own action:action forControlEvents:UIControlEventTouchUpInside];
}

@end
