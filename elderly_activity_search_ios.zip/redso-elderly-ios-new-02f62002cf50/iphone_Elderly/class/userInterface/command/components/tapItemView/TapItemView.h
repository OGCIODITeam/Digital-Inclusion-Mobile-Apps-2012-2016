//
//  TapItemView.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-11.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyCommunityCentre;
@interface TapItemView : UIView{

    UILabel* label;
    MyCommunityCentre* chooseView;

}

@property(nonatomic,retain) NSString* leftText;
@property(nonatomic,retain) NSString* text;
@property(nonatomic,assign) NSInteger tag;

-(id)initWithImage:(UIImage*)image;
-(void)highlight:(BOOL)isHighlight;
-(void)themeChanged;
-(void)addTarget:(id)own action:(SEL)action;


@end
