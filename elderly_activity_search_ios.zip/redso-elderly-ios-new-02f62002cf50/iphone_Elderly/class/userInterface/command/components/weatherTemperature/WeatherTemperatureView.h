//
//  WeatherTemperatureView.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherTemperatureView : UIView{

    UILabel* maxTemperatureLabel;
    UILabel* minTemperatureLabel;
    UILabel* humidityLabel;
    
    UILabel* temperatureLabel;

}


-(void)setMaxTemperature:(NSInteger)temperature;
-(void)setMinTemperature:(NSInteger)temperature;
-(void)setHumidity:(NSInteger)humidity;
-(void)setTemperature:(NSInteger)temperature;

@end
