//
//  WeatherTemperatureView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "WeatherTemperatureView.h"
#import "ElderlyThemeManager.h"

@implementation WeatherTemperatureView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code

        UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_highest.png"];
        UIImageView* maxImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, img.size.width, img.size.height)];
        maxImageView.image = img;
        [maxImageView setAccessibilityLabel:lang(@"highestTemperature")];
        maxImageView.isAccessibilityElement = YES;
        [self addSubview:maxImageView];
        [maxImageView release];
        
        maxTemperatureLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(maxImageView.frame)+2, 0, 40, 18)];
        maxTemperatureLabel.shadowColor = [UIColor blackColor];
        maxTemperatureLabel.shadowOffset = CGSizeMake(1.0, 1.0);
        
        [self addSubview: maxTemperatureLabel];
        [maxTemperatureLabel release];
        
        img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_lowest.png"];
        UIImageView* minImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(maxTemperatureLabel.frame)+5, 0, img.size.width, img.size.height)];
        minImageView.image = img;
        minImageView.isAccessibilityElement = YES;
        [minImageView setAccessibilityLabel:lang(@"lowestTemperature")];
        [self addSubview:minImageView];
        [minImageView release];
        
        minTemperatureLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(minImageView.frame)+2, 0, 40, 18)];
        minTemperatureLabel.shadowColor = [UIColor blackColor];
        minTemperatureLabel.shadowOffset = CGSizeMake(1.0, 1.0);
        
        [self addSubview:minTemperatureLabel];
        [minTemperatureLabel release];
        
        img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_humidity.png"];
        UIImageView* humidityImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(minTemperatureLabel.frame)+5, 0, img.size.width, img.size.height)];
        humidityImageView.image = img;
        humidityImageView.isAccessibilityElement = YES;
        [humidityImageView setAccessibilityLabel:lang(@"humidity")];
        [self addSubview:humidityImageView];
        [humidityImageView release];

        

        
        humidityLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(humidityImageView.frame)+2, 0, 50, 18)];
        humidityLabel.shadowColor = [UIColor blackColor];
        humidityLabel.shadowOffset = CGSizeMake(1.0, 1.0);
        
        [self addSubview:humidityLabel];
        [humidityLabel release];
        
        temperatureLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(maxImageView.frame)+([ElderlyUtils isRetain4]?15:5), 160, ([ElderlyUtils isRetain4]?70:60))];
        temperatureLabel.shadowColor = [UIColor blackColor];
        temperatureLabel.shadowOffset = CGSizeMake(1.0, 1.0);
       
        [self addSubview:temperatureLabel];
        [temperatureLabel release];
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)setMaxTemperature:(NSInteger)temperature{
    
    [maxTemperatureLabel theme:[ElderlyUtils isRetain4]?@"weather_maxTemperature_big":@"weather_maxTemperature"];
    maxTemperatureLabel.text = [NSString stringWithFormat:@"%d°",temperature];
}


-(void)setMinTemperature:(NSInteger)temperature{
    [minTemperatureLabel theme:[ElderlyUtils isRetain4]?@"weather_mixTemperature_big":@"weather_mixTemperature"];
    minTemperatureLabel.text = [NSString stringWithFormat:@"%d°",temperature];
}

-(void)setHumidity:(NSInteger)humidity{
    [humidityLabel theme:[ElderlyUtils isRetain4]?@"weather_humidity_big":@"weather_humidity"];
    
     humidityLabel.text = [[NSString stringWithFormat:@"%d",humidity] stringByAppendingString:@"%"];
}


-(void)setTemperature:(NSInteger)temperature{
    [temperatureLabel theme:[ElderlyUtils isRetain4]?@"weather_temperature_big":@"weather_temperature"];
     temperatureLabel.text = [NSString stringWithFormat:@"%d°c",temperature];
}

@end
