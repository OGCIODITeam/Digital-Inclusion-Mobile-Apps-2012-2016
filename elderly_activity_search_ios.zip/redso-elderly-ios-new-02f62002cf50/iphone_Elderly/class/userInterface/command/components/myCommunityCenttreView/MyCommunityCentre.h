//
//  MyCommunityCentre.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCommunityCentre : UIControl{

    UILabel* titleLabel;
    UILabel* subHeaderLabel;
    
    UIButton* button;

}


- (id)initWithFrame:(CGRect)frame bgImage:(UIImage*)bgimg;
-(void)setTitle:(NSString*)title;
-(void)setAccessibilityTitle:(NSString *)title;
-(void)setSubheader:(NSString*)title;
-(void)sethighlight:(BOOL)highlight;
-(NSString*)getTitle;

-(void)addClearContentButton:(id)target action:(SEL)action;
-(void)removeClearContentButton;
-(void)layoutSubviews;

@end
