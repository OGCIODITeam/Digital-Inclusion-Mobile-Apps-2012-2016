//
//  MyCommunityCentre.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "MyCommunityCentre.h"
#import "ElderlyThemeManager.h"

@implementation MyCommunityCentre


- (id)initWithFrame:(CGRect)frame bgImage:(UIImage*)bgimg
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        UIImage* img = bgimg;
        UIImageView* bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, img.size.width, img.size.height)];
        bgView.image = img;
        
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, (bgView.bounds.size.height - 24)*0.5f, img.size.width - 20 , 24)];

        titleLabel.numberOfLines = 1;
        [bgView addSubview:titleLabel];
        [titleLabel release];
        
        subHeaderLabel =  [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxX(titleLabel.frame)+5, img.size.width - 20, 24)];
        subHeaderLabel.numberOfLines = 1;
        subHeaderLabel.hidden = YES;
        [bgView addSubview:subHeaderLabel];
        [subHeaderLabel release];
        
        [self addSubview:bgView];
        [bgView release];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


-(void)addClearContentButton:(id)target action:(SEL)action{
    
    if(button != nil){
        [button removeFromSuperview];
        button = nil;
    }
    

    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_delete.png"];
    button = [[UIButton alloc] initWithFrame:CGRectMake(self.bounds.size.width - img.size.width*1.2, (self.bounds.size.height - img.size.height)*0.5f, img.size.width, img.size.height)];
    [button setAccessibilityLabel:lang(@"delete")];
    [button setImage:img forState:UIControlStateNormal];
    button.tag = self.tag;
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:button];
    [button release];
    
    CGRect rect = titleLabel.frame;
    rect.size.width = self.bounds.size.width - img.size.width*1.2;
    titleLabel.frame = rect;
    
    rect = subHeaderLabel.frame;
    rect.size.width = self.bounds.size.width - img.size.width*1.2;
    subHeaderLabel.frame = rect;

}

-(void)removeClearContentButton{
    if(button == nil)
        return ;
    
    [button removeFromSuperview];
    button = nil;
    
    
    CGRect rect = titleLabel.frame;
    rect.size.width = self.bounds.size.width - 20;
    titleLabel.frame = rect;
    
    rect = subHeaderLabel.frame;
    rect.size.width = self.bounds.size.width - 20;
    subHeaderLabel.frame = rect;
    
}

-(void)setTitle:(NSString*)title{
    titleLabel.text = title;
    [self setAccessibilityLabel:title];
}

-(void)setAccessibilityTitle:(NSString *)title{
    [titleLabel setAccessibilityLabel:title];
}

-(NSString*)getTitle{

    return titleLabel.text;
}

-(void)theme:(NSString *)key{

    [titleLabel theme:key];
    if(subHeaderLabel.text.length > 0)
       [subHeaderLabel theme:key];
}


-(void)setSubheader:(NSString*)title{
    subHeaderLabel.text = title;
    subHeaderLabel.hidden = NO;
    [self setAccessibilityValue:title];

}

-(void)sethighlight:(BOOL)highlight{

    subHeaderLabel.highlighted = highlight;
    titleLabel.highlighted = highlight;
}

-(void)layoutSubviews{

    [super layoutSubviews];
    CGRect tmpRect = titleLabel.frame;
    
    if(subHeaderLabel.text.length >1){
        
        tmpRect.origin.y = 8;
        titleLabel.frame = tmpRect;
        
        tmpRect = subHeaderLabel.frame;
        tmpRect.origin.y = CGRectGetMaxY(titleLabel.frame);
        subHeaderLabel.frame = tmpRect;
    
    }
    else{
        tmpRect.origin.y = (self.bounds.size.height - titleLabel.frame.size.height)*0.5f;
        titleLabel.frame = tmpRect;
    }
    
}

@end
