//
//  ButtonText.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ButtonText.h"

@implementation ButtonText
@synthesize spacing;
@synthesize alignment;
@synthesize isSelectedButton;

-(id)init{
    self=[super init];
    if(self){
        self.alignment=NSTextAlignmentCenter;
        arrowImage=[[UIImageView alloc] init];
        [self addSubview:arrowImage];
        [arrowImage release];
        
        label=[[UILabel alloc] init];
        [self addSubview:label];
        [label release];
        
        
        self.isSelectedButton = NO;

    }
    return self;
}

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.alignment=NSTextAlignmentCenter;

        arrowImage=[[UIImageView alloc] init];
        [self addSubview:arrowImage];
        [arrowImage release];

        label=[[UILabel alloc] init];
        [self addSubview:label];
        [label release];
        self.isSelectedButton = NO;
    }
    return self;
}

-(void)theme:(NSString*)theme{
    [label theme:theme];
    [label sizeToFit];

}

-(void)arrow:(UIImage*)image{
    arrowImage.image=image;
    CGRect rect=arrowImage.frame;
    rect.size=image.size;
    arrowImage.frame=rect;

}

-(void)text:(NSString*)value{
    label.text=value;
    [self setTitle:value forState:UIControlStateNormal];
    [self setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
}

-(void)textHighlight:(BOOL)value{
    label.highlighted = value;
}

-(void)layoutSubviews{
    [super layoutSubviews];
      float left=0.0f;
    if(self.alignment==NSTextAlignmentCenter)
        left=(self.frame.size.width-(label.frame.size.width+arrowImage.frame.size.width+self.spacing))*0.5f;
    
    arrowImage.hidden = self.isSelectedButton;
    CGRect rect=arrowImage.frame;
    rect.origin.x=left;
    rect.origin.y=(self.frame.size.height-rect.size.height)*0.5f;
    arrowImage.frame=rect;

    rect=label.frame;
    if(rect.size.width>self.frame.size.width-rect.origin.x)
        rect.size.width=self.frame.size.width-rect.origin.x;
    rect.origin.x=(arrowImage.hidden?(self.frame.size.width - rect.size.width)*0.5f:CGRectGetMaxX(arrowImage.frame)+self.spacing);
    rect.size.height=self.frame.size.height;

    label.frame=rect;

}



@end
