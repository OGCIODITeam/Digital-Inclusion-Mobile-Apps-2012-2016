//
//  ButtonText.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButtonText : UIButton{
    UIImageView*  arrowImage;
    UILabel* label;
    
}
@property(nonatomic,assign) NSTextAlignment alignment;
@property(nonatomic,assign) float spacing;
@property(nonatomic,assign) BOOL isSelectedButton;

-(void)text:(NSString*)value;
-(void)arrow:(UIImage*)image;
-(void)textHighlight:(BOOL)value;

@end
