//
//  TabBarView.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "HeadTabView.h"
#import "ElderlyThemeManager.h"
@interface HeadTabView()
-(void)moveArrow:(int)index;
-(void)btnTabClick:(UIButton*)button;
@end

@implementation HeadTabView
@synthesize delegate;

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled=YES;

        lineView=[[UIImageView alloc] initWithImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"tab_line.png"]];
        
        [self addSubview:lineView];
        [lineView release];
        
        UIImage* img=[[ElderlyThemeManager sharedInstance] imageByTheme:@"tab_noraml_purple.png"];
        
        frame.size.height=10.0f+lineView.frame.size.height+img.size.height;
        self.frame=frame;
        buttonList=[[NSMutableArray alloc] initWithCapacity:2];
        
        frame=lineView.frame;
        frame.origin.y=self.frame.size.height-frame.size.height;
        lineView.frame=frame;
    }
    return self;
}

-(void)dealloc{
    [buttonList release];
    [super dealloc];
}

-(void)themeChanged:(NSArray*)array imageArray:(NSArray*)imageArray{

    
    lineView.image=[[ElderlyThemeManager sharedInstance] imageByMotif:[imageArray objectAtIndex:2]];
    UIImage* img=[[ElderlyThemeManager sharedInstance] imageByMotif:[imageArray objectAtIndex:0]];
    UIImage* img_select=[[ElderlyThemeManager sharedInstance] imageByMotif:[imageArray objectAtIndex:1]];

    int index=0;
    for(UIButton* button in buttonList){
        NSString* str=[array objectAtIndex:index];
        [button setTitle:str forState:UIControlStateNormal];
        [button theme:@"tabhead_title"];
        [button setBackgroundImage:img forState:UIControlStateNormal];
        [button setBackgroundImage:img_select forState:UIControlStateSelected];

        index++;
    }
}

-(void)setTabNameArray:(NSArray*)array{

    [buttonList makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [buttonList removeAllObjects];
    
    UIImage* img=[[ElderlyThemeManager sharedInstance] imageByTheme:@"tab_noraml_purple.png"];
    UIImage* img_select=[[ElderlyThemeManager sharedInstance] imageByTheme:@"tab_noraml_purple.png"];

    
    float left=(self.frame.size.width-[array count]*img.size.width-(([array count]-1)*10.0f))*0.5f;
    int index=0;
    for(NSString* str in array){
        UIButton* button =[UIButton buttonWithType:UIButtonTypeCustom];
        [button addTarget:self action:@selector(btnTabClick:) forControlEvents:UIControlEventTouchUpInside];
        button.tag=index;
        [button theme:@"tabhead_title"];
        button.frame=CGRectMake(left, 10.0f, img.size.width, img.size.height);
        [button setTitle:str forState:UIControlStateNormal];
        [button setBackgroundImage:img forState:UIControlStateNormal];
        [button setBackgroundImage:img_select forState:UIControlStateSelected];
        [self addSubview:button];
        
        left+=img.size.width+10.0f;
        
        index++;
        
        [buttonList addObject:button];
    }
    [self bringSubviewToFront:lineView];
    [self moveArrow:0];
}

-(void)setTabImageView:(NSArray*)array{

    if([array count] <3 || [buttonList count]<1)
        return;
     lineView.image=[[ElderlyThemeManager sharedInstance] imageByMotif:[array objectAtIndex:2]];
    UIImage* img=[[ElderlyThemeManager sharedInstance] imageByMotif:[array objectAtIndex:0]];
    UIImage* img_select=[[ElderlyThemeManager sharedInstance] imageByMotif:[array objectAtIndex:1]];
    
    for(UIButton* button in buttonList){
        [button setBackgroundImage:img forState:UIControlStateNormal];
        [button setBackgroundImage:img_select forState:UIControlStateSelected];
    }


}

-(void)moveArrow:(int)index{
    if([buttonList count]<1)return;

    for(UIButton* button in buttonList)
        button.selected=(button.tag==index);
    
}

-(void)btnTabClick:(UIButton*)button{
    
    [self moveArrow:button.tag];
    if([self.delegate respondsToSelector:@selector(tabDidSelected:index:) ])
        [self.delegate tabDidSelected:self index:button.tag];
}

@end
