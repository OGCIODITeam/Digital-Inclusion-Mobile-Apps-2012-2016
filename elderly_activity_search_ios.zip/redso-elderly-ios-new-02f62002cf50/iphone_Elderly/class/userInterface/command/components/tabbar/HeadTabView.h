//
//  TabBarView.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HeadTabView;

@protocol HeadTabViewDelegte <NSObject>
@optional
-(void)tabDidSelected:(HeadTabView*)tabView index:(int)index;

@end

@interface HeadTabView : UIView{
    UIImageView* lineView;
    NSMutableArray* buttonList;
}
@property(nonatomic,assign) id<HeadTabViewDelegte> delegate;

-(void)setTabNameArray:(NSArray*)array;
-(void)themeChanged:(NSArray*)array imageArray:(NSArray*)imageArray;

-(void)setTabImageView:(NSArray*)array;

@end
