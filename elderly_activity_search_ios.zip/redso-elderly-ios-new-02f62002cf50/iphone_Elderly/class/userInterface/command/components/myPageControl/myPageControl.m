//
//  myPageControl.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-10-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "myPageControl.h"
@interface myPageControl()
@property (nonatomic,retain)NSMutableArray *arrayMyIndicaters;
@end;

@implementation myPageControl

@synthesize numberOfPages=_numberOfPages;
@synthesize currentPage=_currentPage;
@synthesize arrayMyIndicaters=_arrayMyIndicaters;
@synthesize indicaterColor=_indicaterColor;

#define indicaterWidthMaker 0.5  //min 0 ,max 1
#define nonusingIndicaterAplha 0.6

-(UIColor *)indicaterColor{
    if (_indicaterColor) {
        return _indicaterColor;
    }else{
        return [UIColor whiteColor];
    }
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)setCurrentPage:(NSInteger)currentPage{
    _currentPage=currentPage;
    [self reSetIndicaterColor];
 }

-(void)setNumberOfPages:(NSInteger)numberOfPages{
    _numberOfPages=numberOfPages;
    [self creatIndicater:numberOfPages];

}

-(void)setIndicaterColor:(UIColor *)indicaterColor{
    _indicaterColor=indicaterColor;
    if (self.arrayMyIndicaters) {
        for (UIButton *btn in self.arrayMyIndicaters) btn.backgroundColor=indicaterColor;
    }
}

-(void)creatIndicater:(int)numberOfPages{
    NSMutableArray *aArray=[[NSMutableArray alloc]init];
    self.arrayMyIndicaters=aArray;
    [aArray release]; aArray=nil;
    float indicaterWidth=self.frame.size.width/numberOfPages*indicaterWidthMaker;
  
    for (int i=0; i<numberOfPages; i++) {
         UIButton *indicater=[UIButton buttonWithType:UIButtonTypeCustom];
            
         if (self.arrayMyIndicaters.count) {
                indicater.frame= CGRectMake( [self getXfrom:[self.arrayMyIndicaters lastObject]]+(1-indicaterWidthMaker)*indicaterWidth,  0,  indicaterWidth, indicaterWidth);
            }else{
                indicater.frame= CGRectMake((1-indicaterWidthMaker)/2*indicaterWidth,  0,  indicaterWidth, indicaterWidth);
         }
        
        indicater.layer.cornerRadius =indicaterWidth/2;//half of the width
         indicater.backgroundColor=self.indicaterColor;
        if (i!=self.currentPage)indicater.alpha=nonusingIndicaterAplha;
        indicater.tag=i;
        indicater.accessibilityLabel=[NSString  stringWithFormat:@"共%d页　第%d页",self.numberOfPages,i];
        
        [indicater  addTarget:self action:@selector(selectedIndicater:)  forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:indicater];
        [self.arrayMyIndicaters addObject:indicater];
     }
}

-(float)getXfrom:(id)view{
    UIButton *aButton=view;
    return aButton.frame.origin.x+aButton.frame.size.width;
}

-(void)reSetIndicaterColor{
    
    for (UIButton *btn in self.arrayMyIndicaters) {
        if (btn.tag==self.currentPage) {
            btn.alpha=1;
        }else{
        btn.alpha=nonusingIndicaterAplha;
        }
    }
}

-(IBAction)selectedIndicater:(UIButton *)sender{
    
    self.currentPage=sender.tag;
    [self reSetIndicaterColor];
    [self.delegate myPageControlClicked:sender.tag];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)dealloc{
    self.numberOfPages=nil;
    self.currentPage=nil;
    self.arrayMyIndicaters=nil;
    self.indicaterColor=nil;
    [super dealloc];
    
}

@end
