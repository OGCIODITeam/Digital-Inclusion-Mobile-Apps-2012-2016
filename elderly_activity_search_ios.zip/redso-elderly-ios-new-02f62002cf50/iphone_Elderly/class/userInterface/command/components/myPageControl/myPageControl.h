//
//  myPageControl.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-10-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//
 #import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
@class myPageControl;
@protocol myPageControlDelegate
  -(void)myPageControlClicked:(int)numberOfIndicater;
@end

@interface myPageControl : UIView
@property(nonatomic) NSInteger numberOfPages;          // default is 0
@property(nonatomic) NSInteger currentPage;            // default is 0. value pinned to 0..numberOfPages-1
@property(retain,nonatomic)UIColor *indicaterColor;
@property(nonatomic,assign)id <myPageControlDelegate>delegate;

@end
