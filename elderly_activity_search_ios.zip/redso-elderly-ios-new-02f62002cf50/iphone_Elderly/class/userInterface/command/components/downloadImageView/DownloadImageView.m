//
//  DownloadImageView.m
//  SVW_STAR
//
//  Created by fanty on 13-6-25.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import "DownloadImageView.h"

@implementation DownloadImageView
@synthesize loadingSize;
-(id)init{
    self=[super init];
    self.thumbnailSize=CGSizeZero;
    self.loadingSize=CGSizeMake(120.0f, 120.0f);
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    self.thumbnailSize=CGSizeZero;
    self.loadingSize=CGSizeMake(120.0f, 120.0f);
    return self;

}

-(void)imageDownloadedStatusChanged{
    
    if(self.status!=ImageViewDownloadedStatusFinish && self.status!=ImageViewDownloadedStatusNone){
        if(loadingView==nil){
            loadingView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            loadingView.color=[UIColor blackColor];
            [self addSubview:loadingView];
            [loadingView release];
        }
        [loadingView startAnimating];
    }
    else{
        [loadingView stopAnimating];
        [loadingView removeFromSuperview];
        loadingView=nil;
    }
}

-(void)layoutSubviews{
    [super layoutSubviews];
    CGRect rect=loadingView.frame;
    rect.size=self.loadingSize;
    rect.origin=CGPointMake((self.frame.size.width-rect.size.width)*0.5f, (self.frame.size.height-rect.size.height)*0.5f);
    loadingView.frame=rect;
}

@end
