//
//  DownloadImageView.h
//  SVW_STAR
//
//  Created by fanty on 13-6-25.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import "GTGZImageDownloadedView.h"

@interface DownloadImageView : GTGZImageDownloadedView{
    UIActivityIndicatorView* loadingView;
}

@property(nonatomic,assign) CGSize loadingSize;

@end
