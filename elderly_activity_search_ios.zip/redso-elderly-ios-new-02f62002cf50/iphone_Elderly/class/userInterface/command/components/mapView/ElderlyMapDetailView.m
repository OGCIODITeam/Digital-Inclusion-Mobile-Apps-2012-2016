//
//  ElderlyMapDetailView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-23.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyMapDetailView.h"
#import "ElderlyThemeManager.h"
#import <QuartzCore/QuartzCore.h>

@implementation ElderlyMapDetailView



- (id)initWithFrame:(CGRect)frame
{
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_box.png"];
    
    frame.size.height = img.size.height;
    frame.size.width = img.size.width;
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
       
        UIImageView* bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, img.size.width, img.size.height)];
        bgImageView.image = img;
        [self addSubview:bgImageView];
        [bgImageView release];
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 272, 20)];
        [titleLabel theme:@"mapDetailView"];
        titleLabel.numberOfLines = 0;
        [self addSubview:titleLabel];
        [titleLabel release];
        
        dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(titleLabel.frame)+5, 272, 20)];
        [dateLabel theme:@"mapDetailView"];
        [self addSubview:dateLabel];
        [dateLabel release];
        
        timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(dateLabel.frame)+5, 272, 20)];
        [timeLabel theme:@"mapDetailView"];
        [self addSubview:timeLabel];
        [timeLabel release];
        
        addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(timeLabel.frame)+5, 272, 20)];
        [addressLabel theme:@"mapDetailView"];
        addressLabel.numberOfLines = 0;
        [self addSubview:addressLabel];
        [addressLabel release];
        
//        endDate = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(addressLabel.frame)+5, 272, 20)];
//        [endDate theme:@"mapDetailView"];
//        [self addSubview:endDate];
//        [endDate release];

        registrationMethodLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(addressLabel.frame)+5, 272, 20)];
        [registrationMethodLabel theme:@"mapDetailView"];
        registrationMethodLabel.numberOfLines = 0;
        [self addSubview:registrationMethodLabel];
        [registrationMethodLabel release];
        
        
        UIImage* btnImg = [[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_detail_%@.png"];
        detailButton = [[UIButton alloc] initWithFrame:CGRectMake(img.size.width - btnImg.size.width - 10,img.size.height - btnImg.size.height*2.5 , btnImg.size.width, btnImg.size.height)];
        [detailButton setBackgroundImage:btnImg forState:UIControlStateNormal];
        [detailButton setAccessibilityLabel:lang(@"detail")];
        detailLable = [[UILabel alloc] initWithFrame:CGRectMake(3, 0, btnImg.size.width - 20, btnImg.size.height)];
        [detailLable theme:@"developmentsButton_Title"];
        detailLable.text = lang(@"detail");
        detailLable.textAlignment = UITextAlignmentCenter;
        [detailButton addSubview:detailLable];
        [detailLable release];
       
        [self addSubview:detailButton];
        [detailButton release];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)setTitle:(NSString*)value{
    titleLabel.text = [NSString stringWithFormat:@"%@：%@",lang(@"activityName"),value];
}


-(void)setDate:(NSString*)value{
    dateLabel.text = [NSString stringWithFormat:@"%@：%@",lang(@"date"),value];
}


-(void)setTime:(NSString*)value{
    timeLabel.text = [NSString stringWithFormat:@"%@：%@",lang(@"newActivityDetailSubTitle_price"),value];
}


//-(void)setEndDate:(NSString*)value{
//    endDate.text = [NSString stringWithFormat:@"%@：%@",lang(@"endRegDate"),value];
//}


-(void)setRegistration:(NSString*)value{
    registrationMethodLabel.text = [NSString stringWithFormat:@"%@：%@",lang(@"newActivityDetailSubTitle_registerMethod"),value];
    

    NSString* number = [ElderlyUtils getTelNumber:value];
    if(number != nil){
        if(registrationMethodCallTelButton == nil){
            registrationMethodCallTelButton = [[UIButton alloc] initWithFrame:registrationMethodLabel.frame];
            [self addSubview:registrationMethodCallTelButton];
            [registrationMethodCallTelButton release];
        }
 
        [registrationMethodCallTelButton setTitle:number forState:UIControlStateNormal];
        [registrationMethodCallTelButton setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        [registrationMethodCallTelButton setAccessibilityLabel:registrationMethodLabel.text];
        [registrationMethodCallTelButton addTarget:self action:@selector(callTelNumber:) forControlEvents:UIControlEventTouchUpInside];
    }
    

}

-(void)callTelNumber:(UIButton*)button{
 
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",button.titleLabel.text]]];
}

-(void)setAddress:(NSString*)value{
    addressLabel.text = [NSString stringWithFormat:@"%@：%@",lang(@"newActivityDetailSubTitle_time"),value];
    
    NSString* number = [ElderlyUtils getTelNumber:value];
    if(number != nil){
        if(addressCallTelButton == nil){
            addressCallTelButton = [[UIButton alloc] initWithFrame:addressLabel.frame];
            [self addSubview:addressCallTelButton];
            [addressCallTelButton release];
        }

        [addressCallTelButton setTitle:number forState:UIControlStateNormal];
        [addressCallTelButton setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        [addressCallTelButton setAccessibilityLabel:addressLabel.text];
        [addressCallTelButton addTarget:self action:@selector(callTelNumber:) forControlEvents:UIControlEventTouchUpInside];
    }
}

-(void)addTarget:(id)target action:(SEL)action{

     [detailButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
}

-(void)showAnimation{
    
    CAKeyframeAnimation * animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.27f;
    
    animation.removedOnCompletion = YES;
    animation.fillMode = kCAFillModeForwards;
    
    NSMutableArray *values = [NSMutableArray array];
    
    
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DConcat(CATransform3DMakeScale(0.1, 0.1, 1.0), CATransform3DMakeTranslation(0, self.frame.size.height*0.25, 0))]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.15, 1.15, 1.15)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.95, 0.95, 0.95)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    [self.layer addAnimation:animation forKey:nil];
    self.layer.transform=CATransform3DIdentity;
    
}

-(void)layoutSubviews{
     [super layoutSubviews];
    
    if(titleLabel.text.length > 0){
        [titleLabel sizeToFit];
       
    }
    dateLabel.frame = CGRectMake(10, CGRectGetMaxY(titleLabel.frame)+5, 272, 20);
    timeLabel.frame = CGRectMake(10, CGRectGetMaxY(dateLabel.frame)+5, 272, 20);
    addressLabel.frame = CGRectMake(10, CGRectGetMaxY(timeLabel.frame)+5, 272, 20);
    
    if(addressLabel.text.length > 0){
        [addressLabel sizeToFit];
        if(addressCallTelButton != nil){
            addressCallTelButton.frame = addressLabel.frame;
        }
    }
    
 
    
    if(registrationMethodLabel.text.length > 0){
    
        registrationMethodLabel.frame = CGRectMake(10, CGRectGetMaxY(addressLabel.frame)+5, 272, 20);
        [registrationMethodLabel sizeToFit];
        
        if(registrationMethodCallTelButton != nil){
            registrationMethodCallTelButton.frame = registrationMethodLabel.frame;
        }
    }


}


@end
