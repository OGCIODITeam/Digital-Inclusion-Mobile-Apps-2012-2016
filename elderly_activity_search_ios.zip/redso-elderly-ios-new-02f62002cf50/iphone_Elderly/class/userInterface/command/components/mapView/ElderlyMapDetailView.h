//
//  ElderlyMapDetailView.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-23.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ElderlyMapDetailView : UIView{
    
    UILabel* titleLabel;
    UILabel* dateLabel;
    UILabel* timeLabel;
    UILabel* addressLabel;
//    UILabel* endDate;
    UILabel* registrationMethodLabel;
    
    UIButton* detailButton;
    UILabel* detailLable;
    UIButton* addressCallTelButton;
    UIButton* registrationMethodCallTelButton;
}

-(void)setTitle:(NSString*)value;
-(void)setDate:(NSString*)value;
-(void)setTime:(NSString*)value;
//-(void)setEndDate:(NSString*)value;
-(void)setRegistration:(NSString*)value;
-(void)setAddress:(NSString*)value;
-(void)addTarget:(id)target action:(SEL)action;
-(void)showAnimation;

@end
