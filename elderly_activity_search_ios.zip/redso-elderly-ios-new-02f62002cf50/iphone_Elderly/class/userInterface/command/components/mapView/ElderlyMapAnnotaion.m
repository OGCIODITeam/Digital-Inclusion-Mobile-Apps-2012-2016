//
//  ElderlyMapAnnotaion.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-23.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyMapAnnotaion.h"

@interface ElderlyMapAnnotaion()

@property (nonatomic) CLLocationDegrees latitude;
@property (nonatomic) CLLocationDegrees longitude;

@end


@implementation ElderlyMapAnnotaion

@synthesize latitude = _latitude;
@synthesize longitude = _longitude;
@synthesize title;


- (id)initWithLatitude:(CLLocationDegrees)latitude
		  andLongitude:(CLLocationDegrees)longitude {
	if (self = [super init]) {
		self.latitude = latitude;
		self.longitude = longitude;
	}
	return self;
}

- (CLLocationCoordinate2D)coordinate {
	CLLocationCoordinate2D coordinate;
	coordinate.latitude = self.latitude;
	coordinate.longitude = self.longitude;
	return coordinate;
}

- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate {
	self.latitude = newCoordinate.latitude;
	self.longitude = newCoordinate.longitude;
}

-(void)dealloc{
    self.title=nil;
    [super dealloc];
}

@end
