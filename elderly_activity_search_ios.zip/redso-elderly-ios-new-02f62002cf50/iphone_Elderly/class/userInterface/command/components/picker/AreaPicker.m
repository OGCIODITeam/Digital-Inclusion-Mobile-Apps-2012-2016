//
//  AreaPicker.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "AreaPicker.h"
#import "iCarousel.h"
#import "ElderlyThemeManager.h"
#import "ButtonText.h"
#import <QuartzCore/QuartzCore.h>

@interface AreaPicker()<iCarouselDataSource,iCarouselDelegate>
-(void)btnCancel;
-(void)btnConfirm;
-(void)animationWithShow;
-(void)animationWithClose;
@end

@implementation AreaPicker
@synthesize list;
@synthesize selectedIndex;
@synthesize delegate;
@synthesize blackPanelFrame;
@synthesize pickerSize;
@synthesize animationWithPop;
@synthesize animationIsRun;
- (id)init{
    self=[super init];
    if(self){
        self.animationIsRun = NO;
        self.animationWithPop=YES;
        self.backgroundColor=[UIColor clearColor];
        self.userInteractionEnabled=YES;
        [self setAccessibilityViewIsModal:YES];
        
        panelBGView=[[UIView alloc] init];
        panelBGView.backgroundColor=[UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.8f];
        [self addSubview:panelBGView];
        [panelBGView release];
        
        bgView=[[UIImageView alloc] initWithImage:[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"picker_box.png"]];
        bgView.userInteractionEnabled=YES;
        [self addSubview:bgView];
        
        [bgView release];
        
        
        UIImage* cancelImg=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_cancel_%@.png"];
        cancelButton=[[ButtonText alloc] initWithFrame:CGRectMake(-0.5f, bgView.frame.size.height-cancelImg.size.height, cancelImg.size.width+0.7, cancelImg.size.height)];
        [cancelButton addTarget:self action:@selector(btnCancel) forControlEvents:UIControlEventTouchUpInside];
        cancelButton.spacing=5.0f;
        [cancelButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_cancel.png"]];
        [cancelButton text:lang(@"cancel")];
        [cancelButton theme:@"picker_button_label"];
        [cancelButton setBackgroundImage:cancelImg forState:UIControlStateNormal];
        
        UIImage* okImg=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_sure_%@.png"];
        confirmButton=[[ButtonText alloc] initWithFrame:CGRectMake(CGRectGetMaxX(cancelButton.frame)-0.5, bgView.frame.size.height-okImg.size.height, okImg.size.width+0.5, okImg.size.height)];
        [confirmButton addTarget:self action:@selector(btnConfirm) forControlEvents:UIControlEventTouchUpInside];
        confirmButton.spacing=5.0f;
        [confirmButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_sure.png"]];
        [confirmButton text:lang(@"confirm")];
        [confirmButton theme:@"picker_button_label"];
        [confirmButton setBackgroundImage:okImg forState:UIControlStateNormal];
        
        [bgView addSubview:cancelButton];
        [bgView addSubview:confirmButton];
        
        [cancelButton release];
        [confirmButton release];
        
        
        upArrow=[UIButton buttonWithType:UIButtonTypeCustom];
        
        UIImage* upImage=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"arrow_up.png"];
        CGRect rect=upArrow.frame;
        rect.size.width=upImage.size.width*4.0f;
        rect.size.height=upImage.size.height*3.0f;
        rect.origin.x=(bgView.frame.size.width-rect.size.width)*0.5f;
        upArrow.frame=rect;
        [upArrow setImage:upImage forState:UIControlStateNormal];
        [bgView addSubview:upArrow];
        
        downArrow=[UIButton buttonWithType:UIButtonTypeCustom];
        
        UIImage* downImage=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"arrow_down.png"];
        rect=downArrow.frame;
        rect.size.width=upImage.size.width*4.0f;
        rect.size.height=upImage.size.height*3.0f;
        rect.origin.x=(bgView.frame.size.width-rect.size.width)*0.5f;
        rect.origin.y=CGRectGetMinY(cancelButton.frame)-rect.size.height;
        downArrow.frame=rect;
        [downArrow setImage:downImage forState:UIControlStateNormal];
        [bgView addSubview:downArrow];
        

        
        picker=[[iCarousel alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(upArrow.frame), bgView.frame.size.width, CGRectGetMinY(downArrow.frame)-CGRectGetMaxY(upArrow.frame))];
        picker.type=iCarouselTypeLinear;
        picker.clipsToBounds=YES;
        picker.vertical=YES;
        picker.delegate=self;
        picker.dataSource=self;
        [bgView addSubview:picker];
        [picker release];
        
        selectedView=[[UIImageView alloc] initWithImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"area_selected_%@.png"]];
        rect=selectedView.frame;
        rect.size.height*=0.8f;
        rect.origin.x=(bgView.frame.size.width-rect.size.width)*0.5f;
        rect.origin.y=(bgView.frame.size.height-rect.size.height)*0.5f-20.0f;
        selectedView.frame=rect;
        [bgView addSubview:selectedView];
        [selectedView release];
    }
    
    return self;
}

-(void)dealloc{
    [list release];
    [super dealloc];
}


-(void)themeChanged{
    [confirmButton text:lang(@"confirm")];
    [confirmButton theme:@"picker_button_label"];
    
    [cancelButton text:lang(@"cancel")];
    [cancelButton theme:@"picker_button_label"];
    
    [cancelButton setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_cancel_%@.png"] forState:UIControlStateNormal];
    selectedView.image = [[ElderlyThemeManager sharedInstance] imageByMotif:@"area_selected_%@.png"];
    [confirmButton setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_sure_%@.png"] forState:UIControlStateNormal];
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    if(blackPanelFrame.size.width==0.0f && blackPanelFrame.size.height==0.0f){
        panelBGView.frame=self.bounds;
    }
    else{
        panelBGView.frame=blackPanelFrame;
    }
    
}

-(CGSize)pickerSize{
    return bgView.frame.size;
}

-(void)setList:(NSArray *)value{
    [list release];
    list=[value retain];
    [picker reloadData];
}

-(void)showInWindow{
    UIWindow* window=[UIApplication sharedApplication].keyWindow;
    
    self.frame=window.bounds;
    [window addSubview:self];
    
    bgView.center=self.center;
    
    [self animationWithShow];

}

-(void)showInView:(UIView*)view{
    self.frame = view.bounds;
    [view addSubview:self];
    
    CGRect rect = bgView.frame;
    rect.origin.x = (self.blackPanelFrame.size.width - rect.size.width)*0.5f;
    rect.origin.y = self.blackPanelFrame.origin.y + (self.blackPanelFrame.size.height - rect.size.height)*0.5f-([ElderlyUtils isRetain4]?78:0);
    bgView.frame = rect;
    
    
}

-(void)showInWindowWithPosition:(CGPoint)point{
    UIWindow* window=[UIApplication sharedApplication].keyWindow;
    
    self.frame=window.bounds;
    [window addSubview:self];
    
    CGRect frame=bgView.frame;
    frame.origin=point;
    bgView.frame=frame;
    
    [self animationWithShow];
}

-(void)showInView:(UIView *)view originFrame:(CGRect)originFrame destionFrame:(CGRect)destionFrame{
    self.frame = view.bounds;
    [view addSubview:self];

    panelBGView.frame=originFrame;
    
    CGRect frame=bgView.frame;
    frame.origin.x=originFrame.origin.x+(originFrame.size.width-frame.size.width)*0.5f;
    frame.origin.y=originFrame.origin.y+(originFrame.size.height-frame.size.height)*0.5f-([ElderlyUtils isRetain4]?78:0);
    bgView.frame=frame;

    [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^{
        panelBGView.frame=destionFrame;
        
        CGRect frame=bgView.frame;
        frame.origin.x=destionFrame.origin.x+(destionFrame.size.width-frame.size.width)*0.5f;
        frame.origin.y=destionFrame.origin.y+(destionFrame.size.height-frame.size.height)*0.5f-([ElderlyUtils isRetain4]?78:0);
        bgView.frame=frame;
        
    } completion:^(BOOL finish){
    
        
    }];
    
}

-(void)cancelImage:(UIImage*)cancelImage comfirmImage:(UIImage*)confirmImage{
    [cancelButton setBackgroundImage:cancelImage forState:UIControlStateNormal];
    [confirmButton setBackgroundImage:confirmImage forState:UIControlStateNormal];
}

-(void)setSelectedIndex:(int)value{
    UIButton* button=(UIButton*)[picker itemViewAtIndex:selectedIndex];
    [button theme:@"picker_button_button1"];
    selectedIndex=value;
    button=(UIButton*)[picker itemViewAtIndex:selectedIndex];
    [button theme:@"picker_button_button2"];
}

-(void)selectedView:(UIImage*)selectedImage{

    selectedView.image = selectedImage;
}

-(void)btnCancel{
    if([self.delegate respondsToSelector:@selector(didClickAreaPicker:confirm:)])
        [self.delegate didClickAreaPicker:self confirm:NO];
    
    [self animationWithClose];

}

-(void)btnConfirm{
    if([self.delegate respondsToSelector:@selector(didClickAreaPicker:confirm:)])
        [self.delegate didClickAreaPicker:self confirm:YES];

    [self animationWithClose];
}

-(void)animationWithShow{
    if(animationWithPop){
        
        panelBGView.alpha=0.0f;
        [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^{
            panelBGView.alpha=1.0f;
        } completion:^(BOOL finish){
        
        }];
        
        CAKeyframeAnimation * animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
        animation.duration = 0.5f;
        
        animation.removedOnCompletion = YES;
        animation.fillMode = kCAFillModeForwards;
        
        NSMutableArray *values = [NSMutableArray array];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.1, 1.1, 1.1)]];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 0.9)]];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
        animation.values = values;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
        [bgView.layer addAnimation:animation forKey:nil];
    }
    else{
        
        panelBGView.alpha=0.0f;
        [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^{
            panelBGView.alpha=1.0f;
        } completion:^(BOOL finish){
            
        }];
        
        CAKeyframeAnimation * animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        CGPoint point=bgView.layer.position;
        CGPoint nPoint=point;
        nPoint.y+=bgView.frame.size.height*2.0f;
        
        animation.duration = 0.2f;
        
        animation.removedOnCompletion = YES;
        animation.fillMode = kCAFillModeForwards;
        
        NSMutableArray *values = [NSMutableArray array];
        [values addObject:[NSValue valueWithCGPoint:nPoint]];
        [values addObject:[NSValue valueWithCGPoint:point]];
        animation.values = values;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
        [bgView.layer addAnimation:animation forKey:nil];
    }
}

-(void)animationWithClose{
    if(!self.animationIsRun){
        [self removeFromSuperview];
        return;
    }
    if(animationWithPop){
        CAKeyframeAnimation * animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
        animation.duration = 0.3f;
        
        animation.removedOnCompletion = YES;
        animation.fillMode = kCAFillModeForwards;
        
        NSMutableArray *values = [NSMutableArray array];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.2)]];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.8, 0.8, 0.8)]];
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
        
        animation.values = values;
        animation.delegate=self;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
        [bgView.layer addAnimation:animation forKey:nil];
        bgView.layer.transform=CATransform3DMakeScale(0.0, 0.0, 0.0);
    }
    else{
        CAKeyframeAnimation * animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        CGPoint point=bgView.layer.position;
        CGPoint nPoint=point;
        nPoint.y+=bgView.frame.size.height*2.0f;
        
        animation.duration = 0.2f;
        
        animation.removedOnCompletion = YES;
        animation.fillMode = kCAFillModeForwards;
        
        NSMutableArray *values = [NSMutableArray array];
        [values addObject:[NSValue valueWithCGPoint:point]];
        [values addObject:[NSValue valueWithCGPoint:nPoint]];
        animation.values = values;
        animation.delegate=self;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
        [bgView.layer addAnimation:animation forKey:nil];
        bgView.layer.position=nPoint;
    }
}

#pragma mark  icarousel delegate
- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return [list count];
}

- (BOOL)carouselShouldWrap:(iCarousel *)carousel{
    return YES;
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if(option==iCarouselOptionVisibleItems){
        return 5.0f;
    }
    return value;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index reusingView:(UIView *)view{
    
    UIButton* buttonView=nil;

    if (view == nil){
        buttonView=[UIButton buttonWithType:UIButtonTypeCustom];
        buttonView.frame=CGRectMake(0.0f, 0.0f, carousel.frame.size.width,40.0f);
        view=buttonView;
    }
    else{
        buttonView=(UIButton*)view;
    }
    
    NSString* title=[list objectAtIndex:index];
    [buttonView theme:@"picker_button_button1"];

    [buttonView setTitle:title forState:UIControlStateNormal];
    
	return view;
    
}


-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    self.selectedIndex=index;
}

- (void)carouselDidScroll:(iCarousel *)carousel{
    self.selectedIndex=carousel.currentItemIndex;
}

- (void)carouselDidEndDragging:(iCarousel *)carousel willDecelerate:(BOOL)decelerate{
    self.selectedIndex=carousel.currentItemIndex;

}

- (void)carouselDidEndDecelerating:(iCarousel *)carousel{
    self.selectedIndex=carousel.currentItemIndex;

}

#pragma mark  animation delegate


- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    [self removeFromSuperview];
}



@end
