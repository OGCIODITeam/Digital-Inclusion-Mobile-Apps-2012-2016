//
//  AreaPicker.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>



@class AreaPicker;
@class iCarousel;
@class ButtonText;

@protocol AreaPickerDelegate <NSObject>
-(void)didClickAreaPicker:(AreaPicker*)picker confirm:(BOOL)confirm;
@end


@interface AreaPicker : UIView{
    UIView* panelBGView;
    UIImageView* bgView;
    iCarousel* picker;
    
    ButtonText* cancelButton;
    ButtonText* confirmButton;
    
    UIButton* upArrow;
    UIButton* downArrow;
    
    
    UIImageView* selectedView;
    
    
}

@property(nonatomic,assign) BOOL animationIsRun;
@property(nonatomic,assign) BOOL animationWithPop;
@property(nonatomic,assign) CGRect blackPanelFrame;
@property(nonatomic,assign) int selectedIndex;
@property(nonatomic,retain) NSArray* list;
@property(nonatomic,assign) id<AreaPickerDelegate> delegate;
@property(nonatomic,readonly) CGSize pickerSize;
-(void)showInWindow;
-(void)showInView:(UIView*)view;
-(void)showInWindowWithPosition:(CGPoint)point;
-(void)showInView:(UIView *)view originFrame:(CGRect)frame destionFrame:(CGRect)frame;
-(void)cancelImage:(UIImage*)cancelImage comfirmImage:(UIImage*)confirmImage;
-(void)selectedView:(UIImage*)selectedImage;

-(void)themeChanged;
@end
