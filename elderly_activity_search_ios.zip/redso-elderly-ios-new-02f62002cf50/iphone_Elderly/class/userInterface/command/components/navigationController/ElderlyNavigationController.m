//
//  ElderlyNavigationController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyUtils.h"
#import <QuartzCore/QuartzCore.h>


#define CUSTOM_BAR_IMAGE_TAG   13

#define BAR_HEIGHT   44

@interface ElderlyBarButtonItem(private)

@end


@implementation ElderlyBarButtonItem

- (id)initWithImage:(NSString*)themeImage right:(BOOL)right target:(id)_target action:(SEL)_action{
    
    self=[super init];
    UIView* bgView = [[UIView alloc]  initWithFrame:CGRectMake(-10, 0, BAR_HEIGHT, BAR_HEIGHT)];
    UIImage* image=[[ElderlyThemeManager sharedInstance] imageByTheme:themeImage];
    UIButton* button=[UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:image forState:UIControlStateNormal];
    
    float spacing = 6;
    if([ElderlyUtils systemVersion] >= 7.0){
        spacing = 17;
    }
    
    NSString* accessibitilyTitle = lang(@"back");
    if(right){
        accessibitilyTitle = lang(@"setting");
        if([themeImage isEqualToString:@"btn_location.png"]){
            accessibitilyTitle = lang(@"GPS");
        }
    }
    [button setAccessibilityLabel:accessibitilyTitle];

    
    CGRect rect=CGRectMake((right?spacing:-spacing), 0, image.size.width, image.size.height);
    
    button.frame=rect;
    if(_target!=nil && _action!=nil)
        [button addTarget:_target action:_action forControlEvents:UIControlEventTouchUpInside];
    
    button.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [bgView addSubview:button];
    self.customView=bgView;
    CGRect rect1 =  self.customView.frame;
    rect1.origin.x = -10;
    self.customView.frame = rect1;
    [bgView release];
    return self;
}


@end




@interface ElderlyNavigationController ()

@end

@implementation ElderlyNavigationController



-(id)initWithRootViewController:(UIViewController*)viewController{
    self=[super initWithRootViewController:viewController];
    if (self) {
        self.delegate=self;
    }
    return self;
    
}

- (id)init{
    self = [super init];
    if (self) {
        self.delegate=self;
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    if([ElderlyUtils isRetain4]){
        CGRect frame=self.view.frame;
        frame.size.height+=(640-480);
        self.view.frame=frame;
    }

    
    if( [[[UIDevice currentDevice] systemVersion] floatValue]<6.0){   //ios 5 以下
        
        backgroundImage=[[UIImageView alloc] initWithFrame:self.navigationBar.bounds];
        backgroundImage.backgroundColor=[UIColor clearColor];
        backgroundImage.autoresizingMask  = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        
        //        EBayImageView* lineView=[[EBayImageView alloc] initWithImage:[EBayThemeManager imageByTheme:@"breakline.png"]];
        //
        //        CGRect rect=lineView.frame;
        //        rect.origin.y=backgroundImage.frame.size.height;
        //        rect.size.width=backgroundImage.frame.size.width;
        //        lineView.frame=rect;
        //
        //        [backgroundImage addSubview:lineView];
        //        [lineView release];
        
        [self.navigationBar addSubview:backgroundImage];
        [backgroundImage release];
        
        backgroundImage.layer.shadowColor=[[UIColor blackColor] CGColor];
        backgroundImage.layer.shadowOpacity=0.5f;
        backgroundImage.layer.shadowOffset=CGSizeMake(0, -0.8);
        
     
        
        
    }
    
    if(label == nil){
        label=[[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width-244)*0.5, 7, 244, 30)];
        label.numberOfLines=1;
        label.textAlignment=NSTextAlignmentCenter;
        [label theme:@"nav_title"];
        [self.navigationBar addSubview:label];
        
        [label release];
    }
    
  //  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeChanged) name:NotificationThemeChanged object:nil];
    
}

-(void)dealloc{
    [bgImage release];
    [text release];
    [super dealloc];
}

-(void)themeChanged{
    UIImage* image=[[ElderlyThemeManager sharedInstance] imageByTheme:bgImage];
    if( [[[UIDevice currentDevice] systemVersion] floatValue]<5.0){   //ios 5 以下
        backgroundImage.image=image;
       
        [self.navigationBar sendSubviewToBack:backgroundImage];
    }
    else{
        
        [self.navigationBar setBackgroundImage:image forBarMetrics:( (self.interfaceOrientation==UIInterfaceOrientationPortrait || self.interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown)? UIBarMetricsDefault:UIBarMetricsLandscapePhone )];
        

    }
   
    [label theme:@"nav_title"];
    label.text = text;
    
    
}

- (void)viewDidUnload{
    [super viewDidUnload];
    
  //  [[NSNotificationCenter defaultCenter] removeObserver:self name:NotificationThemeChanged object:nil];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void)titleView:(NSString*)value{

    [text release];
    text = [value retain];
    [self themeChanged];

}

-(void)barBackground:(NSString*) image{
    [bgImage release];
    bgImage=[image retain];
    [self themeChanged];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [self.navigationBar sendSubviewToBack:backgroundImage];
    
    if([viewController respondsToSelector:@selector(willShowViewController)])
        [viewController performSelector:@selector(willShowViewController)];
}

- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [self.navigationBar sendSubviewToBack:backgroundImage];
    if([viewController respondsToSelector:@selector(didShowViewController)])
        [viewController performSelector:@selector(didShowViewController)];
    
}

@end
