//
//  ExpandSectionTableViewCell.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 8/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ExpandSectionTableViewCell.h"

@interface ExpandSectionTableViewCell()

@property (retain, nonatomic) UILabel *titleLabel;
@property (retain, nonatomic) UILabel *subTitleLabel;
@property (retain, nonatomic) UIImageView *bgImageView;
@property (retain, nonatomic) UIImageView *arrowImageView;
@property (retain, nonatomic) UIImage *arrowImageOpen;
@property (retain, nonatomic) UIImage *arrowImageClose;

@end

@implementation ExpandSectionTableViewCell
@synthesize titleLabel;
@synthesize subTitleLabel;
@synthesize bgImageView;
@synthesize arrowImageView;
@synthesize arrowImageOpen;
@synthesize arrowImageClose;

- (void)dealloc
{
    self.titleLabel = nil;
    self.subTitleLabel = nil;
    self.bgImageView = nil;
    self.arrowImageView = nil;
    self.arrowImageOpen = nil;
    self.arrowImageClose = nil;
    [super dealloc];
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.frame = CGRectMake(0, 0, 320, 60);
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        NSLog(@"initWithStyle  >>>  NSStringFromCGRect   >>>> %@ ", NSStringFromCGRect(self.frame));
        
        CGRect bgFrame = self.frame;
        bgFrame.origin = CGPointZero;
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:bgFrame];
//        imageView.image = [UIImage imageNamed:@"bg_top_green.png"];
        [self addSubview:imageView];
        self.bgImageView = imageView;
        [imageView release];
        
        
        UIImage *arrowImage = [UIImage imageNamed:@"btn_green_up.png"];
        CGRect arrowFrame = CGRectMake(self.frame.size.width - arrowImage.size.width, 0, arrowImage.size.width, arrowImage.size.height);
        UIImageView *tmpArrowImageView = [[UIImageView alloc] initWithFrame:arrowFrame];
        tmpArrowImageView.center = CGPointMake(tmpArrowImageView.center.x, self.frame.size.height/2);
        tmpArrowImageView.image = arrowImage;
        [self addSubview:tmpArrowImageView];
        self.arrowImageView = tmpArrowImageView;
        [tmpArrowImageView release];
        
        
        CGRect titleFrame = CGRectMake(15, 10, tmpArrowImageView.frame.origin.x - 15, 20);
        UILabel *tmpTitleLabel = [[UILabel alloc] initWithFrame:titleFrame];
        [tmpTitleLabel theme:@"myActivityCellTitle"];
        [self addSubview:tmpTitleLabel];
        self.titleLabel = tmpTitleLabel;
        [tmpTitleLabel release];
        
        
        CGRect subTitleFrame = CGRectMake(15, 30, tmpArrowImageView.frame.origin.x - 15, 20);
        UILabel *tmpSubTitleLabel = [[UILabel alloc] initWithFrame:subTitleFrame];
        [tmpSubTitleLabel theme:@"myActivityCellTitle"];
        [self addSubview:tmpSubTitleLabel];
        self.subTitleLabel = tmpSubTitleLabel;
        [tmpSubTitleLabel release];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)setSectionTitle:(NSString*) title{
    self.titleLabel.text = title;
}
- (void)setSectionSubTitle:(NSString*) subTitle{
    self.subTitleLabel.text = subTitle;
}
- (void)setBackgroundImage:(UIImage*) backgroundImage{
    self.bgImageView.image = backgroundImage;
}

- (void)setExpand:(UIImage*) image forStatus:(ExpandSectionTableViewCellStatus) status{
    if (status == ExpandSectionTableViewCellStatusOpen) {
        self.arrowImageOpen = image;
    }else{
        self.arrowImageClose = image;
    }
}

- (void)setExpandSectionTableViewCellStatus:(ExpandSectionTableViewCellStatus) status{
    if (status == ExpandSectionTableViewCellStatusOpen) {
        self.arrowImageView.image = self.arrowImageOpen;
    }else{
        self.arrowImageView.image = self.arrowImageClose;
    }
}

-(void)layoutSubviews{
    [super layoutSubviews];
    self.titleLabel.frame =  CGRectMake(15, 10, self.titleLabel.frame.size.width, 20);
    self.subTitleLabel.frame = CGRectMake(15, 30, self.subTitleLabel.frame.size.width, 20);
    
    if(self.titleLabel.text.length < 1 ){
        CGRect rect = self.subTitleLabel.frame;
        rect.origin.y = (self.frame.size.height - rect.size.height)*0.5f;
        self.subTitleLabel.frame = rect;
    }
    
    if(self.subTitleLabel.text.length < 1){
        CGRect rect = self.titleLabel.frame;
        rect.origin.y = (self.frame.size.height - rect.size.height)*0.5f;
        self.titleLabel.frame = rect;
    }

}

@end
