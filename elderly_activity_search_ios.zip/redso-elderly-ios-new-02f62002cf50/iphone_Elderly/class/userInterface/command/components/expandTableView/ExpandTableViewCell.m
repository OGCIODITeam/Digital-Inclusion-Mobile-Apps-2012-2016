//
//  ExpandTableViewCell.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 8/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ExpandTableViewCell.h"

@interface ExpandTableViewCell()

@property (retain, nonatomic) UILabel *expandTitleLabel;
@property (retain, nonatomic) UILabel *typeLabel;
@property (retain, nonatomic) UILabel *dateLabel;
@property (retain, nonatomic) UILabel *timeLabel;
@property (retain, nonatomic) UILabel *priceLabel;
@property (retain, nonatomic) UILabel *placeLabel;
@end

@implementation ExpandTableViewCell
@synthesize expandTitleLabel;
@synthesize typeLabel;
@synthesize dateLabel;
@synthesize timeLabel;
@synthesize priceLabel;
@synthesize placeLabel;

- (void)dealloc
{
    self.expandTitleLabel = nil;
    self.typeLabel = nil;
    self.dateLabel = nil;
    self.timeLabel = nil;
    self.priceLabel = nil;
    self.placeLabel = nil;
    [super dealloc];
}

- (id)initWithCellType:(ExpandTableViewCellStyle) cellType reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (self) {
        if (cellType==ExpandTableViewCellStyleCenter) {
            self.frame = CGRectMake(0, 0, 320, 110);
        }else{
            self.frame = CGRectMake(0, 0, 320, 130);
        }
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImage *arrowImage = [UIImage imageNamed:@"btn_more.png"];
        CGRect arrowFrame = CGRectMake(self.frame.size.width - arrowImage.size.width, 0, arrowImage.size.width, arrowImage.size.height);
        UIImageView *arrowImageView = [[UIImageView alloc] initWithImage:arrowImage];
        arrowImageView.frame = arrowFrame;
        arrowImageView.center = CGPointMake(arrowImageView.center.x, self.frame.size.height/2);
        [self addSubview:arrowImageView];
        [arrowImageView release];
        
        
        CGRect tmpTitleFrame = CGRectMake(15, 8, arrowImageView.frame.origin.x - 15, 20);
        UILabel *tmpTitleLabel = [[UILabel alloc] initWithFrame:tmpTitleFrame];
        [tmpTitleLabel theme:@"myActivitySubCellTitle"];
        [self addSubview:tmpTitleLabel];
        self.expandTitleLabel = tmpTitleLabel;
        [tmpTitleLabel release];
        
        
        float infoLabelHeight = 16;
        float textY = CGRectGetMaxY(tmpTitleLabel.frame) + 8;
        
        if (cellType==ExpandTableViewCellStyleCenter) {
            CGRect typeFrame = CGRectMake(15, textY, arrowImageView.frame.origin.x - 15, infoLabelHeight);
            UILabel *tmpTypeLabel = [[UILabel alloc] initWithFrame:typeFrame];
            [tmpTypeLabel theme:@"myActivitySubCellInfo"];
            [self addSubview:tmpTypeLabel];
            self.typeLabel = tmpTypeLabel;
            [tmpTypeLabel release];
            textY = CGRectGetMaxY(tmpTypeLabel.frame) + 3;
        }
        
        CGRect dateFrame = CGRectMake(15, textY, arrowImageView.frame.origin.x - 15, infoLabelHeight);
        UILabel *tmpDateLabel = [[UILabel alloc] initWithFrame:dateFrame];
        [tmpDateLabel theme:@"myActivitySubCellInfo"];
        [self addSubview:tmpDateLabel];
        self.dateLabel = tmpDateLabel;
        [tmpDateLabel release];
        
        CGRect timeFrame = CGRectMake(15, CGRectGetMaxY(tmpDateLabel.frame) + 3, arrowImageView.frame.origin.x - 15, infoLabelHeight);
        UILabel *tmpTimeLabel = [[UILabel alloc] initWithFrame:timeFrame];
        [tmpTimeLabel theme:@"myActivitySubCellInfo"];
        [self addSubview:tmpTimeLabel];
        self.timeLabel = tmpTimeLabel;
        [tmpTimeLabel release];
        
        
        float y = CGRectGetMaxY(tmpTimeLabel.frame) + 3;
        if (cellType==ExpandTableViewCellStyleLCSD) {
            CGRect placeFrame = CGRectMake(15, y, arrowImageView.frame.origin.x - 15, infoLabelHeight);
            UILabel *tmpPlaceLabel = [[UILabel alloc] initWithFrame:placeFrame];
            [tmpPlaceLabel theme:@"myActivitySubCellInfo"];
            [self addSubview:tmpPlaceLabel];
            self.placeLabel = tmpPlaceLabel;
            [tmpPlaceLabel release];
            
            y = CGRectGetMaxY(tmpPlaceLabel.frame) + 3;
        }
        
        
        
        CGRect priceFrame = CGRectMake(15, y, arrowImageView.frame.origin.x - 15, infoLabelHeight);
        UILabel *tmpPriceLabel = [[UILabel alloc] initWithFrame:priceFrame];
        [tmpPriceLabel theme:@"myActivitySubCellInfo"];
        [self addSubview:tmpPriceLabel];
        self.priceLabel = tmpPriceLabel;
        [tmpPriceLabel release];
        
        
        NSLog(@"priceFrame  >>>  %@", NSStringFromCGRect(priceFrame));
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setExpandTitle:(NSString*) title{
    self.expandTitleLabel.text = title;
}
- (void)setType:(NSString*) type{
    if (type.length==0) {
        type = lang(@"noContent");
    }
    self.typeLabel.text = [NSString stringWithFormat:@"%@：%@", lang(@"activity_type"), type];
}

- (void)setDate:(NSArray*) dateList{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    
    
    NSMutableArray *list = [[NSMutableArray alloc] init];
    for (int i=0; i<dateList.count; i++) {
        NSString *dateStr = [dateList objectAtIndex:i];
        dateFormatter.dateFormat = @"yyyy-MM-dd";
        NSDate *date = [dateFormatter dateFromString:dateStr];
        dateFormatter.dateFormat = lang(@"dateFormat");
        dateStr = [dateFormatter stringFromDate:date];
        [list addObject:dateStr];
    }
    if (list.count==0) {
        self.dateLabel.text=@"";
    }else if(list.count==1){
        self.dateLabel.text = [NSString stringWithFormat:@"%@：%@", lang(@"newActivityDetailSubTitle_date"), [list objectAtIndex:0]];
     }else{
        self.dateLabel.text = [NSString stringWithFormat:@"%@：%@ - %@", lang(@"newActivityDetailSubTitle_date"), [list objectAtIndex:0],[list lastObject]];
    }
 
    
    [list release];
    [dateFormatter release];
}

- (void)setStartDate:(NSString*) startDateStr endDate:(NSString*) endDateStr{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd";
    
    NSDate *startDate = [dateFormatter dateFromString:startDateStr];
    NSDate *endDate = [dateFormatter dateFromString:endDateStr];
    
    dateFormatter.dateFormat = lang(@"dateFormat");
    
    NSString *startDateStrDisplay = [dateFormatter stringFromDate:startDate];
    NSString *endDateStrDisplay = [dateFormatter stringFromDate:endDate];
    
    self.dateLabel.text = [NSString stringWithFormat:@"%@：%@ - %@", lang(@"newActivityDetailSubTitle_date"), startDateStrDisplay, endDateStrDisplay];
    [dateFormatter release];
}

- (void)setTimeFrom:(NSString*) fromTime to:(NSString*) toTime{
    self.timeLabel.text = [NSString stringWithFormat:@"%@：%@ - %@", lang(@"newActivityDetailSubTitle_price"), fromTime, toTime];
}
- (void)setPrice:(NSString*) price{
    if (!price){
        self.placeLabel.hidden=YES;
    }else if(![price integerValue]) {
        self.priceLabel.text =[NSString stringWithFormat:@"%@：%@",lang(@"newActivityDetailSubTitle_address"),lang(@"free")];
    }else{
    self.priceLabel.text = [NSString stringWithFormat:@"%@：＄%@", lang(@"newActivityDetailSubTitle_address"), price];
    }
}
- (void)setPlace:(NSString*) place{
    self.placeLabel.text = [NSString stringWithFormat:@"%@：%@", lang(@"newActivityDetailSubTitle_time"), place];
}

- (void)hidPrice:(BOOL) hid{
//    NSLog(@"self.placeLabel.frame.size.height  >>>  %f", self.placeLabel.frame.size.height);
    if (hid) {
        self.placeLabel.hidden = YES;
    }else{
        self.placeLabel.hidden = NO;
    }
}

@end
