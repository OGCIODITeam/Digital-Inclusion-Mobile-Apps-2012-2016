//
//  ExpandTableView.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 7/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ExpandTableView;

@protocol ExpandTableViewDelegate <NSObject>

- (NSInteger)numberOfSectionsInTableView:(ExpandTableView *)tableView;

- (NSInteger)tableView:(ExpandTableView *)tableView numberOfRowsInSection:(NSInteger)section;

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;

- (CGFloat)tableView:(UITableView *)tableView heightForSection:(NSInteger)section;

- (UITableViewCell *)tableView:(ExpandTableView *)tableView sectionViewAtSection:(NSInteger) section;

- (UITableViewCell *)tableView:(ExpandTableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;



@optional
- (void)onReloadData:(UITableView *)tableView;
- (void)onRowNumberChange:(UITableView *)tableView;
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath;

- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)onLongPassWithIndexPaht:(NSIndexPath*) indexPath;

@end

@interface ExpandTableView : UITableView<UITableViewDataSource, UITableViewDelegate>

@property (assign, nonatomic) id<ExpandTableViewDelegate> expandDelegate;

- (void)deleteRowsAtIndexPath:(NSIndexPath *)indexPath withRowAnimation:(UITableViewRowAnimation)animation;

@end
