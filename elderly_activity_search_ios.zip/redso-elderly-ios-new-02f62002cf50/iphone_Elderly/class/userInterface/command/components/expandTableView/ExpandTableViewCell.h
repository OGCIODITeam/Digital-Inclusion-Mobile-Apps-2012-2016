//
//  ExpandTableViewCell.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 8/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, ExpandTableViewCellStyle) {
    ExpandTableViewCellStyleCenter = 0,
    ExpandTableViewCellStyleLCSD = 1,
};

@interface ExpandTableViewCell : UITableViewCell

- (id)initWithCellType:(ExpandTableViewCellStyle) cellType reuseIdentifier:(NSString *)reuseIdentifier;

- (void)setExpandTitle:(NSString*) title;
- (void)setType:(NSString*) type;
- (void)setDate:(NSArray*) dateList;
- (void)setStartDate:(NSString*) startDateStr endDate:(NSString*) endDateStr;
- (void)setTimeFrom:(NSString*) fromTime to:(NSString*) toTime;
- (void)setPrice:(NSString*) price;
- (void)setPlace:(NSString*) place;
- (void)hidPrice:(BOOL) hid;

@end
