//
//  ExpandTableView.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 7/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ExpandTableView.h"
#import "ElderlyThemeManager.h"
#import "ExpandSectionTableViewCell.h"

@interface ExpandModle : NSObject

@property (assign, nonatomic) NSInteger type;  //1 title 2 detail
@property (retain, nonatomic) NSIndexPath *expandIndexPath;
@property (assign, nonatomic) BOOL isExpanded;
@property (assign, nonatomic) NSInteger totalSubCell;


@end

@implementation ExpandModle

@synthesize type;
@synthesize expandIndexPath;
@synthesize isExpanded;
@synthesize totalSubCell;


- (void)dealloc
{
    self.expandIndexPath = nil;
    
    [super dealloc];
}

@end

@interface ExpandTableView()

@property (retain, nonatomic) NSMutableArray *expandModleList;


@end

@implementation ExpandTableView
@synthesize expandDelegate;
@synthesize expandModleList;


- (void)dealloc
{
    self.expandDelegate = nil;
    self.expandModleList = nil;
    
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.delegate = self;
        self.dataSource = self;
        
        NSMutableArray *list = [[NSMutableArray alloc] init];
        self.expandModleList = list;
        [list release];
        
        
        UILongPressGestureRecognizer * longPressGr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressToDo:)];
        longPressGr.minimumPressDuration = 0.5;
        [self addGestureRecognizer:longPressGr];
        [longPressGr release];
        
    }
    return self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    int total = 0;
    if (self.expandModleList.count>0) {
        total = self.expandModleList.count;
    }else{
        total = [self.expandDelegate numberOfSectionsInTableView:self];
        for (int i=0; i<total; i++) {
            ExpandModle *model = [[ExpandModle alloc] init];
            model.type = 0;
            model.expandIndexPath = [NSIndexPath indexPathForRow:0 inSection:i];
            [self.expandModleList addObject:model];
            [model release];
            
        }
    }
    
    
    return total;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = nil;
    ExpandModle *model = [self.expandModleList objectAtIndex:indexPath.row];
    //NSLog(@"row >>>   %d  model.type  >>>  %d", indexPath.row, model.type);
    if (model.type==0) {
        cell = [self.expandDelegate tableView:self sectionViewAtSection:model.expandIndexPath.section];
        ExpandSectionTableViewCell *expCell = (ExpandSectionTableViewCell*)cell;
        if (model.isExpanded) {
            [expCell setExpandSectionTableViewCellStatus:ExpandSectionTableViewCellStatusOpen];
        }else{
            [expCell setExpandSectionTableViewCellStatus:ExpandSectionTableViewCellStatusClose];
        }
    }else{
        cell = [self.expandDelegate tableView:self cellForRowAtIndexPath:model.expandIndexPath];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    float height = 0;
    ExpandModle *model = [self.expandModleList objectAtIndex:indexPath.row];
    
    if (model.type==0) {
        height = [self.expandDelegate tableView:self heightForSection:model.expandIndexPath.section];
    }else{
        height = [self.expandDelegate tableView:self heightForRowAtIndexPath:model.expandIndexPath];
    }
    return height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ExpandModle *model = [self.expandModleList objectAtIndex:indexPath.row];
    if (model.type==0) {
        if (model.isExpanded==YES){
            model.isExpanded = NO;
            
            ExpandSectionTableViewCell *expCell = (ExpandSectionTableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
            [expCell setExpandSectionTableViewCellStatus:ExpandSectionTableViewCellStatusClose];
            
           
            
            if (model.totalSubCell>0) {
                NSMutableArray *rows = [[NSMutableArray alloc] init];
                NSMutableArray *models = [[NSMutableArray alloc] init];
                
                int index = indexPath.row+1;
                ExpandModle *subModle = [self.expandModleList objectAtIndex:index];
                while (subModle.type==1) {
                    [models addObject:subModle];
                    NSIndexPath *subIndexPath = [NSIndexPath indexPathForRow:index inSection:indexPath.section];
                    [rows addObject:subIndexPath];
                    index++;
                    if (index<self.expandModleList.count) {
                        subModle = [self.expandModleList objectAtIndex:index];
                    }else{
                        break;
                    }
                    
                }
                
                [self.expandModleList removeObjectsInArray:models];
                [tableView deleteRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationFade];
                
                [models release];
                [rows release];
                
                if ([self.expandDelegate respondsToSelector:@selector(onRowNumberChange:)]) {
                    [self.expandDelegate performSelector:@selector(onRowNumberChange:) withObject:nil];
                }
            }
            
            
        }else{
            model.isExpanded = YES;
            
            ExpandSectionTableViewCell *expCell = (ExpandSectionTableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
            [expCell setExpandSectionTableViewCellStatus:ExpandSectionTableViewCellStatusOpen];
            
            NSInteger totalSub = [self.expandDelegate tableView:self numberOfRowsInSection:model.expandIndexPath.section];
            if (totalSub>0) {
                model.totalSubCell = totalSub;
                NSMutableArray *rows = [[NSMutableArray alloc] init];
                
                int index = indexPath.row + 1;
                for (int i=0; i<totalSub; i++) {
                    
                    NSIndexPath *subIndexPath = [NSIndexPath indexPathForRow:index inSection:indexPath.section];
                    [rows addObject:subIndexPath];
                    
                    
                    
                    ExpandModle *tmpModel = [[ExpandModle alloc] init];
                    tmpModel.type = 1;
                    tmpModel.expandIndexPath = [NSIndexPath indexPathForRow:i inSection:model.expandIndexPath.section];
                    NSLog(@"tmpModel.expandIndexPath  >>>  %@", tmpModel.expandIndexPath);
                    [self.expandModleList insertObject:tmpModel atIndex:index];
                    [tmpModel release];
                    
                    index++;
                }
                
                
                
                [tableView insertRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationFade];
                
                if ([self.expandDelegate respondsToSelector:@selector(onRowNumberChange:)]) {
                    [self.expandDelegate performSelector:@selector(onRowNumberChange:) withObject:nil];
                }
                
                [rows release];
            }
        }
       
        
    }else{
        if (self.expandDelegate!=nil) {
            [self.expandDelegate tableView:self didSelectRowAtIndexPath:model.expandIndexPath];
        }
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if ([self.expandDelegate respondsToSelector:@selector(scrollViewDidScroll:)]) {
        [self.expandDelegate performSelector:@selector(scrollViewDidScroll:) withObject:scrollView];
    }
}

- (void)reloadData{
    [self.expandModleList removeAllObjects];
    [super reloadData];
    
    if ([self.expandDelegate respondsToSelector:@selector(onReloadData:)]) {
        [self.expandDelegate performSelector:@selector(onReloadData:) withObject:nil];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([self.expandDelegate respondsToSelector:@selector(tableView:canEditRowAtIndexPath:)]) {
        
        ExpandModle *model = [self.expandModleList objectAtIndex:indexPath.row];
        if (model.type==0) {
            return NO;
        }else{
            return [self.expandDelegate performSelector:@selector(tableView:canEditRowAtIndexPath:) withObject:tableView withObject:model.expandIndexPath];
        }
        
        
    }else{
        return NO;
    }
    
}

- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    ExpandModle *model = [self.expandModleList objectAtIndex:indexPath.row];
    if ([self.expandDelegate respondsToSelector:@selector(tableView:commitEditingStyle:forRowAtIndexPath:)]) {
        [self.expandDelegate tableView:aTableView commitEditingStyle:editingStyle forRowAtIndexPath:model.expandIndexPath];
    }
    
}

- (void)deleteRowsAtIndexPath:(NSIndexPath *)indexPath withRowAnimation:(UITableViewRowAnimation)animation{
    
    NSIndexPath *deleteIndexPath = nil;
    ExpandModle *deleteModel = nil;
    ExpandModle *sectionModel = nil;
    int sectionRow;
    
    for (int i=0; i<self.expandModleList.count; i++) {
        ExpandModle *model = [self.expandModleList objectAtIndex:i];
        if (model.type==0) {
            sectionModel = model;
            sectionRow = i;
        }else{
            if ([model.expandIndexPath isEqual:indexPath]) {
                deleteIndexPath =[NSIndexPath indexPathForRow:i inSection:0];
                deleteModel = model;
                
                break;
            }
        }
        
    }
    
    int lastRow = deleteIndexPath.row;
    int index = deleteIndexPath.row+1;
    if (index < self.expandModleList.count) {
        ExpandModle *subModle = [self.expandModleList objectAtIndex:index];
        while (subModle.type==1) {
            int tmpRow = subModle.expandIndexPath.row;
            int tmpSection = subModle.expandIndexPath.section;
            subModle.expandIndexPath = [NSIndexPath indexPathForRow:tmpRow-1 inSection:tmpSection];
            lastRow = tmpRow;
            index++;
            if (index<self.expandModleList.count) {
                subModle = [self.expandModleList objectAtIndex:index];
            }else{
                break;
            }
        }
    }
    
    
    [self.expandModleList removeObject:deleteModel];
    
    NSMutableArray *deleteArray = [[[NSMutableArray alloc] init] autorelease];
    [deleteArray addObject:deleteIndexPath];
    
    sectionModel.totalSubCell = sectionModel.totalSubCell - 1;
    
    if (sectionModel.totalSubCell==0) {
        [self.expandModleList removeObject:sectionModel];
        [deleteArray addObject:[NSIndexPath indexPathForRow:sectionRow inSection:0]];
    }
    
    
    
    [self deleteRowsAtIndexPaths:deleteArray withRowAnimation:animation];
}


- (void)longPressToDo:(UILongPressGestureRecognizer *)gesture{
    DLog(@" longPressToDo >>> sender >>>  %@", gesture);
    if(gesture.state == UIGestureRecognizerStateBegan)
    {
        CGPoint point = [gesture locationInView:self];
        NSIndexPath * indexPath = [self indexPathForRowAtPoint:point];
        
        ExpandModle *model = [self.expandModleList objectAtIndex:indexPath.row];
        if (model.type==1) {
            if ([self.expandDelegate respondsToSelector:@selector(onLongPassWithIndexPaht:)]) {
                [self.expandDelegate performSelector:@selector(onLongPassWithIndexPaht:) withObject:model.expandIndexPath];
            }
        }
        
    }
}


@end
