//
//  ExpandSectionTableViewCell.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 8/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

typedef NS_ENUM(NSInteger, ExpandSectionTableViewCellStatus) {
    ExpandSectionTableViewCellStatusOpen = 0,
    ExpandSectionTableViewCellStatusClose = 1,
};

#import <UIKit/UIKit.h>
//#define ExpandSectionTableViewCellOpen 1;
//#define ExpandSectionTableViewCellClose 0;

@interface ExpandSectionTableViewCell : UITableViewCell

- (void)setSectionTitle:(NSString*) title;
- (void)setSectionSubTitle:(NSString*) subTitle;
- (void)setBackgroundImage:(UIImage*) backgroundImage;
- (void)setExpand:(UIImage*) image forStatus:(ExpandSectionTableViewCellStatus) status;
- (void)setExpandSectionTableViewCellStatus:(ExpandSectionTableViewCellStatus) status;
@end
