//
//  GuideView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "GuideView.h"
#import "ElderlyThemeManager.h"

@implementation GuideView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        bgView = [[UIImageView alloc] initWithFrame:CGRectZero];
        bgView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_picker_box.png"];
        bgView.hidden = YES;
        [self addSubview:bgView];
        [bgView release];
        
//        [self setAccessibilityViewIsModal:YES];
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)addView:(UIView*)view{

   
    [self addSubview:view];
    
    if(self.bounds.size.height > view.bounds.size.height){
        CGRect rect = self.bounds;
        rect.origin.y = view.bounds.size.height;
        rect.size.height = self.bounds.size.height - view.bounds.size.height;
        bgView.frame = rect;
        bgView.hidden = NO;
    }
    else{
        bgView.hidden = YES;

    }
}

-(void)addImageView:(UIImage*)img{

    UIImageView* imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, img.size.width, img.size.height)];
    imageView.image = img;
    [self addSubview:imageView];
    [imageView release];
    
    if(self.bounds.size.height > img.size.height){
        CGRect rect = self.bounds;
        rect.origin.y = img.size.height;
        rect.size.height = self.bounds.size.height - img.size.height;
        bgView.frame = rect;
        bgView.hidden = NO;
    
    }
    else{
    
        bgView.hidden = YES;
    }

    
}

-(void)setGuideOrignY:(float)y{
    orignY = y;
    
    [self startAnimation];
}

-(float)getGuideOrignY{

    return orignY;
}

-(void)startAnimation{

    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        
        CGRect rect = self.frame;
        rect.origin.y = orignY;
        self.frame = rect;
    
    } completion:^(BOOL finish){
    
    }];
}

-(void)removeAllSubView{
    
    while([self.subviews count]>1){
        UIView* view = [self.subviews objectAtIndex:1];
        [view removeFromSuperview];

    }

    
//    for(int i=1; i< self.subviews.count;i++){
//    
//        UIView* view = [self.subviews objectAtIndex:i];
//        [view removeFromSuperview];
//    }

    bgView.frame = self.bounds;

}

@end
