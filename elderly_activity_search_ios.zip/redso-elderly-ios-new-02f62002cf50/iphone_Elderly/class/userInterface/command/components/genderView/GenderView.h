//
//  GenderView.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol GenderViewDelegate <NSObject>

@optional
-(void)selectGenderView:(NSInteger)selectIndex;

@end

@interface GenderView : UIView{

    UIButton* menButton;
    UIButton* womenButton;
    UIButton* skipButton;

}

@property(nonatomic,assign)id<GenderViewDelegate> delegate;


-(void)setMenButtonTitle:(NSString*)title;
-(void)setWomenButonTitle:(NSString*)title;
-(void)setSkipButton:(NSString*)title;

@end
