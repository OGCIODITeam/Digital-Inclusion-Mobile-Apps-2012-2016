//
//  GenderView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "GenderView.h"
#import "ElderlyThemeManager.h"
#import "ElderlyUtils.h"

@implementation GenderView


@synthesize delegate;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setAccessibilityViewIsModal:YES];
        
        UIImageView* bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 115, self.bounds.size.width, self.bounds.size.height - 115)];
        bgView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_picker_box.png"];
        [self addSubview:bgView];
        [bgView release];
        
        UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_sex.png"];
        
        float orginX = (self.bounds.size.width - (img.size.width*2+5))*0.5f;

        float orginY = 115 + (bgView.frame.size.height - (img.size.height*2+30))*0.5f - ([ElderlyUtils isRetain4]?88:0);
        
        menButton = [[UIButton alloc] initWithFrame:CGRectMake(orginX, orginY, img.size.width, img.size.height)];
        [menButton setBackgroundImage:img forState:UIControlStateNormal];
        menButton.tag = 1001;
        [menButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:menButton];
        
        womenButton = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(menButton.frame)+5, orginY, img.size.width, img.size.height)];
        [womenButton setBackgroundImage:img forState:UIControlStateNormal];
        womenButton.tag = 1002;
        [womenButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:womenButton];
        
        img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_sex.png"];
        skipButton = [[UIButton alloc] initWithFrame:CGRectMake(orginX, CGRectGetMaxY(womenButton.frame)+25, CGRectGetMaxX(womenButton.frame)-orginX, img.size.height)];
        [skipButton setBackgroundImage:img forState:UIControlStateNormal];
        [skipButton setBackgroundImage:img forState:UIControlStateHighlighted];
        skipButton.tag = 1003;
        [skipButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:skipButton];


        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)selectButton:(id)sender{

    if(self.delegate != nil){
    
        UIButton* button = (UIButton*)sender;
        [self.delegate selectGenderView:button.tag];
    }

}

-(void)setMenButtonTitle:(NSString*)title{

    [menButton setTitle:title forState:UIControlStateNormal];
    [menButton theme:@"men_button_title"];
    
}


-(void)setWomenButonTitle:(NSString*)title{
    [womenButton setTitle:title forState:UIControlStateNormal];
    [womenButton theme:@"women_button_title"];


}


-(void)setSkipButton:(NSString*)title{
    [skipButton setTitle:title forState:UIControlStateNormal];
    [skipButton theme:@"skip_button_title"];


}

@end
