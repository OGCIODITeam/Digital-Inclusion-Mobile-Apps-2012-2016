//
//  LabelCustomTextField.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CustomTextField;

@interface LabelCustomTextField : UIView{
    UILabel* label;
    CustomTextField* textField;
}

@property(nonatomic,retain) NSString* leftText;
@property(nonatomic,retain) NSString* text;

@property(nonatomic,assign) id<UITextFieldDelegate> delegate;



-(id)initWithImage:(UIImage*)image;


-(void)placeHolderText:(NSString*)text;

-(void)setFont:(NSString *)familyName size:(CGFloat)fontSize;

-(void)themeChanged;

-(void)textFieldReturnType:(UIReturnKeyType)returnKeyType;

-(void)setKeyBoardType:(UIKeyboardType)keyboardType;


@end
