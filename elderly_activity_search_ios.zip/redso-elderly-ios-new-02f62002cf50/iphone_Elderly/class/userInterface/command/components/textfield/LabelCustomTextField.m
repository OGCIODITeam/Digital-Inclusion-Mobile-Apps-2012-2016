//
//  LabelCustomTextField.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LabelCustomTextField.h"
#import "ElderlyTextField.h"
#import "CustomTextField.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyThemeManager.h"

@implementation LabelCustomTextField

@synthesize leftText;
@synthesize text;
@synthesize delegate;
-(id)initWithImage:(UIImage*)image{
    self=[self init];
    if(self){
        label=[[UILabel alloc] init];
        [label theme:@"label_custom_label"];
        ElderlyThemeGridModel* model = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
        label.textColor = [ElderlyUtils colorConvertFromString:model.color];
        [self addSubview:label];
        
        [label release];
        
        textField=[[CustomTextField alloc] initWithImage:image];
//        NSInteger fontSize = [[self getAppDelegate].settingManager getFontType];
       
        [textField.elderlyTextField theme:@"inputkeyword"];
        [self addSubview:textField];
        [textField release];
        
        
        CGRect rect=self.frame;
        rect.size.height=textField.frame.size.height+7.0f;
        self.frame=rect;
    }
    
    return self;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    CGRect rect=textField.frame;
    rect.origin.y=5.0f;
    rect.origin.x=self.frame.size.width-10.0f-rect.size.width;
    textField.frame=rect;
    
    rect=label.frame;
    rect.size.width=self.frame.size.width-CGRectGetMinX(textField.frame)-10.0f-5.0f;
    rect.size.height=self.frame.size.height;
    rect.origin.x=10.0f;
    label.frame=rect;
}


-(void)placeHolderText:(NSString*)value{
    textField.elderlyTextField.placeholder=value;
}

-(void)themeChanged{
    [label theme:@"label_custom_label"];
    [textField.elderlyTextField theme:@"inputkeyword"];
    ElderlyThemeGridModel* model = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    label.textColor = [ElderlyUtils colorConvertFromString:model.color];

}

-(void)setText:(NSString *)value{
    textField.elderlyTextField.text=value;
}

-(NSString*)text{
    return textField.elderlyTextField.text;
}

-(void)setFont:(NSString *)familyName size:(CGFloat)fontSize{
    [textField.elderlyTextField setFont:familyName size:fontSize];
}

-(void)setLeftText:(NSString *)value{
    label.text=value;
}

-(NSString*)leftText{
    return label.text;
}

-(void)setDelegate:(id<UITextFieldDelegate>)value{
    textField.elderlyTextField.delegate=value;
}

-(id<UITextFieldDelegate>)delegate{
    return textField.elderlyTextField.delegate;
}

-(BOOL)resignFirstResponder{
    if([textField.elderlyTextField isFirstResponder])
        [textField.elderlyTextField resignFirstResponder];
    
    return YES;
}

-(BOOL)becomeFirstResponder{
    if([textField.elderlyTextField canBecomeFirstResponder])
        [textField.elderlyTextField becomeFirstResponder];
    
    return YES;
}

-(void)textFieldReturnType:(UIReturnKeyType)returnKeyType{
    textField.elderlyTextField.returnKeyType=returnKeyType;
}

-(void)setKeyBoardType:(UIKeyboardType)keyboardType{

    textField.elderlyTextField.keyboardType = keyboardType;

}
@end
