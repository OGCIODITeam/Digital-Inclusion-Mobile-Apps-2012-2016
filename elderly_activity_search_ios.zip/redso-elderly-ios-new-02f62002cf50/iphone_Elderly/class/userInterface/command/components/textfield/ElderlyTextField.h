//
//  ElderlyTextField.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ElderlyTextField : UITextField{

    UIFont* font;

}


@property(nonatomic,assign)float spacing;
-(void)setFont:(NSString *)familyName size:(CGFloat)fontSize;


@end
