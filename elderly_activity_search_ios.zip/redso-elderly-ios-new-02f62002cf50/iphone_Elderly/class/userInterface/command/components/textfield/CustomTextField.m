//
//  CustomTextField.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "CustomTextField.h"
#import "ElderlyTextField.h"

@implementation CustomTextField

@synthesize elderlyTextField;

- (id)initWithImage:(UIImage *)image
{
    self = [super initWithImage:image];
    if (self) {
        self.userInteractionEnabled=YES;
        CGRect rect=self.frame;
        elderlyTextField=[[ElderlyTextField alloc] initWithFrame:CGRectMake(5.0f, (rect.size.height-30.0f)*0.5f, rect.size.width-35.0f, image.size.height)];
        elderlyTextField.borderStyle=UITextBorderStyleNone;
        elderlyTextField.spacing = 5.0f;
        [self addSubview:elderlyTextField];
        [elderlyTextField release];
    }
    return self;
}


-(void)dealloc{
    
    [super dealloc];
}

@end
