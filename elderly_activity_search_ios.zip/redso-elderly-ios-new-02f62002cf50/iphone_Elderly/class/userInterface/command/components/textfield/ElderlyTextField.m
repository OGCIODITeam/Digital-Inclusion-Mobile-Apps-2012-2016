//
//  ElderlyTextField.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyTextField.h"

@implementation ElderlyTextField

@synthesize spacing;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.spacing = 0;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)setFont:(NSString *)familyName size:(CGFloat)fontSize{
    font = [UIFont fontWithName:familyName size:fontSize];
}

- (void)drawPlaceholderInRect:(CGRect)rect{
    [[UIColor lightGrayColor] setFill];
    [self.placeholder drawInRect:rect withFont:font];
    
}

- (CGRect)placeholderRectForBounds:(CGRect)bounds{
    CGRect inset = CGRectMake(bounds.origin.x+spacing, bounds.origin.y+spacing, bounds.size.width -10, bounds.size.height);//更好理解些
    return inset;
    
}

-(CGRect)textRectForBounds:(CGRect)bounds{
    
    CGRect inset = CGRectMake(bounds.origin.x+spacing, bounds.origin.y+([ElderlyUtils systemVersion]>=7.0?-4:spacing), bounds.size.width -10, bounds.size.height);//更好理解些
    return inset;
}



@end
