//
//  LoadingView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LoadingView.h"

@implementation LoadingView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.hidden = YES;
        [self setAccessibilityViewIsModal:YES];
        UIView* bgView = [[UIView alloc] initWithFrame:self.bounds];
        bgView.backgroundColor = [UIColor blackColor];
        bgView.alpha = 0.9;
        [self addSubview:bgView];
        [bgView release];
        
        loadingView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        loadingView.frame = CGRectMake((self.frame.size.width - 30)*0.5f, (self.frame.size.height - 30)*0.5f, 30, 30);
        [self addSubview:loadingView];
        [loadingView release];
        
        [self setAccessibilityViewIsModal:YES];

    }
    return self;
}

-(void)loadingViewStyle:(UIActivityIndicatorViewStyle)style{

    loadingView.activityIndicatorViewStyle = style;
}

-(void)startLoading{

    [loadingView startAnimating];
    self.hidden = NO;
}

-(void)stopLoading{


    [loadingView stopAnimating];
    self.hidden = YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/



@end
