//
//  LoadingView.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadingView : UIView{

    UIActivityIndicatorView* loadingView;

}


-(void)startLoading;
-(void)stopLoading;
-(void)loadingViewStyle:(UIActivityIndicatorViewStyle)style;
@end
