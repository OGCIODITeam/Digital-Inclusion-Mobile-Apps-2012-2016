//
//  GridView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "GridView.h"
#import "ElderlyThemeManager.h"
#import "ElderlyUtils.h"

@implementation GridView

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        dataViewArray = [[NSMutableArray alloc] init];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)dealloc{


    [dataViewArray removeAllObjects];
    [dataViewArray release];
    [super dealloc];
}

-(void)setViewContent:(NSArray*)array title:(NSArray*)titleArray{

    
    
    for(int i=0; i<array.count-1;i++){
    
        NSString*imageName = [array objectAtIndex:i];
 
        UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:imageName,([[ElderlyUtils language] isEqualToString:@"zh-cn"]?@"sc":@"tc")]];
        UIButton* button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, img.size.width,img.size.height)];
        button.tag = i;
        [button setAccessibilityLabel:[titleArray objectAtIndex:i]];
        [button setImage:img forState:UIControlStateNormal];
        [button addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
       
        [self addSubview:button];
        [dataViewArray addObject:button];
        [button release];
    
    
    }
}

-(void)changeViewColor:(NSArray*)array{

    for(int i=0; i<array.count-1;i++ ){
    
        NSString* imageName = [array objectAtIndex:i];
        UIButton* button = [dataViewArray objectAtIndex:i];
         UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:imageName,([[ElderlyUtils language] isEqualToString:@"zh-cn"]?@"sc":@"tc")]];
        [button setImage:img forState:UIControlStateNormal];
    
    }

}


-(void)setViewContentFinish{
    
    float orginX = 0.0f;
    float orginY = 0.0f;
    for(UIButton* button in dataViewArray){
    
        CGRect rect = button.frame;
        rect.origin.x = orginX;
        rect.origin.y = orginY;
        button.frame = rect;
        
        orginX = CGRectGetMaxX(button.frame);
        
        if(CGRectGetMaxX(button.frame) >= self.bounds.size.width-20){
            orginY = CGRectGetMaxY(button.frame);
            orginX = 0.0f;
        }
    }

}



-(void)selectButton:(id)sender{
    if(self.delegate != nil){
        UIButton* button = (UIButton*)sender;
        [self.delegate selectorGridView:button.tag];
    }
}

@end
