//
//  WeatherIndexView.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-8.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "WeatherIndexView.h"
#import "ElderlyThemeManager.h"

@implementation WeatherIndexView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code

        weatherIconView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 5, 44, 41)];
        [self addSubview: weatherIconView];
        [weatherIconView release];
        
        
        weatherNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(weatherIconView.frame)+5, 7, 95, 50)];
        
        weatherNameLabel.shadowColor = [UIColor blackColor];
        weatherNameLabel.shadowOffset = CGSizeMake(1.0, 1.0);
        weatherNameLabel.numberOfLines = 2;
        [self addSubview:weatherNameLabel];
        [weatherNameLabel release];
        
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)weatherIcon:(UIImage*)image{

    weatherIconView.image = image;

}


-(void)weatherName:(NSString*)text{

    [weatherNameLabel theme:@"weather_title"];
    weatherNameLabel.text = text;
    weatherNameLabel.frame = CGRectMake(CGRectGetMaxX(weatherIconView.frame)+5, 7, 95, 50);
    [weatherNameLabel sizeToFit];
    CGRect rect = weatherNameLabel.frame;
    rect.origin.y = 7;
    if(rect.size.width > 95){
        rect.size.width = 95;
    }
    
}

-(void)weatherWraing:(NSArray*)weatherIcons{

    float orginX = 308-23;
    float orginY = 5;
    for(int i=0;i<weatherIcons.count && i<6;i++){
    
        NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
        UIImage* image = [[ElderlyThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:@"weather_icons_%@.png",[weatherIcons objectAtIndex:i]]];
        
        UIImageView* weatherWarningImageView = [[UIImageView alloc] initWithFrame:CGRectMake(orginX, orginY, image.size.width, image.size.height)];
        weatherWarningImageView.image = image;
        [self addSubview:weatherWarningImageView];
                
        orginX-=(image.size.width+5);
        if(i == 2){
        
            orginX = 308-image.size.width;
            orginY = CGRectGetMaxY(weatherWarningImageView.frame);
        
        }
        [weatherWarningImageView release];
        [pool release];
    }
}


@end
