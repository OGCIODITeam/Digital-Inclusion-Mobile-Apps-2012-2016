//
//  ElderlyIphoneViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;
@interface ElderlyIphoneViewController : UIViewController


-(AppDelegate*)getAppDelegate;
-(void)themeChanged;

@end
