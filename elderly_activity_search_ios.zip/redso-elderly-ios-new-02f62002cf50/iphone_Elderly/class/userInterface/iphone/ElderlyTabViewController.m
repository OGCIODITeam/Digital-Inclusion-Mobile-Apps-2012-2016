//
//  ElderlyTabViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 17/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyTabViewController.h"
#import "HeadTabView.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyThemeManager.h"
#import "ElderlyRootViewController.h"

@interface ElderlyTabViewController ()<HeadTabViewDelegte>

@property (retain, nonatomic) UIViewController *vc1;
@property (retain, nonatomic) UIViewController *vc2;
@property (retain, nonatomic) UIView *subViewHolder;
@property (assign, nonatomic) int selectedTabIndex;


-(void)initView:(int)index;

@end


@implementation ElderlyTabViewController
@synthesize subViewHolder;
@synthesize vc1;
@synthesize vc2;


- (void)dealloc
{
    self.subViewHolder = nil;
    self.vc1 = nil;
    self.vc2 = nil;
    [super dealloc];
}

- (id)init{
    self = [super init];
    if (self) {

        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
        
        
    }
    return self;
}


- (void)viewDidLoad{
    [super viewDidLoad];
    
    headTabView=[[HeadTabView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 0.0f)];
    headTabView.delegate=self;
    [headTabView setTabNameArray:[NSArray arrayWithObjects:lang(@"older_center"),lang(@"kanwenshu"), nil]];
    [headTabView setTabImageView:[NSArray arrayWithObjects:@"tab_noraml_%@.png",@"tab_noraml_on_%@.png",@"tab_line_%@.png", nil]];
    [self.view addSubview:headTabView];
    [headTabView release];
    
    UIView *tmpView =[[UIView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(headTabView.frame), self.view.frame.size.width, self.view.frame.size.height-CGRectGetMaxY(headTabView.frame))];
    self.subViewHolder = tmpView;
    [tmpView release];
    [self.view addSubview:self.subViewHolder];
    
    NSLog(@"tmpView  >>>  %f", CGRectGetMaxY(headTabView.frame));
    
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self initView:self.selectedTabIndex];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];

    
}

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    [self.navigationController popViewControllerAnimated:YES];
    //    [[self getAppDelegate].rootController back];
    
}

-(void)themeChanged{
    
    [super themeChanged];
    [headTabView themeChanged:[NSArray arrayWithObjects:lang(@"older_center"),lang(@"kanwenshu"), nil] imageArray:[NSArray arrayWithObjects:@"tab_noraml_%@.png",@"tab_noraml_on_%@.png",@"tab_line_%@.png", nil]];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)initView:(int)index{
    self.vc1.view.hidden=YES;
    self.vc2.view.hidden=YES;
    if(index==0){
        if(self.vc1==nil){
            self.vc1 = [self getVCByIndex:index];
            [self.subViewHolder addSubview:self.vc1.view];
        }
        self.vc1.view.hidden=NO;
    }else if(index==1){
        
        if (self.vc2==nil) {
            self.vc2 = [self getVCByIndex:index];
            [self.subViewHolder addSubview:self.vc2.view];
        }
        
        self.vc2.view.hidden=NO;
    }
    self.selectedTabIndex = index;
}

- (UIViewController*)getVCByIndex:(NSInteger) index{
    return nil;
}


#pragma mark headtab delegate


-(void)tabDidSelected:(HeadTabView*)tabView index:(int)index{
    [self initView:index];
}

@end
