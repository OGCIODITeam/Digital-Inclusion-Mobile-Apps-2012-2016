//
//  WeatherWarningViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "WeatherWarningViewController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyRootViewController.h"
#import "AppDelegate.h"
#import "SettingViewController.h"
#import "WeatherTableCell.h"
#import "ElderlyWeatherModel.h"
#import "ElderlyUtils.h"
#import "ElderlyNavigationController.h"

@interface WeatherWarningViewController ()<UITableViewDataSource,UITableViewDelegate>
//-(void)initTopBar;
-(NSString*)getWeatherBgImageView:(NSInteger)code;
@end

@implementation WeatherWarningViewController
@synthesize weatherArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

   


    UIImageView* bgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    bgView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_daytime_rain.png"];
    if(self.weatherArray != nil && self.weatherArray.count > 1){
        ElderlyWeatherModel* model = [self.weatherArray objectAtIndex:0];
        bgView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:[self getWeatherBgImageView:model.code]];
    }
    [self.view addSubview:bgView];
    [bgView release];
    
//    [self initTopBar];
    [self initTableView];
    [self initButtomView];
}


-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top.png"];
    [nav titleView:lang(@"weather_title")];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{

    self.weatherArray = nil;
    [super dealloc];
}


-(void)themeChanged{

    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"weather_title")];
    
    buttomLabel.text = lang(@"weathercue");
    [buttomLabel theme:@"buttomLabel"];
    [titleLabel theme:@"mainPage_title"];
    titleLabel.text = lang(@"weather_title");
    buttomLabel.text = lang(@"weathercue");
    
    [weatherTableView reloadData];
    
}

#pragma mark init

//-(void)initTopBar{
//    
//    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_top.png"];
//    UIImageView* topBarBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width,img.size.height )];
//    topBarBgView.userInteractionEnabled = YES;
//    topBarBgView.image = img;
//    
//    
//    
//    
//    titleLabel = [[UILabel alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 200)*0.5f, 5, 200, img.size.height-10)];
//    
//    [titleLabel theme:@"mainPage_title"];
//    titleLabel.text = lang(@"weather_title");
//    titleLabel.textAlignment = NSTextAlignmentCenter;
//    [topBarBgView addSubview:titleLabel];
//    [titleLabel release];
//    
//    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_setting.png"];
//    UIButton* settingButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    [settingButton setImage:img forState:UIControlStateNormal];
//    settingButton.frame = CGRectMake(self.view.bounds.size.width-img.size.width, 0, img.size.width, img.size.height);
//    [settingButton addTarget:self action:@selector(navigationRightClick) forControlEvents:UIControlEventTouchUpInside];
//    [topBarBgView addSubview:settingButton];
//    
//    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_back.png"];
//    UIButton* backButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    [backButton setImage:img forState:UIControlStateNormal];
//    backButton.frame = CGRectMake(0, 0, img.size.width, img.size.height);
//    [backButton addTarget:self action:@selector(navigationLeftClick) forControlEvents:UIControlEventTouchUpInside];
//    [topBarBgView addSubview:backButton];
//    
//    [self.view addSubview:topBarBgView];
//    [topBarBgView release];
//}

-(void)initTableView{

    weatherTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 10, self.view.bounds.size.width, self.view.bounds.size.height - 80)];
    weatherTableView.delegate = self;
    weatherTableView.dataSource = self;
    weatherTableView.showsVerticalScrollIndicator = NO;
    [weatherTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    weatherTableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:weatherTableView];
    [weatherTableView release];

    if([ElderlyUtils systemVersion] < 7.0)
        [weatherTableView setAccessibilityViewIsModal:YES];
}

-(void)initButtomView{

 
    float h=self.view.bounds.size.height;

    buttomLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, h - 66, 299, 20)];
    buttomLabel.text = lang(@"weathercue");
    [buttomLabel theme:@"buttomLabel"];
    [self.view addSubview:buttomLabel ];
    [buttomLabel release];

}


#pragma mark method

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
  
}

-(void)navigationLeftClick{
    NSLog(@"navigationLeftClick");
    [[self getAppDelegate].rootController back];
}

#pragma mark UITableView delegate 
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 55;

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.weatherArray.count-1;

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString *identifier = @"Cell";
    WeatherTableCell* cell = [weatherTableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil){
    
        cell = [[[WeatherTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSInteger row = indexPath.row+1;
    if(row < self.weatherArray.count){
    
        ElderlyWeatherModel* model = [self.weatherArray objectAtIndex:row];
        
        [cell setWeatherIcon:[[ElderlyThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:@"weather_forecast_%d.png",model.code]]];
        [cell setDate:model.date];
        [cell setTemperature:[NSString stringWithFormat:@"%d - %d",model.minTemperature,model.maxTemperature] weatherName:[ElderlyUtils text:model key:@"name"]];
    }
  

    return cell;

}

-(NSString*)getWeatherBgImageView:(NSInteger)code{
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
                                    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:[NSDate date]];
    
    NSInteger hour = [components hour];
    
    NSString* imageStr = @"bg_daytime_%@.png";
    if((hour <= 24 && hour >17) || (hour >= 0 && hour < 6)){
        imageStr = @"bg_night_%@.png";
    }
    imageStr = [NSString stringWithFormat:imageStr,@"sun"];
    if(code > 61 && code < 66){
        imageStr = [NSString stringWithFormat:imageStr,@"rain"];
    }
    
    
    return imageStr;
    
}



@end
