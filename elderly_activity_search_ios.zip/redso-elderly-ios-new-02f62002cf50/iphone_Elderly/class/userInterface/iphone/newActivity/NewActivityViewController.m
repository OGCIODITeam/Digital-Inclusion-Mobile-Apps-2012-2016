//
//  NewActivityViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//
#import "Reachability.h"
#import "ElderlyNavigationController.h"
#import "NewActivityViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlySettingManager.h"
#import "ActivityOrganizerSelector.h"
#import "TopBanner.h"
#import "ActivityDetailViewController.h"
#import "NewActivityCellController.h"
#import "GuideView.h"
#import "ElderlyNewActivityModel.h"
#import "ElderlyBannerModel.h"
#import "ElderlyActivityDetailModel.h"
#import "ScrollViewBottomBar.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyGuideMannager.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyHTTPRequestManager.h"
#import "AsyncTask.h"
#import "ElderlyIphoneWebBrowserViewController.h"
#import "LoadingView.h"
#import "ElderlyUtils.h"
#import "ElderlyAlertUtils.h"
#import "ApiError.h"
#import "ElderlyGA.h"

#define topBannerHeight 167
@interface NewActivityViewController () <UITableViewDelegate, UITableViewDataSource, bannerHit, organizerSeletor>

@property (nonatomic, retain) NSArray *bannerArray;
@property (nonatomic, retain) NSArray *smallInfoArray;//在下面
@property (nonatomic, retain) NSArray *detailInfoArray;//活动详情

@property (nonatomic, retain) TopBanner *theLogo;
@property (nonatomic, retain) ActivityOrganizerSelector *theSelector;
@property (nonatomic, retain) IBOutlet UITableView *downTableView;
@property (nonatomic, retain) IBOutlet ScrollViewBottomBar *bottomBar;
@property (assign) Boolean scrolledToButtom;
@property (nonatomic, retain) NSString *organizerType;//activityType:L(康文屬)，E(長者活動中心)
@property (nonatomic, retain) UIColor *myMainColor;
@property (nonatomic, retain) IBOutlet UIButton *guider;
@property (nonatomic, retain) NSString *isShowingAlertString;

@end

@implementation NewActivityViewController

@synthesize bannerArray = _bannerArray;
@synthesize smallInfoArray = _smallInfoArray;//在下面
@synthesize detailInfoArray = _detailInfoArray;//活动详情

@synthesize theSelector;
@synthesize theLogo = _theLogo;
@synthesize downTableView = _downTableView;
@synthesize bottomBar;

@synthesize organizerType;
@synthesize scrolledToButtom;
@synthesize myMainColor;
@synthesize guider;
@synthesize isShowingAlertString;


int numberOfItemForText = 8;

- (NSArray *)detailInfoArray {
	return _detailInfoArray;
}

- (NSArray *)smallInfoArray {
	return _smallInfoArray;
}

- (NSArray *)bannerArray {
	return _bannerArray;
}

- (void)setBannerArray:(NSArray *)bannerArray {
	_bannerArray = bannerArray;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
		// Custom initialization
		ElderlyBarButtonItem *tmpBtn = [[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)];
		self.navigationItem.leftBarButtonItem = tmpBtn;
		[tmpBtn release];

		self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	[self initView];

	[[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_LATESTACTIVITY];
}

- (void)viewWillAppear:(BOOL)animated {
	if (self.theLogo) [self.theLogo startTimer];
}

- (void)viewWillDisappear:(BOOL)animated {
	if (self.theLogo) [self.theLogo stopTimer];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

- (void)willShowViewController {
	ElderlyNavigationController *nav = (ElderlyNavigationController *)self.navigationController;
	[nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
	[nav titleView:lang(@"newActivity")];
}

- (void)navigationLeftClick {
	// NSLog(@"navigationLeftClick");

	[[self getAppDelegate].rootController back];
}

//-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
//    if ([keyPath isEqualToString:@"bannerArray"])
//    {
//        [self createBanner];
//    }
//}

- (void)navigationRightClick {
	//   NSLog(@"navigationRightClick");
	[[self getAppDelegate].rootController goSettingViewController:self.navigationController];
}

#define theTrylengthsIWant 7 //banner Array lengths
#pragma mark methods
- (void)initView {
	//上部的banner
	[self createBanner];

	//下部的表格


	// now will be create when click selector

	//半透明黑底的 两个按钮
	ActivityOrganizerSelector *aSelector = [[ActivityOrganizerSelector alloc] initWithFrame:self.view.frame];
	aSelector.delegate = self;
	self.theSelector = aSelector;
	[aSelector release];
	[self.view addSubview:self.theSelector];

	//底部的 触底显示bar
	UIImage *img = [UIImage imageNamed:@"btn_scroll.png"];
	NSString *reachBottomKey = @"littleTalbeReachedBottom";
	CGRect rectForbottomBar = CGRectMake(0, self.view.frame.size.height - 44 - img.size.height, self.view.frame.size.width, img.size.height);
	ScrollViewBottomBar *aBar = [[ScrollViewBottomBar alloc]initWithFrame:rectForbottomBar];
	reachBottomKey = nil;
	self.bottomBar = aBar;
	[aBar release]; aBar = nil;
	[self.view addSubview:self.bottomBar];
	[self.view bringSubviewToFront:self.bottomBar];
	self.bottomBar.hidden = YES;
}

- (void)createBanner {
	CGRect contentLogoRect = self.view.frame;
	contentLogoRect.size.height = topBannerHeight;
	LoadingView *loadingView = [[LoadingView alloc] initWithFrame:contentLogoRect];
	[loadingView startLoading];
	[self.view addSubview:loadingView];

	AsyncTask *asyncTask = [[self getAppDelegate].httpRequestManager getBannerlist:@"L"];
	[asyncTask setFinishBlock: ^{
	    NSArray *list = [asyncTask result];
	    if (list != nil) {
	        //   NSLog(@"_bannerArray  %@  & list %@",_bannerArray,list);
	        NSMutableArray *tempMuArray = [[NSMutableArray alloc] init];
	        for (id banner in list) {
	            if ([banner isKindOfClass:[ElderlyBannerModel class]]) [tempMuArray addObject:banner];
			}

	        NSArray *array = [tempMuArray copy];
	        // if (tempMuArray.count) [self  setValue:array forKey:@"bannerArray"];
	        self.bannerArray = array;
	        /////// [self createBanner]
	        TopBanner *Banner = [[TopBanner alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, topBannerHeight) andArray:self.bannerArray];
	        NSLog(@"%@", self.bannerArray);
	        Banner.delegate = self;
	        self.theLogo = Banner;
	        //  [self.view addSubview:self.theLogo];
	        [Banner  release];  Banner = nil;


	        ////////
	        if (!self.downTableView) {
	            UITableView *downTable = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
	            [downTable setDataSource:self];
	            [downTable setDelegate:self];
	            downTable.separatorStyle = UITableViewCellSelectionStyleNone;
	            self.downTableView = downTable;
	            //       self.downTableView.accessibilityViewIsModal=YES;
	            [self.view addSubview:self.downTableView];
	            [downTable release]; downTable = nil;
			}

	        [tempMuArray release]; tempMuArray = nil;
	        [array release];
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];


	        if (self.theSelector) {
	            [self.view bringSubviewToFront:self.theSelector];
			}
		}
	    else {
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];
	        [self alertControl:asyncTask.error.errorMessage];
	        //  [ElderlyAlertUtils showAlert:asyncTask.error.errorMessage delegate:nil];
		}
	}];
	asyncTask = nil;
}

- (void)createBottomBar {
	//底部的 触底显示bar
	UIImage *img = [UIImage imageNamed:@"btn_scroll.png"];
	NSString *reachBottomKey = @"littleTalbeReachedBottom";
	CGRect rectForbottomBar = CGRectMake(0, self.view.frame.size.height - 44 - img.size.height, self.view.frame.size.width, img.size.height);
	ScrollViewBottomBar *aBar = [[ScrollViewBottomBar alloc]initWithFrame:rectForbottomBar];
	reachBottomKey = nil;
	self.bottomBar = aBar;
	[aBar release]; aBar = nil;
	[self.view addSubview:self.bottomBar];
	[self.view bringSubviewToFront:self.bottomBar];
}

- (void)theBanner:(TopBanner *)sender
            Hited:(NSString *)link BannerID:(NSString *)bannerID {
	DLog(@"banner clicked 2");
	//  [self.theLogo stopTimer];
	ElderlyIphoneWebBrowserViewController *controller = [[ElderlyIphoneWebBrowserViewController alloc]init];
	[self.navigationController pushViewController:controller animated:YES];
	[controller loadRequestAfterDelay:link];
	[controller release];

	[[ElderlyGA sharedInstance] trackEvent:GA_CODE_BANNER];
}

//-(void)receiveMessageOrganizerSelected:(NSNotification *)type{
- (void)selectOrganizer:(NSString *)theOrganizer {
	//self.theSelector=nil;
	// if (self.downTableView)[self.downTableView removeFromSuperview];
	//self.downTableView=nil;
	if (!self.theLogo) {
		[self  createBanner];
	}

	CGRect contentTableRect = self.view.bounds;
	if (self.view.frame.size.height > 500) {
		contentTableRect.size.height = self.view.frame.size.height - 88 - 44 - 26;
	}
	else {
		contentTableRect.size.height = self.view.frame.size.height;
	}
	self.organizerType = theOrganizer;
	LoadingView *loadingView = [[LoadingView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

	[loadingView startLoading];

	[self.view addSubview:loadingView];


	AsyncTask *asyncTaskB = [[self getAppDelegate].httpRequestManager getActivityPageList:self.organizerType offset:offsetCounter pageSize:loadCount];

	[asyncTaskB setFinishBlock: ^{
	    NSArray *list = [asyncTaskB result];

	    if (list != nil) {
	        offsetCounter += loadCount;
	        if (list.count < loadCount) {
	            didloadALldata = YES;
			}
	        NSMutableArray *tempMuArray = [[NSMutableArray alloc] init];

	        for (id newAtivity in list) {
	            if ([newAtivity isKindOfClass:[ElderlyNewActivityModel class]]) [tempMuArray addObject:newAtivity];
			}

	        NSArray *array = [tempMuArray copy];
	        self.smallInfoArray = array;
	        self.downTableView = nil;

	        if (self.downTableView == nil) {
	            UITableView *downTable = [[UITableView alloc]initWithFrame:contentTableRect style:UITableViewStylePlain];
	            [downTable setDataSource:self];
	            [downTable setDelegate:self];
	            downTable.frame = contentTableRect;
	            self.downTableView = downTable;
	            [self.view addSubview:self.downTableView];
	            [downTable release]; downTable = nil;
			}

	        [self.downTableView reloadData];
	        [self.view bringSubviewToFront:self.bottomBar];
	        self.bottomBar.hidden = NO;
	        ////
	        [tempMuArray release]; tempMuArray = nil;
	        [array release]; array = nil;
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];

	        ////// 提示下拉的按钮图片

	        if ([[ElderlyGuideMannager sharedInstance] getGudieState:latestActivitiesGuide]) {
	            [self creatFirstTimeRunGuide];
			}
		}
	    else {
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];
	        [self alertControl:asyncTaskB.error.errorMessage];
	        //       [ElderlyAlertUtils showAlert:asyncTaskB.error.errorMessage delegate:nil];
		}
	}];
	asyncTaskB = nil;


	if (theOrganizer != nil && theOrganizer.length > 0) {
		NSString *categoryCode = nil;
		if ([theOrganizer isEqualToString:@"E"]) {
			categoryCode = GA_CODE_ELDERCENTERBUTTON;
		}
		else if ([theOrganizer isEqualToString:@"L"]) {
			categoryCode = GA_CODE_LCSDBUTTON;
		}

		if (categoryCode != nil) {
			[[ElderlyGA sharedInstance] trackEvent:categoryCode];
		}
	}


	//
}

- (void)creatFirstTimeRunGuide {
	GuideView *maskBtn =  [[GuideView alloc] initWithFrame:self.view.bounds];
	// maskBtn.frame=contentTableRect;
	[maskBtn setGuideOrignY:0];
	maskBtn.tag = 999;
	//       NSLog(@"%f", contentTableRect.origin.y);


	AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;

	BOOL lang = [appDelegate.settingManager getlanguageType];

	if (lang) {
		[maskBtn addImageView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"guide11_sc.png"]];
	}
	else {
		[maskBtn addImageView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"guide11_tc.png"]];
	}


	//  [maskBtn setImage:guideimg  forState:UIControlStateNormal];
	[maskBtn addTarget:self action:@selector(disapperItSelf:) forControlEvents:UIControlEventTouchUpInside];
	self.guider = maskBtn;
	//   [maskBtn release];maskBtn=nil;
	[self.view addSubview:self.guider];
}

bool didloadALldata = NO;
- (BOOL)checkNetWork {
	Reachability *reachability = [Reachability reachabilityForInternetConnection];
	NetworkStatus internetStatus = [reachability currentReachabilityStatus];
	return internetStatus;
}

int offsetCounter = 0;

- (void)reflashDownTable {
	if (offsetCounter > 199) {
		return;
	}

	LoadingView *loadingView = [[LoadingView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	[loadingView startLoading];
	[self.view addSubview:loadingView];

	AsyncTask *asyncTaskB = [[self getAppDelegate].httpRequestManager getActivityPageList:self.organizerType offset:offsetCounter pageSize:loadCount];
	[asyncTaskB setFinishBlock: ^{
	    NSArray *list = [asyncTaskB result];
	    if (list != nil) {
	        offsetCounter += loadCount;
	        if (list.count < loadCount) {
	            didloadALldata = YES;
			}
	        NSMutableArray *tempMuArray = [[NSMutableArray alloc] init];
	        for (id newAtivity in list) {
	            if ([newAtivity isKindOfClass:[ElderlyNewActivityModel class]]) [tempMuArray addObject:newAtivity];
			}
	        self.smallInfoArray = [self.smallInfoArray arrayByAddingObjectsFromArray:tempMuArray];
	        [self.downTableView reloadData];
	        [tempMuArray release]; tempMuArray = nil;
	        [self.view bringSubviewToFront:self.bottomBar];
	        self.bottomBar.hidden = NO;
	        [tempMuArray release]; tempMuArray = nil;
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];
		}
	    else {
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];
	        [self alertControl:asyncTaskB.error.errorMessage];
		}
	}];
	asyncTaskB = nil;
}

static bool alerting = NO;
- (void)alertControl:(NSString *)theAlert {
	if (![theAlert isEqualToString:self.isShowingAlertString] && (!alerting)) {
		alerting = YES;
		[ElderlyAlertUtils showAlert:theAlert delegate:nil];
		[self performSelector:@selector(notAlerting) withObject:nil afterDelay:0.2];
	}
}

- (void)notAlerting {
	alerting = NO;
}

- (void)disapperItSelf:(UIView *)sender {
	GuideView *guideView = (GuideView *)[self.view viewWithTag:999];
	[UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations: ^{
	    guideView.alpha = 0.0f;
	} completion: ^(BOOL finish) {
	    [guideView removeFromSuperview];
	}];

	[[ElderlyGuideMannager sharedInstance] setGudieState:latestActivitiesGuide state:NO];
	[[ElderlyGuideMannager sharedInstance] saveGudieFile];
}

- (void)showActvtyDetailWithRowNumber:(int)index {
	//  loadingViewRect.origin.y=loadingViewRect.origin.y-44-44;
	//NSString *version = [[UIDevice currentDevice] systemVersion];
	// if ([version hasPrefix:@"7."])loadingViewRect.origin.y=loadingViewRect.origin.y-44;
//    NSLog(@"%@",self.view);
	LoadingView *loadingView = [[LoadingView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

	[loadingView startLoading];
	[self.view addSubview:loadingView];

	ElderlyActivityDetailModel *oneActivity = [self.smallInfoArray objectAtIndex:index];
	AsyncTask *asyncTask = [[self getAppDelegate].httpRequestManager getActivityDetail:self.organizerType cativityId:oneActivity.activityId];
	[asyncTask setFinishBlock: ^{
	    ElderlyActivityDetailModel *detail = [asyncTask result];
	    if (detail != nil) {
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];
	        ActivityDetailViewController *controller = [[ActivityDetailViewController alloc]init];
	        controller.organizerType = self.organizerType;
	        controller.theActivity = detail;
	        //controller.subTitleBackGroundColor=[UIColor blueColor] ;
	        [self.navigationController pushViewController:controller animated:YES];

	        [controller release];
	        //  [self.theLogo stopTimer];
		}
	    else {
	        [loadingView stopLoading];
	        [loadingView removeFromSuperview];
	        [loadingView release];
	        [self alertControl:asyncTask.error.errorMessage];
	        //    [ElderlyAlertUtils showAlert:asyncTask.error.errorMessage delegate:nil];
		}
	}];
	asyncTask = nil;
}

- (NSInteger)themeIndex {
	return 0;
}

//- (UIColor *)darkerColorForColor:(UIColor *)c
//{
//    NSString *version = [[UIDevice currentDevice] systemVersion];
//
//    if ([version floatValue] >= 5.0 ) {
//        float r, g, b, a;
//        if ([c getRed:&r green:&g blue:&b alpha:&a])
//            return [UIColor colorWithRed:MAX(r - 0.05, 0.0)
//                                   green:MAX(g - 0.05, 0.0)
//                                    blue:MAX(b - 0.05, 0.0)
//                                   alpha:a];
//    }
//    return c;
//}

- (void)themeChanged {
	ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel /*:[self themeIndex]*/];
	NSUInteger red, green, blue;
	sscanf([theme.color UTF8String], "#%02X%02X%02X", &red, &green, &blue);
	self.myMainColor = [UIColor colorWithRed:red / 255.0 green:green / 255.0 blue:blue / 255.0 alpha:1];

	ElderlyNavigationController *nav = (ElderlyNavigationController *)self.navigationController;
	[nav titleView:lang(@"newActivity")];
	[(UIButton *)self.theSelector.btnLCSD setTitle:lang(@"kanwenshu")  forState:UIControlStateNormal];
	[(UIButton *)self.theSelector.btnOrganizer setTitle:lang(@"older_center")  forState:UIControlStateNormal];
	[self.theSelector.btnLCSD theme:@"newActivityDetail_selector"];
	[self.theSelector.btnOrganizer theme:@"newActivityDetail_selector"];
	//////////////
	// UIColor *darker=[self darkerColorForColor:self.myMainColor];
	[(UIButton *)self.theSelector.btnLCSD setBackgroundColor:self.myMainColor];
	[(UIButton *)self.theSelector.btnOrganizer setBackgroundColor:self.myMainColor];

	[self.downTableView reloadData];
	/////////提示下拉圖片
	AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;

	if (self.guider) {
		[(GuideView *)self.guider removeAllSubView];
		BOOL lang = [appDelegate.settingManager getlanguageType];
		// UIImage *guideimg=nil;
		if (lang) {
			[(GuideView *)self.guider addImageView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"guide11_sc.png"]];
		}
		else {
			[(GuideView *)self.guider addImageView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"guide11_tc.png"]];
		}
	}
	////
}

- (NSString *)getChineseWeekDay:(NSString *)weekDay {
	NSString *theWeekDay = nil;
	//CFStringTokenizerCopyBestStringLanguage(weekDay,{1})
	if ([weekDay isEqualToString:@"Monday"]) theWeekDay = lang(@"weekday1");
	if ([weekDay isEqualToString:@"Tuesday"]) theWeekDay = lang(@"weekday2");
	if ([weekDay isEqualToString:@"Wednesday"]) theWeekDay = lang(@"weekday3");
	if ([weekDay isEqualToString:@"Thursday"]) theWeekDay = lang(@"weekday4");
	if ([weekDay isEqualToString:@"Friday"]) theWeekDay = lang(@"weekday5");
	if ([weekDay isEqualToString:@"Saturday"]) theWeekDay = lang(@"weekday6");
	if ([weekDay isEqualToString:@"Sunday"]) theWeekDay = lang(@"weekday7");
	if (!theWeekDay) {
		theWeekDay = [NSString stringWithFormat:@"（%@）", weekDay];
	}
	return theWeekDay;
}

- (NSString *)getChineseWeekDayFromInt:(int)weekDay {
	NSString *theWeekDay = nil;
	switch (weekDay) {
		case 1:
			theWeekDay = lang(@"weekday7");
			break;

		case 2:
			theWeekDay = lang(@"weekday1");
			break;

		case 3:
			theWeekDay = lang(@"weekday2");
			break;

		case 4:
			theWeekDay = lang(@"weekday3");
			break;

		case 5:
			theWeekDay = lang(@"weekday4");
			break;

		case 6:
			theWeekDay = lang(@"weekday5");
			break;

		case 7:
			theWeekDay = lang(@"weekday6");
			break;

		default:
			break;
	}
	if (theWeekDay) {
		return [NSString stringWithFormat:@"（%@）", theWeekDay];
	}
	else {
		return @"";
	}
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.smallInfoArray.count + 1;
}

- (void)ReflashAccessLabel:(NSString *)theString {
	[self.downTableView beginUpdates];
	NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
	NSArray *indexPaths = [[NSArray alloc] initWithObjects:indexPath, nil];
	[self.downTableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
	[indexPaths release];
	[self.downTableView endUpdates];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.row == 0) {
		UITableViewCell *cell = [[[UITableViewCell alloc]init] autorelease];
		CGRect cellFrame = [cell frame];
		cellFrame.size.height = topBannerHeight;
		[cell setFrame:cellFrame];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		if (self.theLogo) {
			[self.theLogo removeFromSuperview];
			[tableView addSubview:self.theLogo];
		}
		return cell;
	}
	else {
		static NSString *customCellIdentifier = @"CustomCellIdentifier";
		NewActivityCellController *cell = [tableView dequeueReusableCellWithIdentifier:customCellIdentifier];
		if (cell == nil) {
			cell = [[[NewActivityCellController   alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:customCellIdentifier]autorelease];
		}

		ElderlyNewActivityModel *obj = [self.smallInfoArray objectAtIndex:indexPath.row - 1];
		NSString *date;
		if (obj.activityDateArray) {
			//  NSMutableString *aStr=[[NSMutableString alloc]initWithString:@""];
			NSDateFormatter *isoDateFormatter = [[NSDateFormatter alloc] init];
			[isoDateFormatter setDateFormat:@"yyyy-MM-dd"];
			NSDateFormatter *f = [[NSDateFormatter alloc] init];
			[f setDateFormat:@"EEEE"];
			NSDateFormatter *outPutDateFormatter = [[NSDateFormatter alloc] init];
			[outPutDateFormatter setDateFormat:@"yyyy年MM月dd日"];

			//    for (NSString *str in obj.activityDateArray) {
			NSString *str = [obj.activityDateArray objectAtIndex:0];
			NSDate *aDate = [isoDateFormatter dateFromString:str];
			NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
			NSDateComponents *weekdayComponents = [gregorian components:NSWeekdayCalendarUnit fromDate:aDate];
			[gregorian release];

			NSInteger weekday = [weekdayComponents weekday];
			NSString *weekDayInChinese = [self getChineseWeekDayFromInt:weekday];
			//     NSString *whole=[NSString stringWithFormat:@"%@%@",[outPutDateFormatter stringFromDate:date],weekDayInChinese];
			date = [NSString stringWithFormat:@"%@%@", [outPutDateFormatter stringFromDate:aDate], weekDayInChinese];
			//    [aStr appendString:whole];
			//      [aStr appendString:@"\n"];
			//  }
			[isoDateFormatter release]; isoDateFormatter = nil;
			[f release]; f = nil;
			[outPutDateFormatter release]; outPutDateFormatter = nil;
		}
		else {
			date = lang(@"noHav");
		}

		[cell setTitle:[ElderlyUtils text:obj key:@"title"]];
		[cell setDate:date];
		// [date release];
		[cell setArea:[ElderlyUtils text:obj key:@"activeArea"]];

		NSString *price = nil;
		//   NSLog(@"obj %@",obj);
		if ([[ElderlyUtils text:obj key:@"fee"] length] != 0) {
			if ([[ElderlyUtils text:obj key:@"fee"] integerValue]) {
				price = [NSString stringWithFormat:@"%@：＄%@", lang(@"newActivityDetailSubTitle_address"), [ElderlyUtils text:obj key:@"fee"]];
			}
			else {
				price = lang(@"free");
			}
		}
		else if ([[ElderlyUtils text:obj key:@"menberFee"] length] > 0) {
			if ([[ElderlyUtils text:obj key:@"menberFee"] integerValue]) {
				price = [NSString stringWithFormat:@"%@：＄%@", lang(@"memberCharge"), [ElderlyUtils text:obj key:@"menberFee"]];
			}
			else {
				price = [NSString stringWithFormat:@"%@：＄%@", lang(@"memberCharge"), lang(@"free")];
			}
		}
		else if ([[ElderlyUtils text:obj key:@"nonMenberFee"] length] != 0) {
			if ([[ElderlyUtils text:obj key:@"nonMenberFee"] integerValue]) {
				price = [NSString stringWithFormat:@"%@：＄%@", lang(@"nonMenberCharge"), [ElderlyUtils text:obj key:@"nonMenberFee"]];
			}
			else {
				price = [NSString stringWithFormat:@"%@：＄%@", lang(@"nonMenberCharge"), lang(@"free")];
			}
		}
		[cell setPrice:price];

		[cell  adjustSize];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		CGRect cellFrame = [cell frame];

		cellFrame.size.height = cell.myHeight;

		if (indexPath.row == self.smallInfoArray.count) cellFrame.size.height = cell.myHeight + 25;
		[cell setFrame:cellFrame];
		cell.tag = indexPath.row;
		return cell;
	}
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
	return cell.frame.size.height;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {  //0 row is the banner, should not be selected.
	if (indexPath.row) [self showActvtyDetailWithRowNumber:indexPath.row - 1];
}

static bool isShouldLoad = NO;
bool isloading = 0;

- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
	CGPoint offset = aScrollView.contentOffset;
	CGRect bounds = aScrollView.bounds;
	CGSize size = aScrollView.contentSize;
	UIEdgeInsets inset = aScrollView.contentInset;
	float y = offset.y + bounds.size.height - inset.bottom;
	float h = size.height;
	// NSLog(@"offset: %f", offset.y);
	// NSLog(@"content.height: %f", size.height);
	// NSLog(@"bounds.height: %f", bounds.size.height);
	// NSLog(@"inset.top: %f", inset.top);
	// NSLog(@"inset.bottom: %f", inset.bottom);
	// NSLog(@"pos: %f of %f", y, h);

	float reload_distance =  10;      //超出底部多少才显示已经到底或者触发更新
	float StillSomeThingDistance = 0; //距离底部多远会显示下面还有内容
	if ((y > h + reload_distance) && (!self.scrolledToButtom)) { /**/
		if (didloadALldata || offsetCounter > 199) [self.bottomBar reachedBottom];
		if (!didloadALldata && isShouldLoad && (!isloading)) [self reflashDownTable];
		isShouldLoad = !isShouldLoad;
		self.scrolledToButtom = YES;
	}
	if ((y < h + 1) && (self.scrolledToButtom)) {
		self.scrolledToButtom = NO;
	}

	if (y < h - StillSomeThingDistance) {
		[self.bottomBar notReachedBottom];
		self.scrolledToButtom = NO;
	}
}

- (void)dealloc {
//    [self.theLogo stopTimer];
	self.theLogo = nil;
	didloadALldata = NO;
	offsetCounter = 0;
	self.smallInfoArray = nil;
	self.theSelector = nil;
	self.bottomBar = nil;
	self.bannerArray = nil;
	self.smallInfoArray = nil;//在下面
	self.detailInfoArray = nil;//活动详情
	self.downTableView = nil;
	[super dealloc];
}

@end
