//
//  ActivityDetailViewController.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-9-2.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#import "GTGZThemeManager.h"
#import "Reachability.h"
#import <CoreText/CoreText.h>
#import <QuartzCore/QuartzCore.h>
#import "ActivityDetailViewController.h"
#import "ElderlyNavigationController.h"
#import "NewActivityViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyThemeGridModel.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "LoadingView.h"
#import "ActivityOrganizerSelector.h"
#import "TopBanner.h"
#import "GTGZHorizalTableView.h"
#import "ScrollViewBottomBar.h"
#import "ElderlyBannerModel.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyHTTPRequestManager.h"
#import "AsyncTask.h"
#import "ElderlyAlertUtils.h"
#import "ElderlyUtils.h"
#import "ElderlyIphoneWebBrowserViewController.h"
#import "ElderlyMapViewController.h"
#import "ViewController.h"
#import "TwitterHelper.h"
#import "ShareingObject.h"
#import "FacebookHelper.h"
#import "ElderlyAlertUtils.h"
#import "String_Date_Time_Formater.h"
#import "ButtonText.h"
#import "String_Date_Time_Formater.h"
#import "ElderlyGA.h"
#import "ElderlyCacheManager.h"

#define topBannerHeight 167
#define buttonHeight  38
#define contentEdge 12 //详细内容与边界之间的空位



@interface ActivityDetailViewController() <UIScrollViewDelegate,bannerHit, TwitterHelperDelegate,weiboWeiProtocol,MFMailComposeViewControllerDelegate>

@property(nonatomic,retain)TopBanner *topLogo;
@property (retain, nonatomic) IBOutlet UILabel *lblActivityBigTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblActivityDescription;
@property (retain,nonatomic)NSMutableArray *barTitleArray;
@property (retain,nonatomic)NSMutableArray *contentArray;
@property (retain,nonatomic)NSMutableArray *buttonArray;
@property (retain,nonatomic)NSMutableArray *buttonTitleArray;
@property (retain,nonatomic)UIScrollView *myScrollView;
@property (retain,nonatomic)NSString *reachBottomNotificationKey;
@property (assign)Boolean scrolledToButtom;
@property (retain,nonatomic)NSString *dates;
@property (retain,nonatomic)NSString *charge;
@property (retain,nonatomic)NSString *target;
@property (retain,nonatomic)NSString *content;
@property(retain,nonatomic)NSMutableArray *stringArrayForSubContents;
@property (retain,nonatomic)UIColor *myMainColor;
@property (retain,nonatomic)UIView *buttonBar;
@property (retain,nonatomic)UIView *shareView;
@property (retain,nonatomic)ViewController *weiboController;
@property (retain,nonatomic)NSString *stringToShare;
@property (retain, nonatomic) ShareingObject *shareingObject;
@property (retain,nonatomic)NSArray *stringArrayForSubTitle;
@property   (retain,nonatomic)CATextLayer *openWebConfirmLayer;
@property (retain,nonatomic)ButtonText *openLinkConfirmBtn;
@property (retain,nonatomic)ButtonText *openLinkCancelBtn;
@property (retain,nonatomic)UIView *openLinkConfirmView;
@property (retain,nonatomic)NSString *telNumber;

@end

@implementation ActivityDetailViewController
@synthesize topLogo=_topLogo;
@synthesize theBannerArray=_theBannerArray;
@synthesize theActivity=_theActivity;
@synthesize barTitleArray=_barTitleArray;
@synthesize contentArray=_contentArray;
@synthesize buttonArray=_buttonArray;
@synthesize reachBottomNotificationKey=_reachBottomNotificationKey;
@synthesize scrolledToButtom;
@synthesize dates=_dates;
@synthesize charge=_charge;
@synthesize target=_target;
@synthesize content=_content;
@synthesize  myScrollView;
@synthesize lblActivityBigTitle;
@synthesize lblActivityDescription;
@synthesize myMainColor;
@synthesize buttonTitleArray=_buttonTitleArray;
@synthesize stringArrayForSubContents=_stringArrayForSubContents;
@synthesize organizerType;
@synthesize buttonBar;
@synthesize shareView;
@synthesize weiboController;
@synthesize stringToShare=_stringToShare;
@synthesize shareingObject;
@synthesize stringArrayForSubTitle=_stringArrayForSubTitle;
@synthesize openWebConfirmLayer;
@synthesize openLinkConfirmBtn;
@synthesize openLinkCancelBtn;
@synthesize openLinkConfirmView;
@synthesize telNumber;
//@synthesize sharedBody=_sharedBody;

//@synthesize facebook;
-(void)ReflashAccessLabel:(NSString *)theString{
    
}
-(NSString *)stringToShare{
    return [NSString stringWithFormat:@"%@ %@ %@ %@\n %@ www.LinkForDownloadingTheApplication.com",lang(@"comeOn"),[ElderlyUtils text:self.theActivity key:@"title"],lang(@"activityLink"),self.theActivity.link,lang(@"appDownLoadLink")];
}

-(void)viewDidAppear:(BOOL)animated
{
    
}


-(NSMutableArray *)stringArrayForSubContents{
     _stringArrayForSubContents=nil;

    _stringArrayForSubContents=[[NSMutableArray alloc] initWithObjects:
                                self.content,
                                [NSString stringWithFormat:@"%@\n%@",[ElderlyUtils text:self.theActivity key:@"organlization"],[ElderlyUtils text:self.theActivity key:@"activityCenterName"]],
                                self.dates,
                                self.theActivity.startTime,
                                [ElderlyUtils text:self.theActivity key:@"location"],
                                self.charge,
                                [ElderlyUtils text:self.theActivity key:@"applicationMethod"],
                                self.target,
                                [ElderlyUtils text:self.theActivity key:@"ageLowerLimit"],
                                [ElderlyUtils text:self.theActivity key:@"remark"],
                                nil];
//    _stringArrayForSubContents=someArray;
//    [someArray release];someArray=nil;
    
    return _stringArrayForSubContents;
}

-(NSArray *)stringArrayForSubTitle{
      _stringArrayForSubTitle=[[NSArray alloc]
                          initWithObjects:lang(@"newActivityDetailSubTitle_content"),
                          lang(@"newActivityDetailSubTitle_sponser"),
                          lang(@"newActivityDetailSubTitle_date"),
                          lang(@"newActivityDetailSubTitle_price"),
                          lang(@"newActivityDetailSubTitle_time"),
                          lang(@"newActivityDetailSubTitle_address"),
                          lang(@"newActivityDetailSubTitle_registerMethod"),
                          lang(@"newActivityDetailSubTitle_targetedPersons"),
                          lang(@"newActivityDetailSubTitle_ageLimit"),
                          lang(@"newActivityDetailSubTitle_otherInfo"),
                          nil];
     return _stringArrayForSubTitle;
}

-(NSMutableArray *)buttonTitleArray{
    if (!_buttonTitleArray) {
        _buttonTitleArray=[[NSMutableArray alloc]init];
    }
    return _buttonTitleArray;
}

-(void)setTitleBackGroundColor:(UIColor *)theColor{
  //  NSLog(@"%@",theColor);
    //UIColor *darker=[self darkerColorForColor:theColor];
    
    for (UILabel *lbl in self.barTitleArray) {
        lbl.backgroundColor=theColor;
    }
    for (UILabel *lbl in self.buttonArray) {
        lbl.backgroundColor=theColor;
    }
    
}

-(void)setTitleTextColor:(UIColor *)theColor{
    for (UILabel *lbl in self.barTitleArray) {
        lbl.textColor=theColor;
    }
}
-(NSString *)content{
//    if (!([[ElderlyUtils text:self.theActivity key:@"activityDetail"]isEqualToString:@""]||[[ElderlyUtils text:self.theActivity key:@"activityDetail"]isEqualToString:@" "])) {
        _content=[ElderlyUtils text:self.theActivity key:@"activityDetail"];
//    }else{_content=lang(@"seeTheLink");}
    return _content;
}

-(NSString *)target{
//    if (!([[ElderlyUtils text:self.theActivity key:@"activityTarget"]isEqualToString:@""]||[[ElderlyUtils text:self.theActivity key:@"activityTarget"]isEqualToString:@" "])) {
        _target=[ElderlyUtils text:self.theActivity key:@"activityTarget"];
//    }else{_target=@"不限";}
    return _target;
}

-(NSString *)charge{
    
    _charge=Nil;
    
    NSMutableString *aStr=[[NSMutableString alloc]initWithString:@""];
    if ([[ElderlyUtils text:self.theActivity key:@"fee"]  length]){
        if([[ElderlyUtils text:self.theActivity key:@"fee"] floatValue]){
        [aStr appendString:@"$"];
        [aStr appendString:[ElderlyUtils text:self.theActivity key:@"fee"]];
        [aStr appendFormat:@"\n"];
        }else{
        [aStr appendString:lang(@"free")];
        [aStr appendFormat:@"\n"];
        }
    }
//    else if([[ElderlyUtils text:self.theActivity key:@"fee"]  length]<1 || [ElderlyUtils text:self.theActivity key:@"fee"] == nil){
//            
//        }
//    
    if ([[ElderlyUtils text:self.theActivity key:@"menberFee"] length]) {
        if ([[ElderlyUtils text:self.theActivity key:@"menberFee"] floatValue]) {
            [aStr appendString:[NSString stringWithFormat:@"%@:$",lang(@"memberCharge")]];
            [aStr appendString:[ElderlyUtils text:self.theActivity key:@"menberFee"]];
            [aStr appendFormat:@"\n"];
        }else{
            [aStr appendString:[NSString stringWithFormat:@"%@:",lang(@"memberCharge")]];
            [aStr appendString:lang(@"free")];
            [aStr appendFormat:@"\n"];
        }
        
        
    }
    
    if ([[ElderlyUtils text:self.theActivity key:@"nonMenberFee"]  length]) {
        
        
        if ([[ElderlyUtils text:self.theActivity key:@"menberFee"] floatValue]) {
            [aStr appendString:[NSString stringWithFormat:@"%@:$",lang(@"nonmemberCharge")]];
            [aStr appendString:[ElderlyUtils text:self.theActivity key:@"nonMenberFee"]];
        }else{
            [aStr appendString:[NSString stringWithFormat:@"%@:",lang(@"nonmemberCharge")]];
            [aStr appendString:lang(@"free")];
            [aStr appendFormat:@"\n"];
        }

        
    }
    
    if ([aStr length]) {
        _charge=[aStr copy];
    }else{
        _charge=@"";//lang(@"noHav");
    }
    
    [aStr release];aStr=nil;
    
    return _charge;
}
    
-(NSString *)getChineseWeekDayFromInt:(int )weekDay{
    NSString *theWeekDay=nil;
    switch (weekDay) {
        case 1:
            theWeekDay=lang(@"weekday7");
            break;
        case 2:
            theWeekDay=lang(@"weekday1");
            break;
        case 3:
            theWeekDay=lang(@"weekday2");
            break;
        case 4:
            theWeekDay=lang(@"weekday3");
            break;
        case 5:
            theWeekDay=lang(@"weekday4");
            break;
        case 6:
            theWeekDay=lang(@"weekday5");
            break;
        case 7:
            theWeekDay=lang(@"weekday6");
            break;
        default:
            break;
    }
    if (theWeekDay) {
        return [NSString stringWithFormat:@"（%@）", theWeekDay];
        
    }else{
        return @"";
    }
}
-(NSString *)getChineseWeekDay:(NSString *)weekDay{
    NSString *theWeekDay=nil;
    //CFStringTokenizerCopyBestStringLanguage(weekDay,{1})
    if ([weekDay isEqualToString:@"Monday"]) theWeekDay=lang(@"weekday1");
    if ([weekDay isEqualToString:@"Tuesday"]) theWeekDay=lang(@"weekday2");
    if ([weekDay isEqualToString:@"Wednesday"]) theWeekDay=lang(@"weekday3");
    if ([weekDay isEqualToString:@"Thursday"]) theWeekDay=lang(@"weekday4");
    if ([weekDay isEqualToString:@"Friday"]) theWeekDay=lang(@"weekday5");
    if ([weekDay isEqualToString:@"Saturday"]) theWeekDay=lang(@"weekday6");
    if ([weekDay isEqualToString:@"Sunday"]) theWeekDay=lang(@"weekday7");
    if (!theWeekDay) {
        theWeekDay=[NSString stringWithFormat:@"（%@）",weekDay];
    }
    return theWeekDay;
}
-(NSString *)getDateInFormat:(NSString *)theodate{
    NSDateFormatter *isoDateFormatter = [[NSDateFormatter alloc] init];
    [isoDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDateFormatter *weekDayFormat = [[NSDateFormatter alloc] init];
    [weekDayFormat setDateFormat:@"EEEE"];
    NSDateFormatter *outPutDateFormatter = [[NSDateFormatter alloc] init];
    [outPutDateFormatter setDateFormat:@"yyyy年MM月dd日"];
    NSString *whole = nil;
    if (![theodate isEqualToString:@""]) {
        NSDate *theDate=[isoDateFormatter dateFromString:theodate];
     //   NSLog(@"%@ %@",theDate,self.theActivity.dateArray);
        //   NSLog(@"%@ ",[f stringFromDate:date]);
        NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *weekdayComponents =[gregorian components:NSWeekdayCalendarUnit fromDate:theDate];
        NSInteger weekday = [weekdayComponents weekday];
        NSString *weekDayInChinese=[self getChineseWeekDayFromInt:weekday];
        
        //   NSString *weekDayInChinese=[self getChineseWeekDay:[weekDayFormat stringFromDate:theDate]];
        whole=[NSString stringWithFormat:@"%@%@",[outPutDateFormatter stringFromDate:theDate],weekDayInChinese];
        [gregorian release];
      }
    else{
        whole=@"";
       // whole = lang(@"noHav");
    }
    [weekDayFormat release];
    [isoDateFormatter release];
    [outPutDateFormatter release];
    return whole;
}

-(NSString *)dates{
    if (!_dates) {

        if (!self.theActivity.dateArray){
            //dateArray 没有數據
            _dates=@"";
           // _dates=lang(@"noHav");
            
        }else{
            //有数据
            if ([self.theActivity.activityType  isEqualToString:@"L"]) {
                // 康民处的特别处理
                    NSString *startDate=[String_Date_Time_Formater getADateFromNSArray:self.theActivity.dateArray fromFormat:nil toFormat:nil atIndex:0];
                    NSString *endDate=[String_Date_Time_Formater changeDate:self.theActivity.endDate FormatFrom:nil to:nil showWeekDay:YES];
                
                    if ([startDate isEqualToString:endDate]) {
                        //起始和結束日一樣
                        _dates=startDate;
                    }else{
                        //起始和結束日不一樣
                        _dates=[NSString stringWithFormat:@"%@\n                     至\n%@",startDate,endDate];
                        }
                }else{
                //长者活动中心
                            _dates=[String_Date_Time_Formater   getAllDateFromNSArray:self.theActivity.dateArray fromFormat:nil toFormat:nil];
                         }
             }
        
    }
     return _dates;
    
    
}
-(NSString *)reachBottomNotificationKey{
    if (!_reachBottomNotificationKey) {
        _reachBottomNotificationKey=@"newActivityDetailReachedBottom";
    }
    return _reachBottomNotificationKey;
}

-(NSMutableArray *)barTitleArray{
    if (!_barTitleArray) {
        _barTitleArray=[[NSMutableArray alloc] init];
    }
    return  _barTitleArray;
}

-(NSMutableArray *)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray alloc] init];
    }
    return  _contentArray;
}

-(NSMutableArray *)buttonArray{
    if (!_buttonArray) {
        _buttonArray=[[NSMutableArray alloc] init];
    }
    return  _buttonArray;
}



-(ElderlyActivityDetailModel *)theActivity{
      return _theActivity;
}



-(void)theBanner:(TopBanner *)sender Hited:(NSString *)link BannerID:(NSString *)bannerID{
    
    ElderlyIphoneWebBrowserViewController *controller=[[ElderlyIphoneWebBrowserViewController alloc]init];
     [self.navigationController pushViewController:controller animated:YES];
    [controller loadRequestAfterDelay:link];
    [controller release];
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_BANNER ActionCode:GA_CODE_CLICK LabelCode:bannerID];
}

#define yLevel1 0.28
#define yLevel2 0.35
#define yLevel3 0.6
-(void)share{
    UIView *shareBackGround=[[UIView alloc]init];
    shareBackGround.accessibilityViewIsModal=YES;
    shareBackGround.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.9];
    [shareBackGround setFrame:[[UIScreen mainScreen] bounds]];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake( shareBackGround.frame.size.width*0.23, 0.1*shareBackGround.frame.size.height, shareBackGround.frame.size.width*0.54, 0.09*shareBackGround.frame.size.height)];
    label.text=lang(@"shareTo");
   [label theme:@"bigWhiteTitleWithClearBg"];
     label.textAlignment=NSTextAlignmentCenter;
 
    [shareBackGround addSubview:label];
    [label release]; label=nil;
    //6 share button
    NSMutableArray *imgIconArray=[[NSMutableArray alloc]init];
    [imgIconArray addObject:[UIImage imageNamed:@"icon_facebook.png"]];
    [imgIconArray addObject:[UIImage imageNamed:@"icon_weibo.png"]];
    [imgIconArray addObject:[UIImage imageNamed:@"icon_twitter.png"]];
    // [imgIconArray addObject:[UIImage imageNamed:@"icon_whatsapp.png"]];
    [imgIconArray addObject:[UIImage imageNamed:@"icon_sms.png"]];
    [imgIconArray addObject:[UIImage imageNamed:@"icon_email.png"]];
    
    UIImage *img_facebook=[UIImage imageNamed:@"icon_facebook.png"];
    float iconWidth=img_facebook.size.width;
    float iconHeight=img_facebook.size.height;
 //   float x1=0.1*self.view.frame.size.width;
    float x2=(self.view.frame.size.width-iconWidth)/2;
//    float x3=self.view.frame.size.width*0.9-iconWidth;
    float x12=self.view.frame.size.width/3-iconWidth/2;
    float x23=self.view.frame.size.width/3*2-iconWidth/2;
    float y1=self.view.frame.size.height*yLevel1;
    float y2=y1+128;
    float y3=shareBackGround.frame.size.height-44*3;
    
    NSMutableArray *rectArray=[[NSMutableArray alloc]init];
   // [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x1, y1, iconWidth, iconHeight)]];
    [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x12, y1, iconWidth, iconHeight)]];
    [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x2, y1, iconWidth, iconHeight)]];
 //   [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x3, y1, iconWidth, iconHeight)]];
    [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x23, y1, iconWidth, iconHeight)]];
    //[rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x1, y2, iconWidth, iconHeight)]];
    [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x12, y2, iconWidth, iconHeight)]];
    [rectArray addObject:[NSValue valueWithCGRect:CGRectMake(x23, y2, iconWidth, iconHeight)]];
    
    NSArray *labelStringArray=[[NSArray alloc]initWithObjects:lang(@"facebook"),lang(@"blog"),lang(@"twitter"),lang(@"sms"),lang(@"Email"),nil];
    
    for (int i=0; i<labelStringArray.count; i++) {
         
        CGRect theRect=[[rectArray objectAtIndex:i] CGRectValue];
        UIButton *thebutton=[self  creatButtonWithImg:(UIImage *)[imgIconArray objectAtIndex:i]  andRect:theRect];
        [thebutton addTarget:self action:@selector(shareMethodChoosed:) forControlEvents:UIControlEventTouchUpInside];
        thebutton.tag=i;
        [shareBackGround addSubview:thebutton];
        
        // the label below the icon
        UILabel *label=[[UILabel alloc]init];
        label.frame=CGRectMake( 0, 0, 120, 50);
        label.text=[labelStringArray objectAtIndex:i];
        [label theme:@"newActivityDetail_shareIconLabel"];
        [label sizeToFit];
        label.center=thebutton.center;
        label.center =CGPointMake(label.center.x ,label.center.y+44);
        [shareBackGround addSubview:label];
        if (i==1) {
            thebutton.hidden=YES;
            label.hidden=YES;
        }
        [label release];label=nil;
     
    }
    [imgIconArray release]; imgIconArray=nil;
    [rectArray release];rectArray=nil;
    [labelStringArray release]; labelStringArray=nil;
     // the cancel button

    UIImage* cancelImg=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_cancel_%@.png"];
    ButtonText *cancelButton=[[ButtonText alloc] initWithFrame:CGRectMake(self.view.frame.size.width*0.22, y3, self.view.frame.size.width*0.56,44)];
    cancelButton.backgroundColor=self.myMainColor;
    cancelButton.layer.cornerRadius = 6;
    cancelButton.clipsToBounds = YES;
    cancelButton.tag=999;
    [cancelButton addTarget:self action:@selector(cancelButton:)   forControlEvents:UIControlEventTouchUpInside];
    cancelButton.spacing=5.0f;
    [cancelButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_cancel.png"]];
    [cancelButton text:lang(@"cancel")];
    [cancelButton theme:@"picker_button_label"];
    [cancelButton setBackgroundImage:cancelImg forState:UIControlStateNormal];
    [shareBackGround addSubview:cancelButton];
    [cancelButton release];
    
    shareBackGround.alpha=0;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.38];
    shareBackGround.alpha=1;
    [UIView setAnimationDelegate:self];
    //   [UIView setAnimationDidStopSelector:@selector(removeBannerFadedOut)];
 	[UIView commitAnimations];
    self.shareView=shareBackGround;
    [self.navigationController.view addSubview:self.shareView];
    [shareBackGround release];shareBackGround=nil;
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_SHAREBUTTON];
}

-(void)showViewInAnmination:(UIView *)view{
    view.alpha=0;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.38];
    view.alpha=1;
    [UIView setAnimationDelegate:self];
  	[UIView commitAnimations];
}

-(void)showWeiBo{
    
    if (!self.weiboController) {
        ViewController *weiboHelper=[[ViewController alloc]init];
        weiboHelper.delegate=self;
        weiboHelper.theThing=self.stringToShare;
     self.weiboController=weiboHelper;
    [weiboHelper release];

    }
     [self.shareView addSubview:self.weiboController.view];
    [(ViewController  *)self.weiboController share:Nil];
}

-(void)hitCancel{
    [self.weiboController.view removeFromSuperview];
   
  //  self.weiboController=nil;
    
    
}
-(void)sendSMS{
    if([MFMessageComposeViewController canSendText]){
        MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
        picker.messageComposeDelegate = self;
        picker.body=self.stringToShare;
        picker.wantsFullScreenLayout = NO;
         [self presentModalViewController:picker animated:YES];
        [[UIApplication sharedApplication] setStatusBarHidden:YES];
         [picker release];picker=nil;
    }else{
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:lang(@"SMSCanotSend")
                              message:nil
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];    }
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    NSString *alertString=nil;
    switch (result)
    {
        case MFMailComposeResultCancelled:
            alertString=lang(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
          alertString=lang (@"Mail saved");
            break;
        case MFMailComposeResultSent:
            alertString=lang (@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            alertString=lang(@"failure"); //[error localizedDescription]);
            break;
        default:
            break;
    }
    
    // Close the Mail Interface
    [self dismissModalViewControllerAnimated:YES];// completion:NULL];
    [ElderlyAlertUtils  showAlert:alertString delegate:nil];
}


- (IBAction)showEmail:(id)sender {
  //  NSLog(@"[MFMailComposeViewController canSendMail]%d",[MFMailComposeViewController canSendMail]);
    if ([MFMailComposeViewController canSendMail]) {
    // Email Subject
    NSString *emailTitle = [NSString stringWithFormat:@"%@：%@",lang(@"elderly"),[ElderlyUtils text:self.theActivity key:@"title"]];
    // Email Content
 //   NSString *messageBody =self.stringToShare;
    // To address
    NSArray *toRecipents = [NSArray arrayWithObject:@""];
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    [mc setSubject:emailTitle];
//NSLog(@"self.stringtoshare %@",self.stringToShare);
   [mc setMessageBody:self.stringToShare isHTML:NO];
    //    messageBody=nil;
    [mc setToRecipients:toRecipents];
    
    // Present mail view controller on screen
    [self   presentModalViewController:mc animated:YES];
       //  [mc release];mc=nil;
    }else{
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:lang(@"EmailCanotSend")
                              message:nil
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
   
}

- (void)shareTwitter{
//    NSString *messageBody = [NSString stringWithFormat:@"%@ %@ %@ %@\n %@ www.LinkForDownloadingTheApplication.com",lang(@"comeOn"),[ElderlyUtils text:self.theActivity key:@"title"],lang(@"activityLink"),self.theActivity.link,lang(@"appDownLoadLink")];
    
    if(twitterHelper==nil){
        twitterHelper=[[TwitterHelper alloc] init];
        twitterHelper.delegate=self;
    }
    ShareingObject *tmpShareingObject = [[ShareingObject alloc] init];
    self.shareingObject = tmpShareingObject;
    [tmpShareingObject release];
    
    self.shareingObject.adTitle = [ElderlyUtils text:self.theActivity key:@"title"];
    self.shareingObject.adLink = self.theActivity.link;
    
    [twitterHelper shareTweet:self.shareingObject];
}

-(void)shareFacebook{

    FacebookHelper* facebookHelper = [FacebookHelper defaultHelper];
    ShareingObject* facebookShareingObject = [[ShareingObject alloc] init];
    
    facebookShareingObject.adTitle = [ElderlyUtils text:self.theActivity key:@"title"];
    facebookShareingObject.adLink = self.theActivity.link;
    
    [facebookHelper shareMessageWithObject:facebookShareingObject];
    [facebookShareingObject release];

}



- (void)messageComposeViewController:(MFMessageComposeViewController *)controller
                 didFinishWithResult:(MessageComposeResult)result {
//    NSString *msg;
//    switch (result)
//    {
//        case MessageComposeResultCancelled:
//            msg=lang(@"SMSCancel");
//            break;
//        case MessageComposeResultSent:
//            msg=lang(@"SMSAlreadySend");
//
//            break;
//        case MessageComposeResultFailed:
//            msg=lang(@"SMSFail");
//            break;
//        default:
//            msg=lang(@"SMSWasNotSent");
//            break;
//    }
//    UIAlertView *alert = [[UIAlertView alloc]
//						  initWithTitle:msg
//                          message:nil
//						  delegate:self
//						  cancelButtonTitle:@"Ok"
//						  otherButtonTitles:nil];
//	[alert show];
//    [alert release];
//    NSLog(@"%@",msg);
    
    [self dismissModalViewControllerAnimated:YES];
}
-(BOOL)checkNetWork{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus internetStatus = [reachability currentReachabilityStatus];
    return internetStatus;
}


-(void)shareMethodChoosed:(UIButton *)sender{
     NSString* shareActionCode = nil;
    if (sender.tag==3) {
         [self sendSMS];
        shareActionCode = @"SMS";
    }else{
        
        if ([self checkNetWork]) {   //network is ok
     
           
            
            switch (sender.tag) {
                case 0:{
                      [self shareFacebook];
                    shareActionCode = @"Facebook";
                      break;
                }
                case 1:{
                    [self showWeiBo];
                    shareActionCode = @"Weibo";
                    break;
                }
                case 2:{  //twitter
                    [self shareTwitter];
                    shareActionCode = @"Twitter";
                    break;
                }
                case 4:{
                    [self showEmail:nil];
                    shareActionCode = @"Email";
                    break;
                }
                 default:
                    break;
             }
        }else{
            [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
        }
    }
     [self cancelButton:self.shareView];
    
    if(shareActionCode != nil){
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_ACTIVITYDETAILSHARE ActionCode:shareActionCode LabelCode:[NSString stringWithFormat:@"%@_%@",self.theActivity.activityId,self.theActivity.title_tc]];
    }
}





-(void)cancelButton:(UIView *)sender{
    UIView *view=nil;
//    if (sender.tag) {
//        view=sender.superview;
//    }else{
//        view=sender;
//    }
    switch (sender.tag) {
        case 0:
            view=sender;

            break;
        case 2:
            view=sender.superview.superview;
            break;
        default:
            view=sender.superview;
            break;
    }
    view.alpha=1;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.38];
    view.alpha=0;
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(removeBannerFadedOut)];
 	[UIView commitAnimations];
    [self performSelector:@selector(remove:)  withObject:view afterDelay:0.38];
}

-(void)remove:(UIView *)sender{
    if(sender)[sender removeFromSuperview];
    sender=nil;
    
}
-(UIButton *)creatButtonWithImg:(UIImage *)img andRect:(CGRect )rect{
    UIButton *thebutton=[UIButton buttonWithType:UIButtonTypeCustom];
    [thebutton setImage:img forState:UIControlStateNormal];
    thebutton.frame=rect;
    return thebutton;
}

#define readChar 16 //char number in confirm openlink view
-(void)openLink{
    //黑的大背景
    UIView *aView=[[UIView alloc] initWithFrame:self.view.bounds];
    aView.accessibilityViewIsModal=YES;
    aView.backgroundColor=[UIColor blackColor];
    aView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
     [self.view addSubview:aView];
 
    //白的小背景
    UIView *textBg=[[UIView alloc] initWithFrame:CGRectMake(0.05*self.view.frame.size.width,100, 0.9*self.view.frame.size.width, 200)];
    textBg.accessibilityViewIsModal=YES;
    textBg.backgroundColor=[UIColor whiteColor];
    textBg.alpha=1;
    [aView addSubview:textBg];
   // [self.view addSubview:textBg];
    
    //提示內容
    NSString *limitedString=[ElderlyUtils text:self.theActivity key:@"title"];
    if ([ElderlyUtils text:self.theActivity key:@"title"].length>readChar)limitedString=[NSString stringWithFormat:@"%@⋯",[[ElderlyUtils text:self.theActivity key:@"title"] substringToIndex:readChar]];
    NSString *confirmStrings=[NSString stringWithFormat:@"%@ “%@” %@",lang(@"nowWeGoto"),limitedString,lang(@"hisWebSite")];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:confirmStrings];
    [string addAttribute:(NSString *)kCTFontAttributeName
                   value:[(id)CTFontCreateWithName((CFStringRef)[UIFont boldSystemFontOfSize:23].fontName,23,NULL) autorelease]
                   range:NSMakeRange(0, string.length)];
    //把字体颜色变
    [string addAttribute:(NSString *)kCTForegroundColorAttributeName
                        value:(id)myMainColor.CGColor
                        range:NSMakeRange(4, (limitedString.length)+3)];
     //字體框
    CATextLayer *aText=[CATextLayer layer];
    aText.backgroundColor=[UIColor whiteColor].CGColor;
  // aText.accessibilityLabel=confirmStrings;
    aText.string=string;
    [string release]; string=nil;
    aText.wrapped=YES;
    aText.contentsScale=2;
     aText.frame= CGRectMake(0.12*textBg.frame.size.width,0.15*textBg.frame.size.height, 0.76*textBg.frame.size.width, 0.63*textBg.frame.size.height);
    self.openWebConfirmLayer=aText;
    aText=nil;
    [textBg.layer addSublayer:self.openWebConfirmLayer];
    
    
    //make a label forvoice over
    UILabel  *aMaskLabel=[[UILabel alloc]initWithFrame:self.openWebConfirmLayer.frame];
    aMaskLabel.text=confirmStrings;
    aMaskLabel.backgroundColor=[UIColor clearColor];
    aMaskLabel.textColor=[UIColor clearColor];
   // aMaskLabel.alpha=0;
    [textBg addSubview:aMaskLabel];
    [aMaskLabel release]; aMaskLabel=nil;
    
    //两个按钮
    // cancel button
    CGRect cancelButtonRect=CGRectMake(0,0.78*textBg.frame.size.height, textBg.frame.size.width/2,0.22*textBg.frame.size.height);
     UIImage* cancelImg=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_cancel_%@.png"];
    ButtonText *cancelButton=[[ButtonText alloc] initWithFrame:cancelButtonRect];
    cancelButton.backgroundColor=self.myMainColor;
     cancelButton.clipsToBounds = YES;
    [cancelButton addTarget:self action:@selector(cancelButton:) forControlEvents:UIControlEventTouchUpInside];
    cancelButton.spacing=5.0f;
    [cancelButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_cancel.png"]];
    [cancelButton text:lang(@"cancel")];
    [cancelButton theme:@"picker_button_label"];
    [cancelButton setBackgroundImage:cancelImg forState:UIControlStateNormal];
    self.openLinkCancelBtn=cancelButton;
    [cancelButton release];
    cancelButton.tag=2;
    [textBg addSubview:self.openLinkCancelBtn];

    // confirm button
    CGRect yesButtonRect=cancelButtonRect;
    yesButtonRect.origin.x=cancelButtonRect.size.width;
    UIImage* yesImg=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_sure_%@.png"];
    ButtonText *yesButton=[[ButtonText alloc] initWithFrame:yesButtonRect];
    yesButton.backgroundColor=[String_Date_Time_Formater darkerColorForColor:self.myMainColor];
    yesButton.clipsToBounds = YES;
    yesButton.tag=2;
    [yesButton addTarget:self action:@selector(jumpToTheWeb) forControlEvents:UIControlEventTouchUpInside];
    yesButton.spacing=5.0f;
    [yesButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_sure.png"]];
    [yesButton text:lang(@"confirm")];
    [yesButton theme:@"picker_button_label"];
    [yesButton setBackgroundImage:yesImg forState:UIControlStateNormal];
    self.openLinkConfirmBtn=yesButton;
    [yesButton release];
    [textBg addSubview:self.openLinkConfirmBtn];
    [textBg release]; textBg=nil;
    self.openLinkConfirmView=aView;
    [aView release];aView=nil;
    [self showViewInAnmination:self.openLinkConfirmView];
}

-(void)jumpToTheWeb{
  //  [self.topLogo stopTimer];
    [self cancelButton:self.openLinkConfirmView];
    ElderlyIphoneWebBrowserViewController *controller=[[ElderlyIphoneWebBrowserViewController alloc]init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller loadRequestAfterDelay:self.theActivity.link];
    [controller release];
}

-(void)joinAtivity{
//    if (self.theActivity.centerId==nil || self.theActivity.centerId.length < 1) {
//        [ElderlyAlertUtils showAlert:lang(@"") delegate:nil];
//
//    }else{
        if ([[self getAppDelegate].databaseManager isMyActivityExisted:self.theActivity.activityId activityType:self.theActivity.activityType]  ) {
            [ElderlyAlertUtils showAlert:lang(@"AlertNewActivityAlreadyJoin") delegate:nil];
        }else{
            [[self getAppDelegate].databaseManager saveMyActivity:self.theActivity];
            //     [(UIButton *)[self.buttonArray objectAtIndex:0] setEnabled:NO];
            [ElderlyAlertUtils showAlert:lang(@"newActivityAlreadyJoin") delegate:nil];
        }
//    }
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_ADDBUTTON];
}
-(void)seeMap{
   
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_MAPBUTTON ActionCode:GA_CODE_CLICK LabelCode:[NSString stringWithFormat:@"%@_%@",self.theActivity.activityId,self.theActivity.title_tc]];
   
    ElderlyMapViewController* mapViewController = [[ElderlyMapViewController alloc] init];
    mapViewController.activityDetailMode = self.theActivity;
    [self.navigationController pushViewController:mapViewController animated:YES];
    [mapViewController release];
   
}

-(void)initView{
   
    
    ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    NSUInteger red, green, blue;
    sscanf([theme.color UTF8String], "#%02X%02X%02X", &red, &green, &blue);
    self.myMainColor = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1];
    
    //0.the scroll view
    UIScrollView *aScrollView=[[UIScrollView alloc] initWithFrame:self.view.bounds];
    aScrollView.accessibilityViewIsModal=YES;
    aScrollView.showsHorizontalScrollIndicator=NO;
    aScrollView.showsVerticalScrollIndicator=NO;
    [aScrollView  setDelegate:self];
    self.myScrollView=aScrollView;
    [self.view addSubview:self.myScrollView];
    [aScrollView release]; aScrollView=nil;
    //1. banner
 
    CGRect contentLogoRect=self.view.frame;
    contentLogoRect.size.height=topBannerHeight;
    
    
    LoadingView *loadingView=[[LoadingView alloc] initWithFrame:contentLogoRect];
     [loadingView startLoading];
    [self.myScrollView addSubview:loadingView];
    
    AsyncTask  *asyncTask = [[self getAppDelegate].httpRequestManager getBannerlist:@"A"];
    [asyncTask setFinishBlock:^{
        
       
        
        NSArray* list=[asyncTask result];
        if(list != nil && list.count > 0){
            [[ElderlyCacheManager sharedInstance] saveActivityDetailCacheData:[asyncTask responseData]];
        }
        else{
           list = [[ElderlyCacheManager sharedInstance] readActivityDetailCacheData];
        }
        
        if(list != nil && list.count > 0){
            NSMutableArray *tempMuArray=nil;
            tempMuArray=[[NSMutableArray alloc] init];
            
            for (id banner in list) {
                if ([banner isKindOfClass:[ElderlyBannerModel class]]) [tempMuArray   addObject:banner];
            }
            
            if (tempMuArray.count){
                NSArray *array = [[NSArray alloc] initWithArray:tempMuArray];
                self.theBannerArray=array;
                [array release];array=nil;
                TopBanner  *Banner=[[TopBanner alloc]initWithFrame:contentLogoRect andArray:self.theBannerArray];
                Banner.delegate=self;
                self.topLogo=Banner;
                [self.myScrollView addSubview:self.topLogo];
                [Banner stopTimer];
                [Banner  release];   Banner=nil;
                
            }
            [tempMuArray release]; tempMuArray=nil;
        }
     

        
        [loadingView stopLoading];
        [loadingView removeFromSuperview];
        [loadingView release];
    }];
    asyncTask=nil;
    
    //2.  "加入活动" "地圖" “分享” “連結”等 4個按鈕
    
    
    NSMutableArray *stringArrayForButtons=[[NSMutableArray alloc]initWithObjects:
                                           lang(@"newActivityDetailBtn_Join"),
                                           lang(@"newActivityDetailBtn_share"),
                                           lang(@"newActivityDetailBtn_map"),
                                           lang(@"newActivityDetailBtn_link"),
                                           nil];
    self.buttonTitleArray=stringArrayForButtons;
    
    UIImage *imgLonger=[UIImage imageNamed:@"btn_join.png"];
    UIImage *imgShorter=[UIImage imageNamed:@"btn_share.png"];
    float edge=(self.view.frame.size.width-imgLonger.size.width-imgShorter.size.width*3)/5;
    
    
    
    //制作较长的button并加到view上，
    [self creatAButton:[stringArrayForButtons objectAtIndex:0]  withImg:imgLonger withEdge:edge];
    //其余3个button
    for (int i=1;i<stringArrayForButtons.count;i++) {
        [self creatAButton:[stringArrayForButtons objectAtIndex:i] withImg:imgShorter  withEdge:edge];
    }
    [stringArrayForButtons release]; stringArrayForButtons=nil;
    
    
    UIButton *buttonJ=[self.buttonArray objectAtIndex:0];
    [buttonJ addTarget:self action:@selector(joinAtivity)  forControlEvents:UIControlEventTouchUpInside];
    [(UIButton  *)[self.buttonArray objectAtIndex:1] addTarget:self action:@selector(share) forControlEvents: UIControlEventTouchUpInside];
    buttonJ = (UIButton  *)[self.buttonArray objectAtIndex:2];
    [buttonJ addTarget:self action:@selector(seeMap) forControlEvents: UIControlEventTouchUpInside];
    buttonJ.enabled = ([self.theActivity.activityType isEqualToString:@"L"])?NO:YES;
 
    
    UIButton *buttonLink=[self.buttonArray objectAtIndex:3];
    [buttonLink addTarget:self action:@selector(openLink)  forControlEvents:UIControlEventTouchUpInside];
    if ([self.theActivity.activityType isEqualToString:@"L"]) {//如果是康文署的活動隱藏“地圖”按鍵，“連結”位置按鍵向前挪
        UIButton *btn1=(UIButton  *)[self.buttonArray objectAtIndex:3];
       UIButton *btn2=(UIButton  *)[self.buttonArray objectAtIndex:2];
        btn1.frame=btn2.frame;
         [btn2 removeFromSuperview];
       // [buttonJ removeFromSuperview];
        
    }
    

    //3. big title
    float contentWidth=self.view.frame.size.width-2*contentEdge;
    CGRect rectBigTitle= CGRectMake(contentEdge,[self getY:[self.buttonArray objectAtIndex:0]], contentWidth,36);
    UILabel *bigTitle=[[UILabel alloc] initWithFrame:rectBigTitle];
    bigTitle.numberOfLines=0;
    [bigTitle setText:[ElderlyUtils text:self.theActivity key:@"title"]];
    [bigTitle   theme:@"newActivityDetail_bigTitle"];
    [bigTitle sizeToFit];

    bigTitle.backgroundColor=[UIColor clearColor];
    bigTitle.textColor=myMainColor;
    self.lblActivityBigTitle=bigTitle;
    [self.myScrollView  addSubview:self.lblActivityBigTitle];
    [bigTitle release]; bigTitle=nil;
   // [self.contentArray addObject:self.lblActivityBigTitle];
    
    //4.description
    CGRect rectDescription=CGRectMake(contentEdge,contentEdge+self.lblActivityBigTitle.frame.origin.y+self.lblActivityBigTitle.frame.size.height, contentWidth, 20);
    UILabel *description=[[UILabel alloc]initWithFrame:rectDescription];
    [description setText:[ElderlyUtils text:self.theActivity key:@"activityDescription"]];
    description.backgroundColor=[UIColor clearColor];
    description.numberOfLines=0;
    [description sizeToFit];
    self.lblActivityDescription=description;
    [self.myScrollView  addSubview:self.lblActivityDescription];
    [description release];description=nil;
  //  [self.contentArray addObject:self.lblActivityDescription];
    
    ;
    [self.lblActivityDescription   theme:@"newActivityDetail_subTitle"];
    //5.10个小标题 及其 內容
    

    NSArray *TempSubTitleStringArray=[self.stringArrayForSubTitle copy];

    int i=0;
    for (NSString *string in TempSubTitleStringArray) {
        
        if ([(NSString *)[ self.stringArrayForSubContents objectAtIndex:i] length] && (![[self.stringArrayForSubContents objectAtIndex:i]isEqualToString:@"NULL"]) ) {
             [self creatASubTitle:string withTagNumber:i];
             [self creatASubContent:[ self.stringArrayForSubContents objectAtIndex:i] withTag:i];
            
         }
        i++;
    }
    
    [TempSubTitleStringArray release];TempSubTitleStringArray=nil;
     UIImage *img=[UIImage imageNamed:@"btn_scroll.png"];
    self.myScrollView.contentSize=CGSizeMake(self.view.frame.size.width,[self getY:[self.contentArray lastObject]]+38+img.size.height);
  
    //底部的 的BAR (“显示是否到底“)
    UIImage *imgBottombar=[UIImage imageNamed:@"btn_scroll.png"];
    CGRect  rectBottomBar=CGRectMake(0,self.view.frame.size.height-44-imgBottombar.size.height,imgBottombar.size.width,imgBottombar.size.height);
    ScrollViewBottomBar *aBottomBar=[[ScrollViewBottomBar alloc]initWithFrame:rectBottomBar];
    self.buttonBar=aBottomBar;
    [self.view addSubview:self.buttonBar];
    [aBottomBar release]; aBottomBar=nil;
    self.scrolledToButtom=NO;
    [self setTitleTextColor:[UIColor whiteColor]];
}

-(void)adjustLabelWidth:(UILabel *)label{
    float contentWidth=self.view.frame.size.width- contentEdge*2;
    [label sizeToFit];
    CGRect tempR= label.frame;
    tempR.size.width=contentWidth;
    label.frame=tempR;
}

-(void)creatAButton:(NSString *)theTitle withImg:(UIImage *)img withEdge:(float)Edge{
    float x;
    if (self.buttonArray.count) {
        x=[self getXFrom:[self.buttonArray lastObject]  with:Edge];
    }else{
        x=Edge;
    }
    CGRect rect=CGRectMake(x, topBannerHeight+Edge , img.size.width,img.size.height);
    UIButton *aButton=[[UIButton alloc]initWithFrame:rect];
    NSString *string=[NSString stringWithFormat:@"%@",theTitle];
    aButton.layer.cornerRadius = 3; // this value vary as per your desire
    aButton.clipsToBounds = YES;
    [aButton.titleLabel theme:@"newActivityDetail_subTitle"];
    aButton.backgroundColor=myMainColor;
    [aButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
    [aButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [aButton setTitle:string forState:UIControlStateNormal];
    [aButton addTarget:self action:@selector(someFuntion)  forControlEvents:UIControlEventTouchUpInside];
    [self.myScrollView addSubview:aButton];
    [self.buttonArray addObject:aButton];
    [aButton release]; aButton=nil;
}

-(void)someFuntion{
 //   NSLog(@"sdfjlasjflkjdslkfjalsdjflksdjflkds");
}

-(void)creatASubTitle:(NSString *)theTitle withTagNumber:(int)tag{
    
    
    UIImage *img=[UIImage imageNamed:@"bg_active_title.png"];
    float y=[self getY:[self.contentArray lastObject]];
    if (!self.contentArray.count) {
        //第一个小标题坐标参照活动详情
        y=[self getY:self.lblActivityDescription];
    }
    CGRect rect=CGRectMake(0, y , img.size.width,img.size.height);
    UILabel *aLabel=[[UILabel alloc]initWithFrame:rect];
    NSString *string=[NSString stringWithFormat:@"  %@",theTitle];
    aLabel.text=string;
    [aLabel theme:@"newActivityDetail_subTitle"];
    aLabel.backgroundColor=myMainColor;
    aLabel.tag=tag;
    [self.myScrollView addSubview:aLabel];
    [self.barTitleArray addObject:aLabel];
    [aLabel release]; aLabel=nil;
    
}

-(void)creatASubContent:(NSString *)theContent withTag:(int)tag{
    
    float y=[self getY:[self.barTitleArray lastObject]];
    CGRect rect=CGRectMake(contentEdge, y , self.view.frame.size.width-2*contentEdge,45);
    UILabel *aLabel=[[UILabel alloc]initWithFrame:rect];
    aLabel.text=theContent;
    if (([theContent isEqualToString:@""])||([theContent isEqualToString:@" "])) {
        aLabel.text=@"沒有";
    }
    [aLabel theme:@"newActivityDetail_subContent"];
    aLabel.numberOfLines=0;
    aLabel.tag=tag;
    [aLabel sizeToFit];

    [self.myScrollView addSubview:aLabel];
    [self.contentArray addObject:aLabel];
   
    
 
    //20140127 begin add by weeka.guo(add call tel Method)
    if(tag == 6){
        NSString* number = [ElderlyUtils getTelNumber:theContent];
       
        if(number != nil){
            self.telNumber = number;
            aLabel.userInteractionEnabled = YES;
            UITapGestureRecognizer *twoFingersTwoTaps =
            [[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(callTel)] autorelease];
            [aLabel addGestureRecognizer:twoFingersTwoTaps];
        }
    }
    //20140127 end add by weeka.guo(add call tel Method)

    [aLabel release]; aLabel=nil;

}

//20140127 begin add by weeka.guo(add call tel Method)
-(void)callTel{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",self.telNumber]]];

}
//20140127 end add by weeka.guo(add call tel Method)

-(float)getXFrom:(UIView *)theViewOntTheLeft with:(float)Edge{
    return theViewOntTheLeft.frame.origin.x+theViewOntTheLeft.frame.size.width+Edge;
}

-(float)getY:(UIView *)theViewAbove{
    return  theViewAbove.frame.origin.y+theViewAbove.frame.size.height+contentEdge;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];}
    return self;
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    [self initView];
    
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_ACTIVITYDETAIL_ACTIVITYNUMBER_ACTIVITYTITLE];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"newActivityDetail")];
}

-(void)navigationLeftClick{
    
 //   NSLog(@"navigationLeftClick");
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
//    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}
-(NSInteger)themeIndex{
    return 0;
}

-(void)adjustView:(UILabel *)sender sHightAndYwithView:(UIView *)aView withType:(Boolean)isASubTitle{
    CGRect temp=sender.frame;
    temp.origin.y= aView.frame.origin.y+aView.frame.size.height+8;
    sender.frame=temp;
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"newActivityDetail")];
    
    ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    NSUInteger red, green, blue;
    sscanf([theme.color UTF8String], "#%02X%02X%02X", &red, &green, &blue);
    self.myMainColor = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1];
    
    //上面4個按鈕
    
    for (int i=0;i<self.buttonArray.count;i++) {
        [ (UIButton *)[self.buttonArray objectAtIndex:i] theme:@"newActivityDetail_subTitle"];
    }
    
    [(UIButton *)[self.buttonArray objectAtIndex:0] setTitle:lang(@"newActivityDetailBtn_Join") forState:UIControlStateNormal];
    [(UIButton *)[self.buttonArray objectAtIndex:1] setTitle:lang(@"newActivityDetailBtn_share") forState:UIControlStateNormal];
    [(UIButton *)[self.buttonArray objectAtIndex:2] setTitle:lang(@"newActivityDetailBtn_map") forState:UIControlStateNormal];
    [(UIButton *)[self.buttonArray objectAtIndex:3] setTitle:lang(@"newActivityDetailBtn_link") forState:UIControlStateNormal];
    
    
    //上面兩個活動描述
    [self adjustLabelWidth:self.lblActivityBigTitle];
    self.lblActivityBigTitle.numberOfLines=0;
    self.lblActivityBigTitle.Text=[ElderlyUtils text:self.theActivity key:@"title"];
    self.lblActivityBigTitle.textColor=myMainColor;
    [self.lblActivityBigTitle theme:@"newActivityDetail_bigTitle"];
    [self.lblActivityBigTitle sizeToFit];
    
    [self adjustLabelWidth:self.lblActivityDescription];
    self.lblActivityDescription.Text=[ElderlyUtils text:self.theActivity key:@"activityDescription"];
    //
    [self.lblActivityDescription theme:@"newActivityDetail_subContent"];
    [self.lblActivityDescription sizeToFit];
    [self adjustView:self.lblActivityDescription  sHightAndYwithView:self.lblActivityBigTitle withType:NO];
    
    //具體每一項內容
//    for (int i=0; i<self.contentArray.count; i++) {
    for (UILabel  *lbl in self.contentArray) {
        [self adjustLabelWidth:lbl];
        lbl.text=[self.stringArrayForSubContents objectAtIndex:lbl.tag];
        [lbl theme:@"newActivityDetail_subContent"];
        [lbl sizeToFit];
    }
    NSMutableArray *TempSubTitleStringArray=[self.stringArrayForSubTitle copy];
     //每個標題
    for (UILabel *lbl in self.barTitleArray) {
        [lbl theme:@"newActivityDetail_subTitle"];
        [lbl setText:[NSString stringWithFormat:@"  %@",[TempSubTitleStringArray objectAtIndex:lbl.tag]]];
        }
    [TempSubTitleStringArray release];TempSubTitleStringArray=nil;
      [self setTitleBackGroundColor:self.myMainColor];

    [self adjustView:(UILabel *)[self.barTitleArray objectAtIndex:0]  sHightAndYwithView:self.lblActivityDescription withType:YES];
    for (int i=0; i<self.contentArray.count; i++) {
        [self adjustView:(UILabel *)[self.contentArray objectAtIndex:i]  sHightAndYwithView:(UILabel *)[self.barTitleArray objectAtIndex:i ] withType:NO];
        if (i<self.contentArray.count-1) {
            [self adjustView:(UILabel *)[self.barTitleArray objectAtIndex:i+1]  sHightAndYwithView:(UILabel *)[self.contentArray objectAtIndex:i] withType:YES];
        }
    }
    //最后一行加长，以放置显示底部ｂａｒ
    UILabel *aLbl=[self.contentArray lastObject];
    CGRect tempRect=aLbl.frame;
    tempRect.size.height=aLbl.frame.size.height+20;
    aLbl.frame=tempRect;
    self.myScrollView.contentSize=CGSizeMake(self.view.frame.size.width,aLbl.frame.origin.y+aLbl.frame.size.height+72);
    
    
     //如果跳至确认框打开
    
      if (self.openLinkConfirmView) {
        
        NSString *theTitle=[ElderlyUtils text:self.theActivity key:@"title"];
        if ([ElderlyUtils text:self.theActivity key:@"title"].length>readChar)theTitle=[NSString stringWithFormat:@"%@⋯",[[ElderlyUtils text:self.theActivity key:@"title"] substringToIndex:readChar]];
        NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@ “%@” %@",lang(@"nowWeGoto"),theTitle,lang(@"hisWebSite")]];
        [string addAttribute:(NSString *)kCTFontAttributeName
                   value:[(id)CTFontCreateWithName((CFStringRef)[UIFont boldSystemFontOfSize:23].fontName,23,NULL) autorelease]
                   range:NSMakeRange(0, string.length)];
    
    //把字体颜色变
        [string addAttribute:(NSString *)kCTForegroundColorAttributeName
                   value:(id)myMainColor.CGColor
                   range:NSMakeRange(4, (theTitle.length)+3)];
    //字體框
        self.openWebConfirmLayer.string=string;
        [string release];string=nil;
        
     }
    
    if (self.openLinkConfirmBtn) {
             [self.openLinkConfirmBtn text:lang(@"confirm")];
             [self.openLinkCancelBtn  text:lang(@"cancel")];
        [self.openLinkConfirmBtn setBackgroundColor:[String_Date_Time_Formater darkerColorForColor:myMainColor]];
        [self.openLinkCancelBtn setBackgroundColor:myMainColor];

    }
 
}



-(void)dealloc{
 
  //  [self.topLogo stopTimer];
    self.topLogo=nil;
    self.barTitleArray=nil;
    self.contentArray=nil;
    self.weiboController=nil;
    self.reachBottomNotificationKey=nil ;
    self.lblActivityBigTitle=nil;
    self.lblActivityDescription=nil;
    self.theBannerArray=nil;
    self.theActivity=nil;
    self.buttonArray=nil;
    self.dates=Nil;
    self.myScrollView=nil;
    self.shareingObject = nil;
    self.buttonBar=nil;
    self.buttonTitleArray=nil;
    self.charge=nil;
    self.content=nil;
    self.myMainColor=nil;
    self.openLinkCancelBtn=nil;
    self.openWebConfirmLayer=nil;
    self.organizerType=nil;
    self.scrolledToButtom=nil;
    self.shareView=nil;
    self.stringArrayForSubContents=nil;
    self.stringArrayForSubTitle=nil;
    self.stringToShare=nil;
    self.target=nil;
    self.openLinkConfirmView=nil;
      self.openWebConfirmLayer=nil;
     self.openLinkConfirmBtn=nil;
     self.openLinkCancelBtn=nil;
    self.telNumber = nil;
    [super dealloc];
    
}

- (void)viewDidUnload {
    [self setBarTitleArray:nil];
    [self setContentArray:nil];
   [super viewDidUnload];
}

-(void)viewWillAppear:(BOOL)animated{
    if (self.topLogo) [self.topLogo startTimer];
}
-(void)viewWillDisappear:(BOOL)animated{
    if (self.topLogo) [self.topLogo stopTimer];

}

- (UIColor *)darkerColorForColor:(UIColor *)c
{
    NSString *version = [[UIDevice currentDevice] systemVersion];
    
    if ([version floatValue] >= 5.0 ) {
        float r, g, b, a;
        if ([c getRed:&r green:&g blue:&b alpha:&a])
            return [UIColor colorWithRed:MAX(r - 0.05, 0.0)
                                   green:MAX(g - 0.05, 0.0)
                                    blue:MAX(b - 0.05, 0.0)
                                   alpha:a];
    }
    return c;
}
- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height -  inset.bottom;
    float h = size.height;
    // NSLog(@"offset: %f", offset.y);
    // NSLog(@"content.height: %f", size.height);
    // NSLog(@"bounds.height: %f", bounds.size.height);
    // NSLog(@"inset.top: %f", inset.top);
    // NSLog(@"inset.bottom: %f", inset.bottom);
    // NSLog(@"pos: %f of %f", y, h);
    float reload_distance =  0;      //超出底部多少才显示已经到底或者触发更新
    float  StillSomeThingDistance=50; //距离底部多远会显示下面还有内容
    if((y > h + reload_distance)&&(!self.scrolledToButtom)) {
    // [[NSNotificationCenter defaultCenter] postNotificationName:self.reachBottomNotificationKey object:nil]; //userInfo:dir];
        self.scrolledToButtom=YES;
        [(ScrollViewBottomBar *)self.buttonBar  reachedBottom];
    }
    if((y<h-StillSomeThingDistance)&&(self.scrolledToButtom)){
        [(ScrollViewBottomBar *)self.buttonBar  notReachedBottom];
        self.scrolledToButtom=NO;
    }
    
}

#pragma mark - TwitterHelperDelegate Methods
-(void)twitterDidClose:(TwitterHelper*)helper{
    
}
@end
