//
//  ViewController.h
//  SinaWeibo
//
//  Created by Ibokan on 12-12-25.
//  Copyright (c) 2012年 Ibokan. All rights reserved.
//

#import <UIKit/UIKit.h>

//#import "SinaWeb/SinaWeibo/SinaWeibo.h"
//#import "SinaWeb.h"
#import "SinaWeibo.h"
#import "SinaWeiboRequest.h"

@protocol weiboWeiProtocol <NSObject>

-(void)hitCancel;

@end

@interface ViewController : UIViewController<SinaWeiboDelegate,SinaWeiboRequestDelegate>
{
    SinaWeibo *_sinaWeibo;
    
    UIButton *_shareButton;
    
    UITextView *_textView;
    
    UIView *_shareView;
    
    UIActivityIndicatorView *_indicator;
    
    NSString *_theThing;
}
@property (retain,nonatomic)NSString *theThing;

@property (retain,nonatomic)id <weiboWeiProtocol>delegate;

@property (readonly, nonatomic) SinaWeibo *sinaWeibo;

@property (retain, nonatomic) UIButton *shareButton;

@property (retain, nonatomic) UITextView *textView;

@property (retain, nonatomic) UIView *shareView;

@property (retain, nonatomic) UIActivityIndicatorView *indicator;

 
- (void) addButton;

- (void) addShareView;

- (void) share:(UIButton*) sender;

- (void) removeShare:(UIButton*) sender;

- (void) sendShare:(UIButton*) sender;

- (void) exitShare:(UIButton*) sender;



@end
