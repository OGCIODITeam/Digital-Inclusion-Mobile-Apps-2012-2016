//
//  NewActvityDetailViewController.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-9-2.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
// @interface MyGreatIOSAppAppDelegate : NSObject <UIApplicationDelegate, FBSessionDelegate>


#import <MessageUI/MessageUI.h>
#import "ElderlyActivityDetailModel.h"
#import "ElderlyIphoneViewController.h"

@class TwitterHelper;
//#import "FBConnect.h"
@interface ActivityDetailViewController : ElderlyIphoneViewController<MFMessageComposeViewControllerDelegate>	{
    TwitterHelper *twitterHelper;
}
@property(nonatomic,retain)ElderlyActivityDetailModel  *theActivity;//
@property(nonatomic,retain)NSArray *theBannerArray;

@property(nonatomic,retain)NSString *organizerType;//activityType:L(康文屬)，E(長者活動中心)

//以下三項現在现在已经不起作用，此view會根據現在的頁面顏色作出相應變化

@property (retain,nonatomic)UIColor *subTitleBackGroundColor; //在view制定的時候傳入
-(void)setTitleBackGroundColor:(UIColor *)theColor; //在view已經生成之後改變顏色
-(void)setTitleTextColor:(UIColor *)theColor;

@end