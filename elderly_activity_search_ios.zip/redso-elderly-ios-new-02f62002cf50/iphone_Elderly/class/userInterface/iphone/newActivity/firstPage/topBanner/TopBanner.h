//
//  TopBanner.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-8-28.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
    //手势的方向
    error=0,
    left ,
    right
} direction;
@class  TopBanner;
@protocol bannerHit  

-(void)theBanner:(TopBanner *)sender
           Hited:(NSString *)link BannerID:(NSString*)bannerID;
@optional
-(void)ReflashAccessLabel:(NSString *)theString;

@end

@interface TopBanner : UIView

@property(nonatomic,retain)NSMutableArray *bannerArray;//接收一個UIView 或其子類的NSArray 然後會以AddSubView的形式逐個顯示上去，所以幾乎可以裝載任何東西的列表
@property(nonatomic,retain)NSArray *URLArray; //或者接收一個URL列表，然後顯示圖片
@property(nonatomic,assign)id <bannerHit>delegate;
-(void)stopTimer;
-(void)startTimer;
- (id)initWithFrame:(CGRect)frame andArray:(NSArray *)theBannerArray;
-(void)bannerClicked;
@end
