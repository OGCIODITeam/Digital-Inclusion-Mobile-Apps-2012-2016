//
//  ActivityOrganizerSelector.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-8-27.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ActivityOrganizerSelector.h"
#import <QuartzCore/QuartzCore.h>
#import "LabelCustomTextField.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyThemeManager.h"
@interface ActivityOrganizerSelector()

@end

@implementation ActivityOrganizerSelector
@synthesize btnLCSD;
@synthesize btnOrganizer ;
-(NSInteger)themeIndex{
    return 0;
}

- (UIColor *)darkerColorForColor:(UIColor *)c
{
    NSString *version = [[UIDevice currentDevice] systemVersion];
    
    if ([version floatValue] >= 5.0 ) {
        float r, g, b, a;
        if ([c getRed:&r green:&g blue:&b alpha:&a])
            return [UIColor colorWithRed:MAX(r - 0.05, 0.0)
                                   green:MAX(g - 0.05, 0.0)
                                    blue:MAX(b - 0.05, 0.0)
                                   alpha:a];
    } 
    return c;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
       UIView *backGround=[[UIView alloc]initWithFrame:(frame)];
        backGround.accessibilityViewIsModal=YES;
        backGround.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        [self addSubview:backGround];

   //     backGround.alpha=0.5;
        UIImage *imga=[UIImage imageNamed:@"btn_activity_red.png"];
         ///////
        ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel/*:[self themeIndex]*/];
        NSUInteger red, green, blue;
        sscanf([theme.color UTF8String], "#%02X%02X%02X", &red, &green, &blue);
        UIColor *MainColor = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1];
     //   UIColor *darker=[self darkerColorForColor:MainColor];
        ///////
     // UIImage *img=[UIImage imageNamed:[[ElderlyThemeManager sharedInstance] getColorImageName]] ;
       
        CGRect rect;
        rect.size=imga.size;
//        NSLog(@"%f",self.frame.size.height);
        rect.origin.y=(frame.size.height-44-20)/2-rect.size.height*1.5;
        rect.origin.x=frame.size.width/2-rect.size.width/2;
        
        UIButton *abutton =[[UIButton alloc] init];
        self.btnLCSD=abutton;
        [abutton release];
         self.btnLCSD.tag=1;
      //  [self.btnLCSD  setBackgroundImage:img  forState:UIControlStateNormal];
        [self.btnLCSD setTitle:lang(@"older_center") forState:UIControlStateNormal];
        [self.btnLCSD theme:@"newActivityDetail_selector"];
        [self.btnLCSD setBackgroundColor:MainColor];
        self.btnLCSD.layer.cornerRadius = 6;
        self.btnLCSD.clipsToBounds = YES;
        [self.btnLCSD addTarget:self action:@selector(ActivityOrganizerSelectorBtnClicked:)  forControlEvents:UIControlEventTouchUpInside];
        [self.btnLCSD setFrame:rect];
        //NSLog(@" %@",lang(@"btnLCSD"));
                
    //  UIImage *img2=[UIImage imageNamed:@"btn_activity_red.png"];
        UIButton *bButton =[[UIButton alloc] init];
        bButton.tag=2;
        bButton.layer.cornerRadius = 6;
        bButton.clipsToBounds=YES;
        [bButton setTitle:lang(@"kanwenshu") forState:UIControlStateNormal];
        [bButton theme:@"newActivityDetail_selector"];
        [bButton setBackgroundColor:MainColor];
        [bButton  addTarget:self action:@selector(ActivityOrganizerSelectorBtnClicked:)  forControlEvents:UIControlEventTouchUpInside];
      //  bButton.accessibilityElementsHidden=NO;
       // bButton.accessibilityViewIsModal=NO;
        rect.origin.y=rect.origin.y+rect.size.height*2;
        [bButton setFrame:rect];
        self.btnOrganizer=bButton;
        [bButton release];
         [backGround addSubview:self.btnOrganizer];
        [backGround addSubview:self.btnLCSD];
        [backGround release]; backGround=nil;
       
    }
    return self;
}


-(void)dealloc{
    self.btnLCSD = nil;
    self.btnOrganizer=nil;
    [super dealloc];
}

-(IBAction)ActivityOrganizerSelectorBtnClicked:(UIButton *)sender{
      NSString *string = nil;
    switch (sender.tag) {
          
        case 1:
             string=@"E";
            break;
        case 2:
             string=@"L";
            break;
        default:{
            break;
        }
    }
    
  //  NSNumber *num=[NSNumber numberWithInt:sender.tag];
//    NSDictionary *dir=[NSDictionary dictionaryWithObject:string forKey:@"Organizer"];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"Organizer" object:nil userInfo:dir];
 //   NSLog(@"[NSNotificationCenter defaultCenter] postNotificationName:@\"Organizer\" userInfo(NSDictionary)=%@ (1=\"康文署\" ,2=\"老年人活动中心\")",dir);
    [self.delegate selectOrganizer:string];
    [self removeFromSuperview];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
