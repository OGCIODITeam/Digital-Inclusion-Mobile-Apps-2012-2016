//
//  NewActivityCellController.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "NewActivityCellController.h"
@interface NewActivityCellController(){

    UILabel *labelTitle;
    UILabel *labelDate;
    UILabel *labelarea;
    UIButton *btnSeeDetail;
    UILabel *labelPrice;

}
//@property (retain, nonatomic) UILabel *labelTitle;
//@property (retain, nonatomic) UILabel *labelDate;
//@property (retain, nonatomic) UILabel *labelarea;
//@property (retain, nonatomic) UIButton *btnSeeDetail;
//@property (retain, nonatomic) UILabel *labelPrice;

@end

@implementation NewActivityCellController
@synthesize rowNumber;
@synthesize myHeight;

#define titleAndDataWidth 268
#define priceAndAreaWidth 100


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    
        labelTitle = [[UILabel alloc] initWithFrame:CGRectMake(9, 8, 268, 50)];
        [self.contentView addSubview:labelTitle];
        [labelTitle release];
        
        labelDate = [[UILabel alloc] initWithFrame:CGRectMake(9, 56, 268, 25)];
        [self.contentView addSubview:labelDate];
        [labelDate release];
        
        labelarea = [[UILabel alloc] initWithFrame:CGRectMake(9, 81, 100, 25)];
        [self.contentView addSubview:labelarea];
        [labelarea release];
        
        btnSeeDetail = [[UIButton alloc] initWithFrame:CGRectMake(283, 68, 37, 38)];
        [self.contentView addSubview:btnSeeDetail];
        [btnSeeDetail release];
        [btnSeeDetail setAccessibilityFrame:CGRectZero];
        
        UIImage *img=[UIImage imageNamed:@"btn_more.png"];
        [btnSeeDetail setImage:img  forState:UIControlStateNormal];
        [btnSeeDetail setFrame:CGRectMake(self.frame.size.width-img.size.width, (self.frame.size.height-img.size.height)/2 , img.size.width,img.size.height)];
        
        labelPrice = [[UILabel alloc] initWithFrame:CGRectMake(142, 81, 108, 25)];
        [self.contentView addSubview:labelPrice];
        [labelPrice release];
        
    }
    return self;
}

-(void)setTitle:(NSString *)title{
    [labelTitle theme:@"newActivityDetail_lowTableTitle"];
    CGRect rect=labelTitle.frame;
    rect.size.width=titleAndDataWidth;
    labelTitle.frame=rect;
    labelTitle.text=title;
    
  //  NSLog(@"%@",self.labelTitle);
    
}
-(void)setDate:(NSString *)date{
 //   NSLog(@"date %@",date);
    
    [labelDate theme:@"newActivityDetail_lowTableContents"];

    CGRect rect=labelDate.frame;
    rect.size.width=titleAndDataWidth;
    labelDate.frame=rect;
    labelDate.text=date;
}

-(void)setArea:(NSString *)area{
    [labelarea theme:@"newActivityDetail_lowTableContents"];

    CGRect rect=labelarea.frame;
    rect.size.width=priceAndAreaWidth;
    labelarea.frame=rect;
    labelarea.text=area;
}

-(void)setPrice:(NSString *)price{
    [labelPrice theme:@"newActivityDetail_lowTableContents"];

    CGRect rect=labelPrice.frame;
    rect.size.width=priceAndAreaWidth;
    labelPrice.frame=rect;
/*
    if ([price length]&&[price floatValue]) {
        NSString *theprice=[NSString stringWithFormat:@"%@ : $%@",lang(@"fee"),price];
        self.labelPrice.text=theprice;
    }else if([price length]&&(![price floatValue])){
 
        NSString *theprice=[NSString stringWithFormat:@"免费"];
        self.labelPrice.text=theprice;}
    else{
       // NSString *theprice=[NSString stringWithFormat:@"费用 : 沒有"];
       // self.labelPrice.text=theprice;
        self.labelPrice.hidden=YES;
    }
    
  //  [self adjustSize];
*/
    labelPrice.hidden=YES;
    if (price) {
        labelPrice.text=price;
        labelPrice.hidden=NO;
    }
}

-(void)adjustSize{
    NSMutableArray *tempArray=[[NSMutableArray alloc] init];
    [tempArray addObject:labelTitle];
    [tempArray addObject:labelDate];
    [tempArray addObject:labelPrice];
    [tempArray addObject:labelarea];
    
    for (int i=0;i<tempArray.count;i++) {
        UILabel  *lbl=[tempArray objectAtIndex:i];
        [lbl sizeToFit];
        
        CGRect Rect = lbl.frame;
        if (i==1) {
             UILabel  *lblLast=[tempArray objectAtIndex:i-1];
            Rect.origin.y=lblLast.frame.origin.y+lblLast.frame.size.height+8;
            lbl.frame=Rect;
        }else if(i==2||i==3){
            UILabel  *lblLast=[tempArray objectAtIndex:1];
            Rect.origin.y=lblLast.frame.origin.y+lblLast.frame.size.height+2;
            lbl.frame=Rect;
            //调整Cell的大小
            self.myHeight=[self getBottom:lbl]+10;
        }
    }
    [tempArray release];
    
    ////////////////////////new
    [labelTitle sizeToFit];
    [labelDate sizeToFit];
    UIImage *img=[UIImage imageNamed:@"btn_more.png"];
    
    
    [btnSeeDetail setFrame:CGRectMake(self.frame.size.width-img.size.width, (self.myHeight-img.size.height)/2 , img.size.width,img.size.height)];
    
    
    
    
}

-(float)getBottom:(UIView *)view{
    return view.frame.origin.y +view.frame.size.height;
}



-(IBAction)seeDetail:(id)sender {
    //    NSNumber *aNum=[NSNumber numberWithInt:self.tag];
    //     NSDictionary *dir=[NSDictionary dictionaryWithObject:aNum
    //                                                   forKey:@"activityDetailWantToSee"];
    //    [[NSNotificationCenter defaultCenter] postNotificationName:@"activityDetailWantToSee" object:nil userInfo:dir];
    //    NSLog(@"[NSNotificationCenter defaultCenter] postNotificationName:@\"activityDetailWantToSee\" userInfo(NSDictionary)=%@ ",dir);
    //
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


- (void)dealloc {

    [super dealloc];
}
@end
