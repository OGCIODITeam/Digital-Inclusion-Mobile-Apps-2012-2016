//
//  NewActivityCellController.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-8-29.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewActivityCellController : UITableViewCell

-(void)setTitle:(NSString *)title;
-(void)setDate:(NSString *)date;
-(void)setArea:(NSString *)area;
-(void)setPrice:(NSString *)price;
-(void)adjustSize;
@property (assign)float myHeight;
@property(nonatomic,retain)NSNumber *rowNumber;
@end
