//
//  TopBanner.m
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-8-28.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "TopBanner.h"
#import "ElderlyBannerModel.h"
#import "GTGZImageDownloadedView.h"
#import "ElderlyApiManager.h"
#import "DownloadImageView.h"
#import "ElderlyIphoneWebBrowserViewController.h"
#import "ElderlyIphoneViewController.h"
#import "myPageControl.h"
#import "LoadingView.h"
//20131118 begin add by weeka.guo
#import "ElderlyCacheManager.h"
#import "ElderlyPathUtils.h"
//20131118 end add by weeka.guo

@interface TopBanner()<myPageControlDelegate>

@property (nonatomic,assign)CGRect rect_leftPositionOutOfScreen;
@property (nonatomic,assign)CGRect rect_rightPositionOutOfScreen;
//@property (nonatomic,retain)UIControl *bannerShowing;
//@property (nonatomic,retain)UIControl *bannerComing;
@property (nonatomic,retain)UIButton *bannerShowing;
@property (nonatomic,retain)UIButton *bannerComing;
@property (assign,nonatomic)int int_currentObjcetIndex;
@property (assign)Boolean isMoving;
@property (assign)int nonActionCount;
@property (nonatomic,assign)myPageControl *pageController;
@property (nonatomic,retain)NSTimer *aTimer;
@property (nonatomic,retain)IBOutlet UIImageView *theLeftArrow;
@property (nonatomic,retain)IBOutlet UIImageView *theRightArrow;
@property (nonatomic,retain)IBOutlet UIButton *theLeftArrowInvsrb;
@property (nonatomic,retain)IBOutlet UIButton *theRightArrowInvsrb;
@property (nonatomic,retain)NSArray *dataArray;
@property (nonatomic,assign)Boolean goingRight;
@property  (nonatomic,retain)UIActivityIndicatorView *mloadingView;
@property (nonatomic,retain)UIView *LoadingViewBG;
@end

@implementation TopBanner

@synthesize rect_leftPositionOutOfScreen=_rect_leftPositionOutOfScreen;
@synthesize rect_rightPositionOutOfScreen=_rect_rightPositionOutOfScreen;
@synthesize bannerArray=_bannerArray;
@synthesize int_currentObjcetIndex=_int_currentObjcetIndex;
@synthesize isMoving;
@synthesize nonActionCount;
@synthesize pageController;
@synthesize aTimer;
@synthesize bannerShowing,bannerComing;
@synthesize URLArray;
@synthesize theLeftArrow;
@synthesize theRightArrow;
@synthesize theLeftArrowInvsrb;
@synthesize theRightArrowInvsrb;
@synthesize dataArray;
@synthesize delegate;
@synthesize goingRight;
@synthesize mloadingView;
@synthesize LoadingViewBG;

#define pageControllerSize 16
#define theTrylengthsIWant 7 //banner Array lengths
#define distanceBetweenArrowAndTheEdge 0.02
-(void)setInt_currentObjcetIndex:(int)int_currentObjcetIndex{
    _int_currentObjcetIndex=int_currentObjcetIndex;

}

-(void)ShowOrHideArroWs{
    int lengh= self.bannerArray.count-1;

    if(_int_currentObjcetIndex<1){
        [self weAreAtTheLeftEnd];
    }else if(_int_currentObjcetIndex>=lengh)
    {
        [self weAreAtTheRightEnd];
    }else{
        [self weAreAtTheMiddle];
    }
}

-(void)weAreAtTheLeftEnd{
    [self bringTwoArrowToFront];
 
    self.goingRight=YES;
    self.theLeftArrow.hidden=YES;
    self.theLeftArrowInvsrb.hidden=YES;
    if(self.bannerArray.count > 1){
        self.theRightArrow.hidden=NO;
        self.theRightArrowInvsrb.hidden=NO;
    }

 }
-(void)weAreAtTheRightEnd{
    [self bringTwoArrowToFront];
    
    self.goingRight=NO;
    self.theLeftArrow.hidden=NO;
     self.theLeftArrowInvsrb.hidden =NO;
    self.theRightArrow.hidden=YES;
     self.theRightArrowInvsrb.hidden =YES;


}

-(void)weAreAtTheMiddle{
    [self bringTwoArrowToFront];

    self.theLeftArrow.hidden=NO;
     self.theLeftArrowInvsrb.hidden=NO;
    self.theRightArrow.hidden=NO;
     self.theRightArrowInvsrb.hidden=NO;


}

-(void)bringTwoArrowToFront{
    
    [self bringSubviewToFront:self.theRightArrow];
    [self bringSubviewToFront:self.theLeftArrow];
    [self bringSubviewToFront:self.theRightArrowInvsrb];
    [self bringSubviewToFront:self.theLeftArrowInvsrb];
}
-(NSMutableArray *)bannerArray{
    if (!_bannerArray) {
        _bannerArray=[[NSMutableArray alloc]init];
    }
    return  _bannerArray;
}

- (void)displayImage:(UIImage *)image {
    
         
   
     CGRect imgRect=self.frame;
  //  NSLog(@"%f%f",self.frame.size.height,self.frame.size.width);
    
    //根据图片尺寸拉长或者拉高以适应显示
    if (image) {
        if (image.size.height/image.size.width>self.frame.size.height/self.frame.size.width) {
            imgRect.size.height=self.frame.size.height;
            imgRect.size.width=self.frame.size.height/image.size.height*image.size.width;
            imgRect.origin.x=(self.frame.size.width-imgRect.size.width)/2;
        }else{
            imgRect.size.width=self.frame.size.width;
            imgRect.size.height=self.frame.size.width/image.size.width*image.size.height;
            imgRect.origin.y=(self.frame.size.height-imgRect.size.height)/2;
        }
     
    }
 //   imgRect.size.width=image.size.width;
    UIImageView *imageView=[[UIImageView alloc] initWithFrame:imgRect];
        
    [imageView setImage:image]; //UIImageView
    
  //  [imageView sizeToFit];

    [self.bannerArray  addObject:imageView];
   
    [imageView release];
   
    //load 够之后，再开始开始init
    static int i=0;
     
    if (i<self.dataArray.count-1) {
        i++;
    }else{
        [self initViews];
        i=0;
    }
    
    
}

-(void)loadImage{
      for (ElderlyBannerModel *aBanner in  self.dataArray) {
          if (aBanner.imageUrl.length) {
              
            NSString *link= [ElderlyApiManager imageApi:aBanner.imageUrl width:self.bounds.size.width];
              NSLog(@"urllink>>>>>>%@", link);

            NSData* imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:link]];
            UIImage* image = [[[UIImage alloc] initWithData:imageData] autorelease];
            //20131118 begin add by weeka.guo
            if(image != nil){
                [[ElderlyCacheManager sharedInstance] saveActivityBannerCachePicture:image imagePath:[ElderlyPathUtils getActivityBannerPictureCachePath:aBanner.imageUrl]];
            }
            else{
                image = [[ElderlyCacheManager sharedInstance] readActivityBannerCachePicture:[ElderlyPathUtils getActivityBannerPictureCachePath:aBanner.imageUrl]];
            }
            //20131118 end add by weeka.guo
            
            [imageData release];
            [self performSelectorOnMainThread:@selector(displayImage:) withObject:image  waitUntilDone:NO];
          }
      }
    
   
}

- (id)initWithFrame:(CGRect)frame andArray:(NSArray *)theBannerArray
{

    
    
    self = [super initWithFrame:frame];
    if (self) {
        UIView *ibg=[[UIView alloc]initWithFrame:self.frame];
        self.LoadingViewBG=ibg;
        ibg.backgroundColor=[UIColor blackColor];
        [ibg release];ibg =nil;
        [self addSubview:self.LoadingViewBG];
        
      UIActivityIndicatorView *aLoadingView= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
 //       UIActivityIndicatorView *aLoadingView= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];

        aLoadingView.frame=self.frame;
        self.mloadingView=aLoadingView;
        [aLoadingView release]; aLoadingView=nil;
        [self  addSubview:self.mloadingView];
        [self.mloadingView  startAnimating];
        self.mloadingView.hidden=NO;
        //異步處理
        
        self.dataArray=theBannerArray;
        NSOperationQueue *queue = [NSOperationQueue new];
        NSInvocationOperation *operation = [[NSInvocationOperation alloc]
                                            initWithTarget:self
                                            selector:@selector(loadImage)
                                            object:nil];
        [queue addOperation:operation];
         [operation release];
        [queue release];
         
        /*
         //無異步處理
         for (ElderlyBannerModel *aBanner in  self.dataArray) {
        NSData* imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[ElderlyApiManager imageApi:aBanner.imageUrl width:self.frame.size.width]]];
        UIImage* image = [[UIImage alloc] initWithData:imageData];
        UIImageView *imageView=[[UIImageView alloc]initWithFrame:self.frame];
        [imageView setImage:image]; // UIImageView
        [self.bannerArray  addObject:imageView];
        [image release];
        [imageData release];
         }
        [self initViews];
        */
        
        self.rect_leftPositionOutOfScreen=CGRectMake( -frame.size.width, 0, frame.size.width, frame.size.height);
        self.rect_rightPositionOutOfScreen=CGRectMake(  frame.size.width, 0, frame.size.width, frame.size.height);
        
        //添加向右輕抹報告器
        UISwipeGestureRecognizer *horizontal=[[UISwipeGestureRecognizer alloc]
                                              initWithTarget:self
                                              action:@selector(reportRightSwipe:)];
        horizontal.direction=UISwipeGestureRecognizerDirectionRight;
        [self addGestureRecognizer:horizontal];
        [horizontal release];
        
        //添加向左輕抹報告器
        UISwipeGestureRecognizer *leftSwipe=[[UISwipeGestureRecognizer alloc]
                                             initWithTarget:self
                                             action:@selector(reportLeftSwipe:)];
        leftSwipe.direction=UISwipeGestureRecognizerDirectionLeft;
        [self addGestureRecognizer:leftSwipe];
        [leftSwipe release];
        

        
     }
     return self;
}
//隐形按钮的长和宽
#define ivsbBtnWidth 68
#define ivsbBtnHight 100

-(void)initViews{

    //create the first showing banner
    self.int_currentObjcetIndex=0;
    UIButton* view = [[UIButton alloc]initWithFrame:self.frame];
 //   view.accessibilityViewIsModal=YES;
    self.bannerShowing = view;
    [view release];
//20131025 begin add by weeka.guo
    ElderlyBannerModel* model = [self.dataArray objectAtIndex:_int_currentObjcetIndex];
    [self.bannerShowing setAccessibilityLabel:model.title];
//20131025 end add by weeka.guo
    [self.bannerShowing addSubview:[self.bannerArray objectAtIndex:_int_currentObjcetIndex]];
     [self.bannerShowing  addTarget:self action:@selector(bannerClicked)      forControlEvents:(UIControlEventTouchUpInside)];
    [self addSubview:bannerShowing];
    [self startTimer];
    
    //点点点
    [self creatPageController];
    
    // 左右箭头
    UIImage *imgLeftArrow=[UIImage imageNamed:@"photo_arrow_left.png"];
    UIImage *imgRightArrow=[UIImage imageNamed:@"photo_arrow_right.png"];
    float arrowY=(self.frame.size.height-imgLeftArrow.size.height)/2;
   
    //箭头L
    CGRect rectLeftimg=CGRectMake( self.frame.size.width*distanceBetweenArrowAndTheEdge,arrowY ,imgLeftArrow.size.width,imgLeftArrow.size.height);
    UIImageView *imgViewA=[[UIImageView alloc] initWithFrame:rectLeftimg];
    imgViewA.image=imgLeftArrow;
     self.theLeftArrow=imgViewA;
    [self addSubview:self.theLeftArrow];
    self.theLeftArrow.hidden=YES;
    [imgViewA release];imgViewA=nil;
    //隐形按钮（更大的作用范围）
    CGRect rectLeftArrow=CGRectMake(0, (self.frame.size.height-ivsbBtnHight)/2, ivsbBtnWidth, ivsbBtnHight);
     UIButton *btnA=[[UIButton alloc]initWithFrame:rectLeftArrow];
    [btnA addTarget:self action:@selector(reportRightSwipe:) forControlEvents:UIControlEventTouchUpInside];
   btnA.accessibilityLabel=@"上一页";
    self.theLeftArrowInvsrb=btnA;
    [btnA release];btnA=nil;
    [self addSubview:theLeftArrowInvsrb];
    
    ////箭头R
    float arrowX=(self.frame.size.width*(1-distanceBetweenArrowAndTheEdge)-imgRightArrow.size.width);
    
    CGRect rectRightImg=self.theLeftArrow.frame;
    rectRightImg.origin.x=arrowX;
    UIImageView *imgViewB=[[UIImageView alloc]initWithFrame:rectRightImg];
    imgViewB.image=imgRightArrow;
    self.theRightArrow=imgViewB;
    [self addSubview:self.theRightArrow];
    if ( self.bannerArray.count<2)self.theRightArrow.hidden=YES;
    [imgViewB release];imgViewB=nil;
    
    //隐形按钮（更大的作用范围）
    CGRect rectRightArrow=CGRectMake(self.frame.size.width-ivsbBtnWidth, (self.frame.size.height-ivsbBtnHight)/2, ivsbBtnWidth, ivsbBtnHight);
  //  UIButton *btnB=[[UIButton alloc]initWithFrame:rectReftArrow];
    UIButton *btnB=[UIButton buttonWithType:UIButtonTypeCustom];
    btnB.frame=rectRightArrow;
      btnB.accessibilityLabel=@"下一页";
    [btnB addTarget:self action:@selector(reportLeftSwipe:) forControlEvents:UIControlEventTouchUpInside];
    self.theRightArrowInvsrb=btnB;
  //  [btnA release];btnA=nil;
    [self addSubview:theRightArrowInvsrb];
    [self    ShowOrHideArroWs];

    
    [self.mloadingView stopAnimating];
    self.mloadingView=nil;
    [self.LoadingViewBG removeFromSuperview];
    self.LoadingViewBG=nil;

}

-(void)creatPageController{
  //  NSLog( @" pageController create");
    float theWidth=self.bannerArray.count*pageControllerSize;
    float thehigh=pageControllerSize;
    float theX=(self.frame.size.width-theWidth)/2;
    float theY=self.frame.size.height*0.9;
    
    myPageControl   *aPageController=[[myPageControl alloc]initWithFrame:CGRectMake(theX, theY, theWidth, thehigh)];
    aPageController.backgroundColor=[UIColor clearColor];
    aPageController.numberOfPages=self.bannerArray.count;
    aPageController.currentPage=self.int_currentObjcetIndex;
    aPageController.delegate=self;
    self.pageController=aPageController;
    [self addSubview:self.pageController];
    [aPageController release]; aPageController=nil;
    
    
}

-(void)myPageControlClicked:(int)numberOfIndicater{
    if (numberOfIndicater>self.int_currentObjcetIndex) {
        self.int_currentObjcetIndex=numberOfIndicater-1;
        [self reportLeftSwipe:nil];
    }else{
        self.int_currentObjcetIndex=numberOfIndicater+1;
         [self reportRightSwipe:nil];
    }
}


-(void)stopTimer{
    
    if(self.aTimer)
    {
        [self.aTimer invalidate];
        self.aTimer = nil;
    }
}
-(void)startTimer{
    self.aTimer= [NSTimer scheduledTimerWithTimeInterval:1.0 target:self
                                                selector:@selector(AutoRenewBanner)
                                                userInfo:nil repeats:YES];
    self.nonActionCount=0;
}

-(void)bannerClicked{
    
    if (!self.isMoving) {
        DLog(@"banner clicked 1");
        ElderlyBannerModel *banner=[self.dataArray objectAtIndex:self.int_currentObjcetIndex];
        if (banner.link.length)[self.delegate theBanner:self Hited:banner.link BannerID:[NSString stringWithFormat:@"%d",banner.bId]];
    }
}
-(void)AutoRenewBanner{
     self.nonActionCount++;
    if (self.nonActionCount>4&&(!self.isMoving)) {
        self.nonActionCount=0;
      
        if (self.goingRight) {
         
            [self reportLeftSwipe:nil];
            
        }else {

            [self reportRightSwipe:nil];
        }
     }
    
}

-(void)removeSomething:(UIView *)sender{
    [sender removeFromSuperview];
    sender =nil;
}

-(void)reportLeftSwipe:(UIGestureRecognizer *)recognizer{
	//    NSLog(  @"leftswip detected \n************************** %@\n**********************",self);
    self.nonActionCount=0;
    if([self  WhetherItShoudFadeTo:left]){
        self.isMoving=YES;
        self.userInteractionEnabled=NO;
        self.int_currentObjcetIndex= self.int_currentObjcetIndex+1;
        [self creatbannerComing:right];
        [self fadeOutTheShowingBannerTo:left];
        [self fadeInThebannerComingFrom:right];
        self.pageController.currentPage=self.int_currentObjcetIndex;
     };
 }

-(void)reportRightSwipe:(UIGestureRecognizer *)recognizer{
    //	    NSLog(@"rightSwip detected");
    self.nonActionCount=0;
    if([self  WhetherItShoudFadeTo:right]){
        self.isMoving=YES;
        self.userInteractionEnabled=NO;
        self.int_currentObjcetIndex= self.int_currentObjcetIndex-1;
        [self creatbannerComing:left];
        [self fadeOutTheShowingBannerTo:right];
        [self fadeInThebannerComingFrom:left];
        self.pageController.currentPage=self.int_currentObjcetIndex;
      };
}

-(BOOL)WhetherItShoudFadeTo:(direction)theDirection{
    
    BOOL result=0;
    if ( self.bannerArray.count ) {
         
    
    switch (theDirection) {
        case right:
            result= self.int_currentObjcetIndex>0;
            break;
        case left:
            result= self.int_currentObjcetIndex<self.bannerArray.count-1;
            break;
        default:
            result= NO;
            break;
    }
        }
    return result;
}

-(void)creatbannerComing:(direction)thedirection{
    
    CGRect TheRect;
//    UIControl* view = [[UIControl alloc]initWithFrame:self.frame];
    UIButton* view = [[UIButton alloc]initWithFrame:self.frame];
 //   view.accessibilityViewIsModal=YES;
    
    self.bannerComing = view;
    [view release];
    
    if (thedirection==left) {
        TheRect= self.rect_leftPositionOutOfScreen;
    }else{
        TheRect= self.rect_rightPositionOutOfScreen;
    }
    
    [self.bannerComing addSubview:[self.bannerArray objectAtIndex:_int_currentObjcetIndex]];
//    NSString *string=[(ElderlyBannerModel *)[self.dataArray objectAtIndex:_int_currentObjcetIndex] title];
//    self.bannerComing.accessibilityLabel =[NSString stringWithFormat:@"打开活动%@的网页",string];
    
    [ self.bannerComing  addTarget:self action:@selector(bannerClicked)forControlEvents:(UIControlEventTouchUpInside)];
    [self addSubview:bannerComing];
    [bannerComing setFrame:TheRect];
    [self bringSubviewToFront:self.pageController];
    
}

-(void)fadeOutTheShowingBannerTo:(direction)theDirection{
    self.bannerShowing.frame=self.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.32];
    if (theDirection==left) {
        self.bannerShowing.frame=self.rect_leftPositionOutOfScreen;
    }else{
        self.bannerShowing.frame=self.rect_rightPositionOutOfScreen;
    }
    [UIView setAnimationDelegate:self];
 	[UIView commitAnimations];
}

-(void)fadeInThebannerComingFrom:(direction)TheDirection{
    //    NSLog(@"fade in comingbanner %@",bannerComing);
    [UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.32];
    self.bannerComing.frame=self.frame;
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(removeBannerFadedOut)];
   	[UIView commitAnimations];
}

-(void)removeBannerFadedOut{
   ElderlyBannerModel* model = [self.dataArray objectAtIndex:_int_currentObjcetIndex];

 
    self.bannerShowing.accessibilityLabel=model.title;
    self.bannerComing.accessibilityLabel=model.title;
    
    [self.bannerShowing removeFromSuperview];
    self.bannerShowing = nil;
    UIButton *view= self.bannerComing;
    self.bannerShowing=view;
    view=nil;
    self.bannerComing = nil;
    self.isMoving=NO;
    self.userInteractionEnabled=YES;
    [self ShowOrHideArroWs];
    
    if(self.delegate != nil && [self respondsToSelector:@selector(ReflashAccessLabel:)])
        [self.delegate  ReflashAccessLabel:model.title];
}



-(void)viewDidUnload{

}

-(void)dealloc{
    self.bannerShowing=nil;
    self.bannerComing=nil;
    self.aTimer=nil;
    self.URLArray=nil;
    self.theLeftArrow=nil;
    self.theRightArrow=nil;
    self.theLeftArrowInvsrb=nil;
    self.theRightArrowInvsrb=nil;
    self.pageController=nil;
    self.bannerArray=nil;
    self.bannerShowing=nil;
    self.bannerComing=nil;
 //   NSLog(@"%@",self.aTimer);
    
    [super dealloc];
    
}
@end
