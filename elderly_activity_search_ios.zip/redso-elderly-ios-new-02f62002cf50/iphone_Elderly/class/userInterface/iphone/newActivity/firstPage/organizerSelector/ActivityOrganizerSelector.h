//
//  ActivityOrganizerSelector.h
//  iphone_Elderly
//
//  Created by gtmac 002 on 13-8-27.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h> 

@protocol organizerSeletor
-(void)selectOrganizer:(NSString *)theOrganizer;
 @end

@interface ActivityOrganizerSelector : UIView
@property(nonatomic,assign)id <organizerSeletor>delegate;
@property(nonatomic,retain) UIButton *btnLCSD;
@property(nonatomic,retain) UIButton *btnOrganizer;
@end
