//
//  ElderlyActivityListViewController.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 9/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyScrollableViewController.h"
#import "CalendarHeaderView.h"
#import "CalendarView.h"
#import "ExpandTableView.h"
#import "LoadingView.h"
#import "MonthView.h"

@interface ElderlyActivityListViewController : ElderlyScrollableViewController<CalendarHeaderViewDelegate, CalendarViewDelegate, ExpandTableViewDelegate,MonthViewDelegate>{
    
    UILabel *loadMoreText;
    
}

@property (retain, nonatomic) UILabel *noActivityLabel;
@property (retain, nonatomic) ExpandTableView* expandTableView;
@property (retain, nonatomic) CalendarHeaderView *calendarHeaderView;
@property (retain, nonatomic) CalendarView *calendarView;
@property (retain, nonatomic) NSArray *centerList;
@property (retain, nonatomic) NSDate *currentDate;
@property (retain, nonatomic) LoadingView *loadingView;
@property (assign, nonatomic) BOOL isMonth;
@property (retain, nonatomic) MonthView* monthView;
@property (assign, nonatomic) BOOL isMyActivity;

@end
