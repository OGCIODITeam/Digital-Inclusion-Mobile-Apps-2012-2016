//
//  ElderlyMainPageViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneViewController.h"
@class ElderlyNavigationController;
@class GridView;
@class ElderlyWeatherModel;
@class WeatherIndexView;
@class WeatherTemperatureView;
@class AsyncTask;
@class ElderlyBannerModel;
@class LoadingView;
@interface ElderlyMainPageViewController: ElderlyIphoneViewController{

    ElderlyNavigationController* navigationController;
    UIImageView* bgView;
    GridView* gridView;
    UIButton* portraitButton;
    WeatherIndexView* weatherIndexView;
    WeatherTemperatureView* temperatureView;
    UILabel* titleLabel;
    UILabel* weatherLabel;
    UILabel* dateLabel;
    UILabel* developmentsIntroLabel;
    UILabel* developmentsButtonTitle;
    UILabel* developmentsTitleLabel;
    UIButton* developmentsBgView;
    ElderlyWeatherModel* weatherModel;
    
    UIImageView* topBarBgView;
    
    float spaceing;
    
    AsyncTask* asyncTask;
    
    NSArray* weatherArray;
    ElderlyBannerModel* mainPageBanner;
    
    LoadingView* weatherViewLoadingView;
    LoadingView* bannerLoadingView;
    
}

-(void)back;

@end
