//
//  ElderlyMainPageViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyMainPageViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "WeatherIndexView.h"
#import "WeatherTemperatureView.h"
#import "GridView.h"
#import "AppDelegate.h"
#import "ElderlyUserModel.h"

#import "ElderlyIphoneMyProfileViewController.h"
#import "WeatherWarningViewController.h"
#import "AdSearchViewController.h"
#import "SettingViewController.h"
#import "EasySearchViewController.h"
#import "LocatorSearchViewController.h"
#import "MyActivityViewController.h"
#import "NewActivityViewController.h"
#import "FavoCenterViewController.h"
#import "ElderlyIphoneMyProfileSelectPictureViewController.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyUtils.h"
#import "ElderlyWeatherModel.h"
#import "ElderlyIphoneWebBrowserViewController.h"
#import "ElderlyBannerModel.h"
#import "MyActivityTabViewController.h"
#import "GTGZImageDownloadedView.h"
#import "AsyncTask.h"
#import "ElderlyHTTPRequestManager.h"
#import "ElderlyAlertUtils.h"
#import "ApiError.h"
#import "LoadingView.h"
#import "ElderlyGA.h"
#import "ElderlyCacheManager.h"


@interface ElderlyMainPageViewController ()<GridViewDelegate>

-(void)initTopBar;
-(void)initWeatherIndexView;
-(void)initWeatherTemperatureView;
-(void)initGridView;
-(void)navigationRightClick;
-(void)pushViewController:(UIViewController*)viewController;
-(NSString*)getWeatherBgImageView:(NSInteger)code;

-(void)initWeatherViewData;

-(void)loadWeatherData;
-(void)loadMainPageBanner;

@end

@implementation ElderlyMainPageViewController

- (id)init{
    self = [super init];
    if (self) {
        // Custom initialization
//        self.title = lang(@"mainPage_Title");
//        
//        self.navigationItem.rightBarButtonItem = [[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" target:self action:@selector(navigationRightClick)];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

    self.view.alpha = 0;
    
    weatherModel = nil;
    spaceing = 0;
    if([ElderlyUtils isRetain4]){
        spaceing = 29;
    }
    
    bgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:bgView];
    [bgView release];
    
    [self initTopBar];
    [self initWeatherIndexView];
    [self initWeatherTemperatureView];
    [self initButtonView];
    [self initDevelopmentsView];
    [self initGridView];
    
     [self loadWeatherData];
    

    [UIView animateWithDuration:0.7f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.view.alpha = 1.0f;
    } completion:^(BOOL finish){
        
    }];
    
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_MAINPAGE];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{

    [mainPageBanner release];
    [weatherModel release];
    [weatherArray release];

    [navigationController.view removeFromSuperview];
    [navigationController release];
    navigationController=nil;
    [super dealloc];
}

-(void)themeChanged{

    [titleLabel theme:@"mainPage_title"];
    titleLabel.text = lang(@"mainPage_Title");
    
    [weatherIndexView weatherName:[ElderlyUtils text:weatherModel key:@"name"]];
    
    [gridView changeViewColor: [[ElderlyThemeManager sharedInstance] getAllColorImageName]];
    
    [temperatureView setMaxTemperature:weatherModel.maxTemperature];
    [temperatureView setMinTemperature:weatherModel.minTemperature];
    [temperatureView setHumidity:weatherModel.humidity];
    [temperatureView setTemperature:weatherModel.temperature];
    
    weatherLabel.text = lang(@"weather_title");
    [weatherLabel theme:@"weather_button_title"];
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    NSLocale *locale=[[NSLocale alloc] initWithLocaleIdentifier:[ElderlyUtils language]];
    [dateFormatter setLocale:locale];
    [dateFormatter setDateFormat:@"EEEE dd/MM"];
    [locale release];
    dateLabel.text = [dateFormatter stringFromDate:[NSDate date]];
    [dateFormatter release];
    
    developmentsIntroLabel.text=[ElderlyUtils text:mainPageBanner key:@"bannerDescription"];
    [developmentsIntroLabel theme:@"developmentsIntroLabel"];
    
    developmentsButtonTitle.text=lang(@"detail");
    [developmentsButtonTitle theme:@"developmentsButton_Title"];
    
    developmentsTitleLabel.text = [ElderlyUtils text:mainPageBanner key:@"title"];
    [developmentsTitleLabel theme:@"developments_TitleLabel"];

}

#pragma mark method

-(void)initTopBar{

    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_top.png"];
    topBarBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width,img.size.height )];
    topBarBgView.userInteractionEnabled = YES;
    topBarBgView.image = img;
    
    titleLabel = [[UILabel alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 200)*0.5f, 5, 200, img.size.height-10)];
    
    [titleLabel theme:@"mainPage_title"];
    titleLabel.text = lang(@"mainPage_Title");
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [topBarBgView addSubview:titleLabel];
    [titleLabel release];
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_setting.png"];
    
    UIButton* settingButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [settingButton setImage:img forState:UIControlStateNormal];
    [settingButton setAccessibilityLabel:lang(@"setting")];
    settingButton.frame = CGRectMake(self.view.bounds.size.width-img.size.width, 0, img.size.width, img.size.height);
    [settingButton addTarget:self action:@selector(navigationRightClick) forControlEvents:UIControlEventTouchUpInside];
    [topBarBgView addSubview:settingButton];
    
    [self.view addSubview:topBarBgView];
    [topBarBgView release];

}

-(void)initWeatherIndexView{
    
    weatherIndexView = [[WeatherIndexView alloc] initWithFrame:CGRectMake(0, 44, self.view.bounds.size.width, 45)];
    NSLog(@"%@",[NSString stringWithFormat:@"weather_icons_%d.png",weatherModel.code]);

    [self.view addSubview:weatherIndexView];
    [weatherIndexView release];
    

}

-(void)initWeatherTemperatureView{

    temperatureView = [[WeatherTemperatureView alloc] initWithFrame:CGRectMake(0, 95+spaceing, 195, 85)];
    [self.view addSubview:temperatureView];
    [temperatureView release];

}

-(void)initButtonView{

    UIImage* image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"photo_none_bg.png"];
    if([ElderlyUtils isRetain4]){
        image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"photo_none_bg_iP5.png"];
    }
    UIImageView* portraitView = [[UIImageView alloc] initWithFrame:CGRectMake([ElderlyUtils isRetain4]?200:235, ([ElderlyUtils isRetain4]?80:100)+spaceing, image.size.width,image.size.height)];
    portraitView.userInteractionEnabled = YES;
    portraitView.image = image;
    [self.view addSubview:portraitView];
    portraitButton = [[UIButton alloc] init];
    image = [[self getAppDelegate].profileSettingManager readPortrait:[self getAppDelegate].profileSettingManager.userModel.portraitPath];
    [portraitButton setImage:[[self getAppDelegate].profileSettingManager readPortrait:[self getAppDelegate].profileSettingManager.userModel.portraitPath] forState:UIControlStateNormal];
    
    [portraitButton addTarget:self action:@selector(seletorPortraitView) forControlEvents:UIControlEventTouchUpInside];
    portraitButton.frame = CGRectMake([ElderlyUtils isRetain4]?4.5:3,[ElderlyUtils isRetain4]?4.5:3, image.size.width, image.size.width);
    [portraitView addSubview:portraitButton];
    [portraitButton setAccessibilityLabel:lang(@"picture")];
    [portraitButton release];
    [portraitView release];
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_check_weather.png"];
    UIButton* weatherView = [UIButton buttonWithType:UIButtonTypeCustom];
    [weatherView setImage:img forState:UIControlStateNormal];
    [weatherView setAccessibilityLabel:lang(@"weather_title")];
    weatherView.frame = CGRectMake(CGRectGetMaxX(portraitView.frame)-img.size.width, CGRectGetMaxY(portraitView.frame)+4+spaceing, img.size.width, img.size.height);
    [weatherView addTarget:self action:@selector(selectorWeatherView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:weatherView];
    
    weatherLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(portraitView.frame)-img.size.width+5, CGRectGetMaxY(portraitView.frame)+5+spaceing, 113, img.size.height)];
    weatherLabel.text = lang(@"weather_title");
    [weatherLabel theme:@"weather_button_title"];
    weatherLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:weatherLabel];
    [weatherLabel release];
    
    
    dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(portraitView.frame)+5+spaceing, 150, 24)];
    dateLabel.shadowColor = [UIColor blackColor];
    dateLabel.shadowOffset = CGSizeMake(1, 1);
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    NSLocale *locale=[[NSLocale alloc] initWithLocaleIdentifier:[ElderlyUtils language]];
    [dateFormatter setLocale:locale];
    [dateFormatter setDateFormat:@"EEEE dd/MM"];
    [locale release];
    dateLabel.text = [dateFormatter stringFromDate:[NSDate date]];
    [dateFormatter release];
    
    [dateLabel theme:@"date_Label"];
    if([ElderlyUtils isRetain4]){
        [dateLabel theme:@"date_Label_big"];
    }
   
    [self.view addSubview:dateLabel];
    [dateLabel release];
    
}


-(void)initDevelopmentsView{

    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_detail.png"];
    UIView* developmentsView = [[UIView alloc] initWithFrame:CGRectMake(0, 202+spaceing*3, img.size.width, img.size.height)];

    developmentsBgView = [[UIButton alloc] initWithFrame:developmentsView.bounds];
    [developmentsBgView setBackgroundImage:img forState:UIControlStateNormal];
    [developmentsBgView addTarget:self action:@selector(selectorDevelopmentsButton) forControlEvents:UIControlEventTouchUpInside];
    [developmentsView addSubview:developmentsBgView];
    [developmentsBgView release];
    [developmentsBgView setAccessibilityLabel:@""];
    developmentsTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 200, 25)];
    [developmentsTitleLabel theme:@"developments_TitleLabel"];
    [developmentsView addSubview:developmentsTitleLabel];
        
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_detail.png"];
    UIButton* developmentsButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [developmentsButton setImage:img forState:UIControlStateNormal];
    developmentsButton.frame = CGRectMake(developmentsView.frame.size.width - img.size.width - 12, 5, img.size.width, img.size.height);
    [developmentsButton addTarget:self action:@selector(selectorDevelopmentsButton) forControlEvents:UIControlEventTouchUpInside];
    [developmentsView addSubview:developmentsButton];
    [developmentsButton setAccessibilityLabel:lang(@"detail")];
    
    developmentsButtonTitle = [[UILabel alloc] initWithFrame:CGRectMake(developmentsView.frame.size.width - img.size.width - 12, 5, 45, img.size.height)];
    developmentsButtonTitle.text=lang(@"detail");
    developmentsButtonTitle.textAlignment = NSTextAlignmentCenter;
    [developmentsButtonTitle theme:@"developmentsButton_Title"];
    [developmentsView addSubview:developmentsButtonTitle];
    [developmentsButtonTitle release];
    
    developmentsIntroLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(developmentsTitleLabel.frame)+10, 290, 18)];
    [developmentsIntroLabel theme:@"developmentsIntroLabel"];
    [developmentsView addSubview:developmentsIntroLabel];
    [developmentsIntroLabel release];
    [developmentsTitleLabel release];
    
    [self.view addSubview: developmentsView];
    [developmentsView release];
    
    bannerLoadingView = [[LoadingView alloc] initWithFrame:developmentsView.frame];
    [self.view addSubview:bannerLoadingView];
    [bannerLoadingView release];
    [bannerLoadingView startLoading];

}

-(void)initGridView{

    UIView* view = [[self.view subviews] objectAtIndex:[self.view subviews].count -1];
    gridView = [[GridView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(view.frame), self.view.bounds.size.width, 214)];
    
    gridView.delegate = self;
    
    NSArray* list= [[ElderlyThemeManager sharedInstance] getAllColorImageName];
    
    [gridView setViewContent:list title:[NSArray arrayWithObjects:lang(@"newActivity"), lang(@"favo_center"), lang(@"myActivity"), lang(@"locator"), lang(@"easy_search"), lang(@"ad_search"), nil]];
    [gridView setViewContentFinish];
    [self.view addSubview:gridView];
    [gridView release];

}

-(void)back{
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^{
        CGRect rect=navigationController.view.frame;
        rect.origin.x=rect.size.width;
        navigationController.view.frame=rect;
        topBarBgView.hidden = NO;
    } completion:^(BOOL finish){
        [navigationController.view removeFromSuperview];
        [navigationController release];
        navigationController=nil;

        [portraitButton setImage:[[self getAppDelegate].profileSettingManager readPortrait:[self getAppDelegate].profileSettingManager.userModel.portraitPath] forState:UIControlStateNormal];
        bgView.image =[[ElderlyThemeManager sharedInstance] imageByTheme:[self getWeatherBgImageView:weatherModel.code]];
 
    }];

}

-(NSString*)getWeatherBgImageView:(NSInteger)code{

    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
                                    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:[NSDate date]];
    
    NSInteger hour = [components hour];
    
    NSString* imageStr = @"bg_daytime_%@.png";
    if((hour <= 24 && hour >17) || (hour >= 0 && hour < 6)){
        imageStr = @"bg_night_%@.png";
    }
    imageStr = [NSString stringWithFormat:imageStr,@"sun"];
    if(code > 61 && code < 66){
         imageStr = [NSString stringWithFormat:@"bg_daytime_%@.png",@"rain"];
    }


    return imageStr;

}

-(void)pushViewController:(UIViewController*)viewController{

    self.view.userInteractionEnabled=NO;
    [navigationController.view removeFromSuperview];
    [navigationController release];
    [viewController.view setAccessibilityViewIsModal:YES];
    navigationController = [[ElderlyNavigationController alloc] initWithRootViewController:viewController];
    [self.view addSubview:navigationController.view];
    
    CGRect rect=navigationController.view.frame;
    rect.origin.x=rect.size.width;
    navigationController.view.frame=rect;
    
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^{
        CGRect rect=navigationController.view.frame;
        rect.origin.x=0;
        navigationController.view.frame=rect;
        
    } completion:^(BOOL finish){
        self.view.userInteractionEnabled=YES;
    }];

}


-(void)navigationRightClick{
    NSLog(@"ElderlyMainPageViewController did selector navigationRight Button");

    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_SETTINGBUTTON];
    SettingViewController* settingViewController = [[SettingViewController alloc] init];
    settingViewController.back = YES;

    [self pushViewController:settingViewController];
    [settingViewController release];

}


-(void)seletorPortraitView{

    NSLog(@"seletorPortraitView");
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_PHOTOBUTTON];
    
    if([self getAppDelegate].profileSettingManager.userModel.portraitPath == nil || [self getAppDelegate].profileSettingManager.userModel.portraitPath.length < 1){
        ElderlyIphoneMyProfileSelectPictureViewController* selectPicture = [[ElderlyIphoneMyProfileSelectPictureViewController alloc] init];
        [self pushViewController:selectPicture];
        [selectPicture release];
    }
    else{
        ElderlyIphoneMyProfileViewController* myProfile = [[ElderlyIphoneMyProfileViewController alloc] init];
        [self pushViewController:myProfile];
        [myProfile release];
    }
    [ElderlyThemeManager sharedInstance].gridIndex = 6;

}

-(void)selectorWeatherView{

    NSLog(@"selectorWeatherView");
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_WEATHERFORECASTBUTTON];
    
    WeatherWarningViewController* weatherWarningViewController = [[WeatherWarningViewController alloc] init];
    weatherWarningViewController.weatherArray = weatherArray;
    [self pushViewController:weatherWarningViewController];
    topBarBgView.hidden = YES;
//    [navigationController setNavigationBarHidden:YES];
    [weatherWarningViewController release];
}

-(void)selectorDevelopmentsButton{
    NSLog(@"selectorDevelopmentsButton");
    
    
     [[ElderlyGA sharedInstance] trackEvent:GA_CODE_BANNER];
    
    
    if(mainPageBanner.link == nil || mainPageBanner.link.length < 1)
        return;
    
    ElderlyIphoneWebBrowserViewController* webBrowserViewController = [[ElderlyIphoneWebBrowserViewController alloc] init];
    webBrowserViewController.isHome = 1;
    topBarBgView.hidden = YES;
    [self pushViewController:webBrowserViewController];
    [webBrowserViewController loadRequestAfterDelay:mainPageBanner.link];
    [webBrowserViewController release];
    
    
}

-(void)initWeatherViewData{

    
    bgView.image =[[ElderlyThemeManager sharedInstance] imageByTheme:[self getWeatherBgImageView:weatherModel.code]];
    
    [weatherIndexView weatherIcon:[[ElderlyThemeManager sharedInstance] imageByTheme:[NSString stringWithFormat:@"weather_icons_%d.png",weatherModel.code]]];
    [weatherIndexView weatherName:[ElderlyUtils text:weatherModel key:@"name"]];
    [weatherIndexView weatherWraing:weatherModel.warning];
    
    [temperatureView setMaxTemperature:weatherModel.maxTemperature];
    [temperatureView setMinTemperature:weatherModel.minTemperature];
    [temperatureView setHumidity:weatherModel.humidity];
    [temperatureView setTemperature:weatherModel.temperature];

    
}

-(void)loadWeatherData{
    
    [asyncTask cancel];

    weatherViewLoadingView = [[LoadingView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 202+spaceing*3)];
    [self.view addSubview: weatherViewLoadingView];
    [weatherViewLoadingView release];
    [weatherViewLoadingView startLoading];
    
    asyncTask = [[self getAppDelegate].httpRequestManager getWeatherList];
    
    [asyncTask setFinishBlock:^{
        
        NSArray* array =[asyncTask result];
        if(array != nil && array.count > 0){
            [[ElderlyCacheManager sharedInstance] saveWeaterCacheData:[asyncTask responseData]];
        }
        else{
            array = [[ElderlyCacheManager sharedInstance] readWeaterCacheData];
        }
        ApiError* error = [asyncTask error];
        asyncTask=nil;
        [weatherViewLoadingView stopLoading];
        [weatherViewLoadingView removeFromSuperview];
        weatherViewLoadingView = nil;
        
        if(array != nil ){
            [weatherArray release];
            weatherArray = [array retain];
            if(weatherArray != nil && weatherArray.count > 0){
                weatherModel = [weatherArray objectAtIndex:0];
            }
            [self initWeatherViewData];
            [self loadMainPageBanner];
        }
        else{
            UIAlertView* alertView =[ElderlyAlertUtils showAlert:[error errorMessage] cancelButton:lang(@"retry") delegate:self];
            alertView.tag = 1002;
        }
        
    }];
}

-(void)loadMainPageBanner{
    [asyncTask cancel];
    asyncTask = [[self getAppDelegate].httpRequestManager getBannerlist:@"M"];
    [asyncTask setFinishBlock:^{
        
        NSArray* array =[asyncTask result];
        if(array != nil && array.count > 0){
            [[ElderlyCacheManager sharedInstance] saveMainBannerCacheData:[asyncTask responseData]];
        }
        else{
            array = [[ElderlyCacheManager sharedInstance] readMainBannerCacheData];
        }
        ApiError* error = [asyncTask error];
        
        asyncTask=nil;
        
        [bannerLoadingView stopLoading];
        [bannerLoadingView removeFromSuperview];
        bannerLoadingView = nil;
        
        if(array != nil){
            if([array count] > 0){
                [mainPageBanner release];
                mainPageBanner = [[array objectAtIndex:0] retain];
                developmentsTitleLabel.text = [ElderlyUtils text:mainPageBanner key:@"title"];
                developmentsIntroLabel.text=[ElderlyUtils text:mainPageBanner key:@"bannerDescription"];
                [developmentsBgView setAccessibilityLabel:developmentsTitleLabel.text];
            }
            
        }
        else if([error errorMessage].length > 0){
            UIAlertView* alertView =[ElderlyAlertUtils showAlert:[error errorMessage] cancelButton:lang(@"retry") delegate:self];
            alertView.tag = 1003;
        }
        
        
    }];
}


#pragma mark GridView Delegate
-(void)selectorGridView:(NSInteger)selectorIndex{
    
    if((![ElderlyUtils checkNetWork]) && selectorIndex != 2){
        
        NSArray* array = [NSArray arrayWithObjects:lang(@"newActivity"),lang(@"favo_center"),@"",lang(@"locator"),lang(@"easy_search"),lang(@"ad_search"), nil];
        NSString* msg = [array objectAtIndex:selectorIndex];
        if(msg != nil && msg.length > 0){
            [ElderlyAlertUtils showAlert:[NSString stringWithFormat:lang(@"offlineMsg"),msg] delegate:nil];
        }
        
        return ;
    }
    
    

    ElderlyIphoneViewController* viewController = nil;
    NSLog(@"selectorGridViewIndex:%d",selectorIndex);
    [ElderlyThemeManager sharedInstance].gridIndex = selectorIndex;
    switch (selectorIndex) {
        case 0:{
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_LATESTACTIVITYBUTTON];
            viewController = [[NewActivityViewController alloc] init];
            break;
        }
        case 1:{
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_FAVOURITECENTERBUTTON];
            viewController = [[FavoCenterViewController alloc] init];
            break;
        }
        case 2:{
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_MYACTIVITYBUTTON];
//            viewController = [[MyActivityViewController alloc] init];
            viewController = [[MyActivityTabViewController alloc] init];
            break;
        }
        case 3:{
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_SEARCHNEARBYBUTTON];
            viewController = [[LocatorSearchViewController alloc] init];
            break;
        }
        case 4:{
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_EASYSEARCHBUTTON];
            viewController = [[EasySearchViewController alloc] init];
            break;
        }
        case 5:{
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_ADVANCEDSEARCHBUTTON];
            viewController = [[AdSearchViewController alloc] init];
            break;
        }
        default:
            break;
    }
    
    if(viewController != nil){
        [self pushViewController:viewController];
        [viewController release];
    
    }

}

#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag == 1002){
        [self loadWeatherData];
    }
    else {
        [self loadMainPageBanner];
    }
}

@end
