//
//  ElderlyRootViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-7.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyRootViewController.h"
#import "ElderlyMainPageViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "SettingViewController.h"


@interface ElderlyRootViewController ()

@end

@implementation ElderlyRootViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    mainPageViewController = [[ElderlyMainPageViewController alloc] init];
    [self.view addSubview:mainPageViewController.view];
   
    
}


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    [mainPageViewController.view removeFromSuperview];
    [mainPageViewController release];
    [super dealloc];
}

-(void)back{

    if(mainPageViewController!=nil){
        [mainPageViewController back];
    }
   
}

-(void)goSettingViewController:(UINavigationController*)nav {
    SettingViewController* settingViewController = [[SettingViewController alloc] init];
    [nav pushViewController:settingViewController animated:YES];
    [settingViewController release];

}


@end
