//
//  ElderlyIphoneWebBrowserViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"

@class LoadingView;
@interface ElderlyIphoneWebBrowserViewController : ElderlyContentViewController{

    UIWebView* webView;
    LoadingView* loadingView;
    UIImageView* scrollImageView;
}

@property(nonatomic,assign) BOOL zoomScale;
@property(nonatomic,assign) NSInteger isHome;
// 
/*!
 @property request:         url request
 @start the url request loading
 */
- (void)loadRequest:(NSString *)request;
- (void)loadRequestAfterDelay:(NSString *)request;
- (void)loadHTMLStringAfterDelay:(NSString *)request;

@end
