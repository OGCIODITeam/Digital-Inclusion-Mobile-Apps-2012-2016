//
//  ElderlyIphoneWebBrowserViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-10.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneWebBrowserViewController.h"
#import "ElderlyNavigationController.h"
#import "LoadingView.h"
#import "ElderlyAlertUtils.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import <MessageUI/MFMailComposeViewController.h>

@interface ElderlyIphoneWebBrowserViewController ()<UIWebViewDelegate,MFMailComposeViewControllerDelegate,UIScrollViewDelegate>

-(void)sendEmail:(NSString*)emailAddrss;
-(void)sendInAppEmail:(NSString*)aAddress;

@end

@implementation ElderlyIphoneWebBrowserViewController

@synthesize zoomScale;
@synthesize isHome;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.zoomScale=YES;
        self.isHome = 0;
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    if(webView!=nil)return;
    webView=[[UIWebView alloc] initWithFrame:self.view.bounds];
    webView.scalesPageToFit=self.zoomScale;
    webView.delegate=self;
    if(self.isHome == 2)
        webView.scrollView.delegate = self;
    webView.backgroundColor=[UIColor whiteColor];
    webView.autoresizesSubviews=YES;
    [self.view addSubview:webView];
    [webView release];
    
    
    loadingView=[[LoadingView alloc] init];
    loadingView.center=CGPointMake(self.view.center.x, self.view.center.y-44.0f);
    [loadingView loadingViewStyle:UIActivityIndicatorViewStyleGray];
    [self.view addSubview:loadingView];
    [loadingView release];
    
    if(self.isHome == 2){
        UIImage* image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
        scrollImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height - image.size.height, image.size.width, image.size.height)];
        scrollImageView.image = image;
        [self.view addSubview:scrollImageView];
        [scrollImageView release];
    }
    
}

-(void)viewDidUnload{

    webView=nil;
    [loadingView stopLoading];
    loadingView=nil;
    
    [super viewDidUnload];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    
    NSString* headerImage = [[ElderlyThemeManager sharedInstance] getColorImageName];
    NSString* title = lang(@"mainPage_Title");
    if(self.isHome == 1){
        headerImage = @"bg_top.png";
    }
    else if(self.isHome == 2){
        headerImage = @"bg_top_vermilion.png";
        title=lang(@"about");
    }
    [nav barBackground:headerImage];
    [nav titleView:title];
}


-(void)dealloc{
    [loadingView stopLoading];
    [super dealloc];
}

#pragma mark method;
-(void)navigationLeftClick{
    
    if(self.isHome == 1){
        [[self getAppDelegate].rootController back];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }

}


- (void)loadRequest:(NSString *)request{
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:request]]];
}


- (void)loadRequestAfterDelay:(NSString *)request {
    [self performSelector:@selector(loadRequest:) withObject:request afterDelay:0.3];
}


-(void)loadHTMLString:(NSString *)html{

    [webView loadHTMLString:html baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
}

- (void)loadHTMLStringAfterDelay:(NSString *)request{
    [self performSelector:@selector(loadHTMLString:) withObject:request afterDelay:0.3];
}


#pragma mark  webview delegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    DLog(@"%@",request.URL.absoluteString);
    
    if(self.isHome == 2){
        NSString* link = [[request URL] absoluteString];
        const char* _link=[link UTF8String];
        if (strstr(_link,"mailto:")!=NULL ){
            [self sendEmail:[link stringByReplacingOccurrencesOfString:@"mailto:" withString:@""]];
            return NO;
        }
    }
    
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [loadingView startLoading];
}

- (void)webViewDidFinishLoad:(UIWebView *)_webView{
    [loadingView stopLoading];
    for(UIView* view in webView.subviews){
        if([[view class] isSubclassOfClass:[UIScrollView class]]){
            UIScrollView* scrollView=(UIScrollView*)view;
            scrollView.scrollEnabled=YES;
        }
    }
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [loadingView stopLoading];
    
    if(error.code!=-999 && error.code!=1200 && error.code!=-1200 && error.code!=101)
        [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
}


-(void)sendEmail:(NSString*)emailAddrss{

    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
    if(mailClass != nil && [mailClass canSendMail]){
        [self sendInAppEmail:emailAddrss];
    }
    
}

-(void)sendInAppEmail:(NSString*)aAddress {
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    [controller setToRecipients: [NSArray arrayWithObject: aAddress]];
    if (controller){
        [self presentModalViewController:controller animated:YES];
    }
    [controller release];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    
    if(result == MFMailComposeResultSent){
        [ElderlyAlertUtils  showAlert:lang(@"Mail sent") delegate:nil];
    }
  
    [self dismissModalViewControllerAnimated:YES];
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if(scrollView.contentOffset.y <= 0){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
        
    }
    else if(scrollView.contentOffset.y>=scrollView.contentSize.height-scrollView.frame.size.height){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll_up.png"];
    }
}


@end
