//
//  ElderlyScrollableViewController.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 8/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"

@interface ElderlyScrollableViewController : ElderlyContentViewController
@property (retain, nonatomic) UIImageView *scrollImageView;
@end
