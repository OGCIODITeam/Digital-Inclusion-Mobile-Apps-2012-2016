//
//  EasySearchViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "EasySearchViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "EasyOneTypeView.h"
#import "ButtonText.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyCategoryModel.h"
#import "ElderlySearchKeyModel.h"
#import "LocatorSearchResultViewController.h"
#import "ElderlyAreaModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyUserModel.h"
#import "ElderlyGA.h"
#import "ElderlyAlertUtils.h"

@interface EasySearchViewController ()<EasyOneTypeViewDelegate>


-(NSString*)converDate:(NSInteger)index;

@end

@implementation EasySearchViewController

- (id)init{
    self = [super init];
    if (self) {
        // Custom initialization

        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_EASYSEARCH];

    areaSelectIndex = [[self getAppDelegate].databaseManager getEasySearchAreaDefaultIndex:[self getAppDelegate].profileSettingManager.userModel.area];
    
    typeView=[[EasyOneTypeView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 0.0f)];
    [typeView theme:@"activity_type_bg"];
    [typeView title:lang(@"activity_type")];
    [typeView panel:[NSArray arrayWithObjects:@"area_blue.png", nil]];
    [typeView titleTheme:@"activity_type_title"];
    [typeView selectedImage:@"area_selected01.png"];
    typeView.list = [[self getAppDelegate].databaseManager getCategoryNameArray];
    
    if([[self getAppDelegate].databaseManager getMyInterest].count > 0){
        ElderlyCategoryModel* model = [[[self getAppDelegate].databaseManager getMyInterest] objectAtIndex:0];
        [typeView setDefault:[model.key integerValue]];
    }
    [self.view addSubview:typeView];
    [typeView release];

    
    
    
    areaView1=[[EasyOneTypeView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(typeView.frame)+3.0f, self.view.frame.size.width, 0.0f)];
    [areaView1 title:lang(@"area")];
    [areaView1 titleTheme:@"activity_area_title"];
    [areaView1 theme:@"activity_area_bg"];
    [areaView1 panel:[NSArray arrayWithObjects:@"area_purple.png",@"area_red.png",@"area_green.png", nil]];
    [areaView1 selectedImage:@"area_selected02.png"];
    areaView1.delegate = self;
    areaView1.list = [[self getAppDelegate].databaseManager getAreaNameArray];
    
    [areaView1 setDefault:areaSelectIndex];

    [self.view addSubview:areaView1];
    [areaView1 release];

    
    
    areaView2=[[EasyOneTypeView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(areaView1.frame), self.view.frame.size.width, 0.0f)];
    [areaView2 hideTitleAndAdjustPannel];
    [areaView2 theme:@"activity_area_bg"]; 
    [areaView2 panel:[NSArray arrayWithObjects:[self getAreaView2PanelImageName], nil]];
    [areaView2 selectedImage:@"area_selected02.png"];
    areaView2.list=[[self getAppDelegate].databaseManager getRegionName:[self getAppDelegate].profileSettingManager.userModel.area];
    [areaView2 setDefault:[[self getAppDelegate].databaseManager getEasySearchAreaDefaultIndex:[self getAppDelegate].profileSettingManager.userModel.region]];
 
    [self.view addSubview:areaView2];
    [areaView2 release];

    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:[NSDate date]];

    monthView=[[EasyOneTypeView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(areaView2.frame)+3.0f, self.view.frame.size.width, 0.0f)];
    [monthView theme:@"activity_month_bg"];
    [monthView title:lang(@"month")];
    [monthView panel:[NSArray arrayWithObjects:@"area_light_green.png", nil]];
    [monthView titleTheme:@"activity_month_title"];
    [monthView selectedImage:@"area_selected03.png"];
    monthView.list=[NSArray arrayWithObjects:lang(@"Jan"),lang(@"Feb"),lang(@"Mar"),lang(@"Apr"),lang(@"May"),lang(@"Jun"),lang(@"July"),lang(@"Aug"),lang(@"Sep"),lang(@"Oct"),lang(@"Nov"),lang(@"Dec"), nil];
    
    [monthView setDefault:[components month]-1];
    
    [self.view addSubview:monthView];
    [monthView release];
    

    
    UIImage* img=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_%@.png"];
    searchButton = [[ButtonText alloc] initWithFrame:CGRectMake((self.view.frame.size.width-img.size.width)*0.5f, CGRectGetMaxY(monthView.frame) + (self.view.bounds.size.height - CGRectGetMaxY(monthView.frame) - img.size.height)*0.5f, img.size.width, img.size.height)];
    searchButton.spacing = 5.0f;
    [searchButton text:lang(@"search")];
    [searchButton setBackgroundImage:img forState:UIControlStateNormal];
    [searchButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_search_white.png"]];
    [searchButton theme:@"activity_search_title"];
    [searchButton addTarget:self action:@selector(clickSearchButton) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:searchButton];
    [searchButton release];
    
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"easy_search")];
    
    [typeView theme:@"activity_type_bg"];
    [typeView title:lang(@"activity_type")];
    [typeView titleTheme:@"activity_type_title"];
    typeView.list = [[self getAppDelegate].databaseManager getCategoryNameArray];

    
    [areaView1 title:lang(@"area")];
    [areaView1 titleTheme:@"activity_area_title"];
    [areaView1 theme:@"activity_area_bg"];
    areaView1.list = [[self getAppDelegate].databaseManager getAreaNameArray];

    
    [areaView2 theme:@"activity_area_bg"];

    [areaView2 selectedImage:@"area_selected02.png"];
    areaView2.list=[[self getAppDelegate].databaseManager getRegionName:[self getAppDelegate].profileSettingManager.userModel.area];

    
    [monthView theme:@"activity_month_bg"];
    [monthView title:lang(@"month")];
    [monthView titleTheme:@"activity_month_title"];
    monthView.list=[NSArray arrayWithObjects:lang(@"Jan"),lang(@"Feb"),lang(@"Mar"),lang(@"Apr"),lang(@"May"),lang(@"Jun"),lang(@"July"),lang(@"Aug"),lang(@"Sep"),lang(@"Oct"),lang(@"Nov"),lang(@"Dec"), nil];

    
    [searchButton text:lang(@"search")];
    [searchButton theme:@"activity_search_title"];
    [searchButton setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_%@.png"] forState:UIControlStateNormal];

    


}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"easy_search")];
    
}

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    [[self getAppDelegate].rootController back];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)clickSearchButton{
    
    
    if(![ElderlyUtils checkNetWork]){
        [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
        return;
    }
    
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_SEARCHBUTTON];
    
    ElderlySearchKeyModel* searchKeyModel = [[ElderlySearchKeyModel alloc] init];
    if([[self getAppDelegate].databaseManager getCategoryArray].count > typeView.selectedIndex){
        ElderlyCategoryModel* categroyModel =  [[[self getAppDelegate].databaseManager getCategoryArray] objectAtIndex:typeView.selectedIndex];
        searchKeyModel.eventType = categroyModel.name_tc;
    }

    

//searchKeyModel.eventType = [[self getAppDelegate].databaseManager getAreaTCContent:];

    ElderlyAreaModel* model = [[self getAppDelegate].databaseManager getAreaModelForName:[areaView2.list objectAtIndex:areaView2.selectedIndex]];
    searchKeyModel.activeArea = model.value;

    searchKeyModel.month = [self converDate:monthView.selectedIndex+1];
    
    searchKeyModel.searchtype = easySrach;
    LocatorSearchResultViewController* controller=[[LocatorSearchResultViewController alloc] init];
    controller.searchKeyModel = searchKeyModel;
    controller.navTitle = @"easy_search_result";
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
    
    [searchKeyModel release];

}

-(NSString*)getAreaView2PanelImageName{

    NSString* panelImageName = @"area_purple.png";
    if(areaSelectIndex == 0){
        panelImageName = @"area_purple.png";
    }
    else if(areaSelectIndex == 1){
        panelImageName = @"area_red.png";
    }
    else if(areaSelectIndex == 2){
        panelImageName = @"area_green.png";
    }

    return panelImageName;
    
}

-(NSString*)converDate:(NSInteger)index{

    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:[NSDate date]];
    
    int year;
    
    year = components.year;
    
    int m = components.month;
    if (index < m && index < (m-6)){
        year++;
    }

    if(index > m && index > (m+6)){
        year--;
    }
    
    NSString* format = @"%d-%d";
    if(index< 10){
        format = @"%d-0%d";
    }
    
    NSLog(@"%@",[NSString stringWithFormat:format,year,index]);
    
    return [NSString stringWithFormat:format,year,index];

}

#pragma mark EasyOneTypeView Delegate
-(void)carouselDidEndDecelerating:(EasyOneTypeView*)oneTypeView index:(int)index{
    areaSelectIndex = index;
    areaView2.list=[[self getAppDelegate].databaseManager getRegionName:[oneTypeView.list objectAtIndex:index]];
    [areaView2 panel:[NSArray arrayWithObjects:[self getAreaView2PanelImageName], nil]];
}

@end
