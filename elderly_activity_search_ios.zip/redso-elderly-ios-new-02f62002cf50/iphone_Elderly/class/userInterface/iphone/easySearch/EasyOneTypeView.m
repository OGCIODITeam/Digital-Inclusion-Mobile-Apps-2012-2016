//
//  EasyOneTypeView.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "EasyOneTypeView.h"
#import "iCarousel.h"
#import "ElderlyThemeManager.h"
#import "GTGZHorizalTableView.h"

@interface EasyOneTypeView()<iCarouselDataSource,iCarouselDelegate,GTGZHorizalTableViewDataSource,GTGZTouchScrollerDelegate>
@property (strong,nonatomic)NSMutableArray *cellArray;
@end

@implementation EasyOneTypeView

@synthesize list;
@synthesize selectedIndex;
@synthesize cellArray=_cellArray;

- (id)initWithFrame:(CGRect)frame{
    frame.size.height=100.0f;
    self = [super initWithFrame:frame];
    if (self) {
        titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(0.0f, 5.0f, frame.size.width, 25.0f)];
        titleLabel.numberOfLines=1;
        titleLabel.textAlignment=NSTextAlignmentCenter;
        [self addSubview:titleLabel];
        [titleLabel release];
        
        carousel=[[iCarousel alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(titleLabel.frame), frame.size.width, frame.size.height-CGRectGetMaxY(titleLabel.frame))];
        carousel.type=iCarouselTypeLinear;
        carousel.clipsToBounds=YES;
        carousel.delegate=self;
        carousel.dataSource=self;
//        carousel.userInteractionEnabled=NO;
//        carousel.scrollEnabled=NO;
        [self addSubview:carousel];
        [carousel release];
        
        
        selctedImageView=[[UIImageView alloc] init];
        [carousel addSubview:selctedImageView];
        [selctedImageView release];
        
        panelImgIndex = 0;
        
        hCarousel=[[GTGZHorizalTableView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(titleLabel.frame), frame.size.width, frame.size.height-CGRectGetMaxY(titleLabel.frame))];
        hCarousel.clipsToBounds=YES;
        hCarousel.dataSource=self;
        hCarousel.touchDelegate=self;
        hCarousel.pagingEnabled = YES;
        [self addSubview:hCarousel];
        [self voiceOverStatusChanged];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(voiceOverStatusChanged)  name:UIAccessibilityVoiceOverStatusChanged object:nil];
        
    }
    return self;
}
-(void)voiceOverStatusChanged{
    NSLog(@"voice over changed");
    hCarousel.hidden=!UIAccessibilityIsVoiceOverRunning();
 }
-(void)dealloc{
//    [panelImg release];
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [panelImgArray release];
    [list release];
    self.cellArray = nil ;
    [super dealloc];
}

-(void)title:(NSString*)value{
    titleLabel.text=value;
}

-(void)titleTheme:(NSString*)theme{
    [titleLabel theme:theme];
}

-(void)panel:(NSArray*)array{
//    [panelImg release];
    [panelImgArray release];
    
    panelImgIndex = 0;
    
//    UIImage* img=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:[array objectAtIndex:panelImgIndex]];
//    img=[img stretchableImageWithLeftCapWidth:img.size.width*0.5f topCapHeight:img.size.height*0.5f];
    
//    panelImg=[img retain];
    panelImgArray = [array retain];
    [carousel reloadData];
    
}
-(void)setList:(NSArray *)value{
    [list release];
    self.cellArray=nil;
    list=[value retain];
    [carousel reloadData];
    [hCarousel reloadData];
}


-(void)scrollToIndex:(NSInteger)index{
    [hCarousel setContentOffset:CGPointMake(index*carousel.bounds.size.width , 0) animated:YES];
    [self.delegate carouselDidEndDecelerating:self index:index];
}

-(void)selectedImage:(NSString*)value{
    
    UIImage* img=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:value];
   //img=[img stretchableImageWithLeftCapWidth:img.size.width*0.5f topCapHeight:img.size.height*0.5f];
    selctedImageView.image=img;
    CGRect rect=selctedImageView.frame;
    rect.size=img.size;
    rect.origin.x=(self.frame.size.width-rect.size.width)*0.5f;
    rect.origin.y=5.0f;
    selctedImageView.frame=rect;
}




-(void)setDefault:(NSInteger)index{
    [self scrollToIndex:index];
    [carousel scrollToItemAtIndex:index animated:NO];
}

-(void)hideTitleAndAdjustPannel{
    titleLabel.hidden=YES;
    CGRect rect=self.frame;
    rect.size.height=100.0f-25.0f;
    self.frame=rect;
    
    carousel.frame=self.bounds;
   hCarousel.frame=self.bounds;
}

#pragma mark  icarousel delegate
- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return [list count];
}

//- (BOOL)carouselShouldWrap:(iCarousel *)carousel{
//    return YES;
//}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if(option==iCarouselOptionVisibleItems){
        return 3.0f;
    }
    return value;
}

-(CGFloat)carouselItemWidth:(iCarousel *)_carousel{
        return 180.0f;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index reusingView:(UIView *)view{
    
    UIButton* panelView=nil;
    
    if (view == nil){
        panelView=[UIButton buttonWithType:UIButtonTypeCustom];
      //  [panelView addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [panelView theme:@"easysearch_carousel_button"];
    }
    else{
        panelView=(UIButton*)view;
    }
    
    view=panelView;
    panelView.tag=index;
    [panelView setUserInteractionEnabled:NO];

    NSString* title=[list objectAtIndex:index];

      
    if(panelImgIndex >= panelImgArray.count){
        panelImgIndex = 0;
    }
    
    UIImage* panelImg = [[ElderlyThemeManager sharedInstance] imageByTheme:[panelImgArray objectAtIndex:panelImgIndex]];
    panelImgIndex++;
    
    
    [panelView setBackgroundImage:panelImg forState:UIControlStateNormal];

    CGSize _size=[title sizeWithFont:panelView.titleLabel.font];

    CGRect rect=panelView.frame;
    rect.size.height=panelImg.size.height;
    rect.size.width=_size.width+40.0f;
    panelView.frame=rect;
        
    [panelView setTitle:title forState:UIControlStateNormal];

	return view;
    
}

-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    self.selectedIndex=index;
}

- (void)carouselDidScroll:(iCarousel *)_carousel{
    self.selectedIndex=carousel.currentItemIndex;
}

- (void)carouselDidEndDragging:(iCarousel *)_carousel willDecelerate:(BOOL)decelerate{
    self.selectedIndex=carousel.currentItemIndex;

}

- (void)carouselDidEndDecelerating:(iCarousel *)_carousel{
    self.selectedIndex=carousel.currentItemIndex;
    
}

- (void)carouselDidEndScrollingAnimation:(iCarousel *)carousel{

    if(self.delegate != nil){
        [self.delegate carouselDidEndDecelerating:self index:self.selectedIndex];
    }
}
#pragma mark  GTGZHorizalTableView delegate

-(NSMutableArray *)cellArray{
    if (!_cellArray) {
        _cellArray=[[NSMutableArray alloc]init];
        for (int rowIndex=0;rowIndex<list.count;rowIndex++) {
            
            GTGZHorizalTableViewCell  *panelView=[GTGZHorizalTableViewCell buttonWithType:UIButtonTypeCustom];
             NSString* title=[list objectAtIndex:rowIndex];
            panelView.alpha=0.5;
            panelView.accessibilityLabel=title;
            [_cellArray addObject:panelView];
        }
    }
    return   _cellArray;
}
-(float)dataViewWidth:(GTGZHorizalTableView*)tableView rowIndex:(int)rowIndex{
    return self.frame.size.width;
}


-(void)dataViewEndDraging:(GTGZHorizalTableView*)tableView{
    
    self.selectedIndex=[self checkWhichCellSelected];
    [carousel scrollToItemAtIndex:self.selectedIndex animated:YES];

    if(self.delegate != nil){
        [self.delegate carouselDidEndDecelerating:self index:self.selectedIndex];

    }
}
-(NSInteger)checkWhichCellSelected{
    return  hCarousel.contentOffset.x/carousel.bounds.size.width;
}
- (GTGZHorizalTableViewCell *)dataView:(GTGZHorizalTableView *)tableView rowIndex:(int)rowIndex{
    GTGZHorizalTableViewCell *panelView=[GTGZHorizalTableViewCell buttonWithType:UIButtonTypeSystem];
    
    if (self.cellArray) {
        panelView=(GTGZHorizalTableViewCell *)[self.cellArray objectAtIndex:rowIndex];
        
    }
    
   	return panelView;
}

-(int)dataViewRowsCount:(GTGZHorizalTableView*)tableView{
    return (int)[list count];
}


@end
