//
//  EasyOneTypeView.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-19.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EasyOneTypeView;

@protocol EasyOneTypeViewDelegate <NSObject>
@optional
-(void)carouselDidEndDecelerating:(EasyOneTypeView*)oneTypeView index:(int)index;

@end



@class iCarousel;
@class GTGZHorizalTableView;
@interface EasyOneTypeView : UIView{
    UILabel* titleLabel;
    iCarousel* carousel;
//    UIImage* panelImg;
    UIImageView* selctedImageView;
    NSArray* panelImgArray;
    NSInteger panelImgIndex;
   GTGZHorizalTableView *hCarousel;
}

@property(nonatomic,assign) int selectedIndex;
@property(nonatomic,retain) NSArray* list;
@property(nonatomic,assign) id<EasyOneTypeViewDelegate> delegate;

-(void)title:(NSString*)value;

-(void)titleTheme:(NSString*)theme;

-(void)panel:(NSArray*)array;
-(void)selectedImage:(NSString*)value;
-(void)setDefault:(NSInteger)index;

-(void)hideTitleAndAdjustPannel;

@end
