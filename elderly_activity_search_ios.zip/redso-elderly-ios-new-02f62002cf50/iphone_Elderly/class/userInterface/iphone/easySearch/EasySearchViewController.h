//
//  EasySearchViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"

@class EasyOneTypeView;
@class ButtonText;
@interface EasySearchViewController : ElderlyContentViewController{
    EasyOneTypeView* typeView;
    
    EasyOneTypeView* areaView1;
    EasyOneTypeView* areaView2;
    
    EasyOneTypeView* monthView;
    
    
    ButtonText* searchButton;
    
    NSInteger areaSelectIndex;

}

@end
