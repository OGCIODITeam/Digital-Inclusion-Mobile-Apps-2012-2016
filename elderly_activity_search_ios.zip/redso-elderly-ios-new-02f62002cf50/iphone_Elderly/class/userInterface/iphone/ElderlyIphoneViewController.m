//
//  ElderlyIphoneViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneViewController.h"
#import "ElderlyUtils.h"
#import "AppDelegate.h"

@interface ElderlyIphoneViewController ()
-(void)themeChanged;
@end

@implementation ElderlyIphoneViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    //if([ElderlyUtils isRetain4]){
        //CGRect frame=self.view.frame;
        //frame.size.height+=(568-480);
        //self.view.frame=frame;
    //}
    
    if([ElderlyUtils systemVersion] >= 7.0){
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars=NO;
        self.automaticallyAdjustsScrollViewInsets=NO;
    }
    [self.view setAccessibilityViewIsModal:YES];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeChanged) name:NotificationThemeChanged object:nil];

    self.view.backgroundColor = UIColorFromRGB(0xfbf8f5);
}

- (void)viewDidUnload{
    [super viewDidUnload];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NotificationThemeChanged object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)themeChanged{
    
}

-(AppDelegate*)getAppDelegate{

    return (AppDelegate*)[UIApplication sharedApplication].delegate;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
