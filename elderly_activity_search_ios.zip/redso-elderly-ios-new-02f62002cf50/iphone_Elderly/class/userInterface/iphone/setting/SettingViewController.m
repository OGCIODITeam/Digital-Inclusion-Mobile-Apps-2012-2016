//
//  SettingViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "SettingViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyThemeManager.h"
#import "SettingItemView.h"
#import "ElderlySettingManager.h"
#import "ButtonText.h"
#import "ElderlyIphoneWebBrowserViewController.h"
#import "ElderlyGA.h"
#import "ElderlyApiManager.h"

@interface SettingViewController ()<SettingItemViewDelegate>

-(void)initItemView;
-(void)initSelectColor:(NSInteger)selectIndex;
-(void)removeSelectColorView;
-(NSString*)getColorImage:(NSInteger)index;
@end

@implementation SettingViewController

@synthesize back;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
//        self.title = lang(@"setting");
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_SETTING];
    [self initItemView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{

    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_vermilion.png"];
    [nav titleView:lang(@"setting")];

}


-(void)themeChanged{

    DLog(@" themeChanged ");
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_vermilion.png"];
    [nav titleView:lang(@"setting")];
    
    [aboutButton setTitle:lang(@"about") forState:UIControlStateNormal];
    [aboutButton theme:@"about_Title"];
    [fontItemView setTitle:lang(@"fontSize")];
    [languageItemView setTitle:lang(@"language")];
    [colorItemView setTitle:lang(@"color")];
    [fontItemView setButtonViewTitleTheme:[NSArray arrayWithObjects:@"setting_font_small_title",@"setting_font_medium_title",@"setting_font_big_title", nil]];
    [languageItemView setButtonViewTitleTheme:[NSArray arrayWithObjects:@"setting_language_title",@"setting_language_title", nil]];
    [colorItemView setButtonViewTitleTheme:[NSArray arrayWithObjects:@"setting_color_title",@"setting_color_title", nil]];
    
}


#pragma mark init

-(void)initItemView{
    
    float spacing = 8;
    if([ElderlyUtils isRetain4]){
        spacing = 20;
    }

    float orginX = (self.view.bounds.size.width - 288)*0.5f;
    fontItemView = [[SettingItemView alloc] initWithFrame:CGRectMake(orginX, ([ElderlyUtils isRetain4]?30:15), 290, 107)];
    [fontItemView setTitle:lang(@"fontSize")];
    fontItemView.delegate = self;
    fontItemView.tag = 1001;
    [fontItemView setButtonViewTitle:[NSArray arrayWithObjects:lang(@"small"),lang(@"medium"),lang(@"big"), nil] selectIndex:[[self getAppDelegate].settingManager getFontType]];
    [fontItemView setButtonViewTitleTheme:[NSArray arrayWithObjects:@"setting_font_small_title",@"setting_font_medium_title",@"setting_font_big_title", nil]];
    [self.view addSubview:fontItemView];
    [fontItemView release];
    
    languageItemView = [[SettingItemView alloc] initWithFrame:CGRectMake(orginX, CGRectGetMaxY(fontItemView.frame)+spacing, 290, 107)];
    [languageItemView setTitle:lang(@"language")];
    languageItemView.delegate = self;
    languageItemView.tag = 1002;
    [languageItemView setButtonViewTitle:[NSArray arrayWithObjects:lang(@"complex_font"),lang(@"familiar_style"), nil] selectIndex:[[self getAppDelegate].settingManager getlanguageType]];
    [languageItemView setButtonViewTitleTheme:[NSArray arrayWithObjects:@"setting_language_title",@"setting_language_title", nil]];
    [self.view addSubview:languageItemView];
    [languageItemView release];
    
    colorItemView = [[SettingItemView alloc] initWithFrame:CGRectMake(orginX, CGRectGetMaxY(languageItemView.frame)+spacing, 290, 107)];
    [colorItemView setButtonViewTitle:[NSArray arrayWithObjects:lang(@"color1"),lang(@"color2"), nil] selectIndex:[[self getAppDelegate].settingManager getColorType]];
    [colorItemView setTitle:lang(@"color")];
    colorItemView.delegate = self;
    [colorItemView setButtonViewTitleTheme:[NSArray arrayWithObjects:@"setting_color_title",@"setting_color_title", nil]];
    colorItemView.tag = 1003;
    [self.view addSubview:colorItemView];
    [colorItemView release];
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"item_setting.png"];
    UIImageView* aboutView = [[UIImageView alloc] initWithFrame:CGRectMake(orginX, CGRectGetMaxY(colorItemView.frame)+spacing+5, 290, 60)];
    aboutView.image = img;
    aboutView.userInteractionEnabled = YES;
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_about_us.png"];
    aboutButton = [[UIButton alloc] initWithFrame:CGRectMake((aboutView.frame.size.width - img.size.width)*0.5f, (aboutView.frame.size.height - img.size.height)*0.5f, img.size.width, img.size.height)];
    [aboutButton setBackgroundImage:img forState:UIControlStateNormal];
    [aboutButton setTitle:lang(@"about") forState:UIControlStateNormal];
    [aboutButton theme:@"about_Title"];
    [aboutButton addTarget:self action:@selector(clickAboutButton) forControlEvents:UIControlEventTouchUpInside];
    [aboutView addSubview:aboutButton];
    [aboutButton release];
    
    [self.view addSubview:aboutView];
    [aboutView release];
    


}

-(void)initSelectColor:(NSInteger)selectIndex{

    if(selectColorView == nil){
    
        selectColorView = [[UIView alloc] initWithFrame:self.view.bounds];
        [selectColorView setAccessibilityViewIsModal:YES];
        UIImageView* bgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
        bgView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_picker_box.png"];
        selectColorView.alpha = 0.0f;
        [selectColorView addSubview:bgView];
        [bgView release];
        
        UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 60)*0.5f, 91, 60, 25)];
        
        titleLabel.text = (selectIndex == 0?lang(@"color1"):lang(@"color2"));
        [titleLabel theme:@"setting_select_color_title"];
        titleLabel.textAlignment = UITextAlignmentCenter;
        [selectColorView addSubview:titleLabel];
        [titleLabel release];
        
        UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme: [self getColorImage:selectIndex]];
        UIImageView* colorImageView = [[UIImageView alloc] initWithFrame:CGRectMake((selectColorView.frame.size.width - img.size.width)*0.5f, CGRectGetMaxY(titleLabel.frame)+15, img.size.width, img.size.height)];
        colorImageView.image = img;
        [selectColorView addSubview:colorImageView];
        [colorImageView release];
        
        
        img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_setting_sure.png"];
        ButtonText* okButton = [[ButtonText alloc] initWithFrame:CGRectMake((selectColorView.frame.size.width - img.size.width)*0.5f, CGRectGetMaxY(colorImageView.frame)+25, img.size.width, img.size.height)];
        okButton.spacing = 5.0f;
        [okButton setBackgroundImage:img forState:UIControlStateNormal];
        [okButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_sure.png"]];
        [okButton text:lang(@"confirm")];
        okButton.tag = selectIndex;
        [okButton theme:@"okButton_title"];
        [okButton addTarget:self action:@selector(clickOkButton:) forControlEvents:UIControlEventTouchUpInside];
        [selectColorView addSubview:okButton];
        [okButton release];

        [self.view addSubview:selectColorView];
        [selectColorView release];
        
        
        [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
            selectColorView.alpha=1.0f;
        } completion:^(BOOL finish){
            
        }];
    }

}


#pragma mark method
-(void)navigationLeftClick{
    
    if(selectColorView != nil){
        [self removeSelectColorView];
              
        return ;
    }
    if(self.back){
        [[self getAppDelegate].rootController back];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)clickOkButton:(ButtonText*)sender{

    [[self getAppDelegate].settingManager setColorType:sender.tag];
    [self removeSelectColorView];
}

-(void)clickAboutButton{
    DLog(@"clickAboutButton");
    
    ElderlyIphoneWebBrowserViewController* webBrowserViewController = [[ElderlyIphoneWebBrowserViewController alloc] init];
    webBrowserViewController.isHome = 2;
    webBrowserViewController.zoomScale = YES;
    [self.navigationController pushViewController:webBrowserViewController animated:YES];
    
    [webBrowserViewController loadRequestAfterDelay:[ElderlyApiManager aboutUsApi].absoluteString];


//    NSString* htmlPath = [[NSBundle mainBundle] pathForResource:@"rest_home" ofType:@"html"];
//    NSString* html = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
//    [webBrowserViewController loadHTMLStringAfterDelay:html ];

    [webBrowserViewController release];

}

-(void)removeSelectColorView{
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        selectColorView.alpha=0.0f;
        [colorItemView selectButton:[[self getAppDelegate].settingManager getColorType]];
        
    } completion:^(BOOL finish){
        [selectColorView removeFromSuperview];
        selectColorView = nil;
    }];

}

-(NSString*)getColorImage:(NSInteger)index{

    
    NSString* colorImage = nil;
    
    if([ElderlyUtils languageType]){
        colorImage = (index == 0?@"color01_sc.png":@"color02_sc.png");
    }
    else{
        colorImage = (index == 0?@"color01_tc.png":@"color02_tc.png");
    }
    
    
    return colorImage;

}

#pragma mark SettingItemView Delegate

-(void)didSelectSettingItemView:(SettingItemView*)itemView selectIndex:(NSInteger)index{
    NSLog(@"didSelectSettingItemView");
    
    switch (itemView.tag) {
        case 1001:{
            [[self getAppDelegate].settingManager setFontType:index];
            [fontItemView selectButton:index];
            
            NSString* categoryCode = nil;
            if(index == 0){
                categoryCode = GA_CODE_SMALLFONTSIZE;
            }
            else if(index == 1){
                categoryCode = GA_CODE_MEDIUMFONTSIZE;
            }
            else if(index == 2){
                categoryCode = GA_CODE_LARGEFONTSIZE;
            }
            
            if(categoryCode != nil)
                [[ElderlyGA sharedInstance] trackEvent:categoryCode];
        
            break;
        }
        case 1002:{
        
            [[self getAppDelegate].settingManager setlanguageType:index];
            [languageItemView selectButton:index];
            
            NSString* categoryCode = nil;
            if(index == 0){
                categoryCode = GA_CODE_TRADITIONALCHINESE;
            }
            else if(index == 1){
                categoryCode = GA_CODE_SIMPLIFIEDCHINESE;
            }
           
            if(categoryCode != nil)
                [[ElderlyGA sharedInstance] trackEvent:categoryCode];
            break;
        }
        case 1003:{
        
            [colorItemView selectButton:index];
            [self initSelectColor:index];
            
            NSString* categoryCode = nil;
            if(index == 0){
                categoryCode = GA_CODE_COLOUR1;
            }
            else if(index == 1){
                categoryCode = GA_CODE_COLOUR2;
            }
            
            if(categoryCode != nil)
                [[ElderlyGA sharedInstance] trackEvent:categoryCode];
            break;
        }
            
        default:
            break;
    }
}




@end
