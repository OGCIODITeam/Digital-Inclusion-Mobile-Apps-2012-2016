//
//  SettingViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"
@class SettingItemView;
@interface SettingViewController : ElderlyContentViewController{

    SettingItemView* fontItemView;
    SettingItemView* languageItemView;
    SettingItemView* colorItemView;
    
    UIButton* aboutButton;
    
    UIView* selectColorView;
}



@property(nonatomic,assign)BOOL back;


@end
