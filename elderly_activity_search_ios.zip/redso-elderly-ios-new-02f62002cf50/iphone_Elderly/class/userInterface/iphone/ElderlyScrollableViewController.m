//
//  ElderlyScrollableViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 8/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyScrollableViewController.h"
#import "ElderlyThemeManager.h"

@interface ElderlyScrollableViewController ()


@end

@implementation ElderlyScrollableViewController
@synthesize scrollImageView;

- (void)dealloc
{
    self.scrollImageView = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    
    UIImage *image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
    CGRect imageFrame = CGRectMake(0, self.view.frame.size.height - image.size.height, image.size.width, image.size.height);
    UIImageView *tmpImageView = [[UIImageView alloc] initWithFrame:imageFrame];
    tmpImageView.image = image;
    DLog(@"tmpImageView  >>>  %@", NSStringFromCGRect(imageFrame));
    [self.view addSubview:tmpImageView];
    self.scrollImageView = tmpImageView;
    self.scrollImageView.hidden = YES;
    [tmpImageView release];
    [self.view bringSubviewToFront:self.scrollImageView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if(scrollView.contentOffset.y <= 0){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
        
    }
    else if(scrollView.contentOffset.y>=scrollView.contentSize.height-scrollView.frame.size.height){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll_up.png"];
    }
}

@end
