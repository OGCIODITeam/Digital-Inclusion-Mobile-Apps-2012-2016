//
//  LocatorSearchResultViewController.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LocatorSearchResultViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyThemeManager.h"
#import "ElderlyRootViewController.h"


#import "CenterSearchResultViewController.h"
#import "LCSDViewController.h"
#import "ElderlySearchKeyModel.h"

@interface LocatorSearchResultViewController ()

@property (retain, nonatomic) CenterSearchResultViewController *centerSearchResultVC;
@property (retain, nonatomic) LCSDViewController *lcsdVC;


@end

@implementation LocatorSearchResultViewController
@synthesize centerSearchResultVC;
@synthesize lcsdVC;
@synthesize searchKeyModel;
@synthesize navTitle;


- (id)init
{
    self = [super init];
    if (self) {
//        self.title = lang(@"search_result");
    }
    return self;
}

- (void)dealloc
{
    self.centerSearchResultVC = nil;
    self.lcsdVC = nil;
    self.searchKeyModel = nil;
    self.navTitle = nil;
    [super dealloc];
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    
//    [nav titleView:lang(@"search_result")];
    [nav titleView:lang(self.navTitle)];
}

-(void)themeChanged{
    [super themeChanged];
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
//    [nav titleView:lang(@"search_result")];
    [nav titleView:lang(self.navTitle)];
}


-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    [self.navigationController popViewControllerAnimated:YES];
//    [[self getAppDelegate].rootController back];
    
}

- (UIViewController*)getVCByIndex:(NSInteger) index{
    
    ElderlySearchKeyModel *keyModel = [[ElderlySearchKeyModel alloc] init];
    keyModel.eventType = self.searchKeyModel.eventType;
    keyModel.month = self.searchKeyModel.month;
    keyModel.activeArea = self.searchKeyModel.activeArea;
    keyModel.age = self.searchKeyModel.age;
    keyModel.fee = self.searchKeyModel.fee;
    keyModel.organization = self.searchKeyModel.organization;
    keyModel.keyword = self.searchKeyModel.keyword;
    keyModel.isAdSearch = self.searchKeyModel.isAdSearch;
    keyModel.searchtype = self.searchKeyModel.searchtype;
    
    UIViewController *rVC = nil;
    if(index==0){
        CenterSearchResultViewController *vc = [[[CenterSearchResultViewController alloc] init] autorelease];
        vc.searchResultTabVC = self;
        vc.searchKeyModel = keyModel;
        rVC = vc;
        
    }
    else if(index==1){
        
        LCSDViewController *vc = [[[LCSDViewController alloc] init] autorelease];
        vc.searchResultTabVC = self;
        vc.searchKeyModel = keyModel;
        rVC = vc;
    }
    
    [keyModel release];
    
    return rVC;
}



@end
