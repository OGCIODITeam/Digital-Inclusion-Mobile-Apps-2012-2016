//
//  LCSDViewController.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 12/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyScrollableViewController.h"
#import "CalendarHeaderView.h"
#import "CalendarView.h"
#import "LocatorSearchResultViewController.h"
@class ElderlySearchKeyModel;
@class LoadingView;
@class MonthView;

@interface LCSDViewController : ElderlyScrollableViewController<CalendarHeaderViewDelegate, CalendarViewDelegate, UITableViewDataSource, UITableViewDelegate>

@property (assign, nonatomic) LocatorSearchResultViewController *searchResultTabVC;
@property (retain, nonatomic) ElderlySearchKeyModel* searchKeyModel;
@property (retain, nonatomic) LoadingView *loadingView;
@property (retain, nonatomic) NSDate *currentDate;
@property (retain, nonatomic) NSArray *activityList;
@property (retain, nonatomic) UILabel *noActivityLabel;
@property (retain, nonatomic) UITableView* lcsdTableView;
@property (retain, nonatomic) CalendarHeaderView *calendarHeaderView;
@property (retain, nonatomic) CalendarView *calendarView;
@property (retain, nonatomic) MonthView *monthView;
@property (assign, nonatomic) BOOL isMonth;

@end
