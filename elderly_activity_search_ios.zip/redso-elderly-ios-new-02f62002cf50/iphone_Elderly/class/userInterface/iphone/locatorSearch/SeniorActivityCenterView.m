//
//  SeniorActivityCenterView.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "SeniorActivityCenterView.h"
#import "LevelModel.h"

#define TITLE_CELL_HEIGHT  60.0f
#define DETAIL_CELL_HEIGHT 110.0f

@interface SeniorActivityCenterView()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation SeniorActivityCenterView

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor clearColor];
        self.dataSource=self;
        self.delegate=self;
        self.showsHorizontalScrollIndicator=NO;
        self.showsVerticalScrollIndicator=NO;
        self.separatorColor=[UIColor clearColor];
        
        list=[[NSMutableArray alloc] initWithCapacity:2];
        

        [self loadData];
        
    }
    return self;
}

- (void)dealloc{
    [list release];
    [super dealloc];
}

#ifdef DEV_VERSION

-(void)loadData{
    LevelModel* entity=[[LevelModel alloc] init];
    entity.titleModel=@"title1";
    [list addObject:entity];
    [entity release];
    
    
    entity=[[LevelModel alloc] init];
    entity.titleModel=@"title2";
    [list addObject:entity];
    [entity release];
    

    entity=[[LevelModel alloc] init];
    entity.titleModel=@"title3";
    [list addObject:entity];
    [entity release];
        

}
#endif

#pragma mark tableview delegate datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [list count];
}

-(CGFloat)tableView:(UITableView *)_tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    LevelModel* entity=[ list objectAtIndex:[indexPath row]];
    
    return entity.detailModel!=nil?DETAIL_CELL_HEIGHT:TITLE_CELL_HEIGHT;
}

- (UITableViewCell *)tableView:(UITableView *)_tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LevelModel* entity=[ list objectAtIndex:[indexPath row]];
    if(entity.detailModel==nil){
        UITableViewCell* cell=[_tableView dequeueReusableCellWithIdentifier:@"titlecell"];
        if(cell==nil){
            cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"titlecell"] autorelease];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
        }
        NSString* title=entity.titleModel;
        cell.textLabel.text=title;
        return cell;
    }
    else{
        UITableViewCell* cell=[_tableView dequeueReusableCellWithIdentifier:@"detailcell"];
        if(cell==nil){
            cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"detailcell"] autorelease];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
        }
        NSString* content=entity.detailModel;
        cell.textLabel.text=content;
        return cell;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    LevelModel* entity=[ list objectAtIndex:[indexPath row]];

    if(entity.titleModel!=nil){
        NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];

        if(entity.expand){
            int i=[indexPath row]+1;
            int index=i;
            NSMutableArray* rows=[NSMutableArray arrayWithCapacity:2];

            while (i<[list count]) {
                NSIndexPath* _indexPath=[NSIndexPath indexPathForRow:index inSection:[indexPath section]];
                LevelModel* _entity=[ list objectAtIndex:i];
                if(_entity.titleModel!=nil)break;
                
                index++;

                [rows addObject:_indexPath];
                [list removeObjectAtIndex:i];
            }
            
            [tableView deleteRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationFade];

        }
        else{

            NSMutableArray* rows=[NSMutableArray arrayWithCapacity:2];

            LevelModel* entity=[[LevelModel alloc] init];
            entity.detailModel=@"content1";
            [list insertObject:entity atIndex:[indexPath row]+1];
            [entity release];
            NSIndexPath* _indexPath=[NSIndexPath indexPathForRow:[indexPath row]+1 inSection:[indexPath section]];
            [rows addObject:_indexPath];

            
            entity=[[LevelModel alloc] init];
            entity.detailModel=@"content2";
            [list insertObject:entity atIndex:[indexPath row]+2];
            [entity release];
            
            _indexPath=[NSIndexPath indexPathForRow:[indexPath row]+2 inSection:[indexPath section]];
            [rows addObject:_indexPath];


            
            [tableView insertRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationFade];

        }
        
        [pool release];
        entity.expand=!entity.expand;
    }
    
    
    
}

@end
