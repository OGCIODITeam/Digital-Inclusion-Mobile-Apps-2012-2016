//
//  CenterSearchResultViewController.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 11/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyActivityListViewController.h"
#import "LocatorSearchResultViewController.h"
@class ElderlySearchKeyModel;
@class ElderlyNearBySearchKeyModel;

@interface CenterSearchResultViewController : ElderlyActivityListViewController

@property (assign, nonatomic) LocatorSearchResultViewController *searchResultTabVC;
@property (retain, nonatomic) ElderlySearchKeyModel* searchKeyModel;
@property (retain, nonatomic) ElderlyNearBySearchKeyModel* nearBySearchKeyModel;
@property (retain, nonatomic) NSString *navTitle;
//@property (assign, nonatomic) BOOL isAdven

@end
