//
//  LocatorSearchResultViewController.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyTabViewController.h"
@class ElderlySearchKeyModel;
@interface LocatorSearchResultViewController : ElderlyTabViewController

@property(retain, nonatomic) ElderlySearchKeyModel* searchKeyModel;
@property (retain, nonatomic) NSString *navTitle;

@end
