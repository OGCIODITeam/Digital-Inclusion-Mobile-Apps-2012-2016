//
//  CenterSearchResultViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 11/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "CenterSearchResultViewController.h"
#import "AsyncTask.h"
#import "ElderlyHTTPRequestManager.h"
#import "AppDelegate.h"
#import "ElderlySearchKeyModel.h"
#import "ElderlyNearBySearchKeyModel.h"

#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyRootViewController.h"

@interface CenterSearchResultViewController ()
@property (retain, nonatomic) AsyncTask *httpTask;
@property (retain, nonatomic) NSArray *dateList;
@property (assign, nonatomic) BOOL isFirst;

@end

@implementation CenterSearchResultViewController
@synthesize httpTask;
@synthesize searchResultTabVC;
@synthesize searchKeyModel;
@synthesize dateList;
@synthesize nearBySearchKeyModel;
@synthesize navTitle;
@synthesize isFirst;
- (void)dealloc
{
    [self.httpTask cancel];
    self.httpTask = nil;
    self.searchResultTabVC = nil;
    self.searchKeyModel = nil;
    self.dateList = nil;
    self.nearBySearchKeyModel = nil;
    self.navTitle = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
        self.isFirst = YES;
    }
    return self;
}
    
-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(self.navTitle)];
        
}
    
-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    [self.navigationController popViewControllerAnimated:YES];
    //    [[self getAppDelegate].rootController back];
    
}
   
    
-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}
    
-(void)themeChanged{
    [super themeChanged];
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
//    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(self.navTitle)];
}

- (void)viewDidLoad
{
    if(self.searchKeyModel != nil && (self.searchKeyModel.searchtype == hotSearch || self.searchKeyModel.searchtype == easySrach)){
        self.isMonth = YES;
    }
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
//    CGRect frame = self.view.frame;S
//    frame.origin = CGPointZero;
//    frame.size.height = self.view.superview.frame.size.height;
//    self.view.frame = frame;
    
  
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.httpTask cancel];
    self.httpTask = nil;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)themeIndx{
    return 3;
}

- (void)getActivityList{
    [self.loadingView startLoading];
    self.noActivityLabel.hidden = YES;

    if(self.searchKeyModel != nil && (self.searchKeyModel.searchtype == hotSearch || self.searchKeyModel.searchtype == easySrach)){
    
        
        
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = lang(@"yyyy-MM");
        
        if(self.isFirst){
            self.isFirst = NO;
            self.currentDate = [dateFormatter dateFromString:self.searchKeyModel.month];
            [self.calendarHeaderView setDate:self.currentDate];
        }
        else{
            NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
            self.searchKeyModel.month = dateStr;
        }

        [dateFormatter release];
        AsyncTask *task = nil;
        if(self.searchKeyModel.searchtype == easySrach )
            task = [[self getAppDelegate].httpRequestManager easySearchList:self.searchKeyModel activityType:@"E" offset:0 pageSize:200];
        else
            task = [[self getAppDelegate].httpRequestManager searchElderlyList:self.searchKeyModel offset:0 pageSize:200];
        [task setFinishBlock:^{
        
            self.centerList = [task result];
            [self.expandTableView reloadData];
            [self.calendarHeaderView setDate:self.currentDate];
            [self.loadingView stopLoading];
            
            if (self.centerList.count>0) {
                self.expandTableView.hidden = NO;
                self.noActivityLabel.hidden = YES;
            }else{
                self.expandTableView.hidden = YES;
                self.noActivityLabel.hidden = NO;
                self.scrollImageView.hidden = YES;
            }
            [self.loadingView stopLoading];

        
        }];
        self.httpTask = task;

        return;
    }
    

    if (self.dateList==nil) {
        
        if (self.searchKeyModel.isAdSearch) {
            NSArray *list = [NSArray arrayWithObjects:@"1", nil];
            self.dateList = list;
            
            NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
            
            if (self.searchKeyModel.month==nil) {
                self.searchKeyModel.month = [dateFormatter stringFromDate:[NSDate date]];
            }
            
            self.currentDate = [dateFormatter dateFromString:self.searchKeyModel.month];
            
            [self.calendarHeaderView setDate:self.currentDate];
            [dateFormatter release];
            
            [self search];
            return;
        }
        
        AsyncTask *task = nil;
        if ([self isNearBySearch]) {
            task = [[self getAppDelegate].httpRequestManager getDateListByCoordinate:self.nearBySearchKeyModel];
        }else{
            task = [[self getAppDelegate].httpRequestManager getDateList:self.searchKeyModel activityType:@"E"];
        }
        
        [task setFinishBlock:^{
            self.dateList = [task result];
            NSLog(@"self.dateList.count  >>>>  %d", self.dateList.count);
            if (self.dateList.count>0) {
                unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
                NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
                
                
                NSString *dateStr = nil;
                NSString *month = nil;
                if ([self isNearBySearch]) {
                    month = self.nearBySearchKeyModel.date;
                }else{
                    month = self.searchKeyModel.month;
                }
                dateFormatter.dateFormat = lang(@"yyyy-MM");
                
                NSDate *searchDate = [dateFormatter dateFromString:month];
                NSDateComponents *searchComp = [cal components:units fromDate:searchDate];
                
                NSDate *today = [NSDate date];
                NSDateComponents *todayComp = [cal components:units fromDate:today];
                
                if (searchComp.month!=todayComp.month) {
                    dateStr = [self.dateList objectAtIndex:0];
                }else{
                    dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
                    for (int i=0; i<self.dateList.count; i++) {
                        NSString *resultDateStr = [self.dateList objectAtIndex:i];
                        NSDate *resultDate = [dateFormatter dateFromString:resultDateStr];
                        NSDateComponents *resultComp = [cal components:units fromDate:resultDate];
                        if (resultComp.day >= todayComp.day) {
                            dateStr = [self.dateList objectAtIndex:i];
                            break;
                        }
                    }
                    
                    if (dateStr == nil) {
                        dateStr = [self.dateList objectAtIndex:self.dateList.count - 1];
                    }
                }
                
                
                [cal release];
                dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
                self.currentDate = [dateFormatter dateFromString:dateStr];
                
                [self.calendarHeaderView setDate:self.currentDate];
                [dateFormatter release];
                if ([self isNearBySearch]) {
                    self.nearBySearchKeyModel.date = dateStr;
                }else{
                    self.searchKeyModel.month = dateStr;
                }
                
                
                [self search];
                
            }else{
                
                unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
                NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
                dateFormatter.dateFormat = lang(@"yyyy-MM");
                
                
                NSString *monthStr = nil;
                if ([self isNearBySearch]) {
                    monthStr =self.nearBySearchKeyModel.date;
                }else{
                    monthStr =self.searchKeyModel.month;
                }
                
                NSDate *searchDate = [dateFormatter dateFromString:monthStr];
                NSDateComponents *searchComp = [cal components:units fromDate:searchDate];
                
                NSDate *today = [NSDate date];
                NSDateComponents *todayComp = [cal components:units fromDate:today];
                
                if (searchComp.month!=todayComp.month) {
                    dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
                    NSString *month = nil;
                    if ([self isNearBySearch]) {
                        month =self.nearBySearchKeyModel.date;
                    }else{
                        month =self.searchKeyModel.month;
                    }
                    self.currentDate = [dateFormatter dateFromString:[NSString stringWithFormat:@"%@-01", month]];
                    DLog(@"self.currentDate  >>>   %@", self.currentDate);
                    [self.calendarHeaderView setDate:self.currentDate];
                    
                }
                [cal release];
                [dateFormatter release];
                
                self.expandTableView.hidden = YES;
                self.noActivityLabel.hidden = NO;
                self.scrollImageView.hidden = YES;
                [self.loadingView stopLoading];
            }
        }];
        self.httpTask = task;
    }else{
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
        NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
        
        if ([self isNearBySearch]) {
            self.nearBySearchKeyModel.date = dateStr;
        }else{
            self.searchKeyModel.month = dateStr;
        }
        [dateFormatter release];
        [self search];
    }
    
    

}

- (void)search{
    
    
    AsyncTask *task = nil;
    if ([self isNearBySearch]) {
        task = [[self getAppDelegate].httpRequestManager searchNearByList:self.nearBySearchKeyModel offset:0 pageSize:200];
    }else{
        task = [[self getAppDelegate].httpRequestManager searchElderlyList:self.searchKeyModel offset:0 pageSize:200];
    }
    
    [task setFinishBlock:^{
        self.centerList = [task result];
        [self.expandTableView reloadData];
        [self.loadingView stopLoading];
        
        if (self.centerList.count>0) {
            self.expandTableView.hidden = NO;
            self.noActivityLabel.hidden = YES;
        }else{
            self.expandTableView.hidden = YES;
            self.noActivityLabel.hidden = NO;
            self.scrollImageView.hidden = YES;
        }
        [self.loadingView stopLoading];
    }];
    self.httpTask = task;
    
    
}


- (float)paddingTop{
    if (self.searchResultTabVC==nil) {
        return 10;
    }else{
        return 0;
    }
    
}

- (CGRect)getViewFrame{
    CGRect rect = [[UIScreen mainScreen]bounds];
    if (self.searchResultTabVC==nil) {
        rect.size.height-= (44.0f);
    }else{
        rect.size.height-= (44.0f + 56.0f);
    }
    
    return rect;
}

- (UINavigationController*)navigationController{
    if (self.searchResultTabVC.navigationController!=nil) {
        return self.searchResultTabVC.navigationController;
    }else{
        return [super navigationController];
    }
    
}
- (BOOL)isNearBySearch{
    if (self.nearBySearchKeyModel!=nil) {
        return YES;
    }else{
        return NO;
    }
}
    

@end
