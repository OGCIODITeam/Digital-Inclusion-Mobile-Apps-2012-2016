//
//  LevelModel.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LevelModel.h"

@implementation LevelModel
@synthesize titleModel;
@synthesize detailModel;
@synthesize expand;
-(void)dealloc{
    self.titleModel=nil;
    self.detailModel=nil;
    [super dealloc];
}
@end
