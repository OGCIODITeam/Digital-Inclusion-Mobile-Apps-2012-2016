//
//  LocatorSearchViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"

@class ButtonText;
@class AreaPicker;
@class CLLocationManager;
@interface LocatorSearchViewController : ElderlyContentViewController{
    UILabel* titleLabel;
    
    UIButton* currentLocationButton;
    UIButton* liveButton;
    
    UIImageView* arrowImage;
    
    UILabel* selectedLabel;
    
    ButtonText* comboxButton;
    
    UIImageView* lineView;
    
    ButtonText* searchButton;
    
    int locationIndex;
    int distanceIndex;
    
    NSArray* distanceList;

    AreaPicker* picker;
    
    CLLocationManager* locationManager;
    
    double longitude;
    double latitude;
    
}

@end
