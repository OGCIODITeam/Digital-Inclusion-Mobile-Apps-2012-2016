//
//  LCSDView.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCSDView : UITableView

@end
