//
//  LCSDViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 12/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LCSDViewController.h"

#import "LoadingView.h"
#import "AsyncTask.h"
#import "ElderlyHTTPRequestManager.h"
#import "AppDelegate.h"
#import "ElderlySearchKeyModel.h"
#import "ExpandTableViewCell.h"
#import "ElderlyNewActivityModel.h"
#import "ActivityDetailViewController.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyThemeManager.h"
#import "ElderlyGA.h"
#import "MonthView.h"
#import "ThreadTask.h"
#import "ElderlyDatabaseManager.h"

@interface LCSDViewController ()<MonthViewDelegate>





@property (retain, nonatomic) AsyncTask *httpTask;
@property (retain, nonatomic) NSArray *dateList;
@property (retain, nonatomic) ThreadTask* threadTask;
@property (retain, nonatomic) ElderlyActivityDetailModel *activityDetailModel;
@property (assign, nonatomic) BOOL isFirst;



@end

@implementation LCSDViewController
@synthesize noActivityLabel;
@synthesize lcsdTableView;
@synthesize calendarHeaderView;
@synthesize calendarView;
@synthesize activityList;
@synthesize currentDate;
@synthesize loadingView;
@synthesize httpTask;
@synthesize searchResultTabVC;
@synthesize dateList;
@synthesize searchKeyModel;
@synthesize isMonth;
@synthesize monthView;
@synthesize threadTask;
@synthesize activityDetailModel;
@synthesize isFirst;

- (void)dealloc
{
    self.noActivityLabel = nil;
    self.lcsdTableView = nil;
    self.calendarHeaderView = nil;
    self.calendarView = nil;
    self.activityList = nil;
    self.currentDate = nil;
    self.loadingView = nil;
    self.httpTask = nil;
    self.searchResultTabVC = nil;
    self.dateList = nil;
    self.searchKeyModel = nil;
    self.monthView = nil;
    self.threadTask = nil;
    self.activityDetailModel = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.isMonth = NO;
        self.isFirst = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.view.frame = [self getViewFrame];
    
    CGRect calendarHeaderFrame = CGRectMake(0, 0, self.view.frame.size.width, 37);
    

    if(self.searchKeyModel.searchtype == hotSearch || self.searchKeyModel.searchtype == easySrach )
        self.isMonth = YES;
    
    CalendarHeaderView *tmpCalendarHeaderView = [[CalendarHeaderView alloc] initWithFrame:calendarHeaderFrame dateFormat:self.isMonth?lang(@"dateFormat2"):lang(@"dateFormat")];
    [self.view addSubview:tmpCalendarHeaderView];
    [tmpCalendarHeaderView setDate:[NSDate date]];
    tmpCalendarHeaderView.deleagte = self;
    self.calendarHeaderView = tmpCalendarHeaderView;
    [tmpCalendarHeaderView release];
    
    
    UITableView *tmpExpandTableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(self.calendarHeaderView.frame), self.view.frame.size.width, self.view.frame.size.height-CGRectGetMaxY(self.calendarHeaderView.frame))];
    tmpExpandTableView.delegate = self;
    tmpExpandTableView.dataSource = self;
    [self.view addSubview:tmpExpandTableView];
    self.lcsdTableView = tmpExpandTableView;
    [tmpExpandTableView release];
    

    UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.lcsdTableView.bounds.size.width, 30)];
    self.lcsdTableView.tableFooterView = tableFooterView;
    [tableFooterView release];
    
    
    NSDate *date = [NSDate date];
    self.currentDate = date;
    
    LoadingView *tmpLoadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview: tmpLoadingView];
    [tmpLoadingView release];
    self.loadingView = tmpLoadingView;
    
    
    UILabel *label = [[UILabel alloc] init];
    label.text = lang(@"noActivity");
    label.backgroundColor = [UIColor clearColor];
    [label sizeToFit];
    label.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    [self.view addSubview:label];
    label.hidden = YES;
    self.noActivityLabel = label;
    [label release];
    
    
    [self.view bringSubviewToFront:self.calendarHeaderView];
    
    [self getActivityList];
    [self resetScrollImageView];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.httpTask cancel];
    self.httpTask = nil;
    
}


#pragma marks - CalendarHeaderViewDelegate Methods
- (void)onHeaderClick{
    if(self.calendarView != nil)
        return;
    
    
    if( [ElderlyThemeManager sharedInstance].gridIndex == 2){
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_DATE];
    }
    
    if(self.isMonth){
        MonthView *tmpMonthView = [[MonthView alloc] initWithFrame:self.view.frame andDate:[self.calendarHeaderView getDate]];
        tmpMonthView.delegate = self;
        [self.view addSubview:tmpMonthView];
        self.monthView = tmpMonthView;
        [tmpMonthView release];
    }
    else{
        CalendarView *tmpCalendarView = [[CalendarView alloc] initWithFrame:self.view.frame andDate:[self.calendarHeaderView getDate]];
        tmpCalendarView.delegate = self;
        [self.view addSubview:tmpCalendarView];
        self.calendarView = tmpCalendarView;
        [tmpCalendarView release];
    }
    

}
- (void)onLeftButtonClick{
    [self changeDay:-1];
}
- (void)onRightButtonClick{
    [self changeDay:1];
}

- (void)changeDay:(int) day{
    unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *currentComp = [cal components:units fromDate:self.currentDate];
    
    if (day>0) {
        self.isMonth?[currentComp setMonth:currentComp.month + 1]:[currentComp setDay:currentComp.day + 1];
    }else{
        self.isMonth?[currentComp setMonth:currentComp.month - 1]:[currentComp setDay:currentComp.day - 1];
    }
    
    NSDate *date = [cal dateFromComponents:currentComp];
    [cal release];
    [self.calendarHeaderView setDate:date];
    self.currentDate = date;
    [self getActivityList];
}


#pragma marks - CalendarViewDelegate Methods
- (void)onDateSelect:(NSDate*) date{
    
    self.currentDate = date;
    [self getActivityList];
    
    [self.calendarHeaderView setDate:date];
    [self.calendarView removeFromSuperview];
    self.calendarView = nil;
    
}

- (void)onNoDateSelect{
    [self.calendarView removeFromSuperview];
    self.calendarView = nil;
}

#pragma marks - MonthViewDelegate Methods
-(void)onMonthSelect:(NSDate *)date{
    
    self.currentDate = date;
    [self getActivityList];
    [self.calendarHeaderView setDate:date];
    [self.monthView removeFromSuperview];
    self.monthView = nil;
}


-(void)onNoMonthSelect{
    [self.monthView removeFromSuperview];
    self.monthView = nil;
}

- (CGRect)getViewFrame{
    CGRect rect = [[UIScreen mainScreen]bounds];
    rect.size.height-= (44.0f + 56.0f);
    return rect;
}

- (void)getActivityList{
    
    [self.loadingView startLoading];
    self.noActivityLabel.hidden = YES;
    
    if(self.searchKeyModel != nil && (self.searchKeyModel.searchtype == hotSearch || self.searchKeyModel.searchtype == easySrach)){
        
        
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = lang(@"yyyy-MM");
        
        
        if(self.isFirst){
            self.isFirst = NO;
            self.currentDate = [dateFormatter dateFromString:self.searchKeyModel.month];
            [self.calendarHeaderView setDate:self.currentDate];
        }
        else{
            NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
            self.searchKeyModel.month = dateStr;
        }

        
        
        [dateFormatter release];
        AsyncTask *task = nil;
        if(self.searchKeyModel.searchtype == easySrach )
            task = [[self getAppDelegate].httpRequestManager easySearchList:self.searchKeyModel activityType:@"L" offset:0 pageSize:200];
        else
            task = [[self getAppDelegate].httpRequestManager searchLcsdListByKeyword:self.searchKeyModel offset:0 pageSize:200];
        [task setFinishBlock:^{
            
            self.activityList = [task result];
            [self.calendarHeaderView setDate:self.currentDate];
            [self.lcsdTableView reloadData];
            [self.loadingView stopLoading];
            
            if (self.activityList.count>0) {
                self.lcsdTableView.hidden = NO;
                self.noActivityLabel.hidden = YES;
            }else{
                self.lcsdTableView.hidden = YES;
                self.noActivityLabel.hidden = NO;
                self.scrollImageView.hidden = YES;
            }
            [self.loadingView stopLoading];
            [self performSelector:@selector(resetScrollImageView) withObject:nil afterDelay:0.5];
            
            
        }];
        self.httpTask = task;
        
        return;
    }
    
    
    if (self.dateList==nil) {
        
        if (self.searchKeyModel.isAdSearch) {
            NSArray *list = [NSArray arrayWithObjects:@"1", nil];
            self.dateList = list;
            
            
            NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
            
            if (self.searchKeyModel.month==nil) {
                self.searchKeyModel.month = [dateFormatter stringFromDate:[NSDate date]];
            }
            
            self.currentDate = [dateFormatter dateFromString:self.searchKeyModel.month];
            
            [self.calendarHeaderView setDate:self.currentDate];
            [dateFormatter release];
            
            
            [self search];
            return;
        }
        
        AsyncTask *task = [[self getAppDelegate].httpRequestManager getDateList:self.searchKeyModel activityType:@"L"];
        [task setFinishBlock:^{
            self.dateList = [task result];
            NSLog(@"self.dateList.count  >>>>  %d", self.dateList.count);
            if (self.dateList.count>0) {
                
                unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
                NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
                
                
                NSString *dateStr = nil;
                dateFormatter.dateFormat = lang(@"yyyy-MM");
                NSDate *searchDate = [dateFormatter dateFromString:self.searchKeyModel.month];
                NSDateComponents *searchComp = [cal components:units fromDate:searchDate];
                
                NSDate *today = [NSDate date];
                NSDateComponents *todayComp = [cal components:units fromDate:today];
                
                if (searchComp.month!=todayComp.month) {
                    dateStr = [self.dateList objectAtIndex:0];
                }else{
                    dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
                    for (int i=0; i<self.dateList.count; i++) {
                        NSString *resultDateStr = [self.dateList objectAtIndex:i];
                        NSDate *resultDate = [dateFormatter dateFromString:resultDateStr];
                        NSDateComponents *resultComp = [cal components:units fromDate:resultDate];
                        if (resultComp.day >= todayComp.day) {
                            dateStr = [self.dateList objectAtIndex:i];
                            break;
                        }
                    }
                    
                    if (dateStr == nil) {
                        dateStr = [self.dateList objectAtIndex:self.dateList.count - 1];
                    }
                }
                
                
                dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
                self.currentDate = [dateFormatter dateFromString:dateStr];
                
                [self.calendarHeaderView setDate:self.currentDate];
                
                [dateFormatter release];
                self.searchKeyModel.month = dateStr;
                [cal release];
                [self search];
                
            }else{
                
                
                unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
                NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
                dateFormatter.dateFormat = lang(@"yyyy-MM");
                
                NSDate *searchDate = [dateFormatter dateFromString:self.searchKeyModel.month];
                NSDateComponents *searchComp = [cal components:units fromDate:searchDate];
                
                NSDate *today = [NSDate date];
                NSDateComponents *todayComp = [cal components:units fromDate:today];
                
                if (searchComp.month!=todayComp.month) {
                    dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
                    self.currentDate = [dateFormatter dateFromString:[NSString stringWithFormat:@"%@-01", self.searchKeyModel.month]];
                    DLog(@"self.currentDate  >>>   %@", self.currentDate);
                    [self.calendarHeaderView setDate:self.currentDate];
                    
                }
                [cal release];
                [dateFormatter release];
                
                
                self.lcsdTableView.hidden = YES;
                self.noActivityLabel.hidden = NO;
                self.scrollImageView.hidden = YES;
                [self.loadingView stopLoading];
            }
        }];
        self.httpTask = task;
    }else{
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = lang(@"yyyy-MM-dd");
        NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
        self.searchKeyModel.month = dateStr;
        
        [dateFormatter release];

        
        [self search];
    }
    
    
    
}


- (void)search{
    
    AsyncTask *task = [[self getAppDelegate].httpRequestManager searchLcsdList:self.searchKeyModel offset:0 pageSize:200];
    [task setFinishBlock:^{
        self.activityList = [task result];
        [self.lcsdTableView reloadData];
        [self.loadingView stopLoading];
        
        if (self.activityList.count>0) {
            self.lcsdTableView.hidden = NO;
            self.noActivityLabel.hidden = YES;
        }else{
            self.lcsdTableView.hidden = YES;
            self.noActivityLabel.hidden = NO;
            self.scrollImageView.hidden = YES;
        }
        [self.loadingView stopLoading];
        [self performSelector:@selector(resetScrollImageView) withObject:nil afterDelay:0.5];
    }];
    self.httpTask = task;
    
}

#pragma mark - UITableViewDataSource methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.activityList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *key = @"detailView";
    UITableViewCell *tmp = [tableView dequeueReusableCellWithIdentifier:key];
    ExpandTableViewCell *cell = nil;
    if (tmp!=nil && [tmp isKindOfClass:[ExpandTableViewCell class]]) {
        cell = (ExpandTableViewCell*)tmp;
    }else{
        cell = [[[ExpandTableViewCell alloc] initWithCellType:ExpandTableViewCellStyleLCSD reuseIdentifier:key] autorelease];
    }
    
    ElderlyNewActivityModel *activity = [self.activityList objectAtIndex:indexPath.row];
    
    [cell setExpandTitle:[ElderlyUtils text:activity key:@"title"]];
    [cell setType:[ElderlyUtils text:activity key:@"eventType"]];
    //[cell setDate:activity.activityDateArray];
    NSString *startDate = nil;
    if (activity.activityDateArray.count>0) {
        startDate = [activity.activityDateArray objectAtIndex:0];
    }
    [cell setStartDate:startDate endDate:activity.endDate];
    [cell setTimeFrom:activity.stratTime to:activity.endTime];
    [cell setPrice:[ElderlyUtils text:activity key:@"fee"]];
    if (activity.fee.length>0) {
        [cell setPlace:[ElderlyUtils text:activity key:@"activeArea"]];
        [cell hidPrice:NO];
    }else{
        [cell hidPrice:YES];
    }
    
    
    
    
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    ElderlyNewActivityModel *activity = [self.activityList objectAtIndex:indexPath.row];
    if (activity.fee.length>0) {
        return 140 - 16;
    }else{
        return 140 - 16 - 16;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ElderlyNewActivityModel *oneActivity = [self.activityList objectAtIndex:indexPath.row];
    
    if(self.searchKeyModel == nil){
        [self.loadingView startLoading];
    
        self.threadTask = [ThreadTask asyncStart:^{
        
            self.activityDetailModel = [[self getAppDelegate].databaseManager getMyActivityDetail:oneActivity.activityId activityType:@"L"];
            
        } end:^{
            
            ActivityDetailViewController *controller=[[ActivityDetailViewController alloc]init];
            //     controller.theBannerArray=[NSArray arrayWithArray:self.bannerArray];
            controller.theActivity=self.activityDetailModel;
            ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
            NSString *colorStr = theme.color;
            UIColor *color = [ElderlyUtils colorConvertFromString:colorStr];
            
            [self.navigationController pushViewController:controller animated:YES];
            [controller setTitleBackGroundColor:color];
            //[controller.theBannerArray release];
            // controller.theBannerArray=nil;
            [controller release];
            
            [self.loadingView stopLoading];
        }];
        
        
        
        return;
    }
    
    AsyncTask  *asyncTask = [[self getAppDelegate].httpRequestManager getActivityDetail:@"L" cativityId:oneActivity.activityId];
    [self.loadingView startLoading];
    [asyncTask setFinishBlock:^{
   

        ElderlyActivityDetailModel* detail = [asyncTask result];
        if(detail != nil){
            
            ActivityDetailViewController *controller=[[ActivityDetailViewController alloc]init];
            //     controller.theBannerArray=[NSArray arrayWithArray:self.bannerArray];
            controller.theActivity=detail;
            ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
            NSString *colorStr = theme.color;
            UIColor *color = [ElderlyUtils colorConvertFromString:colorStr];
            
            [self.navigationController pushViewController:controller animated:YES];
            [controller setTitleBackGroundColor:color];
            //[controller.theBannerArray release];
            // controller.theBannerArray=nil;
            [controller release];
            
        }
        [self.loadingView stopLoading];
    }];
    asyncTask=nil;
}

-(void)themeChanged{
    self.noActivityLabel.text = lang(@"noActivity");
    [self.lcsdTableView reloadData];
    [self.calendarHeaderView changeTheme];
    [self.calendarView themeChanged];
    if(self.monthView != nil){
        [self.monthView themeChanged];
    }
}

- (UINavigationController*)navigationController{
    NSLog(@"self.searchResultTabVC.navigationController  >>>  %@", self.searchResultTabVC.navigationController);
    return self.searchResultTabVC.navigationController;
}

- (void)resetScrollImageView{
    if (self.lcsdTableView.contentSize.height <= self.lcsdTableView.frame.size.height) {
        self.scrollImageView.hidden = YES;
    }else{
        self.scrollImageView.hidden = NO;
    }
}

@end
