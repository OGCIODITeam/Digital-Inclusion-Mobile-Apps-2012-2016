//
//  LocatorSearchViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LocatorSearchViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ButtonText.h"
#import "AreaPicker.h"
#import "ElderlyThemeGridModel.h"
#import "LocatorSearchResultViewController.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyUserModel.h"
#import "ElderlyAlertUtils.h"
#import "ElderlyNearBySearchKeyModel.h"
#import <CoreLocation/CoreLocation.h>
#import "ElderlySearchKeyModel.h"
#import "CenterSearchResultViewController.h"
#import "ElderlyGA.h"
#import "ElderlyAreaModel.h"
#import "ElderlyDatabaseManager.h"

 @interface LocatorSearchViewController ()<AreaPickerDelegate,CLLocationManagerDelegate>
-(void)btnSelect:(UIButton*)button;
-(void)setLocationSelected:(int)index;
-(void)comboxShowClick;
-(void)searchClick;
-(long)getSearchDistance;
-(void)initLocationManager;
@end

 @implementation LocatorSearchViewController

- (id)init{

    self = [super init];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
        
        distanceList=[[NSArray arrayWithObjects:lang(@"2_distance"),lang(@"4_distance"),lang(@"8_distance"), nil] retain];
        
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_SEARCHNEARBY];
 	[self initViews];
    // Do any additional setup after loading the view.
    [self initLocationManager];
    locationIndex=0;
    distanceIndex=0;

    titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(0.0f,30.0f, self.view.frame.size.width, 30.0f)];
    titleLabel.numberOfLines=1;
    titleLabel.textAlignment=NSTextAlignmentCenter;
    titleLabel.text=lang(@"pls_select_location");
    [titleLabel theme:@"locator_title"];
    ElderlyThemeGridModel* model = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    titleLabel.textColor = [ElderlyUtils colorConvertFromString:model.color];
    [self.view addSubview:titleLabel];
    [titleLabel release];
    
    
    
    UIImage* img=[[ElderlyThemeManager sharedInstance] imageByMotif:@"item_%@.png"];
    currentLocationButton=[UIButton buttonWithType:UIButtonTypeCustom];
    currentLocationButton.tag=0;
    [currentLocationButton addTarget:self action:@selector(btnSelect:) forControlEvents:UIControlEventTouchUpInside];
    [currentLocationButton setBackgroundImage:img forState:UIControlStateNormal];
    currentLocationButton.frame=CGRectMake((self.view.frame.size.width-img.size.width)*0.5f, 100.0f, img.size.width, img.size.height);
    [currentLocationButton setTitle:lang(@"my_current_location") forState:UIControlStateNormal];
    [currentLocationButton theme:@"locator_button"];
    [self.view addSubview:currentLocationButton];
    
    liveButton=[UIButton buttonWithType:UIButtonTypeCustom];
    liveButton.tag=1;
    [liveButton addTarget:self action:@selector(btnSelect:) forControlEvents:UIControlEventTouchUpInside];
    [liveButton setBackgroundImage:img forState:UIControlStateNormal];
    liveButton.frame=CGRectMake((self.view.frame.size.width-img.size.width)*0.5f, 154.0f, img.size.width, img.size.height);
    [liveButton setTitle:lang(@"my_live_location") forState:UIControlStateNormal];
    [liveButton theme:@"locator_button"];
    [self.view addSubview:liveButton];

    
    
    arrowImage=[[UIImageView alloc] initWithImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"item_tick_%@.png"]];
    CGRect rect=arrowImage.frame;
    rect.origin.x=35.0f;
    rect.origin.y=CGRectGetMinY(currentLocationButton.frame)+(currentLocationButton.frame.size.height-rect.size.height)*0.5f;
    arrowImage.frame=rect;
    [self.view addSubview:arrowImage];
    [arrowImage release];
    
    img=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"dropdown_distance.png"];

    selectedLabel=[[UILabel alloc] initWithFrame:CGRectMake(10.0f, 230.0f, 90.f, img.size.height)];
    selectedLabel.numberOfLines=1;
    selectedLabel.textAlignment=NSTextAlignmentRight;
    selectedLabel.text=lang(@"pls_select_distance");
    [selectedLabel theme:@"locator_title"];
    selectedLabel.textColor = [ElderlyUtils colorConvertFromString:model.color];
    [self.view addSubview:selectedLabel];
    [selectedLabel release];

    
    comboxButton=[[ButtonText alloc] initWithFrame:CGRectMake(self.view.frame.size.width-img.size.width-15.0f,230.0f, img.size.width, img.size.height)];
    [comboxButton addTarget:self action:@selector(comboxShowClick) forControlEvents:UIControlEventTouchUpInside];
    comboxButton.alignment=NSTextAlignmentLeft;
    comboxButton.spacing=12.0f;
    [comboxButton setImage:img forState:UIControlStateNormal];
    [comboxButton text:[distanceList objectAtIndex:distanceIndex]];
    [comboxButton theme:@"locator_combox"];
    [self.view addSubview:comboxButton];
    [comboxButton release];
    
    lineView=[[UIImageView alloc] initWithImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"search_line.png"]];
    [self.view addSubview:lineView];
    [lineView release];
    
    img=[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_%@.png"];

    searchButton=[[ButtonText alloc] initWithFrame:CGRectMake((self.view.frame.size.width-img.size.width)*0.5f,self.view.frame.size.height-img.size.height-20.0f, img.size.width, img.size.height)];
    searchButton.spacing=5.0f;
    [searchButton text:lang(@"search")];
    [searchButton theme:@"locator_search"];
    [searchButton addTarget:self action:@selector(searchClick) forControlEvents:UIControlEventTouchUpInside];
    [searchButton setBackgroundImage:img forState:UIControlStateNormal];
    [searchButton arrow:[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"icon_search_white.png"]];

    [self.view addSubview:searchButton];
    [searchButton release];
    
    rect=lineView.frame;
    rect.origin.y=CGRectGetMinY(searchButton.frame)-20.0f-rect.size.height;
    lineView.frame=rect;
 }

-(void)dealloc{
    [locationManager stopUpdatingLocation];
    [locationManager release];
    [distanceList release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"locator")];
    
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"locator")];
    
    [distanceList release];
    distanceList=[[NSArray arrayWithObjects:lang(@"2_distance"),lang(@"4_distance"),lang(@"8_distance"), nil] retain];
    [comboxButton text:[distanceList objectAtIndex:distanceIndex]];

    titleLabel.text=lang(@"pls_select_location");
    [titleLabel theme:@"locator_title"];
    
    ElderlyThemeGridModel* model = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    titleLabel.textColor = [ElderlyUtils colorConvertFromString:model.color];
    
    [currentLocationButton setTitle:lang(@"my_current_location") forState:UIControlStateNormal];
    [currentLocationButton theme:@"locator_button"];
    
    [liveButton setTitle:lang(@"my_live_location") forState:UIControlStateNormal];
    [liveButton theme:@"locator_button"];
    
    selectedLabel.text=lang(@"pls_select_distance");
    [selectedLabel theme:@"locator_title"];
    selectedLabel.textColor = [ElderlyUtils colorConvertFromString:model.color];
    
    
    [comboxButton theme:@"locator_combox"];
    
    [searchButton theme:@"locator_search"];
    [searchButton text:lang(@"search")];
    [searchButton setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_%@.png"] forState:UIControlStateNormal];
    
    arrowImage.image = [[ElderlyThemeManager sharedInstance] imageByMotif:@"item_tick_%@.png"];
    UIImage* image = [[ElderlyThemeManager sharedInstance] imageByMotif:@"item_%@.png"];
    [currentLocationButton setBackgroundImage:image forState:UIControlStateNormal];
    [liveButton setBackgroundImage:image forState:UIControlStateNormal];
    
    picker = (AreaPicker*)[self.view viewWithTag:1001];
    if(picker != nil){
        picker.list = distanceList;
        [picker themeChanged];
    }

}

-(void)initLocationManager{

    if (locationManager == nil) {
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest; // 越精确，越耗电！
    }
    [locationManager startUpdatingLocation];

}

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [[self getAppDelegate].rootController back];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

 -(void)initViews{
 
}


 #pragma mark method

-(void)btnSelect:(UIButton*)button{
    [self setLocationSelected:button.tag];
}

-(void)setLocationSelected:(int)index{

    [locationManager stopUpdatingLocation];
    if(index == 1){
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_LIVINGLOCATIONBUTTON];
        NSString* region = [self getAppDelegate].profileSettingManager.userModel.region;
        if(region == nil || region.length < 1){
            [ElderlyAlertUtils showAlert:lang(@"regionCueMsg2") delegate:nil];
            return ;
        }
    }
    else {
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_CURRENTLOCATIONBUTTON];
        [locationManager startUpdatingLocation];
        
    }
    
    
    locationIndex=index;
    CGRect parentFrame=(index==0?currentLocationButton.frame:liveButton.frame);
    CGRect rect=arrowImage.frame;
        
    rect.origin.y=CGRectGetMinY(parentFrame)+(parentFrame.size.height-rect.size.height)*0.5f;
    arrowImage.frame=rect;
}

-(void)comboxShowClick{
    picker=[[AreaPicker alloc] init];
    picker.blackPanelFrame=CGRectMake(0.0f, 0, self.view.frame.size.width, self.view.frame.size.height);
    picker.tag = 1001;
    picker.delegate=self;
    picker.list=distanceList;
    [picker showInView:self.view];
    [picker release];
}

-(void)searchClick{
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_SELECTDISTANCEBUTTON];
    
    if(![ElderlyUtils checkNetWork]){
        [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
        return;
    }
    
    if(locationIndex == 1){
    
        ElderlySearchKeyModel* searchKeyModel = [[ElderlySearchKeyModel alloc] init];
        ElderlyAreaModel* areaModel = [[self getAppDelegate].databaseManager getAreaModelForName:[self getAppDelegate].profileSettingManager.userModel.region];
        searchKeyModel.activeArea = areaModel.value;
        
        NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM"];
        searchKeyModel.month = [formatter stringFromDate:[NSDate date]];
        [formatter release];
        searchKeyModel.searchtype = locationSearch;
        
        LocatorSearchResultViewController* controller=[[LocatorSearchResultViewController alloc] init];
        controller.searchKeyModel = searchKeyModel;
        controller.navTitle = @"nearby_search_result";
        [self.navigationController pushViewController:controller animated:YES];
        [controller release];
        
        [searchKeyModel release];
    
    }
    else if(locationIndex == 0){
    
        ElderlyNearBySearchKeyModel* nearBySearchKeyModel = [[ElderlyNearBySearchKeyModel alloc] init];
        nearBySearchKeyModel.searchDistance = [self getSearchDistance];
        nearBySearchKeyModel.latitude = latitude;
        nearBySearchKeyModel.longitude = longitude;
//        nearBySearchKeyModel.latitude = 22.311212;
//        nearBySearchKeyModel.longitude = 114.222486;
        
        NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM"];
        nearBySearchKeyModel.date = [formatter stringFromDate:[NSDate date]];
        [formatter release];
   
        CenterSearchResultViewController *vc = [[CenterSearchResultViewController alloc] init];
        vc.nearBySearchKeyModel = nearBySearchKeyModel;
        vc.navTitle = @"nearby_search_result";
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
        
//        LocatorSearchResultViewController* controller=[[LocatorSearchResultViewController alloc] init];
//        [self.navigationController pushViewController:controller animated:YES];
//        [controller release];
        
        [nearBySearchKeyModel release];
    }
    
 
}

-(long)getSearchDistance{

    long distance = 2000;
    if(distanceIndex == 1){
        distance = 4000;
    }
    else if(distanceIndex == 2){
        distance = 8000;
    }

    return distance;
}

#pragma mark area picker delegate

-(void)didClickAreaPicker:(AreaPicker*)_picker confirm:(BOOL)confirm{
    if(confirm){
        distanceIndex=_picker.selectedIndex;
        [comboxButton text:[distanceList objectAtIndex:distanceIndex]];
    }
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSString* errorMsg = nil;
    switch (error.code) {
        case kCLErrorLocationUnknown:
            errorMsg = lang(@"GPS_erroe_locationUnknown");
            break;
        case kCLErrorDenied:
            errorMsg = lang(@"GPS_error_denied");
            break;
        case kCLErrorNetwork:
            errorMsg = lang(@"GPS_erroe_locationUnknown");
            break;
        default:
            errorMsg = lang(@"GPS_erroe_locationUnknown");
            break;
    }
    
    if (errorMsg != nil) {
        [ElderlyAlertUtils showAlert:errorMsg delegate:nil];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    DLog(@"oldLocation.coordinate.timestamp:%@", oldLocation.timestamp);
    DLog(@"oldLocation.coordinate.longitude:%f", oldLocation.coordinate.longitude);
    DLog(@"oldLocation.coordinate.latitude:%f", oldLocation.coordinate.latitude);
    DLog(@"newLocation.coordinate.timestamp:%@", newLocation.timestamp);
    DLog(@"newLocation.coordinate.longitude:%f", newLocation.coordinate.longitude);
    DLog(@"newLocation.coordinate.latitude:%f", newLocation.coordinate.latitude);
    NSTimeInterval interval = [newLocation.timestamp timeIntervalSinceDate:oldLocation.timestamp];
    NSLog(@"%lf", interval);
    // 取到精确GPS位置后停止更新
    if (interval < 3) {
        // 停止更新
        [locationManager stopUpdatingLocation];
    }
//    latitudeLabel.text = [NSString stringWithFormat:@"%f", newLocation.coordinate.latitude];
//    longitudeLabel.text = [NSString stringWithFormat:@"%f", newLocation.coordinate.longitude];
    
    longitude = newLocation.coordinate.longitude;
    latitude = newLocation.coordinate.latitude;
}

 @end
