//
//  LCSDView.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LCSDView.h"

@implementation LCSDView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
