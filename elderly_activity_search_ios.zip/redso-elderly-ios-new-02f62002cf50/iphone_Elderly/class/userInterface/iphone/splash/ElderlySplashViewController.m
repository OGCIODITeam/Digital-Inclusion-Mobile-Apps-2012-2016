//
//  ElderlySplashViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlySplashViewController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "AsyncTask.h"
#import "ElderlyHTTPRequestManager.h"
#import "ElderlyVersionModel.h"
#import "ElderlyAlertUtils.h"
#import "ApiError.h"
#import "LoadingView.h"
#import "ElderlyUtils.h"
#import "MediaPlayer/MediaPlayer.h"
#import "ElderlyGA.h"

@interface ElderlySplashViewController ()<UIAlertViewDelegate>

-(void)checkVersion;
@end

@implementation ElderlySplashViewController



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    

    NSString* videoPath = [[NSBundle mainBundle] pathForResource:@"SAGE_Splash_video" ofType:@"mp4"];
    moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:videoPath]];
    isMoviePlayer = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieFinish) name:
     MPMoviePlayerPlaybackDidFinishNotification object:nil];
    moviePlayer.scalingMode=MPMovieScalingModeAspectFill;
    moviePlayer.view.frame = self.view.bounds;
    [moviePlayer setControlStyle:MPMovieControlStyleNone];

    [moviePlayer prepareToPlay];
    [self performSelector:@selector(afterAddMoviePlayer) withObject:nil afterDelay:0.1];
    
    [self checkVersion];
    
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_SPLASHSCREEN];
    
}

-(void)afterAddMoviePlayer{
    
    [moviePlayer play];
    [self.view addSubview:moviePlayer.view];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc{
    [moviePlayer release];
    [link release];
    [asyncTask cancel];
    [super dealloc];
}

-(void)movieFinish{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    isMoviePlayer = NO;
    
    [self goMainPage];
}


-(void)goMainPage{

    if(ischeckVersion || isMoviePlayer)
        return;
    
    
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [appDelegate clearSplashAndCreateMainPage];

}


-(void)checkVersion{
    ischeckVersion = YES;
    [asyncTask cancel];
    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    asyncTask = [appDelegate.httpRequestManager checkElderlyVersion];

    [asyncTask setFinishBlock:^{
    
        ElderlyVersionModel* info=[asyncTask result];
        asyncTask=nil;
        if(info != nil){
        
            NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];
            
            float currentNum=[[APP_VERSION stringByReplacingOccurrencesOfString:@"." withString:@""] floatValue];
            float serverCurrentNum=[[info.versionNum stringByReplacingOccurrencesOfString:@"." withString:@""] floatValue];
            
            if(serverCurrentNum>currentNum){
               
                UIAlertView* alertView = [ElderlyAlertUtils showAlert:lang(@"Elderly") message:lang(@"updateAppMessage") button:lang(@"update") cancelButton:lang(@"cancel") delegate:self];
                alertView.tag = 1001;
                
                [link release];
                link = [info.link retain];
            }
            else{
                ischeckVersion = NO;
                [self goMainPage];
            }
            [pool release];
        }
        else{
            ischeckVersion = NO;
            [self goMainPage];
        }
        
    }];

}

#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{

    if(alertView.tag == 1001){
        if(buttonIndex==1){
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:link]];
            exit(0);
        }
        else{
            AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
            [appDelegate clearSplashAndCreateMainPage];
        }
        [link release];
        link=nil;
    }
    else if(alertView.tag == 1004){
        [self checkVersion];
    }
   
}

@end
