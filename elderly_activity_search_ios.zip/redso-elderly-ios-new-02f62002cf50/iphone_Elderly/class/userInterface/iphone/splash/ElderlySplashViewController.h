//
//  ElderlySplashViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-6.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ElderlyIphoneViewController.h"

@class AsyncTask;
@class LoadingView;
@class MPMoviePlayerController;
@interface ElderlySplashViewController : ElderlyIphoneViewController{

    AsyncTask* asyncTask;
    
    NSString* link;
    BOOL ischeckVersion;

    MPMoviePlayerController *moviePlayer;

    BOOL isMoviePlayer;
}

@end
