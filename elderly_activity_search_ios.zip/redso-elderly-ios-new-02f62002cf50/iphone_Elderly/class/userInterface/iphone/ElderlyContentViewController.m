//
//  ElderlyContentViewController.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-30.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"

@interface ElderlyContentViewController ()

@end

@implementation ElderlyContentViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    CGRect rect=self.view.frame;
    rect.size.height-=44.0f;
    self.view.frame=rect;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
