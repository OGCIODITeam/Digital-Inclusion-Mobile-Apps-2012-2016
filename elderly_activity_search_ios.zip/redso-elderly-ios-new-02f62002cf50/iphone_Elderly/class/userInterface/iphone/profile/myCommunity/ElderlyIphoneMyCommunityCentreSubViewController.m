//
//  ElderlyIphoneMyCommunityCentreSubViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyCommunityCentreSubViewController.h"
#import "AppDelegate.h"
#import "ElderlyNavigationController.h"
#import "ElderlyRootViewController.h"
#import "MyCommunityCentre.h"
#import "ElderlyThemeManager.h"
#import "AreaPicker.h"
#import "ButtonText.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyUserModel.h"
#import "ElderlyIphoneMyCommunityCentreTableViewController.h"
#import "ElderlyHTTPRequestManager.h"
#import "AsyncTask.h"
#import "LoadingView.h"
#import "ElderlyAlertUtils.h"
#import "ApiError.h"
#import "ElderlyAreaModel.h"


@interface ElderlyIphoneMyCommunityCentreSubViewController ()<AreaPickerDelegate>

@property(nonatomic,retain)ElderlyAreaModel* areaModel;
@property(nonatomic,retain)ElderlyAreaModel* regionModel;

-(void)initMyCommunityCentreView;
-(void)initSearchButton;
-(void)initPickView;
-(void)initRegionPicker:(BOOL)isClickRegion;

@end

@implementation ElderlyIphoneMyCommunityCentreSubViewController
@synthesize myCommunityCentreIndex;
@synthesize dic;
@synthesize areaModel;
@synthesize regionModel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self initMyCommunityCentreView];
    [self initSearchButton];
    
    loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview: loadingView];
    [loadingView release];
    
    [self initPickView];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myCommunity")];
    
}

- (void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myCommunity")];

    [searchButton text:lang(@"search")];
    [searchButton theme:@"okButton_title"];
    [areaView theme:@"myCommunityCentreSubView_title"];
    [regionView theme:@"myCommunityCentreSubView_title"];
    
    
    if(self.areaModel != nil){
        [areaView setTitle:[ElderlyUtils text:self.areaModel key:@"name"]];
        [areaView sethighlight:YES];
    }
    else{
        [areaView setTitle:lang(@"inputArea")];
    }
    
    if(self.regionModel != nil){
        [regionView setTitle:[ElderlyUtils text:self.regionModel key:@"name"]];
        [regionView sethighlight:YES];
    }
    else{
        [regionView setTitle:lang(@"inputRegion")];
    }
    
    areaPicker = (AreaPicker*)[self.view viewWithTag:1003];
    if(areaPicker != nil){
        areaPicker.list=[[self getAppDelegate].databaseManager getAreaNameArray];
        [areaPicker themeChanged];
    }
    
    regionPicker = (AreaPicker*)[self.view viewWithTag:1004];
    if(regionPicker != nil){
        NSArray* regionList = [[self getAppDelegate].databaseManager getRegionName:[areaView getTitle]];
        regionPicker.list = regionList;
        [regionPicker themeChanged];
    }
    
    
}


- (void)dealloc
{
    [asyncTask cancel];
    self.regionModel = nil;
    self.areaModel = nil;
    self.dic = nil;
    [super dealloc];
}


#pragma mark init View

-(void)initMyCommunityCentreView{
    
    UIImage* img =  [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_input.png"];
    areaView = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 25, img.size.width, img.size.height) bgImage: img];
    [areaView setTitle:lang(@"inputArea")];
    [areaView theme:@"myCommunityCentreSubView_title"];
    areaView.tag = 1001;
    [areaView addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:areaView];
    [areaView release];
    
    
    regionView = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(areaView.frame)+20,  img.size.width, img.size.height) bgImage: img];
    [regionView setTitle:lang(@"inputRegion")];
    [regionView theme:@"myCommunityCentreSubView_title"];
    regionView.tag = 1002;
    [regionView addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:regionView];
    [regionView release];
    
}

-(void)initSearchButton{
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_ok_cyan.png"];
    
    searchButton = [[ButtonText alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f,self.view.bounds.size.height- img.size.height*4, img.size.width, img.size.height)];
    [searchButton setBackgroundImage:img forState:UIControlStateNormal];
    searchButton.spacing = 5.0f;
    [searchButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_search_white.png"]];
    [searchButton text:lang(@"search")];
    [searchButton theme:@"okButton_title"];
    [searchButton addTarget:self action:@selector(selectOKButton) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:searchButton];
    [searchButton release];
}

-(void)initPickView{

    areaPicker = [[AreaPicker alloc] init];
    areaPicker.tag = 1003;
    areaPicker.list=[[self getAppDelegate].databaseManager  getAreaNameArray];
    areaPicker.blackPanelFrame=CGRectMake(0.0f, 70.0f, 320.0f, self.view.frame.size.height-70.0f);
    areaPicker.delegate = self;
//    [areaPicker cancelImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cancel.png"] comfirmImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_sure.png"]];
//    [areaPicker selectedView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"setting_area_on.png"] ];
    [areaPicker showInView:self.view];
    [areaPicker release];

}

-(void)initRegionPicker:(BOOL)isClickRegion{

    
    NSArray* regionList = [[self getAppDelegate].databaseManager getRegionName:[areaView getTitle]];
    if(regionList == nil || regionList.count < 1){
        
        [ElderlyAlertUtils showAlert:lang(@"regionCueMsg") delegate:nil];
        return;
    }
    
    regionPicker = [[AreaPicker alloc] init];
    regionPicker.tag = 1004;
    regionPicker.list=regionList;
    regionPicker.blackPanelFrame=CGRectMake(0.0f, 132.0f, 320.0f, self.view.frame.size.height-132.0f);
//    [regionPicker cancelImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cancel.png"] comfirmImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_sure.png"]];
//    [regionPicker selectedView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"setting_area_on.png"] ];
    regionPicker.delegate = self;
    regionPicker.animationIsRun = YES;
    if(isClickRegion){

        [regionPicker showInView:self.view];

    }
    else{
        [regionPicker showInView:self.view originFrame:CGRectMake(0.0f, 70.0f, 320.0f, self.view.frame.size.height-70.0f) destionFrame:CGRectMake(0.0f, 132.0f, 320.0f, self.view.frame.size.height-132.0f)];
        }
    [regionPicker release];
}

#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)selectMyCommunityCentreView:(id)sender{
    
    NSLog(@"selectMyCommunityCentreView");
    MyCommunityCentre* mycommunityCenter = (MyCommunityCentre*)sender;

    if(mycommunityCenter.tag == 1001){
        [self initPickView];
    }
    else if(mycommunityCenter.tag == 1002){
        [self initRegionPicker:YES];
    }
}

-(void)selectOKButton{
    
    if(self.regionModel == nil){
        [ElderlyAlertUtils showAlert:lang(@"regionCueMsg2") cancelButton:lang(@"confirm") delegate:nil];
        return ;
    }
    
    [loadingView startLoading];
    asyncTask = [[self getAppDelegate].httpRequestManager getMyCommunityCentreList:self.regionModel.name_tc offset:0 pageSize:20];
    [asyncTask setFinishBlock:^{
    
        NSArray* list=[asyncTask result];
        [loadingView stopLoading];
        if(list != nil){
            
            if(list.count < 1){
                
                
                [ElderlyAlertUtils showAlert:lang(@"myCommunity2") delegate:nil];
                asyncTask=nil;
                return ;
            }
        
            ElderlyIphoneMyCommunityCentreTableViewController* tableViewController = [[ElderlyIphoneMyCommunityCentreTableViewController alloc] init];
            tableViewController.selectMyCommunityCentreIndex = self.myCommunityCentreIndex;
            tableViewController.dic = self.dic;
            tableViewController.dataArray = list;
            tableViewController.searchKey = self.regionModel.name_tc;
            [self.navigationController pushViewController:tableViewController animated:YES];
            [tableViewController release];
        
        }
        else{
            [ElderlyAlertUtils showAlert:[[asyncTask error] errorMessage] cancelButton:lang(@"confirm") delegate:nil];
        }
        
        asyncTask=nil;
    
    }];
    
    


}



#pragma mark picker Delegate 
-(void)didClickAreaPicker:(AreaPicker*)picker confirm:(BOOL)confirm{

    
    if(picker.tag == 1003){
    
        if(confirm){

            NSString* area = [picker.list objectAtIndex:picker.selectedIndex];
            [areaView sethighlight:YES];
            [areaView setTitle:area];
            self.areaModel = [[self getAppDelegate].databaseManager getAreaModelForName:area];
            
            self.regionModel = nil;
            
            [regionView sethighlight:NO];
            [regionView setTitle:lang(@"inputRegion")];

            [self initRegionPicker:NO];
        }
        else {
           // [self navigationLeftClick];
        }
        
    }
    else if(picker.tag == 1004){
        if(confirm){

            NSString* region = [picker.list objectAtIndex:picker.selectedIndex];
            [regionView sethighlight:YES];
            [regionView setTitle:region];
            self.regionModel = [[self getAppDelegate].databaseManager getAreaModelForName:region];
            
        }
        else {
           // [self navigationLeftClick];
        }

    }
}



@end
