//
//  ElderlyIphoneMyCommunityCentreViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneViewController.h"

@class MyCommunityCentre;
@class ButtonText;
@class GuideView;
@interface ElderlyIphoneMyCommunityCentreViewController : ElderlyIphoneViewController{

    MyCommunityCentre* myCommunityCentreView_first;
    MyCommunityCentre* myCommunityCentreView_second;
    MyCommunityCentre* myCommunityCentreView_thrid;
    
    ButtonText* okButton;
    GuideView* guideView;
    
    NSMutableDictionary* dic;
    
    NSString* imageName;

}

@end
