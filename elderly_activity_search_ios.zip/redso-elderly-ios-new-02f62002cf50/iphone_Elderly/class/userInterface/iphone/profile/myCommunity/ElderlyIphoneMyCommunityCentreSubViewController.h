//
//  ElderlyIphoneMyCommunityCentreSubViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"

@class MyCommunityCentre;
@class AreaPicker;
@class ButtonText;
@class AsyncTask;
@class LoadingView;
@interface ElderlyIphoneMyCommunityCentreSubViewController : ElderlyContentViewController{

    MyCommunityCentre* areaView;
    MyCommunityCentre* regionView;
    
    AreaPicker* areaPicker;
    AreaPicker* regionPicker;

    ButtonText* searchButton;

    AsyncTask* asyncTask;
    
    LoadingView* loadingView;
    
}

@property(nonatomic,assign)NSInteger myCommunityCentreIndex;
@property(nonatomic,retain)NSMutableDictionary* dic;


@end
