//
//  ElderlyIphoneMyCommunityCentreTableViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-3.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyCommunityCentreTableViewController.h"
#import "ElderlyNavigationController.h"
#import "ButtonText.h"
#import "ElderlyGuideMannager.h"
#import "GuideView.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyTableCell.h"
#import "ElderlyMyCommunityCentreModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyUserModel.h"
#import "ElderlyHTTPRequestManager.h"
#import "AsyncTask.h"
#import "ElderlyAlertUtils.h"


@interface ElderlyIphoneMyCommunityCentreTableViewController ()<UITableViewDataSource,UITableViewDelegate>


-(void)loadMycommunityCentreData;
-(void)createTableFooter:(BOOL)isMore;

@end

@implementation ElderlyIphoneMyCommunityCentreTableViewController

@synthesize selectMyCommunityCentreIndex;
@synthesize dic;
@synthesize dataArray;
@synthesize searchKey;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    offset = 0;

    tableViewDateArray = [[NSMutableArray alloc] init];
    [tableViewDateArray addObjectsFromArray:self.dataArray];
    
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_ok.png"];
    myCommunityCentreTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - img.size.height-44)];
    //[myInterestTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    myCommunityCentreTableView.showsVerticalScrollIndicator = NO;
    [myCommunityCentreTableView setDataSource:self];
    [myCommunityCentreTableView setDelegate:self];
    [self.view addSubview:myCommunityCentreTableView];
    [myCommunityCentreTableView release];
    
    
    UIImage* image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
    scrollImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, myCommunityCentreTableView.frame.size.height - image.size.height, image.size.width, image.size.height)];
    scrollImageView.image = image;
    [self.view addSubview:scrollImageView];
    [scrollImageView release];
    
    
    UIImageView* buttomBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - img.size.height-44, img.size.width, img.size.height)];
    buttomBgView.image = img;
    buttomBgView.userInteractionEnabled = YES;
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_ok_cyan.png"];
    
    okButton = [[ButtonText alloc] initWithFrame:CGRectMake((buttomBgView.bounds.size.width - img.size.width)*0.5f,(buttomBgView.bounds.size.height - img.size.height)*0.5f, img.size.width, img.size.height)];
    okButton.spacing=5.0f;
    [okButton setBackgroundImage:img forState:UIControlStateNormal];
    [okButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_sure.png"]];
    [okButton text:lang(@"confirm")];
    [okButton theme:@"okButton_title"];
    [okButton addTarget:self action:@selector(selectOKButton) forControlEvents:UIControlEventTouchUpInside];
    
    [buttomBgView addSubview:okButton];
    [okButton release];
    
    [self.view addSubview:buttomBgView];
    [buttomBgView release];
    
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:myInterestListGuide]){
        
        guideView = [[GuideView alloc] initWithFrame:self.view.bounds];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide10_%@.png"]];
        [guideView setGuideOrignY:0];
        guideView.tag = 999;
        [guideView addTarget:self action:@selector(clickGuideView) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:guideView];
        [guideView release];
    }
    
    [self createTableFooter:([tableViewDateArray count] >= loadCount)];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [asyncTask cancel];
    self.searchKey = nil;
    self.dic = nil;
    self.dataArray = nil;
    [tableViewDateArray release];
    [selectIndexPath release];
    [super dealloc];
}

-(void)willShowViewController{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myCommunity")];
    
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav themeChanged];
    
    
    [okButton text:lang(@"confirm")];
    [okButton theme:@"okButton_title"];
    if(loadMoreText != nil && myCommunityCentreTableView.tableFooterView != nil){
        [loadMoreText setText:lang(@"showmore")];
        [loadMoreText theme:@"showmore_title"];
    }

    [myCommunityCentreTableView reloadData];
    
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:myInterestListGuide] && guideView != nil){
        [guideView removeAllSubView];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide10_%@.png"]];
    }
    
}

-(void)createTableFooter:(BOOL)isMore{
    
    myCommunityCentreTableView.tableFooterView=nil;
    loadMoreText = nil;
    if(isMore){
        
        UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, myCommunityCentreTableView.bounds.size.width, 40)];
        loadMoreText = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 200, 40.0f)];
        [loadMoreText setCenter:tableFooterView.center];
        [loadMoreText setText:lang(@"showmore")];
        [loadMoreText theme:@"showmore_title"];
        loadMoreText.textAlignment = UITextAlignmentCenter;
        [tableFooterView addSubview:loadMoreText];
        
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(moreClicked)];
        
        [tableFooterView addGestureRecognizer:singleTap];
        [singleTap release];
        
        myCommunityCentreTableView.tableFooterView = tableFooterView;
        
        [loadMoreText release];
        [tableFooterView release];
    }
    else{
        UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, myCommunityCentreTableView.bounds.size.width, scrollImageView.frame.size.height)];
        tableFooterView.backgroundColor = [UIColor clearColor];
        myCommunityCentreTableView.tableFooterView = tableFooterView;
        [tableFooterView release];
        loadingMore = YES;
    }
}



#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)clickGuideView{
    NSLog(@"clickGuideView");
    
    guideView = (GuideView*)[self.view viewWithTag:999];
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        guideView.alpha=0.0f;
    } completion:^(BOOL finish){
        [guideView removeFromSuperview];
        
    }];
    
    [[ElderlyGuideMannager sharedInstance] setGudieState:myInterestListGuide state:NO];
    
}

-(void)selectOKButton{
    
    if(selectIndexPath != nil){
        
        ElderlyMyCommunityCentreModel* selectModel =[tableViewDateArray objectAtIndex:selectIndexPath.row];
        NSArray* allKeys = [self.dic allKeys];
        BOOL add = YES;
        for(NSString* key in allKeys){
        
            ElderlyMyCommunityCentreModel* model = [self.dic objectForKey:key];
            if([selectModel.vid isEqualToString:model.vid]){
                add = NO;
                break;
            }
        
        }
        
        if(add)
            [self.dic setObject:[tableViewDateArray objectAtIndex:selectIndexPath.row] forKey:[NSString stringWithFormat:@"%d",self.selectMyCommunityCentreIndex]];
        else{
        
            [ElderlyAlertUtils showAlert:lang(@"addedMyCommunityCentre") delegate:nil];
            return;
        }
    }
    
    
    NSMutableArray* viewsArray = [NSMutableArray arrayWithArray:[self.navigationController viewControllers]];
    [viewsArray removeObjectAtIndex:[viewsArray count]-2];
    [self.navigationController setViewControllers:[NSArray arrayWithArray:viewsArray]];
    [self.navigationController popViewControllerAnimated:YES];
}


- (void) loadDataBegin{

    if (loadingMore == NO)
    {
        loadingMore = YES;
        UIActivityIndicatorView *tableFooterActivityIndicator = [[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(40.0f, 10.0f, 20.0f, 20.0f)] autorelease];
        [tableFooterActivityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
        [tableFooterActivityIndicator startAnimating];
        [myCommunityCentreTableView.tableFooterView addSubview:tableFooterActivityIndicator];
        [self loadMycommunityCentreData];
        
    }
}



#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return tableViewDateArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    ElderlyTableCell* cell = (ElderlyTableCell*)[self tableView:tableView cellForRowAtIndexPath:indexPath];

    return [cell getCellHeight];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifier = @"Cell";
    ElderlyTableCell* cell = [ myCommunityCentreTableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil){
        cell = [[[ElderlyTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        [cell setSelectImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_add_chosen_%@.png"] ];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
    }
    
    [cell selectItem:NO];
    if(selectIndexPath != nil){
    
        if(indexPath.row == selectIndexPath.row){
            [cell selectItem:YES];
        }
    
    }

    ElderlyMyCommunityCentreModel* model = [tableViewDateArray objectAtIndex:indexPath.row];
    
    [cell setTitle:(model.organizationValue.length < 1?@"":[ElderlyUtils text:model key:@"organizationValue"])];
//    if(model.organizationValue.length > 1)
    [cell setSubHeadTitle:[ElderlyUtils text:model key:@"centreValue"]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"didSelectRowAtIndexPath");
    
    ElderlyTableCell* cell = (ElderlyTableCell*)[myCommunityCentreTableView cellForRowAtIndexPath:indexPath];
    [cell selectItem:YES];
    
    [selectIndexPath release];
    selectIndexPath = [indexPath retain];

    [myCommunityCentreTableView reloadData];

}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if(scrollView.contentOffset.y <= 0){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
        
    }
    else if(scrollView.contentOffset.y>=scrollView.contentSize.height-scrollView.frame.size.height){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll_up.png"];
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    // 下拉到最底部时显示更多数据
	if(!loadingMore && scrollView.contentOffset.y > ((scrollView.contentSize.height - scrollView.frame.size.height)))
	{
        [self loadDataBegin];
	}
}

-(void)loadMycommunityCentreData{

    offset+=loadCount;
    asyncTask = [[self getAppDelegate].httpRequestManager getMyCommunityCentreList:self.searchKey offset:offset pageSize:loadCount];
    [asyncTask setFinishBlock:^{
        myCommunityCentreTableView.tableFooterView=nil;
        loadMoreText = nil;
        NSArray* list=[asyncTask result];
        loadingMore = NO;
        if(list != nil){
            
            [self createTableFooter:(list.count >= loadCount)];
            [tableViewDateArray addObjectsFromArray:list];
            [myCommunityCentreTableView reloadData];
            
        }
        else{
             offset-=loadCount;
        }
        
        asyncTask=nil;
        
    }];

}



@end
