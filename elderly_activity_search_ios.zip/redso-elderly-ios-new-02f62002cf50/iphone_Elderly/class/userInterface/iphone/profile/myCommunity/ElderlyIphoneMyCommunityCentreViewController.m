//
//  ElderlyIphoneMyCommunityCentreViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyCommunityCentreViewController.h"
#import "AppDelegate.h"
#import "ElderlyNavigationController.h"
#import "ElderlyRootViewController.h"
#import "MyCommunityCentre.h"
#import "ElderlyThemeManager.h"
#import "ElderlyIphoneMyCommunityCentreSubViewController.h"
#import "ButtonText.h"
#import "ElderlyGuideMannager.h"
#import "GuideView.h"
#import "ElderlyUserModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyMyCommunityCentreModel.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyUtils.h"

@interface ElderlyIphoneMyCommunityCentreViewController ()

-(void)initMyCommunityCentreView;
-(void)initOKButton;
-(void)checkGuideState;
-(void)getMyCommunityCentreData;

@end

@implementation ElderlyIphoneMyCommunityCentreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    imageName = nil;
    
    if(dic == nil){
        dic = [[NSMutableDictionary alloc] init];
        [[self getAppDelegate].databaseManager getMyCommuntiyCentre:dic];
    }


    
    [self initMyCommunityCentreView];
    [self initOKButton];
    
    guideView = [[GuideView alloc] initWithFrame:self.view.bounds];
    guideView.tag = 888;
    [guideView addTarget:self action:@selector(clickGuideView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:guideView];
    [guideView release];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [imageName release];
    [dic release];
    [super dealloc];
}


-(void)willShowViewController{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myCommunity")];
    [self checkGuideState];
    
    [self getMyCommunityCentreData];
    
    
    
    
}

-(void)themeChanged{

    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav themeChanged];
    [okButton text:lang(@"confirm")];
    [okButton theme:@"okButton_title"];
    [myCommunityCentreView_second theme:@"myCommunityCentre_title"];
    [myCommunityCentreView_first theme:@"myCommunityCentre_title"];
    [myCommunityCentreView_thrid theme:@"myCommunityCentre_title"];
    [myCommunityCentreView_first setTitle:lang(@"selectMyCommunity")];
    [myCommunityCentreView_second setTitle:lang(@"selectMyCommunity")];
    [myCommunityCentreView_thrid setTitle:lang(@"selectMyCommunity")];

    
    if(guideView != nil && imageName != nil){
    
        [guideView removeAllSubView];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:imageName]];
    }
}

#pragma mark init View

-(void)initMyCommunityCentreView{
    
    UIImage* img =  [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_choose.png"];
    myCommunityCentreView_first = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 30,  img.size.width, img.size.height) bgImage: img];
    [myCommunityCentreView_first setTitle:lang(@"selectMyCommunity")];
    [myCommunityCentreView_first theme:@"myCommunityCentre_title"];
    myCommunityCentreView_first.tag = 1001;
    [myCommunityCentreView_first addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:myCommunityCentreView_first];
    [myCommunityCentreView_first release];
    
    
    myCommunityCentreView_second = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(myCommunityCentreView_first.frame)+10,  img.size.width, img.size.height) bgImage: img];
    [myCommunityCentreView_second setTitle:lang(@"selectMyCommunity")];
    [myCommunityCentreView_second theme:@"myCommunityCentre_title"];
    myCommunityCentreView_second.tag = 1002;
    [myCommunityCentreView_second addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:myCommunityCentreView_second];
    [myCommunityCentreView_second release];
    
    
    myCommunityCentreView_thrid = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(myCommunityCentreView_second.frame)+10,  img.size.width, img.size.height) bgImage: img];
    [myCommunityCentreView_thrid setTitle:lang(@"selectMyCommunity")];
    [myCommunityCentreView_thrid theme:@"myCommunityCentre_title"];
    myCommunityCentreView_thrid.tag = 1003;
    [myCommunityCentreView_thrid addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:myCommunityCentreView_thrid];
    [myCommunityCentreView_thrid release];
    
}

-(void)initOKButton{
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_ok_cyan.png"];
    
    okButton = [[ButtonText alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f,self.view.bounds.size.height- img.size.height*4, img.size.width, img.size.height)];
    [okButton setBackgroundImage:img forState:UIControlStateNormal];
    okButton.spacing=5.0f;
    [okButton addTarget:self action:@selector(selectOKButton) forControlEvents:UIControlEventTouchUpInside];
    [okButton text:lang(@"confirm")];
    [okButton theme:@"okButton_title"];
    [okButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_sure.png"]];
    [self.view addSubview:okButton];
    [okButton release];
}

#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}


-(void)selectOKButton{

    NSLog(@"selelctOKButton");
    
    [[self getAppDelegate].databaseManager updateMyCommuntiyCentre:dic];
    
    [self.navigationController popViewControllerAnimated:YES];

}

-(void)selectMyCommunityCentreView:(id)sender{

    //MyCommunityCentre* myCommunityCentre = (MyCommunityCentre*)sender;
   
    ElderlyIphoneMyCommunityCentreSubViewController* myCommunityCentreSubViewController = [[ElderlyIphoneMyCommunityCentreSubViewController alloc] init];
    myCommunityCentreSubViewController.myCommunityCentreIndex = ((MyCommunityCentre*)sender).tag;
    myCommunityCentreSubViewController.dic = dic;
    [self.navigationController pushViewController:myCommunityCentreSubViewController animated:YES];
    [myCommunityCentreSubViewController release];

    [[ElderlyGuideMannager sharedInstance] setGudieState:myCommunitySelectedGuide state:NO];
}

-(void)clickGuideView:(GuideView*)sender{
    NSLog(@"clickGuideView");
    GuideView* guide = (GuideView*)sender;
    if(guide.tag == 888){
    
        [[ElderlyGuideMannager sharedInstance] setGudieState:myCommunitySelectGuide state:NO];
        [guide removeAllSubView];
        [self checkGuideState];
        guide.tag = 999;
        return;
    
    }
    
//    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
//        guideView.alpha=0.0f;
//    } completion:^(BOOL finish){
//        [guideView removeFromSuperview];
//        
//    }];
}

-(void)checkGuideState{

    [imageName release];
    imageName = nil;
    float orginY = 0;
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:myCommunitySelectGuide]){
        imageName=@"guide08_%@.png";
        orginY=0;
    }
    else if([[ElderlyGuideMannager sharedInstance] getGudieState:myCommunitySelectedGuide]){
    
        imageName=@"guide09_%@.png";
        orginY=105.0f;
    }
    
    if(imageName == nil){
        if(guideView != nil){
            [guideView removeFromSuperview];
            guideView = nil;
        }

        return ;
    }
    
    [imageName retain];
    [guideView removeAllSubView];
    [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:imageName]];
    [guideView setGuideOrignY:orginY];
    

}

-(void)getMyCommunityCentreData{

    NSArray* keys = [dic allKeys];
    
    for(NSString* key in keys){
        
        ElderlyMyCommunityCentreModel* centreModel = [dic objectForKey:key];
        
        MyCommunityCentre* myCommunityCentreView = nil;
        
        if([key integerValue] == 1001){
            myCommunityCentreView = myCommunityCentreView_first;
        }
        else if([key integerValue] == 1002){
            myCommunityCentreView = myCommunityCentreView_second;
        }
        else if([key integerValue] == 1003){
            myCommunityCentreView = myCommunityCentreView_thrid;
        }
        
        [myCommunityCentreView setTitle:(centreModel.organizationValue.length < 1 ? [ElderlyUtils text:centreModel key:@"centreValue"]:[ElderlyUtils text:centreModel key:@"organizationValue"])];
        if(centreModel.organizationValue.length > 1)
            [myCommunityCentreView setSubheader:[ElderlyUtils text:centreModel key:@"centreValue"]];
        [myCommunityCentreView sethighlight:YES];
        [myCommunityCentreView addClearContentButton:self action:@selector(removeMyCommunityCentre:)];
        [myCommunityCentreView theme:@"myCommunityCentre_title"];
        [myCommunityCentreView layoutSubviews];
    
    }
    
    

}

-(void)removeMyCommunityCentre:(id)sender{

    UIButton* button = (UIButton*)sender;
    DLog(@"%d",button.tag);
    NSInteger selectIndex = button.tag;
    
    MyCommunityCentre* myCommunityCentreView = nil;
    
    if(selectIndex == 1001){
        myCommunityCentreView = myCommunityCentreView_first;
    }
    else if(selectIndex == 1002){
        myCommunityCentreView = myCommunityCentreView_second;
    }
    else if(selectIndex == 1003){
        myCommunityCentreView = myCommunityCentreView_thrid;
    }
    
    if(myCommunityCentreView != nil){
    
        [myCommunityCentreView removeClearContentButton];
        [myCommunityCentreView setTitle:lang(@"selectMyCommunity")];
        [myCommunityCentreView setSubheader:@""];
        [myCommunityCentreView sethighlight:NO];
        [myCommunityCentreView theme:@"myCommunityCentre_title"];
        [myCommunityCentreView layoutSubviews];
        
        NSArray* keys = [dic allKeys];
        
        for(NSString* key in keys){
            
            if(selectIndex == [key integerValue]){
                [dic removeObjectForKey:key];
                break;
            }
        }
    }
}


@end
