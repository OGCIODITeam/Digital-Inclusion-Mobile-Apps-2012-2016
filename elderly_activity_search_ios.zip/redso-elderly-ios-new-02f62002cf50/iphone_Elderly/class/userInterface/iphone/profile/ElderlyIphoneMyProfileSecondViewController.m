//
//  ElderlyIphoneMyProfileSecondViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-15.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyProfileSecondViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyThemeManager.h"
#import "GuideView.h"
#import "GenderView.h"
#import "ElderlyIphoneMyInterestViewController.h"
#import "AreaPicker.h"
#import "MyCommunityCentre.h"
#import "ElderlyTextField.h"
#import "ElderlyGuideMannager.h"
#import "ElderlyUserModel.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlySettingManager.h"
#import "ElderlyAreaModel.h"
#import "ElderlyAlertUtils.h"

@interface ElderlyIphoneMyProfileSecondViewController ()<UITextFieldDelegate,GenderViewDelegate,AreaPickerDelegate>

@property(nonatomic,retain)ElderlyAreaModel* areaModel;
@property(nonatomic,retain)ElderlyAreaModel* regionModel;

-(void)resetPageControlImage;
-(void)initInputUserNameView;
-(void)initInputGenderView;
-(void)initInputAreaView;
-(void)initInputReginView;
-(void)initPickView;
-(void)initRegionPicker;

-(void)checkGuideState;

@end

@implementation ElderlyIphoneMyProfileSecondViewController

@synthesize areaModel;
@synthesize regionModel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    imageName = nil;
    userModel = [self getAppDelegate].profileSettingManager.userModel;

    [self initInputUserNameView];
    [self initInputGenderView];
    [self initInputAreaView];
    [self initInputReginView];



    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cyan.png"];
    nextButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, self.view.bounds.size.height- img.size.height*4, img.size.width, img.size.height)];
    [nextButton setBackgroundImage:img forState:UIControlStateNormal];
    [nextButton setTitle:lang(@"next") forState:UIControlStateNormal];
    [nextButton theme:@"next_title"];
    [nextButton addTarget:self action:@selector(selectButton) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:nextButton];
    [nextButton release];
    
    pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 70)*0.5f, CGRectGetMaxY(nextButton.frame)+30, 70, 12)];
    pageControl.numberOfPages = 3;
    pageControl.currentPage = 1;
    pageControl.userInteractionEnabled = NO;
    [self resetPageControlImage];
    [self.view addSubview:pageControl];
    [pageControl release];
    
    guideView = [[GuideView alloc] initWithFrame:CGRectMake(0, 70, self.view.bounds.size.width, self.view.bounds.size.height - 70)];
    
    [self checkGuideState];
    [self.view addSubview:guideView];
    [guideView release];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{

    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myProfile")];
    
}

-(void)dealloc{
    [imageName release];
    self.areaModel = nil;
    self.regionModel = nil;
    [super dealloc];
}

-(void)themeChanged{

    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myProfile")];
    
    NSInteger fontSize = [[self getAppDelegate].settingManager getFontType];
    userNameField.placeholder = lang(@"inputName");
    [userNameField setFont:@"STHeitiTC-Medium" size:(fontSize == 0?14:(fontSize==1?16:18))];
    [userNameField theme:@"inputUserName"];
    
    
    [nextButton setTitle:lang(@"next") forState:UIControlStateNormal];
    [nextButton theme:@"next_title"];
    
    [genderView setMenButtonTitle:lang(@"men")];
    [genderView setWomenButonTitle:lang(@"women")];
    [genderView setSkipButton:lang(@"skip")];
    [inputGenderView theme:@"myCommunityCentreSubView_title"];
    
    NSString* gender = [inputGenderView getTitle];
    if([gender isEqualToString:lang(@"men")] || [gender isEqualToString:lang(@"women")])
        [inputGenderView setTitle:gender];
    else{
        [inputGenderView setTitle:lang(@"inputGender")];
    }
//    [inputGenderView sethighlight:([gender isEqualToString:lang(@"inputGender")]?NO:YES)];
   
    NSString* area = [[self getAppDelegate].databaseManager showAreaContent:[inputAreaView getTitle]];
    if(area == nil){
        area = lang(@"inputArea");
    }
    [inputAreaView setTitle:area];
   
    NSString* region = [[self getAppDelegate].databaseManager showAreaContent:[inputRegionView getTitle]];
    if(region == nil){
        region = lang(@"inputRegion");
    }
    [inputRegionView setTitle:region];
    

//    if(self.areaModel != nil){
//        [inputAreaView setTitle:[ElderlyUtils text:self.areaModel key:@"name"]];
//        [inputAreaView sethighlight:YES];
//    }
//    else{
//        [inputAreaView setTitle:lang(@"inputArea")];
//    }
//    
//    if(self.regionModel != nil){
//        [inputRegionView setTitle:[ElderlyUtils text:self.regionModel key:@"name"]];
//        [inputRegionView sethighlight:YES];
//    }
//    else{
//        [inputRegionView setTitle:lang(@"inputRegion")];
//    }
    
    
    [inputAreaView theme:@"myCommunityCentreSubView_title"];
    [inputRegionView theme:@"myCommunityCentreSubView_title"];
    
    
    areaPicker = (AreaPicker*)[self.view viewWithTag:1004];
    if(areaPicker != nil){
        areaPicker.list=[[self getAppDelegate].databaseManager getAreaNameArray];
        [areaPicker themeChanged];
    }

    
    regionPicker = (AreaPicker*)[self.view viewWithTag:1005];
    if(regionPicker != nil){
         NSArray* regionList = [[self getAppDelegate].databaseManager getRegionName:[inputAreaView getTitle]];
        regionPicker.list = regionList;
        [regionPicker themeChanged];
    }
    
    
    if(guideView != nil && imageName != nil){
    
        [guideView removeAllSubView];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:imageName]];
    }
}

#pragma mark init

-(void)initInputUserNameView{

    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_input.png"];
    UIImageView* imageView = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 22, img.size.width, img.size.height)];
    imageView.image = img;
    imageView.userInteractionEnabled = YES;
    
    UIImage* deleteImg = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_delete.png"];
    clearTextFieldButton = [[UIButton alloc] initWithFrame:CGRectMake(img.size.width - deleteImg.size.width*1.2, (img.size.height - deleteImg.size.height)*0.5f, deleteImg.size.width, deleteImg.size.height)];
    clearTextFieldButton.tag = 9999;
    [clearTextFieldButton setAccessibilityLabel:lang(@"delete")];
    [clearTextFieldButton setImage:deleteImg forState:UIControlStateNormal];
    clearTextFieldButton.hidden = (userModel.userName.length?NO:YES);
    [clearTextFieldButton addTarget:self action:@selector(clearInputContent:) forControlEvents:UIControlEventTouchUpInside];
    [imageView addSubview:clearTextFieldButton];
    [clearTextFieldButton release];
    
    
    userNameField = [[ElderlyTextField alloc] initWithFrame:CGRectMake(10, 10, img.size.width-deleteImg.size.width - 10, img.size.height-10)];
    NSInteger fontSize = [[self getAppDelegate].settingManager getFontType];
    [userNameField setFont:@"STHeitiTC-Medium" size:(fontSize == 0?14:(fontSize==1?16:18))];
    [userNameField theme:@"inputUserName"];
    
    if(userModel.userName.length > 0){
        userNameField.text = userModel.userName;
    }
    
    userNameField.borderStyle = UITextBorderStyleNone;
    userNameField.returnKeyType = UIReturnKeyDone;
    userNameField.placeholder = lang(@"inputName");
    userNameField.delegate = self;
    [imageView addSubview:userNameField];
    [userNameField release];
    
    [self.view addSubview:imageView];
    [imageView release];
}


-(void)initInputGenderView{

    UIImage* img =  [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_input.png"];
    inputGenderView = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 70, img.size.width, img.size.height) bgImage: img];
   
    inputGenderView.tag = 1001;
    if(userModel.gender.length > 1){
        [inputGenderView setTitle:userModel.gender];
        [inputGenderView sethighlight:YES];
        [inputGenderView addClearContentButton:self action:@selector(clearInputContent:)];
    }
    else{
        [inputGenderView setTitle:lang(@"inputGender")];
    }
    
    
    [inputGenderView theme:@"myCommunityCentreSubView_title"];

    [inputGenderView addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:inputGenderView];
    [inputGenderView release];

}


-(void)initInputAreaView{

    UIImage* img =  [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_input.png"];
    inputAreaView = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(inputGenderView.frame)+12, img.size.width, img.size.height) bgImage: img];

    inputAreaView.tag = 1002;
    if(userModel.area.length > 1){
        [inputAreaView setTitle:[[self getAppDelegate].databaseManager showAreaContent:userModel.area]];
        [inputAreaView sethighlight:YES];
        [inputAreaView addClearContentButton:self action:@selector(clearInputContent:)];
    }
    else{
        [inputAreaView setTitle:lang(@"inputArea")];
    }
    
    [inputAreaView theme:@"myCommunityCentreSubView_title"];
 
    [inputAreaView addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:inputAreaView];
    [inputAreaView release];

}


-(void)initInputReginView{
                                                                         
    UIImage* img =  [[ElderlyThemeManager sharedInstance] imageByTheme:@"txt_input.png"];
    inputRegionView = [[MyCommunityCentre alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(inputAreaView.frame)+12, img.size.width, img.size.height) bgImage: img];
    inputRegionView.tag = 1003;
    if(userModel.region.length > 1){
        [inputRegionView setTitle:[[self getAppDelegate].databaseManager showAreaContent:userModel.region]];
        [inputRegionView sethighlight:YES];
        [inputRegionView addClearContentButton:self action:@selector(clearInputContent:)];
    }
    else{
        [inputRegionView setTitle:lang(@"inputRegion")];
    }
    
    [inputRegionView theme:@"myCommunityCentreSubView_title"];

    [inputRegionView addTarget:self action:@selector(selectMyCommunityCentreView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:inputRegionView];
    [inputRegionView release];

}


-(void)initGenderView{

    genderView = [[GenderView alloc] initWithFrame:self.view.bounds];
    genderView.delegate = self;
    [genderView setMenButtonTitle:lang(@"men")];
    [genderView setWomenButonTitle:lang(@"women")];
    [genderView setSkipButton:lang(@"skip")];
    [self.view addSubview:genderView];
    [genderView release];
}

-(void)initPickView{
    
    areaPicker = [[AreaPicker alloc] init];
    areaPicker.tag = 1004;
    areaPicker.list=[[self getAppDelegate].databaseManager getAreaNameArray];
    areaPicker.blackPanelFrame=CGRectMake(0.0f, 165.0f, 320.0f, self.view.frame.size.height-165.0f);
    areaPicker.delegate = self;
//    [areaPicker cancelImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cancel.png"] comfirmImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_sure.png"]];
//    [areaPicker selectedView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"setting_area_on.png"] ];
    [areaPicker showInView:self.view];
    [areaPicker release];
    
}

-(void)initRegionPicker{
    
    [[ElderlyGuideMannager sharedInstance] setGudieState:inputRegionGuide state:NO];
    NSArray* regionList = [[self getAppDelegate].databaseManager getRegionName:[inputAreaView getTitle]];
    if(regionList == nil || regionList.count < 1){
        
        [ElderlyAlertUtils showAlert:lang(@"regionCueMsg") delegate:nil];
        return;
    }
    
    regionPicker = [[AreaPicker alloc] init];
    regionPicker.tag = 1005;
    regionPicker.list=regionList;
    regionPicker.blackPanelFrame=CGRectMake(0.0f, 218.0f, 320.0f, self.view.frame.size.height-218.0f);
    regionPicker.delegate = self;
    regionPicker.animationIsRun = YES;
//    [regionPicker cancelImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cancel.png"] comfirmImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_sure.png"]];
//    [regionPicker selectedView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"setting_area_on.png"] ];
    [regionPicker showInView:self.view];
    [regionPicker release];
}

#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)clearInputContent:(id)sender{

    UIButton* button = (UIButton*)sender;
    DLog(@"clearInputContent:%d",button.tag);
    if(button.tag == 1001){
        [inputGenderView setTitle:lang(@"inputGender")];
        [inputGenderView sethighlight:NO];
        [inputGenderView removeClearContentButton];
    }
    else if(button.tag == 1002){
        [inputAreaView setTitle:lang(@"inputArea")];
        [inputRegionView setTitle:lang(@"inputRegion")];
        self.areaModel = nil;
        self.regionModel = nil;

        [inputAreaView sethighlight:NO];
        [inputRegionView sethighlight:NO];
        [inputAreaView removeClearContentButton];
        [inputRegionView removeClearContentButton];
    }
    else if(button.tag == 1003){
        [inputRegionView setTitle:lang(@"inputRegion")];
        self.regionModel = nil;
        [inputRegionView sethighlight:NO];
        [inputRegionView removeClearContentButton];
    }
    else if(button.tag == 9999){
    
        userNameField.text = @"";
        clearTextFieldButton.hidden = YES;
    }
    

}

-(void)resetPageControlImage{
    if ([pageControl respondsToSelector:@selector(pageIndicatorTintColor)]) {
        UIImage *pageIndicatorImage = [[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim.png"];
        UIImage *currentPageIndicatorImage = [[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim_on.png"];
        pageControl.pageIndicatorTintColor = [UIColor colorWithPatternImage:pageIndicatorImage];
        pageControl.currentPageIndicatorTintColor = [UIColor colorWithPatternImage:currentPageIndicatorImage];
    }else{
        NSArray *subView = pageControl.subviews;
        for (int i =0; i < [subView count]; i++){
            UIImageView *dot = [subView objectAtIndex:i];
            dot.image = (pageControl.currentPage == i ?[[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim_on.png"]:[[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim.png"]);
        }
    }
    
    
    
}

-(void)selectButton{
    
    userModel.userName = userNameField.text;
    userModel.gender = ([[inputGenderView getTitle] isEqualToString:lang(@"inputGender")] ?@"":[inputGenderView getTitle] );

    
    if(self.regionModel.name_tc != nil){
        userModel.region = self.regionModel.name_tc;
    }
    
    
    if([[inputRegionView getTitle] isEqualToString:lang(@"inputRegion")]){
        userModel.region = nil;
    }
        
    
    
//    if(userModel.region == nil){
//        [ElderlyAlertUtils showAlert:lang(@"regionCueMsg2") delegate:nil];
//        return;
//    }
    
    if(self.areaModel.name_tc != nil)
        userModel.area = self.areaModel.name_tc ;
    
    if([[inputAreaView getTitle] isEqualToString:lang(@"inputArea")]){
        userModel.area = nil;
    }
    
//    if(userModel.area == nil){
//        [ElderlyAlertUtils showAlert:lang(@"regionCueMsg") delegate:nil];
//        return;
//    }
    
    

    

    
    ElderlyIphoneMyInterestViewController* myInterestViewController = [[ElderlyIphoneMyInterestViewController alloc] init];
    [self.navigationController pushViewController:myInterestViewController animated:YES];
    [myInterestViewController release];

}

-(void)selectMyCommunityCentreView:(id)sender{
    
    [userNameField resignFirstResponder];
    MyCommunityCentre* myCommunityCentre = (MyCommunityCentre*)sender;
    if(myCommunityCentre.tag == 1001){

        [guideView removeAllSubView];
        guideView.hidden = YES;
        [self initGenderView];
    }
    else if(myCommunityCentre.tag == 1002){
    
        [guideView removeAllSubView];
        guideView.hidden = YES;
        [self initPickView];
    }
    else if(myCommunityCentre.tag == 1003){
    
        [guideView removeAllSubView];
        guideView.hidden = YES;
        [self initRegionPicker];
    }

}

#pragma mark UITextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{


    if(keyboardBgView == nil){
        keyboardBgView = [[UIButton alloc] initWithFrame:CGRectMake(0, 65, self.view.bounds.size.width, self.view.bounds.size.height - 65)];
        [keyboardBgView setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_picker_box.png"] forState:UIControlStateNormal];
        [self.view addSubview:keyboardBgView];
        [keyboardBgView release];
    }

 
    [guideView removeAllSubView];
    guideView.hidden = YES;


    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    
    if(string.length > 0){
        clearTextFieldButton.hidden = NO;
    }
    
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{

    [userNameField resignFirstResponder];
    [keyboardBgView removeFromSuperview];
    keyboardBgView = nil;
    
    clearTextFieldButton.hidden = (userNameField.text.length?NO:YES);

//    [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"guide02.png"]];
//    [guideView setGuideOrignY:132];
    
    [[ElderlyGuideMannager sharedInstance] setGudieState:inputNameGuide state:NO];
    [self checkGuideState];
    return YES;
}


#pragma mark GenderView Delegate
-(void)selectGenderView:(NSInteger)selectIndex{

    NSLog(@"selectGenderView:%d",selectIndex);
    
    [genderView removeFromSuperview];
    genderView=nil;
    guideView.hidden = NO;
    [guideView removeAllSubView];
//    [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByTheme:@"guide03.png"]];
//    [guideView setGuideOrignY:194];
    [[ElderlyGuideMannager sharedInstance] setGudieState:inputGenderGuide state:NO];
    [self checkGuideState];
    
    if(selectIndex == 1003)
        return;
    
    NSString* gender = lang(@"men");
    if(selectIndex == 1002){
        gender = lang(@"women");
    }
    [inputGenderView addClearContentButton:self action:@selector(clearInputContent:)];
    [inputGenderView setTitle:gender];
    [inputGenderView sethighlight:YES];
}

#pragma mark areaPicker Delegate
-(void)didClickAreaPicker:(AreaPicker*)picker confirm:(BOOL)confirm{

    if(picker.tag == 1004){
        if(confirm){
            [inputAreaView sethighlight:YES];
            NSString* title = [picker.list objectAtIndex:picker.selectedIndex];
            [inputAreaView setTitle:title];
            self.areaModel = [[self getAppDelegate].databaseManager getAreaModelForName:title];
            self.regionModel = nil;
            
            [inputRegionView sethighlight:NO];
            [inputRegionView setTitle:lang(@"inputRegion")];
            [inputAreaView addClearContentButton:self action:@selector(clearInputContent:)];
            [inputRegionView removeClearContentButton];
           
        }
        [guideView removeAllSubView];
        guideView.hidden = NO;
        [[ElderlyGuideMannager sharedInstance] setGudieState:inputAreaGuide state:NO];
        [self checkGuideState];
    }
    else if(picker.tag == 1005){
    
        
        if(confirm){
            if(picker.list == nil || picker.list.count < 1)
                return;
            [inputRegionView sethighlight:YES];
            [inputRegionView addClearContentButton:self action:@selector(clearInputContent:)];

            NSString* title = [picker.list objectAtIndex:picker.selectedIndex];
            [inputRegionView setTitle:title];
            self.regionModel = [[self getAppDelegate].databaseManager getAreaModelForName:title];
        }
        else{
             [self checkGuideState];
        } 
    }
}

-(void)checkGuideState{

    [imageName release];
    imageName = nil;
    float orginY = 0;
    if([[ElderlyGuideMannager sharedInstance] getGudieState:inputNameGuide]){
        imageName = @"guide01_%@.png";
        orginY = 65;
    }
    else if([[ElderlyGuideMannager sharedInstance] getGudieState:inputGenderGuide]){
        imageName = @"guide02_%@.png";
        orginY = 115;
    }
    else if([[ElderlyGuideMannager sharedInstance] getGudieState:inputAreaGuide]){
        imageName = @"guide03_%@.png";
        orginY = 165;
    }
    else if([[ElderlyGuideMannager sharedInstance] getGudieState:inputRegionGuide]){
        imageName = @"guide04_%@.png";
        orginY = 218;
    }
    
    if(imageName == nil){
        guideView.hidden = YES;
        return ;
    }
    
    [imageName retain];
    guideView.hidden = NO;
    [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:imageName]];
    [guideView setGuideOrignY:orginY];
    

}


@end
