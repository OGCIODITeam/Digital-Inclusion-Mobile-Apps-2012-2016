//
//  ElderlyIphoneMyInterestViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-16.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyInterestViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyIphoneMyInterestTableViewViewController.h"
#import "ElderlyIphoneMyCommunityCentreViewController.h"
#import "GuideView.h"
#import "ElderlyGuideMannager.h"
#import "ElderlyUserModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyDatabaseManager.h"

@interface ElderlyIphoneMyInterestViewController ()

-(BOOL)checkGuideState;

@end

@implementation ElderlyIphoneMyInterestViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    imageName = nil;
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"item_cyan.png"];

    
    myInterestButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 25, img.size.width, img.size.height)];
    myInterestButton.tag = 1001;
    [myInterestButton setBackgroundImage:img forState:UIControlStateNormal];
    [myInterestButton setTitle:lang(@"myInterest") forState:UIControlStateNormal];
    [myInterestButton theme:@"my_interest_title"];
    [myInterestButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:myInterestButton];
    [myInterestButton release];
    
    myCommunityButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(myInterestButton.frame)+25, img.size.width, img.size.height)];
    myCommunityButton.tag = 1002;
    [myCommunityButton setBackgroundImage:img forState:UIControlStateNormal];
    [myCommunityButton setTitle:lang(@"myCommunity") forState:UIControlStateNormal];
    [myCommunityButton theme:@"my_community_title"];
    [myCommunityButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:myCommunityButton];
    [myCommunityButton release];
    
    
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cyan.png"];
    finishButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, self.view.bounds.size.height- img.size.height*4, img.size.width, img.size.height)];
    [finishButton setBackgroundImage:img forState:UIControlStateNormal];
    [finishButton setTitle:lang(@"finish") forState:UIControlStateNormal];
    [finishButton theme:@"next_title"];
    finishButton.tag = 1003;
    [finishButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:finishButton];
    [finishButton release];
    
    pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 70)*0.5f, CGRectGetMaxY(finishButton.frame)+20, 70, 12)];
    pageControl.numberOfPages = 3;
    pageControl.currentPage = 2;
    pageControl.userInteractionEnabled = NO;
    [self resetPageControlImage];
    [self.view addSubview:pageControl];
    [pageControl release];
    
    if([self checkGuideState]){
        guideView = [[GuideView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height, self.view.bounds.size.width, self.view.bounds.size.height - 70)];
        [self.view addSubview:guideView];
        [guideView release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [imageName release];
    [super dealloc];
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myProfile")];
    [self checkGuideState];
}


-(void)themeChanged{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myProfile")];
    
    [finishButton setTitle:lang(@"finish") forState:UIControlStateNormal];
    [finishButton theme:@"next_title"];
    [myCommunityButton setTitle:lang(@"myCommunity") forState:UIControlStateNormal];
    [myCommunityButton theme:@"my_community_title"];
    [myInterestButton setTitle:lang(@"myInterest") forState:UIControlStateNormal];
    [myInterestButton theme:@"my_interest_title"];
    
    if(guideView != nil && imageName != nil){
        [guideView removeAllSubView];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:imageName]];

    }
}

#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)resetPageControlImage{
    if ([pageControl respondsToSelector:@selector(pageIndicatorTintColor)]) {
        UIImage *pageIndicatorImage = [[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim.png"];
        UIImage *currentPageIndicatorImage = [[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim_on.png"];
        pageControl.pageIndicatorTintColor = [UIColor colorWithPatternImage:pageIndicatorImage];
        pageControl.currentPageIndicatorTintColor = [UIColor colorWithPatternImage:currentPageIndicatorImage];
    }else{
        NSArray *subView = pageControl.subviews;
        for (int i =0; i < [subView count]; i++){
            UIImageView *dot = [subView objectAtIndex:i];
            dot.image = (pageControl.currentPage == i ?[[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim_on.png"]:[[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim.png"]);
        }
    }
    
    
}

-(void)selectButton:(id)sender{
    
    UIButton* button = (UIButton*)sender;
    if(button.tag == 1001){
    
        ElderlyIphoneMyInterestTableViewViewController* tableViewViewController = [[ElderlyIphoneMyInterestTableViewViewController alloc] init];
        [self.navigationController pushViewController:tableViewViewController animated:YES];
        [tableViewViewController release];
        
        [[ElderlyGuideMannager sharedInstance] setGudieState:myInterestGuide state:NO];
    
    }
    else if(button.tag == 1002){


        ElderlyIphoneMyCommunityCentreViewController* myCommunityCentreViewController = [[ElderlyIphoneMyCommunityCentreViewController alloc] init];
        [self.navigationController pushViewController:myCommunityCentreViewController animated:YES];
        [myCommunityCentreViewController release];

        if(guideView != nil){
        
            [guideView removeFromSuperview];
            guideView  = nil;
        }
        
        [[ElderlyGuideMannager sharedInstance] setGudieState:myCommunityGuide state:NO];
    }
    else if(button.tag == 1003){
        [[self getAppDelegate].rootController back];
        [[self getAppDelegate].databaseManager updateElderlyUser:[self getAppDelegate].profileSettingManager.userModel];
    }

}

-(BOOL)checkGuideState{
    [imageName release];
    imageName = nil;
    float orginY = 0;
    [guideView removeAllSubView];
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:myInterestGuide]){
        imageName = @"guide05_%@.png";
        orginY = 75;
    }
    else if([[ElderlyGuideMannager sharedInstance] getGudieState:myCommunityGuide]){
        imageName = @"guide07_%@.png";
        orginY = 140;
    }
       
    if(imageName == nil){
        return NO;
    }
    
    [imageName retain];
    [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:imageName]];
    [guideView setGuideOrignY:orginY];
    
    return YES;
    
}

@end
