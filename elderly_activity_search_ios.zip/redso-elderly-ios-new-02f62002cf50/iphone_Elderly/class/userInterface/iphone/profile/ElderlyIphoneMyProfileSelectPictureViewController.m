//
//  ElderlyIphoneMyProfileSelectPictureViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-14.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyProfileSelectPictureViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyUserModel.h"
#import "GTGZUtils.h"
#import "ElderlyPathUtils.h"
#import "ElderlyIphoneMyProfileViewController.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyDatabaseManager.h"

@interface ElderlyIphoneMyProfileSelectPictureViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation ElderlyIphoneMyProfileSelectPictureViewController
@synthesize isHome;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
        isHome = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_photo.png"];
    UIImageView* portraitBgView = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 27, img.size.width, img.size.height)];
    portraitBgView.image = img;
    
    
    UIImageView* portraitView = [[UIImageView alloc] initWithFrame:CGRectMake(6, 6, 167, 167)];
    ElderlyProfileSettingManager* profileSetting = [self getAppDelegate].profileSettingManager ;
    portraitView.image = [profileSetting readPortraitBig:profileSetting.userModel.portraitBigPath];
    
    [portraitBgView addSubview:portraitView];
    [portraitView release];
    
    
    [self.view addSubview:portraitBgView];
    [portraitBgView release];
    
    UIView* shadowView = [[UIView alloc] initWithFrame:self.view.bounds];
    shadowView.backgroundColor = [UIColor blackColor];
    shadowView.alpha = 0.5;
    [self.view addSubview:shadowView];
    [shadowView release];
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_panel_up.png"];
    takePictureButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 240, img.size.width, img.size.height)];
    [takePictureButton setBackgroundImage:img forState:UIControlStateNormal];
    [takePictureButton setBackgroundImage:img forState:UIControlStateHighlighted];
    [takePictureButton setTitle:lang(@"takePicture") forState:UIControlStateNormal];
    [takePictureButton theme:@"takePictureButton_title"];
    takePictureButton.tag = 1001;
    [takePictureButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:takePictureButton];
    [takePictureButton release];
    
    selectPictureButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(takePictureButton.frame), img.size.width, img.size.height)];
    [selectPictureButton setBackgroundImage:img forState:UIControlStateNormal];
    [selectPictureButton setBackgroundImage:img forState:UIControlStateHighlighted];
    [selectPictureButton setTitle:lang(@"selectPictured") forState:UIControlStateNormal];
    [selectPictureButton theme:@"selectPictureButton_title"];
    selectPictureButton.tag = 1002;
    [selectPictureButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:selectPictureButton];
    [selectPictureButton release];
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_panel_down.png"];
    skipPictureButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(selectPictureButton.frame), img.size.width, img.size.height)];
    [skipPictureButton setBackgroundImage:img forState:UIControlStateNormal];
    [skipPictureButton setBackgroundImage:img forState:UIControlStateHighlighted];
    [skipPictureButton setTitle:lang(@"skip") forState:UIControlStateNormal];
    [skipPictureButton theme:@"skipButton_title"];
    skipPictureButton.tag = 1003;
    [skipPictureButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:skipPictureButton];
    [skipPictureButton release];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myProfile")];
    
    
    
}

-(void)themeChanged{

    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myProfile")];
    
    [takePictureButton setTitle:lang(@"takePicture") forState:UIControlStateNormal];
    [takePictureButton theme:@"takePictureButton_title"];
    
    [selectPictureButton theme:@"selectPictureButton_title"];
    [selectPictureButton setTitle:lang(@"selectPictured") forState:UIControlStateNormal];
    
    [skipPictureButton setTitle:lang(@"skip") forState:UIControlStateNormal];
    [skipPictureButton theme:@"skipButton_title"];
    
}

-(void)dealloc{

    [super dealloc];
}


#pragma mark method

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    if(isHome)
        [[self getAppDelegate].rootController back];
    else{
    
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)selectButton:(id)sender{
    NSLog(@"selectButton");
    
    UIButton* button = (UIButton*)sender;
    if(button.tag == 1001){
        [self capturePhoto];
    }
    else if(button.tag == 1002){
        [self fromPhotoAlbum];
    }
    else if(button.tag == 1003){
        if(isHome){
            
            ElderlyIphoneMyProfileViewController* myProfileViewController = [[ElderlyIphoneMyProfileViewController alloc] init];
            [self.navigationController pushViewController:myProfileViewController animated:YES];
            [myProfileViewController release];
            
        }
        else{
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}


-(void)fromPhotoAlbum{
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        NSArray *temp_MediaTypes = [UIImagePickerController availableMediaTypesForSourceType:picker.sourceType];
        picker.mediaTypes = temp_MediaTypes;
        picker.delegate = self;
        
    }
    
    [[self getAppDelegate].rootController presentModalViewController:picker animated:YES];
    [picker release];
    
    
}

-(void)capturePhoto{
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        NSArray *temp_MediaTypes = [UIImagePickerController availableMediaTypesForSourceType:picker.sourceType];
        picker.mediaTypes = temp_MediaTypes;
        picker.cameraCaptureMode = UIImagePickerControllerCameraCaptureModePhoto;
        picker.delegate = self;
        
    }

    [[self getAppDelegate].rootController presentModalViewController:picker animated:YES];
    [picker release];
    
}


#pragma mark imagePicker Delegate
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    
      [[self getAppDelegate].rootController dismissModalViewControllerAnimated:YES];
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    
    if ([mediaType isEqualToString:@"public.image"]){
        NSString *imageKey = @"UIImagePickerControllerOriginalImage";
        //  UIImage *image = [info objectForKey:key];
        //        imageView.image = image;
        
        UIImage* image=[info objectForKey:imageKey];
        
        if(image!=nil && picker.sourceType==UIImagePickerControllerSourceTypeCamera){
            UIImageWriteToSavedPhotosAlbum(image, nil,nil, nil);
        }
        
        [self getAppDelegate].profileSettingManager.userModel.portraitPath = [ElderlyPathUtils getPortraitPath:NO];
        
        CGSize size = CGSizeMake(65, 65);
        if([ElderlyUtils isRetain4]){
            size = CGSizeMake(93, 93);
        }
        
        [[[self getAppDelegate] profileSettingManager] savePortrait:[GTGZUtils imageWithThumbnail:image size:size] imagePath:[self getAppDelegate].profileSettingManager.userModel.portraitPath];
        
        [self getAppDelegate].profileSettingManager.userModel.portraitBigPath = [ElderlyPathUtils getPortraitPath:YES];
        
        [[[self getAppDelegate] profileSettingManager] savePortrait:[GTGZUtils imageWithThumbnail:image size:CGSizeMake(167, 167)] imagePath:[self getAppDelegate].profileSettingManager.userModel.portraitBigPath];
        
        [[self getAppDelegate].databaseManager updateElderlyUser:[self getAppDelegate].profileSettingManager.userModel];
        
       
    }
    [[self getAppDelegate].rootController dismissModalViewControllerAnimated:NO];
  
    if(isHome){
    
        ElderlyIphoneMyProfileViewController* myProfileViewController = [[ElderlyIphoneMyProfileViewController alloc] init];
        [self.navigationController pushViewController:myProfileViewController animated:YES];
        [myProfileViewController release];
        
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

@end
