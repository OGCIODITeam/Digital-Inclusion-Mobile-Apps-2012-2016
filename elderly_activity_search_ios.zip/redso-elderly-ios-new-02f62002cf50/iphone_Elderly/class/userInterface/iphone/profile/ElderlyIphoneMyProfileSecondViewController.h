//
//  ElderlyIphoneMyProfileSecondViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-15.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneViewController.h"

@class GuideView;
@class GenderView;
@class MyCommunityCentre;
@class ElderlyTextField;
@class AreaPicker;
@class ElderlyUserModel;
@interface ElderlyIphoneMyProfileSecondViewController : ElderlyIphoneViewController{
    ElderlyTextField* userNameField;
    UIButton* clearTextFieldButton;
    UIPageControl* pageControl;
    UIButton* nextButton;
    UIImageView* cueImageView;
    
    
    MyCommunityCentre* inputGenderView;
    MyCommunityCentre* inputAreaView;
    MyCommunityCentre* inputRegionView;
    
    GuideView* guideView;
    GenderView* genderView;
    
    AreaPicker* areaPicker;
    AreaPicker* regionPicker;
    ElderlyUserModel* userModel;
    
    UIButton* keyboardBgView;
    
    NSString* imageName;
}

@end
