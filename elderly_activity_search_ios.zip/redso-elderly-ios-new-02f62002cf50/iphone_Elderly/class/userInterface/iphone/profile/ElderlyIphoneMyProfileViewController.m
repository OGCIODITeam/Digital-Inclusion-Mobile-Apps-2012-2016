//
//  ElderlyIphoneMyProfileViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-7.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneMyProfileViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyThemeManager.h"
#import "ElderlyIphoneMyProfileSelectPictureViewController.h"
#import "ElderlyIphoneMyProfileSecondViewController.h"
#import "ElderlyUserModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyAlertUtils.h"
#import "ElderlyPathUtils.h"
#import "GuideView.h"
#import "ElderlyGuideMannager.h"

#define ShakeTime 0.2


@interface ElderlyIphoneMyProfileViewController ()<UIAlertViewDelegate>
-(void)resetPageControlImage;
@end

@implementation ElderlyIphoneMyProfileViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    

    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_photo.png"];
    UIImageView* portraitBgView = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, 27, img.size.width, img.size.height)];
    portraitBgView.image = img;
    portraitBgView.userInteractionEnabled = YES;
    [self.view addSubview:portraitBgView];
    [portraitBgView release];
    img = [[self getAppDelegate].profileSettingManager readPortraitBig:[self getAppDelegate].profileSettingManager.userModel.portraitBigPath];
    portraitButtonView = [[UIButton alloc] initWithFrame:CGRectMake(6, 6, img.size.width, img.size.height)];
    [portraitButtonView setImage:img forState:UIControlStateNormal];
    [portraitButtonView setTitle:lang(@"picture") forState:UIControlStateNormal];
    portraitButtonView.tag = 1001;
//    [portraitButtonView addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [portraitBgView addSubview:portraitButtonView];
    [portraitButtonView release];
    
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_cyan.png"];
    changePictureButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, CGRectGetMaxY(portraitBgView.frame)+10, img.size.width, img.size.height)];
    [changePictureButton setBackgroundImage:img forState:UIControlStateNormal];
    [changePictureButton setTitle:lang(@"changePicture") forState:UIControlStateNormal];
    [changePictureButton theme:@"changePictureButton_title"];
    changePictureButton.tag = 1002;
    [changePictureButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:changePictureButton];
    [changePictureButton release];
    

    nextButton = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - img.size.width)*0.5f, self.view.bounds.size.height- img.size.height*4, img.size.width, img.size.height)];
    [nextButton setBackgroundImage:img forState:UIControlStateNormal];
    [nextButton setTitle:lang(@"next") forState:UIControlStateNormal];
    [nextButton theme:@"next_title"];
    nextButton.tag = 1003;
    [nextButton addTarget:self action:@selector(selectButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:nextButton];
    [nextButton release];
    
    pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 70)*0.5f, CGRectGetMaxY(nextButton.frame)+30, 70, 12)];
    pageControl.numberOfPages = 3;
    pageControl.currentPage = 0;
     pageControl.userInteractionEnabled = NO;
    [self resetPageControlImage];
    [self.view addSubview:pageControl];
    [pageControl release];
    
    
   
    if( [[ElderlyGuideMannager sharedInstance] getGudieState:profileSettingPictureGuide]){
        guideView = [[GuideView alloc] initWithFrame:self.view.bounds];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide13_%@.png"]];
        [guideView addTarget:self action:@selector(onGuideButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:guideView];
        [guideView release];
    }
    

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    pageControl = nil;
    nextButton = nil;
    // Dispose of any resources that can be recreated.
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myProfile")];
    [changePictureButton setTitle:lang(@"changePicture") forState:UIControlStateNormal];
    [changePictureButton theme:@"changePictureButton_title"];

    [nextButton setTitle:lang(@"next") forState:UIControlStateNormal];
    [nextButton theme:@"next_title"];
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:profileSettingPictureGuide] && guideView != nil){
        [guideView removeAllSubView];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide13_%@.png"]];
    }
}


-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:@"bg_top_cyan.png"];
    [nav titleView:lang(@"myProfile")];

    
    NSLog(@"%@",[self getAppDelegate].profileSettingManager.userModel.portraitBigPath);
    
    [portraitButtonView setImage:[[self getAppDelegate].profileSettingManager readPortraitBig:[self getAppDelegate].profileSettingManager.userModel.portraitBigPath] forState:UIControlStateNormal];
    
    if([self getAppDelegate].profileSettingManager.userModel.portraitBigPath != nil && [self getAppDelegate].profileSettingManager.userModel.portraitBigPath.length >0 && longPress == nil){
        longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(btnLong:)];
        longPress.minimumPressDuration = 0.8; //定义按的时间
        [portraitButtonView addGestureRecognizer:longPress];
        [longPress release];
        
    }


}

#pragma mark init


#pragma mark methods

-(void)navigationLeftClick{

    NSLog(@"navigationLeftClick");

    [[self getAppDelegate].rootController back];

}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];

}

-(void)selectButton:(id)sender{

    NSLog(@"selectButton");

    UIButton* button = (UIButton*)sender;
    if(button.tag == 1002){
    
        ElderlyIphoneMyProfileSelectPictureViewController* selectPircutreViewController = [[ElderlyIphoneMyProfileSelectPictureViewController alloc] init];
        selectPircutreViewController.isHome = NO;
        [self.navigationController pushViewController:selectPircutreViewController animated:YES];
        [selectPircutreViewController release];
    
    }
    else if(button.tag == 1003){
    
        ElderlyIphoneMyProfileSecondViewController* secondViewController = [[ElderlyIphoneMyProfileSecondViewController alloc] init];
        [self.navigationController pushViewController:secondViewController animated:YES];
        [secondViewController release];
        
    }
}


-(void)resetPageControlImage{
    if ([pageControl respondsToSelector:@selector(pageIndicatorTintColor)]) {
        UIImage *pageIndicatorImage = [[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim.png"];
        UIImage *currentPageIndicatorImage = [[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim_on.png"];
        pageControl.pageIndicatorTintColor = [UIColor colorWithPatternImage:pageIndicatorImage];
        pageControl.currentPageIndicatorTintColor = [UIColor colorWithPatternImage:currentPageIndicatorImage];
    }else{
        NSArray *subView = pageControl.subviews;
        for (int i =0; i < [subView count]; i++){
            UIImageView *dot = [subView objectAtIndex:i];
            dot.image = (pageControl.currentPage == i ?[[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim_on.png"]:[[ElderlyThemeManager sharedInstance]imageByTheme:@"icon_dim.png"]);
        }
    }
}

-(void)btnLong:(UILongPressGestureRecognizer *)gestureRecognizer{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        
        [ElderlyAlertUtils showAlert:lang(@"Elderly") message:[NSString stringWithFormat:lang(@"deleteMessage"), lang(@"picture")] button:lang(@"confirm") cancelButton:lang(@"cancel") delegate:self];
        
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{

    if(buttonIndex == 1){
        [self getAppDelegate].profileSettingManager.userModel.portraitBigPath = nil;
        [self getAppDelegate].profileSettingManager.userModel.portraitPath = nil;
        [portraitButtonView setImage:[[self getAppDelegate].profileSettingManager readPortraitBig:nil] forState:UIControlStateNormal];
        [portraitButtonView removeGestureRecognizer:longPress];
        longPress = nil;
        [[self getAppDelegate].profileSettingManager deletePortraitFile:[ElderlyPathUtils getPortraitDocPath]];
    }

}

-(void)onGuideButtonClick:(UIButton*)button{

    if(guideView != nil){
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
            guideView.alpha=0.0f;
        } completion:^(BOOL finish){
            [guideView removeFromSuperview];
            
        }];
        
        [[ElderlyGuideMannager sharedInstance] setGudieState:profileSettingPictureGuide state:NO];
    }
}


@end
