//
//  MyActivityTabViewController.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 17/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyTabViewController.h"

@interface MyActivityTabViewController : ElderlyTabViewController

@end
