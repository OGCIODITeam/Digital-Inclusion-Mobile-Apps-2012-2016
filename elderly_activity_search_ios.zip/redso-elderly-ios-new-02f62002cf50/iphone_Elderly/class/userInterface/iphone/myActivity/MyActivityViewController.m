//
//  MyActivityViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "MyActivityViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ExpandSectionTableViewCell.h"
#import "ExpandTableViewCell.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyActivityDetailModel.h"
#import "ElderlyDatabaseManager.h"
#import "AsyncTask.h"
#import "ElderlyHTTPRequestManager.h"
#import "ElderlyNewActivityModel.h"
#import "ThreadTask.h"
#import "NewActivityViewController.h"
#import "ElderlyGA.h"
#import "ElderlySearchModel.h"
#import "GuideView.h"
#import "ElderlyAlertUtils.h"

@interface MyActivityViewController ()<UIAlertViewDelegate>

@property (retain, nonatomic) ThreadTask *task;
@property (retain, nonatomic) NSIndexPath *deleteIndexPath;
@end

@implementation MyActivityViewController
@synthesize task;
@synthesize tabVC;
@synthesize deleteIndexPath;

- (void)dealloc
{
    [self.task cancel];
    self.task = nil;
    self.tabVC = nil;
    self.deleteIndexPath = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
        self.isMonth = YES;
        self.isMyActivity = YES;
//        [self test];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_MYACTIVITY];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)themeChanged{
    [super themeChanged];
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myActivity")];
    
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"myActivity")];
    
}

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [[self getAppDelegate].rootController back];
    
}


- (NSInteger)themeIndx{
    return 2;
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

- (void)test{
    
    AsyncTask *httpTask = [[self getAppDelegate].httpRequestManager getActivityPageList:@"E"  offset:0 pageSize:20 ];
    [httpTask setFinishBlock:^{
        NSArray* array =[httpTask result];
        NSLog(@"array  %d", array.count);
        for(int i=0;i<array.count;i++){
            ElderlyNewActivityModel *activity = [array objectAtIndex:i];
            NSLog(@"activity  >>>  %@", activity.title);
            
            AsyncTask *task2 = [[self getAppDelegate].httpRequestManager getActivityDetail:@"E" cativityId:activity.activityId];
            [task2 setFinishBlock:^{
                ElderlyActivityDetailModel *detail = [task2 result];
                NSLog(@"detail.title  >>>  %@", detail.title);
                [[self getAppDelegate].databaseManager saveMyActivity:detail];
            }];
        }
    }];
    
//    ElderlyActivityDetailModel *detail = [[ElderlyActivityDetailModel alloc] init];
//    detail.activityId = @"1";
//    detail.nid = @"16818";
//    detail.centerId = @"";
//    detail.centerNid = @"";
//    detail.activityCenterName = @"梅艷芳長者日間護理中心";
//    detail.activityCenterName_tc = @"梅艷芳長者日間護理中心";
//    detail.title = @"香港中乐團慶祝長青網三周年呈獻冠軍以樂會友";
//    detail.title_tc = @"香港中乐團慶祝長青網三周年呈獻冠軍以樂會友";
//    detail.activityDescription = @"四王巧相逢，以樂會友！一場雲集當代音樂界頂尖水平的";
//    detail.activityDescription_tc = @"四王巧相逢，以樂會友！一場雲集當代音樂界頂尖水平的";
//    detail.activityDetail = @"當天晚上，古箏、二胡、口琴所編織的樂章，將會";
//    detail.activityDetail_tc = @"當天晚上，古箏、二胡、口琴所編織的樂章，將會";
//    detail.organlization = @"香港中樂團";
//    detail.organlization_tc = @"香港中樂團";
//    detail.categoriesValue = @"";
//    detail.categoriesValue_tc = @"";
//    detail.dateArray = [NSArray arrayWithObjects:@"2013-09-09", @"2013-09-10", nil];
//    detail.startTime = @"02:00";
//    detail.endTime = @"04:00";
//    detail.location = @"香港文化中心音樂廳";
//    detail.location_tc = @"香港文化中心音樂廳";
//    detail.fee = @"250";
//    detail.fee_tc = @"250";
//    detail.applicationMethod = @"請致電22676322或將姓名、聯繫電話及參與人數電郵至pcit@tungwah.org.hk";
//    detail.applicationMethod_tc = @"請致電22676322或將姓名、聯繫電話及參與人數電郵至pcit@tungwah.org.hk";
//    detail.activityTarget = @"任何人士";
//    detail.activityTarget_tc = @"任何人士";
//    detail.ageLowerLimit = @"";
//    detail.ageLowerLimit_tc = @"";
//    detail.eventType = @"";
//    detail.eventType_tc = @"";
//    detail.activeArea = @"中西區";
//    detail.activeArea_tc = @"中西區";
//    detail.remark = @"";
//    detail.remark_tc = @"";
//    detail.longitude = 113.2759952545166;
//    detail.latitude = 23.117055306224895;
//    detail.link = @"http://www.e123.hk/ElderlyPro/lcsdDetails/field_activity_code_value/nid";
//    detail.menberFee = @"";
//    detail.nonMenberFee = @"";
//    detail.menberFee_tc = @"";
//    detail.nonMenberFee_tc = @"";
//    detail.activityType = @"";
//    
//    [[self getAppDelegate].databaseManager saveMyActivity:detail];
//    
//    [detail release];
}

- (void)getActivityList{
    [self.loadingView startLoading];
    self.task = [ThreadTask asyncStart:^{
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"yyyy-MM";
        NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
        [dateFormatter release];
        
        self.centerList = [[self getAppDelegate].databaseManager findMyActivityByDate:dateStr];
        NSLog(@"centerList  >>>  %@", self.centerList);
    } end:^{
        [self.expandTableView reloadData];
        [self.loadingView stopLoading];
        
        if (self.centerList.count>0) {
            self.expandTableView.hidden = NO;
            self.noActivityLabel.hidden = YES;
            
            
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *hasBeenShow = [userDefaults objectForKey:@"myActivityGuide"];
            if (hasBeenShow==nil) {
                
                GuideView *guideView = [[GuideView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
                [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide12_%@.png"]];
                [guideView addTarget:self action:@selector(onGuideButtonClick:) forControlEvents:UIControlEventTouchUpInside];
                [self.view addSubview:guideView];
 
                
                [userDefaults setObject:@"hasBeenShow" forKey:@"myActivityGuide"];
            }
            
        }else{
            self.expandTableView.hidden = YES;
            self.noActivityLabel.hidden = NO;
            self.scrollImageView.hidden = YES;
        }
    }];
}

- (float)paddingTop{
    return 0;
}

- (CGRect)getViewFrame{
    CGRect rect = [[UIScreen mainScreen]bounds];
    rect.size.height-= (44.0f + 56.0f);
    return rect;
}

- (UINavigationController*)navigationController{
    return self.tabVC.navigationController;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
     DLog(@"indexPath  canEditRowAtIndexPath  >>>  %@", indexPath);
    
    return NO;
}

- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self deleteActivityWithIndexPath:indexPath];
    }
}

- (void)deleteActivityWithIndexPath:(NSIndexPath*) indexPath{
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:indexPath.section];
    DLog(@"indexPath  >>>  %@", indexPath);
    NSArray *activityList = searchModel.activityList;
    if (indexPath.row < activityList.count) {
        ElderlyNewActivityModel *activity = [activityList objectAtIndex:indexPath.row];
        [[self getAppDelegate].databaseManager deleteMyActivityById:activity.activityId activityType:activity.activityType];
        
        NSMutableArray *mArray = [[NSMutableArray alloc] initWithArray:activityList];
        [mArray removeObject:activity];
        searchModel.activityList = mArray;
        [mArray release];
        
        if (mArray.count==0) {
            NSMutableArray *cArray = [[NSMutableArray alloc] initWithArray:self.centerList];
            [cArray removeObject:searchModel];
            self.centerList = cArray;
            [cArray release];
        }
        
        [self.expandTableView deleteRowsAtIndexPath:indexPath withRowAnimation:UITableViewRowAnimationTop];
        
        if (self.centerList.count==0) {
            [self getActivityList];
        }
        
        //[self getActivityList];
    }

}

- (void)onGuideButtonClick:(UIButton*) button{
    [button removeFromSuperview];
}

- (void)onLongPassWithIndexPaht:(NSIndexPath*) indexPath{
    self.deleteIndexPath = indexPath;
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:indexPath.section];
    NSArray *activityList = searchModel.activityList;
    if (indexPath.row < activityList.count) {
        ElderlyNewActivityModel *activity = [activityList objectAtIndex:indexPath.row];
        
        [ElderlyAlertUtils showAlert:lang(@"Elderly") message:[NSString stringWithFormat:lang(@"deleteMessage"), [ElderlyUtils text:activity key:@"title"]] button:lang(@"confirm") cancelButton:lang(@"cancel") delegate:self];
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1) {
        [self deleteActivityWithIndexPath:self.deleteIndexPath];
    }
}

@end
