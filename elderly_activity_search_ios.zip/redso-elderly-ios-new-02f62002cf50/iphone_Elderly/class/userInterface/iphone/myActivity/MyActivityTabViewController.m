//
//  MyActivityTabViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 17/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "MyActivityTabViewController.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "MyActivityViewController.h"
#import "MyLCSDViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"

@interface MyActivityTabViewController ()

@end

@implementation MyActivityTabViewController



- (id)init
{
    self = [super init];
    if (self) {

    }
    return self;
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"myActivity")];
    
    
}

-(void)themeChanged{
    [super themeChanged];
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"myActivity")];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    [[self getAppDelegate].rootController back];
    
}

- (UIViewController*)getVCByIndex:(NSInteger) index{
    UIViewController *rVC = nil;
    if(index==0){
        MyActivityViewController *vc = [[[MyActivityViewController alloc] init] autorelease];
        vc.tabVC = self;
        rVC = vc;
        
    }
    else if(index==1){
        
        MyLCSDViewController *vc = [[[MyLCSDViewController alloc] init] autorelease];
        vc.tabVC = self;
        rVC = vc;
    }
    return rVC;
}

@end
