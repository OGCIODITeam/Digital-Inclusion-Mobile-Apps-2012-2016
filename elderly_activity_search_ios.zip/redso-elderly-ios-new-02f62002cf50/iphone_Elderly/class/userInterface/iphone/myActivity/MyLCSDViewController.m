//
//  MyLCSDViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 17/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "MyLCSDViewController.h"
#import "ThreadTask.h"
#import "LoadingView.h"
#import "AppDelegate.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyNewActivityModel.h"
#import "GuideView.h"
#import "ElderlyThemeManager.h"
#import "ElderlyAlertUtils.h"

@interface MyLCSDViewController ()<UIAlertViewDelegate>

@property (retain, nonatomic) ThreadTask *task;
@property (retain, nonatomic) NSIndexPath *deleteIndexPath;

@end

@implementation MyLCSDViewController
@synthesize task;
@synthesize tabVC;
@synthesize deleteIndexPath;

- (void)dealloc
{
    self.task = nil;
    self.tabVC = nil;
    self.deleteIndexPath = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.isMonth = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UILongPressGestureRecognizer * longPressGr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressToDo:)];
    longPressGr.minimumPressDuration = 0.5;
    [self.lcsdTableView addGestureRecognizer:longPressGr];
    [longPressGr release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)getActivityList{
    [self.loadingView startLoading];
    self.task = [ThreadTask asyncStart:^{
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"yyyy-MM-dd";
        NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
        [dateFormatter release];
        
        self.activityList = [[self getAppDelegate].databaseManager findMyLCSDByDate:dateStr];
        NSLog(@"centerList  >>>  %@", self.activityList);
    } end:^{
        [self.lcsdTableView reloadData];
        [self.loadingView stopLoading];
        
        if (self.activityList.count>0) {
            self.lcsdTableView.hidden = NO;
            self.noActivityLabel.hidden = YES;
            
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *hasBeenShow = [userDefaults objectForKey:@"myActivityGuide"];
            if (hasBeenShow==nil) {
                GuideView *guideView = [[GuideView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
                [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide12_%@.png"]];
                [guideView addTarget:self action:@selector(onGuideButtonClick:) forControlEvents:UIControlEventTouchUpInside];
                [self.view addSubview:guideView];
                
                [userDefaults setObject:@"hasBeenShow" forKey:@"myActivityGuide"];
            }
        }else{
            self.lcsdTableView.hidden = YES;
            self.noActivityLabel.hidden = NO;
            self.scrollImageView.hidden = YES;
        }
    }];
}

- (UINavigationController*)navigationController{
    return self.tabVC.navigationController;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
   
    return NO;
}

- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        
        [self deleteActivityWithIndexPath:indexPath];
        
    }
}

- (void)deleteActivityWithIndexPath:(NSIndexPath*) indexPath{
    ElderlyNewActivityModel *activity = [self.activityList objectAtIndex:indexPath.row];
    [[self getAppDelegate].databaseManager deleteMyActivityById:activity.activityId activityType:activity.activityType];
    
    NSMutableArray *mArray = [[NSMutableArray alloc] initWithArray:self.activityList];
    [mArray removeObject:activity];
    self.activityList = mArray;
    [mArray release];
    [self.lcsdTableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationTop];
    
    if (self.activityList.count==0) {
        [self getActivityList];
    }
}

- (void)onGuideButtonClick:(UIButton*) button{
    [button removeFromSuperview];
}

- (void)longPressToDo:(UILongPressGestureRecognizer *)gesture{
    DLog(@" longPressToDo >>> sender >>>  %@", gesture);
    if(gesture.state == UIGestureRecognizerStateBegan)
    {
        CGPoint point = [gesture locationInView:self.lcsdTableView];
        NSIndexPath * indexPath = [self.lcsdTableView indexPathForRowAtPoint:point];
        self.deleteIndexPath = indexPath;
        
        ElderlyNewActivityModel *activity = [self.activityList objectAtIndex:indexPath.row];
        
        [ElderlyAlertUtils showAlert:lang(@"Elderly") message:[NSString stringWithFormat:lang(@"deleteMessage"), [ElderlyUtils text:activity key:@"title"]] button:lang(@"confirm") cancelButton:lang(@"cancel") delegate:self];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1) {
        [self deleteActivityWithIndexPath:self.deleteIndexPath];
    }
}

@end
