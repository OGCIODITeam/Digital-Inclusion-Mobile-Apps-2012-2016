//
//  MyLCSDViewController.h
//  iphone_Elderly
//
//  Created by Henry.Yu on 17/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "LCSDViewController.h"
#import "ElderlyTabViewController.h"

@interface MyLCSDViewController : LCSDViewController

@property (assign, nonatomic) ElderlyTabViewController *tabVC;

@end
