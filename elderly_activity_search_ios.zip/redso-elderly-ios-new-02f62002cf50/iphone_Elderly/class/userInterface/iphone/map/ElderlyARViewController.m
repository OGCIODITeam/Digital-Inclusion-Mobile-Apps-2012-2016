//
//  ElderlyARViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-24.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyARViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ElderlyActivityDetailModel.h"
#import "ARGeoViewController.h"
#import "ARGeoCoordinate.h"
#import <MapKit/MapKit.h>
#import "ElderlyAlertUtils.h"


@interface ElderlyARViewController ()<ARViewDelegate,UIImagePickerControllerDelegate>

@property(nonatomic,retain)UIImagePickerController* imagePicker;
-(void)initTopBar;

@end

@implementation ElderlyARViewController


@synthesize detailModel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
//        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    viewController = [[ARGeoViewController alloc] init];
    viewController.view.frame = self.view.bounds;
	viewController.debugMode = NO;
	viewController.delegate = self;

    CLLocation* tempLocation = [[CLLocation alloc] initWithLatitude:self.detailModel.latitude longitude:self.detailModel.longitude];
//    CLLocation* tempLocation = [[CLLocation alloc] initWithLatitude:23.12911 longitude:113.3188];

	ARGeoCoordinate* tempCoordinate = [ARGeoCoordinate coordinateWithLocation:tempLocation];
	tempCoordinate.title = [ElderlyUtils text:self.detailModel key:@"organlization"];
    tempCoordinate.subtitle = [ElderlyUtils text:self.detailModel key:@"activityCenterName"];
    [viewController addCoordinate:tempCoordinate];
    [tempLocation release];
    
    
    //HK 观塘 坐标
    CLLocation *newCenter = [[CLLocation alloc] initWithLatitude:22.318319 longitude: 114.228973];
//    CLLocation *newCenter = [[CLLocation alloc] initWithLatitude:23.12910 longitude:113.3188];
	viewController.centerLocation = newCenter;
	[newCenter release];
	[viewController startListening];

//    [self.view addSubview: viewController.view];
    
    [self initTopBar];
    
    self.imagePicker = [[[UIImagePickerController alloc]init]autorelease];
    self.imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    self.imagePicker.showsCameraControls = NO;
    self.imagePicker.cameraOverlayView = viewController.view;
    self.imagePicker.cameraViewTransform = CGAffineTransformMakeScale(1.3f, 1.3f);
    self.imagePicker.allowsEditing = NO;
    [[self getAppDelegate].rootController presentModalViewController: self.imagePicker animated: YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
  
    viewController.delegate = nil;
//    [locationManager stopUpdatingLocation];
//    [locationManager release];
    self.imagePicker = nil;
    self.detailModel = nil;
  
    [super dealloc];
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"liveNav")];
   
    
}


-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"liveNav")];
    
}

#pragma mark methods


-(void)initTopBar{
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    
    float spacing = 0.0f;
    if([ElderlyUtils systemVersion] >= 7.0){
        spacing = 20.0f;
    }
    
    UIImageView* topBarBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width,img.size.height+spacing )];
    topBarBgView.userInteractionEnabled = YES;
    topBarBgView.image = img;
    
    
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 200)*0.5f, spacing+5, 200, img.size.height-10)];
    
    [titleLabel theme:@"mainPage_title"];
    titleLabel.text = lang(@"liveNav");
    
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [topBarBgView addSubview:titleLabel];
    [titleLabel release];
    
//    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_location.png"];
//    UIButton* settingButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    [settingButton setImage:img forState:UIControlStateNormal];
//    settingButton.frame = CGRectMake(self.view.bounds.size.width-img.size.width, 0, img.size.width, img.size.height);
//    [settingButton addTarget:self action:@selector(navigationRightClick) forControlEvents:UIControlEventTouchUpInside];
//    [topBarBgView addSubview:settingButton];
    
    img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_back.png"];
    UIButton* backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:img forState:UIControlStateNormal];
    [backButton setAccessibilityLabel:lang(@"back")];
    backButton.frame = CGRectMake(0, spacing+0, img.size.width, img.size.height);
    [backButton addTarget:self action:@selector(navigationLeftClick) forControlEvents:UIControlEventTouchUpInside];
    [topBarBgView addSubview:backButton];
    
    [viewController.view addSubview:topBarBgView];
    [topBarBgView release];
}


-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
                                          
    [[self getAppDelegate].rootController dismissModalViewControllerAnimated: NO];
    [self.navigationController popViewControllerAnimated:NO];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
//     [[self getAppDelegate].rootController dismissModalViewControllerAnimated: NO];
//    
//    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSString* errorMsg = nil;
    switch (error.code) {
        case kCLErrorLocationUnknown:
            errorMsg = lang(@"GPS_erroe_locationUnknown");
            break;
        case kCLErrorDenied:
            errorMsg = lang(@"GPS_error_denied");
            break;
        case kCLErrorNetwork:
            errorMsg = lang(@"GPS_erroe_locationUnknown");
            break;
        default:
            errorMsg = lang(@"GPS_erroe_locationUnknown");
            break;
    }
    
    if (errorMsg != nil) {
        [ElderlyAlertUtils showAlert:errorMsg delegate:nil];
    }
}


#define BOX_WIDTH 188
#define BOX_HEIGHT 133

- (UIView *)viewForCoordinate:(ARCoordinate *)coordinate {
	
	CGRect theFrame = CGRectMake(0, 0, BOX_WIDTH, BOX_HEIGHT);
	UIView *tempView = [[UIView alloc] initWithFrame:theFrame];
    

    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 10.0f, BOX_WIDTH-10, 18.0)];
    [titleLabel theme:@"AR_Title"];
	titleLabel.text = coordinate.title;
    titleLabel.textAlignment = UITextAlignmentCenter;
//	[titleLabel sizeToFit];
//	titleLabel.frame = CGRectMake(BOX_WIDTH / 2.0 - titleLabel.frame.size.width / 2.0 - 4.0, 46.0f, titleLabel.frame.size.width + 8.0, titleLabel.frame.size.height + 8.0);

    
    UILabel* centreNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(titleLabel.frame)+5, BOX_WIDTH-10, 18.0f)];
    centreNameLabel.text = coordinate.subtitle;
    centreNameLabel.textAlignment = UITextAlignmentCenter;
    [centreNameLabel theme:@"AR_Title"];
    

    UIImageView *pointView = [[UIImageView alloc] initWithFrame: CGRectZero];
	pointView.image = [[ElderlyThemeManager sharedInstance] imageByMotif:@"txt_box02_%@.png"];
	pointView.frame = CGRectMake((int)(BOX_WIDTH / 2.0 - pointView.image.size.width / 2.0), (int)(BOX_HEIGHT / 2.0 - pointView.image.size.height / 2.0), pointView.image.size.width,pointView.image.size.height);
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"map_white_line.png"];
    UIImageView* lineImageView = [[UIImageView alloc] initWithFrame:CGRectMake(pointView.frame.origin.x+2,(pointView.frame.size.height-img.size.height)*0.4f ,pointView.frame.size.width-4 , img.size.height)];
    lineImageView.image = img;
    [pointView addSubview:lineImageView];
    [lineImageView release];
    
    
    UILabel *distanceLabel = [[UILabel alloc]initWithFrame: CGRectMake(5, CGRectGetMaxY(lineImageView.frame)+5, BOX_WIDTH-10, 18.0)];
	distanceLabel.textAlignment = UITextAlignmentCenter;
    [distanceLabel setTag:10001];
    [distanceLabel theme:@"AR_Title"];
    
    UILabel* loctionLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(distanceLabel.frame)+5, BOX_WIDTH-10, 18.0)];
    loctionLabel.text = [ElderlyUtils text:self.detailModel key:@"location"];
    loctionLabel.textAlignment = UITextAlignmentCenter;
    [loctionLabel theme:@"AR_Title"];
    

	[tempView addSubview:pointView];
    [tempView addSubview:titleLabel];
    [tempView addSubview:centreNameLabel];
    [tempView addSubview:distanceLabel];
    [tempView addSubview:loctionLabel];
	
    [pointView release];
    [titleLabel release];
    [distanceLabel release];
    [loctionLabel release];
    [centreNameLabel release];
	return [tempView autorelease];
}

@end
