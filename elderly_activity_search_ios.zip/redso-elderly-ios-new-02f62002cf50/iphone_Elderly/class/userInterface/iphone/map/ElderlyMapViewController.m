//
//  ElderlyMapViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-23.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyMapViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import <MapKit/MapKit.h>
#import "ElderlyAlertUtils.h"
#import "ElderlyMapAnnotaion.h"
#import "ElderlyMapDetailView.h"
#import "ElderlyActivityDetailModel.h"
#import "ElderlyARViewController.h"
#import "ElderlyGA.h"

//#define DISTANCE_FILTER 1000.0f
#define ZOOMLEVEL 0.02

@interface ElderlyMapViewController () <MKMapViewDelegate, CLLocationManagerDelegate>

- (void)initLocationManager;
- (void)initLiveNavigationButton;


@end

@implementation ElderlyMapViewController

@synthesize activityDetailMode;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
		// Custom initialization
		self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
		self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_location.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view.

	elderlyMapView = [[MKMapView alloc] initWithFrame:self.view.bounds];
	elderlyMapView.delegate = self;
	elderlyMapView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	elderlyMapView.showsUserLocation = YES;
	elderlyMapView.userLocation.title = nil;
	[self.view addSubview:elderlyMapView];

	[elderlyMapView release];




	CLLocationCoordinate2D coordinate2D = CLLocationCoordinate2DMake(activityDetailMode.latitude, activityDetailMode.longitude);
	float zoomLevel = ZOOMLEVEL;
	MKCoordinateRegion region = MKCoordinateRegionMake(coordinate2D, MKCoordinateSpanMake(zoomLevel, zoomLevel));
	[elderlyMapView setRegion:[elderlyMapView regionThatFits:region] animated:YES];

	ElderlyMapAnnotaion *mapAnnotation = [[ElderlyMapAnnotaion alloc] initWithLatitude:activityDetailMode.latitude andLongitude:activityDetailMode.longitude];
	[elderlyMapView addAnnotation:mapAnnotation];
	[mapAnnotation release];



	[self initLiveNavigationButton];
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

- (void)dealloc {
	[locationManager stopUpdatingLocation];
	self.activityDetailMode = nil;
	[locationManager release];
	[super dealloc];
}

- (void)willShowViewController {
	ElderlyNavigationController *nav = (ElderlyNavigationController *)self.navigationController;
	[nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
	[nav titleView:lang(@"newActivityDetailBtn_map")];
}

- (void)themeChanged {
	ElderlyNavigationController *nav = (ElderlyNavigationController *)self.navigationController;
	[nav titleView:lang(@"newActivityDetailBtn_map")];
}

#pragma mark methods
- (void)navigationLeftClick {
	NSLog(@"navigationLeftClick");
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)navigationRightClick {
	NSLog(@"navigationRightClick");
//    [locationManager stopUpdatingLocation];
	[[ElderlyGA sharedInstance] trackEvent:GA_CODE_CURRENTLOCATIONBUTTON];
	[self initLocationManager];
}

- (void)initLiveNavigationButton {
	UIImage *img = [[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_navigation_%@.png"];
	UIButton *liveNavButton = [[UIButton alloc] initWithFrame:CGRectMake(self.view.bounds.size.width - img.size.width - 15, self.view.bounds.size.height - img.size.height * 0.5f - 20, img.size.width, img.size.height)];
	[liveNavButton setBackgroundImage:img forState:UIControlStateNormal];
	[liveNavButton addTarget:self action:@selector(clickLiveNavButton) forControlEvents:UIControlEventTouchUpInside];

	[liveNavButton setAccessibilityLabel:lang(@"liveNav")];
	UILabel *liveTitle = [[UILabel alloc] initWithFrame:CGRectMake(3, 0, img.size.width - 25, img.size.height)];
	[liveTitle theme:@"liveTitle"];
	liveTitle.text = lang(@"liveNav");
	liveTitle.textAlignment = UITextAlignmentCenter;
	[liveNavButton addSubview:liveTitle];
	[liveTitle release];


	[self.view addSubview:liveNavButton];
	[liveNavButton release];
}

- (void)initLocationManager {
	[self clearMapDetail];
	if (locationManager == nil) {
		locationManager = [[CLLocationManager alloc] init];
		locationManager.delegate = self;
		locationManager.desiredAccuracy = kCLLocationAccuracyBest; // 越精确，越耗电！
	}
	[locationManager startUpdatingLocation];
}

- (void)clickLiveNavButton {
	DLog(@"clickLiveNavButton");

	[[ElderlyGA sharedInstance] trackEvent:GA_CODE_ARBUTTON ActionCode:GA_CODE_CLICK LabelCode:[NSString stringWithFormat:@"%@_%@", self.activityDetailMode.activityId, self.activityDetailMode.title_tc]];

	ElderlyARViewController *arViewController = [[ElderlyARViewController alloc] init];
	arViewController.detailModel = self.activityDetailMode;
	[self.navigationController pushViewController:arViewController animated:YES];
	[arViewController release];
}

- (void)bubbleClick:(UIButton *)button {
	DLog(@"bubbleClick");

	MKAnnotationView *view = (MKAnnotationView *)button.superview;
	[elderlyMapView bringSubviewToFront:view];


	[self clearMapDetail];
	elderlyMapView.userInteractionEnabled = NO;
	float zoomLevel = ZOOMLEVEL;
	MKCoordinateRegion region = MKCoordinateRegionMake(view.annotation.coordinate, MKCoordinateSpanMake(zoomLevel, zoomLevel));
	[elderlyMapView setRegion:[elderlyMapView regionThatFits:region] animated:NO];

	delayShowMapDetailTimer = [NSTimer scheduledTimerWithTimeInterval:0.5f target:self selector:@selector(delayShowMapDetail) userInfo:view repeats:NO];

	[[ElderlyGA sharedInstance] trackEvent:GA_CODE_PIN ActionCode:GA_CODE_CLICK LabelCode:[NSString stringWithFormat:@"%@_%@", self.activityDetailMode.activityId, self.activityDetailMode.title_tc]];
}

- (void)clickDetailButton {
	NSLog(@"clickDetailButton");

	[[ElderlyGA sharedInstance] trackEvent:GA_CODE_ACTIVITYDETAILBUTTON ActionCode:GA_CODE_CLICK LabelCode:[NSString stringWithFormat:@"%@_%@", self.activityDetailMode.activityId, self.activityDetailMode.title_tc]];

	[self.navigationController popViewControllerAnimated:YES];
}

- (void)clearMapDetail {
	elderlyMapView.userInteractionEnabled = YES;
	[delayShowMapDetailTimer invalidate];
	delayShowMapDetailTimer = nil;
	[mapDetailView removeFromSuperview];
	mapDetailView = nil;
}

- (void)delayShowMapDetail {
	MKAnnotationView *view = (MKAnnotationView *)delayShowMapDetailTimer.userInfo;
	[mapDetailView removeFromSuperview];
	mapDetailView = [[ElderlyMapDetailView alloc] initWithFrame:CGRectMake(7, 10, 0, 0)];

	CGPoint point = [elderlyMapView convertCoordinate:view.annotation.coordinate toPointToView:elderlyMapView];
	if ([ElderlyUtils isRetain4]) {
		point.x -= 10;
		point.y = 355;
	}
	else {
		point.y = 110;
		point.x -= 10;
	}

	CLLocationCoordinate2D coordinate2D = [elderlyMapView convertPoint:point toCoordinateFromView:elderlyMapView];
	[elderlyMapView setCenterCoordinate:coordinate2D animated:YES];

	[mapDetailView setTitle:[ElderlyUtils text:activityDetailMode key:@"title"]];

	if (activityDetailMode.dateArray != nil && activityDetailMode.dateArray.count > 0) {
		NSString *date = nil;
		date = [activityDetailMode.dateArray objectAtIndex:0];
		date = [ElderlyUtils converDateStringFromeString:date];
		if (date != nil)
			[mapDetailView setDate:date];
	}
	if (activityDetailMode.startTime.length > 0 && activityDetailMode.endTime.length > 0)
		[mapDetailView setTime:[NSString stringWithFormat:lang(@"map_timeFrome"), activityDetailMode.startTime, activityDetailMode.endTime]];

	[mapDetailView setAddress:[ElderlyUtils text:activityDetailMode key:@"location"]];
//    if(activityDetailMode.endDate != nil && activityDetailMode.endDate.length > 0){
//        NSString* date = activityDetailMode.endDate;
//        date = [ElderlyUtils converDateStringFromeString:date];
//        if(date != nil)
//            [mapDetailView setEndDate:date];
//    }

	if (activityDetailMode.applicationMethod.length > 0)
		[mapDetailView setRegistration:[ElderlyUtils text:activityDetailMode key:@"applicationMethod"]];

	[mapDetailView addTarget:self action:@selector(clickDetailButton)];

	[elderlyMapView addSubview:mapDetailView];
	[mapDetailView showAnimation];
	[mapDetailView release];

	[delayShowMapDetailTimer invalidate];
	delayShowMapDetailTimer = nil;

	elderlyMapView.userInteractionEnabled = YES;
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	NSString *errorMsg = nil;
	switch (error.code) {
		case kCLErrorLocationUnknown:
			errorMsg = lang(@"GPS_erroe_locationUnknown");
			break;

		case kCLErrorDenied:
			errorMsg = lang(@"GPS_error_denied");
			break;

		case kCLErrorNetwork:
			errorMsg = lang(@"GPS_erroe_locationUnknown");
			break;

		default:
			errorMsg = lang(@"GPS_erroe_locationUnknown");
			break;
	}

	if (errorMsg != nil) {
		[ElderlyAlertUtils showAlert:errorMsg delegate:nil];
	}
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
//    DLog(@"oldLocation.coordinate.timestamp:%@", oldLocation.timestamp);
//    DLog(@"oldLocation.coordinate.longitude:%f", oldLocation.coordinate.longitude);
//    DLog(@"oldLocation.coordinate.latitude:%f", oldLocation.coordinate.latitude);
//    DLog(@"newLocation.coordinate.timestamp:%@", newLocation.timestamp);
//    DLog(@"newLocation.coordinate.longitude:%f", newLocation.coordinate.longitude);
//    DLog(@"newLocation.coordinate.latitude:%f", newLocation.coordinate.latitude);
//    NSTimeInterval interval = [newLocation.timestamp timeIntervalSinceDate:oldLocation.timestamp];
//    NSLog(@"%lf", interval);
//    // 取到精确GPS位置后停止更新
//    if (interval < 3) {
//        // 停止更新
//        [locationManager stopUpdatingLocation];
//    }
	//    latitudeLabel.text = [NSString stringWithFormat:@"%f", newLocation.coordinate.latitude];
	//    longitudeLabel.text = [NSString stringWithFormat:@"%f", newLocation.coordinate.longitude];

	[locationManager stopUpdatingLocation];

	DLog(@"newLocation.coordinate.longitude:%f", newLocation.coordinate.longitude);
	DLog(@"newLocation.coordinate.latitude:%f", newLocation.coordinate.latitude);

	CLLocationCoordinate2D coordinate2D = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
	float zoomLevel = ZOOMLEVEL;
	MKCoordinateRegion region = MKCoordinateRegionMake(coordinate2D, MKCoordinateSpanMake(zoomLevel, zoomLevel));
	[elderlyMapView setRegion:[elderlyMapView regionThatFits:region] animated:YES];


//    [elderlyMapView setCenterCoordinate:coordinate2D animated:YES];
}

#pragma mark MKMapView Delegate
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation> )annotation {
	if ([annotation isKindOfClass:[ElderlyMapAnnotaion class]]) {  //创建地图图标
		MKAnnotationView *annotationView = [elderlyMapView dequeueReusableAnnotationViewWithIdentifier:@"CustomAnnotation"];
		if (!annotationView) {
			annotationView = [[[MKAnnotationView alloc] initWithAnnotation:annotation
			                                               reuseIdentifier:@"CustomAnnotation"] autorelease];

			UIButton *but = [UIButton buttonWithType:UIButtonTypeCustom];
			[but addTarget:self action:@selector(bubbleClick:) forControlEvents:UIControlEventTouchDown];
			but.frame = CGRectMake(0, 0, 45, 61);
			but.tag = 9999;
			[annotationView addSubview:but];
		}
		annotationView.enabled = YES;
		annotationView.canShowCallout = YES;


		UIImage *image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_location.png"];
		annotationView.image = image;


		// set accessibiliy label and focus

		[annotationView setAccessibilityLabel:[ElderlyUtils text:activityDetailMode key:@"location"]];
		UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, annotationView);

		return annotationView;
	}
	return nil;
}

- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated {
	if (!animated) {
		[self clearMapDetail];
	}
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
}

@end
