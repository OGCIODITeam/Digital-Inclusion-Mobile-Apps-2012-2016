//
//  ElderlyActivityListViewController.m
//  iphone_Elderly
//
//  Created by Henry.Yu on 9/9/13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyActivityListViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ExpandSectionTableViewCell.h"
#import "ExpandTableViewCell.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyActivityDetailModel.h"
#import "ElderlyDatabaseManager.h"
#import "ThreadTask.h"
#import "ElderlySearchModel.h"
#import "ElderlyNewActivityModel.h"
#import "ActivityDetailViewController.h"
#import "AsyncTask.h"
#import "ElderlyHTTPRequestManager.h"
#import "ElderlyUtils.h"
#import "ElderlyGA.h"
#import "ThreadTask.h"

@interface ElderlyActivityListViewController ()

@property(retain,nonatomic)ThreadTask* thradTask;
@property(retain,nonatomic)ElderlyActivityDetailModel* activityDetailModel;

@end

@implementation ElderlyActivityListViewController
@synthesize noActivityLabel;
@synthesize expandTableView;
@synthesize calendarHeaderView;
@synthesize calendarView;
@synthesize centerList;
@synthesize currentDate;
@synthesize loadingView;
@synthesize isMonth;
@synthesize monthView;
@synthesize activityDetailModel;
@synthesize thradTask;
@synthesize isMyActivity;

- (void)dealloc
{
    self.noActivityLabel = nil;
    self.expandTableView = nil;
    self.calendarHeaderView = nil;
    self.calendarView = nil;
    self.centerList = nil;
    self.currentDate = nil;
    self.loadingView = nil;
    self.monthView = nil;
    self.thradTask = nil;
    self.activityDetailModel = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.isMonth = NO;
        self.isMyActivity = NO;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.view.frame = [self getViewFrame];
    
    CGRect calendarHeaderFrame = CGRectMake(0, [self paddingTop], self.view.frame.size.width, 37);
    CalendarHeaderView *tmpCalendarHeaderView = [[CalendarHeaderView alloc] initWithFrame:calendarHeaderFrame dateFormat:self.isMonth?lang(@"dateFormat2"):lang(@"dateFormat")];
    [self.view addSubview:tmpCalendarHeaderView];
    [tmpCalendarHeaderView setDate:[NSDate date]];
    tmpCalendarHeaderView.deleagte = self;
    self.calendarHeaderView = tmpCalendarHeaderView;
    [tmpCalendarHeaderView release];
    

    ExpandTableView *tmpExpandTableView = [[ExpandTableView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(self.calendarHeaderView.frame), self.view.frame.size.width, self.view.frame.size.height-CGRectGetMaxY(self.calendarHeaderView.frame))];
    [tmpExpandTableView setAccessibilityViewIsModal:YES];
    tmpExpandTableView.expandDelegate = self;
    [self.view addSubview:tmpExpandTableView];
    self.expandTableView = tmpExpandTableView;
    [tmpExpandTableView release];
    
    [self createTableFooter];
    
    NSDate *date = [NSDate date];
    self.currentDate = date;
    
    LoadingView *tmpLoadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview: tmpLoadingView];
    [tmpLoadingView release];
    self.loadingView = tmpLoadingView;
    
    
    UILabel *label = [[UILabel alloc] init];
    label.text = lang(@"noActivity");
    label.backgroundColor = [UIColor clearColor];
    [label sizeToFit];
    label.hidden = YES;
    label.textAlignment = UITextAlignmentCenter;
    label.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    [self.view addSubview:label];
    self.noActivityLabel = label;
    [label release];
    
    [self.view bringSubviewToFront:self.calendarHeaderView];
    [self getActivityList];
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma marks - CalendarHeaderViewDelegate Methods
- (void)onHeaderClick{
    
    if(self.calendarView != nil || self.monthView != nil)
        return;
    
    
    if([ElderlyThemeManager sharedInstance].gridIndex == 1 || [ElderlyThemeManager sharedInstance].gridIndex == 2){
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_DATE];
    }
    
    CGRect rect =self.view.frame;
    rect.origin.y = 0;
    if(rect.size.height > 568)
        rect.size.height = 568;
    
    if(self.isMonth){
        MonthView *tmpMonthView = [[MonthView alloc] initWithFrame:rect andDate:[self.calendarHeaderView getDate]];
        tmpMonthView.delegate = self;
        [self.view addSubview:tmpMonthView];
        self.monthView = tmpMonthView;
        [tmpMonthView release];
    }
    else{
        CalendarView *tmpCalendarView = [[CalendarView alloc] initWithFrame:rect andDate:[self.calendarHeaderView getDate]];
        tmpCalendarView.delegate = self;
        [self.view addSubview:tmpCalendarView];
        self.calendarView = tmpCalendarView;
        [tmpCalendarView release];
    }

}
- (void)onLeftButtonClick{
    
    [self changeDay:-1];
}
- (void)onRightButtonClick{
    [self changeDay:1];
}

- (void)changeDay:(int) day{
    unsigned units  = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    NSCalendar *cal = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *currentComp = [cal components:units fromDate:self.currentDate];
    

    if (day>0) {
        self.isMonth?[currentComp setMonth:currentComp.month + 1]:[currentComp setDay:currentComp.day + 1];
    }else{
        self.isMonth?[currentComp setMonth:currentComp.month - 1]:[currentComp setDay:currentComp.day - 1];
    }
    
  
    
    NSDate *date = [cal dateFromComponents:currentComp];
    [self.calendarHeaderView setDate:date];
    self.currentDate = date;
    [self getActivityList];
    [cal release];
}


#pragma marks - CalendarViewDelegate Methods
- (void)onDateSelect:(NSDate*) date{
    
    self.currentDate = date;
    [self getActivityList];
    
    [self.calendarHeaderView setDate:date];
    [self.calendarView removeFromSuperview];
    self.calendarView = nil;
 
}

- (void)onNoDateSelect{
    [self.calendarView removeFromSuperview];
    self.calendarView = nil;
}

#pragma marks - MonthViewDelegate Methods
-(void)onMonthSelect:(NSDate *)date{

    self.currentDate = date;
    [self getActivityList];
    [self.calendarHeaderView setDate:date];
    [self.monthView removeFromSuperview];
    self.monthView = nil;
}


-(void)onNoMonthSelect{
    [self.monthView removeFromSuperview];
    self.monthView = nil;
}


#pragma marks - ExpandTableViewDelegate Methods
- (NSInteger)numberOfSectionsInTableView:(ExpandTableView *)tableView{
    NSLog(@"self.centerList.count >>>  %d", self.centerList.count);
    return self.centerList.count;
}

- (NSInteger)tableView:(ExpandTableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:section];
    NSLog(@"searchModel.activityList.count >>>  %d", searchModel.activityList.count);
    return searchModel.activityList.count;
}

- (UITableViewCell *)tableView:(ExpandTableView *)tableView sectionViewAtSection:(NSInteger) section{
    NSString *key = @"sectionView";
    UITableViewCell *tmp = [tableView dequeueReusableCellWithIdentifier:key];
    ExpandSectionTableViewCell *cell = nil;
    if (tmp!=nil && [tmp isKindOfClass:[ExpandSectionTableViewCell class]]) {
        cell = (ExpandSectionTableViewCell*)tmp;
    }else{
        cell = [[[ExpandSectionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:key] autorelease];
        
        
        
    }
    
    ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
    [cell setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByTheme:theme.header]];
    [cell setExpand:[[ElderlyThemeManager sharedInstance] imageByTheme:theme.arrowUp] forStatus:ExpandSectionTableViewCellStatusOpen];
    [cell setExpand:[[ElderlyThemeManager sharedInstance] imageByTheme:theme.arrowDown] forStatus:ExpandSectionTableViewCellStatusClose];
    
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:section];
    
    [cell setSectionTitle:[ElderlyUtils text:searchModel key:@"organization"]];
    [cell setSectionSubTitle:[ElderlyUtils text:searchModel key:@"activityCenterName"]];
    return cell;
}

- (UITableViewCell *)tableView:(ExpandTableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *key = @"detailView";
    UITableViewCell *tmp = [tableView dequeueReusableCellWithIdentifier:key];
    ExpandTableViewCell *cell = nil;
    if (tmp!=nil && [tmp isKindOfClass:[ExpandTableViewCell class]]) {
        cell = (ExpandTableViewCell*)tmp;
    }else{
        cell = [[[ExpandTableViewCell alloc] initWithCellType:ExpandTableViewCellStyleCenter reuseIdentifier:key] autorelease];
    }
    
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:indexPath.section];
    DLog(@"indexPath  >>>  %@", indexPath);
    NSArray *activityList = searchModel.activityList;
    if (indexPath.row < activityList.count) {
        ElderlyNewActivityModel *activity = [activityList objectAtIndex:indexPath.row];
        
        [cell setExpandTitle:[ElderlyUtils text:activity key:@"title"]];
        [cell setType:[ElderlyUtils text:activity key:@"eventType"]];
        [cell setDate:activity.activityDateArray];
        [cell setTimeFrom:activity.stratTime to:activity.endTime];
        if (activity.fee.length>0) {
            
            [cell setPrice:[ElderlyUtils text:activity key:@"fee"]];
            [cell hidPrice:NO];
        }else{
            [cell hidPrice:YES];
        }
    
    }
    
    
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForSection:(NSInteger)section{
    return 60;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat height = 120;
    
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:indexPath.section];
    NSArray *activityList = searchModel.activityList;
    if (indexPath.row < activityList.count) {
        ElderlyNewActivityModel *activity = [activityList objectAtIndex:indexPath.row];
        if (activity.fee.length>0) {
            height = 120;
        }else{
            height = 120 - 16;
        }

    }
    return height;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"didSelectRowAtIndexPath  》》》  ");
    
    [self.loadingView startLoading];
    
    ElderlySearchModel *searchModel = [self.centerList objectAtIndex:indexPath.section];
    NSArray *activityList = searchModel.activityList;
    ElderlyNewActivityModel *oneActivity = [activityList objectAtIndex:indexPath.row];
    
    if(self.isMyActivity){
        self.thradTask = [ThreadTask asyncStart:^{
        self.activityDetailModel = [[self getAppDelegate].databaseManager getMyActivityDetail:oneActivity.activityId activityType:@"E"];
            
        } end:^{
            
            [self.loadingView stopLoading];

            if(self.activityDetailModel == nil){
            
                return ;
            }
            ActivityDetailViewController *controller=[[ActivityDetailViewController alloc]init];
            //     controller.theBannerArray=[NSArray arrayWithArray:self.bannerArray];
            controller.theActivity=self.activityDetailModel;
            ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
            NSString *colorStr = theme.color;
            UIColor *color = [ElderlyUtils colorConvertFromString:colorStr];
            
            [self.navigationController pushViewController:controller animated:YES];
            [controller setTitleBackGroundColor:color];
            //[controller.theBannerArray release];
            // controller.theBannerArray=nil;
            [controller release];
            
                   }];
        

    
        return;
    }
    
    
    AsyncTask  *asyncTask = [[self getAppDelegate].httpRequestManager getActivityDetail:@"E" cativityId:oneActivity.activityId];
    
    [asyncTask setFinishBlock:^{
        
        ElderlyActivityDetailModel* detail = [asyncTask result];
        if(detail != nil){
            
            ActivityDetailViewController *controller=[[ActivityDetailViewController alloc]init];
            //     controller.theBannerArray=[NSArray arrayWithArray:self.bannerArray];
            controller.theActivity=detail;
            ElderlyThemeGridModel *theme = [[ElderlyThemeManager sharedInstance] getThemeGridModel];
            NSString *colorStr = theme.color;
            UIColor *color = [ElderlyUtils colorConvertFromString:colorStr];
            
            [self.navigationController pushViewController:controller animated:YES];
            [controller setTitleBackGroundColor:color];
            //[controller.theBannerArray release];
            // controller.theBannerArray=nil;
            [controller release];
            
        }
        [self.loadingView stopLoading];
    }];
    asyncTask=nil;
}


- (void) createTableFooter{
    
    UIView *tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.expandTableView.bounds.size.width, 30)];
//    loadMoreText = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 200, 30.0f)];
//    [loadMoreText setCenter:tableFooterView.center];
//    [loadMoreText setText:lang(@"showmore")];
//    [loadMoreText theme:@"showmore_title"];
//    loadMoreText.textAlignment = UITextAlignmentCenter;
//    [tableFooterView addSubview:loadMoreText];
//    
//    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(moreClicked)];
//    
//    [tableFooterView addGestureRecognizer:singleTap];
//    [singleTap release];
    
    self.expandTableView.tableFooterView = tableFooterView;
    
//    [loadMoreText release];
    [tableFooterView release];
    
}

- (void)onReloadData:(UITableView *)tableView{
    [self performSelector:@selector(resetScrollImageView) withObject:nil afterDelay:0.5];
//    [self resetScrollImageView];
}

- (void)onRowNumberChange:(UITableView *)tableView{
    [self performSelector:@selector(resetScrollImageView) withObject:nil afterDelay:0.5];
//    [self resetScrollImageView];
}



- (void)resetScrollImageView{
    if (self.expandTableView.contentSize.height <= self.expandTableView.frame.size.height) {
        self.scrollImageView.hidden = YES;
    }else{
        self.scrollImageView.hidden = NO;
    }
}

#pragma marks - SubClass rewrite Methods
- (void)getActivityList{
    
}



- (float)paddingTop{
    return 10;
}

- (CGRect)getViewFrame{
    CGRect rect = [[UIScreen mainScreen]bounds];
    rect.size.height-=44.0f;
    return rect;
}

-(void)themeChanged{
    self.noActivityLabel.text = lang(@"noActivity");
    [self.expandTableView reloadData];
    [self.calendarHeaderView changeTheme];
    if(self.calendarView != nil){
        [self.calendarView themeChanged];
    }
    if(self.monthView != nil){
        [self.monthView themeChanged];
    }
}

@end
