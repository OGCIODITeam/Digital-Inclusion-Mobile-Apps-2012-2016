//
//  HotSearchView.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "HotSearchView.h"
#import "ElderlyThemeManager.h"
#import "AsyncTask.h"
#import "AppDelegate.h"
#import "ElderlyHTTPRequestManager.h"
#import "LoadingView.h"
#import "ApiError.h"
#import "ElderlyAlertUtils.h"
#import "ElderlyKeywordModel.h"

@implementation HotSearchSubView

-(id)initWithTitle:(NSString*)value{
    
    self=[self init];
    if(self){
        UIImage* img=[[ElderlyThemeManager sharedInstance] imageByTheme:@"keyword01.png"];
        CGRect rect=self.frame;
        rect.size=img.size;
        self.frame=rect;
        [self setBackgroundImage:img forState:UIControlStateNormal];
        titleLabel=[[UILabel alloc] init];
        titleLabel.text=value;
        [self setAccessibilityLabel:value];
        titleLabel.numberOfLines=1;
        [self addSubview:titleLabel];
        [titleLabel release];
    }
    return self;
}

-(void)themeChanged{
    titleLabel.frame=CGRectMake(13.0f, 8.0f, 294.0f, 0.0f);
    [titleLabel theme:@"hot_search_label"];
    [titleLabel sizeToFit];
    
    CGRect rect=self.frame;
    rect.size.width=titleLabel.frame.size.width+26.0f;
    rect.size.height=titleLabel.frame.size.height+16.0f;
    self.frame=rect;
}

@end

@interface HotSearchView()
-(void)btnTagClick:(HotSearchSubView*)subView;
@end

@implementation HotSearchView

@synthesize hotSearchdelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        list=[[NSMutableArray alloc] initWithCapacity:2];
        self.userInteractionEnabled = YES;
    
        loadingView = [[LoadingView alloc] initWithFrame:self.bounds];
//        loadingView.hidden = YES;
        [self addSubview:loadingView];
        [loadingView release];
        [self loadHotSearchData];
        
    }
    return self;
}

-(void)dealloc{
    [tags release];
    [list release];
    [super dealloc];
}

-(void)themeChanged{
     [self setArray:tags];
}

-(void)refreshLayout{
    float left=10.0f;
    float top=10.0f;
    float width=self.frame.size.width-20.0f;
    for(HotSearchSubView* subView in list){
        [subView themeChanged];
        CGRect rect=subView.frame;
        if(left+rect.size.width>width){
            left=10.0f;
            top+=rect.size.height+10.0f;
        }
        rect.origin.x=left;
        rect.origin.y=top;
        subView.frame=rect;
        
        left+=rect.size.width+10.0f;
    }
    
    self.contentSize=CGSizeMake(self.frame.size.width, top+100.0f);
}


-(void)setArray:(NSArray*)_tags{
    [list makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [list removeAllObjects];
    int index=0;
    for(ElderlyKeywordModel* keyModel in tags){
        HotSearchSubView* subView=[[HotSearchSubView alloc] initWithTitle:[ElderlyUtils text:keyModel key:@"code"]];
        subView.tag=index;
        [subView addTarget:self action:@selector(btnTagClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:subView];
        [list addObject:subView];
        [subView release];
        index++;
    }
    
    [self refreshLayout];
}

-(void)btnTagClick:(HotSearchSubView*)subView{
    ElderlyKeywordModel* keywordModel=[tags objectAtIndex:subView.tag];
    if(self.hotSearchdelegate != nil){
        [self.hotSearchdelegate selectedHotSearchView:subView.tag selectTag:keywordModel.code_tc];
    }
}

-(void)loadHotSearchData{

    AppDelegate* appdlegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    AsyncTask* task = [appdlegate.httpRequestManager getKeywordList];
    [loadingView startLoading];
    [task setFinishBlock:^{
    
        [loadingView stopLoading];
       
        NSArray* tmpArray = [task result];
        
        if(tmpArray != nil){
            [tags release];
            tags = [tmpArray retain];
            [self setArray:tmpArray];
        }
        else{
            [ElderlyAlertUtils showAlert:[[task error] errorMessage] cancelButton:lang(@"confirm") delegate:nil];
        }
        
    
    }];
    
    

}

@end
