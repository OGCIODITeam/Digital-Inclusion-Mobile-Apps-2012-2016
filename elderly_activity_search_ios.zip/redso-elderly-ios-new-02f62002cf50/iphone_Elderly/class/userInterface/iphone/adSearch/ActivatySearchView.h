//
//  ActivatySearchView.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GTGZScroller.h"

@class LabelCustomTextField;
@class TapItemView;
@class ButtonText;


@protocol ActivatySearchViewDelegate <NSObject>

-(void)selectedActivatySearchView:(NSInteger)selectIndex;

@end


@interface ActivatySearchView : GTGZScrollView{
    TapItemView* typeView;
    TapItemView* areaView;
    TapItemView* companyView;
    TapItemView* monthView;
    LabelCustomTextField* ageView;
    TapItemView* priceView;
    LabelCustomTextField* keyworViewk;
    
    ButtonText* searchButton;
}

@property(nonatomic,assign)id<ActivatySearchViewDelegate> activatySearchViewDelegate;

-(void)setType:(NSString*)value;
-(void)setAreaView:(NSString*)value;
-(void)setcompany:(NSString*)value;
-(void)setMonthView:(NSString*)value;
-(void)setPice:(NSString*)value;

-(NSString*)getType;
-(NSString*)getArea;
-(NSString*)getCompany;
-(NSString*)month;
-(NSString*)price;
-(NSString*)age;
-(NSString*)keyword;


-(void)themeChanged;

@end
