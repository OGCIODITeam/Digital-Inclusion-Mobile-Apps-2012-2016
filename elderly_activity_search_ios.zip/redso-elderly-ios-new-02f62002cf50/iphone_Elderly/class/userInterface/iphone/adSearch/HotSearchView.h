//
//  HotSearchView.h
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LoadingView;

@protocol HotSearchViewDelegate <NSObject>
@optional

-(void)selectedHotSearchView:(NSInteger)selectIndex selectTag:(NSString*)tag;

@end


@interface HotSearchSubView : UIButton{
    UILabel* titleLabel;
}

-(id)initWithTitle:(NSString*)value;

@end


@interface HotSearchView : UIScrollView{
    
    NSArray*  tags;
    NSMutableArray*  list;
    LoadingView* loadingView;
}

@property(nonatomic,assign)id<HotSearchViewDelegate> hotSearchdelegate;

-(void)themeChanged;

@end
