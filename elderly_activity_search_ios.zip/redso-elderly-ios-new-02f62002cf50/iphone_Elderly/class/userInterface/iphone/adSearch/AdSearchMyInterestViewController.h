//
//  AdSearchMyInterestViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyIphoneViewController.h"
@class ButtonText;
@class AdSearchViewController;
@class GuideView;
@interface AdSearchMyInterestViewController : ElderlyIphoneViewController{

    UITableView* myInterestTableView;
    UIImageView* scrollImageView;
    
    ButtonText* okButton;
    NSMutableArray* dataArray;
    GuideView* guideView;

}

@property(nonatomic,assign)AdSearchViewController* adSearchViewController;

@end
