//
//  AdSearchViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "AdSearchViewController.h"
#import "ElderlyNavigationController.h"
#import "AppDelegate.h"
#import "ElderlyThemeManager.h"
#import "ElderlyRootViewController.h"
#import "AppDelegate.h"
#import "ElderlyHTTPRequestManager.h"
#import "AdSearchMyCommunityCentreViewController.h"
#import "AdSearchMyInterestViewController.h"
#import "HeadTabView.h"
#import "ActivatySearchView.h"
#import "HotSearchView.h"
#import "AreaPicker.h"
#import "ElderlySearchKeyModel.h"
#import "ElderlyAlertUtils.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyUserModel.h"

#import "LocatorSearchResultViewController.h"

#import "CalendarView.h"
#import "LoadingView.h"
#import "AsyncTask.h"
#import "ApiError.h"
#import "ElderlyMyCommunityCentreModel.h"
#import "ElderlyAreaModel.h"
#import "ElderlyCategoryModel.h"
#import "ElderlyThemeGridModel.h"
#import "ElderlyGA.h"


@interface AdSearchViewController ()<HeadTabViewDelegte,HotSearchViewDelegate,ActivatySearchViewDelegate,AreaPickerDelegate,CalendarViewDelegate>

@property(nonatomic,retain)ElderlyMyCommunityCentreModel* myCommunityCentreModel;
@property(nonatomic,retain)NSString* fee;
@property(nonatomic,retain)NSString* month;
@property(nonatomic,retain)NSArray* cagtegroyArray;

-(void)initView:(int)index;
-(void)initMonthView;
-(void)initFeePicker;
-(void)initAreaPicker;
-(void)gotoAdSearchMyCommunityView;
-(void)startSearch;
@end

@implementation AdSearchViewController

@synthesize myCommunityCentreModel;
@synthesize fee;
@synthesize month;
@synthesize cagtegroyArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
        
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_ADVANCEDSEARCH];
    
    activatySearchViewSelectIndex = 0;
    searchKeyModel = [[ElderlySearchKeyModel alloc] init];

    headTabView=[[HeadTabView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 0.0f)];
    headTabView.delegate=self;
    [headTabView setTabNameArray:[NSArray arrayWithObjects:lang(@"activaty_search"),lang(@"hot_search"),nil]];
    [headTabView setTabImageView:[NSArray arrayWithObjects:@"tab_noraml_%@.png",@"tab_noraml_on_%@.png",@"tab_line_%@.png", nil]];
    [self.view addSubview:headTabView];
    [headTabView release];
    
    [self initView:0];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"ad_search")];

    [headTabView themeChanged:[NSArray arrayWithObjects:lang(@"activaty_search"),lang(@"hot_search"), nil] imageArray:[NSArray arrayWithObjects:@"tab_noraml_%@.png",@"tab_noraml_on_%@.png",@"tab_line_%@.png", nil]];
    
    [activatySearchView themeChanged];
    [hotSearchView themeChanged];
    
    [self setActivatySearchViewType];
    
    if(self.myCommunityCentreModel != nil)
        [activatySearchView setcompany:(self.myCommunityCentreModel.organizationValue.length<1?[ElderlyUtils text:self.myCommunityCentreModel key:@"centreValue"]:[ElderlyUtils text:self.myCommunityCentreModel key:@"organizationValue"])];
    
    if(regionModel != nil){
         [activatySearchView setAreaView:[ElderlyUtils text:regionModel key:@"name"]];
    }
    
    if(self.fee != nil){
        [activatySearchView setPice:self.fee];
    }
    
    if(self.month != nil){
        [activatySearchView setMonthView:self.month];
    }
        
    regionPicker = (AreaPicker*)[self.view viewWithTag:1001];
    if(regionPicker != nil){
        NSArray* regionList = [[self getAppDelegate].databaseManager getAllDistrictNameArray];
        regionPicker.list = regionList;
        [regionPicker themeChanged];
    }
    
    feePicker = (AreaPicker*)[self.view viewWithTag:1002];
    if(feePicker != nil){
        feePicker.list=[NSArray arrayWithObjects:lang(@"all"),lang(@"free"),lang(@"price1"),lang(@"price2"),lang(@"price3"),lang(@"price4"),lang(@"price5"),lang(@"price6"), nil];
        [feePicker themeChanged];
    }
    
    if(caledarView != nil){
        [caledarView themeChanged];
    }
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"ad_search")];
    
}

- (void)dealloc
{
    [regionModel release];
    self.month = nil;
    self.fee = nil;
    self.myCommunityCentreModel = nil;
    self.cagtegroyArray = nil;
    [searchKeyModel release];
    [task cancel];
    [super dealloc];
}

#pragma mark headtab delegate


-(void)tabDidSelected:(HeadTabView*)tabView index:(int)index{
    [self initView:index];
}

#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [[self getAppDelegate].rootController back];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)initView:(int)index{
    

    CGRect rect = self.view.frame;
    rect.size.height = [ElderlyUtils isRetain4]?568:480;
    self.view.frame = rect;
    
    activatySearchView.hidden=YES;
    hotSearchView.hidden=YES;
    [activatySearchView resignFirstResponder];
    

    if(index==0){

        if(activatySearchView==nil){
            activatySearchView=[[ActivatySearchView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(headTabView.frame), self.view.frame.size.width, self.view.frame.size.height-CGRectGetMaxY(headTabView.frame))];
            activatySearchView.activatySearchViewDelegate = self;
            [self.view addSubview:activatySearchView];
            [activatySearchView release];
            
        }
        activatySearchView.hidden=NO;
        

    }
    else if(index==1){
        

        
        if(hotSearchView==nil){
            hotSearchView=[[HotSearchView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(headTabView.frame), self.view.frame.size.width, ([ElderlyUtils isRetain4]?568:480)-CGRectGetMaxY(headTabView.frame))];
            hotSearchView.hotSearchdelegate = self;
            [self.view addSubview:hotSearchView];
            [hotSearchView release];
        }
        hotSearchView.hidden=NO;

    }
}

-(void)initAreaPicker{
    
    
    NSArray* regionList = [[self getAppDelegate].databaseManager getAllDistrictNameArray];
        
    regionPicker = [[AreaPicker alloc] init];
    regionPicker.tag = 1001;
    regionPicker.list=regionList;
    regionPicker.blackPanelFrame=CGRectMake(0.0f, 0, self.view.frame.size.width, self.view.frame.size.height);
    regionPicker.delegate = self;
    regionPicker.animationIsRun = NO;
//    [regionPicker cancelImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_cancel_%@.png"] comfirmImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_sure_%@.png"]];
//    [regionPicker selectedView:[[ElderlyThemeManager sharedInstance] imageByMotif:@"search_area_selected_%@.png"] ];
    [regionPicker showInView:self.view];
    [regionPicker release];
}

-(void)initFeePicker{

    feePicker = [[AreaPicker alloc] init];
    feePicker.tag = 1002;
    feePicker.list=[NSArray arrayWithObjects:lang(@"all"),lang(@"free"),lang(@"price1"),lang(@"price2"),lang(@"price3"),lang(@"price4"),lang(@"price5"),lang(@"price6"), nil];
    feePicker.blackPanelFrame=CGRectMake(0.0f, 0, self.view.frame.size.width, self.view.frame.size.height);
    feePicker.delegate = self;
    feePicker.animationIsRun = YES;
//     [feePicker cancelImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_cancel_%@.png"] comfirmImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_sure_%@.png"]];
//    [feePicker selectedView:[[ElderlyThemeManager sharedInstance] imageByMotif:@"search_area_selected_%@.png"] ];
    [feePicker showInView:self.view];
    [feePicker release];

}

-(void)initMonthView{
    
    caledarView = [[CalendarView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, (self.view.frame.size.height>568?568:self.view.frame.size.height) ) andDate:[NSDate date]];
    caledarView.delegate = self;
    [activatySearchView addSubview:caledarView];
    [caledarView release];

}


-(void)gotoAdSearchMyCommunityView{

    
    if(searchKeyModel.activeArea.length < 1){
    
        [ElderlyAlertUtils showAlert:lang(@"regionCueMsg2") cancelButton:lang(@"confirm") delegate:nil];
        return ;
    }
    
    
    [task cancel];

    CGRect rect = self.view.frame;
    rect.size.height = [ElderlyUtils isRetain4]?568:480;
    self.view.frame = rect;

    loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:loadingView];
    [loadingView release];
    [loadingView startLoading];
    
    task = [[self getAppDelegate].httpRequestManager getMyCommunityCentreList:searchKeyModel.activeArea offset:0 pageSize:20];
    [task setFinishBlock:^{

        
        NSArray* list=[task result];
        [loadingView stopLoading];
        [loadingView removeFromSuperview];
        loadingView = nil;
        if(list != nil){
            
            if(list.count < 1){
            
                
                [ElderlyAlertUtils showAlert:lang(@"myCommunity1") delegate:nil];
                task=nil;
                return ;
            }
            
            AdSearchMyCommunityCentreViewController* tableViewController = [[AdSearchMyCommunityCentreViewController alloc] init];
            tableViewController.dataArray = list;
            tableViewController.searchKey = searchKeyModel.activeArea;
            tableViewController.adSearchViewController = self;
            [self.navigationController pushViewController:tableViewController animated:YES];
            [tableViewController release];
            
        }
        else{
            [ElderlyAlertUtils showAlert:[[task error] errorMessage] cancelButton:lang(@"confirm") delegate:nil];
        }
        
        task=nil;
        
        
    }];
    

}

-(void)setCompany:(ElderlyMyCommunityCentreModel*)value{
    self.myCommunityCentreModel = value;
    [activatySearchView setcompany:(self.myCommunityCentreModel.organizationValue.length<1?[ElderlyUtils text:self.myCommunityCentreModel key:@"centreValue"]:[ElderlyUtils text:self.myCommunityCentreModel key:@"organizationValue"])];
}

-(void)setCategoryName:(NSArray*)array{
    self.cagtegroyArray = array;
    
    [self setActivatySearchViewType];
 }

-(void)setActivatySearchViewType{
    
    if(self.cagtegroyArray == nil)
        return;
    
    
    NSMutableString* str = [[NSMutableString alloc] init];
    for(int i=0; i<self.cagtegroyArray.count;i++){
        ElderlyCategoryModel* model = [self.cagtegroyArray objectAtIndex:i];
        if(i==0){
            [str appendString:[ElderlyUtils text:model key:@"name"]];
        }
        else{
            [str appendString:[NSString stringWithFormat:@",%@",[ElderlyUtils text:model key:@"name"]]];
        }
    }

    if(str.length > 1)
        [activatySearchView setType:(str)];
    [str release];

}

-(NSArray*)getcategoryArray{
    return self.cagtegroyArray;
}

-(void)startSearch{
    
    if(![ElderlyUtils checkNetWork]){
        [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
        return;
    }
    
    NSMutableString* str = [[NSMutableString alloc] init];
    for(int i=0; i<self.cagtegroyArray.count;i++){
        ElderlyCategoryModel* model = [self.cagtegroyArray objectAtIndex:i];
        if(i==0){
            [str appendString:model.name_tc];
        }
        else{
            [str appendString:[NSString stringWithFormat:@",%@",model.name_tc]];
        }
    }
    
    searchKeyModel.eventType = str;
    [str release];
    
    searchKeyModel.keyword = activatySearchView.keyword;
    searchKeyModel.age = [activatySearchView.age integerValue];
    

    searchKeyModel.organization = self.myCommunityCentreModel.nid;
    searchKeyModel.searchtype = adSearch;

    
    LocatorSearchResultViewController* controller=[[LocatorSearchResultViewController alloc] init];
    controller.searchKeyModel = searchKeyModel;
    controller.searchKeyModel.isAdSearch = YES;
    controller.navTitle = @"ad_search_result";
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];

    

}

#pragma mark hotSearchView Delegate
-(void)selectedHotSearchView:(NSInteger)selectIndex selectTag:(NSString*)tag{

    NSLog(@"selectedHotSearchView");
    
    if(![ElderlyUtils checkNetWork]){
        [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
        return;
    }
    
    
    
    [[ElderlyGA sharedInstance] trackEvent:GA_CODE_HOTKEY];
    
    ElderlySearchKeyModel* hotSearchKeyModel = [[ElderlySearchKeyModel alloc] init];
    hotSearchKeyModel.keyword = tag;
    hotSearchKeyModel.searchtype = hotSearch;
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = lang(@"yyyy-MM");
    NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
    hotSearchKeyModel.month = dateStr;
    [dateFormatter release];
    LocatorSearchResultViewController* controller=[[LocatorSearchResultViewController alloc] init];
    controller.searchKeyModel = hotSearchKeyModel;
    controller.searchKeyModel.isAdSearch = YES;
    controller.navTitle = @"ad_search_result";
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    

    [hotSearchKeyModel release];

}

#pragma mark ActivatySearchView Delegate
-(void)selectedActivatySearchView:(NSInteger)selectIndex{

    activatySearchViewSelectIndex = selectIndex;
    
    switch (selectIndex) {
        case 1:{
        
            AdSearchMyInterestViewController* myInterestViewController = [[AdSearchMyInterestViewController alloc] init];
            myInterestViewController.adSearchViewController = self;
            [self.navigationController pushViewController:myInterestViewController animated:YES];
            [myInterestViewController release];
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_ACTIVITYTYPE];

            break;
        }
        case 2:{

            [self initAreaPicker];
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_ACTIVITYLOCATION];
            break;
        }
        case 3:{
            [self gotoAdSearchMyCommunityView];
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_ORGANIZATION];
            break;
        }
        case 4:{
            [self initMonthView];
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_DATE];
            
            break;
        }
        case 6:{
            [self initFeePicker];
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_PRICE];
            break;
        }
        case 8:{
            [self startSearch];
            [[ElderlyGA sharedInstance] trackEvent:GA_CODE_SEARCHBUTTON];
        }
            
            
        default:
            break;
    }
}

#pragma mark AreaPicke Delegate
-(void)didClickAreaPicker:(AreaPicker*)picker confirm:(BOOL)confirm{

    if(confirm){
        if(picker.tag == 1001){
            [regionModel release];
            regionModel = [[[self getAppDelegate].databaseManager getAreaModelForName:[picker.list objectAtIndex:picker.selectedIndex]] retain];
            [activatySearchView setAreaView:[ElderlyUtils text:regionModel key:@"name"]];
            
            searchKeyModel.activeArea = regionModel.value;
            self.myCommunityCentreModel = nil;
            [activatySearchView setcompany:nil];
        }
        else if(picker.tag == 1002){
            
            self.fee = [picker.list objectAtIndex:picker.selectedIndex];
            [activatySearchView setPice:self.fee];
            searchKeyModel.fee = [[NSArray arrayWithObjects:@"",lang(@"free"),@"1,100",@"101,300",@"301,500",@"501,700",@"701,1000",@"1000", nil] objectAtIndex:picker.selectedIndex];
        }
    }
    
}

#pragma mark caledarView Delegate
- (void)onDateSelect:(NSDate*) date{
    NSLog(@"%@",date);
    
    
//    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:date];
//    
//    int year;
//    NSDateComponents *currentComp = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:[NSDate date]];
//    
//    year = currentComp.year;
//    if(year < components.year){
//        year = components.year;
//    }
//    
//    if (currentComp.month > [components month]) {
//        year++;
//    }
//
//    NSString* format = @"%d-%d";
//    if([components month] < 10){
//        format = @"%d-0%d";
//    }
//    
//    searchKeyModel.month = [NSString stringWithFormat:format,year,[components month]];
    self.month = [ElderlyUtils convertStringFromDate:date];
    searchKeyModel.month = self.month;
    [activatySearchView setMonthView:self.month];
    
    

    
    [caledarView removeFromSuperview];
    caledarView = nil;
}


- (void)onNoDateSelect{
    [caledarView removeFromSuperview];
    caledarView = nil;
}


@end
