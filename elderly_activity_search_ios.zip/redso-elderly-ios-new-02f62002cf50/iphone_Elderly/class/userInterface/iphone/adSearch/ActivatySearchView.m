//
//  ActivatySearchView.m
//  iphone_Elderly
//
//  Created by fanty on 13-8-20.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ActivatySearchView.h"

#import "LabelCustomTextField.h"

#import "ElderlyThemeManager.h"
#import "ButtonText.h"
#import "TapItemView.h"
#import "AppDelegate.h"
#import "ElderlySettingManager.h"
#import "MyCommunityCentre.h"
#import "ElderlyGA.h"

@interface ActivatySearchView()<GTGZTouchScrollerDelegate,UITextFieldDelegate>

@end

@implementation ActivatySearchView

@synthesize activatySearchViewDelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.touchDelegate=self;
        self.scrollEnabled = NO;
        UIImage* img=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"txt_input02.png"];
        UIImage* img_search=[[ElderlyThemeManager sharedInstance] imageResourceByTheme:@"txt_input_search.png"];

        typeView=[[TapItemView alloc] initWithImage:img];
        areaView=[[TapItemView alloc] initWithImage:img];
        companyView=[[TapItemView alloc] initWithImage:img];
        monthView=[[TapItemView alloc] initWithImage:img];
        ageView=[[LabelCustomTextField alloc] initWithImage:img];
        priceView=[[TapItemView alloc] initWithImage:img];
        keyworViewk=[[LabelCustomTextField alloc] initWithImage:img_search];
        AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
        NSInteger fontSize = [appDelegate.settingManager getFontType];
        [ageView setFont:@"STHeitiTC-Medium" size:(fontSize == 0?17:(fontSize==1?19:21))];
        [keyworViewk setFont:@"STHeitiTC-Medium" size:(fontSize == 0?17:(fontSize==1?19:21))];
  

        ageView.delegate=self;
        keyworViewk.delegate=self;

        [ageView textFieldReturnType:UIReturnKeyDone];
        [ageView setKeyBoardType:UIKeyboardTypeNumberPad];
        [keyworViewk textFieldReturnType:UIReturnKeyDone];
        
        
        typeView.tag = 1;
        areaView.tag = 2;
        companyView.tag = 3;
        monthView.tag = 4;
        ageView.tag = 5;
        priceView.tag = 6;
        keyworViewk.tag = 7;
        
        [typeView addTarget:self action:@selector(clickButton:)];
        [areaView addTarget:self action:@selector(clickButton:)];
        [companyView addTarget:self action:@selector(clickButton:)];
        [monthView addTarget:self action:@selector(clickButton:)];
        [priceView addTarget:self action:@selector(clickButton:)];
    
        CGRect rect=typeView.frame;
        rect.origin.y=5.0f;
        rect.size.width=self.frame.size.width;
        typeView.frame=rect;
        
        rect=areaView.frame;
        rect.origin.y=CGRectGetMaxY(typeView.frame);
        rect.size.width=self.frame.size.width;
        areaView.frame=rect;
        
        rect=companyView.frame;
        rect.origin.y=CGRectGetMaxY(areaView.frame);
        rect.size.width=self.frame.size.width;
        companyView.frame=rect;

        rect=monthView.frame;
        rect.origin.y=CGRectGetMaxY(companyView.frame);
        rect.size.width=self.frame.size.width;
        monthView.frame=rect;

        rect=ageView.frame;
        rect.origin.y=CGRectGetMaxY(monthView.frame);
        rect.size.width=self.frame.size.width;
        ageView.frame=rect;

        rect=priceView.frame;
        rect.origin.y=CGRectGetMaxY(ageView.frame);
        rect.size.width=self.frame.size.width;
        priceView.frame=rect;

        rect=keyworViewk.frame;
        rect.origin.y=CGRectGetMaxY(priceView.frame);
        rect.size.width=self.frame.size.width;
        keyworViewk.frame=rect;
        

        UIImage* searchImage = [[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_%@.png"];

        searchButton = [[ButtonText alloc] initWithFrame:CGRectMake((frame.size.width-searchImage.size.width)*0.5f, CGRectGetMaxY(keyworViewk.frame)-20 + (self.bounds.size.height - CGRectGetMaxY(keyworViewk.frame) - searchImage.size.height)*0.5f, searchImage.size.width, searchImage.size.height)];
        searchButton.spacing = 5.0f;
        [searchButton text:lang(@"search")];
        [searchButton theme:@"activity_search_title"];
        [searchButton setBackgroundImage:searchImage forState:UIControlStateNormal];
        [searchButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_search_white.png"]];
        searchButton.tag = 8;
        [searchButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];


        typeView.leftText=lang(@"activity_type");
        areaView.leftText=lang(@"activaty_area");
        companyView.leftText=lang(@"company");
        monthView.leftText=lang(@"date");
        ageView.leftText=lang(@"age");
        priceView.leftText=lang(@"fee");
        keyworViewk.leftText=lang(@"keyword");

        
        typeView.text = lang(@"pls_select");
        areaView.text = lang(@"pls_select");
        companyView.text = lang(@"pls_select");
        monthView.text = lang(@"pls_select");
        [ageView placeHolderText:lang(@"pls_inputAge")];
        priceView.text = lang(@"pls_select");
        [keyworViewk placeHolderText:lang(@"pls_selectkeyword")];
        
        
        self.showsHorizontalScrollIndicator=NO;
        self.showsVerticalScrollIndicator=NO;
//        self.contentSize=CGSizeMake(frame.size.width, CGRectGetMaxY(searchButton.frame)+260.0f);


        [self addSubview:typeView];
        [self addSubview:areaView];
        [self addSubview:companyView];
        [self addSubview:monthView];
        [self addSubview:ageView];
        [self addSubview:priceView];
        [self addSubview:keyworViewk];
        [self addSubview:searchButton];
        
        [typeView release];
        [areaView release];
        [companyView release];
        [monthView release];
        [ageView release];
        [priceView release];
        [keyworViewk release];
        [searchButton release];
        
        
    
    }
    return self;
}


#pragma mark method

-(void)themeChanged{
    [typeView themeChanged];
    [areaView themeChanged];
    [companyView themeChanged];
    [monthView themeChanged];
    [ageView themeChanged];
    [priceView themeChanged];
    [keyworViewk themeChanged];
    
    typeView.leftText=lang(@"activity_type");
    areaView.leftText=lang(@"activaty_area");
    companyView.leftText=lang(@"company");
    monthView.leftText=lang(@"date");
    ageView.leftText=lang(@"age");
    priceView.leftText=lang(@"fee");
    keyworViewk.leftText=lang(@"keyword");
    
    
    typeView.text = lang(@"pls_select");
    areaView.text = lang(@"pls_select");
    companyView.text = lang(@"pls_select");
    monthView.text = lang(@"pls_select");
    priceView.text = lang(@"pls_select");

    [keyworViewk placeHolderText:lang(@"pls_selectkeyword")];
    [ageView placeHolderText:lang(@"pls_inputAge")];
    
    [searchButton text:lang(@"search")];
    [searchButton theme:@"activity_search_title"];
    [searchButton setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_search_%@.png"] forState:UIControlStateNormal];
    

    AppDelegate* appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    NSInteger fontSize = [appDelegate.settingManager getFontType];
    
    CGFloat font = 17;
    if(fontSize == 1){
        font = 19;
    }
    else if(fontSize == 2){
        font = 21;
    }
    
    [ageView setFont:@"STHeitiTC-Medium" size:font];
    [keyworViewk setFont:@"STHeitiTC-Medium"  size:font];

    
}

-(BOOL)resignFirstResponder{

    [ageView resignFirstResponder];
    [keyworViewk resignFirstResponder];
    
     [self setContentOffset:CGPointMake(0, 0) animated:YES];
    
    return YES;
}

-(void)positionForTextField:(LabelCustomTextField*)labelCustomTextField{
    CGPoint  poisition=self.contentOffset;
    
    poisition.y=0.0f;
    if([labelCustomTextField isEqual:ageView]){
        poisition.y=180.0f;
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_AGE];
    }
    else if([labelCustomTextField isEqual:keyworViewk]){
        poisition.y=260.0f;
        [[ElderlyGA sharedInstance] trackEvent:GA_CODE_KEYWORD];
    }
    
    [self setContentOffset:poisition animated:YES];
}


-(void)setType:(NSString*)value{
    if(value.length > 1){
        typeView.text = value;
        [typeView highlight:YES];
    }
    else{
        typeView.text = lang(@"pls_select");
        [typeView highlight:NO];
    }

}

-(void)setAreaView:(NSString*)value{
    areaView.text = value;
    [areaView highlight:YES];
}

-(void)setcompany:(NSString*)value{
    if(value){
        companyView.text = value;
        [companyView highlight:YES];
    }
    else{
        companyView.text = lang(@"pls_select");
        [companyView highlight:NO];
    }

  
}

-(void)setMonthView:(NSString*)value{
    monthView.text = value;
    [monthView highlight:YES];
}

-(void)setPice:(NSString*)value{
    priceView.text = value;
    [priceView highlight:YES];
}

-(NSString*)getType{
    return typeView.text;
}

-(NSString*)getArea{
    return typeView.text;
}


-(NSString*)getCompany{
    return companyView.text;
}


-(NSString*)month{
    return monthView.text;
}


-(NSString*)price{
    return priceView.text;
}

-(NSString*)age{

    return ageView.text;
}


-(NSString*)keyword{
    return keyworViewk.text;
}

#pragma mark gtgzscroll delegate

- (void)tableView:(UIScrollView *)tableView
     touchesBegan:(NSSet *)touches
        withEvent:(UIEvent *)event{
    
    [self resignFirstResponder];

}

#pragma mark textfield delegate


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [self positionForTextField:(LabelCustomTextField*)textField.superview.superview];
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{

    [self resignFirstResponder];

    return YES;
}

-(void)clickButton:(id)sender{

    [self resignFirstResponder];
    MyCommunityCentre* tapItemView = (MyCommunityCentre*)sender;
    NSLog(@"clickButton:%d",tapItemView.tag);
    
    if(self.activatySearchViewDelegate != nil){
        [self.activatySearchViewDelegate selectedActivatySearchView:tapItemView.tag];
    }

}

@end
