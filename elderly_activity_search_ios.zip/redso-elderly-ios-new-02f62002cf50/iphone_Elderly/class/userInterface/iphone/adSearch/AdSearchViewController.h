//
//  AdSearchViewController.h
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "ElderlyContentViewController.h"
@class HeadTabView;
@class ActivatySearchView;
@class HotSearchView;
@class ButtonText;
@class AreaPicker;
@class CalendarView;
@class LoadingView;
@class AsyncTask;
@class ElderlySearchKeyModel;
@class ElderlyMyCommunityCentreModel;
@class ElderlyAreaModel;
@interface AdSearchViewController : ElderlyContentViewController{
    HeadTabView* headTabView;
    
    
    ActivatySearchView* activatySearchView;
    NSInteger activatySearchViewSelectIndex;
    
    HotSearchView* hotSearchView;
    CalendarView* caledarView;
    AreaPicker* feePicker;
    AreaPicker* regionPicker;
    
    LoadingView* loadingView;
    AsyncTask* task;
    ElderlySearchKeyModel* searchKeyModel;
    ElderlyAreaModel* regionModel;

}

-(void)setCompany:(ElderlyMyCommunityCentreModel*)value;
-(void)setCategoryName:(NSArray*)array;
-(NSArray*)getcategoryArray;


@end
