//
//  AdSearchMyInterestViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-9-13.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "AdSearchMyInterestViewController.h"

#import "AppDelegate.h"
#import "ElderlyNavigationController.h"
#import "ElderlyRootViewController.h"
#import "ElderlyTableCell.h"
#import "ElderlyThemeManager.h"
#import "ButtonText.h"
#import "ElderlyGuideMannager.h"
#import "GuideView.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyCategoryModel.h"
#import "ElderlyUserModel.h"
#import "ElderlyProfileSettingManager.h"
#import "ElderlyCategoryModel.h"
#import "AdSearchViewController.h"
#import "ElderlyAlertUtils.h"

@interface AdSearchMyInterestViewController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation AdSearchMyInterestViewController

@synthesize adSearchViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    dataArray = [[NSMutableArray alloc] init];
    
    int i=0;
    for(ElderlyCategoryModel* model in [[self getAppDelegate].databaseManager getCategoryArray]){
        
        ElderlyCategoryModel* temp = [model mutableCopy];
        if(self.adSearchViewController != nil && [self.adSearchViewController getcategoryArray] != nil){
            for(ElderlyCategoryModel* cagtegoryModel in [self.adSearchViewController getcategoryArray]){
                if([temp.key isEqualToString:cagtegoryModel.key]){
                    temp.isSelected = cagtegoryModel.isSelected;
                    i++;
                }
            }
        }
        
        [dataArray addObject:temp];
        [temp release];
    }
    
    ElderlyCategoryModel* categoryModel =[[ElderlyCategoryModel alloc] init];
    categoryModel.key = @"";
    categoryModel.name = lang(@"all");
    categoryModel.name_tc = lang(@"all");
    categoryModel.isSelected = NO;
    if(i == dataArray.count){
        categoryModel.isSelected = YES;
    }

    [dataArray insertObject:categoryModel atIndex:0];
    [categoryModel release];

    

    
    
    UIImage* img = [[ElderlyThemeManager sharedInstance] imageByTheme:@"bg_ok.png"];
    
    myInterestTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - img.size.height-44)];
    //[myInterestTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    myInterestTableView.showsVerticalScrollIndicator = NO;
    [myInterestTableView setDataSource:self];
    [myInterestTableView setDelegate:self];
    [self.view addSubview:myInterestTableView];
    [myInterestTableView release];
    
    
    UIImage* image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
    scrollImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, myInterestTableView.frame.size.height - image.size.height, image.size.width, image.size.height)];
    scrollImageView.image = image;
    [self.view addSubview:scrollImageView];
    [scrollImageView release];
    
    
    UIImageView* buttomBgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - img.size.height-44, img.size.width, img.size.height)];
    buttomBgView.image = img;
    buttomBgView.userInteractionEnabled = YES;
    
    img = [[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_ok_%@.png"];
    
    okButton = [[ButtonText alloc] initWithFrame:CGRectMake((buttomBgView.bounds.size.width - img.size.width)*0.5f,(buttomBgView.bounds.size.height - img.size.height)*0.5f, img.size.width, img.size.height)];
    okButton.spacing=5.0f;
    [okButton setBackgroundImage:img forState:UIControlStateNormal];
    [okButton arrow:[[ElderlyThemeManager sharedInstance] imageByTheme:@"icon_sure.png"]];
    [okButton text:lang(@"confirm")];
    [okButton theme:@"okButton_title"];
    [okButton addTarget:self action:@selector(selectOKButton) forControlEvents:UIControlEventTouchUpInside];
    
    [buttomBgView addSubview:okButton];
    [okButton release];
    
    [self.view addSubview:buttomBgView];
    [buttomBgView release];
    
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:advancedSearchGuide]){
        
        guideView = [[GuideView alloc] initWithFrame:self.view.bounds];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide06_%@.png"]];
        [guideView setGuideOrignY:0];
        guideView.tag = 999;
        [guideView addTarget:self action:@selector(clickGuideView) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:guideView];
        [guideView release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    
    [dataArray release];
    [super dealloc];
}

-(void)willShowViewController{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"activity_type")];
    
}

-(void)themeChanged{
    
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"activity_type")];
    
    [okButton text:lang(@"confirm")];
    [okButton theme:@"okButton_title"];
    [okButton setBackgroundImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_ok_%@.png"] forState:UIControlStateNormal];
    [myInterestTableView reloadData];
    
    if([[ElderlyGuideMannager sharedInstance] getGudieState:advancedSearchGuide]){
        
        [guideView removeAllSubView];
        [guideView addImageView:[[ElderlyThemeManager sharedInstance] imageByLangeuage:@"guide06_%@.png"]];
    }
}


#pragma mark methods

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}

-(void)clickGuideView{
    NSLog(@"clickGuideView");
    guideView = (GuideView*)[self.view viewWithTag:999];
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        guideView.alpha=0.0f;
    } completion:^(BOOL finish){
        [guideView removeFromSuperview];
        
    }];
    
    [[ElderlyGuideMannager sharedInstance] setGudieState:advancedSearchGuide state:NO];
    
}

-(void)selectOKButton{
    
   
    
    if(self.adSearchViewController != nil){
        
        NSMutableArray* selectArray = [[NSMutableArray alloc] init];
        for(int i=1;i<dataArray.count;i++){
            ElderlyCategoryModel* model = [dataArray objectAtIndex:i];
            if(model.isSelected){
                [selectArray addObject:model];
            }
        }
        
        if(selectArray.count < 1){
            [ElderlyAlertUtils showAlert:lang(@"selectMsg") delegate:nil];
            
            [selectArray release];
            return ;
        }
  
        
        [self.adSearchViewController setCategoryName:selectArray];
        
        [selectArray release];
    
    }
    


    
    [self.navigationController popViewControllerAnimated:YES];
    
}

#pragma mark UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [dataArray count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    ElderlyTableCell* cell = (ElderlyTableCell*)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    if(cell == nil)
        return 65;
    return [cell getCellHeight];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return scrollImageView.frame.size.height;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView* footerView = [[[UIView alloc] init] autorelease];
    footerView.backgroundColor = [UIColor clearColor];
    return footerView;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifier = @"Cell";
    ElderlyTableCell* cell = [ myInterestTableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil){
        cell = [[[ElderlyTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
        [cell setSelectImage:[[ElderlyThemeManager sharedInstance] imageByMotif:@"btn_add_chosen_%@.png"] ];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
    }
    
    ElderlyCategoryModel* model = [dataArray objectAtIndex:indexPath.row];
    [cell setTitle:[ElderlyUtils text:model key:@"name"]];
    [cell selectItem:model.isSelected];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"didSelectRowAtIndexPath");
    
    ElderlyCategoryModel* allModel = [dataArray objectAtIndex:0];

    if(indexPath.row == 0){

        allModel.isSelected = !allModel.isSelected;
        for(ElderlyCategoryModel* model  in dataArray){
            model.isSelected = allModel.isSelected;
        }
    }
    else{
        ElderlyCategoryModel* model = [dataArray objectAtIndex:indexPath.row];
        model.isSelected = !model.isSelected;
        if(allModel.isSelected){
            allModel.isSelected = !allModel.isSelected;
        }
    }
    

    [myInterestTableView reloadData];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if(scrollView.contentOffset.y <= 0){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll.png"];
        
    }
    else if(scrollView.contentOffset.y>=scrollView.contentSize.height-scrollView.frame.size.height){
        scrollImageView.image = [[ElderlyThemeManager sharedInstance] imageByTheme:@"btn_scroll_up.png"];
    }
}

@end
