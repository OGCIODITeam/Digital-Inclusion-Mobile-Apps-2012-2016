//
//  FavoCenterViewController.m
//  iphone_Elderly
//
//  Created by GT mac_5 on 13-8-9.
//  Copyright (c) 2013年 GT mac_5. All rights reserved.
//

#import "FavoCenterViewController.h"
#import "ElderlyNavigationController.h"
#import "ElderlyThemeManager.h"
#import "AppDelegate.h"
#import "ElderlyRootViewController.h"
#import "ThreadTask.h"
#import "ElderlyDatabaseManager.h"
#import "ElderlyMyCommunityCentreModel.h"
#import "ElderlySearchModel.h"
#import "ElderlyNewActivityModel.h"
#import "ElderlyHTTPRequestManager.h"
#import "ElderlyGA.h"
#import "ElderlyAlertUtils.h"

@interface FavoCenterViewController ()

@property (retain, nonatomic) ThreadTask *task;

@end

@implementation FavoCenterViewController
@synthesize task;


- (void)dealloc
{
    [self.task cancel];
    self.task = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.navigationItem.leftBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_back.png" right:NO target:self action:@selector(navigationLeftClick)] autorelease];
        self.navigationItem.rightBarButtonItem = [[[ElderlyBarButtonItem alloc] initWithImage:@"btn_setting.png" right:YES target:self action:@selector(navigationRightClick)] autorelease];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [[ElderlyGA sharedInstance] trackPageView:GA_CODE_PG_FAVOURITECENTER];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willShowViewController{
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav barBackground:[[ElderlyThemeManager sharedInstance] getColorImageName]];
    [nav titleView:lang(@"favo_center")];
    
}

-(void)navigationLeftClick{
    
    NSLog(@"navigationLeftClick");
    
    [[self getAppDelegate].rootController back];
    
}

-(void)navigationRightClick{
    NSLog(@"navigationRightClick");
    [[self getAppDelegate].rootController goSettingViewController:self.navigationController];
    
}


-(void)themeChanged{
    [super themeChanged];
    ElderlyNavigationController* nav = (ElderlyNavigationController*)self.navigationController;
    [nav titleView:lang(@"favo_center")];
    if(self.noActivityLabel.hidden == NO){
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        [[self getAppDelegate].databaseManager getMyCommuntiyCentre:dic];
        
        NSArray *allKeys = [dic allKeys];
        if(allKeys == nil || allKeys.count < 1)
            self.noActivityLabel.text = lang(@"favoNoSetting");
        else
            self.noActivityLabel.text = lang(@"favoNoActivity");
        [dic release];
       
    }
}

- (NSInteger)themeIndx{
    return 1;
}

- (void)getActivityList{
    
    if(![ElderlyUtils checkNetWork]){
        [ElderlyAlertUtils showAlert:lang(@"connect_error") delegate:nil];
        return;
    }
    
    [self.loadingView startLoading];
    msg = nil;
    self.task = [ThreadTask asyncStart:^{
        
 
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        NSMutableArray *list = [[NSMutableArray alloc] init];
        
        [[self getAppDelegate].databaseManager getMyCommuntiyCentre:dic];
        
        NSArray *allKeys = [dic allKeys];
        if(allKeys == nil || allKeys.count < 1)
            msg = lang(@"favoNoSetting");
        
        for (int i=0; i<allKeys.count; i++) {
            NSString *key = [allKeys objectAtIndex:i];
            ElderlyMyCommunityCentreModel *centerModel = [dic objectForKey:key];
            
            ElderlySearchModel *searchModel = [[ElderlySearchModel alloc] init];
            searchModel.centerId = centerModel.nid;
            searchModel.activityCenterName = centerModel.centreValue;
            searchModel.activityCenterName_tc = centerModel.centreValue_tc;
            searchModel.organization = centerModel.organizationValue;
            searchModel.organization_tc = centerModel.organizationValue_tc;
            
            NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = @"yyyy-MM-dd";
            NSString *dateStr = [dateFormatter stringFromDate:self.currentDate];
            [dateFormatter release];
            
            NSArray *activityList = [[self getAppDelegate].httpRequestManager getMyFavouriteCentre:searchModel.centerId date:dateStr];
            searchModel.activityList = activityList;
            
            if (activityList.count>0){
                [list addObject:searchModel];
            }
            [searchModel release];
        }
        
        self.centerList = list;
        [list release];
        
        [dic release];
    } end:^{
        [self.expandTableView reloadData];
        [self.loadingView stopLoading];
        
        if (self.centerList.count>0) {
            self.expandTableView.hidden = NO;
            self.noActivityLabel.hidden = YES;
        }else{
            self.expandTableView.hidden = YES;
            self.noActivityLabel.hidden = NO;
            self.scrollImageView.hidden = YES;
            self.noActivityLabel.text = (msg==nil?lang(@"favoNoActivity"):msg);
            [self.noActivityLabel sizeToFit];
            self.noActivityLabel.center = CGPointMake(self.view.frame.size.width/2, (self.view.frame.size.height/2 > 262 ? 262:self.view.frame.size.height/2));
        }
    }];
}



@end
